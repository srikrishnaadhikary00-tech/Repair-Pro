const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_user_001";
const BOB_UID = "bob_user_002";
const ADMIN_UID = "super_admin_001";
const ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users are blocked from all collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("problem_reports").get());
  await assertFails(unauthDb.collection("catalog_entries").where("published", "==", true).get());
  await assertFails(unauthDb.collection("app_settings").doc("admob_config").get());
  await assertFails(unauthDb.collection("audit_logs").get());
});

test("User profile create, partial update, cross-user denial, and shadow field rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Tech",
      preferredLanguage: "bn",
      adConsentGranted: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      preferredLanguage: "hi",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject ghost field / role escalation
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "SUPER_ADMIN",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject cross-user read & write
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      displayName: "Hijacked",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Saved guides subcollection allows owner list/create/delete and blocks other users", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 3000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("saved_guides").doc("err_lg_ch05").set({
      userId: ALICE_UID,
      itemType: "ERROR_CODE",
      itemId: "err_lg_ch05",
      categoryId: "ac",
      title: "LG AC CH05",
      subtitle: "Indoor-Outdoor Communication Error",
      createdAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("saved_guides").get()
  );

  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("saved_guides").get()
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("saved_guides").doc("err_lg_ch05").delete()
  );
});

test("Problem reports enforce owner filtered list, PENDING create, and Admin-only status update", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const spoofedAdminDb = testEnv.authenticatedContext("spoof_1", {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 4000);

  // Alice creates a valid PENDING report
  await assertSucceeds(
    aliceDb.collection("problem_reports").doc("rep_001").set({
      userId: ALICE_UID,
      categoryId: "ac",
      brandName: "LG",
      modelName: "Dual Inverter 1.5T",
      errorCode: "CH05",
      description: "Outdoor unit stops after 3 minutes and indoor blinks 5 times.",
      preferredLanguage: "bn",
      status: "PENDING",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice cannot bypass PENDING status on create
  await assertFails(
    aliceDb.collection("problem_reports").doc("rep_002").set({
      userId: ALICE_UID,
      categoryId: "ac",
      brandName: "LG",
      description: "Trying to self-publish report",
      preferredLanguage: "en",
      status: "PUBLISHED",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice can query her own reports, cannot run unfiltered list
  await assertSucceeds(
    aliceDb.collection("problem_reports").where("userId", "==", ALICE_UID).get()
  );
  await assertFails(aliceDb.collection("problem_reports").get());
  await assertFails(bobDb.collection("problem_reports").doc("rep_001").get());

  // Unverified spoofed admin email cannot read or update
  await assertFails(spoofedAdminDb.collection("problem_reports").get());
  await assertFails(
    spoofedAdminDb.collection("problem_reports").doc("rep_001").update({
      status: "REVIEWED",
      adminNote: "Spoofed",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Verified Super Admin can list all and update status/adminNote
  await assertSucceeds(adminDb.collection("problem_reports").get());
  await assertSucceeds(
    adminDb.collection("problem_reports").doc("rep_001").update({
      status: "PUBLISHED",
      adminNote: "Verified against LG service manual and added to catalog.",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Catalog entries, App Settings / AdMob config, and Audit logs enforce Admin RBAC", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 4000);

  // Regular user cannot create catalog entry or modify AdMob config
  await assertFails(
    aliceDb.collection("catalog_entries").doc("cat_custom_1").set({
      entryType: "ERROR_CODE",
      categoryId: "ac",
      brandName: "Daikin",
      code: "U4",
      titleEn: "U4 Signal Error",
      summaryEn: "Transmission error between indoor and outdoor units.",
      verificationStatus: "VERIFIED",
      published: true,
      revision: 1,
      updatedByUid: ALICE_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(
    aliceDb.collection("app_settings").doc("admob_config").set({
      configType: "ADMOB",
      adsGlobalEnabled: false,
      updatedByUid: ALICE_UID,
      updatedAt: now,
    })
  );

  // Super Admin can publish catalog entry
  await assertSucceeds(
    adminDb.collection("catalog_entries").doc("cat_custom_1").set({
      entryType: "ERROR_CODE",
      categoryId: "ac",
      brandName: "Daikin",
      code: "U4",
      titleEn: "U4 Signal Error",
      summaryEn: "Transmission error between indoor and outdoor units.",
      verificationStatus: "VERIFIED",
      published: true,
      revision: 1,
      updatedByUid: ADMIN_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Authenticated user can query published catalog entries (filtered)
  await assertSucceeds(
    aliceDb.collection("catalog_entries").where("published", "==", true).get()
  );
  // Unfiltered catalog query blocked for regular users
  await assertFails(aliceDb.collection("catalog_entries").get());

  // Super Admin can configure AdMob settings; regular user can get doc
  await assertSucceeds(
    adminDb.collection("app_settings").doc("admob_config").set({
      configType: "ADMOB",
      adsGlobalEnabled: true,
      bannerEnabled: true,
      interstitialEnabled: false,
      rewardedEnabled: true,
      emergencyKillSwitch: false,
      testMode: true,
      acAdsEnabled: true,
      fridgeAdsEnabled: true,
      washerAdsEnabled: true,
      interstitialCooldownMin: 3,
      sessionFrequencyCap: 5,
      updatedByUid: ADMIN_UID,
      updatedAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("app_settings").doc("admob_config").get());

  // Audit log creation by Admin succeeds, update/delete fail
  await assertSucceeds(
    adminDb.collection("audit_logs").doc("log_001").set({
      adminUid: ADMIN_UID,
      adminEmail: ADMIN_EMAIL,
      action: "UPDATE_ADMOB_CONFIG",
      targetType: "app_settings",
      targetId: "admob_config",
      details: "Enabled Banner Ads in Test Mode",
      createdAt: now,
    })
  );
  await assertFails(
    adminDb.collection("audit_logs").doc("log_001").update({ details: "Tampered" })
  );
  await assertFails(aliceDb.collection("audit_logs").get());
});

test("Server-side admins/ role delegation grants and revokes admin privileges without hardcoded passwords", async () => {
  const bootstrapDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const editorUid = "editor_uid_007";
  const editorDb = testEnv.authenticatedContext(editorUid, {
    email: "editor@repairpro.example",
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 4000);

  // Regular user cannot self-promote to admins/
  await assertFails(
    editorDb.collection("admins").doc(editorUid).set({
      userId: editorUid,
      role: "SUPER_ADMIN",
      createdAt: now,
    })
  );

  // Bootstrap Super Admin grants CONTENT_EDITOR role in Firestore
  await assertSucceeds(
    bootstrapDb.collection("admins").doc(editorUid).set({
      userId: editorUid,
      role: "CONTENT_EDITOR",
      createdAt: now,
    })
  );

  // Delegated admin can now publish multilingual Fridge & Washer guides and read audit logs
  await assertSucceeds(
    editorDb.collection("catalog_entries").doc("fridge_er_ff").set({
      entryType: "ERROR_CODE",
      categoryId: "fridge",
      brandName: "LG",
      modelSeries: "Frost Free Inverter",
      code: "Er FF",
      titleEn: "Freezer Fan Motor Fault",
      titleBn: "ফ্রিজার ফ্যান মোটর সমস্যা",
      titleHi: "फ्रीज़र फैन मोटर त्रुटि",
      summaryEn: "Freezer evaporator fan failed to report normal RPM.",
      stepsEn: "1. Check frost buildup around fan blades. 2. Disconnect power before inspection.",
      safetyWarningEn: "Unplug refrigerator before removing rear evaporator cover.",
      verificationStatus: "VERIFIED",
      published: true,
      revision: 1,
      updatedByUid: editorUid,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(editorDb.collection("audit_logs").get());

  // Delegated admin can update & bump revision, then unpublish and delete
  await assertSucceeds(
    editorDb.collection("catalog_entries").doc("fridge_er_ff").update({
      published: false,
      revision: 2,
      updatedByUid: editorUid,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(editorDb.collection("catalog_entries").doc("fridge_er_ff").delete());

  // Bootstrap Super Admin revokes role; former editor is immediately blocked server-side
  await assertSucceeds(bootstrapDb.collection("admins").doc(editorUid).delete());
  await assertFails(editorDb.collection("audit_logs").get());
});

test("Super Admin publishes offline global_config settings and Washer category updates", async () => {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 3000);

  await assertSucceeds(
    adminDb.collection("app_settings").doc("global_config").set({
      configType: "GLOBAL",
      announcement: "New Washing Machine & AC error codes synced for offline mode.",
      maintenanceNotice: "",
      minSupportedVersion: "1.0.0",
      updatedByUid: ADMIN_UID,
      updatedAt: now,
    })
  );

  // Regular signed-in user can read global_config but cannot overwrite it
  await assertSucceeds(aliceDb.collection("app_settings").doc("global_config").get());
  await assertFails(
    aliceDb.collection("app_settings").doc("global_config").update({
      announcement: "Hacked",
      updatedByUid: ALICE_UID,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

