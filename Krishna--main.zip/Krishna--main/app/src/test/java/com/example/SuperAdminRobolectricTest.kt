package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.RepairProDatabase
import com.example.data.local.SeedDataPart1
import com.example.data.local.SeedDataPart2
import com.example.data.remote.AdminRoleCloud
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.AuditLogCloud
import com.example.data.remote.CatalogEntryCloud
import com.example.data.remote.ProblemReportCloud
import com.example.ui.screens.SuperAdminScreen
import com.example.ui.theme.RepairProTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h2600dp")
class SuperAdminRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `non-admin user is blocked by server-side role gate`() {
        composeRule.setContent {
            RepairProTheme {
                SuperAdminScreen(
                    isAdmin = false,
                    isBootstrapAdmin = false,
                    adminRoleChecked = true,
                    currentUserUid = "regular_user_123",
                    adminEmail = "user@example.com",
                    categories = SeedDataPart1.categories,
                    brands = SeedDataPart1.brands,
                    totalModels = 42,
                    errorCodes = SeedDataPart1.acErrorCodes + SeedDataPart2.fridgeAndWasherErrorCodes,
                    problems = SeedDataPart1.acProblems + SeedDataPart2.fridgeAndWasherProblems,
                    allReports = emptyList(),
                    allCatalog = emptyList(),
                    auditLogs = emptyList(),
                    adminRoles = emptyList(),
                    adMobConfig = AppSettingCloud(id = "admob_config", configType = "ADMOB"),
                    globalConfig = AppSettingCloud(id = "global_config", configType = "GLOBAL"),
                    syncInProgress = false,
                    onBack = {},
                    onUpdateReportStatus = { _, _, _ -> },
                    onPublishCatalogEntry = { _, _ -> },
                    onDeleteCatalogEntry = {},
                    onSaveAdMobConfig = {},
                    onSaveGlobalConfig = { _, _, _ -> },
                    onSyncOfflineNow = {},
                    onUpsertAdminRole = { _, _ -> },
                    onRevokeAdminRole = {},
                    onExportBackupJson = { "{}" }
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_access_denied_view").assertIsDisplayed()
        composeRule.onNodeWithText("Super Admin access required").assertIsDisplayed()
    }

    @Test
    fun `super admin navigates all modules publishes multilingual catalog entry and saves admob config`() {
        var publishedEntry: CatalogEntryCloud? = null
        var savedAdMob: AppSettingCloud? = null
        var offlineSyncTriggered = false

        val sampleReport = ProblemReportCloud(
            id = "rep_1",
            userId = "u1",
            categoryId = "ac",
            brandName = "Daikin",
            errorCode = "U4",
            description = "Indoor outdoor communication loss",
            status = "PENDING"
        )
        val sampleCatalog = CatalogEntryCloud(
            id = "cat_cloud_1",
            entryType = "ERROR_CODE",
            categoryId = "washer",
            brandName = "LG",
            code = "OE",
            titleEn = "Drain Pump Fault",
            titleBn = "ড্রেন পাম্প সমস্যা",
            titleHi = "ड्रेन पंप त्रुटि",
            summaryEn = "Machine failed to drain water within 10 minutes.",
            published = true,
            revision = 1L
        )
        val sampleLog = AuditLogCloud(
            id = "log_1",
            adminUid = "admin_1",
            adminEmail = "srikrishnaadhikary00@gmail.com",
            action = "UPDATE_ADMOB_CONFIG",
            targetType = "app_settings",
            targetId = "admob_config",
            details = "Global=true"
        )
        val sampleRole = AdminRoleCloud(id = "admin_1", userId = "admin_1", role = "SUPER_ADMIN")

        composeRule.setContent {
            RepairProTheme {
                SuperAdminScreen(
                    isAdmin = true,
                    isBootstrapAdmin = true,
                    adminRoleChecked = true,
                    currentUserUid = "admin_1",
                    adminEmail = "srikrishnaadhikary00@gmail.com",
                    categories = SeedDataPart1.categories,
                    brands = SeedDataPart1.brands,
                    totalModels = 42,
                    errorCodes = SeedDataPart1.acErrorCodes + SeedDataPart2.fridgeAndWasherErrorCodes,
                    problems = SeedDataPart1.acProblems + SeedDataPart2.fridgeAndWasherProblems,
                    allReports = listOf(sampleReport),
                    allCatalog = listOf(sampleCatalog),
                    auditLogs = listOf(sampleLog),
                    adminRoles = listOf(sampleRole),
                    adMobConfig = AppSettingCloud(id = "admob_config", configType = "ADMOB", adsGlobalEnabled = true),
                    globalConfig = AppSettingCloud(id = "global_config", configType = "GLOBAL"),
                    syncInProgress = false,
                    onBack = {},
                    onUpdateReportStatus = { _, _, _ -> },
                    onPublishCatalogEntry = { entry, onDone ->
                        publishedEntry = entry
                        onDone()
                    },
                    onDeleteCatalogEntry = {},
                    onSaveAdMobConfig = { savedAdMob = it },
                    onSaveGlobalConfig = { _, _, _ -> },
                    onSyncOfflineNow = { offlineSyncTriggered = true },
                    onUpsertAdminRole = { _, _ -> },
                    onRevokeAdminRole = {},
                    onExportBackupJson = { "{\"ok\":true}" }
                )
            }
        }
        composeRule.waitForIdle()

        // 1. Dashboard visible
        composeRule.onNodeWithText("Live System Metrics").assertIsDisplayed()

        // 2. Navigate to Appliances (AC / Fridge / Washer)
        composeRule.onNodeWithTag("admin_tab_1").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_appliance_card_ac").assertIsDisplayed()
        composeRule.onNodeWithTag("admin_appliance_card_fridge").assertIsDisplayed()
        composeRule.onNodeWithTag("admin_appliance_card_washer").assertExists()

        // 3. Navigate to Catalog & Guides and publish a multilingual entry
        composeRule.onNodeWithTag("admin_tab_2").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_catalog_brand").performTextInput("Samsung")
        composeRule.onNodeWithTag("admin_catalog_code").performTextInput("E101")
        composeRule.onNodeWithTag("admin_catalog_title_en").performTextInput("Communication Error")
        composeRule.onNodeWithTag("admin_catalog_summary_en").performTextInput("Indoor and outdoor PCB lost signal.")
        composeRule.onNodeWithTag("admin_publish_catalog_button").performClick()
        composeRule.waitForIdle()

        assertNotNull(publishedEntry)
        assertEquals("Samsung", publishedEntry?.brandName)
        assertEquals("E101", publishedEntry?.code)
        assertEquals("Communication Error", publishedEntry?.titleEn)

        // 4. Navigate to Reports tab
        composeRule.onNodeWithTag("admin_tab_3").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("User Submitted Reports (1)").assertIsDisplayed()

        // 5. Navigate to AdMob Ads tab, toggle kill switch, and save
        composeRule.onNodeWithTag("admin_tab_4").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admob_kill_switch").performClick()
        composeRule.onNodeWithTag("admob_save_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertNotNull(savedAdMob)
        assertTrue(savedAdMob!!.emergencyKillSwitch)

        // 6. Navigate to Offline & Sync tab and trigger SQLite sync
        composeRule.onNodeWithTag("admin_tab_5").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_sync_offline_button").performClick()
        composeRule.waitForIdle()
        assertTrue(offlineSyncTriggered)

        // 7. Navigate to Roles & Logs tab
        composeRule.onNodeWithTag("admin_tab_6").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_content_list").performScrollToNode(hasTestTag("admin_audit_heading"))
        composeRule.onNodeWithText("Immutable Admin Audit Logs (1)").assertIsDisplayed()
    }

    @Test
    fun `offline room database seeds ac fridge washer data and stores admin published entries`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, RepairProDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val dao = db.repairDao()
            dao.upsertCategories(SeedDataPart1.categories)
            dao.upsertBrands(SeedDataPart1.brands)
            dao.upsertErrorCodes(SeedDataPart1.acErrorCodes + SeedDataPart2.fridgeAndWasherErrorCodes)
            dao.upsertProblems(SeedDataPart1.acProblems + SeedDataPart2.fridgeAndWasherProblems)

            val cats = dao.observeCategories().first()
            assertEquals(3, cats.size)
            assertTrue(cats.any { it.id == "ac" })
            assertTrue(cats.any { it.id == "fridge" })
            assertTrue(cats.any { it.id == "washer" })
            assertTrue(dao.observeAllErrorCodes().first().isNotEmpty())
            assertTrue(dao.observeAllProblems().first().isNotEmpty())
        } finally {
            db.close()
        }
    }
}
