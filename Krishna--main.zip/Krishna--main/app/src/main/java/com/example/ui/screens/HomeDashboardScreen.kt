package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Troubleshoot
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.local.SearchHistoryEntity
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.CatalogEntryCloud
import com.example.data.remote.SavedGuideCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AdMobBannerSlot
import com.example.ui.components.ElectricQuickTile
import com.example.ui.components.ErrorCodePill
import com.example.ui.components.GlowingApplianceCard
import com.example.ui.components.LanguageSwitcherRow
import com.example.ui.components.RepairProBrandLogo
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun HomeDashboardScreen(
    language: AppLanguage,
    categories: List<ApplianceCategoryEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    searchHistory: List<SearchHistoryEntity>,
    savedGuides: List<SavedGuideCloud>,
    publishedCatalog: List<CatalogEntryCloud>,
    adMobConfig: AppSettingCloud,
    globalConfig: AppSettingCloud,
    isOnline: Boolean,
    isAdmin: Boolean,
    adConsentGranted: Boolean,
    onSelectLanguage: (AppLanguage) -> Unit,
    onOpenSearch: (String) -> Unit,
    onOpenCategory: (String) -> Unit,
    onOpenErrorSearch: () -> Unit,
    onOpenProblemSearch: () -> Unit,
    onOpenScanner: () -> Unit,
    onOpenWizard: (String) -> Unit,
    onOpenOfflineDownloads: () -> Unit,
    onOpenSaved: () -> Unit,
    onOpenReportProblem: () -> Unit,
    onOpenAdminConsole: () -> Unit,
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit
) {
    val strings = StringsProvider.get(language)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header Row: Logo + Language Switcher + Admin Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    RepairProBrandLogo(compact = true)
                    Text(
                        text = strings.tagline,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (isAdmin) {
                        IconButton(
                            onClick = onOpenAdminConsole,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(ElectricBluePrimary.copy(alpha = 0.2f))
                                .testTag("home_admin_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AdminPanelSettings,
                                contentDescription = strings.superAdminPanel,
                                tint = CyanAccent
                            )
                        }
                    }
                    IconButton(
                        onClick = onOpenReportProblem,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(SecondaryNavySurface)
                            .testTag("home_report_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ReportProblem,
                            contentDescription = strings.reportProblemTitle,
                            tint = WarningAmber
                        )
                    }
                }
            }
        }

        // Language Switcher + Offline Status Pill
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                LanguageSwitcherRow(
                    currentLanguage = language,
                    onSelect = onSelectLanguage
                )
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onOpenOfflineDownloads)
                        .testTag("home_offline_status_pill"),
                    color = (if (isOnline) SuccessGreen else WarningAmber).copy(alpha = 0.14f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(
                        1.dp,
                        (if (isOnline) SuccessGreen else WarningAmber).copy(alpha = 0.45f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = if (isOnline) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
                            contentDescription = strings.offlineReady,
                            tint = if (isOnline) SuccessGreen else WarningAmber,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = if (isOnline) "Offline OK" else "Offline",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isOnline) SuccessGreen else WarningAmber
                        )
                    }
                }
            }
        }

        // Remote Announcement / Maintenance Banner (Controlled by Super Admin)
        if (globalConfig.announcement.isNotBlank() || globalConfig.maintenanceNotice.isNotBlank()) {
            item {
                val isMaint = globalConfig.maintenanceNotice.isNotBlank()
                val accent = if (isMaint) WarningAmber else CyanAccent
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = accent.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Campaign,
                            contentDescription = "Announcement",
                            tint = accent
                        )
                        Text(
                            text = if (isMaint) globalConfig.maintenanceNotice else globalConfig.announcement,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimaryWhite
                        )
                    }
                }
            }
        }

        // Compact Search Bar with Camera Scanner shortcut (Matches Reference Screen 2)
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.2.dp, CyanAccent.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
                    .clickable { onOpenSearch("") }
                    .testTag("home_search_bar"),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 14.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = strings.navSearch,
                        tint = CyanAccent,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = strings.searchPlaceholder,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondarySlate,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(
                        onClick = onOpenScanner,
                        modifier = Modifier.testTag("home_search_camera_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CameraAlt,
                            contentDescription = strings.cameraScan,
                            tint = CyanAccent
                        )
                    }
                }
            }
        }

        // Three Main Independent Appliance Category Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                categories.forEach { cat ->
                    val name = resolveLocalizedText(language, cat.nameEn, cat.nameBn, cat.nameHi).text
                    val sub = resolveLocalizedText(language, cat.subtitleEn, cat.subtitleBn, cat.subtitleHi).text
                    val codeCount = errorCodes.count { it.categoryId == cat.id }
                    val probCount = problems.count { it.categoryId == cat.id }
                    GlowingApplianceCard(
                        categoryId = cat.id,
                        title = name,
                        subtitle = sub,
                        badgeText = "$codeCount Codes • $probCount Guides",
                        onClick = { onOpenCategory(cat.id) }
                    )
                }
            }
        }

        // Four Shortcut Action Tiles (Error Code Search | Problem Search | Camera Scan | Repair Wizard)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ElectricQuickTile(
                    icon = Icons.Filled.Search,
                    label = strings.errorCodeSearch,
                    accentColor = CyanAccent,
                    testTagName = "shortcut_error_search",
                    onClick = onOpenErrorSearch,
                    modifier = Modifier.weight(1f)
                )
                ElectricQuickTile(
                    icon = Icons.Filled.Troubleshoot,
                    label = strings.problemSearch,
                    accentColor = ElectricBluePrimary,
                    testTagName = "shortcut_problem_search",
                    onClick = onOpenProblemSearch,
                    modifier = Modifier.weight(1f)
                )
                ElectricQuickTile(
                    icon = Icons.Filled.CameraAlt,
                    label = strings.cameraScan,
                    accentColor = SuccessGreen,
                    testTagName = "shortcut_camera_scan",
                    onClick = onOpenScanner,
                    modifier = Modifier.weight(1f)
                )
                ElectricQuickTile(
                    icon = Icons.Filled.AutoFixHigh,
                    label = strings.repairGuide,
                    accentColor = WarningAmber,
                    testTagName = "shortcut_repair_wizard",
                    onClick = { onOpenWizard("ac") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Recently Searched Problems & Error Codes
        if (searchHistory.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.History,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = strings.recentSearches,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimaryWhite
                        )
                    }
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        searchHistory.take(8).forEach { entry ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onOpenSearch(entry.query) },
                                color = ElevatedCardSurface,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, CardBorderSubtle)
                            ) {
                                Text(
                                    text = entry.query,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextPrimaryWhite,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Saved Guides Quick Strip
        if (savedGuides.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Bookmark,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = strings.savedGuides,
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite
                            )
                        }
                        Text(
                            text = "${savedGuides.size} →",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyanAccent,
                            modifier = Modifier.clickable(onClick = onOpenSaved)
                        )
                    }
                    savedGuides.take(2).forEach { saved ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable {
                                    if (saved.itemType == "ERROR_CODE") onOpenErrorDetail(saved.itemId)
                                    else onOpenProblemDetail(saved.itemId)
                                },
                            color = SecondaryNavySurface,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, CardBorderSubtle)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Build,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = saved.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimaryWhite,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = saved.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondarySlate,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Latest Published Content (Cloud + Popular Verified Codes)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = strings.latestPublished,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimaryWhite
                )
                val featuredCodes = errorCodes.take(3)
                featuredCodes.forEach { codeItem ->
                    val title = resolveLocalizedText(language, codeItem.titleEn, codeItem.titleBn, codeItem.titleHi).text
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onOpenErrorDetail(codeItem.id) },
                        color = DeepCardSurface,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CardBorderSubtle)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            ErrorCodePill(code = codeItem.code)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${codeItem.brandName} • $title",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimaryWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = codeItem.modelSeries,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
                if (publishedCatalog.isNotEmpty()) {
                    Text(
                        text = "+ ${publishedCatalog.size} live admin-published updates synced",
                        style = MaterialTheme.typography.labelSmall,
                        color = SuccessGreen
                    )
                }
            }
        }

        // Optional AdMob Banner Placement (Remote-controlled by Super Admin)
        item {
            AdMobBannerSlot(
                config = adMobConfig,
                categoryId = null,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "home"
            )
        }
    }
}
