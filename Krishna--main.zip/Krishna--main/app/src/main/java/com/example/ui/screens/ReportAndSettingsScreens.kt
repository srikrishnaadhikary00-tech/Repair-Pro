package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.ProblemReportCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.ui.components.LanguageSwitcherRow
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun ReportProblemScreen(
    language: AppLanguage,
    myReports: List<ProblemReportCloud>,
    onBack: () -> Unit,
    onSubmitReport: (
        categoryId: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        description: String,
        onSuccess: () -> Unit
    ) -> Unit
) {
    val strings = StringsProvider.get(language)
    var categoryId by remember { mutableStateOf("ac") }
    var brandName by remember { mutableStateOf("") }
    var modelName by remember { mutableStateOf("") }
    var errorCode by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var validationError by remember { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> selectedPhotoUri = uri }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("report_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Text(strings.reportProblemTitle, style = MaterialTheme.typography.titleLarge, color = TextPrimaryWhite)
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                    FilterChip(
                        selected = categoryId == id,
                        onClick = { categoryId = id },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricBluePrimary,
                            selectedLabelColor = TextPrimaryWhite,
                            containerColor = SecondaryNavySurface,
                            labelColor = TextSecondarySlate
                        )
                    )
                }
            }
        }

        item {
            val fieldColors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyanAccent,
                unfocusedBorderColor = CardBorderSubtle,
                focusedTextColor = TextPrimaryWhite,
                unfocusedTextColor = TextPrimaryWhite,
                focusedContainerColor = SecondaryNavySurface,
                unfocusedContainerColor = SecondaryNavySurface
            )
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = brandName,
                    onValueChange = { brandName = it.take(80) },
                    label = { Text(strings.reportBrandLabel) },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("report_brand_input")
                )
                OutlinedTextField(
                    value = modelName,
                    onValueChange = { modelName = it.take(100) },
                    label = { Text(strings.reportModelLabel) },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = errorCode,
                    onValueChange = { errorCode = it.uppercase().take(32) },
                    label = { Text(strings.reportCodeLabel) },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it.take(1500) },
                    label = { Text(strings.reportDescLabel) },
                    minLines = 3,
                    maxLines = 5,
                    colors = fieldColors,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("report_description_input")
                )

                OutlinedButton(
                    onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.PhotoLibrary, contentDescription = null, tint = CyanAccent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedPhotoUri == null) "Attach Optional Reference Photo (Local Preview)" else "Change Attached Photo",
                        color = TextPrimaryWhite
                    )
                }

                if (selectedPhotoUri != null) {
                    AsyncImage(
                        model = selectedPhotoUri,
                        contentDescription = "Attached photo preview",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                }

                if (validationError != null) {
                    Text(validationError!!, style = MaterialTheme.typography.bodySmall, color = ErrorCrimson)
                }

                Button(
                    onClick = {
                        when {
                            brandName.trim().isEmpty() -> validationError = "Please enter the appliance brand."
                            description.trim().length < 5 -> validationError = "Please describe the problem (at least 5 characters)."
                            else -> {
                                validationError = null
                                onSubmitReport(categoryId, brandName, modelName, errorCode, description) {
                                    brandName = ""
                                    modelName = ""
                                    errorCode = ""
                                    description = ""
                                    selectedPhotoUri = null
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_report_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                ) {
                    Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.submitReport, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (myReports.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Text(strings.myReports, style = MaterialTheme.typography.titleMedium, color = CyanAccent)
            }
            items(myReports, key = { it.id }) { rep ->
                val statusColor = when (rep.status) {
                    "PUBLISHED" -> SuccessGreen
                    "REVIEWED" -> CyanAccent
                    else -> WarningAmber
                }
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = SecondaryNavySurface,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CardBorderSubtle)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${rep.brandName} (${rep.categoryId.uppercase()})${if (rep.errorCode.isNotBlank()) " • ${rep.errorCode}" else ""}",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite
                            )
                            Surface(
                                color = statusColor.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = rep.status,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = statusColor,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Text(rep.description, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        if (rep.adminNote.isNotBlank()) {
                            Text(
                                text = "Technician Note: ${rep.adminNote}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SuccessGreen
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    language: AppLanguage,
    userDisplayName: String,
    userEmail: String,
    isAdmin: Boolean,
    adConsentGranted: Boolean,
    onSelectLanguage: (AppLanguage) -> Unit,
    onToggleAdConsent: (Boolean) -> Unit,
    onOpenOfflineDownloads: () -> Unit,
    onOpenReportProblem: () -> Unit,
    onOpenAdminConsole: () -> Unit,
    onDeleteCloudData: () -> Unit,
    onSignOut: () -> Unit
) {
    val strings = StringsProvider.get(language)
    var activeLegalDialog by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(strings.settingsTitle, style = MaterialTheme.typography.headlineMedium, color = TextPrimaryWhite)
        }

        // Signed-in User Profile Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = ElevatedCardSurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(userDisplayName, style = MaterialTheme.typography.titleMedium, color = TextPrimaryWhite)
                    Text(userEmail, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                    if (isAdmin) {
                        Surface(
                            color = CyanAccent.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text(
                                text = "ROLE: SUPER ADMIN",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanAccent,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }

        // Language Selection
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.languageSetting, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                    LanguageSwitcherRow(currentLanguage = language, onSelect = onSelectLanguage)
                }
            }
        }

        // Super Admin Console Entry (Visible for Admin)
        if (isAdmin) {
            item {
                SettingsRowCard(
                    icon = Icons.Filled.AdminPanelSettings,
                    title = strings.superAdminPanel,
                    subtitle = "Manage Catalog, User Reports, AdMob Controls & Audit Logs",
                    accent = CyanAccent,
                    testTagName = "settings_admin_console",
                    onClick = onOpenAdminConsole
                )
            }
        }

        // Offline Database & Report a Problem
        item {
            SettingsRowCard(
                icon = Icons.Filled.CloudDownload,
                title = strings.offlineDownloadsTitle,
                subtitle = "Manage SQLite packs & sync latest published updates",
                testTagName = "settings_offline_downloads",
                onClick = onOpenOfflineDownloads
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.ReportProblem,
                title = strings.reportProblemTitle,
                subtitle = "Submit an unlisted error code or appliance issue",
                accent = WarningAmber,
                testTagName = "settings_report_problem",
                onClick = onOpenReportProblem
            )
        }

        // Advertising Privacy & Consent Control
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CardBorderSubtle)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(strings.adPrivacyConsent, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                        Text(
                            text = if (adConsentGranted) "Personalized ads permitted (UMP compliant)" else "Non-personalized ads only",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate
                        )
                    }
                    Switch(
                        checked = adConsentGranted,
                        onCheckedChange = onToggleAdConsent,
                        colors = SwitchDefaults.colors(checkedThumbColor = TextPrimaryWhite, checkedTrackColor = ElectricBluePrimary)
                    )
                }
            }
        }

        // Legal & About Links
        item {
            SettingsRowCard(
                icon = Icons.Filled.Policy,
                title = strings.privacyPolicy,
                subtitle = "Data safety, camera usage, offline storage & Google Sign-In",
                testTagName = "settings_privacy_policy",
                onClick = { activeLegalDialog = "privacy" }
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.Info,
                title = "${strings.aboutApp} & ${strings.termsOfUse}",
                subtitle = "Repair Pro v1.0.0 • Safety Disclaimer & Terms",
                testTagName = "settings_about_app",
                onClick = { activeLegalDialog = "about" }
            )
        }

        // Delete Cloud Data & Sign Out
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("settings_delete_data_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.6f))
                ) {
                    Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = ErrorCrimson, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Delete Data", color = ErrorCrimson, style = MaterialTheme.typography.labelMedium)
                }
                Button(
                    onClick = onSignOut,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("settings_sign_out_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElevatedCardSurface, contentColor = TextPrimaryWhite)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.signOut, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }

    if (activeLegalDialog != null) {
        val isPrivacy = activeLegalDialog == "privacy"
        AlertDialog(
            onDismissRequest = { activeLegalDialog = null },
            containerColor = SecondaryNavySurface,
            title = {
                Text(
                    text = if (isPrivacy) strings.privacyPolicy else "${strings.aboutApp} & ${strings.termsOfUse}",
                    color = TextPrimaryWhite
                )
            },
            text = {
                Text(
                    text = if (isPrivacy) {
                        "Repair Pro Privacy & Data Safety Policy:\n\n" +
                            "1. Camera Permission: Used strictly on-device via ML Kit OCR to recognize appliance display error codes. Camera frames are never uploaded without user action.\n" +
                            "2. Photo Picker: Gallery images use the zero-permission Android Photo Picker.\n" +
                            "3. Cloud Sync: Google Sign-In secures your saved guides, language preferences, and submitted problem reports in isolated per-user Firestore records.\n" +
                            "4. Advertising Consent: You may switch between personalized and non-personalized ads anytime in Settings. Ads are never displayed inside critical electrical safety warnings.\n" +
                            "5. Data Deletion: Tap 'Delete Data' in Settings to permanently erase your cloud profile, bookmarks, and submitted reports."
                    } else {
                        "Repair Pro v1.0.0 — Multilingual Home Appliance Repair Guide\n\n" +
                            "Languages: English, বাংলা (Bengali), हिन्दी (Hindi).\n" +
                            "Categories: Air Conditioner, Refrigerator, Washing Machine.\n\n" +
                            "Safety & Liability Terms:\n" +
                            "Repair Pro clearly separates safe user maintenance checks (filter cleaning, power resets, coin trap cleaning) from hazardous high-voltage, PCB, and pressurized refrigerant repairs. Always disconnect mains power before touching any appliance and hire a licensed technician for electrical or gas work."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate
                )
            },
            confirmButton = {
                TextButton(onClick = { activeLegalDialog = null }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = SecondaryNavySurface,
            title = { Text(strings.deleteMyData, color = ErrorCrimson) },
            text = {
                Text(
                    "This permanently deletes your Firestore profile, cloud-saved guides, and submitted problem reports. Local offline repair guides will remain available.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteCloudData()
                    }
                ) {
                    Text("Delete Permanently", color = ErrorCrimson)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = TextPrimaryWhite)
                }
            }
        )
    }
}

@Composable
private fun SettingsRowCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: androidx.compose.ui.graphics.Color = ElectricBluePrimary,
    testTagName: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(testTagName),
        color = SecondaryNavySurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextSecondarySlate)
        }
    }
}
