package com.example.data.remote

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class CloudRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun isCurrentUserBootstrapAdmin(): Boolean {
        val user = auth.currentUser ?: return false
        return user.isEmailVerified &&
            user.email.equals(BOOTSTRAP_SUPER_ADMIN_EMAIL, ignoreCase = true)
    }

    suspend fun checkIsAdmin(userId: String): Boolean {
        if (isCurrentUserBootstrapAdmin()) return true
        return try {
            val doc = db.collection("admins").document(userId).get().await()
            doc.exists()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "admins/$userId")
            false
        }
    }

    suspend fun ensureUserProfile(
        userId: String,
        displayName: String,
        preferredLanguage: String
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val docRef = db.collection("users").document(userId)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val safeName = displayName.trim().ifBlank { "Repair Pro User" }.take(80)
                val safeLang = if (preferredLanguage in listOf("en", "bn", "hi")) preferredLanguage else "en"
                val payload = mapOf(
                    "userId" to userId,
                    "displayName" to safeName,
                    "preferredLanguage" to safeLang,
                    "adConsentGranted" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateUserPreferences(
        userId: String,
        preferredLanguage: String? = null,
        adConsentGranted: Boolean? = null
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
            if (preferredLanguage != null && preferredLanguage in listOf("en", "bn", "hi")) {
                updates["preferredLanguage"] = preferredLanguage
            }
            if (adConsentGranted != null) {
                updates["adConsentGranted"] = adConsentGranted
            }
            db.collection("users").document(userId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfileCloud?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snap -> snap.toObject(UserProfileCloud::class.java, ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeSavedGuides(userId: String): Flow<List<SavedGuideCloud>> = flow {
        val path = "users/$userId/saved_guides"
        emitAll(
            db.collection("users").document(userId).collection("saved_guides")
                .snapshots()
                .map { snap ->
                    snap.toObjects(SavedGuideCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    suspend fun saveGuide(
        userId: String,
        itemType: String,
        itemId: String,
        categoryId: String,
        title: String,
        subtitle: String
    ): Result<Unit> {
        val safeDocId = sanitizeId("${itemType.lowercase()}_$itemId")
        val path = "users/$userId/saved_guides/$safeDocId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val payload = mapOf(
                "userId" to userId,
                "itemType" to if (itemType == "ERROR_CODE") "ERROR_CODE" else "PROBLEM",
                "itemId" to itemId.take(128),
                "categoryId" to categoryId.take(64),
                "title" to title.trim().ifBlank { "Saved Guide" }.take(180),
                "subtitle" to subtitle.trim().take(240),
                "createdAt" to FieldValue.serverTimestamp()
            )
            db.collection("users").document(userId)
                .collection("saved_guides").document(safeDocId)
                .set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun removeSavedGuide(userId: String, guideDocId: String): Result<Unit> {
        val path = "users/$userId/saved_guides/$guideDocId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            db.collection("users").document(userId)
                .collection("saved_guides").document(guideDocId)
                .delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    fun observeUserProblemReports(userId: String): Flow<List<ProblemReportCloud>> = flow {
        val path = "problem_reports"
        emitAll(
            db.collection("problem_reports")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ProblemReportCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeAllProblemReportsForAdmin(adminUid: String): Flow<List<ProblemReportCloud>> = flow {
        val path = "problem_reports"
        emitAll(
            db.collection("problem_reports")
                .snapshots()
                .map { snap ->
                    snap.toObjects(ProblemReportCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun submitProblemReport(
        userId: String,
        categoryId: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        description: String,
        preferredLanguage: String
    ): Result<Unit> {
        val docId = sanitizeId("rep_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "problem_reports/$docId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            require(brandName.trim().isNotEmpty()) { "Brand name is required." }
            require(description.trim().length >= 5) { "Please enter at least 5 characters describing the issue." }
            val safeLang = if (preferredLanguage in listOf("en", "bn", "hi")) preferredLanguage else "en"
            val payload = mutableMapOf<String, Any?>(
                "userId" to userId,
                "categoryId" to categoryId.take(64),
                "brandName" to brandName.trim().take(80),
                "modelName" to modelName.trim().take(100).ifBlank { null },
                "errorCode" to errorCode.trim().uppercase().take(32).ifBlank { null },
                "description" to description.trim().take(1500),
                "preferredLanguage" to safeLang,
                "status" to "PENDING",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>

            db.collection("problem_reports").document(docId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProblemReportStatus(
        reportId: String,
        newStatus: String,
        adminNote: String
    ): Result<Unit> {
        val path = "problem_reports/$reportId"
        return try {
            val uid = requireUserId()
            require(newStatus in listOf("PENDING", "REVIEWED", "PUBLISHED")) { "Invalid status." }
            val updates = mutableMapOf<String, Any>(
                "status" to newStatus,
                "adminNote" to adminNote.trim().take(1000),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("problem_reports").document(reportId).update(updates).await()
            logAdminAction(uid, "UPDATE_REPORT_STATUS", "problem_reports", reportId, "Status -> $newStatus")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observePublishedCatalog(userId: String): Flow<List<CatalogEntryCloud>> = flow {
        val path = "catalog_entries"
        emitAll(
            db.collection("catalog_entries")
                .whereEqualTo("published", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(CatalogEntryCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeAllCatalogForAdmin(adminUid: String): Flow<List<CatalogEntryCloud>> = flow {
        val path = "catalog_entries"
        emitAll(
            db.collection("catalog_entries")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CatalogEntryCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun publishCatalogEntry(entry: CatalogEntryCloud): Result<Unit> {
        val docId = if (entry.id.isNotBlank()) sanitizeId(entry.id)
        else sanitizeId("cat_${UUID.randomUUID().toString().replace("-", "").take(14)}")
        val path = "catalog_entries/$docId"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("catalog_entries").document(docId)
            val existingSnap = docRef.get().await()
            val cleanType = if (entry.entryType in listOf("CATEGORY", "ERROR_CODE", "PROBLEM")) entry.entryType else "ERROR_CODE"
            val cleanVer = if (entry.verificationStatus in listOf("VERIFIED", "UNVERIFIED")) entry.verificationStatus else "VERIFIED"

            if (!existingSnap.exists()) {
                val payload = mapOf(
                    "entryType" to cleanType,
                    "categoryId" to entry.categoryId.take(64),
                    "brandName" to entry.brandName.trim().take(80).ifBlank { null },
                    "modelSeries" to entry.modelSeries.trim().take(100).ifBlank { null },
                    "code" to entry.code.trim().uppercase().take(32).ifBlank { null },
                    "titleEn" to entry.titleEn.trim().ifBlank { "Untitled Entry" }.take(180),
                    "titleBn" to entry.titleBn.trim().take(220).ifBlank { null },
                    "titleHi" to entry.titleHi.trim().take(220).ifBlank { null },
                    "summaryEn" to entry.summaryEn.trim().ifBlank { "Details pending" }.take(1200),
                    "summaryBn" to entry.summaryBn.trim().take(1400).ifBlank { null },
                    "summaryHi" to entry.summaryHi.trim().take(1400).ifBlank { null },
                    "stepsEn" to entry.stepsEn.trim().take(2000).ifBlank { null },
                    "stepsBn" to entry.stepsBn.trim().take(2400).ifBlank { null },
                    "stepsHi" to entry.stepsHi.trim().take(2400).ifBlank { null },
                    "safetyWarningEn" to entry.safetyWarningEn.trim().take(600).ifBlank { null },
                    "verificationStatus" to cleanVer,
                    "published" to entry.published,
                    "revision" to 1L,
                    "updatedByUid" to uid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null } as Map<String, Any>
                docRef.set(payload).await()
                logAdminAction(uid, "CREATE_CATALOG_ENTRY", "catalog_entries", docId, "${entry.entryType}: ${entry.titleEn}")
            } else {
                val currentRev = existingSnap.getLong("revision") ?: 1L
                val updates = mapOf(
                    "brandName" to entry.brandName.trim().take(80),
                    "modelSeries" to entry.modelSeries.trim().take(100),
                    "code" to entry.code.trim().uppercase().take(32),
                    "titleEn" to entry.titleEn.trim().ifBlank { "Untitled Entry" }.take(180),
                    "titleBn" to entry.titleBn.trim().take(220),
                    "titleHi" to entry.titleHi.trim().take(220),
                    "summaryEn" to entry.summaryEn.trim().ifBlank { "Details pending" }.take(1200),
                    "summaryBn" to entry.summaryBn.trim().take(1400),
                    "summaryHi" to entry.summaryHi.trim().take(1400),
                    "stepsEn" to entry.stepsEn.trim().take(2000),
                    "stepsBn" to entry.stepsBn.trim().take(2400),
                    "stepsHi" to entry.stepsHi.trim().take(2400),
                    "safetyWarningEn" to entry.safetyWarningEn.trim().take(600),
                    "verificationStatus" to cleanVer,
                    "published" to entry.published,
                    "revision" to (currentRev + 1L),
                    "updatedByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
                logAdminAction(uid, "UPDATE_CATALOG_ENTRY", "catalog_entries", docId, "Rev ${currentRev + 1}: ${entry.titleEn}")
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteCatalogEntry(entryId: String): Result<Unit> {
        val path = "catalog_entries/$entryId"
        return try {
            val uid = requireUserId()
            db.collection("catalog_entries").document(entryId).delete().await()
            logAdminAction(uid, "DELETE_CATALOG_ENTRY", "catalog_entries", entryId, "Deleted catalog entry")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    fun observeAdMobConfig(userId: String): Flow<AppSettingCloud> = flow {
        val path = "app_settings/admob_config"
        emitAll(
            db.collection("app_settings").document("admob_config")
                .snapshots()
                .map { snap ->
                    snap.toObject(AppSettingCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        ?: AppSettingCloud(id = "admob_config", configType = "ADMOB")
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeGlobalConfig(userId: String): Flow<AppSettingCloud> = flow {
        val path = "app_settings/global_config"
        emitAll(
            db.collection("app_settings").document("global_config")
                .snapshots()
                .map { snap ->
                    snap.toObject(AppSettingCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        ?: AppSettingCloud(id = "global_config", configType = "GLOBAL")
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    suspend fun saveAdMobConfig(config: AppSettingCloud): Result<Unit> {
        val path = "app_settings/admob_config"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "configType" to "ADMOB",
                "adsGlobalEnabled" to config.adsGlobalEnabled,
                "bannerEnabled" to config.bannerEnabled,
                "interstitialEnabled" to config.interstitialEnabled,
                "rewardedEnabled" to config.rewardedEnabled,
                "nativeEnabled" to config.nativeEnabled,
                "emergencyKillSwitch" to config.emergencyKillSwitch,
                "testMode" to config.testMode,
                "acAdsEnabled" to config.acAdsEnabled,
                "fridgeAdsEnabled" to config.fridgeAdsEnabled,
                "washerAdsEnabled" to config.washerAdsEnabled,
                "interstitialCooldownMin" to config.interstitialCooldownMin.coerceIn(1L, 60L),
                "sessionFrequencyCap" to config.sessionFrequencyCap.coerceIn(1L, 50L),
                "androidAppId" to config.androidAppId.take(120),
                "androidBannerId" to config.androidBannerId.take(120),
                "androidInterstitialId" to config.androidInterstitialId.take(120),
                "androidRewardedId" to config.androidRewardedId.take(120),
                "iosAppId" to config.iosAppId.take(120),
                "iosBannerId" to config.iosBannerId.take(120),
                "updatedByUid" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("app_settings").document("admob_config").set(payload).await()
            logAdminAction(
                uid,
                "UPDATE_ADMOB_CONFIG",
                "app_settings",
                "admob_config",
                "Global=${config.adsGlobalEnabled}, Kill=${config.emergencyKillSwitch}, Test=${config.testMode}"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveGlobalConfig(
        announcement: String,
        maintenanceNotice: String,
        minSupportedVersion: String
    ): Result<Unit> {
        val path = "app_settings/global_config"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "configType" to "GLOBAL",
                "announcement" to announcement.trim().take(400),
                "maintenanceNotice" to maintenanceNotice.trim().take(400),
                "minSupportedVersion" to minSupportedVersion.trim().ifBlank { "1.0.0" }.take(32),
                "updatedByUid" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("app_settings").document("global_config").set(payload).await()
            logAdminAction(uid, "UPDATE_GLOBAL_SETTINGS", "app_settings", "global_config", "MinVer=$minSupportedVersion")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    fun observeAuditLogsForAdmin(adminUid: String): Flow<List<AuditLogCloud>> = flow {
        val path = "audit_logs"
        emitAll(
            db.collection("audit_logs")
                .snapshots()
                .map { snap ->
                    snap.toObjects(AuditLogCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    fun observeAdminRolesForBootstrapAdmin(adminUid: String): Flow<List<AdminRoleCloud>> = flow {
        val path = "admins"
        emitAll(
            db.collection("admins")
                .snapshots()
                .map { snap ->
                    snap.toObjects(AdminRoleCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun upsertAdminRole(targetUid: String, role: String): Result<Unit> {
        val cleanUid = sanitizeId(targetUid.trim())
        val cleanRole = if (role in listOf("SUPER_ADMIN", "CONTENT_EDITOR", "TRANSLATOR", "ANALYST")) role else "CONTENT_EDITOR"
        val path = "admins/$cleanUid"
        return try {
            val actorUid = requireUserId()
            val docRef = db.collection("admins").document(cleanUid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = mapOf(
                    "userId" to cleanUid,
                    "role" to cleanRole,
                    "createdAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
                logAdminAction(actorUid, "GRANT_ADMIN_ROLE", "admins", cleanUid, "Granted $cleanRole")
            } else {
                docRef.update(mapOf("role" to cleanRole)).await()
                logAdminAction(actorUid, "UPDATE_ADMIN_ROLE", "admins", cleanUid, "Updated role -> $cleanRole")
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun removeAdminRole(targetUid: String): Result<Unit> {
        val cleanUid = sanitizeId(targetUid.trim())
        val path = "admins/$cleanUid"
        return try {
            val actorUid = requireUserId()
            db.collection("admins").document(cleanUid).delete().await()
            logAdminAction(actorUid, "REVOKE_ADMIN_ROLE", "admins", cleanUid, "Revoked admin role")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private suspend fun logAdminAction(
        adminUid: String,
        action: String,
        targetType: String,
        targetId: String,
        details: String
    ) {
        val logId = sanitizeId("log_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val email = auth.currentUser?.email ?: "admin@repairpro.local"
        val payload = mapOf(
            "adminUid" to adminUid,
            "adminEmail" to email.take(160),
            "action" to action.take(100),
            "targetType" to targetType.take(64),
            "targetId" to targetId.take(128),
            "details" to details.take(500),
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            db.collection("audit_logs").document(logId).set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "audit_logs/$logId")
        }
    }

    suspend fun deleteUserCloudData(userId: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val savedSnap = db.collection("users").document(userId).collection("saved_guides").get().await()
            for (doc in savedSnap.documents) {
                doc.reference.delete().await()
            }
            val reportsSnap = db.collection("problem_reports").whereEqualTo("userId", userId).get().await()
            for (doc in reportsSnap.documents) {
                doc.reference.delete().await()
            }
            db.collection("users").document(userId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "users/$userId")
            Result.failure(e)
        }
    }

    private fun logStreamErrorIfActive(
        error: Throwable,
        op: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
    }

    companion object {
        fun sanitizeId(raw: String): String {
            val cleaned = raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            return cleaned.take(120).ifBlank { "doc_${System.currentTimeMillis()}" }
        }
    }
}
