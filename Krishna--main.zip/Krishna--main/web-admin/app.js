import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";
import {
  firebaseConfig,
  FIRESTORE_DATABASE_ID,
  BOOTSTRAP_SUPER_ADMIN_EMAIL
} from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app, FIRESTORE_DATABASE_ID);

const $ = (id) => document.getElementById(id);
$("db-id-preview").textContent = FIRESTORE_DATABASE_ID;

let currentUser = null;
let isBootstrapAdmin = false;
let unsubscribers = [];
let cachedCatalog = [];
let cachedReports = [];
let cachedLogs = [];
let cachedRoles = [];

function showToast(msg) {
  const el = $("toast");
  el.textContent = msg;
  el.classList.remove("hidden");
  setTimeout(() => el.classList.add("hidden"), 3600);
}

function sanitizeId(raw) {
  return String(raw || "").replace(/[^a-zA-Z0-9_\-]/g, "_").slice(0, 120) || `doc_${Date.now()}`;
}

function clearSubscriptions() {
  unsubscribers.forEach((fn) => { try { fn(); } catch (_) {} });
  unsubscribers = [];
}

async function logAudit(action, targetType, targetId, details) {
  if (!currentUser) return;
  const logId = sanitizeId(`log_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`);
  await setDoc(doc(db, "audit_logs", logId), {
    adminUid: currentUser.uid,
    adminEmail: (currentUser.email || "admin@repairpro.local").slice(0, 160),
    action: action.slice(0, 100),
    targetType: targetType.slice(0, 64),
    targetId: targetId.slice(0, 128),
    details: details.slice(0, 500),
    createdAt: serverTimestamp()
  });
}

async function verifyServerSideAdmin(user) {
  const bootstrap = Boolean(
    user.emailVerified &&
    user.email &&
    user.email.toLowerCase() === BOOTSTRAP_SUPER_ADMIN_EMAIL.toLowerCase()
  );
  isBootstrapAdmin = bootstrap;
  if (bootstrap) return true;
  try {
    const snap = await getDoc(doc(db, "admins", user.uid));
    return snap.exists();
  } catch (_) {
    return false;
  }
}

// Navigation switching
const sectionTitles = {
  dashboard: "Dashboard Overview",
  appliances: "Appliances (AC, Refrigerator & Washing Machine)",
  catalog: "Error Codes & Multilingual Repair Guides",
  reports: "User Submitted Problem Reports",
  admob: "Google AdMob — Remote Ads Control",
  offline: "Offline Database Publishing & Sync",
  roles: "Server-Side Admin Roles & Audit Logs"
};

function switchSection(sectionKey) {
  document.querySelectorAll(".nav-btn").forEach((b) => {
    b.classList.toggle("active", b.dataset.section === sectionKey);
  });
  document.querySelectorAll(".admin-section").forEach((sec) => {
    sec.classList.toggle("hidden", sec.id !== `sec-${sectionKey}`);
  });
  $("section-title").textContent = sectionTitles[sectionKey] || "Super Admin";
}

document.querySelectorAll(".nav-btn").forEach((btn) => {
  btn.addEventListener("click", () => switchSection(btn.dataset.section));
});

$("quick-new-entry-btn").addEventListener("click", () => switchSection("catalog"));
$("quick-export-btn").addEventListener("click", downloadBackupJson);
$("download-backup-btn").addEventListener("click", downloadBackupJson);

// Handle redirect sign-in completion (essential for iPhone Safari)
getRedirectResult(auth).catch((err) => {
  if (err && err.code) {
    $("login-error").textContent = err.message || "Google Redirect Sign-In failed.";
    $("login-error").classList.remove("hidden");
  }
});

// Login & Logout
async function startGoogleRedirectLogin() {
  $("login-error").classList.add("hidden");
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: "select_account" });
    await signInWithRedirect(auth, provider);
  } catch (err) {
    $("login-error").textContent = err.message || "Google Redirect Sign-In failed.";
    $("login-error").classList.remove("hidden");
  }
}

$("google-login-btn").addEventListener("click", async () => {
  $("login-error").classList.add("hidden");
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: "select_account" });
    await signInWithPopup(auth, provider);
  } catch (err) {
    if (
      err?.code === "auth/popup-blocked" ||
      err?.code === "auth/operation-not-supported-in-this-environment"
    ) {
      await startGoogleRedirectLogin();
      return;
    }
    $("login-error").textContent = err.message || "Google Sign-In failed.";
    $("login-error").classList.remove("hidden");
  }
});

$("google-redirect-btn").addEventListener("click", startGoogleRedirectLogin);

async function handleSignOut() {
  clearSubscriptions();
  await signOut(auth);
}
$("signout-btn").addEventListener("click", handleSignOut);
$("denied-signout-btn").addEventListener("click", handleSignOut);

onAuthStateChanged(auth, async (user) => {
  clearSubscriptions();
  currentUser = user;
  if (!user) {
    $("login-view").classList.remove("hidden");
    $("denied-view").classList.add("hidden");
    $("admin-shell").classList.add("hidden");
    return;
  }

  const authorized = await verifyServerSideAdmin(user);
  if (!authorized) {
    $("login-view").classList.add("hidden");
    $("admin-shell").classList.add("hidden");
    $("denied-view").classList.remove("hidden");
    $("denied-message").textContent =
      `Signed in as ${user.email || "unknown"} (UID: ${user.uid}), which does not have an active admin role in Firestore.`;
    return;
  }

  $("login-view").classList.add("hidden");
  $("denied-view").classList.add("hidden");
  $("admin-shell").classList.remove("hidden");
  $("admin-email-badge").textContent = `Verified • ${user.email}`;
  $("roles-manager-card").classList.toggle("hidden", !isBootstrapAdmin);

  attachAdminStreams();
});

function attachAdminStreams() {
  unsubscribers.push(
    onSnapshot(collection(db, "catalog_entries"), (snap) => {
      cachedCatalog = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      renderDashboard();
      renderAppliances();
      renderCatalogList();
    }),
    onSnapshot(collection(db, "problem_reports"), (snap) => {
      cachedReports = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      renderDashboard();
      renderReportsList();
    }),
    onSnapshot(collection(db, "audit_logs"), (snap) => {
      cachedLogs = snap.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
      renderDashboard();
      renderAuditLogs();
    }),
    onSnapshot(doc(db, "app_settings", "admob_config"), (snap) => {
      if (snap.exists()) populateAdMobForm(snap.data());
    }),
    onSnapshot(doc(db, "app_settings", "global_config"), (snap) => {
      if (snap.exists()) populateGlobalForm(snap.data());
    })
  );

  if (isBootstrapAdmin) {
    unsubscribers.push(
      onSnapshot(collection(db, "admins"), (snap) => {
        cachedRoles = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        renderRolesList();
      })
    );
  }
}

function renderDashboard() {
  $("stat-catalog").textContent = String(cachedCatalog.length);
  $("stat-published").textContent = String(cachedCatalog.filter((c) => c.published).length);
  $("stat-reports").textContent = String(cachedReports.filter((r) => r.status === "PENDING").length);
  $("stat-logs").textContent = String(cachedLogs.length);

  const container = $("category-bars");
  container.replaceChildren();
  const total = Math.max(cachedCatalog.length, 1);
  const cats = [
    { id: "ac", label: "Air Conditioner (AC)" },
    { id: "fridge", label: "Refrigerator (Fridge)" },
    { id: "washer", label: "Washing Machine" }
  ];
  cats.forEach((c) => {
    const count = cachedCatalog.filter((x) => x.categoryId === c.id).length;
    const pct = Math.round((count / total) * 100);
    const wrap = document.createElement("div");
    wrap.style.marginBottom = "12px";

    const row = document.createElement("div");
    row.style.display = "flex";
    row.style.justifyContent = "space-between";
    row.style.fontSize = "13px";
    const left = document.createElement("span");
    left.textContent = c.label;
    const right = document.createElement("span");
    right.style.color = "var(--cyan)";
    right.textContent = `${count} cloud entries (${pct}%)`;
    row.append(left, right);

    const track = document.createElement("div");
    track.className = "progress-track";
    const fill = document.createElement("div");
    fill.className = "progress-fill";
    fill.style.width = `${pct}%`;
    track.append(fill);

    wrap.append(row, track);
    container.append(wrap);
  });
}

function renderAppliances() {
  const grid = $("appliances-grid");
  grid.replaceChildren();
  const base = [
    { id: "ac", title: "Air Conditioner (AC)", sub: "LG, Samsung, Daikin, Voltas, Blue Star, Hitachi, Panasonic, Carrier…" },
    { id: "fridge", title: "Refrigerator (Fridge)", sub: "LG, Samsung, Whirlpool, Haier, Godrej, Bosch, Panasonic, Hitachi, IFB" },
    { id: "washer", title: "Washing Machine", sub: "LG, Samsung, Whirlpool, IFB, Bosch, Haier, Panasonic, Godrej, Siemens" }
  ];
  base.forEach((cat) => {
    const codes = cachedCatalog.filter((e) => e.categoryId === cat.id && e.entryType === "ERROR_CODE").length;
    const guides = cachedCatalog.filter((e) => e.categoryId === cat.id && e.entryType === "PROBLEM").length;
    const card = document.createElement("div");
    card.className = "card card-glow";

    const h = document.createElement("h3");
    h.style.margin = "0 0 6px";
    h.textContent = cat.title;
    const p = document.createElement("p");
    p.className = "subtitle";
    p.style.marginBottom = "10px";
    p.textContent = cat.sub;
    const meta = document.createElement("div");
    meta.className = "badge badge-cyan";
    meta.textContent = `Cloud: ${codes} Codes • ${guides} Guides`;

    const btnRow = document.createElement("div");
    btnRow.style.marginTop = "12px";
    const addBtn = document.createElement("button");
    addBtn.className = "btn btn-outline btn-sm";
    addBtn.textContent = `+ Add ${cat.id.toUpperCase()} Entry`;
    addBtn.addEventListener("click", () => {
      $("cat-category-id").value = cat.id;
      switchSection("catalog");
    });
    btnRow.append(addBtn);

    card.append(h, p, meta, btnRow);
    grid.append(card);
  });
}

// Create New Category
$("new-category-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const slug = sanitizeId($("new-cat-id").value.trim().toLowerCase());
  const titleEn = $("new-cat-en").value.trim();
  if (!slug || !titleEn) return;
  try {
    const docId = sanitizeId(`category_${slug}`);
    await setDoc(doc(db, "catalog_entries", docId), {
      entryType: "CATEGORY",
      categoryId: slug,
      titleEn,
      titleBn: $("new-cat-bn").value.trim() || titleEn,
      titleHi: $("new-cat-hi").value.trim() || titleEn,
      summaryEn: `${titleEn} diagnostics, error codes, and repair guides.`,
      verificationStatus: "VERIFIED",
      published: true,
      revision: 1,
      updatedByUid: currentUser.uid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    await logAudit("CREATE_CATEGORY", "catalog_entries", docId, `Category: ${titleEn}`);
    e.target.reset();
    showToast(`Category "${titleEn}" published to Firestore!`);
  } catch (err) {
    showToast(`Error: ${err.message}`);
  }
});

// Catalog Create / Edit
$("catalog-filter").addEventListener("change", renderCatalogList);
$("cancel-edit-btn").addEventListener("click", resetCatalogForm);

function resetCatalogForm() {
  $("catalog-form").reset();
  $("cat-doc-id").value = "";
  $("cat-safety-en").value = "Disconnect mains power before inspection.";
  $("cat-published").checked = true;
  $("catalog-form-heading").textContent = "Create / Publish Multilingual Entry";
  $("cancel-edit-btn").classList.add("hidden");
}

function startEditCatalog(entry) {
  $("cat-doc-id").value = entry.id;
  $("cat-entry-type").value = entry.entryType || "ERROR_CODE";
  $("cat-category-id").value = entry.categoryId || "ac";
  $("cat-brand").value = entry.brandName || "";
  $("cat-model").value = entry.modelSeries || "";
  $("cat-code").value = entry.code || "";
  $("cat-verification").value = entry.verificationStatus || "VERIFIED";
  $("cat-title-en").value = entry.titleEn || "";
  $("cat-title-bn").value = entry.titleBn || "";
  $("cat-title-hi").value = entry.titleHi || "";
  $("cat-summary-en").value = entry.summaryEn || "";
  $("cat-summary-bn").value = entry.summaryBn || "";
  $("cat-summary-hi").value = entry.summaryHi || "";
  $("cat-steps-en").value = entry.stepsEn || "";
  $("cat-steps-bn").value = entry.stepsBn || "";
  $("cat-steps-hi").value = entry.stepsHi || "";
  $("cat-safety-en").value = entry.safetyWarningEn || "";
  $("cat-published").checked = Boolean(entry.published);
  $("catalog-form-heading").textContent = `Editing ${entry.id} (Rev ${(entry.revision || 1) + 1})`;
  $("cancel-edit-btn").classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

$("catalog-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const existingId = $("cat-doc-id").value.trim();
  const titleEn = $("cat-title-en").value.trim();
  const summaryEn = $("cat-summary-en").value.trim();
  if (!titleEn || !summaryEn) return;

  try {
    if (!existingId) {
      const docId = sanitizeId(`cat_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
      const payload = {
        entryType: $("cat-entry-type").value,
        categoryId: $("cat-category-id").value,
        brandName: $("cat-brand").value.trim(),
        modelSeries: $("cat-model").value.trim(),
        code: $("cat-code").value.trim().toUpperCase(),
        titleEn,
        titleBn: $("cat-title-bn").value.trim(),
        titleHi: $("cat-title-hi").value.trim(),
        summaryEn,
        summaryBn: $("cat-summary-bn").value.trim(),
        summaryHi: $("cat-summary-hi").value.trim(),
        stepsEn: $("cat-steps-en").value.trim(),
        stepsBn: $("cat-steps-bn").value.trim(),
        stepsHi: $("cat-steps-hi").value.trim(),
        safetyWarningEn: $("cat-safety-en").value.trim(),
        verificationStatus: $("cat-verification").value,
        published: $("cat-published").checked,
        revision: 1,
        updatedByUid: currentUser.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      await setDoc(doc(db, "catalog_entries", docId), payload);
      await logAudit("CREATE_CATALOG_ENTRY", "catalog_entries", docId, `${payload.entryType}: ${titleEn}`);
      showToast(`Published "${titleEn}" to Firestore!`);
    } else {
      const prev = cachedCatalog.find((x) => x.id === existingId);
      const nextRev = (prev?.revision || 1) + 1;
      await updateDoc(doc(db, "catalog_entries", existingId), {
        brandName: $("cat-brand").value.trim(),
        modelSeries: $("cat-model").value.trim(),
        code: $("cat-code").value.trim().toUpperCase(),
        titleEn,
        titleBn: $("cat-title-bn").value.trim(),
        titleHi: $("cat-title-hi").value.trim(),
        summaryEn,
        summaryBn: $("cat-summary-bn").value.trim(),
        summaryHi: $("cat-summary-hi").value.trim(),
        stepsEn: $("cat-steps-en").value.trim(),
        stepsBn: $("cat-steps-bn").value.trim(),
        stepsHi: $("cat-steps-hi").value.trim(),
        safetyWarningEn: $("cat-safety-en").value.trim(),
        verificationStatus: $("cat-verification").value,
        published: $("cat-published").checked,
        revision: nextRev,
        updatedByUid: currentUser.uid,
        updatedAt: serverTimestamp()
      });
      await logAudit("UPDATE_CATALOG_ENTRY", "catalog_entries", existingId, `Rev ${nextRev}: ${titleEn}`);
      showToast(`Updated "${titleEn}" (Rev ${nextRev})!`);
    }
    resetCatalogForm();
  } catch (err) {
    showToast(`Save failed: ${err.message}`);
  }
});

function renderCatalogList() {
  const list = $("catalog-list");
  list.replaceChildren();
  const filter = $("catalog-filter").value;
  const items = cachedCatalog.filter((c) => filter === "all" || c.categoryId === filter);
  if (items.length === 0) {
    const empty = document.createElement("p");
    empty.className = "subtitle";
    empty.textContent = "No cloud catalog entries yet. Use the form above to publish verified content.";
    list.append(empty);
    return;
  }

  items.forEach((entry) => {
    const row = document.createElement("div");
    row.className = "list-item";

    const info = document.createElement("div");
    const title = document.createElement("div");
    title.style.fontWeight = "700";
    title.textContent = `[${entry.entryType}] ${entry.brandName || ""} ${entry.code || ""} — ${entry.titleEn}`;
    const meta = document.createElement("div");
    meta.style.fontSize = "12px";
    meta.style.color = "var(--text-muted)";
    meta.textContent = `${(entry.categoryId || "").toUpperCase()} • Rev ${entry.revision || 1} • ${entry.verificationStatus} • ${entry.published ? "PUBLISHED" : "DRAFT"}`;
    info.append(title, meta);

    const actions = document.createElement("div");
    actions.style.display = "flex";
    actions.style.gap = "6px";

    const editBtn = document.createElement("button");
    editBtn.className = "btn btn-outline btn-sm";
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", () => startEditCatalog(entry));

    const delBtn = document.createElement("button");
    delBtn.className = "btn btn-danger btn-sm";
    delBtn.textContent = "Delete";
    delBtn.addEventListener("click", async () => {
      try {
        await deleteDoc(doc(db, "catalog_entries", entry.id));
        await logAudit("DELETE_CATALOG_ENTRY", "catalog_entries", entry.id, `Deleted ${entry.titleEn}`);
        showToast("Deleted catalog entry.");
      } catch (err) {
        showToast(`Delete failed: ${err.message}`);
      }
    });

    actions.append(editBtn, delBtn);
    row.append(info, actions);
    list.append(row);
  });
}

function renderReportsList() {
  const list = $("reports-list");
  list.replaceChildren();
  if (cachedReports.length === 0) {
    const p = document.createElement("p");
    p.className = "subtitle";
    p.textContent = "No user problem reports submitted yet.";
    list.append(p);
    return;
  }
  cachedReports.forEach((rep) => {
    const card = document.createElement("div");
    card.className = "list-item";
    card.style.flexDirection = "column";

    const head = document.createElement("div");
    head.style.display = "flex";
    head.style.justifyContent = "space-between";
    head.style.width = "100%";
    const hTitle = document.createElement("strong");
    hTitle.textContent = `${rep.brandName} (${(rep.categoryId || "").toUpperCase()}) ${rep.errorCode || ""}`;
    const badge = document.createElement("span");
    badge.className = rep.status === "PUBLISHED" ? "badge badge-green" : rep.status === "REVIEWED" ? "badge badge-cyan" : "badge badge-amber";
    badge.textContent = rep.status;
    head.append(hTitle, badge);

    const desc = document.createElement("p");
    desc.style.margin = "6px 0";
    desc.style.fontSize = "13px";
    desc.style.color = "var(--text-muted)";
    desc.textContent = rep.description;

    const noteInput = document.createElement("input");
    noteInput.type = "text";
    noteInput.placeholder = "Technician review note…";
    noteInput.value = rep.adminNote || "";

    const btnRow = document.createElement("div");
    btnRow.style.display = "flex";
    btnRow.style.gap = "8px";
    btnRow.style.marginTop = "8px";

    ["REVIEWED", "PUBLISHED"].forEach((st) => {
      const b = document.createElement("button");
      b.className = st === "PUBLISHED" ? "btn btn-success btn-sm" : "btn btn-outline btn-sm";
      b.textContent = `Mark ${st}`;
      b.addEventListener("click", async () => {
        try {
          await updateDoc(doc(db, "problem_reports", rep.id), {
            status: st,
            adminNote: noteInput.value.trim().slice(0, 1000),
            updatedAt: serverTimestamp()
          });
          await logAudit("UPDATE_REPORT_STATUS", "problem_reports", rep.id, `Status -> ${st}`);
          showToast(`Report marked ${st}`);
        } catch (err) {
          showToast(`Failed: ${err.message}`);
        }
      });
      btnRow.append(b);
    });

    card.append(head, desc, noteInput, btnRow);
    list.append(card);
  });
}

// AdMob Form
function populateAdMobForm(d) {
  $("ad-global").checked = d.adsGlobalEnabled ?? true;
  $("ad-kill").checked = d.emergencyKillSwitch ?? false;
  $("ad-banner").checked = d.bannerEnabled ?? true;
  $("ad-interstitial").checked = d.interstitialEnabled ?? false;
  $("ad-rewarded").checked = d.rewardedEnabled ?? true;
  $("ad-native").checked = d.nativeEnabled ?? false;
  $("ad-test").checked = d.testMode ?? true;
  $("ad-ac").checked = d.acAdsEnabled ?? true;
  $("ad-fridge").checked = d.fridgeAdsEnabled ?? true;
  $("ad-washer").checked = d.washerAdsEnabled ?? true;
  $("ad-cooldown").value = d.interstitialCooldownMin ?? 3;
  $("ad-cap").value = d.sessionFrequencyCap ?? 6;
  $("ad-android-app").value = d.androidAppId || "ca-app-pub-3940256099942544~3347511713";
  $("ad-android-banner").value = d.androidBannerId || "ca-app-pub-3940256099942544/6300978111";
  $("ad-android-interstitial").value = d.androidInterstitialId || "ca-app-pub-3940256099942544/1033173712";
  $("ad-android-rewarded").value = d.androidRewardedId || "ca-app-pub-3940256099942544/5224354917";
  $("ad-ios-app").value = d.iosAppId || "ca-app-pub-3940256099942544~1458002511";
  $("ad-ios-banner").value = d.iosBannerId || "ca-app-pub-3940256099942544/2934735716";
}

$("admob-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    const payload = {
      configType: "ADMOB",
      adsGlobalEnabled: $("ad-global").checked,
      emergencyKillSwitch: $("ad-kill").checked,
      bannerEnabled: $("ad-banner").checked,
      interstitialEnabled: $("ad-interstitial").checked,
      rewardedEnabled: $("ad-rewarded").checked,
      nativeEnabled: $("ad-native").checked,
      testMode: $("ad-test").checked,
      acAdsEnabled: $("ad-ac").checked,
      fridgeAdsEnabled: $("ad-fridge").checked,
      washerAdsEnabled: $("ad-washer").checked,
      interstitialCooldownMin: Math.min(60, Math.max(1, Number($("ad-cooldown").value) || 3)),
      sessionFrequencyCap: Math.min(50, Math.max(1, Number($("ad-cap").value) || 6)),
      androidAppId: $("ad-android-app").value.trim().slice(0, 120),
      androidBannerId: $("ad-android-banner").value.trim().slice(0, 120),
      androidInterstitialId: $("ad-android-interstitial").value.trim().slice(0, 120),
      androidRewardedId: $("ad-android-rewarded").value.trim().slice(0, 120),
      iosAppId: $("ad-ios-app").value.trim().slice(0, 120),
      iosBannerId: $("ad-ios-banner").value.trim().slice(0, 120),
      updatedByUid: currentUser.uid,
      updatedAt: serverTimestamp()
    };
    await setDoc(doc(db, "app_settings", "admob_config"), payload);
    await logAudit("UPDATE_ADMOB_CONFIG", "app_settings", "admob_config", `Global=${payload.adsGlobalEnabled}, Kill=${payload.emergencyKillSwitch}`);
    showToast("AdMob remote config published!");
  } catch (err) {
    showToast(`AdMob save failed: ${err.message}`);
  }
});

// Global Settings & Offline Publish
function populateGlobalForm(d) {
  $("set-announcement").value = d.announcement || "";
  $("set-maintenance").value = d.maintenanceNotice || "";
  $("set-min-version").value = d.minSupportedVersion || "1.0.0";
}

$("global-settings-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    const payload = {
      configType: "GLOBAL",
      announcement: $("set-announcement").value.trim().slice(0, 400),
      maintenanceNotice: $("set-maintenance").value.trim().slice(0, 400),
      minSupportedVersion: ($("set-min-version").value.trim() || "1.0.0").slice(0, 32),
      updatedByUid: currentUser.uid,
      updatedAt: serverTimestamp()
    };
    await setDoc(doc(db, "app_settings", "global_config"), payload);
    await logAudit("UPDATE_GLOBAL_SETTINGS", "app_settings", "global_config", `MinVer=${payload.minSupportedVersion}`);
    showToast("Remote App Settings published!");
  } catch (err) {
    showToast(`Save failed: ${err.message}`);
  }
});

function downloadBackupJson() {
  const blob = new Blob(
    [JSON.stringify({ exportedAt: new Date().toISOString(), databaseId: FIRESTORE_DATABASE_ID, catalog: cachedCatalog, reports: cachedReports }, null, 2)],
    { type: "application/json" }
  );
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `repair-pro-backup-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast("Exported JSON backup.");
}

// Roles Management (Bootstrap Super Admin only)
$("register-self-admin-btn").addEventListener("click", async () => {
  if (!currentUser) return;
  await grantRole(currentUser.uid, "SUPER_ADMIN");
});

$("role-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const uid = sanitizeId($("role-uid").value.trim());
  const role = $("role-name").value;
  if (!uid) return;
  await grantRole(uid, role);
  e.target.reset();
});

async function grantRole(uid, role) {
  try {
    const ref = doc(db, "admins", uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, { userId: uid, role, createdAt: serverTimestamp() });
      await logAudit("GRANT_ADMIN_ROLE", "admins", uid, `Granted ${role}`);
    } else {
      await updateDoc(ref, { role });
      await logAudit("UPDATE_ADMIN_ROLE", "admins", uid, `Updated -> ${role}`);
    }
    showToast(`Saved ${role} for ${uid}`);
  } catch (err) {
    showToast(`Role update failed: ${err.message}`);
  }
}

function renderRolesList() {
  const list = $("roles-list");
  list.replaceChildren();
  cachedRoles.forEach((r) => {
    const row = document.createElement("div");
    row.className = "list-item";
    const left = document.createElement("div");
    left.textContent = `${r.userId} — ${r.role}`;
    const btn = document.createElement("button");
    btn.className = "btn btn-danger btn-sm";
    btn.textContent = "Revoke";
    btn.addEventListener("click", async () => {
      try {
        await deleteDoc(doc(db, "admins", r.id));
        await logAudit("REVOKE_ADMIN_ROLE", "admins", r.id, "Revoked admin role");
        showToast("Admin role revoked.");
      } catch (err) {
        showToast(`Revoke failed: ${err.message}`);
      }
    });
    row.append(left, btn);
    list.append(row);
  });
}

function renderAuditLogs() {
  const list = $("audit-list");
  list.replaceChildren();
  if (cachedLogs.length === 0) {
    const p = document.createElement("p");
    p.className = "subtitle";
    p.textContent = "No audit logs recorded yet.";
    list.append(p);
    return;
  }
  cachedLogs.slice(0, 50).forEach((log) => {
    const row = document.createElement("div");
    row.className = "list-item";
    const info = document.createElement("div");
    const t = document.createElement("strong");
    t.style.color = "var(--cyan)";
    t.textContent = `${log.action} • ${log.targetType}`;
    const d = document.createElement("div");
    d.style.fontSize = "13px";
    d.textContent = log.details || "";
    const by = document.createElement("div");
    by.style.fontSize = "11px";
    by.style.color = "var(--text-muted)";
    by.textContent = `By ${log.adminEmail} (${log.targetId})`;
    info.append(t, d, by);
    row.append(info);
    list.append(row);
  });
}
