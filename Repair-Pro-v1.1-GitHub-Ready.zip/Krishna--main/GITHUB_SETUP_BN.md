# Repair Pro v1.1.0 — GitHub Actions setup (বাংলা)

এই ZIP-এ Android Technician update-এর existing source code অক্ষত রাখা হয়েছে। শুধু Android build workflow ও `.gitignore` পরিবর্তন করা হয়েছে। Firebase-এর live rules বা Netlify site এখানে deploy করা হয়নি।

## GitHub Secrets (Settings > Secrets and variables > Actions)

1. `GOOGLE_SERVICES_JSON_BASE64`: Firebase Console থেকে download করা **latest** `app/google-services.json`-এর সম্পূর্ণ ফাইল Base64 করে রাখুন। Firebase-এ বর্তমান APK-এর SHA-1 নিবন্ধিত আছে কি না নিশ্চিত করুন।
2. `DEBUG_KEYSTORE_BASE64`: যে `debug.keystore` দিয়ে **পুরোনো installed debug APK** sign করা হয়েছিল, তার Base64। এটি ছাড়া পুরোনো debug APK-এর ওপর update হবে না। যদি আসল keystore না থাকে, নতুন APK নতুন install হিসেবে পরীক্ষা করতে হতে পারে।
3. Release APK/AAB চাইলে: `KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_PASSWORD` — **আগের release signing key**-এর।

Base64 তৈরির উদাহরণ (macOS/Linux): `base64 -w 0 google-services.json` (macOS: `base64 -i google-services.json | tr -d '\n'`)। Signing keystore-এর ক্ষেত্রেও একই পদ্ধতি। Secret values কখনও chat/public repository-তে প্রকাশ করবেন না।

## GitHub upload

ZIP-এর ভেতরের `Krishna--main/` ফোল্ডারের **contents** GitHub repo-এর root-এ upload/commit করতে হবে; ZIP ফাইলটি শুধু root-এ upload করলে workflow source files পাবে না। তারপর Actions > Build Repair Pro Android App > Run workflow।

## গুরুত্বপূর্ণ

- Package: `com.aistudio.repairpro.kxmvqz`; versionCode 2 / versionName 1.1.0 (unchanged).
- Existing installed debug APK update করতে signing certificate একই হতে হবে। GitHub-hosted runner-এ স্বয়ংক্রিয়ভাবে তৈরি নতুন debug keystore পুরোনো key-এর সঙ্গে মিলবে না।
- Firestore/Storage rules প্রকাশ করার আগে বর্তমান rules-এর সঙ্গে merge ও test করতে হবে।
- Web Admin workflow `deploy-web-admin.yml` Firebase Hosting-এ deploy করে, Netlify-তে নয়। Netlify-তে updated `web-admin/` আলাদাভাবে deploy করুন।
- এই package-এর Android build বা বাস্তব installation এখানে চালিয়ে যাচাই করা হয়নি।
