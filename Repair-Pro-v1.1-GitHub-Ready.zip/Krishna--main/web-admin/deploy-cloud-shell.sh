#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="gen-lang-client-0218221723"
DB_ID="ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8"

echo "=== Repair Pro — Firebase Hosting Pre-Deployment Verification ==="
[ -f "firebase.json" ] || { echo "ERROR: Run this script from the repository root containing firebase.json"; exit 1; }
[ -f "web-admin/index.html" ] || { echo "ERROR: Missing web-admin/index.html"; exit 1; }
[ -f "web-admin/app.js" ] || { echo "ERROR: Missing web-admin/app.js"; exit 1; }
[ -f "web-admin/firebase-config.js" ] || { echo "ERROR: Missing web-admin/firebase-config.js"; exit 1; }

grep -q "$PROJECT_ID" web-admin/firebase-config.js || { echo "ERROR: Project ID mismatch in firebase-config.js"; exit 1; }
grep -q "$DB_ID" web-admin/firebase-config.js || { echo "ERROR: Named Firestore DB mismatch in firebase-config.js"; exit 1; }
echo "OK: web-admin/ files, project ($PROJECT_ID), and named DB ($DB_ID) verified."

if ! command -v firebase >/dev/null 2>&1; then
  echo "Installing firebase-tools..."
  npm install -g firebase-tools
fi

echo "Checking Firebase CLI auth..."
if ! firebase projects:list >/dev/null 2>&1; then
  echo "Please authenticate Firebase CLI (opens Google login URL in your browser):"
  firebase login --no-localhost
fi

echo "Selecting project $PROJECT_ID..."
firebase use "$PROJECT_ID"

echo "Deploying Web Super Admin Panel to Firebase Hosting..."
firebase deploy --only hosting --project "$PROJECT_ID"

echo ""
echo "=== Deployment Complete ==="
echo "Live HTTPS URL: https://${PROJECT_ID}.web.app"
echo "Alternate URL:  https://${PROJECT_ID}.firebaseapp.com"
