// Repair Pro — Shared Firebase Backend Configuration (Web Super Admin Panel)
// Connects to the exact same Firebase project and named Firestore database as the Android app.
// Note: Firebase client config identifies your Firebase project; all access control is enforced
// server-side by Firebase Authentication + deployed firestore.rules (zero hardcoded admin passwords).

export const firebaseConfig = {
  apiKey: "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M",
  authDomain: "gen-lang-client-0218221723.firebaseapp.com",
  projectId: "gen-lang-client-0218221723",
  storageBucket: "gen-lang-client-0218221723.firebasestorage.app",
  messagingSenderId: "548310962148"
};

export const FIRESTORE_DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
export const BOOTSTRAP_SUPER_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
