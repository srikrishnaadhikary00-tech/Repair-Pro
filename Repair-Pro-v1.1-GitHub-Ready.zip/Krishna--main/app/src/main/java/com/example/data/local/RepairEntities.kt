package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "appliance_categories")
data class ApplianceCategoryEntity(
    @PrimaryKey val id: String,
    val nameEn: String,
    val nameBn: String,
    val nameHi: String,
    val subtitleEn: String,
    val subtitleBn: String,
    val subtitleHi: String,
    val iconKey: String,
    val downloaded: Boolean = true,
    val lastSyncedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "brands")
data class BrandEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    val name: String,
    val popular: Boolean = true,
    val modelsCsv: String
)

@Entity(tableName = "error_codes")
data class ErrorCodeEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    val brandId: String,
    val brandName: String,
    val modelSeries: String,
    val code: String,
    val titleEn: String,
    val titleBn: String,
    val titleHi: String,
    val meaningEn: String,
    val meaningBn: String,
    val meaningHi: String,
    val symptomsEn: String,
    val symptomsBn: String,
    val symptomsHi: String,
    val causesEn: String,
    val causesBn: String,
    val causesHi: String,
    val diagnosticsEn: String,
    val diagnosticsBn: String,
    val diagnosticsHi: String,
    val solutionsEn: String,
    val solutionsBn: String,
    val solutionsHi: String,
    val safetyWarningEn: String,
    val safetyWarningBn: String,
    val safetyWarningHi: String,
    val sourceDocumentation: String,
    val verificationStatus: String = "VERIFIED",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "problem_guides")
data class ProblemGuideEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    val iconKey: String,
    val titleEn: String,
    val titleBn: String,
    val titleHi: String,
    val symptomsEn: String,
    val symptomsBn: String,
    val symptomsHi: String,
    val causesEn: String,
    val causesBn: String,
    val causesHi: String,
    val safeStepsEn: String,
    val safeStepsBn: String,
    val safeStepsHi: String,
    val recommendedSolutionEn: String,
    val recommendedSolutionBn: String,
    val recommendedSolutionHi: String,
    val requiredTools: String,
    val relatedErrorCodes: String,
    val safetyWarningEn: String,
    val safetyWarningBn: String,
    val safetyWarningHi: String,
    val technicianCriteriaEn: String,
    val technicianCriteriaBn: String,
    val technicianCriteriaHi: String,
    val sourceDocumentation: String,
    val verificationStatus: String = "VERIFIED",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey val query: String,
    val categoryId: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "offline_packages")
data class OfflinePackageEntity(
    @PrimaryKey val categoryId: String,
    val packageName: String,
    val version: Int = 1,
    val recordCount: Int,
    val sizeKb: Int,
    val downloaded: Boolean = true,
    val lastUpdatedAt: Long = System.currentTimeMillis()
)

data class WizardNode(
    val id: String,
    val categoryId: String,
    val questionEn: String,
    val questionBn: String,
    val questionHi: String,
    val options: List<WizardOption>,
    val conclusionEn: String? = null,
    val conclusionBn: String? = null,
    val conclusionHi: String? = null,
    val safeCheckEn: String? = null,
    val safeCheckBn: String? = null,
    val safeCheckHi: String? = null,
    val technicianWarningEn: String? = null,
    val technicianWarningBn: String? = null,
    val technicianWarningHi: String? = null,
    val relatedProblemId: String? = null,
    val relatedErrorCodeId: String? = null
)

data class WizardOption(
    val labelEn: String,
    val labelBn: String,
    val labelHi: String,
    val nextNodeId: String
)
