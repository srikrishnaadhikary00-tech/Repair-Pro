package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val RepairProDarkColorScheme = darkColorScheme(
    primary = ElectricBluePrimary,
    onPrimary = TextPrimaryWhite,
    primaryContainer = Color(0xFF0A3260),
    onPrimaryContainer = CyanAccent,
    secondary = CyanAccent,
    onSecondary = DeepNavyBackground,
    secondaryContainer = ElevatedCardSurface,
    onSecondaryContainer = TextPrimaryWhite,
    tertiary = SuccessGreen,
    onTertiary = DeepNavyBackground,
    background = DeepNavyBackground,
    onBackground = TextPrimaryWhite,
    surface = SecondaryNavySurface,
    onSurface = TextPrimaryWhite,
    surfaceVariant = ElevatedCardSurface,
    onSurfaceVariant = TextSecondarySlate,
    outline = CardBorderSubtle,
    outlineVariant = Color(0xFF182945),
    error = ErrorCrimson,
    onError = TextPrimaryWhite,
    errorContainer = Color(0xFF3E121B),
    onErrorContainer = Color(0xFFFFB3BC)
)

private val RepairProShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun RepairProTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RepairProDarkColorScheme,
        typography = RepairProTypography,
        shapes = RepairProShapes,
        content = content
    )
}
