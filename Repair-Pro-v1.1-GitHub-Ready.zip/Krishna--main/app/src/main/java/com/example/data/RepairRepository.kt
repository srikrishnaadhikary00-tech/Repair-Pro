package com.example.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.BrandEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.OfflinePackageEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.local.RepairDao
import com.example.data.local.RepairProDatabase
import com.example.data.local.SearchHistoryEntity
import com.example.data.local.SeedDataPart1
import com.example.data.local.SeedDataPart2
import com.example.data.remote.CatalogEntryCloud
import com.example.data.remote.CloudRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class RepairRepository(
    private val dao: RepairDao,
    val cloud: CloudRepository,
    private val appContext: Context
) {
    constructor(context: Context) : this(
        dao = RepairProDatabase.getInstance(context.applicationContext).repairDao(),
        cloud = CloudRepository(context.applicationContext),
        appContext = context.applicationContext
    )

    val categories: Flow<List<ApplianceCategoryEntity>> = dao.observeCategories()
    val allBrands: Flow<List<BrandEntity>> = dao.observeAllBrands()
    val allErrorCodes: Flow<List<ErrorCodeEntity>> = dao.observeAllErrorCodes()
    val allProblems: Flow<List<ProblemGuideEntity>> = dao.observeAllProblems()
    val searchHistory: Flow<List<SearchHistoryEntity>> = dao.observeSearchHistory()
    val offlinePackages: Flow<List<OfflinePackageEntity>> = dao.observeOfflinePackages()

    suspend fun ensureOfflineDatabaseSeeded() = withContext(Dispatchers.IO) {
        if (dao.countCategories() == 0) {
            dao.upsertCategories(SeedDataPart1.categories)
            dao.upsertBrands(SeedDataPart1.brands)
            dao.upsertErrorCodes(SeedDataPart1.acErrorCodes + SeedDataPart2.fridgeAndWasherErrorCodes)
            dao.upsertProblems(SeedDataPart1.acProblems + SeedDataPart2.fridgeAndWasherProblems)
            dao.upsertOfflinePackages(SeedDataPart2.offlinePackages)
        }
    }

    suspend fun recordSearch(query: String, categoryId: String? = null) = withContext(Dispatchers.IO) {
        val clean = query.trim()
        if (clean.length >= 2) {
            dao.upsertSearchHistory(SearchHistoryEntity(query = clean, categoryId = categoryId))
        }
    }

    suspend fun clearSearchHistory() = withContext(Dispatchers.IO) {
        dao.clearSearchHistory()
    }

    suspend fun toggleOfflinePackage(categoryId: String, downloaded: Boolean) = withContext(Dispatchers.IO) {
        dao.updatePackageStatus(categoryId, downloaded, System.currentTimeMillis())
    }

    suspend fun mergeCloudCatalogIntoOfflineDb(entries: List<CatalogEntryCloud>): Int = withContext(Dispatchers.IO) {
        var mergedCount = 0
        val now = System.currentTimeMillis()
        for (entry in entries) {
            if (!entry.published) continue
            when (entry.entryType) {
                "CATEGORY" -> {
                    dao.upsertCategory(
                        ApplianceCategoryEntity(
                            id = entry.categoryId.lowercase(),
                            nameEn = entry.titleEn,
                            nameBn = entry.titleBn.ifBlank { entry.titleEn },
                            nameHi = entry.titleHi.ifBlank { entry.titleEn },
                            subtitleEn = entry.summaryEn,
                            subtitleBn = entry.summaryBn.ifBlank { entry.summaryEn },
                            subtitleHi = entry.summaryHi.ifBlank { entry.summaryEn },
                            iconKey = entry.categoryId.lowercase(),
                            downloaded = true,
                            lastSyncedAt = now
                        )
                    )
                    mergedCount++
                }
                "ERROR_CODE" -> {
                    val safeCode = entry.code.ifBlank { "CODE" }
                    val safeBrand = entry.brandName.ifBlank { "Universal" }
                    dao.upsertErrorCode(
                        ErrorCodeEntity(
                            id = "cloud_${entry.id}",
                            categoryId = entry.categoryId,
                            brandId = "${entry.categoryId}_${safeBrand.lowercase().replace(" ", "")}",
                            brandName = safeBrand,
                            modelSeries = entry.modelSeries.ifBlank { "General Series" },
                            code = safeCode,
                            titleEn = entry.titleEn,
                            titleBn = entry.titleBn,
                            titleHi = entry.titleHi,
                            meaningEn = entry.summaryEn,
                            meaningBn = entry.summaryBn,
                            meaningHi = entry.summaryHi,
                            symptomsEn = entry.summaryEn,
                            symptomsBn = entry.summaryBn,
                            symptomsHi = entry.summaryHi,
                            causesEn = entry.summaryEn,
                            causesBn = entry.summaryBn,
                            causesHi = entry.summaryHi,
                            diagnosticsEn = entry.stepsEn.ifBlank { "Inspect error code and follow safe reset guidelines." },
                            diagnosticsBn = entry.stepsBn,
                            diagnosticsHi = entry.stepsHi,
                            solutionsEn = entry.stepsEn.ifBlank { "Verify wiring or consult a certified technician." },
                            solutionsBn = entry.stepsBn,
                            solutionsHi = entry.stepsHi,
                            safetyWarningEn = entry.safetyWarningEn.ifBlank { "Disconnect mains power before inspecting any electrical appliance." },
                            safetyWarningBn = "",
                            safetyWarningHi = "",
                            sourceDocumentation = "Super Admin Published Catalog (Rev ${entry.revision})",
                            verificationStatus = entry.verificationStatus,
                            updatedAt = now
                        )
                    )
                    mergedCount++
                }
                "PROBLEM" -> {
                    dao.upsertProblem(
                        ProblemGuideEntity(
                            id = "cloud_${entry.id}",
                            categoryId = entry.categoryId,
                            iconKey = entry.categoryId,
                            titleEn = entry.titleEn,
                            titleBn = entry.titleBn,
                            titleHi = entry.titleHi,
                            symptomsEn = entry.summaryEn,
                            symptomsBn = entry.summaryBn,
                            symptomsHi = entry.summaryHi,
                            causesEn = entry.summaryEn,
                            causesBn = entry.summaryBn,
                            causesHi = entry.summaryHi,
                            safeStepsEn = entry.stepsEn.ifBlank { "Perform safe external checks before calling a technician." },
                            safeStepsBn = entry.stepsBn,
                            safeStepsHi = entry.stepsHi,
                            recommendedSolutionEn = entry.stepsEn.ifBlank { entry.summaryEn },
                            recommendedSolutionBn = entry.stepsBn,
                            recommendedSolutionHi = entry.stepsHi,
                            requiredTools = "Standard inspection tools",
                            relatedErrorCodes = entry.code,
                            safetyWarningEn = entry.safetyWarningEn.ifBlank { "Disconnect mains power before inspecting appliance." },
                            safetyWarningBn = "",
                            safetyWarningHi = "",
                            technicianCriteriaEn = "Contact a certified technician if fault persists after safe checks.",
                            technicianCriteriaBn = "",
                            technicianCriteriaHi = "",
                            sourceDocumentation = "Super Admin Published Guide (Rev ${entry.revision})",
                            verificationStatus = entry.verificationStatus,
                            updatedAt = now
                        )
                    )
                    mergedCount++
                }
            }
        }
        // Update offline package timestamps
        for (catId in listOf("ac", "fridge", "washer")) {
            val total = dao.countErrorCodesForCategory(catId) + dao.countProblemsForCategory(catId)
            dao.upsertOfflinePackages(
                listOf(
                    OfflinePackageEntity(
                        categoryId = catId,
                        packageName = when (catId) {
                            "ac" -> "Air Conditioner Full Offline Pack"
                            "fridge" -> "Refrigerator Full Offline Pack"
                            else -> "Washing Machine Full Offline Pack"
                        },
                        version = 2,
                        recordCount = total,
                        sizeKb = 280 + (total * 14),
                        downloaded = true,
                        lastUpdatedAt = now
                    )
                )
            )
        }
        mergedCount
    }

    fun isNetworkAvailable(): Boolean {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun exportCatalogAsJson(
        errorCodes: List<ErrorCodeEntity>,
        problems: List<ProblemGuideEntity>
    ): String {
        val root = JSONObject()
        root.put("app", "Repair Pro")
        root.put("exportedAt", System.currentTimeMillis())
        val codesArray = JSONArray()
        errorCodes.forEach { c ->
            codesArray.put(
                JSONObject().apply {
                    put("id", c.id)
                    put("categoryId", c.categoryId)
                    put("brand", c.brandName)
                    put("code", c.code)
                    put("titleEn", c.titleEn)
                    put("verificationStatus", c.verificationStatus)
                }
            )
        }
        val probArray = JSONArray()
        problems.forEach { p ->
            probArray.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("categoryId", p.categoryId)
                    put("titleEn", p.titleEn)
                    put("verificationStatus", p.verificationStatus)
                }
            )
        }
        root.put("errorCodes", codesArray)
        root.put("problems", probArray)
        return root.toString(2)
    }
}
