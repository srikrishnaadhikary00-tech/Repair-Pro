package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.RepairRepository
import com.example.data.remote.authStateFlow
import com.example.data.remote.signOutGoogle
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.RepairViewModel
import com.example.ui.screens.AuthSplashScreen
import com.example.ui.screens.CameraScannerScreen
import com.example.ui.screens.CategoriesDirectoryScreen
import com.example.ui.screens.CategoryDetailBrandScreen
import com.example.ui.screens.ErrorCodeDetailScreen
import com.example.ui.screens.FindTechnicianScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.OfflineDownloadsScreen
import com.example.ui.screens.ProblemDetailScreen
import com.example.ui.screens.ReportProblemScreen
import com.example.ui.screens.SavedGuidesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SmartSearchScreen
import com.example.ui.screens.SuperAdminScreen
import com.example.ui.screens.TroubleshootingWizardScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkScreenGradient
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.RepairProTheme
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

private const val ROUTE_HOME = "home"
private const val ROUTE_CATEGORIES = "categories"
private const val ROUTE_SEARCH_BASE = "search"
private const val ROUTE_SEARCH_PATTERN = "search?q={q}&type={type}"
private const val ROUTE_TECHNICIANS = "technicians"
private const val ROUTE_SAVED = "saved"
private const val ROUTE_SETTINGS = "settings"
private const val ROUTE_CATEGORY_DETAIL = "category/{categoryId}"
private const val ROUTE_ERROR_DETAIL = "error/{errorId}"
private const val ROUTE_PROBLEM_DETAIL = "problem/{problemId}"
private const val ROUTE_WIZARD = "wizard/{categoryId}"
private const val ROUTE_SCANNER = "scanner"
private const val ROUTE_OFFLINE = "offline"
private const val ROUTE_REPORT = "report"
private const val ROUTE_ADMIN = "admin"

private data class TopLevelDestination(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            RepairProTheme {
                RepairProAppRoot()
            }
        }
    }
}

@Composable
private fun RepairProAppRoot() {
    val authFlow = remember { Firebase.auth.authStateFlow() }
    val currentUser by authFlow.collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)
    var selectedPreAuthLanguageCode by rememberSaveable { mutableStateOf(AppLanguage.EN.code) }
    var openAdminAfterLogin by rememberSaveable { mutableStateOf(false) }
    val preAuthLang = AppLanguage.fromCode(selectedPreAuthLanguageCode)

    if (currentUser == null) {
        AuthSplashScreen(
            selectedLanguage = preAuthLang,
            onSelectLanguage = { selectedPreAuthLanguageCode = it.code },
            onAuthSuccess = { /* authStateFlow updates automatically */ },
            onAdminPortalRequested = { openAdminAfterLogin = true }
        )
    } else {
        val user = currentUser!!
        key(user.uid) {
            val appContext = LocalContext.current.applicationContext
            val repository = remember(appContext) { RepairRepository(appContext) }
            val viewModel: RepairViewModel = viewModel(
                key = user.uid,
                factory = viewModelFactory {
                    initializer {
                        RepairViewModel(
                            repository = repository,
                            currentUserId = user.uid,
                            userDisplayName = user.displayName ?: "Repair Pro User",
                            userEmail = user.email ?: "",
                            initialLanguage = preAuthLang
                        )
                    }
                }
            )
            AuthenticatedRepairProShell(
                viewModel = viewModel,
                startInAdminPortal = openAdminAfterLogin,
                onAdminPortalConsumed = { openAdminAfterLogin = false }
            )
        }
    }
}

@Composable
private fun AuthenticatedRepairProShell(
    viewModel: RepairViewModel,
    startInAdminPortal: Boolean = false,
    onAdminPortalConsumed: () -> Unit = {}
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val snackbarHostState = remember { SnackbarHostState() }

    val language by viewModel.language.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val isBootstrapAdmin by viewModel.isBootstrapAdmin.collectAsStateWithLifecycle()
    val adminRoleChecked by viewModel.adminRoleChecked.collectAsStateWithLifecycle()
    val adConsentGranted by viewModel.adConsentGranted.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val syncInProgress by viewModel.syncInProgress.collectAsStateWithLifecycle()
    val lastSyncTime by viewModel.lastCloudSyncTime.collectAsStateWithLifecycle()

    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val brands by viewModel.brands.collectAsStateWithLifecycle()
    val totalModels by viewModel.totalModelCount.collectAsStateWithLifecycle()
    val errorCodes by viewModel.errorCodes.collectAsStateWithLifecycle()
    val problems by viewModel.problems.collectAsStateWithLifecycle()
    val searchHistory by viewModel.searchHistory.collectAsStateWithLifecycle()
    val offlinePackages by viewModel.offlinePackages.collectAsStateWithLifecycle()
    val savedGuides by viewModel.savedGuides.collectAsStateWithLifecycle()
    val userReports by viewModel.userReports.collectAsStateWithLifecycle()
    val publishedCatalog by viewModel.publishedCloudCatalog.collectAsStateWithLifecycle()
    val adMobConfig by viewModel.adMobConfig.collectAsStateWithLifecycle()
    val globalConfig by viewModel.globalConfig.collectAsStateWithLifecycle()
    val adminAllReports by viewModel.adminAllReports.collectAsStateWithLifecycle()
    val adminAllCatalog by viewModel.adminAllCatalog.collectAsStateWithLifecycle()
    val adminAuditLogs by viewModel.adminAuditLogs.collectAsStateWithLifecycle()
    val adminRoles by viewModel.adminRoles.collectAsStateWithLifecycle()
    val activeTechniciansState by viewModel.activeTechniciansState.collectAsStateWithLifecycle()
    val adminAllTechnicians by viewModel.adminAllTechnicians.collectAsStateWithLifecycle()

    LaunchedEffect(startInAdminPortal) {
        if (startInAdminPortal) {
            navController.navigate(ROUTE_ADMIN) { launchSingleTop = true }
            onAdminPortalConsumed()
        }
    }

    val strings = StringsProvider.get(language)

    LaunchedEffect(statusBanner) {
        val message = statusBanner
        if (!message.isNullOrBlank()) {
            snackbarHostState.showSnackbar(message)
            viewModel.clearStatusBanner()
        }
    }

    val topDestinations = listOf(
        TopLevelDestination(ROUTE_HOME, strings.navHome, Icons.Filled.Home, "nav_home"),
        TopLevelDestination(ROUTE_CATEGORIES, strings.navCategories, Icons.Filled.Category, "nav_categories"),
        TopLevelDestination(ROUTE_SEARCH_BASE, strings.navSearch, Icons.Filled.Search, "nav_search"),
        TopLevelDestination(ROUTE_TECHNICIANS, strings.navTechnicians, Icons.Filled.Engineering, "nav_technicians"),
        TopLevelDestination(ROUTE_SAVED, strings.navSaved, Icons.Filled.Bookmark, "nav_saved"),
        TopLevelDestination(ROUTE_SETTINGS, strings.navSettings, Icons.Filled.Settings, "nav_settings")
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_HOME
    val showTopLevelNav = currentRoute == ROUTE_HOME ||
        currentRoute == ROUTE_CATEGORIES ||
        currentRoute.startsWith(ROUTE_SEARCH_BASE) ||
        currentRoute == ROUTE_TECHNICIANS ||
        currentRoute == ROUTE_SAVED ||
        currentRoute == ROUTE_SETTINGS

    fun navigateTopLevel(route: String) {
        val target = if (route == ROUTE_SEARCH_BASE) "search?q=&type=ALL" else route
        navController.navigate(target) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun navigateToSearch(query: String = "", filterType: String = "ALL") {
        val encoded = Uri.encode(query)
        navController.navigate("search?q=$encoded&type=$filterType") {
            launchSingleTop = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkScreenGradient)
    ) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = {
                SnackbarHost(hostState = snackbarHostState) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = SecondaryNavySurface,
                        contentColor = TextPrimaryWhite,
                        actionColor = CyanAccent
                    )
                }
            },
            bottomBar = {
                if (showTopLevelNav && !useNavRail) {
                    NavigationBar(
                        containerColor = DeepCardSurface,
                        tonalElevation = 0.dp
                    ) {
                        topDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route ||
                                (dest.route == ROUTE_SEARCH_BASE && currentRoute.startsWith(ROUTE_SEARCH_BASE))
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                modifier = Modifier.testTag(dest.testTag),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyanAccent,
                                    selectedTextColor = CyanAccent,
                                    unselectedIconColor = TextSecondarySlate,
                                    unselectedTextColor = TextSecondarySlate,
                                    indicatorColor = ElectricBluePrimary.copy(alpha = 0.22f)
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showTopLevelNav && useNavRail) {
                    NavigationRail(
                        containerColor = DeepCardSurface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        topDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route ||
                                (dest.route == ROUTE_SEARCH_BASE && currentRoute.startsWith(ROUTE_SEARCH_BASE))
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                modifier = Modifier.testTag(dest.testTag),
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CyanAccent,
                                    selectedTextColor = CyanAccent,
                                    unselectedIconColor = TextSecondarySlate,
                                    unselectedTextColor = TextSecondarySlate,
                                    indicatorColor = ElectricBluePrimary.copy(alpha = 0.22f)
                                )
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_HOME
                    ) {
                        composable(ROUTE_HOME) {
                            HomeDashboardScreen(
                                language = language,
                                categories = categories,
                                errorCodes = errorCodes,
                                problems = problems,
                                searchHistory = searchHistory,
                                savedGuides = savedGuides,
                                publishedCatalog = publishedCatalog,
                                adMobConfig = adMobConfig,
                                globalConfig = globalConfig,
                                isOnline = isOnline,
                                isAdmin = isAdmin,
                                adConsentGranted = adConsentGranted,
                                onSelectLanguage = viewModel::setLanguage,
                                onOpenSearch = { q -> navigateToSearch(q, "ALL") },
                                onOpenCategory = { catId -> navController.navigate("category/$catId") },
                                onOpenErrorSearch = { navigateToSearch("", "ERROR") },
                                onOpenProblemSearch = { navigateToSearch("", "PROBLEM") },
                                onOpenScanner = { navController.navigate(ROUTE_SCANNER) },
                                onOpenWizard = { catId -> navController.navigate("wizard/$catId") },
                                onOpenOfflineDownloads = { navController.navigate(ROUTE_OFFLINE) },
                                onOpenSaved = { navigateTopLevel(ROUTE_SAVED) },
                                onOpenReportProblem = { navController.navigate(ROUTE_REPORT) },
                                onOpenAdminConsole = { navController.navigate(ROUTE_ADMIN) },
                                onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                onOpenProblemDetail = { id -> navController.navigate("problem/$id") },
                                onOpenFindTechnician = { navigateTopLevel(ROUTE_TECHNICIANS) }
                            )
                        }

                        composable(ROUTE_CATEGORIES) {
                            CategoriesDirectoryScreen(
                                language = language,
                                categories = categories,
                                errorCodes = errorCodes,
                                problems = problems,
                                onSelectCategory = { catId -> navController.navigate("category/$catId") },
                                onOpenWizard = { catId -> navController.navigate("wizard/$catId") }
                            )
                        }

                        composable(
                            route = ROUTE_SEARCH_PATTERN,
                            arguments = listOf(
                                navArgument("q") { type = NavType.StringType; defaultValue = "" },
                                navArgument("type") { type = NavType.StringType; defaultValue = "ALL" }
                            )
                        ) { entry ->
                            val q = entry.arguments?.getString("q").orEmpty()
                            val filterType = entry.arguments?.getString("type").orEmpty().ifBlank { "ALL" }
                            SmartSearchScreen(
                                initialQuery = q,
                                initialFilterType = filterType,
                                language = language,
                                errorCodes = errorCodes,
                                problems = problems,
                                searchHistory = searchHistory,
                                adMobConfig = adMobConfig,
                                isOnline = isOnline,
                                adConsentGranted = adConsentGranted,
                                onRecordSearch = { term -> viewModel.recordSearch(term) },
                                onClearHistory = viewModel::clearSearchHistory,
                                onOpenScanner = { navController.navigate(ROUTE_SCANNER) },
                                onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                onOpenProblemDetail = { id -> navController.navigate("problem/$id") }
                            )
                        }

                        composable(ROUTE_TECHNICIANS) {
                            FindTechnicianScreen(
                                language = language,
                                techniciansState = activeTechniciansState,
                                isOnline = isOnline,
                                onRetry = viewModel::retryLoadTechnicians,
                                onShowMessage = viewModel::showStatusMessage
                            )
                        }

                        composable(ROUTE_SAVED) {
                            SavedGuidesScreen(
                                language = language,
                                savedGuides = savedGuides,
                                onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                onOpenProblemDetail = { id -> navController.navigate("problem/$id") },
                                onRemoveGuide = { guide ->
                                    viewModel.toggleSavedGuide(
                                        itemType = guide.itemType,
                                        itemId = guide.itemId,
                                        categoryId = guide.categoryId,
                                        title = guide.title,
                                        subtitle = guide.subtitle
                                    )
                                }
                            )
                        }

                        composable(ROUTE_SETTINGS) {
                            SettingsScreen(
                                language = language,
                                userDisplayName = viewModel.userDisplayName,
                                userEmail = viewModel.userEmail,
                                isAdmin = isAdmin,
                                adConsentGranted = adConsentGranted,
                                onSelectLanguage = viewModel::setLanguage,
                                onToggleAdConsent = viewModel::setAdConsent,
                                onOpenOfflineDownloads = { navController.navigate(ROUTE_OFFLINE) },
                                onOpenReportProblem = { navController.navigate(ROUTE_REPORT) },
                                onOpenAdminConsole = { navController.navigate(ROUTE_ADMIN) },
                                onDeleteCloudData = {
                                    viewModel.deleteMyCloudData {
                                        signOutGoogle(credentialManager, scope)
                                    }
                                },
                                onSignOut = { signOutGoogle(credentialManager, scope) }
                            )
                        }

                        composable(
                            route = ROUTE_CATEGORY_DETAIL,
                            arguments = listOf(navArgument("categoryId") { type = NavType.StringType })
                        ) { entry ->
                            val categoryId = entry.arguments?.getString("categoryId") ?: "ac"
                            CategoryDetailBrandScreen(
                                categoryId = categoryId,
                                language = language,
                                category = categories.firstOrNull { it.id == categoryId },
                                brands = brands.filter { it.categoryId == categoryId },
                                errorCodes = errorCodes.filter { it.categoryId == categoryId },
                                problems = problems.filter { it.categoryId == categoryId },
                                adMobConfig = adMobConfig,
                                isOnline = isOnline,
                                adConsentGranted = adConsentGranted,
                                onBack = { navController.popBackStack() },
                                onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                onOpenProblemDetail = { id -> navController.navigate("problem/$id") },
                                onOpenWizard = { id -> navController.navigate("wizard/$id") },
                                onOpenScanner = { navController.navigate(ROUTE_SCANNER) }
                            )
                        }

                        composable(
                            route = ROUTE_ERROR_DETAIL,
                            arguments = listOf(navArgument("errorId") { type = NavType.StringType })
                        ) { entry ->
                            val errorId = entry.arguments?.getString("errorId").orEmpty()
                            val item = errorCodes.firstOrNull { it.id == errorId }
                            val isSaved = savedGuides.any { it.itemType == "ERROR_CODE" && it.itemId == errorId }
                            ErrorCodeDetailScreen(
                                errorCode = item,
                                language = language,
                                isSaved = isSaved,
                                onBack = { navController.popBackStack() },
                                onToggleSave = {
                                    if (item != null) {
                                        val title = resolveLocalizedText(language, item.titleEn, item.titleBn, item.titleHi).text
                                        viewModel.toggleSavedGuide(
                                            itemType = "ERROR_CODE",
                                            itemId = item.id,
                                            categoryId = item.categoryId,
                                            title = "${item.brandName} ${item.code} — $title",
                                            subtitle = item.modelSeries
                                        )
                                    }
                                }
                            )
                        }

                        composable(
                            route = ROUTE_PROBLEM_DETAIL,
                            arguments = listOf(navArgument("problemId") { type = NavType.StringType })
                        ) { entry ->
                            val problemId = entry.arguments?.getString("problemId").orEmpty()
                            val item = problems.firstOrNull { it.id == problemId }
                            val isSaved = savedGuides.any { it.itemType == "PROBLEM" && it.itemId == problemId }
                            ProblemDetailScreen(
                                problem = item,
                                language = language,
                                isSaved = isSaved,
                                onBack = { navController.popBackStack() },
                                onToggleSave = {
                                    if (item != null) {
                                        val title = resolveLocalizedText(language, item.titleEn, item.titleBn, item.titleHi).text
                                        val sym = resolveLocalizedText(language, item.symptomsEn, item.symptomsBn, item.symptomsHi).text
                                        viewModel.toggleSavedGuide(
                                            itemType = "PROBLEM",
                                            itemId = item.id,
                                            categoryId = item.categoryId,
                                            title = title,
                                            subtitle = sym.lineSequence().firstOrNull().orEmpty()
                                        )
                                    }
                                },
                                onSearchRelatedCode = { code -> navigateToSearch(code, "ERROR") }
                            )
                        }

                        composable(
                            route = ROUTE_WIZARD,
                            arguments = listOf(navArgument("categoryId") { type = NavType.StringType })
                        ) { entry ->
                            val categoryId = entry.arguments?.getString("categoryId") ?: "ac"
                            TroubleshootingWizardScreen(
                                initialCategoryId = categoryId,
                                language = language,
                                onBack = { navController.popBackStack() },
                                onOpenProblemDetail = { id -> navController.navigate("problem/$id") },
                                onOpenErrorDetail = { id -> navController.navigate("error/$id") }
                            )
                        }

                        composable(ROUTE_SCANNER) {
                            CameraScannerScreen(
                                language = language,
                                allErrorCodes = errorCodes,
                                onBack = { navController.popBackStack() },
                                onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                onManualSearchFallback = { q -> navigateToSearch(q, "ALL") }
                            )
                        }

                        composable(ROUTE_OFFLINE) {
                            OfflineDownloadsScreen(
                                language = language,
                                packages = offlinePackages,
                                isOnline = isOnline,
                                syncInProgress = syncInProgress,
                                lastSyncTime = lastSyncTime,
                                onBack = { navController.popBackStack() },
                                onSyncNow = viewModel::syncOfflineDatabase,
                                onTogglePackage = viewModel::toggleOfflinePackage
                            )
                        }

                        composable(ROUTE_REPORT) {
                            ReportProblemScreen(
                                language = language,
                                myReports = userReports,
                                onBack = { navController.popBackStack() },
                                onSubmitReport = viewModel::submitProblemReport
                            )
                        }

                        composable(ROUTE_ADMIN) {
                            SuperAdminScreen(
                                isAdmin = isAdmin,
                                isBootstrapAdmin = isBootstrapAdmin,
                                adminRoleChecked = adminRoleChecked,
                                currentUserUid = viewModel.currentUserId,
                                adminEmail = viewModel.userEmail,
                                categories = categories,
                                brands = brands,
                                totalModels = totalModels,
                                errorCodes = errorCodes,
                                problems = problems,
                                allReports = adminAllReports,
                                allCatalog = adminAllCatalog,
                                auditLogs = adminAuditLogs,
                                adminRoles = adminRoles,
                                adMobConfig = adMobConfig,
                                globalConfig = globalConfig,
                                syncInProgress = syncInProgress,
                                onBack = { navController.popBackStack() },
                                onUpdateReportStatus = viewModel::adminUpdateReportStatus,
                                onPublishCatalogEntry = viewModel::adminPublishCatalogEntry,
                                onDeleteCatalogEntry = viewModel::adminDeleteCatalogEntry,
                                onSaveAdMobConfig = viewModel::adminSaveAdMobConfig,
                                onSaveGlobalConfig = viewModel::adminSaveGlobalConfig,
                                onSyncOfflineNow = viewModel::syncOfflineDatabase,
                                onUpsertAdminRole = viewModel::adminUpsertRole,
                                onRevokeAdminRole = viewModel::adminRevokeRole,
                                onExportBackupJson = viewModel::exportCatalogBackupJson,
                                allTechnicians = adminAllTechnicians,
                                onSaveTechnician = viewModel::adminSaveTechnician,
                                onToggleTechnicianStatus = viewModel::adminToggleTechnicianStatus,
                                onDeleteTechnician = viewModel::adminDeleteTechnician
                            )
                        }
                    }
                }
            }
        }
    }
}
