package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ApplianceCategoryEntity::class,
        BrandEntity::class,
        ErrorCodeEntity::class,
        ProblemGuideEntity::class,
        SearchHistoryEntity::class,
        OfflinePackageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RepairProDatabase : RoomDatabase() {
    abstract fun repairDao(): RepairDao

    companion object {
        @Volatile
        private var INSTANCE: RepairProDatabase? = null

        fun getInstance(context: Context): RepairProDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RepairProDatabase::class.java,
                    "repair_pro_offline.db"
                ).fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
