package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.BrandEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.remote.CatalogEntryCloud
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun AdminAppliancesManagementCard(
    categories: List<ApplianceCategoryEntity>,
    brands: List<BrandEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    onQuickAddForCategory: (categoryId: String, entryType: String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Appliance Systems (AC, Refrigerator & Washing Machine)",
            style = MaterialTheme.typography.titleMedium,
            color = CyanAccent
        )
        categories.forEach { cat ->
            val catBrands = brands.filter { it.categoryId == cat.id }
            val catCodes = errorCodes.filter { it.categoryId == cat.id }
            val catProblems = problems.filter { it.categoryId == cat.id }
            val catModels = catBrands.sumOf { b -> b.modelsCsv.split(",").count { it.isNotBlank() } }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_appliance_card_${cat.id}"),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(cat.nameEn, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                            Text(
                                text = "${cat.nameBn} • ${cat.nameHi}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                        }
                        Surface(
                            color = SuccessGreen.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "ID: ${cat.id.uppercase()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SuccessGreen,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Text(
                        text = "${catBrands.size} Brands • $catModels Models • ${catCodes.size} Error Codes • ${catProblems.size} Repair Guides",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyanAccent
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { onQuickAddForCategory(cat.id, "ERROR_CODE") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("admin_add_code_${cat.id}"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, ElectricBluePrimary)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Error Code", color = TextPrimaryWhite, style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(
                            onClick = { onQuickAddForCategory(cat.id, "PROBLEM") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("admin_add_guide_${cat.id}"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, CyanAccent)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Guide", color = TextPrimaryWhite, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminCatalogEditorCard(
    initialEntry: CatalogEntryCloud?,
    defaultCategoryId: String,
    defaultEntryType: String,
    onCancelEdit: () -> Unit,
    onPublish: (CatalogEntryCloud, onDone: () -> Unit) -> Unit
) {
    val editKey = initialEntry?.id ?: "$defaultCategoryId:$defaultEntryType"
    var entryType by remember(editKey) { mutableStateOf(initialEntry?.entryType ?: defaultEntryType) }
    var categoryId by remember(editKey) { mutableStateOf(initialEntry?.categoryId ?: defaultCategoryId) }
    var brandName by remember(editKey) { mutableStateOf(initialEntry?.brandName.orEmpty()) }
    var modelSeries by remember(editKey) { mutableStateOf(initialEntry?.modelSeries.orEmpty()) }
    var code by remember(editKey) { mutableStateOf(initialEntry?.code.orEmpty()) }
    var titleEn by remember(editKey) { mutableStateOf(initialEntry?.titleEn.orEmpty()) }
    var titleBn by remember(editKey) { mutableStateOf(initialEntry?.titleBn.orEmpty()) }
    var titleHi by remember(editKey) { mutableStateOf(initialEntry?.titleHi.orEmpty()) }
    var summaryEn by remember(editKey) { mutableStateOf(initialEntry?.summaryEn.orEmpty()) }
    var summaryBn by remember(editKey) { mutableStateOf(initialEntry?.summaryBn.orEmpty()) }
    var summaryHi by remember(editKey) { mutableStateOf(initialEntry?.summaryHi.orEmpty()) }
    var stepsEn by remember(editKey) { mutableStateOf(initialEntry?.stepsEn.orEmpty()) }
    var stepsBn by remember(editKey) { mutableStateOf(initialEntry?.stepsBn.orEmpty()) }
    var stepsHi by remember(editKey) { mutableStateOf(initialEntry?.stepsHi.orEmpty()) }
    var safetyEn by remember(editKey) {
        mutableStateOf(initialEntry?.safetyWarningEn?.ifBlank { null } ?: "Disconnect mains power before inspection.")
    }
    var verificationStatus by remember(editKey) { mutableStateOf(initialEntry?.verificationStatus ?: "VERIFIED") }
    var published by remember(editKey) { mutableStateOf(initialEntry?.published ?: true) }
    var activeLangTab by remember { mutableStateOf("en") }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CyanAccent,
        unfocusedBorderColor = CardBorderSubtle,
        focusedTextColor = TextPrimaryWhite,
        unfocusedTextColor = TextPrimaryWhite,
        focusedContainerColor = DeepCardSurface,
        unfocusedContainerColor = DeepCardSurface
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SecondaryNavySurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (initialEntry != null) CyanAccent else CardBorderSubtle)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (initialEntry != null) "Edit Entry (Rev ${initialEntry.revision + 1})" else "Publish Multilingual Catalog Entry",
                    style = MaterialTheme.typography.titleSmall,
                    color = CyanAccent
                )
                if (initialEntry != null) {
                    IconButton(onClick = onCancelEdit) {
                        Icon(Icons.Filled.Close, contentDescription = "Cancel edit", tint = TextSecondarySlate)
                    }
                }
            }

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("ERROR_CODE", "PROBLEM", "CATEGORY").forEach { t ->
                    FilterChip(
                        selected = entryType == t,
                        onClick = { if (initialEntry == null) entryType = t },
                        label = { Text(t) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricBluePrimary,
                            selectedLabelColor = TextPrimaryWhite,
                            containerColor = DeepCardSurface,
                            labelColor = TextSecondarySlate
                        )
                    )
                }
            }

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                    FilterChip(
                        selected = categoryId == id,
                        onClick = { if (initialEntry == null) categoryId = id },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricBluePrimary,
                            selectedLabelColor = TextPrimaryWhite,
                            containerColor = DeepCardSurface,
                            labelColor = TextSecondarySlate
                        )
                    )
                }
                FilterChip(
                    selected = verificationStatus == "VERIFIED",
                    onClick = { verificationStatus = if (verificationStatus == "VERIFIED") "UNVERIFIED" else "VERIFIED" },
                    label = { Text(verificationStatus) }
                )
                FilterChip(
                    selected = published,
                    onClick = { published = !published },
                    label = { Text(if (published) "PUBLISHED" else "DRAFT") }
                )
            }

            if (entryType != "CATEGORY") {
                OutlinedTextField(
                    value = brandName,
                    onValueChange = { brandName = it.take(80) },
                    label = { Text("Brand Name (e.g., LG, Samsung, Daikin)") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth().testTag("admin_catalog_brand")
                )
                OutlinedTextField(
                    value = modelSeries,
                    onValueChange = { modelSeries = it.take(100) },
                    label = { Text("Model / Series") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (entryType == "ERROR_CODE") {
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it.uppercase().take(32) },
                    label = { Text("Error Code (e.g., CH05, E1, OE)") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth().testTag("admin_catalog_code")
                )
            }

            // Multilingual Editor Language Switcher: EN / BN / HI
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("en" to "English *", "bn" to "বাংলা (BN)", "hi" to "हिन्दी (HI)").forEach { (codeKey, label) ->
                    FilterChip(
                        selected = activeLangTab == codeKey,
                        onClick = { activeLangTab = codeKey },
                        label = { Text(label) },
                        modifier = Modifier.testTag("admin_lang_tab_$codeKey"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanAccent.copy(alpha = 0.25f),
                            selectedLabelColor = CyanAccent,
                            containerColor = DeepCardSurface,
                            labelColor = TextSecondarySlate
                        )
                    )
                }
            }

            when (activeLangTab) {
                "en" -> {
                    OutlinedTextField(
                        value = titleEn,
                        onValueChange = { titleEn = it.take(180) },
                        label = { Text("Title (English) *") },
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth().testTag("admin_catalog_title_en")
                    )
                    OutlinedTextField(
                        value = summaryEn,
                        onValueChange = { summaryEn = it.take(1200) },
                        label = { Text("Meaning / Symptoms (English) *") },
                        minLines = 2,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth().testTag("admin_catalog_summary_en")
                    )
                    OutlinedTextField(
                        value = stepsEn,
                        onValueChange = { stepsEn = it.take(2000) },
                        label = { Text("Repair Guide / Safe Steps (English)") },
                        minLines = 2,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                "bn" -> {
                    OutlinedTextField(
                        value = titleBn,
                        onValueChange = { titleBn = it.take(220) },
                        label = { Text("Title (বাংলা)") },
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth().testTag("admin_catalog_title_bn")
                    )
                    OutlinedTextField(
                        value = summaryBn,
                        onValueChange = { summaryBn = it.take(1400) },
                        label = { Text("Meaning / Symptoms (বাংলা)") },
                        minLines = 2,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = stepsBn,
                        onValueChange = { stepsBn = it.take(2400) },
                        label = { Text("Repair Guide / Safe Steps (বাংলা)") },
                        minLines = 2,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                else -> {
                    OutlinedTextField(
                        value = titleHi,
                        onValueChange = { titleHi = it.take(220) },
                        label = { Text("Title (हिन्दी)") },
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth().testTag("admin_catalog_title_hi")
                    )
                    OutlinedTextField(
                        value = summaryHi,
                        onValueChange = { summaryHi = it.take(1400) },
                        label = { Text("Meaning / Symptoms (हिन्दी)") },
                        minLines = 2,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = stepsHi,
                        onValueChange = { stepsHi = it.take(2400) },
                        label = { Text("Repair Guide / Safe Steps (हिन्दी)") },
                        minLines = 2,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            OutlinedTextField(
                value = safetyEn,
                onValueChange = { safetyEn = it.take(600) },
                label = { Text("Electrical / Refrigerant Safety Warning") },
                singleLine = true,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (titleEn.isNotBlank()) {
                        onPublish(
                            CatalogEntryCloud(
                                id = initialEntry?.id.orEmpty(),
                                entryType = entryType,
                                categoryId = categoryId,
                                brandName = brandName.trim(),
                                modelSeries = modelSeries.trim(),
                                code = code.trim(),
                                titleEn = titleEn.trim(),
                                titleBn = titleBn.trim(),
                                titleHi = titleHi.trim(),
                                summaryEn = summaryEn.trim().ifBlank { titleEn.trim() },
                                summaryBn = summaryBn.trim(),
                                summaryHi = summaryHi.trim(),
                                stepsEn = stepsEn.trim(),
                                stepsBn = stepsBn.trim(),
                                stepsHi = stepsHi.trim(),
                                safetyWarningEn = safetyEn.trim(),
                                verificationStatus = verificationStatus,
                                published = published,
                                revision = initialEntry?.revision ?: 1L
                            )
                        ) {
                            if (initialEntry == null) {
                                brandName = ""
                                modelSeries = ""
                                code = ""
                                titleEn = ""
                                titleBn = ""
                                titleHi = ""
                                summaryEn = ""
                                summaryBn = ""
                                summaryHi = ""
                                stepsEn = ""
                                stepsBn = ""
                                stepsHi = ""
                            } else {
                                onCancelEdit()
                            }
                        }
                    }
                },
                enabled = titleEn.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_publish_catalog_button"),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (initialEntry != null) "Update Cloud Entry & Sync" else "Publish to Cloud & Offline Sync",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AdminCatalogItemRow(
    entry: CatalogEntryCloud,
    onEdit: () -> Unit,
    onTogglePublished: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_catalog_row_${entry.id}"),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = "[${entry.entryType}] ${entry.brandName} ${entry.code} — ${entry.titleEn}".trim(),
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimaryWhite
                )
                val langs = buildList {
                    add("EN")
                    if (entry.titleBn.isNotBlank()) add("BN")
                    if (entry.titleHi.isNotBlank()) add("HI")
                }.joinToString("/")
                Text(
                    text = "${entry.categoryId.uppercase()} • Rev ${entry.revision} • $langs • ${entry.verificationStatus} • ${if (entry.published) "PUBLISHED" else "DRAFT"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (entry.published) SuccessGreen else WarningAmber
                )
            }
            IconButton(onClick = onEdit, modifier = Modifier.testTag("admin_edit_${entry.id}")) {
                Icon(Icons.Filled.Edit, contentDescription = "Edit", tint = CyanAccent)
            }
            IconButton(onClick = onTogglePublished, modifier = Modifier.testTag("admin_toggle_pub_${entry.id}")) {
                Icon(
                    imageVector = if (entry.published) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                    contentDescription = if (entry.published) "Unpublish" else "Publish",
                    tint = if (entry.published) SuccessGreen else WarningAmber
                )
            }
            IconButton(onClick = onDelete, modifier = Modifier.testTag("admin_delete_${entry.id}")) {
                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = ErrorCrimson)
            }
        }
    }
}
