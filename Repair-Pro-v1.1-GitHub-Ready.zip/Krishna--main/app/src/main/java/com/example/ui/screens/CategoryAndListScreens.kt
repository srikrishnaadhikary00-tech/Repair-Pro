package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.BrandEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.remote.AppSettingCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AdMobBannerSlot
import com.example.ui.components.ErrorCodePill
import com.example.ui.components.GlowingApplianceCard
import com.example.ui.components.VerificationBadge
import com.example.ui.components.categoryDrawableRes
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun CategoriesDirectoryScreen(
    language: AppLanguage,
    categories: List<ApplianceCategoryEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    onSelectCategory: (String) -> Unit,
    onOpenWizard: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = strings.navCategories,
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimaryWhite
            )
            Text(
                text = strings.tagline,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondarySlate
            )
        }
        items(categories, key = { it.id }) { cat ->
            val name = resolveLocalizedText(language, cat.nameEn, cat.nameBn, cat.nameHi).text
            val sub = resolveLocalizedText(language, cat.subtitleEn, cat.subtitleBn, cat.subtitleHi).text
            val codeCount = errorCodes.count { it.categoryId == cat.id }
            val probCount = problems.count { it.categoryId == cat.id }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                GlowingApplianceCard(
                    categoryId = cat.id,
                    title = name,
                    subtitle = sub,
                    badgeText = "$codeCount Error Codes • $probCount Guides",
                    onClick = { onSelectCategory(cat.id) }
                )
                Button(
                    onClick = { onOpenWizard(cat.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_wizard_${cat.id}"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElevatedCardSurface,
                        contentColor = CyanAccent
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoFixHigh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("${strings.wizardTitle}: $name", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun CategoryDetailBrandScreen(
    categoryId: String,
    language: AppLanguage,
    category: ApplianceCategoryEntity?,
    brands: List<BrandEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    adMobConfig: AppSettingCloud,
    isOnline: Boolean,
    adConsentGranted: Boolean,
    onBack: () -> Unit,
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit,
    onOpenWizard: (String) -> Unit,
    onOpenScanner: () -> Unit
) {
    val strings = StringsProvider.get(language)
    val categoryTitle = if (category != null) {
        resolveLocalizedText(language, category.nameEn, category.nameBn, category.nameHi).text
    } else categoryId.uppercase()

    var selectedBrandId by remember { mutableStateOf<String?>(null) }
    var selectedModel by remember { mutableStateOf<String?>(null) }
    var activeTab by remember { mutableIntStateOf(0) } // 0 = Brands & Models, 1 = Common Problems, 2 = Error Codes

    val selectedBrand = brands.firstOrNull { it.id == selectedBrandId }
    val filteredCodes = remember(errorCodes, selectedBrandId, selectedModel) {
        errorCodes.filter { code ->
            (selectedBrandId == null || code.brandId == selectedBrandId || code.brandName.equals(selectedBrand?.name, ignoreCase = true)) &&
                (selectedModel == null || code.modelSeries.contains(selectedModel!!.substringBefore(" "), ignoreCase = true) || true)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top App Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("category_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryWhite
                        )
                    }
                    Text(
                        text = categoryTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimaryWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onOpenScanner, modifier = Modifier.testTag("category_scanner_button")) {
                    Icon(
                        imageVector = Icons.Filled.CameraAlt,
                        contentDescription = strings.cameraScan,
                        tint = CyanAccent
                    )
                }
            }
        }

        // Category Appliance Banner Artwork
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
                    .clip(RoundedCornerShape(18.dp))
            ) {
                Image(
                    painter = painterResource(id = categoryDrawableRes(categoryId)),
                    contentDescription = categoryTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onOpenWizard(categoryId) }
                        .testTag("category_wizard_cta"),
                    color = ElectricBluePrimary,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoFixHigh,
                            contentDescription = null,
                            tint = TextPrimaryWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = strings.wizardTitle,
                            style = MaterialTheme.typography.labelMedium,
                            color = TextPrimaryWhite
                        )
                    }
                }
            }
        }

        // Segmented Tabs: Brands | Common Problems | Error Codes (Matches Reference Screens 3 & 4)
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = DeepCardSurface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CardBorderSubtle)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val tabs = listOf(
                        strings.selectBrand.substringAfter(" ").ifBlank { "Brands" },
                        strings.commonProblems,
                        strings.errorCodes
                    )
                    tabs.forEachIndexed { idx, title ->
                        val selected = activeTab == idx
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { activeTab = idx }
                                .testTag("category_tab_$idx"),
                            color = if (selected) ElectricBluePrimary else Color.Transparent,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) TextPrimaryWhite else TextSecondarySlate,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .padding(vertical = 10.dp, horizontal = 6.dp)
                                    .align(Alignment.CenterVertically)
                            )
                        }
                    }
                }
            }
        }

        // Quick Brand Filter Chips
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedBrandId == null,
                    onClick = {
                        selectedBrandId = null
                        selectedModel = null
                    },
                    label = { Text(strings.allBrands) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricBluePrimary,
                        selectedLabelColor = TextPrimaryWhite,
                        containerColor = SecondaryNavySurface,
                        labelColor = TextSecondarySlate
                    )
                )
                brands.forEach { brand ->
                    FilterChip(
                        selected = selectedBrandId == brand.id,
                        onClick = {
                            selectedBrandId = brand.id
                            selectedModel = null
                        },
                        label = { Text(brand.name) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricBluePrimary,
                            selectedLabelColor = TextPrimaryWhite,
                            containerColor = SecondaryNavySurface,
                            labelColor = TextSecondarySlate
                        )
                    )
                }
            }
        }

        // Model / Series selector when a specific brand is selected
        if (selectedBrand != null) {
            item {
                val models = selectedBrand.modelsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "${selectedBrand.name} — ${strings.selectModel}",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyanAccent
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        models.forEach { model ->
                            val isSelected = selectedModel == model
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        selectedModel = if (isSelected) null else model
                                        activeTab = 2
                                    },
                                color = if (isSelected) CyanAccent.copy(alpha = 0.25f) else ElevatedCardSurface,
                                border = BorderStroke(1.dp, if (isSelected) CyanAccent else CardBorderSubtle),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = model,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextPrimaryWhite,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        when (activeTab) {
            0 -> {
                items(brands, key = { it.id }) { brand ->
                    val codeCount = errorCodes.count {
                        it.brandId == brand.id || it.brandName.equals(brand.name, ignoreCase = true)
                    }
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                selectedBrandId = brand.id
                                activeTab = 2
                            }
                            .testTag("brand_row_${brand.id}"),
                        color = SecondaryNavySurface,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(
                            1.dp,
                            if (selectedBrandId == brand.id) CyanAccent else CardBorderSubtle
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(ElectricBluePrimary.copy(alpha = 0.22f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = brand.name.take(2).uppercase(),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = brand.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimaryWhite
                                )
                                Text(
                                    text = brand.modelsCsv.replace(",", " • "),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (codeCount > 0) {
                                Surface(
                                    color = SuccessGreen.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "$codeCount Codes",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SuccessGreen,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = TextSecondarySlate
                            )
                        }
                    }
                }
            }
            1 -> {
                items(problems, key = { it.id }) { prob ->
                    val title = resolveLocalizedText(language, prob.titleEn, prob.titleBn, prob.titleHi).text
                    val symptoms = resolveLocalizedText(language, prob.symptomsEn, prob.symptomsBn, prob.symptomsHi).text
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onOpenProblemDetail(prob.id) }
                            .testTag("problem_row_${prob.id}"),
                        color = SecondaryNavySurface,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CardBorderSubtle)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(problemIconTint(prob.iconKey).copy(alpha = 0.18f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = problemIconForKey(prob.iconKey),
                                    contentDescription = null,
                                    tint = problemIconTint(prob.iconKey),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimaryWhite
                                )
                                Text(
                                    text = symptoms.lineSequence().firstOrNull().orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = CyanAccent
                            )
                        }
                    }
                }
            }
            2 -> {
                if (filteredCodes.isEmpty()) {
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = SecondaryNavySurface,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, CardBorderSubtle)
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "No brand-specific verified codes cached for this filter yet.",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimaryWhite
                                )
                                Text(
                                    text = "Tap 'All' to view verified codes for this appliance category, or report an undocumented code from Settings.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate
                                )
                            }
                        }
                    }
                } else {
                    items(filteredCodes, key = { it.id }) { codeItem ->
                        val title = resolveLocalizedText(language, codeItem.titleEn, codeItem.titleBn, codeItem.titleHi).text
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onOpenErrorDetail(codeItem.id) }
                                .testTag("error_row_${codeItem.id}"),
                            color = SecondaryNavySurface,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, CardBorderSubtle)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                ErrorCodePill(code = codeItem.code)
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "${codeItem.brandName} — $title",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimaryWhite,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = codeItem.modelSeries,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondarySlate,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    VerificationBadge(
                                        status = codeItem.verificationStatus,
                                        verifiedLabel = strings.verifiedBadge,
                                        unverifiedLabel = strings.unverifiedBadge
                                    )
                                }
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = null,
                                    tint = CyanAccent
                                )
                            }
                        }
                    }
                }
            }
        }

        // Category-Specific AdMob Slot
        item {
            AdMobBannerSlot(
                config = adMobConfig,
                categoryId = categoryId,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "category_$categoryId"
            )
        }
    }
}

private fun problemIconForKey(key: String): ImageVector = when (key) {
    "ac_cooling", "fridge_cool", "ice" -> Icons.Filled.AcUnit
    "water_drop", "water_inlet" -> Icons.Filled.WaterDrop
    "power_off" -> Icons.Filled.PowerSettingsNew
    "vibration" -> Icons.Filled.Vibration
    else -> Icons.Filled.Build
}

private fun problemIconTint(key: String): Color = when (key) {
    "ac_cooling", "fridge_cool", "ice" -> CyanAccent
    "water_drop", "water_inlet" -> ElectricBluePrimary
    "power_off" -> ErrorCrimson
    "vibration" -> WarningAmber
    else -> SuccessGreen
}
