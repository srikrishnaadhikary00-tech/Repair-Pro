package com.example.scanner

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

enum class ScanConfidence {
    HIGH,
    MEDIUM,
    LOW
}

data class OcrScanResult(
    val rawText: String,
    val detectedCodes: List<String>,
    val primaryCode: String?,
    val confidence: ScanConfidence
)

object ErrorCodeOcrEngine {

    private val knownErrorCodePattern = Regex(
        pattern = "\\b(CH\\s?\\d{2}|ER\\s?[A-Z0-9]{1,3}|[EUFHPCLAd][0-9]{1,3}|[0-9][EC]|OE|IE|UE|dE|LE|PE|FE|CL|CF|dr|E1|E2|E3|E4|E5|E6|E18|U4|22E)\\b",
        option = RegexOption.IGNORE_CASE
    )

    suspend fun scanFromUri(context: Context, uri: Uri): OcrScanResult {
        val image = InputImage.fromFilePath(context, uri)
        return runRecognizer(image)
    }

    suspend fun scanFromBitmap(bitmap: Bitmap): OcrScanResult {
        val image = InputImage.fromBitmap(bitmap, 0)
        return runRecognizer(image)
    }

    private suspend fun runRecognizer(image: InputImage): OcrScanResult {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        return try {
            val visionText = recognizer.process(image).await()
            val fullText = visionText.text.trim()
            parseErrorCodes(fullText)
        } finally {
            recognizer.close()
        }
    }

    fun parseErrorCodes(rawText: String): OcrScanResult {
        if (rawText.isBlank()) {
            return OcrScanResult(
                rawText = "",
                detectedCodes = emptyList(),
                primaryCode = null,
                confidence = ScanConfidence.LOW
            )
        }
        val normalized = rawText.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        val matches = knownErrorCodePattern.findAll(normalized)
            .map { it.value.trim().uppercase() }
            .distinct()
            .toList()

        return when {
            matches.isNotEmpty() -> OcrScanResult(
                rawText = normalized,
                detectedCodes = matches,
                primaryCode = matches.first(),
                confidence = if (matches.size == 1 && normalized.length <= 20) ScanConfidence.HIGH else ScanConfidence.MEDIUM
            )
            else -> {
                // Fallback: look for short alphanumeric LED tokens (2-5 chars) without fabricating diagnosis
                val shortToken = normalized.split(" ")
                    .firstOrNull { token -> token.length in 2..5 && token.any { it.isDigit() } && token.any { it.isLetter() } }
                    ?.uppercase()
                OcrScanResult(
                    rawText = normalized,
                    detectedCodes = listOfNotNull(shortToken),
                    primaryCode = shortToken,
                    confidence = ScanConfidence.LOW
                )
            }
        }
    }
}
