package com.example.i18n

enum class AppLanguage(
    val code: String,
    val nativeLabel: String,
    val englishName: String
) {
    EN("en", "English", "English"),
    BN("bn", "বাংলা", "Bengali"),
    HI("hi", "हिन्दी", "Hindi");

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: EN
    }
}

data class LocalizedResult(
    val text: String,
    val usedFallback: Boolean
)

fun resolveLocalizedText(
    language: AppLanguage,
    en: String,
    bn: String,
    hi: String
): LocalizedResult {
    return when (language) {
        AppLanguage.EN -> LocalizedResult(en, false)
        AppLanguage.BN -> if (bn.isNotBlank()) LocalizedResult(bn, false) else LocalizedResult(en, true)
        AppLanguage.HI -> if (hi.isNotBlank()) LocalizedResult(hi, false) else LocalizedResult(en, true)
    }
}
