package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import com.example.data.local.ErrorCodeEntity
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.scanner.ErrorCodeOcrEngine
import com.example.scanner.OcrScanResult
import com.example.scanner.ScanConfidence
import com.example.ui.components.ErrorCodePill
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.launch

@Composable
fun CameraScannerScreen(
    language: AppLanguage,
    allErrorCodes: List<ErrorCodeEntity>,
    onBack: () -> Unit,
    onOpenErrorDetail: (String) -> Unit,
    onManualSearchFallback: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var cameraActive by remember { mutableStateOf(false) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isScanning by remember { mutableStateOf(false) }
    var scanResult by remember { mutableStateOf<OcrScanResult?>(null) }
    var manualCodeInput by remember { mutableStateOf("") }
    var selectedBrandFilter by remember { mutableStateOf("All") }
    var scanErrorMsg by remember { mutableStateOf<String?>(null) }
    var imageCaptureRef by remember { mutableStateOf<ImageCapture?>(null) }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (granted) {
            cameraActive = true
            selectedImageUri = null
        } else {
            scanErrorMsg = "Camera permission denied. You can still select a display photo from Gallery or enter the code manually."
        }
    }

    // Zero-permission Android Photo Picker (Google Play Policy Compliant)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            cameraActive = false
            scanErrorMsg = null
            isScanning = true
            scope.launch {
                try {
                    val result = ErrorCodeOcrEngine.scanFromUri(context, uri)
                    scanResult = result
                    if (!result.primaryCode.isNullOrBlank()) {
                        manualCodeInput = result.primaryCode
                    }
                } catch (e: Exception) {
                    Log.w("Scanner", "OCR scan failed", e)
                    scanErrorMsg = "Could not analyze image. Please enter the error code manually below."
                } finally {
                    isScanning = false
                }
            }
        }
    }

    val availableBrands = remember(allErrorCodes) {
        listOf("All") + allErrorCodes.map { it.brandName }.distinct().sorted()
    }

    val queryCode = manualCodeInput.trim()
    val matchingCodes = remember(queryCode, selectedBrandFilter, allErrorCodes) {
        if (queryCode.isBlank()) emptyList()
        else {
            allErrorCodes.filter { item ->
                val matchesCode = item.code.equals(queryCode, ignoreCase = true) ||
                    item.code.replace(" ", "").contains(queryCode.replace(" ", ""), ignoreCase = true)
                val matchesBrand = selectedBrandFilter == "All" ||
                    item.brandName.equals(selectedBrandFilter, ignoreCase = true)
                matchesCode && matchesBrand
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("scanner_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Text(
                    text = strings.scanTitle,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimaryWhite
                )
            }
        }

        // CameraX Live Viewfinder or Selected Photo Preview (Matches Reference Screen 6)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(DeepCardSurface)
                    .border(2.dp, CyanAccent.copy(alpha = 0.7f), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                when {
                    cameraActive && hasCameraPermission -> {
                        val previewView = remember { PreviewView(context) }
                        DisposableEffect(lifecycleOwner) {
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                            val executor = ContextCompat.getMainExecutor(context)
                            cameraProviderFuture.addListener({
                                try {
                                    val cameraProvider = cameraProviderFuture.get()
                                    val preview = Preview.Builder().build().also {
                                        it.surfaceProvider = previewView.surfaceProvider
                                    }
                                    val capture = ImageCapture.Builder().build()
                                    imageCaptureRef = capture
                                    cameraProvider.unbindAll()
                                    cameraProvider.bindToLifecycle(
                                        lifecycleOwner,
                                        CameraSelector.DEFAULT_BACK_CAMERA,
                                        preview,
                                        capture
                                    )
                                } catch (e: Exception) {
                                    Log.e("Scanner", "CameraX bind failed", e)
                                    scanErrorMsg = "Camera unavailable on this device. Use Gallery or manual entry."
                                    cameraActive = false
                                }
                            }, executor)
                            onDispose {
                                try {
                                    ProcessCameraProvider.getInstance(context).get().unbindAll()
                                } catch (_: Exception) {
                                }
                            }
                        }
                        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                        // Glowing target reticle
                        Box(
                            modifier = Modifier
                                .size(width = 180.dp, height = 90.dp)
                                .border(2.dp, CyanAccent, RoundedCornerShape(14.dp))
                        )
                    }
                    selectedImageUri != null -> {
                        AsyncImage(
                            model = selectedImageUri,
                            contentDescription = "Selected appliance display photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    else -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = 150.dp, height = 74.dp)
                                    .border(2.dp, CyanAccent, RoundedCornerShape(14.dp))
                                    .background(SecondaryNavySurface),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "E1 / CH05",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = CyanAccent
                                )
                            }
                            Text(
                                text = strings.scanSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                if (isScanning) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DeepCardSurface.copy(alpha = 0.72f)),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = CyanAccent)
                    }
                }
            }
        }

        // Capture Photo / Activate Camera + Select from Gallery buttons
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        scanErrorMsg = null
                        if (!hasCameraPermission) {
                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                        } else if (!cameraActive) {
                            cameraActive = true
                            selectedImageUri = null
                        } else {
                            val capture = imageCaptureRef
                            if (capture != null) {
                                isScanning = true
                                capture.takePicture(
                                    ContextCompat.getMainExecutor(context),
                                    object : ImageCapture.OnImageCapturedCallback() {
                                        override fun onCaptureSuccess(image: ImageProxy) {
                                            val bmp: Bitmap = image.toBitmap()
                                            image.close()
                                            cameraActive = false
                                            scope.launch {
                                                try {
                                                    val res = ErrorCodeOcrEngine.scanFromBitmap(bmp)
                                                    scanResult = res
                                                    if (!res.primaryCode.isNullOrBlank()) {
                                                        manualCodeInput = res.primaryCode
                                                    }
                                                } catch (e: Exception) {
                                                    scanErrorMsg = "OCR could not read image. Type the code manually."
                                                } finally {
                                                    isScanning = false
                                                }
                                            }
                                        }

                                        override fun onError(exception: ImageCaptureException) {
                                            isScanning = false
                                            scanErrorMsg = "Capture failed: ${exception.localizedMessage}"
                                        }
                                    }
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("scanner_capture_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                ) {
                    Icon(Icons.Filled.CameraAlt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (cameraActive) "Scan Display Now" else strings.capturePhoto,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("scanner_gallery_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CardBorderSubtle),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = SecondaryNavySurface,
                        contentColor = TextPrimaryWhite
                    )
                ) {
                    Icon(Icons.Filled.PhotoLibrary, contentDescription = null, tint = CyanAccent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.selectFromGallery)
                }
            }
        }

        // OCR Confidence / Honest Unrecognized Feedback
        if (scanErrorMsg != null) {
            item {
                Surface(
                    color = WarningAmber.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = scanErrorMsg!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = WarningAmber,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        if (scanResult != null) {
            item {
                val res = scanResult!!
                val reliable = res.confidence != ScanConfidence.LOW && !res.primaryCode.isNullOrBlank()
                val tone = if (reliable) SuccessGreen else WarningAmber
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = tone.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, tone.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = if (reliable) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                            contentDescription = null,
                            tint = tone
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = if (reliable) {
                                    "${strings.scanDetectedCode}: ${res.primaryCode} (${res.confidence.name})"
                                } else {
                                    strings.scanNoMatch
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimaryWhite
                            )
                            if (res.rawText.isNotBlank()) {
                                Text(
                                    text = "OCR Raw Text: ${res.rawText.take(90)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondarySlate
                                )
                            }
                        }
                    }
                }
            }
        }

        // Manual Code Entry & Correction Field
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = strings.orText,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondarySlate,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = manualCodeInput,
                    onValueChange = { manualCodeInput = it.uppercase().take(16) },
                    label = { Text(strings.enterCodeManually) },
                    leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null, tint = CyanAccent) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("scanner_manual_code_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        unfocusedBorderColor = CardBorderSubtle,
                        focusedTextColor = TextPrimaryWhite,
                        unfocusedTextColor = TextPrimaryWhite,
                        focusedContainerColor = SecondaryNavySurface,
                        unfocusedContainerColor = SecondaryNavySurface
                    )
                )

                // Brand filter chips for disambiguating common codes like E1 or dE
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    availableBrands.take(5).forEach { brand ->
                        FilterChip(
                            selected = selectedBrandFilter == brand,
                            onClick = { selectedBrandFilter = brand },
                            label = { Text(brand, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricBluePrimary,
                                selectedLabelColor = TextPrimaryWhite,
                                containerColor = SecondaryNavySurface,
                                labelColor = TextSecondarySlate
                            )
                        )
                    }
                }
            }
        }

        // Matching Scan Results
        if (queryCode.isNotBlank()) {
            if (matchingCodes.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = ElevatedCardSurface,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CardBorderSubtle)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "No verified match for \"$queryCode\" yet.",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite
                            )
                            Text(
                                text = "We do not fabricate error-code meanings. Try searching by symptoms or report this code to our technicians.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                            Button(
                                onClick = { onManualSearchFallback(queryCode) },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                            ) {
                                Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.searchButton)
                            }
                        }
                    }
                }
            } else {
                items(matchingCodes, key = { it.id }) { match ->
                    val title = resolveLocalizedText(language, match.titleEn, match.titleBn, match.titleHi).text
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onOpenErrorDetail(match.id) }
                            .testTag("scan_match_${match.id}"),
                        color = SecondaryNavySurface,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.55f))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            ErrorCodePill(code = match.code)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${match.brandName} • $title",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimaryWhite
                                )
                                Text(
                                    text = match.modelSeries,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
