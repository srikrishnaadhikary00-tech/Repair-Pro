package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Repair Pro Premium Dark Black & Electric Blue Palette
val DeepNavyBackground = Color(0xFF080D19)
val SecondaryNavySurface = Color(0xFF111C30)
val ElevatedCardSurface = Color(0xFF16243D)
val DeepCardSurface = Color(0xFF0D1628)
val ElectricBluePrimary = Color(0xFF008CFF)
val CyanAccent = Color(0xFF00C8FF)
val CyanGlowSoft = Color(0x3300C8FF)
val BlueGlowSoft = Color(0x33008CFF)
val TextPrimaryWhite = Color(0xFFFFFFFF)
val TextSecondarySlate = Color(0xFFA9B8CC)
val TextMutedSteel = Color(0xFF6E829E)
val SuccessGreen = Color(0xFF16C784)
val WarningAmber = Color(0xFFFFB020)
val ErrorCrimson = Color(0xFFFF4757)
val CardBorderSubtle = Color(0xFF1F3454)
val CardBorderCyan = Color(0xFF00A8E8)

val PrimaryBlueGradient = Brush.horizontalGradient(
    colors = listOf(ElectricBluePrimary, CyanAccent)
)

val CyanBorderGradient = Brush.linearGradient(
    colors = listOf(CyanAccent.copy(alpha = 0.75f), ElectricBluePrimary.copy(alpha = 0.35f))
)

val DarkScreenGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF0A1224), DeepNavyBackground, Color(0xFF060A14))
)

val CardSurfaceGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF13223B), Color(0xFF0E182B))
)
