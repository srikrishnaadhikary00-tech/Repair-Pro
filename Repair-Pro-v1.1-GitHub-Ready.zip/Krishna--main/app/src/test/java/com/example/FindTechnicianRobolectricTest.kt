package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import com.example.data.remote.TechnicianCloud
import com.example.i18n.AppLanguage
import com.example.ui.UiState
import com.example.ui.screens.FindTechnicianScreen
import com.example.ui.theme.RepairProTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h2600dp")
class FindTechnicianRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    private val sampleTechnicians = listOf(
        TechnicianCloud(
            id = "tech_1",
            technicianId = "tech_1",
            fullName = "Rahul Das",
            mobileNumber = "+91 98300 11223",
            fullAddress = "14B Lake Road, Near Metro Gate 2",
            state = "West Bengal",
            district = "Kolkata",
            cityArea = "Salt Lake",
            pinCode = "700091",
            serviceCategories = listOf("AC", "Refrigerator"),
            experience = "8 Years",
            status = "ACTIVE"
        ),
        TechnicianCloud(
            id = "tech_2",
            technicianId = "tech_2",
            fullName = "Amit Sharma",
            mobileNumber = "+91 98765 44556",
            fullAddress = "22 Station Road, Howrah Maidan",
            state = "West Bengal",
            district = "Howrah",
            cityArea = "Shibpur",
            pinCode = "711102",
            serviceCategories = listOf("Washing Machine"),
            experience = "5 Years",
            status = "ACTIVE"
        ),
        TechnicianCloud(
            id = "tech_3",
            technicianId = "tech_3",
            fullName = "Hidden Inactive Tech",
            mobileNumber = "+91 90000 00001",
            fullAddress = "Inactive Street",
            state = "West Bengal",
            district = "Kolkata",
            cityArea = "Behala",
            pinCode = "700034",
            serviceCategories = listOf("AC"),
            status = "INACTIVE"
        )
    )

    @Test
    fun `displays only active technicians filters by search category district and triggers dialer callback`() {
        var dialedNumber: String? = null

        composeRule.setContent {
            RepairProTheme {
                FindTechnicianScreen(
                    language = AppLanguage.EN,
                    techniciansState = UiState.Success(sampleTechnicians),
                    isOnline = true,
                    onRetry = {},
                    onShowMessage = {},
                    onCallTechnician = { dialedNumber = it }
                )
            }
        }
        composeRule.waitForIdle()

        // Active technicians appear; inactive technician is strictly hidden
        composeRule.onNodeWithTag("technician_card_tech_1").assertIsDisplayed()
        composeRule.onNodeWithTag("technician_card_tech_2").assertIsDisplayed()
        composeRule.onNodeWithTag("technician_card_tech_3").assertDoesNotExist()

        // Tap Call Now on tech_1 -> opens dialer with sanitized phone number
        composeRule.onNodeWithTag("call_tech_tech_1").performClick()
        assertEquals("+919830011223", dialedNumber)

        // Filter by Washing Machine category -> only tech_2 visible
        composeRule.onNodeWithTag("tech_cat_chip_washing_machine").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("technician_card_tech_2").assertIsDisplayed()
        composeRule.onNodeWithTag("technician_card_tech_1").assertDoesNotExist()

        // Reset category to All, filter by Kolkata district -> only tech_1 visible
        composeRule.onNodeWithTag("tech_cat_chip_all").performScrollTo().performClick()
        composeRule.onNodeWithTag("tech_district_chip_kolkata").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("technician_card_tech_1").assertIsDisplayed()
        composeRule.onNodeWithTag("technician_card_tech_2").assertDoesNotExist()

        // Reset district to All, search by area "Shibpur" -> only tech_2 visible
        composeRule.onNodeWithTag("tech_district_chip_all").performScrollTo().performClick()
        composeRule.onNodeWithTag("tech_search_input").performTextInput("Shibpur")
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("technician_card_tech_2").assertIsDisplayed()
        composeRule.onNodeWithTag("technician_card_tech_1").assertDoesNotExist()

        // Search with no match -> friendly empty state + Clear Filters restores list
        composeRule.onNodeWithTag("tech_search_input").performTextClearance()
        composeRule.onNodeWithTag("tech_search_input").performTextInput("UnknownDistrictXYZ")
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("tech_empty_state").assertIsDisplayed()
        composeRule.onNodeWithTag("tech_clear_filters_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("technician_card_tech_1").assertIsDisplayed()
        composeRule.onNodeWithTag("technician_card_tech_2").assertIsDisplayed()
    }

    @Test
    fun `shows loading indicator and error retry state cleanly`() {
        var retried = false
        composeRule.setContent {
            RepairProTheme {
                FindTechnicianScreen(
                    language = AppLanguage.EN,
                    techniciansState = UiState.Error("Network unavailable"),
                    isOnline = false,
                    onRetry = { retried = true },
                    onShowMessage = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("tech_error_card").assertIsDisplayed()
        composeRule.onNodeWithTag("tech_retry_button").performClick()
        assertTrue(retried)
    }

    @Test
    fun `renders bengali and hindi localization for find technician screen`() {
        composeRule.setContent {
            RepairProTheme {
                FindTechnicianScreen(
                    language = AppLanguage.BN,
                    techniciansState = UiState.Loading,
                    isOnline = true,
                    onRetry = {},
                    onShowMessage = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("টেকনিশিয়ান খুঁজুন").assertIsDisplayed()
        composeRule.onNodeWithTag("tech_loading_indicator").assertIsDisplayed()
    }
}
