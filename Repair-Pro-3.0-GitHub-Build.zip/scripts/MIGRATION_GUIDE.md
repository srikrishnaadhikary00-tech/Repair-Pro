# Repair Pro — Firestore to Supabase Migration Guide

This guide migrates existing live data from Firestore (`ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8`) into Supabase (`xuakzzjtcgcvudkgxpbd`) while keeping **Firebase Auth** (UIDs, Google Sign-In) and **FCM Push Notifications** completely intact.

## Step 1: Apply SQL Migrations in Supabase
1. Open **Supabase Dashboard -> SQL Editor** on project `xuakzzjtcgcvudkgxpbd`.
2. Ensure prior base files (`supabase/schema.sql`, `20261126_phase2_additive_migration.sql`, `20261127_final_security_and_admin_migration.sql`) are applied.
3. Run `supabase/migrations/20261128_complete_supabase_migration.sql`.

## Step 2: Set Environment Variables & Run Dry-Run Verification
```bash
export FIREBASE_SERVICE_ACCOUNT_PATH=./firebase-service-account.json
export SUPABASE_URL=https://xuakzzjtcgcvudkgxpbd.supabase.co
export SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

node scripts/migrate-firestore-to-supabase.mjs --dry-run
```

## Step 3: Run Live Migration
```bash
node scripts/migrate-firestore-to-supabase.mjs
```
To skip copying legacy Storage objects and migrate only structured records:
```bash
node scripts/migrate-firestore-to-supabase.mjs --skip-storage
```

## Step 4: Verify Row Counts
Re-run in verify-only mode to compare Firestore counts vs Supabase totals:
```bash
node scripts/migrate-firestore-to-supabase.mjs --verify-only
```

## Step 5: Deploy Updated Edge Functions & Hosting PHP API
Deploy all 5 functions in `supabase/functions/`:
- `admin-user-management`
- `ai-repair-assistant`
- `hosting-proxy-upload`
- `send-push-notification`
- `send-fcm-v1`

Required Edge Function Secrets:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `FIREBASE_SERVICE_ACCOUNT_JSON`
- `FIREBASE_WEB_API_KEY`
- AI keys (`GEMINI_API_KEY`, `GROQ_API_KEY`, `OPENROUTER_API_KEY`) or save via **Web Admin -> Repair Pro AI -> API Key Vault**.

## Step 6: Third-Party Auth in Supabase
In **Supabase Dashboard -> Authentication -> Third-Party Auth -> Firebase**:
- Ensure Firebase Project ID `gen-lang-client-0218221723` is enabled so Supabase PostgREST & Storage RLS policies verify Firebase ID tokens automatically via `public.firebase_uid()`.
