#!/usr/bin/env node
/**
 * Repair Pro — Idempotent Firestore & Firebase Storage -> Supabase Migration Tool
 * Preserves Firebase Project: gen-lang-client-0218221723 (Auth & FCM ONLY after migration)
 * Legacy Firestore DB:      ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8
 * Target Supabase Project:  xuakzzjtcgcvudkgxpbd
 *
 * Usage:
 *   export FIREBASE_SERVICE_ACCOUNT_PATH=./service-account.json
 *   export SUPABASE_URL=https://xuakzzjtcgcvudkgxpbd.supabase.co
 *   export SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
 *   node scripts/migrate-firestore-to-supabase.mjs --dry-run
 *   node scripts/migrate-firestore-to-supabase.mjs
 *   node scripts/migrate-firestore-to-supabase.mjs --skip-storage
 */

import fs from "node:fs";
import crypto from "node:crypto";

const PROJECT_ID = "gen-lang-client-0218221723";
const FIRESTORE_DB_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
const DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";

const args = new Set(process.argv.slice(2));
const DRY_RUN = args.has("--dry-run");
const SKIP_STORAGE = args.has("--skip-storage");
const VERIFY_ONLY = args.has("--verify-only");

function loadServiceAccount() {
  const inline = process.env.FIREBASE_SERVICE_ACCOUNT_JSON || "";
  if (inline.trim()) return JSON.parse(inline);
  const filePath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH || "";
  if (filePath.trim() && fs.existsSync(filePath)) {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  }
  throw new Error("Set FIREBASE_SERVICE_ACCOUNT_JSON or FIREBASE_SERVICE_ACCOUNT_PATH.");
}

function getSupabaseEnv() {
  const url = (process.env.SUPABASE_URL || DEFAULT_SUPABASE_URL).replace(/\/+$/, "");
  const serviceKey = (process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
  if (!serviceKey && !DRY_RUN) {
    throw new Error("Set SUPABASE_SERVICE_ROLE_KEY environment variable.");
  }
  return { url, serviceKey };
}

function base64Url(input) {
  return Buffer.from(input).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function getGoogleAccessToken(sa) {
  const now = Math.floor(Date.now() / 1000);
  const header = base64Url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claimSet = base64Url(JSON.stringify({
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/datastore https://www.googleapis.com/auth/devstorage.read_only",
    aud: sa.token_uri || "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600
  }));
  const signingInput = `${header}.${claimSet}`;
  const signer = crypto.createSign("RSA-SHA256");
  signer.update(signingInput);
  const signature = base64Url(signer.sign(sa.private_key));
  const resp = await fetch(sa.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: `${signingInput}.${signature}`
    })
  });
  const data = await resp.json();
  if (!resp.ok || !data.access_token) {
    throw new Error(`Google OAuth failed: ${data.error_description || data.error || resp.status}`);
  }
  return data.access_token;
}

function decodeFirestoreValue(val) {
  if (!val || typeof val !== "object") return null;
  if ("stringValue" in val) return String(val.stringValue);
  if ("booleanValue" in val) return Boolean(val.booleanValue);
  if ("integerValue" in val) return Number(val.integerValue);
  if ("doubleValue" in val) return Number(val.doubleValue);
  if ("timestampValue" in val) return String(val.timestampValue);
  if ("nullValue" in val) return null;
  if ("arrayValue" in val) {
    const arr = Array.isArray(val.arrayValue?.values) ? val.arrayValue.values : [];
    return arr.map(decodeFirestoreValue);
  }
  if ("mapValue" in val) {
    return decodeFirestoreFields(val.mapValue?.fields || {});
  }
  return null;
}

function decodeFirestoreFields(fields) {
  const out = {};
  for (const [k, v] of Object.entries(fields || {})) {
    out[k] = decodeFirestoreValue(v);
  }
  return out;
}

async function listFirestoreCollection(collectionPath, googleToken) {
  const docs = [];
  let pageToken = "";
  do {
    const qp = new URLSearchParams({ pageSize: "250" });
    if (pageToken) qp.set("pageToken", pageToken);
    const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DB_ID}/documents/${collectionPath}?${qp}`;
    const resp = await fetch(url, { headers: { Authorization: `Bearer ${googleToken}` } });
    if (resp.status === 404) break;
    if (!resp.ok) {
      const txt = await resp.text().catch(() => "");
      throw new Error(`Firestore read failed for ${collectionPath} (HTTP ${resp.status}): ${txt.slice(0, 180)}`);
    }
    const json = await resp.json();
    for (const d of json.documents || []) {
      const docId = String(d.name || "").split("/").pop() || "";
      docs.push({
        id: docId,
        name: d.name,
        data: decodeFirestoreFields(d.fields || {})
      });
    }
    pageToken = json.nextPageToken || "";
  } while (pageToken);
  return docs;
}

async function upsertSupabaseBatch(table, onConflict, rows, supabaseEnv) {
  if (rows.length === 0) return 0;
  if (DRY_RUN || VERIFY_ONLY) return rows.length;
  let inserted = 0;
  for (let i = 0; i < rows.length; i += 100) {
    const chunk = rows.slice(i, i + 100);
    const resp = await fetch(`${supabaseEnv.url}/rest/v1/${table}?on_conflict=${encodeURIComponent(onConflict)}`, {
      method: "POST",
      headers: {
        apikey: supabaseEnv.serviceKey,
        Authorization: `Bearer ${supabaseEnv.serviceKey}`,
        "Content-Type": "application/json",
        Prefer: "resolution=merge-duplicates,return=minimal"
      },
      body: JSON.stringify(chunk)
    });
    if (!resp.ok) {
      const txt = await resp.text().catch(() => "");
      throw new Error(`Supabase upsert into ${table} failed (HTTP ${resp.status}): ${txt.slice(0, 260)}`);
    }
    inserted += chunk.length;
  }
  return inserted;
}

async function countSupabaseRows(table, supabaseEnv) {
  if (!supabaseEnv.serviceKey) return -1;
  const resp = await fetch(`${supabaseEnv.url}/rest/v1/${table}?select=*&limit=1`, {
    method: "HEAD",
    headers: {
      apikey: supabaseEnv.serviceKey,
      Authorization: `Bearer ${supabaseEnv.serviceKey}`,
      Prefer: "count=exact"
    }
  });
  const cr = resp.headers.get("content-range") || "";
  const total = Number(cr.split("/")[1]);
  return Number.isFinite(total) ? total : -1;
}

function asIso(value, fallback = new Date().toISOString()) {
  if (!value) return fallback;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? fallback : d.toISOString();
}

function asStrArray(val) {
  return Array.isArray(val) ? val.map((v) => String(v || "").trim()).filter(Boolean) : [];
}

async function migrateLegacyStorageUrlIfNeeded(rawUrl, targetBucket, objectPath, supabaseEnv, googleToken) {
  if (!rawUrl || SKIP_STORAGE || DRY_RUN || VERIFY_ONLY) return rawUrl;
  const isFirebaseUrl = rawUrl.includes("firebasestorage.googleapis.com") || rawUrl.includes("storage.googleapis.com/" + PROJECT_ID);
  if (!isFirebaseUrl) return rawUrl;
  try {
    const dl = await fetch(rawUrl, { headers: rawUrl.includes("storage.googleapis.com") ? { Authorization: `Bearer ${googleToken}` } : {} });
    if (!dl.ok) return rawUrl;
    const contentType = dl.headers.get("content-type") || "application/octet-stream";
    const buf = Buffer.from(await dl.arrayBuffer());
    const cleanPath = objectPath.replace(/^\/+/, "");
    const up = await fetch(
      `${supabaseEnv.url}/storage/v1/object/${encodeURIComponent(targetBucket)}/${cleanPath.split("/").map(encodeURIComponent).join("/")}`,
      {
        method: "POST",
        headers: {
          apikey: supabaseEnv.serviceKey,
          Authorization: `Bearer ${supabaseEnv.serviceKey}`,
          "Content-Type": contentType,
          "x-upsert": "true"
        },
        body: buf
      }
    );
    if (!up.ok) return rawUrl;
    if (targetBucket === "verification-documents") {
      return `${supabaseEnv.url}/storage/v1/object/authenticated/${targetBucket}/${cleanPath}`;
    }
    return `${supabaseEnv.url}/storage/v1/object/public/${targetBucket}/${cleanPath}`;
  } catch {
    return rawUrl;
  }
}

async function run() {
  console.log("=== Repair Pro: Firestore -> Supabase Migration ===");
  console.log(`Mode: ${VERIFY_ONLY ? "VERIFY_ONLY" : DRY_RUN ? "DRY_RUN (no writes)" : "LIVE_MIGRATION"} | Skip Storage: ${SKIP_STORAGE}`);

  const sa = loadServiceAccount();
  const supabaseEnv = getSupabaseEnv();
  const googleToken = await getGoogleAccessToken(sa);

  const report = [];
  const recordStat = async (label, table, fsCount, writtenCount) => {
    const sbTotal = await countSupabaseRows(table, supabaseEnv);
    report.push({ label, table, fsCount, writtenCount, sbTotal });
  };

  // 1. Admins -> admin_roles
  const admins = await listFirestoreCollection("admins", googleToken);
  const adminRows = admins.map((d) => ({
    user_id: d.id,
    email: String(d.data.email || ""),
    role: ["SUPER_ADMIN", "CONTENT_EDITOR", "TRANSLATOR", "ANALYST"].includes(String(d.data.role || "").toUpperCase())
      ? String(d.data.role).toUpperCase()
      : "SUPER_ADMIN",
    created_at: asIso(d.data.createdAt),
    updated_at: asIso(d.data.updatedAt)
  }));
  await recordStat("admins", "admin_roles", admins.length, await upsertSupabaseBatch("admin_roles", "user_id", adminRows, supabaseEnv));

  // 2. Users + Subcollections (saved_guides, read_announcements, fcm_tokens)
  const users = await listFirestoreCollection("users", googleToken);
  const userRows = [];
  const savedGuideRows = [];
  const readAnnRows = [];
  const fcmTokenRows = [];

  for (const d of users) {
    const lang = ["en", "bn", "hi"].includes(String(d.data.preferredLanguage)) ? String(d.data.preferredLanguage) : "en";
    const accStatus = ["ACTIVE", "BLOCKED", "SUSPENDED"].includes(String(d.data.accountStatus))
      ? String(d.data.accountStatus)
      : d.data.blocked ? "BLOCKED" : d.data.suspended ? "SUSPENDED" : "ACTIVE";
    const migratedPhoto = await migrateLegacyStorageUrlIfNeeded(
      String(d.data.photoUrl || ""),
      "user-avatars",
      `${d.id}/migrated_avatar.jpg`,
      supabaseEnv,
      googleToken
    );
    userRows.push({
      user_id: d.id,
      display_name: String(d.data.displayName || "Repair Pro User"),
      email: String(d.data.email || ""),
      photo_url: migratedPhoto,
      photo_storage_path: String(d.data.photoStoragePath || ""),
      photo_provider_id: String(d.data.photoProviderId || "supabase_primary"),
      preferred_language: lang,
      ad_consent_granted: d.data.adConsentGranted !== false,
      notifications_enabled: d.data.notificationsEnabled !== false,
      is_verified_technician: Boolean(d.data.isVerifiedTechnician),
      account_status: accStatus,
      blocked: Boolean(d.data.blocked),
      suspended: Boolean(d.data.suspended),
      community_restricted: Boolean(d.data.communityRestricted),
      upload_restricted: Boolean(d.data.uploadRestricted),
      moderation_reason: String(d.data.moderationReason || ""),
      moderated_by_uid: String(d.data.moderatedByUid || ""),
      moderated_at: d.data.moderatedAt ? asIso(d.data.moderatedAt) : null,
      created_at: asIso(d.data.createdAt),
      updated_at: asIso(d.data.updatedAt)
    });

    const [guides, readAnns, tokens] = await Promise.all([
      listFirestoreCollection(`users/${encodeURIComponent(d.id)}/saved_guides`, googleToken),
      listFirestoreCollection(`users/${encodeURIComponent(d.id)}/read_announcements`, googleToken),
      listFirestoreCollection(`users/${encodeURIComponent(d.id)}/fcm_tokens`, googleToken)
    ]);
    for (const g of guides) {
      savedGuideRows.push({
        user_id: d.id,
        guide_id: g.id,
        category_id: String(g.data.categoryId || ""),
        brand_name: String(g.data.brandName || ""),
        model_series: String(g.data.modelSeries || ""),
        code: String(g.data.code || ""),
        title: String(g.data.title || ""),
        summary: String(g.data.summary || ""),
        entry_type: String(g.data.entryType || "ERROR_CODE"),
        saved_at: asIso(g.data.savedAt)
      });
    }
    for (const r of readAnns) {
      readAnnRows.push({
        user_id: d.id,
        announcement_id: r.id,
        read_at: asIso(r.data.readAt)
      });
    }
    for (const t of tokens) {
      const tok = String(t.data.token || "");
      if (tok) {
        fcmTokenRows.push({
          token_id: `${d.id}_${t.id}`,
          user_id: d.id,
          token: tok,
          platform: String(t.data.platform || "android"),
          updated_at: asIso(t.data.updatedAt)
        });
      }
    }
  }
  await recordStat("users", "user_profiles", users.length, await upsertSupabaseBatch("user_profiles", "user_id", userRows, supabaseEnv));
  await recordStat("users/*/saved_guides", "saved_guides", savedGuideRows.length, await upsertSupabaseBatch("saved_guides", "user_id,guide_id", savedGuideRows, supabaseEnv));
  await recordStat("users/*/read_announcements", "read_announcements", readAnnRows.length, await upsertSupabaseBatch("read_announcements", "user_id,announcement_id", readAnnRows, supabaseEnv));
  await recordStat("users/*/fcm_tokens", "fcm_tokens", fcmTokenRows.length, await upsertSupabaseBatch("fcm_tokens", "token_id", fcmTokenRows, supabaseEnv));

  // 3. Repair Catalog Entries
  const catalog = await listFirestoreCollection("repair_catalog_entries", googleToken);
  const catalogRows = catalog.map((d) => ({
    id: d.id,
    entry_type: ["CATEGORY", "ERROR_CODE", "PROBLEM"].includes(String(d.data.entryType)) ? String(d.data.entryType) : "ERROR_CODE",
    category_id: String(d.data.categoryId || "ac"),
    brand_name: String(d.data.brandName || ""),
    model_series: String(d.data.modelSeries || ""),
    code: String(d.data.code || ""),
    title_en: String(d.data.titleEn || "Untitled"),
    title_bn: String(d.data.titleBn || ""),
    title_hi: String(d.data.titleHi || ""),
    summary_en: String(d.data.summaryEn || ""),
    summary_bn: String(d.data.summaryBn || ""),
    summary_hi: String(d.data.summaryHi || ""),
    steps_en: String(d.data.stepsEn || ""),
    steps_bn: String(d.data.stepsBn || ""),
    steps_hi: String(d.data.stepsHi || ""),
    safety_warning_en: String(d.data.safetyWarningEn || "Disconnect mains power before inspection."),
    photo_url: String(d.data.photoUrl || ""),
    photo_storage_path: String(d.data.photoStoragePath || ""),
    pdf_url: String(d.data.pdfUrl || ""),
    pdf_storage_path: String(d.data.pdfStoragePath || ""),
    pdf_title: String(d.data.pdfTitle || ""),
    diagram_url: String(d.data.diagramUrl || ""),
    diagram_storage_path: String(d.data.diagramStoragePath || ""),
    diagram_title: String(d.data.diagramTitle || ""),
    verification_status: String(d.data.verificationStatus) === "UNVERIFIED" ? "UNVERIFIED" : "VERIFIED",
    published: d.data.published !== false,
    revision: Number(d.data.revision || 1),
    updated_by_uid: String(d.data.updatedByUid || "migrated"),
    created_at: asIso(d.data.createdAt),
    updated_at: asIso(d.data.updatedAt)
  }));
  await recordStat("repair_catalog_entries", "repair_catalog_entries", catalog.length, await upsertSupabaseBatch("repair_catalog_entries", "id", catalogRows, supabaseEnv));

  // 4. Technicians & Verification Requests
  const techs = await listFirestoreCollection("technicians", googleToken);
  const techRows = [];
  for (const d of techs) {
    const photoUrl = await migrateLegacyStorageUrlIfNeeded(String(d.data.photoUrl || ""), "technician-photos", `${d.id}/photo.jpg`, supabaseEnv, googleToken);
    techRows.push({
      technician_id: d.id,
      full_name: String(d.data.fullName || ""),
      photo_url: photoUrl,
      photo_storage_path: String(d.data.photoStoragePath || ""),
      photo_provider_id: String(d.data.photoProviderId || "supabase_primary"),
      mobile_number: String(d.data.mobileNumber || ""),
      full_address: String(d.data.fullAddress || ""),
      state: String(d.data.state || ""),
      district: String(d.data.district || ""),
      city_area: String(d.data.cityArea || ""),
      pin_code: String(d.data.pinCode || ""),
      service_categories: asStrArray(d.data.serviceCategories).length ? asStrArray(d.data.serviceCategories) : ["AC"],
      experience: String(d.data.experience || ""),
      bio: String(d.data.bio || ""),
      verification_status: ["PENDING", "VERIFIED", "REJECTED", "SUSPENDED"].includes(String(d.data.verificationStatus)) ? String(d.data.verificationStatus) : "VERIFIED",
      blocked: Boolean(d.data.blocked),
      is_suspended: Boolean(d.data.isSuspended),
      is_deleted: Boolean(d.data.isDeleted),
      linked_user_uid: String(d.data.linkedUserUid || ""),
      status: String(d.data.status) === "INACTIVE" ? "INACTIVE" : "ACTIVE",
      updated_by_uid: String(d.data.updatedByUid || "migrated"),
      created_at: asIso(d.data.createdAt),
      updated_at: asIso(d.data.updatedAt)
    });
  }
  await recordStat("technicians", "technicians", techs.length, await upsertSupabaseBatch("technicians", "technician_id", techRows, supabaseEnv));

  const verReqs = await listFirestoreCollection("technician_verification_requests", googleToken);
  const verRows = [];
  for (const d of verReqs) {
    const profilePhotoUrl = await migrateLegacyStorageUrlIfNeeded(String(d.data.profilePhotoUrl || ""), "technician-photos", `${d.id}/avatar.jpg`, supabaseEnv, googleToken);
    const credUrl = await migrateLegacyStorageUrlIfNeeded(String(d.data.credentialDocUrl || ""), "verification-documents", `${d.id}/credential.jpg`, supabaseEnv, googleToken);
    verRows.push({
      user_id: d.id,
      full_name: String(d.data.fullName || ""),
      mobile_number: String(d.data.mobileNumber || ""),
      full_address: String(d.data.fullAddress || ""),
      state: String(d.data.state || ""),
      district: String(d.data.district || ""),
      city_area: String(d.data.cityArea || ""),
      pin_code: String(d.data.pinCode || ""),
      service_categories: asStrArray(d.data.serviceCategories).length ? asStrArray(d.data.serviceCategories) : ["AC"],
      experience: String(d.data.experience || ""),
      bio: String(d.data.bio || ""),
      profile_photo_url: profilePhotoUrl,
      profile_photo_storage_path: String(d.data.profilePhotoStoragePath || ""),
      profile_photo_provider_id: String(d.data.profilePhotoProviderId || "supabase_primary"),
      credential_doc_url: credUrl,
      credential_doc_storage_path: String(d.data.credentialDocStoragePath || ""),
      credential_doc_provider_id: String(d.data.credentialDocProviderId || "supabase_primary"),
      credential_doc_name: String(d.data.credentialDocName || ""),
      status: ["PENDING", "VERIFIED", "REJECTED", "SUSPENDED"].includes(String(d.data.status)) ? String(d.data.status) : "PENDING",
      rejection_reason: String(d.data.rejectionReason || ""),
      reviewed_by_uid: String(d.data.reviewedByUid || ""),
      created_at: asIso(d.data.createdAt),
      updated_at: asIso(d.data.updatedAt)
    });
  }
  await recordStat("technician_verification_requests", "technician_verification_requests", verReqs.length, await upsertSupabaseBatch("technician_verification_requests", "user_id", verRows, supabaseEnv));

  // 5. Technical Documents
  const docs = await listFirestoreCollection("technical_documents", googleToken);
  const docRows = docs.map((d) => ({
    doc_id: d.id,
    doc_type: ["PDF_MANUAL", "CIRCUIT_DIAGRAM", "REPAIR_PHOTO"].includes(String(d.data.docType)) ? String(d.data.docType) : "PDF_MANUAL",
    category_id: ["ac", "fridge", "washer", "general"].includes(String(d.data.categoryId)) ? String(d.data.categoryId) : "general",
    brand_name: String(d.data.brandName || ""),
    model_name: String(d.data.modelName || ""),
    linked_entry_id: String(d.data.linkedEntryId || ""),
    title: String(d.data.title || "Document"),
    description: String(d.data.description || ""),
    file_url: String(d.data.fileUrl || ""),
    storage_path: String(d.data.storagePath || ""),
    storage_provider_id: String(d.data.storageProviderId || "supabase_primary"),
    mime_type: String(d.data.mimeType || "application/pdf"),
    file_size_bytes: Number(d.data.fileSizeBytes || 0),
    published: d.data.published !== false,
    offline_available: d.data.offlineAvailable !== false,
    is_deleted: Boolean(d.data.isDeleted),
    uploaded_by_uid: String(d.data.uploadedByUid || "migrated"),
    created_at: asIso(d.data.createdAt),
    updated_at: asIso(d.data.updatedAt)
  }));
  await recordStat("technical_documents", "technical_documents", docs.length, await upsertSupabaseBatch("technical_documents", "doc_id", docRows, supabaseEnv));

  // 6. Community Posts + Likes/Comments + Reports/Restrictions
  const posts = await listFirestoreCollection("community_posts", googleToken);
  const postRows = [];
  const likeRows = [];
  const commentRows = [];

  for (const d of posts) {
    const cat = ["AC", "Refrigerator", "Washing Machine", "General"].includes(String(d.data.category)) ? String(d.data.category) : "General";
    const status = ["PENDING", "APPROVED", "REJECTED"].includes(String(d.data.approvalStatus)) ? String(d.data.approvalStatus) : "PENDING";
    postRows.push({
      post_id: d.id,
      author_uid: String(d.data.authorUid || ""),
      author_name: String(d.data.authorName || "Technician"),
      author_photo_url: String(d.data.authorPhotoUrl || ""),
      author_verified: Boolean(d.data.authorVerified),
      category: cat,
      brand_name: String(d.data.brandName || ""),
      model_name: String(d.data.modelName || ""),
      error_code: String(d.data.errorCode || ""),
      title: String(d.data.title || "Repair Post"),
      body: String(d.data.body || ""),
      photo_url: String(d.data.photoUrl || ""),
      photo_storage_path: String(d.data.photoStoragePath || ""),
      photo_urls: asStrArray(d.data.photoUrls),
      photo_storage_paths: asStrArray(d.data.photoStoragePaths),
      photo_provider_ids: asStrArray(d.data.photoProviderIds),
      is_pinned: Boolean(d.data.isPinned),
      is_hidden: Boolean(d.data.isHidden),
      is_deleted: Boolean(d.data.isDeleted),
      approval_status: status,
      moderation_note: String(d.data.moderationNote || ""),
      reviewed_by_uid: String(d.data.reviewedByUid || ""),
      like_count: Number(d.data.likeCount || 0),
      comment_count: Number(d.data.commentCount || 0),
      report_count: Number(d.data.reportCount || 0),
      created_at: asIso(d.data.createdAt),
      updated_at: asIso(d.data.updatedAt)
    });

    const [likes, comments] = await Promise.all([
      listFirestoreCollection(`community_posts/${encodeURIComponent(d.id)}/likes`, googleToken),
      listFirestoreCollection(`community_posts/${encodeURIComponent(d.id)}/comments`, googleToken)
    ]);
    for (const l of likes) {
      likeRows.push({ post_id: d.id, user_id: l.id, created_at: asIso(l.data.createdAt) });
    }
    for (const c of comments) {
      commentRows.push({
        comment_id: c.id,
        post_id: d.id,
        parent_comment_id: String(c.data.parentCommentId || ""),
        reply_to_author_name: String(c.data.replyToAuthorName || ""),
        author_uid: String(c.data.authorUid || ""),
        author_name: String(c.data.authorName || "Technician"),
        author_verified: Boolean(c.data.authorVerified),
        body: String(c.data.body || ""),
        created_at: asIso(c.data.createdAt),
        updated_at: asIso(c.data.updatedAt)
      });
    }
  }
  await recordStat("community_posts", "community_posts", posts.length, await upsertSupabaseBatch("community_posts", "post_id", postRows, supabaseEnv));
  await recordStat("community_posts/*/likes", "community_likes", likeRows.length, await upsertSupabaseBatch("community_likes", "post_id,user_id", likeRows, supabaseEnv));
  await recordStat("community_posts/*/comments", "community_comments", commentRows.length, await upsertSupabaseBatch("community_comments", "comment_id", commentRows, supabaseEnv));

  const reports = await listFirestoreCollection("community_reports", googleToken);
  const reportRows = reports.map((d) => ({
    report_id: d.id,
    post_id: String(d.data.postId || ""),
    comment_id: String(d.data.commentId || ""),
    reporter_uid: String(d.data.reporterUid || ""),
    reporter_name: String(d.data.reporterName || ""),
    reason: ["SPAM", "MISINFORMATION", "UNSAFE_ADVICE", "ABUSE", "OFF_TOPIC", "OTHER"].includes(String(d.data.reason)) ? String(d.data.reason) : "OTHER",
    details: String(d.data.details || ""),
    status: ["OPEN", "REVIEWED", "RESOLVED", "DISMISSED"].includes(String(d.data.status)) ? String(d.data.status) : "OPEN",
    admin_note: String(d.data.adminNote || ""),
    created_at: asIso(d.data.createdAt),
    updated_at: asIso(d.data.updatedAt)
  }));
  await recordStat("community_reports", "community_reports", reports.length, await upsertSupabaseBatch("community_reports", "report_id", reportRows, supabaseEnv));

  const restrictions = await listFirestoreCollection("community_user_restrictions", googleToken);
  const resRows = restrictions.map((d) => ({
    user_id: d.id,
    user_name: String(d.data.userName || ""),
    reason: String(d.data.reason || "Restricted by admin"),
    blocked_by_uid: String(d.data.blockedByUid || ""),
    created_at: asIso(d.data.createdAt)
  }));
  await recordStat("community_user_restrictions", "community_user_restrictions", restrictions.length, await upsertSupabaseBatch("community_user_restrictions", "user_id", resRows, supabaseEnv));

  // 7. Problem Reports, Notifications, Announcements, Push History
  const probReports = await listFirestoreCollection("problem_reports", googleToken);
  const probRows = probReports.map((d) => ({
    report_id: d.id,
    user_id: String(d.data.userId || ""),
    category_id: String(d.data.categoryId || "ac"),
    brand_name: String(d.data.brandName || ""),
    model_name: String(d.data.modelName || ""),
    error_code: String(d.data.errorCode || ""),
    description: String(d.data.description || ""),
    preferred_language: ["en", "bn", "hi"].includes(String(d.data.preferredLanguage)) ? String(d.data.preferredLanguage) : "en",
    status: ["PENDING", "REVIEWED", "PUBLISHED"].includes(String(d.data.status)) ? String(d.data.status) : "PENDING",
    admin_note: String(d.data.adminNote || ""),
    created_at: asIso(d.data.createdAt),
    updated_at: asIso(d.data.updatedAt)
  }));
  await recordStat("problem_reports", "problem_reports", probReports.length, await upsertSupabaseBatch("problem_reports", "report_id", probRows, supabaseEnv));

  const notifs = await listFirestoreCollection("user_notifications", googleToken);
  const notifRows = notifs.map((d) => ({
    notification_id: d.id,
    recipient_uid: String(d.data.recipientUid || ""),
    actor_uid: String(d.data.actorUid || ""),
    type: String(d.data.type || "SYSTEM"),
    title: String(d.data.title || ""),
    body: String(d.data.body || ""),
    image_url: String(d.data.imageUrl || ""),
    target_route: String(d.data.targetRoute || ""),
    is_read: Boolean(d.data.isRead),
    created_at: asIso(d.data.createdAt),
    updated_at: asIso(d.data.updatedAt)
  }));
  await recordStat("user_notifications", "user_notifications", notifs.length, await upsertSupabaseBatch("user_notifications", "notification_id", notifRows, supabaseEnv));

  const anns = await listFirestoreCollection("announcements", googleToken);
  const annRows = anns.map((d) => ({
    announcement_id: d.id,
    title: String(d.data.title || ""),
    body: String(d.data.body || ""),
    category: String(d.data.category || "GENERAL"),
    image_url: String(d.data.imageUrl || ""),
    target_route: String(d.data.targetRoute || ""),
    created_by_uid: String(d.data.createdByUid || "admin"),
    created_at: asIso(d.data.createdAt)
  }));
  await recordStat("announcements", "announcements", anns.length, await upsertSupabaseBatch("announcements", "announcement_id", annRows, supabaseEnv));

  const pushHist = await listFirestoreCollection("push_notification_history", googleToken);
  const pushRows = pushHist.map((d) => ({
    push_id: d.id,
    audience: ["ALL", "SELECTED", "TECHNICIANS"].includes(String(d.data.audience)) ? String(d.data.audience) : "ALL",
    event_type: String(d.data.eventType || "ANNOUNCEMENT"),
    title: String(d.data.title || ""),
    body: String(d.data.body || ""),
    image_url: String(d.data.imageUrl || ""),
    target_route: String(d.data.targetRoute || ""),
    target_uids: asStrArray(d.data.targetUids),
    delivery_status: String(d.data.deliveryStatus || "SENT"),
    sent_count: Number(d.data.sentCount || 0),
    failed_count: Number(d.data.failedCount || 0),
    error_message: String(d.data.errorMessage || ""),
    created_by_uid: String(d.data.createdByUid || ""),
    created_by_email: String(d.data.createdByEmail || ""),
    created_at: asIso(d.data.createdAt)
  }));
  await recordStat("push_notification_history", "push_notification_history", pushHist.length, await upsertSupabaseBatch("push_notification_history", "push_id", pushRows, supabaseEnv));

  // 8. App Settings, Storage History/Errors, Audit Logs
  const appSettings = await listFirestoreCollection("app_settings", googleToken);
  const settingRows = appSettings.map((d) => ({
    setting_id: d.id,
    config_type: d.id.toUpperCase(),
    payload: d.data,
    updated_by_uid: String(d.data.updatedByUid || "migrated"),
    updated_at: asIso(d.data.updatedAt)
  }));
  await recordStat("app_settings", "app_settings", appSettings.length, await upsertSupabaseBatch("app_settings", "setting_id", settingRows, supabaseEnv));

  const audits = await listFirestoreCollection("audit_logs", googleToken);
  const auditRows = audits.map((d) => ({
    log_id: d.id,
    admin_uid: String(d.data.adminUid || ""),
    admin_email: String(d.data.adminEmail || ""),
    action: String(d.data.action || ""),
    target_type: String(d.data.targetType || ""),
    target_id: String(d.data.targetId || ""),
    details: String(d.data.details || ""),
    result: String(d.data.result || "SUCCESS"),
    created_at: asIso(d.data.createdAt)
  }));
  await recordStat("audit_logs", "audit_logs", audits.length, await upsertSupabaseBatch("audit_logs", "log_id", auditRows, supabaseEnv));

  console.table(report);
  console.log("Migration completed cleanly.");
}

run().catch((err) => {
  console.error("Migration error:", err.message || err);
  process.exit(1);
});
