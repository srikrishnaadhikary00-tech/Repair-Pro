import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";

import {
  MIGRATION_TABLES,
  MIGRATION_BUCKETS,
  PROTECTED_MIGRATION_TABLES,
  buildNonSecretDiscoveryPayload,
  canExecuteCleanup,
  evaluateMigrationThresholds,
  executeVerifiedCleanup,
  getPartialCloudFailures,
  isPrimaryDatabaseSupabase,
  isSupabaseQuotaOrOutageError,
  mergeCloudRows,
  multiCloudDbQuery,
  normalizeMigrationConfig
} from "../web-admin/cloud-migration.js";

const ROOT = process.cwd();

test("All web-admin JS files pass Node syntax check", () => {
  for (const rel of [
    "web-admin/firebase-config.js",
    "web-admin/supabase-client.js",
    "web-admin/cloud-migration.js",
    "web-admin/app.js"
  ]) {
    execFileSync(process.execPath, ["--check", path.join(ROOT, rel)], { stdio: "pipe" });
  }
});

test("All literal DOM IDs referenced by $(...) in web-admin/app.js exist in web-admin/index.html", () => {
  const html = fs.readFileSync(path.join(ROOT, "web-admin/index.html"), "utf8");
  const appJs = fs.readFileSync(path.join(ROOT, "web-admin/app.js"), "utf8");

  const htmlIds = new Set();
  for (const m of html.matchAll(/\sid=["']([^"']+)["']/g)) {
    htmlIds.add(m[1]);
  }

  const missingIds = [];
  for (const m of appJs.matchAll(/\$\(\s*["']([^"']+)["']\s*\)/g)) {
    const id = m[1];
    if (!htmlIds.has(id)) {
      missingIds.push(id);
    }
  }
  assert.deepEqual(missingIds, [], `Missing DOM IDs in web-admin/index.html: ${missingIds.join(", ")}`);

  for (const requiredId of [
    "mig-scheduler-status",
    "mig-scheduler-tick-btn",
    "cloud-partial-availability-banner",
    "storage-error-logs-list"
  ]) {
    assert.ok(htmlIds.has(requiredId), `Expected #${requiredId} in web-admin/index.html`);
  }
});

test("canExecuteCleanup blocks deletion unless enabled, healthy, 0 failures, and 100% verified", () => {
  assert.equal(
    canExecuteCleanup({
      autoCleanupEnabled: false,
      totalItems: 10,
      verifiedItems: 10,
      failedItems: 0,
      targetHealthy: true
    }).allowed,
    false
  );
  assert.equal(
    canExecuteCleanup({
      autoCleanupEnabled: true,
      totalItems: 10,
      verifiedItems: 10,
      failedItems: 0,
      targetHealthy: false
    }).allowed,
    false
  );
  assert.equal(
    canExecuteCleanup({
      autoCleanupEnabled: true,
      totalItems: 10,
      verifiedItems: 9,
      failedItems: 1,
      targetHealthy: true
    }).allowed,
    false
  );
  assert.equal(
    canExecuteCleanup({
      autoCleanupEnabled: true,
      totalItems: 10,
      verifiedItems: 9,
      failedItems: 0,
      targetHealthy: true
    }).allowed,
    false
  );
  assert.equal(
    canExecuteCleanup({
      autoCleanupEnabled: true,
      totalItems: 0,
      verifiedItems: 0,
      failedItems: 0,
      targetHealthy: true
    }).allowed,
    false
  );
  assert.equal(
    canExecuteCleanup({
      autoCleanupEnabled: true,
      totalItems: 10,
      verifiedItems: 10,
      failedItems: 0,
      targetHealthy: true
    }).allowed,
    true
  );
});

test("evaluateMigrationThresholds never triggers auto-migration without connected cPanel host", () => {
  const supabaseOnlyState = {
    providers: [
      {
        providerId: "supabase_primary",
        providerType: "SUPABASE_STORAGE",
        endpointUrl: "https://xuakzzjtcgcvudkgxpbd.supabase.co",
        role: "PRIMARY",
        enabled: true
      }
    ]
  };
  const evalNoHost = evaluateMigrationThresholds(
    { dbUsedBytes: 480_000_000, dbLimitBytes: 500_000_000, storageUsedBytes: 950_000_000, storageLimitBytes: 1_000_000_000 },
    { autoMigrationEnabled: true, dbMigrationThresholdPct: 80, storageMigrationThresholdPct: 80 },
    supabaseOnlyState
  );
  assert.equal(evalNoHost.hasTargetHost, false);
  assert.equal(evalNoHost.shouldAutoMigrate, false);
  assert.ok(evalNoHost.reasons.length >= 2);

  const withCpanelState = {
    providers: [
      ...supabaseOnlyState.providers,
      {
        providerId: "cpanel_1",
        providerType: "PHP_HOSTING",
        endpointUrl: "https://host.example.com/repairpro/index.php",
        supportsStorage: true,
        supportsDatabase: true,
        dbEnabled: true,
        role: "BACKUP",
        enabled: true
      }
    ]
  };
  const evalDisabled = evaluateMigrationThresholds(
    { dbUsedBytes: 480_000_000, dbLimitBytes: 500_000_000, storageUsedBytes: 100_000_000, storageLimitBytes: 1_000_000_000 },
    { autoMigrationEnabled: false, dbMigrationThresholdPct: 80, storageMigrationThresholdPct: 80 },
    withCpanelState
  );
  assert.equal(evalDisabled.hasTargetHost, true);
  assert.equal(evalDisabled.shouldAutoMigrate, false);

  const evalTriggered = evaluateMigrationThresholds(
    { dbUsedBytes: 450_000_000, dbLimitBytes: 500_000_000, storageUsedBytes: 100_000_000, storageLimitBytes: 1_000_000_000 },
    { autoMigrationEnabled: true, dbMigrationThresholdPct: 80, storageMigrationThresholdPct: 80 },
    withCpanelState
  );
  assert.equal(evalTriggered.shouldAutoMigrate, true);
  assert.equal(evalTriggered.targetProvider.providerId, "cpanel_1");
});

test("mergeCloudRows deduplicates by primary key and retains newest timestamp across Supabase + cPanel", () => {
  const supaRows = [
    { post_id: "p1", title: "Legacy Supabase", updated_at: "2026-01-01T10:00:00Z" },
    { post_id: "p2", title: "Older Copy", updated_at: "2026-01-02T10:00:00Z" }
  ];
  const cpanelRows = [
    { post_id: "p2", title: "Newer cPanel Copy", updated_at: "2026-03-01T10:00:00Z" },
    { post_id: "p3", title: "Failover cPanel Only", updated_at: "2026-03-05T10:00:00Z" }
  ];
  const merged = mergeCloudRows(
    supaRows,
    [{ providerId: "cpanel_1", rows: cpanelRows }],
    ["post_id"]
  );
  assert.equal(merged.length, 3);
  const map = new Map(merged.map((r) => [r.post_id, r.title]));
  assert.equal(map.get("p1"), "Legacy Supabase");
  assert.equal(map.get("p2"), "Newer cPanel Copy");
  assert.equal(map.get("p3"), "Failover cPanel Only");
});

test("isSupabaseQuotaOrOutageError and isPrimaryDatabaseSupabase work accurately", () => {
  assert.equal(isSupabaseQuotaOrOutageError(new Error("HTTP 507 Insufficient Storage")), true);
  assert.equal(isSupabaseQuotaOrOutageError(new Error("Supabase project paused 503")), true);
  assert.equal(isSupabaseQuotaOrOutageError(new Error("TypeError: Failed to fetch")), true);
  assert.equal(isSupabaseQuotaOrOutageError(new Error("HTTP 400 Invalid UUID")), false);

  assert.equal(
    isPrimaryDatabaseSupabase(
      { providers: [{ providerId: "supabase_primary", providerType: "SUPABASE_STORAGE", role: "PRIMARY", enabled: true }] },
      { primaryDbProviderId: "supabase_primary" }
    ),
    true
  );
  assert.equal(
    isPrimaryDatabaseSupabase(
      {
        providers: [
          {
            providerId: "cpanel_1",
            providerType: "PHP_HOSTING",
            supportsDatabase: true,
            dbEnabled: true,
            role: "PRIMARY",
            enabled: true
          }
        ]
      },
      { primaryDbProviderId: "cpanel_1" }
    ),
    false
  );
});

test("buildNonSecretDiscoveryPayload strips secrets, protects essential auth/system tables, and configures buckets", () => {
  const payload = buildNonSecretDiscoveryPayload(
    {
      providers: [
        {
          providerId: "cpanel_1",
          providerType: "PHP_HOSTING",
          endpointUrl: "https://host.example.com/api/index.php",
          publicAnonKey: "MUST_NOT_LEAK_IN_EXTERNAL",
          apiSecret: "SUPER_SECRET_PASSWORD",
          role: "BACKUP",
          enabled: true
        }
      ]
    },
    normalizeMigrationConfig({ autoMigrationEnabled: true })
  );
  const serialized = JSON.stringify(payload);
  assert.equal(serialized.includes("MUST_NOT_LEAK_IN_EXTERNAL"), false);
  assert.equal(serialized.includes("SUPER_SECRET_PASSWORD"), false);
  assert.ok(payload.fallbackDiscoveryUrls.includes("https://host.example.com/api/index.php"));
  assert.ok(MIGRATION_TABLES.length >= 14);
  assert.ok(MIGRATION_BUCKETS.some((b) => b.bucket === "verification-documents" && b.isPrivate === true));

  for (const critical of [
    "admin_roles",
    "app_settings",
    "user_profiles",
    "fcm_tokens",
    "storage_providers",
    "hosting_provider_secrets",
    "cloud_migration_runs",
    "cloud_migration_items",
    "cloud_backup_manifests",
    "cloud_scheduler_status"
  ]) {
    assert.ok(PROTECTED_MIGRATION_TABLES.has(critical), `Missing protected table: ${critical}`);
  }
});

test("multiCloudDbQuery tracks partial cloud failures and clears when all sources recover", async () => {
  const origFetch = globalThis.fetch;
  const mockUser = { getIdToken: async () => "mock-firebase-jwt" };
  const storageState = {
    providers: [
      {
        providerId: "supabase_primary",
        providerType: "SUPABASE_STORAGE",
        endpointUrl: "https://xuakzzjtcgcvudkgxpbd.supabase.co",
        role: "PRIMARY",
        enabled: true
      },
      {
        providerId: "cpanel_1",
        providerName: "cPanel Host 1",
        providerType: "PHP_HOSTING",
        endpointUrl: "https://host.example.com/api/index.php",
        supportsDatabase: true,
        dbEnabled: true,
        role: "BACKUP",
        enabled: true
      }
    ]
  };

  let cpanelHealthy = false;
  globalThis.fetch = async (url) => {
    const u = String(url);
    if (u.includes("host.example.com")) {
      if (!cpanelHealthy) {
        return new Response(JSON.stringify({ ok: false, message: "cPanel unreachable" }), { status: 503 });
      }
      return new Response(JSON.stringify({
        ok: true,
        rows: [{ post_id: "p_cp", title: "cPanel Post", updated_at: "2026-04-01T10:00:00Z" }]
      }), { status: 200 });
    }
    return new Response(JSON.stringify({ message: "unexpected" }), { status: 400 });
  };

  try {
    // 1. Query with Supabase unavailable (no runtime anon key in Node) -> throws when cPanel also fails
    await assert.rejects(() =>
      multiCloudDbQuery({
        table: "community_posts",
        categoryKey: "community",
        pkFields: ["post_id"],
        currentUser: mockUser,
        storageState
      })
    );

    // 2. When cPanel responds while Supabase fails -> returns cPanel rows and records Supabase Primary partial failure
    cpanelHealthy = true;
    const rows = await multiCloudDbQuery({
      table: "community_posts",
      categoryKey: "community",
      pkFields: ["post_id"],
      currentUser: mockUser,
      storageState
    });
    assert.equal(rows.length, 1);
    assert.equal(rows[0].post_id, "p_cp");
    const failures = getPartialCloudFailures();
    assert.ok(failures.some((f) => f.table === "community_posts" && f.failedSources.includes("Supabase Primary")));

    // 3. With no external DB providers (Supabase-only mode) -> no external failure state recorded when queried cleanly
    const cpanelDisabledState = {
      providers: [storageState.providers[0]]
    };
    globalThis.fetch = async () => new Response(JSON.stringify([]), { status: 200 });
    // Note: without SUPABASE_ANON_KEY in localStorage/meta, supabaseOnly throws; partialCloudFailureMap remains isolated per table.
    assert.ok(Array.isArray(getPartialCloudFailures()));
    assert.ok(cpanelDisabledState.providers.length === 1);
  } finally {
    globalThis.fetch = origFetch;
  }
});

test("executeVerifiedCleanup enforces safety gates and computes reclaimedBytes & verifiedReclamation", async () => {
  const origFetch = globalThis.fetch;
  const origStorage = globalThis.localStorage;
  const store = new Map([["repairpro_supabase_anon_key", "mock-anon-key"]]);
  globalThis.localStorage = {
    getItem: (k) => store.get(k) ?? null,
    setItem: (k, v) => store.set(k, String(v)),
    removeItem: (k) => store.delete(k)
  };

  let failHealth = false;
  let usageCall = 0;
  let deletedPaths = [];
  globalThis.fetch = async (url) => {
    const u = String(url);
    if (u.includes("action=health")) {
      return failHealth
        ? new Response(JSON.stringify({ ok: false }), { status: 503 })
        : new Response(JSON.stringify({ ok: true }), { status: 200 });
    }
    if (u.includes("action=verify_file")) {
      return new Response(JSON.stringify({ ok: true, exists: true, shaMatch: true, sizeBytes: 1500 }), { status: 200 });
    }
    if (u.includes("/rest/v1/cloud_migration_items?") && u.includes("select=")) {
      return new Response(JSON.stringify([
        { item_id: "i1", table_or_bucket: "community-photos", record_or_path: "u1/a.jpg", checksum_sha256: "abc", byte_size: 1500 },
        { item_id: "i2", table_or_bucket: "admin_roles", record_or_path: "ProtectedShouldSkip", checksum_sha256: "def", byte_size: 9999 }
      ]), { status: 200 });
    }
    return new Response(JSON.stringify({ ok: true }), { status: 200 });
  };

  try {
    await assert.rejects(
      () => executeVerifiedCleanup({
        run: { run_id: "run_1", total_items: 2, verified_items: 2, failed_items: 1 },
        targetProvider: { providerId: "cpanel_1", endpointUrl: "https://host.example.com/api/index.php" },
        supaProvider: { providerId: "supabase_primary" },
        migrationConfig: { autoCleanupEnabled: true },
        currentUser: { getIdToken: async () => "jwt" },
        supabaseDeleteObjectFn: async () => {}
      }),
      /failed/i
    );

    await assert.rejects(
      () => executeVerifiedCleanup({
        run: { run_id: "run_1", total_items: 2, verified_items: 2, failed_items: 0 },
        targetProvider: { providerId: "cpanel_1", endpointUrl: "https://host.example.com/api/index.php" },
        supaProvider: { providerId: "supabase_primary" },
        migrationConfig: { autoCleanupEnabled: false },
        currentUser: { getIdToken: async () => "jwt" },
        supabaseDeleteObjectFn: async () => {}
      }),
      /disabled|not enabled/i
    );

    failHealth = true;
    await assert.rejects(
      () => executeVerifiedCleanup({
        run: { run_id: "run_1", total_items: 2, verified_items: 2, failed_items: 0 },
        targetProvider: { providerId: "cpanel_1", endpointUrl: "https://host.example.com/api/index.php" },
        supaProvider: { providerId: "supabase_primary" },
        migrationConfig: { autoCleanupEnabled: true },
        currentUser: { getIdToken: async () => "jwt" },
        supabaseDeleteObjectFn: async () => {}
      }),
      /health check/i
    );

    failHealth = false;
    const result = await executeVerifiedCleanup({
      run: { run_id: "run_1", total_items: 1, verified_items: 1, failed_items: 0, cleaned_items: 0 },
      targetProvider: { providerId: "cpanel_1", endpointUrl: "https://host.example.com/api/index.php" },
      supaProvider: { providerId: "supabase_primary" },
      migrationConfig: { autoCleanupEnabled: true },
      currentUser: { getIdToken: async () => "jwt" },
      supabaseDeleteObjectFn: async (_prov, bucket, pathKey) => {
        deletedPaths.push(`${bucket}/${pathKey}`);
      },
      fetchUsageMetricsFn: async () => {
        usageCall += 1;
        return usageCall === 1 ? { storageUsedBytes: 10000 } : { storageUsedBytes: 7500 };
      }
    });

    assert.equal(result.cleanedCount, 1);
    assert.deepEqual(deletedPaths, ["community-photos/u1/a.jpg"]);
    assert.equal(result.verifiedReclamation, true);
    assert.equal(result.reclaimedBytes, 2500);
  } finally {
    globalThis.fetch = origFetch;
    globalThis.localStorage = origStorage;
  }
});

test("24x7 worker files exist and contain no hardcoded service keys or DB passwords", () => {
  const edgeWorker = fs.readFileSync(path.join(ROOT, "supabase/functions/cloud-migration-worker/index.ts"), "utf8");
  const cpanelCron = fs.readFileSync(path.join(ROOT, "hosting-php-api/cron_migrate.php"), "utf8");
  assert.ok(edgeWorker.includes("acquire_cloud_scheduler_lock"));
  assert.ok(edgeWorker.includes("PROTECTED_TABLES"));
  assert.ok(edgeWorker.includes("reclaimedBytes"));
  assert.equal(edgeWorker.includes("service_role_secret_"), false);

  assert.ok(cpanelCron.includes("flock("));
  assert.ok(cpanelCron.includes("HTTP_X_REPAIRPRO_CRON_SECRET"));
  assert.ok(cpanelCron.includes("hash_equals("));
  assert.ok(cpanelCron.includes(".scheduler_heartbeat.json"));
});
