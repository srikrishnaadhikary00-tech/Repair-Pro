#!/usr/bin/env node
/**
 * Repair Pro — One-Time Firebase Custom Claims Provisioning Script
 * Sets trusted server-side Firebase Auth custom claims (`role: "authenticated"`, `admin`, `repairproRole`)
 * required by Supabase Third-Party Auth + Firestore / Storage Rules.
 *
 * Usage:
 *   GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json \
 *   node scripts/set-firebase-custom-claims.mjs \
 *     --email srikrishnaadhikary00@gmail.com \
 *     --admin true
 *
 * Or pass --service-account /path/to/key.json and/or --uid <firebase_uid>
 */

import fs from "node:fs";
import crypto from "node:crypto";

const PROJECT_ID = "gen-lang-client-0218221723";

function parseArgs(argv) {
  const out = {};
  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    if (arg.startsWith("--")) {
      const key = arg.slice(2);
      const val = argv[i + 1] && !argv[i + 1].startsWith("--") ? argv[++i] : "true";
      out[key] = val;
    }
  }
  return out;
}

function base64Url(input) {
  return Buffer.from(input).toString("base64url");
}

async function getAccessToken(sa) {
  const now = Math.floor(Date.now() / 1000);
  const header = base64Url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const payload = base64Url(JSON.stringify({
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/identitytoolkit https://www.googleapis.com/auth/cloud-platform",
    aud: sa.token_uri || "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600
  }));
  const signingInput = `${header}.${payload}`;
  const sign = crypto.createSign("RSA-SHA256");
  sign.update(signingInput);
  const signature = sign.sign(sa.private_key, "base64url");
  const assertion = `${signingInput}.${signature}`;

  const resp = await fetch(sa.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion
    })
  });
  const data = await resp.json();
  if (!resp.ok || !data.access_token) {
    throw new Error(`Google OAuth2 failed: ${JSON.stringify(data)}`);
  }
  return data.access_token;
}

async function lookupUserByEmail(email, accessToken) {
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts:lookup`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ email: [email] })
  });
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(`User not found for email ${email}: ${JSON.stringify(data)}`);
  }
  return data.users[0];
}

async function main() {
  const args = parseArgs(process.argv);
  const saPath = args["service-account"] || process.env.GOOGLE_APPLICATION_CREDENTIALS || "";
  if (!saPath || !fs.existsSync(saPath)) {
    console.error("ERROR: Provide --service-account <path.json> or set GOOGLE_APPLICATION_CREDENTIALS.");
    process.exit(1);
  }
  const sa = JSON.parse(fs.readFileSync(saPath, "utf8"));
  const accessToken = await getAccessToken(sa);

  let uid = args.uid || "";
  if (!uid) {
    const email = args.email || "srikrishnaadhikary00@gmail.com";
    const user = await lookupUserByEmail(email, accessToken);
    uid = user.localId;
    console.log(`Resolved user ${email} -> UID ${uid}`);
  }

  const isAdmin = args.admin !== "false";
  const claims = {
    role: "authenticated",
    admin: isAdmin,
    repairproRole: isAdmin ? "SUPER_ADMIN" : "USER",
    blocked: false,
    suspended: false
  };

  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts:update`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      localId: uid,
      customAttributes: JSON.stringify(claims)
    })
  });
  const updated = await resp.json();
  if (!resp.ok) {
    console.error("Failed to update custom claims:", JSON.stringify(updated));
    process.exit(1);
  }
  console.log("SUCCESS: Custom claims updated:", JSON.stringify(claims));
  console.log("Ask the user to sign out and sign back in (or refresh ID token) to activate new claims.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
