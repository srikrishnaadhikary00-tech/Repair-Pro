-- Repair Pro — Supabase Free Plan PostgreSQL & Storage Schema
-- Supabase Project Name: Repair-Pro
-- Supabase Project Reference: xuakzzjtcgcvudkgxpbd
-- URL: https://xuakzzjtcgcvudkgxpbd.supabase.co
-- Run this script in the Supabase Dashboard -> SQL Editor (do NOT execute automatically from client).

-- 0. Extensions
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1. Helper: Updated timestamp trigger
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 2. Admin Roles (Bootstrap + Delegated Admins)
CREATE TABLE IF NOT EXISTS public.admin_roles (
  user_id TEXT PRIMARY KEY,
  email TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL CHECK (role IN ('SUPER_ADMIN', 'CONTENT_EDITOR', 'TRANSLATOR', 'ANALYST')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. User Profiles
CREATE TABLE IF NOT EXISTS public.user_profiles (
  user_id TEXT PRIMARY KEY,
  display_name TEXT NOT NULL DEFAULT 'Repair Pro User',
  email TEXT NOT NULL DEFAULT '',
  preferred_language TEXT NOT NULL DEFAULT 'en' CHECK (preferred_language IN ('en', 'bn', 'hi')),
  ad_consent_granted BOOLEAN NOT NULL DEFAULT TRUE,
  notifications_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  is_verified_technician BOOLEAN NOT NULL DEFAULT FALSE,
  account_status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (account_status IN ('ACTIVE', 'BLOCKED', 'SUSPENDED')),
  blocked BOOLEAN NOT NULL DEFAULT FALSE,
  suspended BOOLEAN NOT NULL DEFAULT FALSE,
  community_restricted BOOLEAN NOT NULL DEFAULT FALSE,
  upload_restricted BOOLEAN NOT NULL DEFAULT FALSE,
  moderation_reason TEXT NOT NULL DEFAULT '',
  moderated_by_uid TEXT NOT NULL DEFAULT '',
  moderated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Repair Catalog Entries (Multilingual AC, Refrigerator, Washing Machine)
CREATE TABLE IF NOT EXISTS public.repair_catalog_entries (
  id TEXT PRIMARY KEY,
  entry_type TEXT NOT NULL CHECK (entry_type IN ('CATEGORY', 'ERROR_CODE', 'PROBLEM')),
  category_id TEXT NOT NULL,
  brand_name TEXT NOT NULL DEFAULT '',
  model_series TEXT NOT NULL DEFAULT '',
  code TEXT NOT NULL DEFAULT '',
  title_en TEXT NOT NULL,
  title_bn TEXT NOT NULL DEFAULT '',
  title_hi TEXT NOT NULL DEFAULT '',
  summary_en TEXT NOT NULL,
  summary_bn TEXT NOT NULL DEFAULT '',
  summary_hi TEXT NOT NULL DEFAULT '',
  steps_en TEXT NOT NULL DEFAULT '',
  steps_bn TEXT NOT NULL DEFAULT '',
  steps_hi TEXT NOT NULL DEFAULT '',
  safety_warning_en TEXT NOT NULL DEFAULT 'Disconnect mains power before inspection.',
  photo_url TEXT NOT NULL DEFAULT '',
  photo_storage_path TEXT NOT NULL DEFAULT '',
  pdf_url TEXT NOT NULL DEFAULT '',
  pdf_storage_path TEXT NOT NULL DEFAULT '',
  pdf_title TEXT NOT NULL DEFAULT '',
  diagram_url TEXT NOT NULL DEFAULT '',
  diagram_storage_path TEXT NOT NULL DEFAULT '',
  diagram_title TEXT NOT NULL DEFAULT '',
  verification_status TEXT NOT NULL DEFAULT 'VERIFIED' CHECK (verification_status IN ('VERIFIED', 'UNVERIFIED')),
  published BOOLEAN NOT NULL DEFAULT TRUE,
  revision INTEGER NOT NULL DEFAULT 1,
  updated_by_uid TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Technicians Directory
CREATE TABLE IF NOT EXISTS public.technicians (
  technician_id TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  photo_url TEXT NOT NULL DEFAULT '',
  photo_storage_path TEXT NOT NULL DEFAULT '',
  mobile_number TEXT NOT NULL,
  full_address TEXT NOT NULL,
  state TEXT NOT NULL,
  district TEXT NOT NULL,
  city_area TEXT NOT NULL,
  pin_code TEXT NOT NULL,
  service_categories TEXT[] NOT NULL DEFAULT ARRAY['AC']::TEXT[],
  experience TEXT NOT NULL DEFAULT '',
  bio TEXT NOT NULL DEFAULT '',
  verification_status TEXT NOT NULL DEFAULT 'VERIFIED' CHECK (verification_status IN ('PENDING', 'VERIFIED', 'REJECTED', 'SUSPENDED')),
  blocked BOOLEAN NOT NULL DEFAULT FALSE,
  is_suspended BOOLEAN NOT NULL DEFAULT FALSE,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  deleted_at TIMESTAMPTZ,
  linked_user_uid TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE')),
  updated_by_uid TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. Technician Verification Requests
CREATE TABLE IF NOT EXISTS public.technician_verification_requests (
  user_id TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  mobile_number TEXT NOT NULL,
  full_address TEXT NOT NULL,
  state TEXT NOT NULL,
  district TEXT NOT NULL,
  city_area TEXT NOT NULL,
  pin_code TEXT NOT NULL,
  service_categories TEXT[] NOT NULL DEFAULT ARRAY['AC']::TEXT[],
  experience TEXT NOT NULL DEFAULT '',
  bio TEXT NOT NULL DEFAULT '',
  profile_photo_url TEXT NOT NULL DEFAULT '',
  profile_photo_storage_path TEXT NOT NULL DEFAULT '',
  credential_doc_url TEXT NOT NULL DEFAULT '',
  credential_doc_storage_path TEXT NOT NULL DEFAULT '',
  credential_doc_name TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'VERIFIED', 'REJECTED', 'SUSPENDED')),
  rejection_reason TEXT NOT NULL DEFAULT '',
  reviewed_by_uid TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. Technical Documents (PDF Manuals, Circuit Diagrams, Reference Photos)
CREATE TABLE IF NOT EXISTS public.technical_documents (
  doc_id TEXT PRIMARY KEY,
  doc_type TEXT NOT NULL CHECK (doc_type IN ('PDF_MANUAL', 'CIRCUIT_DIAGRAM', 'REPAIR_PHOTO')),
  category_id TEXT NOT NULL CHECK (category_id IN ('ac', 'fridge', 'washer', 'general')),
  brand_name TEXT NOT NULL DEFAULT '',
  model_name TEXT NOT NULL DEFAULT '',
  linked_entry_id TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  file_url TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  storage_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  mime_type TEXT NOT NULL DEFAULT 'application/pdf',
  file_size_bytes BIGINT NOT NULL DEFAULT 0,
  published BOOLEAN NOT NULL DEFAULT TRUE,
  offline_available BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  uploaded_by_uid TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. Technician Community Posts, Likes, Bookmarks, Comments, Reports, Restrictions
CREATE TABLE IF NOT EXISTS public.community_posts (
  post_id TEXT PRIMARY KEY,
  author_uid TEXT NOT NULL,
  author_name TEXT NOT NULL,
  author_photo_url TEXT NOT NULL DEFAULT '',
  author_verified BOOLEAN NOT NULL DEFAULT FALSE,
  category TEXT NOT NULL CHECK (category IN ('AC', 'Refrigerator', 'Washing Machine', 'General')),
  brand_name TEXT NOT NULL DEFAULT '',
  model_name TEXT NOT NULL DEFAULT '',
  error_code TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  photo_url TEXT NOT NULL DEFAULT '',
  photo_storage_path TEXT NOT NULL DEFAULT '',
  photo_urls TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  photo_storage_paths TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  photo_provider_ids TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  is_pinned BOOLEAN NOT NULL DEFAULT FALSE,
  is_hidden BOOLEAN NOT NULL DEFAULT FALSE,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  deleted_by_uid TEXT NOT NULL DEFAULT '',
  deleted_at TIMESTAMPTZ,
  approval_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (approval_status IN ('PENDING', 'APPROVED', 'REJECTED')),
  moderation_note TEXT NOT NULL DEFAULT '',
  reviewed_by_uid TEXT NOT NULL DEFAULT '',
  like_count INTEGER NOT NULL DEFAULT 0,
  comment_count INTEGER NOT NULL DEFAULT 0,
  report_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.community_likes (
  post_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (post_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.community_bookmarks (
  user_id TEXT NOT NULL,
  post_id TEXT NOT NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  author_name TEXT NOT NULL,
  photo_url TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, post_id)
);

CREATE TABLE IF NOT EXISTS public.community_comments (
  comment_id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL,
  parent_comment_id TEXT NOT NULL DEFAULT '',
  reply_to_author_name TEXT NOT NULL DEFAULT '',
  author_uid TEXT NOT NULL,
  author_name TEXT NOT NULL,
  author_verified BOOLEAN NOT NULL DEFAULT FALSE,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.community_reports (
  report_id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL,
  comment_id TEXT NOT NULL DEFAULT '',
  reporter_uid TEXT NOT NULL,
  reporter_name TEXT NOT NULL,
  reason TEXT NOT NULL CHECK (reason IN ('SPAM', 'MISINFORMATION', 'UNSAFE_ADVICE', 'ABUSE', 'OFF_TOPIC', 'OTHER')),
  details TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'REVIEWED', 'RESOLVED', 'DISMISSED')),
  admin_note TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.community_user_restrictions (
  user_id TEXT PRIMARY KEY,
  user_name TEXT NOT NULL DEFAULT '',
  reason TEXT NOT NULL,
  blocked_by_uid TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. Problem Reports
CREATE TABLE IF NOT EXISTS public.problem_reports (
  report_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  category_id TEXT NOT NULL,
  brand_name TEXT NOT NULL,
  model_name TEXT NOT NULL DEFAULT '',
  error_code TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL,
  preferred_language TEXT NOT NULL DEFAULT 'en' CHECK (preferred_language IN ('en', 'bn', 'hi')),
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'REVIEWED', 'PUBLISHED')),
  admin_note TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. Notifications, Announcements, FCM Tokens & Push Notification History
CREATE TABLE IF NOT EXISTS public.user_notifications (
  notification_id TEXT PRIMARY KEY,
  recipient_uid TEXT NOT NULL,
  actor_uid TEXT NOT NULL DEFAULT '',
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  image_url TEXT NOT NULL DEFAULT '',
  target_route TEXT NOT NULL DEFAULT '',
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.announcements (
  announcement_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'GENERAL',
  image_url TEXT NOT NULL DEFAULT '',
  target_route TEXT NOT NULL DEFAULT '',
  created_by_uid TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.fcm_tokens (
  token_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  token TEXT NOT NULL,
  platform TEXT NOT NULL DEFAULT 'android',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.push_notification_history (
  push_id TEXT PRIMARY KEY,
  audience TEXT NOT NULL CHECK (audience IN ('ALL', 'SELECTED', 'TECHNICIANS')),
  event_type TEXT NOT NULL DEFAULT 'ANNOUNCEMENT',
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  image_url TEXT NOT NULL DEFAULT '',
  target_route TEXT NOT NULL DEFAULT '',
  target_uids TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  delivery_status TEXT NOT NULL DEFAULT 'QUEUED',
  sent_count INTEGER NOT NULL DEFAULT 0,
  failed_count INTEGER NOT NULL DEFAULT 0,
  error_message TEXT NOT NULL DEFAULT '',
  created_by_uid TEXT NOT NULL,
  created_by_email TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. Multi-Cloud Storage Manager Tables (Dynamic Provider Adapters + Failover + Audit)
CREATE TABLE IF NOT EXISTS public.storage_providers (
  provider_id TEXT PRIMARY KEY,
  provider_name TEXT NOT NULL,
  provider_type TEXT NOT NULL CHECK (provider_type IN ('SUPABASE_STORAGE', 'S3_COMPATIBLE', 'CLOUDFLARE_R2', 'GOOGLE_CLOUD_STORAGE', 'FIREBASE_LEGACY')),
  endpoint_url TEXT NOT NULL,
  public_anon_key TEXT NOT NULL DEFAULT '',
  proxy_upload_url TEXT NOT NULL DEFAULT '',
  bucket_community TEXT NOT NULL DEFAULT 'community-photos',
  bucket_technicians TEXT NOT NULL DEFAULT 'technician-photos',
  bucket_pdfs TEXT NOT NULL DEFAULT 'repair-pdfs',
  bucket_diagrams TEXT NOT NULL DEFAULT 'circuit-diagrams',
  bucket_verification TEXT NOT NULL DEFAULT 'verification-documents',
  role TEXT NOT NULL DEFAULT 'BACKUP' CHECK (role IN ('PRIMARY', 'BACKUP', 'DISABLED')),
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  capacity_limit_bytes BIGINT NOT NULL DEFAULT 1073741824, -- 1 GB Supabase Free Plan default
  used_bytes BIGINT NOT NULL DEFAULT 0,
  last_status TEXT NOT NULL DEFAULT 'UNTESTED',
  last_checked_at TIMESTAMPTZ,
  updated_by_uid TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.storage_files (
  file_id TEXT PRIMARY KEY,
  provider_id TEXT NOT NULL,
  bucket_name TEXT NOT NULL,
  object_path TEXT NOT NULL,
  public_url TEXT NOT NULL DEFAULT '',
  mime_type TEXT NOT NULL DEFAULT '',
  size_bytes BIGINT NOT NULL DEFAULT 0,
  uploaded_by_uid TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.storage_upload_history (
  upload_id TEXT PRIMARY KEY,
  provider_id TEXT NOT NULL,
  bucket_name TEXT NOT NULL,
  object_path TEXT NOT NULL,
  public_url TEXT NOT NULL DEFAULT '',
  mime_type TEXT NOT NULL DEFAULT '',
  size_bytes BIGINT NOT NULL DEFAULT 0,
  failover_used BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'SUCCESS',
  uploaded_by_uid TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.storage_error_logs (
  error_id TEXT PRIMARY KEY,
  provider_id TEXT NOT NULL,
  bucket_name TEXT NOT NULL DEFAULT '',
  object_path TEXT NOT NULL DEFAULT '',
  error_code TEXT NOT NULL DEFAULT '',
  error_message TEXT NOT NULL,
  failover_target_id TEXT NOT NULL DEFAULT '',
  actor_uid TEXT NOT NULL DEFAULT '',
  resolved BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. Remote Settings & Audit Logs
CREATE TABLE IF NOT EXISTS public.app_settings (
  setting_id TEXT PRIMARY KEY,
  config_type TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::JSONB,
  updated_by_uid TEXT NOT NULL DEFAULT '',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.audit_logs (
  log_id TEXT PRIMARY KEY,
  admin_uid TEXT NOT NULL,
  admin_email TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  result TEXT NOT NULL DEFAULT 'SUCCESS',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 13. Row Level Security Policies (Safe Defaults for Supabase Free Plan)
ALTER TABLE public.admin_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.repair_catalog_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.technicians ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.technician_verification_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.technical_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_user_restrictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.problem_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fcm_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.push_notification_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.storage_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.storage_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.storage_upload_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.storage_error_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Public read policies for non-sensitive published content
DROP POLICY IF EXISTS "public_read_published_catalog" ON public.repair_catalog_entries;
CREATE POLICY "public_read_published_catalog" ON public.repair_catalog_entries
  FOR SELECT USING (published = TRUE);

DROP POLICY IF EXISTS "public_read_active_technicians" ON public.technicians;
CREATE POLICY "public_read_active_technicians" ON public.technicians
  FOR SELECT USING (status = 'ACTIVE' AND blocked = FALSE);

DROP POLICY IF EXISTS "public_read_published_docs" ON public.technical_documents;
CREATE POLICY "public_read_published_docs" ON public.technical_documents
  FOR SELECT USING (published = TRUE);

DROP POLICY IF EXISTS "public_read_approved_posts" ON public.community_posts;
CREATE POLICY "public_read_approved_posts" ON public.community_posts
  FOR SELECT USING (approval_status = 'APPROVED');

DROP POLICY IF EXISTS "public_read_announcements" ON public.announcements;
CREATE POLICY "public_read_announcements" ON public.announcements
  FOR SELECT USING (TRUE);

DROP POLICY IF EXISTS "public_read_app_settings" ON public.app_settings;
CREATE POLICY "public_read_app_settings" ON public.app_settings
  FOR SELECT USING (setting_id IN ('global_config', 'admob_config', 'storage_config'));

--Note: Sensitive mutations and verification_requests are designed to pass through
--authenticated Supabase JWTs OR trusted Edge Functions using SUPABASE_SERVICE_ROLE_KEY.
--NEVER expose service_role in Android or web client bundles.

-- 14. Existing Supabase Storage Buckets (Inspect & Reuse Exact Names)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  ('community-photos', 'community-photos', TRUE, 5242880, ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp']),
  ('technician-photos', 'technician-photos', TRUE, 5242880, ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp']),
  ('repair-pdfs', 'repair-pdfs', TRUE, 20971520, ARRAY['application/pdf']),
  ('circuit-diagrams', 'circuit-diagrams', TRUE, 20971520, ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf']),
  ('verification-documents', 'verification-documents', FALSE, 10485760, ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf'])
ON CONFLICT (id) DO NOTHING;

-- Storage Object Policies for the 5 buckets
DROP POLICY IF EXISTS "public_read_media_buckets" ON storage.objects;
CREATE POLICY "public_read_media_buckets" ON storage.objects
  FOR SELECT USING (
    bucket_id IN ('community-photos', 'technician-photos', 'repair-pdfs', 'circuit-diagrams')
  );

-- Seed Primary Supabase Storage Provider row matching project xuakzzjtcgcvudkgxpbd
INSERT INTO public.storage_providers (
  provider_id, provider_name, provider_type, endpoint_url,
  bucket_community, bucket_technicians, bucket_pdfs, bucket_diagrams, bucket_verification,
  role, enabled, capacity_limit_bytes, last_status, updated_by_uid
) VALUES (
  'supabase_primary',
  'Supabase Primary Storage (Repair-Pro)',
  'SUPABASE_STORAGE',
  'https://xuakzzjtcgcvudkgxpbd.supabase.co',
  'community-photos',
  'technician-photos',
  'repair-pdfs',
  'circuit-diagrams',
  'verification-documents',
  'PRIMARY',
  TRUE,
  1073741824,
  'CONFIGURED',
  'bootstrap_admin'
) ON CONFLICT (provider_id) DO NOTHING;
