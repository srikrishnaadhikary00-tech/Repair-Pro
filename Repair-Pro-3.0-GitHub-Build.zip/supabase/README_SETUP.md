# Repair Pro v3.0 — Free-Tier Supabase + Firebase Setup Guide (No Credit Card Required)

This setup reuses your **existing** projects without enabling paid services or Firebase Blaze billing:

- **Firebase Project ID:** `gen-lang-client-0218221723` (Spark Plan)
- **Firestore Database ID:** `ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8`
- **Supabase Project Name:** `Repair-Pro` (Free Plan)
- **Supabase Project Reference:** `xuakzzjtcgcvudkgxpbd`
- **Supabase Project URL:** `https://xuakzzjtcgcvudkgxpbd.supabase.co`

---

## Step 1: Run the SQL Migration in Supabase Dashboard (Works on iPhone Safari)

1. Open [Supabase SQL Editor](https://supabase.com/dashboard/project/xuakzzjtcgcvudkgxpbd/sql/new).
2. Copy and run `supabase/migrations/20261124_repair_pro_v3_complete.sql`.
3. This preserves all existing data and buckets (`community-photos`, `repair-pdfs`, `circuit-diagrams`, `technician-photos`, `verification-documents`), enables Row Level Security (RLS), creates the private-document-safe `technician_public_directory` view, installs the `trg_prevent_delete_storage_provider_with_files` Postgres deletion guard, adds `sha256_checksum` migration tracking, and seeds the primary Supabase Storage provider.

## Step 2: Deploy Supabase Edge Functions (Free Tier)

In Google Cloud Shell (or any terminal with Supabase CLI):

```bash
supabase login
supabase link --project-ref xuakzzjtcgcvudkgxpbd
supabase functions deploy repair-pro-api --no-verify-jwt
supabase functions deploy send-push-notification --no-verify-jwt
```

## Step 3: Set Backend Secrets in Supabase (NEVER put in Android APK or Web Admin)

All Multi-Cloud storage credentials live exclusively in Supabase Edge Function secrets and are referenced only by `secret_env_key` in the database/Admin UI:

1. **Firebase Cloud Messaging HTTP v1** push notifications:
   - Open Firebase Console → Project Settings → Service Accounts → **Generate new private key** (JSON).
   ```bash
   supabase secrets set FIREBASE_SERVICE_ACCOUNT_JSON='{"type":"service_account",...}'
   ```
2. **Additional Supabase Storage Project** (`provider_type = SUPABASE`):
   ```bash
   supabase secrets set SUPABASE_BACKUP_1_KEY='<target-project-service-role-key>'
   ```
3. **Cloudflare R2** (`provider_type = CLOUDFLARE_R2`, AWS SigV4):
   ```bash
   supabase secrets set R2_STORAGE_CREDS='{"accessKeyId":"...","secretAccessKey":"...","region":"auto","publicBaseUrl":"https://cdn.example.com"}'
   ```
   *(Or set split secrets `R2_STORAGE_CREDS_ACCESS_KEY_ID` + `R2_STORAGE_CREDS_SECRET_ACCESS_KEY`.)*
4. **Backblaze B2** (`provider_type = BACKBLAZE_B2`):
   - **B2 Native API v2** (endpoint `https://api.backblazeb2.com`):
     ```bash
     supabase secrets set B2_STORAGE_CREDS='{"keyId":"...","applicationKey":"...","bucketId":"..."}'
     ```
   - **B2 S3-Compatible SigV4** (endpoint `https://s3.us-west-004.backblazeb2.com`):
     ```bash
     supabase secrets set B2_STORAGE_CREDS='{"accessKeyId":"...","secretAccessKey":"...","region":"us-west-004"}'
     ```
5. **Custom S3 / Amazon S3** (`provider_type = CUSTOM_S3`, AWS SigV4):
   ```bash
   supabase secrets set S3_STORAGE_CREDS='{"accessKeyId":"...","secretAccessKey":"...","region":"us-east-1"}'
   ```

> [!IMPORTANT]
> **Private Verification Documents:** Files uploaded to `verification-documents` are always stored with `is_private = true` and a `private://<providerId>/<bucket>/<path>` reference on every provider (`SUPABASE`, `CLOUDFLARE_R2`, `BACKBLAZE_B2`, `CUSTOM_S3`), ignoring any CDN/public URL. Only verified Super Admins can mint short-lived 120-second signed/presigned read URLs via `/admin/verification/signed-url`.
> **Safe Migration & Deletion:** `MIGRATE` downloads each source file, verifies SHA-256 checksums before and after writing to the target provider, updates `storage_file_registry` and linked `repair_documents`, rebalances `used_bytes`, and deletes the source copy only after verified commit. Providers with active files cannot be deleted via the API or SQL (`409 PROVIDER_HAS_ACTIVE_FILES`).

## Step 4: Configure Android Secrets in Google AI Studio

Open the **Secrets panel in AI Studio** and set:
- `SUPABASE_ANON_KEY` — Your Supabase publishable/anon key from Project Settings → API.
- `ADMOB_APP_ID` — Leave as `ca-app-pub-3940256099942544~3347511713` for testing, or set your production AdMob App ID for release builds.

## What Requires vs. Does NOT Require an Android APK Update

| Change | APK Update Required? |
|---|---|
| AdMob toggles, frequency caps, banner/interstitial/rewarded/native/app-open unit IDs, test mode | **No** (live remote sync) |
| Adding/editing Supabase, Cloudflare R2, Backblaze B2, or S3 providers, switching primary/backup, failover, or file migration | **No** (live via backend API) |
| New error codes, problems, multilingual guides, categories, announcements | **No** |
| New PDF manuals, circuit diagrams, community moderation, technician approval/verification | **No** |
| Push notifications (All / Selected / Technicians) | **No** |
| Changing `ADMOB_APP_ID` in `AndroidManifest.xml`, `versionCode`/`versionName`, native SDK versions, or new Android runtime permissions | **Yes** (new signed APK/AAB required by Android OS) |
