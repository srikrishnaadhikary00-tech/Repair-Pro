// Repair Pro — Secure Firebase Cloud Messaging (FCM HTTP v1) Edge Function
// Runs on Supabase Free Plan (Deno Edge Runtime).
// Required Supabase Edge Function Secrets (set in Supabase Dashboard -> Edge Functions -> Secrets):
//   FIREBASE_SERVICE_ACCOUNT_JSON  = Full JSON string of Firebase service account key (for gen-lang-client-0218221723)
//   FIREBASE_WEB_API_KEY           = AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M (optional, defaults to Repair Pro Web API key)
//
// NEVER put FIREBASE_SERVICE_ACCOUNT_JSON in Android app or web-admin frontend code.

const PROJECT_ID = "gen-lang-client-0218221723";
const FIRESTORE_DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
const DEFAULT_FIREBASE_WEB_API_KEY = "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M";

const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

function jsonResponse(status: number, payload: Record<string, unknown>): Response {
  return new Response(JSON.stringify(payload), { status, headers: corsHeaders });
}

function base64UrlEncode(input: Uint8Array | string): string {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  let binary = "";
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function pemToArrayBuffer(pem: string): ArrayBuffer {
  const clean = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s+/g, "");
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

async function getGoogleAccessToken(serviceAccount: {
  client_email: string;
  private_key: string;
  token_uri?: string;
}): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlEncode(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claimSet = base64UrlEncode(
    JSON.stringify({
      iss: serviceAccount.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging https://www.googleapis.com/auth/datastore",
      aud: serviceAccount.token_uri || "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600
    })
  );
  const signingInput = `${header}.${claimSet}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToArrayBuffer(serviceAccount.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    key,
    new TextEncoder().encode(signingInput)
  );
  const jwt = `${signingInput}.${base64UrlEncode(new Uint8Array(signature))}`;

  const tokenResp = await fetch(serviceAccount.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  const tokenData = await tokenResp.json();
  if (!tokenResp.ok || !tokenData.access_token) {
    throw new Error(`OAuth2 token exchange failed: ${tokenData.error_description || tokenData.error || tokenResp.status}`);
  }
  return tokenData.access_token;
}

async function verifyFirebaseIdToken(idToken: string): Promise<{ uid: string; email: string; emailVerified: boolean }> {
  const webApiKey = Deno.env.get("FIREBASE_WEB_API_KEY") || DEFAULT_FIREBASE_WEB_API_KEY;
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(webApiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken })
  });
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(data?.error?.message || "Invalid or expired Firebase ID token.");
  }
  const user = data.users[0];
  return {
    uid: String(user.localId || ""),
    email: String(user.email || ""),
    emailVerified: Boolean(user.emailVerified)
  };
}

async function isAuthorizedAdmin(uid: string, email: string, emailVerified: boolean, googleAccessToken: string): Promise<boolean> {
  if (emailVerified && email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) {
    return true;
  }
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/admins/${encodeURIComponent(uid)}`;
  const resp = await fetch(url, {
    headers: { Authorization: `Bearer ${googleAccessToken}` }
  });
  return resp.ok;
}

function extractStringField(fields: Record<string, Record<string, unknown>> | undefined, key: string): string {
  const val = fields?.[key]?.stringValue;
  return typeof val === "string" ? val : "";
}

async function fetchUserTokens(uid: string, googleAccessToken: string): Promise<string[]> {
  const safeUid = uid.replace(/[^a-zA-Z0-9_\-]/g, "");
  if (!safeUid) return [];
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/users/${encodeURIComponent(safeUid)}/fcm_tokens?pageSize=20`;
  const resp = await fetch(url, {
    headers: { Authorization: `Bearer ${googleAccessToken}` }
  });
  if (!resp.ok) return [];
  const data = await resp.json();
  const docs = Array.isArray(data.documents) ? data.documents : [];
  return docs
    .map((d: { fields?: Record<string, Record<string, unknown>> }) => extractStringField(d.fields, "token"))
    .filter((t: string) => t.length >= 10);
}

async function resolveTargetTokens(
  audience: string,
  targetUids: string[],
  explicitTokens: string[],
  googleAccessToken: string
): Promise<string[]> {
  const tokenSet = new Set<string>(explicitTokens.filter((t) => typeof t === "string" && t.length >= 10));

  if (audience === "SELECTED") {
    for (const uid of targetUids.slice(0, 200)) {
      const tokens = await fetchUserTokens(uid, googleAccessToken);
      tokens.forEach((t) => tokenSet.add(t));
    }
    return Array.from(tokenSet);
  }

  if (audience === "TECHNICIANS") {
    const uidSet = new Set<string>();
    const techResp = await fetch(
      `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/technicians?pageSize=200`,
      { headers: { Authorization: `Bearer ${googleAccessToken}` } }
    );
    if (techResp.ok) {
      const techData = await techResp.json();
      for (const doc of techData.documents || []) {
        const linkedUid = extractStringField(doc.fields, "linkedUserUid");
        if (linkedUid) uidSet.add(linkedUid);
      }
    }
    const verResp = await fetch(
      `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/technician_verification_requests?pageSize=200`,
      { headers: { Authorization: `Bearer ${googleAccessToken}` } }
    );
    if (verResp.ok) {
      const verData = await verResp.json();
      for (const doc of verData.documents || []) {
        if (extractStringField(doc.fields, "status") === "VERIFIED") {
          const userId = extractStringField(doc.fields, "userId");
          if (userId) uidSet.add(userId);
        }
      }
    }
    for (const uid of uidSet) {
      const tokens = await fetchUserTokens(uid, googleAccessToken);
      tokens.forEach((t) => tokenSet.add(t));
    }
    return Array.from(tokenSet);
  }

  // Default: ALL via Firestore CollectionGroup query on fcm_tokens
  const runQueryUrl = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents:runQuery`;
  const qResp = await fetch(runQueryUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${googleAccessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId: "fcm_tokens", allDescendants: true }],
        limit: 500
      }
    })
  });
  if (qResp.ok) {
    const rows = await qResp.json();
    if (Array.isArray(rows)) {
      for (const row of rows) {
        const token = extractStringField(row?.document?.fields, "token");
        if (token.length >= 10) tokenSet.add(token);
      }
    }
  }
  return Array.from(tokenSet);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return jsonResponse(405, { ok: false, errorCode: "METHOD_NOT_ALLOWED", message: "Use POST." });
  }

  try {
    const authHeader = req.headers.get("authorization") || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    if (!idToken) {
      return jsonResponse(401, {
        ok: false,
        errorCode: "MISSING_AUTH_TOKEN",
        message: "Missing Firebase ID Bearer token. Your session was NOT signed out."
      });
    }

    let caller: { uid: string; email: string; emailVerified: boolean };
    try {
      caller = await verifyFirebaseIdToken(idToken);
    } catch (authErr) {
      return jsonResponse(401, {
        ok: false,
        errorCode: "INVALID_AUTH_TOKEN",
        message: authErr instanceof Error ? authErr.message : "Firebase token verification failed."
      });
    }

    const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
    if (!saRaw.trim()) {
      return jsonResponse(503, {
        ok: false,
        errorCode: "FCM_SERVICE_ACCOUNT_NOT_CONFIGURED",
        message: "FIREBASE_SERVICE_ACCOUNT_JSON secret is not configured in Supabase Edge Function secrets yet."
      });
    }

    const serviceAccount = JSON.parse(saRaw);
    const googleAccessToken = await getGoogleAccessToken(serviceAccount);

    const allowed = await isAuthorizedAdmin(caller.uid, caller.email, caller.emailVerified, googleAccessToken);
    if (!allowed) {
      return jsonResponse(403, {
        ok: false,
        errorCode: "FORBIDDEN",
        message: "Account does not have Super Admin permission in Firestore admins/ collection."
      });
    }

    const body = await req.json();
    const audience = ["ALL", "SELECTED", "TECHNICIANS"].includes(body?.audience) ? body.audience : "ALL";
    const title = String(body?.title || "").trim().slice(0, 140);
    const message = String(body?.message || body?.body || "").trim().slice(0, 1200);
    const imageUrl = typeof body?.imageUrl === "string" && body.imageUrl.startsWith("https://")
      ? body.imageUrl.trim().slice(0, 1000)
      : "";
    const route = String(body?.route || body?.targetRoute || "notifications").trim().slice(0, 160);
    const channel = String(body?.channel || "announcements").trim().slice(0, 40);
    const eventType = String(body?.eventType || "ANNOUNCEMENT").trim().slice(0, 64);
    const targetUids = Array.isArray(body?.targetUids) ? body.targetUids.map(String) : [];
    const explicitTokens = Array.isArray(body?.tokens) ? body.tokens.map(String) : [];

    if (title.length < 2 || message.length < 2) {
      return jsonResponse(400, {
        ok: false,
        errorCode: "VALIDATION_ERROR",
        message: "Notification title and message are required."
      });
    }

    const tokens = await resolveTargetTokens(audience, targetUids, explicitTokens, googleAccessToken);
    if (tokens.length === 0) {
      return jsonResponse(200, {
        ok: true,
        deliveryStatus: "IN_APP_ONLY",
        sentCount: 0,
        failedCount: 0,
        totalTargets: 0,
        message: "No registered Android FCM tokens matched the target audience yet."
      });
    }

    const androidChannelId = channel === "community"
      ? "repair_pro_community"
      : channel === "verification"
        ? "repair_pro_verification"
        : "repair_pro_announcements";

    let sentCount = 0;
    let failedCount = 0;
    const errors: string[] = [];

    const fcmEndpoint = `https://fcm.googleapis.com/v1/projects/${PROJECT_ID}/messages:send`;
    for (const token of tokens) {
      const fcmBody: Record<string, unknown> = {
        message: {
          token,
          notification: {
            title,
            body: message,
            ...(imageUrl ? { image: imageUrl } : {})
          },
          data: {
            title,
            body: message,
            channel,
            route,
            imageUrl,
            eventType
          },
          android: {
            priority: "HIGH",
            notification: {
              channel_id: androidChannelId,
              ...(imageUrl ? { image: imageUrl } : {})
            }
          }
        }
      };

      const res = await fetch(fcmEndpoint, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${googleAccessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(fcmBody)
      });

      if (res.ok) {
        sentCount += 1;
      } else {
        failedCount += 1;
        const errPayload = await res.json().catch(() => ({}));
        const detail = errPayload?.error?.message || `HTTP ${res.status}`;
        if (errors.length < 5) errors.push(detail);
      }
    }

    const deliveryStatus = sentCount > 0 && failedCount === 0
      ? "SENT"
      : sentCount > 0
        ? "PARTIAL"
        : "FAILED";

    return jsonResponse(200, {
      ok: sentCount > 0,
      deliveryStatus,
      sentCount,
      failedCount,
      totalTargets: tokens.length,
      errors
    });
  } catch (err) {
    return jsonResponse(500, {
      ok: false,
      errorCode: "INTERNAL_ERROR",
      message: err instanceof Error ? err.message : "Unexpected FCM dispatch error"
    });
  }
});
