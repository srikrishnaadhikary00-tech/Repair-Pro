// Repair Pro — Admin User Management, Custom Claims Sync, Account Deletion & Private Signed-URL Edge Function
// Uses Firebase Auth ONLY for authentication/claims/deletion and Supabase Postgres/Storage for all app data.
// Required Supabase Edge Function Secrets:
//   FIREBASE_SERVICE_ACCOUNT_JSON  = Full JSON of Firebase service account (gen-lang-client-0218221723)
//   SUPABASE_URL                   = https://xuakzzjtcgcvudkgxpbd.supabase.co
//   SUPABASE_SERVICE_ROLE_KEY      = Service role key (server-side ONLY; NEVER in APK or Web Admin)
// Optional:
//   FIREBASE_WEB_API_KEY           = AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M

const PROJECT_ID = "gen-lang-client-0218221723";
const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
const DEFAULT_FIREBASE_WEB_API_KEY = "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M";
const DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";

const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

function jsonResponse(status: number, payload: Record<string, unknown>): Response {
  return new Response(JSON.stringify(payload), { status, headers: corsHeaders });
}

interface VerifiedCaller {
  uid: string;
  email: string;
  emailVerified: boolean;
  claims: Record<string, unknown>;
}

function getSupabaseServiceEnv() {
  const url = (Deno.env.get("SUPABASE_URL") || DEFAULT_SUPABASE_URL).replace(/\/+$/, "");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  return { url, serviceKey };
}

async function supabaseRequest(path: string, init: RequestInit = {}): Promise<Response> {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey) {
    throw new Error("SUPABASE_SERVICE_ROLE_KEY is missing in Edge Function secrets.");
  }
  const headers = new Headers(init.headers || {});
  headers.set("apikey", serviceKey);
  headers.set("Authorization", `Bearer ${serviceKey}`);
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  return await fetch(`${url}${path}`, { ...init, headers });
}

async function verifyFirebaseIdToken(idToken: string): Promise<VerifiedCaller> {
  const webApiKey = Deno.env.get("FIREBASE_WEB_API_KEY") || DEFAULT_FIREBASE_WEB_API_KEY;
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(webApiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken })
  });
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(data?.error?.message || "Invalid or expired Firebase ID token.");
  }
  const user = data.users[0];
  let claims: Record<string, unknown> = {};
  if (typeof user.customAttributes === "string" && user.customAttributes.trim()) {
    try {
      claims = JSON.parse(user.customAttributes);
    } catch {
      claims = {};
    }
  }
  return {
    uid: String(user.localId || ""),
    email: String(user.email || ""),
    emailVerified: Boolean(user.emailVerified),
    claims
  };
}

function base64UrlEncode(input: Uint8Array | string): string {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function pemToArrayBuffer(pem: string): ArrayBuffer {
  const clean = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s+/g, "");
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function getGoogleIdentityToken(
  serviceAccount: { client_email: string; private_key: string; token_uri?: string }
): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlEncode(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claimSet = base64UrlEncode(JSON.stringify({
    iss: serviceAccount.client_email,
    scope: "https://www.googleapis.com/auth/identitytoolkit",
    aud: serviceAccount.token_uri || "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600
  }));
  const signingInput = `${header}.${claimSet}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToArrayBuffer(serviceAccount.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(signingInput));
  const jwt = `${signingInput}.${base64UrlEncode(new Uint8Array(signature))}`;
  const resp = await fetch(serviceAccount.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt })
  });
  const data = await resp.json();
  if (!resp.ok || !data.access_token) throw new Error("Google OAuth2 failed");
  return data.access_token;
}

async function isAuthorizedAdmin(caller: VerifiedCaller): Promise<boolean> {
  if (caller.emailVerified && caller.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) return true;
  if (caller.claims?.admin === true || caller.claims?.repairproRole === "SUPER_ADMIN") return true;
  try {
    const resp = await supabaseRequest(
      `/rest/v1/admin_roles?user_id=eq.${encodeURIComponent(caller.uid)}&select=user_id,role&limit=1`
    );
    if (!resp.ok) return false;
    const rows = await resp.json();
    return Array.isArray(rows) && rows.length > 0;
  } catch {
    return false;
  }
}

async function setFirebaseCustomClaims(
  uid: string,
  claims: Record<string, unknown>,
  googleAccessToken: string,
  disableUser?: boolean
): Promise<void> {
  const payload: Record<string, unknown> = {
    localId: uid,
    customAttributes: JSON.stringify(claims)
  };
  if (typeof disableUser === "boolean") {
    payload.disableUser = disableUser;
  }
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts:update`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${googleAccessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err?.error?.message || `Failed to update Firebase custom claims (HTTP ${resp.status})`);
  }
}

async function writeAuditLogToSupabase(
  adminUid: string,
  adminEmail: string,
  action: string,
  targetType: string,
  targetId: string,
  details: string,
  result: "SUCCESS" | "FAILED"
): Promise<void> {
  const logId = `audit_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  await supabaseRequest("/rest/v1/audit_logs", {
    method: "POST",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify({
      log_id: logId,
      admin_uid: adminUid,
      admin_email: adminEmail || "admin@repairpro",
      action: action.slice(0, 100),
      target_type: targetType.slice(0, 64),
      target_id: targetId.slice(0, 128),
      details: details.slice(0, 500),
      result,
      created_at: new Date().toISOString()
    })
  }).catch(() => {});
}

async function purgeUserRowsInSupabase(targetUid: string): Promise<void> {
  const encoded = encodeURIComponent(targetUid);
  const cleanupPaths = [
    `/rest/v1/saved_guides?user_id=eq.${encoded}`,
    `/rest/v1/read_announcements?user_id=eq.${encoded}`,
    `/rest/v1/fcm_tokens?user_id=eq.${encoded}`,
    `/rest/v1/user_notifications?recipient_uid=eq.${encoded}`,
    `/rest/v1/community_bookmarks?user_id=eq.${encoded}`,
    `/rest/v1/community_likes?user_id=eq.${encoded}`,
    `/rest/v1/community_user_restrictions?user_id=eq.${encoded}`,
    `/rest/v1/technician_verification_requests?user_id=eq.${encoded}`,
    `/rest/v1/problem_reports?user_id=eq.${encoded}`,
    `/rest/v1/user_profiles?user_id=eq.${encoded}`
  ];
  await Promise.all(
    cleanupPaths.map((p) => supabaseRequest(p, { method: "DELETE" }).catch(() => null))
  );
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse(405, { ok: false, errorCode: "METHOD_NOT_ALLOWED", message: "Use POST." });

  try {
    const authHeader = req.headers.get("authorization") || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    if (!idToken) return jsonResponse(401, { ok: false, errorCode: "MISSING_AUTH_TOKEN", message: "Firebase Bearer token required." });

    const caller = await verifyFirebaseIdToken(idToken);
    const body = await req.json();
    const action = String(body?.action || "").trim().toLowerCase();

    // 1. Short-lived signed URL generation for private verification-documents (owner or admin)
    if (action === "create_signed_url") {
      const bucket = String(body?.bucket || "verification-documents").replace(/[^a-zA-Z0-9_-]/g, "");
      const storagePath = String(body?.storagePath || "").replace(/^\/+/, "").trim();
      const expiresIn = Math.min(300, Math.max(30, Number(body?.expiresIn || 120)));
      if (!storagePath || storagePath.includes("..")) {
        return jsonResponse(400, { ok: false, errorCode: "INVALID_PATH", message: "Valid storagePath required." });
      }
      const cleanPath = storagePath.startsWith(`${bucket}/`) ? storagePath.slice(bucket.length + 1) : storagePath;
      const admin = await isAuthorizedAdmin(caller);
      const isOwner = cleanPath.startsWith(`${caller.uid}/`) || cleanPath.startsWith(`${caller.uid}_`);
      if (!admin && !isOwner) {
        return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Not authorized to access this private file." });
      }
      const { url: supabaseUrl } = getSupabaseServiceEnv();
      const signResp = await supabaseRequest(
        `/storage/v1/object/sign/${encodeURIComponent(bucket)}/${cleanPath.split("/").map(encodeURIComponent).join("/")}`,
        {
          method: "POST",
          body: JSON.stringify({ expiresIn })
        }
      );
      const signJson = await signResp.json().catch(() => ({}));
      if (!signResp.ok || !signJson?.signedURL) {
        return jsonResponse(signResp.status || 502, {
          ok: false,
          errorCode: "SIGN_URL_FAILED",
          message: signJson?.message || signJson?.error || `Failed to create signed URL (HTTP ${signResp.status})`
        });
      }
      const signedPath = String(signJson.signedURL);
      const signedUrl = signedPath.startsWith("http")
        ? signedPath
        : `${supabaseUrl}/storage/v1${signedPath.startsWith("/") ? "" : "/"}${signedPath}`;
      return jsonResponse(200, { ok: true, signedUrl, expiresIn });
    }

    // 2. Self-service account data purge + Firebase Auth deletion
    if (action === "delete_my_account") {
      await purgeUserRowsInSupabase(caller.uid);
      const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
      if (saRaw.trim()) {
        try {
          const googleAccessToken = await getGoogleIdentityToken(JSON.parse(saRaw));
          await fetch(`https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts:delete`, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${googleAccessToken}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ localId: caller.uid })
          });
        } catch {
          // Client fallback FirebaseAuth.currentUser?.delete() handles auth account deletion if needed
        }
      }
      return jsonResponse(200, { ok: true, uid: caller.uid, deleted: true });
    }

    const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
    if (!saRaw.trim()) {
      return jsonResponse(503, {
        ok: false,
        errorCode: "SERVICE_ACCOUNT_MISSING",
        message: "FIREBASE_SERVICE_ACCOUNT_JSON secret is required for user/claim management."
      });
    }
    const googleAccessToken = await getGoogleIdentityToken(JSON.parse(saRaw));

    // 3. Self-sync custom claims on login (reads moderation flags from Supabase user_profiles)
    if (action === "sync_my_claims") {
      const admin = await isAuthorizedAdmin(caller);
      let blocked = false;
      let suspended = false;
      let communityRestricted = false;
      let uploadRestricted = false;
      const profileResp = await supabaseRequest(
        `/rest/v1/user_profiles?user_id=eq.${encodeURIComponent(caller.uid)}&select=blocked,suspended,community_restricted,upload_restricted&limit=1`
      ).catch(() => null);
      if (profileResp && profileResp.ok) {
        const rows = await profileResp.json().catch(() => []);
        if (Array.isArray(rows) && rows[0]) {
          blocked = Boolean(rows[0].blocked);
          suspended = Boolean(rows[0].suspended);
          communityRestricted = Boolean(rows[0].community_restricted);
          uploadRestricted = Boolean(rows[0].upload_restricted);
        }
      }
      const nextClaims = {
        role: "authenticated",
        admin,
        repairproRole: admin ? "SUPER_ADMIN" : "USER",
        blocked: admin ? false : blocked,
        suspended: admin ? false : suspended,
        communityRestricted: admin ? false : communityRestricted,
        uploadRestricted: admin ? false : uploadRestricted
      };
      await setFirebaseCustomClaims(caller.uid, nextClaims, googleAccessToken);
      return jsonResponse(200, { ok: true, claims: nextClaims, requiresTokenRefresh: true });
    }

    // All remaining actions strictly require Admin authorization
    const isAdminCaller = await isAuthorizedAdmin(caller);
    if (!isAdminCaller) {
      return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Super Admin permission required." });
    }

    // 4. Moderate user + synchronize Firebase custom claims & Supabase user_profiles
    if (action === "moderate_user" || action === "set_custom_claims") {
      const targetUid = String(body?.targetUid || "").trim();
      if (!targetUid || !/^[a-zA-Z0-9_-]{1,128}$/.test(targetUid)) {
        return jsonResponse(400, { ok: false, errorCode: "INVALID_UID", message: "Valid targetUid required." });
      }
      if (targetUid === caller.uid && (body?.blocked === true || body?.suspended === true)) {
        return jsonResponse(400, { ok: false, errorCode: "SELF_LOCK_FORBIDDEN", message: "Cannot block or suspend your own admin account." });
      }

      const blocked = Boolean(body?.blocked);
      const suspended = Boolean(body?.suspended);
      const communityRestricted = Boolean(body?.communityRestricted);
      const uploadRestricted = Boolean(body?.uploadRestricted);
      const makeAdmin = Boolean(body?.admin);
      const reason = String(body?.reason || "").trim().slice(0, 500);
      const accountStatus = blocked ? "BLOCKED" : suspended ? "SUSPENDED" : "ACTIVE";
      const nowIso = new Date().toISOString();

      const claims = {
        role: "authenticated",
        admin: makeAdmin,
        repairproRole: makeAdmin ? "SUPER_ADMIN" : "USER",
        blocked,
        suspended,
        communityRestricted,
        uploadRestricted
      };

      await setFirebaseCustomClaims(targetUid, claims, googleAccessToken, blocked);

      const upsertResp = await supabaseRequest("/rest/v1/user_profiles?on_conflict=user_id", {
        method: "POST",
        headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
        body: JSON.stringify({
          user_id: targetUid,
          account_status: accountStatus,
          blocked,
          suspended,
          community_restricted: communityRestricted,
          upload_restricted: uploadRestricted,
          moderation_reason: reason,
          moderated_by_uid: caller.uid,
          moderated_at: nowIso,
          updated_at: nowIso
        })
      });
      if (!upsertResp.ok) {
        const errText = await upsertResp.text().catch(() => "");
        throw new Error(`Supabase user_profiles update failed (HTTP ${upsertResp.status}): ${errText.slice(0, 180)}`);
      }

      if (communityRestricted) {
        await supabaseRequest("/rest/v1/community_user_restrictions?on_conflict=user_id", {
          method: "POST",
          headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
          body: JSON.stringify({
            user_id: targetUid,
            user_name: String(body?.userName || targetUid),
            reason: reason || "Restricted by administrator",
            blocked_by_uid: caller.uid,
            created_at: nowIso
          })
        }).catch(() => {});
      } else {
        await supabaseRequest(`/rest/v1/community_user_restrictions?user_id=eq.${encodeURIComponent(targetUid)}`, {
          method: "DELETE"
        }).catch(() => {});
      }

      await writeAuditLogToSupabase(
        caller.uid,
        caller.email,
        blocked ? "BLOCK_USER" : suspended ? "SUSPEND_USER" : "MODERATE_USER",
        "users",
        targetUid,
        `status=${accountStatus}, communityRestricted=${communityRestricted}, uploadRestricted=${uploadRestricted}${reason ? `, reason=${reason}` : ""}`,
        "SUCCESS"
      );

      return jsonResponse(200, { ok: true, targetUid, accountStatus, claims });
    }

    // 5. Explicit permanent user account deletion (ONLY when confirmDelete === true)
    if (action === "delete_user_account") {
      const targetUid = String(body?.targetUid || "").trim();
      const confirmDelete = body?.confirmDelete === true;
      if (!confirmDelete || !targetUid || targetUid === caller.uid) {
        return jsonResponse(400, {
          ok: false,
          errorCode: "CONFIRMATION_REQUIRED",
          message: "Explicit confirmDelete=true and non-self targetUid are required."
        });
      }

      const delAuthResp = await fetch(`https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts:delete`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${googleAccessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ localId: targetUid })
      });
      if (!delAuthResp.ok) {
        const err = await delAuthResp.json().catch(() => ({}));
        await writeAuditLogToSupabase(
          caller.uid,
          caller.email,
          "DELETE_USER_ACCOUNT",
          "users",
          targetUid,
          `Firebase Auth delete failed: ${err?.error?.message || delAuthResp.status}`,
          "FAILED"
        );
        return jsonResponse(502, {
          ok: false,
          errorCode: "DELETE_AUTH_FAILED",
          message: err?.error?.message || `Failed to delete Firebase Auth user (HTTP ${delAuthResp.status})`
        });
      }

      await purgeUserRowsInSupabase(targetUid);
      await writeAuditLogToSupabase(
        caller.uid,
        caller.email,
        "DELETE_USER_ACCOUNT",
        "users",
        targetUid,
        "Permanently deleted Firebase Auth account and Supabase user profile/data",
        "SUCCESS"
      );
      return jsonResponse(200, { ok: true, targetUid, deleted: true });
    }

    return jsonResponse(400, { ok: false, errorCode: "UNKNOWN_ACTION", message: "Unsupported action." });
  } catch (err) {
    return jsonResponse(500, {
      ok: false,
      errorCode: "INTERNAL_ERROR",
      message: err instanceof Error ? err.message : "Admin user management error"
    });
  }
});
