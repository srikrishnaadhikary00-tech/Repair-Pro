// Repair Pro — Admin User Management, Custom Claims Sync & Private Signed-URL Edge Function
// Runs on Supabase Free Plan (Deno Edge Runtime).
// Required Supabase Edge Function Secrets:
//   FIREBASE_SERVICE_ACCOUNT_JSON  = Full JSON of Firebase service account (gen-lang-client-0218221723)
//   SUPABASE_URL                   = https://xuakzzjtcgcvudkgxpbd.supabase.co
//   SUPABASE_SERVICE_ROLE_KEY      = Service role key (server-side ONLY; NEVER in APK or Web Admin)
// Optional:
//   FIREBASE_WEB_API_KEY           = AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M

const PROJECT_ID = "gen-lang-client-0218221723";
const FIRESTORE_DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
const DEFAULT_FIREBASE_WEB_API_KEY = "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M";
const DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";

const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

function jsonResponse(status: number, payload: Record<string, unknown>): Response {
  return new Response(JSON.stringify(payload), { status, headers: corsHeaders });
}

interface VerifiedCaller {
  uid: string;
  email: string;
  emailVerified: boolean;
  claims: Record<string, unknown>;
}

async function verifyFirebaseIdToken(idToken: string): Promise<VerifiedCaller> {
  const webApiKey = Deno.env.get("FIREBASE_WEB_API_KEY") || DEFAULT_FIREBASE_WEB_API_KEY;
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(webApiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken })
  });
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(data?.error?.message || "Invalid or expired Firebase ID token.");
  }
  const user = data.users[0];
  let claims: Record<string, unknown> = {};
  if (typeof user.customAttributes === "string" && user.customAttributes.trim()) {
    try {
      claims = JSON.parse(user.customAttributes);
    } catch {
      claims = {};
    }
  }
  return {
    uid: String(user.localId || ""),
    email: String(user.email || ""),
    emailVerified: Boolean(user.emailVerified),
    claims
  };
}

function base64UrlEncode(input: Uint8Array | string): string {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function pemToArrayBuffer(pem: string): ArrayBuffer {
  const clean = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s+/g, "");
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function getGoogleAccessToken(
  serviceAccount: { client_email: string; private_key: string; token_uri?: string },
  scopes = "https://www.googleapis.com/auth/datastore https://www.googleapis.com/auth/identitytoolkit"
): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlEncode(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claimSet = base64UrlEncode(JSON.stringify({
    iss: serviceAccount.client_email,
    scope: scopes,
    aud: serviceAccount.token_uri || "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600
  }));
  const signingInput = `${header}.${claimSet}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToArrayBuffer(serviceAccount.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(signingInput));
  const jwt = `${signingInput}.${base64UrlEncode(new Uint8Array(signature))}`;
  const resp = await fetch(serviceAccount.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt })
  });
  const data = await resp.json();
  if (!resp.ok || !data.access_token) throw new Error("Google OAuth2 failed");
  return data.access_token;
}

async function isAuthorizedAdmin(caller: VerifiedCaller, googleAccessToken?: string): Promise<boolean> {
  if (caller.emailVerified && caller.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) return true;
  if (caller.claims?.admin === true || caller.claims?.repairproRole === "SUPER_ADMIN") return true;
  let token = googleAccessToken;
  if (!token) {
    const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
    if (!saRaw.trim()) return false;
    try {
      token = await getGoogleAccessToken(JSON.parse(saRaw));
    } catch {
      return false;
    }
  }
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/admins/${encodeURIComponent(caller.uid)}`;
    const resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    return resp.ok;
  } catch {
    return false;
  }
}

async function setFirebaseCustomClaims(
  uid: string,
  claims: Record<string, unknown>,
  googleAccessToken: string,
  disableUser?: boolean
): Promise<void> {
  const payload: Record<string, unknown> = {
    localId: uid,
    customAttributes: JSON.stringify(claims)
  };
  if (typeof disableUser === "boolean") {
    payload.disableUser = disableUser;
  }
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts:update`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${googleAccessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err?.error?.message || `Failed to update Firebase custom claims (HTTP ${resp.status})`);
  }
}

async function updateFirestoreUserModeration(
  uid: string,
  fields: Record<string, unknown>,
  googleAccessToken: string
): Promise<void> {
  const docUrl = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/users/${encodeURIComponent(uid)}`;
  const fieldMaskParams = Object.keys(fields).map((k) => `updateMask.fieldPaths=${encodeURIComponent(k)}`).join("&");
  const firestoreFields: Record<string, unknown> = {};
  for (const [key, val] of Object.entries(fields)) {
    if (typeof val === "boolean") firestoreFields[key] = { booleanValue: val };
    else if (typeof val === "string") {
      if (key.endsWith("At") && /^\d{4}-\d{2}-\d{2}T/.test(val)) {
        firestoreFields[key] = { timestampValue: val };
      } else {
        firestoreFields[key] = { stringValue: val };
      }
    }
  }
  const resp = await fetch(`${docUrl}?${fieldMaskParams}`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${googleAccessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ fields: firestoreFields })
  });
  if (!resp.ok) {
    const text = await resp.text().catch(() => "");
    throw new Error(`Firestore user update failed (HTTP ${resp.status}): ${text.slice(0, 180)}`);
  }
}

async function writeAuditLogToFirestore(
  adminUid: string,
  adminEmail: string,
  action: string,
  targetType: string,
  targetId: string,
  details: string,
  result: "SUCCESS" | "FAILED",
  googleAccessToken: string
): Promise<void> {
  const logId = `audit_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const nowIso = new Date().toISOString();
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/audit_logs/${encodeURIComponent(logId)}`;
  await fetch(url, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${googleAccessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      fields: {
        adminUid: { stringValue: adminUid },
        adminEmail: { stringValue: adminEmail || "admin@repairpro" },
        action: { stringValue: action.slice(0, 100) },
        targetType: { stringValue: targetType.slice(0, 64) },
        targetId: { stringValue: targetId.slice(0, 128) },
        details: { stringValue: details.slice(0, 500) },
        result: { stringValue: result },
        createdAt: { timestampValue: nowIso }
      }
    })
  }).catch(() => {});
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse(405, { ok: false, errorCode: "METHOD_NOT_ALLOWED", message: "Use POST." });

  try {
    const authHeader = req.headers.get("authorization") || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    if (!idToken) return jsonResponse(401, { ok: false, errorCode: "MISSING_AUTH_TOKEN", message: "Firebase Bearer token required." });

    const caller = await verifyFirebaseIdToken(idToken);
    const body = await req.json();
    const action = String(body?.action || "").trim().toLowerCase();

    // 1. Short-lived signed URL generation for private verification-documents (owner or admin)
    if (action === "create_signed_url") {
      const bucket = String(body?.bucket || "verification-documents").replace(/[^a-zA-Z0-9_-]/g, "");
      const storagePath = String(body?.storagePath || "").replace(/^\/+/, "").trim();
      const expiresIn = Math.min(300, Math.max(30, Number(body?.expiresIn || 120)));
      if (!storagePath || storagePath.includes("..")) {
        return jsonResponse(400, { ok: false, errorCode: "INVALID_PATH", message: "Valid storagePath required." });
      }
      const cleanPath = storagePath.startsWith(`${bucket}/`) ? storagePath.slice(bucket.length + 1) : storagePath;
      const admin = await isAuthorizedAdmin(caller);
      const isOwner = cleanPath.startsWith(`${caller.uid}/`) || cleanPath.startsWith(`${caller.uid}_`);
      if (!admin && !isOwner) {
        return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Not authorized to access this private file." });
      }
      const supabaseUrl = (Deno.env.get("SUPABASE_URL") || DEFAULT_SUPABASE_URL).replace(/\/+$/, "");
      const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
      if (!serviceKey) {
        return jsonResponse(503, { ok: false, errorCode: "SERVICE_KEY_MISSING", message: "SUPABASE_SERVICE_ROLE_KEY not configured." });
      }
      const signResp = await fetch(`${supabaseUrl}/storage/v1/object/sign/${encodeURIComponent(bucket)}/${cleanPath.split("/").map(encodeURIComponent).join("/")}`, {
        method: "POST",
        headers: {
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ expiresIn })
      });
      const signJson = await signResp.json().catch(() => ({}));
      if (!signResp.ok || !signJson?.signedURL) {
        return jsonResponse(signResp.status || 502, {
          ok: false,
          errorCode: "SIGN_URL_FAILED",
          message: signJson?.message || signJson?.error || `Failed to create signed URL (HTTP ${signResp.status})`
        });
      }
      const signedPath = String(signJson.signedURL);
      const signedUrl = signedPath.startsWith("http")
        ? signedPath
        : `${supabaseUrl}/storage/v1${signedPath.startsWith("/") ? "" : "/"}${signedPath}`;
      return jsonResponse(200, { ok: true, signedUrl, expiresIn });
    }

    const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
    if (!saRaw.trim()) {
      return jsonResponse(503, {
        ok: false,
        errorCode: "SERVICE_ACCOUNT_MISSING",
        message: "FIREBASE_SERVICE_ACCOUNT_JSON secret is required for user/claim management."
      });
    }
    const googleAccessToken = await getGoogleAccessToken(JSON.parse(saRaw));

    // 2. Self-sync custom claims on login (sets Supabase required role='authenticated' + trusted admin/moderation claims)
    if (action === "sync_my_claims") {
      const admin = await isAuthorizedAdmin(caller, googleAccessToken);
      const userDocResp = await fetch(
        `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/users/${encodeURIComponent(caller.uid)}`,
        { headers: { Authorization: `Bearer ${googleAccessToken}` } }
      );
      let blocked = false;
      let suspended = false;
      let communityRestricted = false;
      let uploadRestricted = false;
      if (userDocResp.ok) {
        const u = await userDocResp.json();
        blocked = Boolean(u?.fields?.blocked?.booleanValue);
        suspended = Boolean(u?.fields?.suspended?.booleanValue);
        communityRestricted = Boolean(u?.fields?.communityRestricted?.booleanValue);
        uploadRestricted = Boolean(u?.fields?.uploadRestricted?.booleanValue);
      }
      const nextClaims = {
        role: "authenticated",
        admin,
        repairproRole: admin ? "SUPER_ADMIN" : "USER",
        blocked: admin ? false : blocked,
        suspended: admin ? false : suspended,
        communityRestricted: admin ? false : communityRestricted,
        uploadRestricted: admin ? false : uploadRestricted
      };
      await setFirebaseCustomClaims(caller.uid, nextClaims, googleAccessToken);
      return jsonResponse(200, { ok: true, claims: nextClaims, requiresTokenRefresh: true });
    }

    // All remaining actions strictly require Super Admin authorization
    const isAdminCaller = await isAuthorizedAdmin(caller, googleAccessToken);
    if (!isAdminCaller) {
      return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Super Admin permission required." });
    }

    // 3. Moderate user + synchronize Firebase custom claims & Supabase user_profiles
    if (action === "moderate_user" || action === "set_custom_claims") {
      const targetUid = String(body?.targetUid || "").trim();
      if (!targetUid || !/^[a-zA-Z0-9_-]{1,128}$/.test(targetUid)) {
        return jsonResponse(400, { ok: false, errorCode: "INVALID_UID", message: "Valid targetUid required." });
      }
      if (targetUid === caller.uid && (body?.blocked === true || body?.suspended === true)) {
        return jsonResponse(400, { ok: false, errorCode: "SELF_LOCK_FORBIDDEN", message: "Cannot block or suspend your own admin account." });
      }

      const blocked = Boolean(body?.blocked);
      const suspended = Boolean(body?.suspended);
      const communityRestricted = Boolean(body?.communityRestricted);
      const uploadRestricted = Boolean(body?.uploadRestricted);
      const makeAdmin = Boolean(body?.admin);
      const reason = String(body?.reason || "").trim().slice(0, 500);
      const accountStatus = blocked ? "BLOCKED" : suspended ? "SUSPENDED" : "ACTIVE";
      const nowIso = new Date().toISOString();

      const claims = {
        role: "authenticated",
        admin: makeAdmin,
        repairproRole: makeAdmin ? "SUPER_ADMIN" : "USER",
        blocked,
        suspended,
        communityRestricted,
        uploadRestricted
      };

      await setFirebaseCustomClaims(targetUid, claims, googleAccessToken, blocked);
      await updateFirestoreUserModeration(
        targetUid,
        {
          accountStatus,
          blocked,
          suspended,
          communityRestricted,
          uploadRestricted,
          moderationReason: reason,
          moderatedByUid: caller.uid,
          moderatedAt: nowIso,
          updatedAt: nowIso
        },
        googleAccessToken
      );

      // Mirror moderation state into Supabase user_profiles if table exists
      const supabaseUrl = (Deno.env.get("SUPABASE_URL") || DEFAULT_SUPABASE_URL).replace(/\/+$/, "");
      const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
      if (serviceKey) {
        await fetch(`${supabaseUrl}/rest/v1/user_profiles?user_id=eq.${encodeURIComponent(targetUid)}`, {
          method: "PATCH",
          headers: {
            apikey: serviceKey,
            Authorization: `Bearer ${serviceKey}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            account_status: accountStatus,
            blocked,
            suspended,
            community_restricted: communityRestricted,
            upload_restricted: uploadRestricted,
            moderation_reason: reason,
            moderated_by_uid: caller.uid,
            moderated_at: nowIso
          })
        }).catch(() => {});
      }

      await writeAuditLogToFirestore(
        caller.uid,
        caller.email,
        blocked ? "BLOCK_USER" : suspended ? "SUSPEND_USER" : "MODERATE_USER",
        "users",
        targetUid,
        `status=${accountStatus}, communityRestricted=${communityRestricted}, uploadRestricted=${uploadRestricted}${reason ? `, reason=${reason}` : ""}`,
        "SUCCESS",
        googleAccessToken
      );

      return jsonResponse(200, { ok: true, targetUid, accountStatus, claims });
    }

    // 4. Explicit permanent user account deletion (ONLY when confirmDelete === true; separate from block/suspend)
    if (action === "delete_user_account") {
      const targetUid = String(body?.targetUid || "").trim();
      const confirmDelete = body?.confirmDelete === true;
      if (!confirmDelete || !targetUid || targetUid === caller.uid) {
        return jsonResponse(400, {
          ok: false,
          errorCode: "CONFIRMATION_REQUIRED",
          message: "Explicit confirmDelete=true and non-self targetUid are required."
        });
      }

      const delAuthResp = await fetch(`https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts:delete`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${googleAccessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ localId: targetUid })
      });
      if (!delAuthResp.ok) {
        const err = await delAuthResp.json().catch(() => ({}));
        await writeAuditLogToFirestore(
          caller.uid,
          caller.email,
          "DELETE_USER_ACCOUNT",
          "users",
          targetUid,
          `Firebase Auth delete failed: ${err?.error?.message || delAuthResp.status}`,
          "FAILED",
          googleAccessToken
        );
        return jsonResponse(502, {
          ok: false,
          errorCode: "DELETE_AUTH_FAILED",
          message: err?.error?.message || `Failed to delete Firebase Auth user (HTTP ${delAuthResp.status})`
        });
      }

      await fetch(
        `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/users/${encodeURIComponent(targetUid)}`,
        { method: "DELETE", headers: { Authorization: `Bearer ${googleAccessToken}` } }
      ).catch(() => {});

      await writeAuditLogToFirestore(
        caller.uid,
        caller.email,
        "DELETE_USER_ACCOUNT",
        "users",
        targetUid,
        "Permanently deleted user Auth account and Firestore profile",
        "SUCCESS",
        googleAccessToken
      );
      return jsonResponse(200, { ok: true, targetUid, deleted: true });
    }

    return jsonResponse(400, { ok: false, errorCode: "UNKNOWN_ACTION", message: "Unsupported action." });
  } catch (err) {
    return jsonResponse(500, {
      ok: false,
      errorCode: "INTERNAL_ERROR",
      message: err instanceof Error ? err.message : "Admin user management error"
    });
  }
});
