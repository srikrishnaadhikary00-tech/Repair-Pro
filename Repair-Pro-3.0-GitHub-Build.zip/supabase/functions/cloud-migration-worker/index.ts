// Repair Pro — 24x7 Server-Side Automatic Cloud Migration & Safe Cleanup Worker
// Runs continuously on Supabase Edge Functions via `pg_cron` (`x-cron-secret` or service_role)
// OR triggered on-demand by an authenticated Super Admin from Web Admin Panel.
//
// Safe guarantees:
// - Never migrates or deletes data if `autoMigrationEnabled` is false (unless forceManual by Admin)
//   or if no healthy verified cPanel PHP Hosting target exists.
// - Enforces atomic execution locking (`acquire_cloud_scheduler_lock`).
// - Preserves essential auth/config/system records (`PROTECTED_TABLES`).
// - Verifies every storage file by SHA-256 checksum & byte size before marking VERIFIED.
// - Creates recoverable backup manifest before any cleanup.
// - Executes Supabase cleanup ONLY when `autoCleanupEnabled === true`, 0 failures, 100% verified,
//   backup manifest saved, and measures reclaimed capacity delta afterward.

const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
const DEFAULT_FIREBASE_WEB_API_KEY = "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M";
const DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";

const PROTECTED_TABLES = new Set([
  "admin_roles",
  "app_settings",
  "user_profiles",
  "fcm_tokens",
  "ai_providers",
  "ai_configs",
  "storage_providers",
  "hosting_provider_secrets",
  "cloud_manifest",
  "cloud_migration_runs",
  "cloud_migration_items",
  "cloud_backup_manifests",
  "cloud_scheduler_status",
  "audit_logs",
  "storage_error_logs"
]);

const MIGRATION_TABLES = [
  { table: "repair_catalog_entries", cpanelTable: "catalog_entries", pk: "id" },
  { table: "technicians", cpanelTable: "technicians", pk: "technician_id" },
  { table: "technician_verification_requests", cpanelTable: "technician_verification_requests", pk: "user_id" },
  { table: "community_posts", cpanelTable: "community_posts", pk: "post_id" },
  { table: "community_comments", cpanelTable: "community_comments", pk: "comment_id" },
  { table: "community_likes", cpanelTable: "community_likes", pk: "like_id" },
  { table: "community_bookmarks", cpanelTable: "community_bookmarks", pk: "bookmark_id" },
  { table: "community_reports", cpanelTable: "community_reports", pk: "report_id" },
  { table: "community_user_restrictions", cpanelTable: "community_user_restrictions", pk: "user_id" },
  { table: "technical_documents", cpanelTable: "technical_documents", pk: "doc_id" },
  { table: "problem_reports", cpanelTable: "problem_reports", pk: "report_id" },
  { table: "saved_guides", cpanelTable: "saved_guides", pk: "guide_id" }
];

const MIGRATION_BUCKETS = [
  { key: "community", bucket: "community-photos", isPrivate: false },
  { key: "technicians", bucket: "technician-photos", isPrivate: false },
  { key: "pdfs", bucket: "repair-pdfs", isPrivate: false },
  { key: "diagrams", bucket: "circuit-diagrams", isPrivate: false },
  { key: "verification", bucket: "verification-documents", isPrivate: true },
  { key: "user_profiles", bucket: "user-avatars", isPrivate: false }
];

const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

function jsonResponse(status: number, payload: Record<string, unknown>): Response {
  return new Response(JSON.stringify(payload), { status, headers: corsHeaders });
}

function getSupabaseEnv() {
  const url = (Deno.env.get("SUPABASE_URL") || DEFAULT_SUPABASE_URL).replace(/\/+$/, "");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  return { url, serviceKey };
}

async function supabaseServiceFetch(path: string, init: RequestInit = {}): Promise<Response> {
  const { url, serviceKey } = getSupabaseEnv();
  if (!serviceKey) {
    throw new Error("SUPABASE_SERVICE_ROLE_KEY secret is not configured.");
  }
  const headers = new Headers(init.headers || {});
  headers.set("apikey", serviceKey);
  headers.set("Authorization", `Bearer ${serviceKey}`);
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  return await fetch(`${url}${path}`, { ...init, headers });
}

async function supabaseRpc(fnName: string, params: Record<string, unknown> = {}): Promise<unknown> {
  const resp = await supabaseServiceFetch(`/rest/v1/rpc/${encodeURIComponent(fnName)}`, {
    method: "POST",
    body: JSON.stringify(params)
  });
  const text = await resp.text();
  let parsed: unknown = null;
  try { parsed = text ? JSON.parse(text) : null; } catch { parsed = text; }
  if (!resp.ok) {
    throw new Error(`RPC ${fnName} HTTP ${resp.status}: ${text.slice(0, 220)}`);
  }
  return parsed;
}

function constantTimeEqual(a: string, b: string): boolean {
  if (!a || !b || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

interface VerifiedCaller {
  uid: string;
  email: string;
  emailVerified: boolean;
  claims: Record<string, unknown>;
}

async function verifyFirebaseIdToken(idToken: string): Promise<VerifiedCaller> {
  const webApiKey = Deno.env.get("FIREBASE_WEB_API_KEY") || DEFAULT_FIREBASE_WEB_API_KEY;
  const resp = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(webApiKey)}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ idToken })
    }
  );
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(data?.error?.message || "Invalid or expired Firebase ID token.");
  }
  const user = data.users[0];
  let claims: Record<string, unknown> = {};
  if (typeof user.customAttributes === "string" && user.customAttributes.trim()) {
    try { claims = JSON.parse(user.customAttributes); } catch { claims = {}; }
  }
  return {
    uid: String(user.localId || ""),
    email: String(user.email || ""),
    emailVerified: Boolean(user.emailVerified),
    claims
  };
}

async function isAuthorizedAdmin(caller: VerifiedCaller): Promise<boolean> {
  if (caller.emailVerified && caller.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) return true;
  if (caller.claims?.admin === true || caller.claims?.repairproRole === "SUPER_ADMIN") return true;
  const resp = await supabaseServiceFetch(
    `/rest/v1/admin_roles?user_id=eq.${encodeURIComponent(caller.uid)}&select=user_id&limit=1`
  ).catch(() => null);
  if (!resp || !resp.ok) return false;
  const rows = await resp.json().catch(() => []);
  return Array.isArray(rows) && rows.length > 0;
}

function isIpv4Literal(host: string): boolean {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(host) || /^\d+$/.test(host) || /^0x[0-9a-f]+$/i.test(host);
}

function isPrivateOrBlockedHost(rawHost: string): boolean {
  const host = rawHost.replace(/^\[|\]$/g, "").toLowerCase();
  if (!host) return true;
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host.endsWith(".internal") ||
    host.endsWith(".localdomain") ||
    host === "metadata" ||
    host === "metadata.google.internal"
  ) {
    return true;
  }
  if (host.includes(":")) return true;
  if (isIpv4Literal(host)) return true;
  if (!host.includes(".")) return true;
  return false;
}

function validateExternalHttpsUrl(rawUrl: string): string {
  const trimmed = rawUrl.trim();
  const parsed = new URL(trimmed);
  if (parsed.protocol !== "https:") {
    throw new Error("cPanel hosting endpoint must strictly use HTTPS.");
  }
  if (parsed.username || parsed.password) {
    throw new Error("Endpoint URL must not embed credentials.");
  }
  if (isPrivateOrBlockedHost(parsed.hostname)) {
    throw new Error(`Private or unsafe host "${parsed.hostname}" is rejected.`);
  }
  return parsed.toString();
}

function buildPhpApiUrl(rawEndpoint: string, action: string): string {
  const safeBase = validateExternalHttpsUrl(rawEndpoint).replace(/\/+$/, "");
  const scriptUrl = /\.php$/i.test(safeBase) ? safeBase : `${safeBase}/index.php`;
  const sep = scriptUrl.includes("?") ? "&" : "?";
  return `${scriptUrl}${sep}action=${encodeURIComponent(action)}`;
}

async function hmacSha256Hex(secret: string, message: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function uint8ToBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

async function fetchProviderSecret(providerId: string): Promise<string> {
  const cleanId = providerId.replace(/[^a-zA-Z0-9_-]/g, "_");
  const envSpecific = Deno.env.get(`HOSTING_SECRET_${cleanId.toUpperCase()}`) || "";
  if (envSpecific.trim()) return envSpecific.trim();
  if (cleanId) {
    const resp = await supabaseServiceFetch(
      `/rest/v1/hosting_provider_secrets?provider_id=eq.${encodeURIComponent(providerId)}&select=api_secret&limit=1`
    ).catch(() => null);
    if (resp && resp.ok) {
      const rows = await resp.json().catch(() => []);
      if (Array.isArray(rows) && rows[0]?.api_secret) {
        return String(rows[0].api_secret).trim();
      }
    }
  }
  return (Deno.env.get("PHP_HOSTING_DEFAULT_SECRET") || "").trim();
}

async function callPhpEndpoint(params: {
  endpointUrl: string;
  phpAction: string;
  secret: string;
  method?: "GET" | "POST";
  jsonBody?: Record<string, unknown>;
}): Promise<{ status: number; ok: boolean; data: Record<string, unknown> }> {
  const targetUrl = buildPhpApiUrl(params.endpointUrl, params.phpAction);
  const ts = String(Math.floor(Date.now() / 1000));
  const sig = await hmacSha256Hex(params.secret, `${ts}|${params.phpAction}`);
  const headers: Record<string, string> = {
    Authorization: `Bearer ${params.secret}`,
    "X-RepairPro-Timestamp": ts,
    "X-RepairPro-Signature": sig
  };
  if (params.jsonBody) headers["Content-Type"] = "application/json";

  const resp = await fetch(targetUrl, {
    method: params.method || (params.jsonBody ? "POST" : "GET"),
    redirect: "error",
    signal: AbortSignal.timeout(25_000),
    headers,
    ...(params.jsonBody ? { body: JSON.stringify(params.jsonBody) } : {})
  });
  const data = await resp.json().catch(() => ({}));
  return {
    status: resp.status,
    ok: resp.ok && Boolean(data?.ok),
    data: (typeof data === "object" && data !== null ? data : {}) as Record<string, unknown>
  };
}

async function logStorageError(providerId: string, errorMessage: string, failoverTargetId = ""): Promise<void> {
  const errorId = `err_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  await supabaseServiceFetch("/rest/v1/storage_error_logs?on_conflict=error_id", {
    method: "POST",
    headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
    body: JSON.stringify({
      error_id: errorId,
      provider_id: providerId,
      error_message: errorMessage.slice(0, 800),
      failover_target_id: failoverTargetId,
      resolved: false,
      created_at: new Date().toISOString()
    })
  }).catch(() => {});
}

async function loadCloudState() {
  const [settingsResp, providersResp, schedResp, runsResp] = await Promise.all([
    supabaseServiceFetch("/rest/v1/app_settings?setting_id=in.(migration_config,storage_config)&select=setting_id,payload"),
    supabaseServiceFetch("/rest/v1/storage_providers?select=*&order=created_at.asc"),
    supabaseServiceFetch("/rest/v1/cloud_scheduler_status?scheduler_id=eq.default&limit=1"),
    supabaseServiceFetch("/rest/v1/cloud_migration_runs?select=*&order=started_at.desc&limit=5")
  ]);

  const settingsRows = settingsResp.ok ? await settingsResp.json().catch(() => []) : [];
  let migrationCfg: Record<string, unknown> = {};
  let storageCfg: Record<string, unknown> = {};
  for (const row of settingsRows as Array<Record<string, unknown>>) {
    if (row.setting_id === "migration_config") migrationCfg = (row.payload || {}) as Record<string, unknown>;
    if (row.setting_id === "storage_config") storageCfg = (row.payload || {}) as Record<string, unknown>;
  }

  const providerRows = providersResp.ok ? await providersResp.json().catch(() => []) : [];
  let providers: Array<Record<string, unknown>> = [];
  if (Array.isArray(providerRows) && providerRows.length > 0) {
    providers = providerRows.map((r: Record<string, unknown>) => {
      const meta = (r.provider_metadata || {}) as Record<string, unknown>;
      return {
        providerId: String(r.provider_id || ""),
        providerName: String(r.provider_name || ""),
        providerType: String(r.provider_type || ""),
        endpointUrl: String(meta.uploadApiUrl || r.endpoint_url || ""),
        enabled: Boolean(r.enabled),
        role: String(r.role || "BACKUP"),
        supportsStorage: r.supports_storage !== false,
        supportsDatabase: Boolean(r.supports_database),
        dbEnabled: Boolean(r.db_enabled),
        communityOnly: Boolean(r.community_only)
      };
    });
  } else if (Array.isArray(storageCfg.providers)) {
    providers = storageCfg.providers as Array<Record<string, unknown>>;
  }

  const schedulerRows = schedResp.ok ? await schedResp.json().catch(() => []) : [];
  const latestRuns = runsResp.ok ? await runsResp.json().catch(() => []) : [];

  return {
    migrationCfg,
    storageCfg,
    providers,
    schedulerStatus: Array.isArray(schedulerRows) && schedulerRows[0] ? schedulerRows[0] : null,
    latestRuns: Array.isArray(latestRuns) ? latestRuns : []
  };
}

async function listSupabaseBucketObjects(bucket: string): Promise<Array<{ name: string; size: number; mimetype: string }>> {
  const { url } = getSupabaseEnv();
  const out: Array<{ name: string; size: number; mimetype: string }> = [];
  const walk = async (prefix: string) => {
    const resp = await supabaseServiceFetch(`/storage/v1/object/list/${encodeURIComponent(bucket)}`, {
      method: "POST",
      body: JSON.stringify({ prefix, limit: 200, offset: 0, sortBy: { column: "name", order: "asc" } })
    });
    if (!resp.ok) return;
    const items = await resp.json().catch(() => []);
    if (!Array.isArray(items)) return;
    for (const item of items) {
      const name = String(item?.name || "").trim();
      if (!name) continue;
      const fullPath = prefix ? `${prefix}/${name}` : name;
      if (item?.id == null && !item?.metadata) {
        await walk(fullPath);
      } else {
        out.push({
          name: fullPath,
          size: Number(item?.metadata?.size || 0),
          mimetype: String(item?.metadata?.mimetype || "application/octet-stream")
        });
      }
    }
  };
  void url;
  await walk("");
  return out;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return jsonResponse(405, { ok: false, errorCode: "METHOD_NOT_ALLOWED", message: "Use POST." });
  }

  let lockAcquired = false;
  let dbPct = 0;
  let storagePct = 0;
  let runId = "";
  let reclaimedBytes = 0;

  try {
    const body = await req.json().catch(() => ({}));
    const action = String(body?.action || "status").toLowerCase();

    const cronHeader = (req.headers.get("x-cron-secret") || "").trim();
    const expectedCronSecret = (Deno.env.get("CRON_SECRET") || "").trim();
    const authHeader = req.headers.get("authorization") || "";
    const bearerToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    const { serviceKey } = getSupabaseEnv();

    let isTrustedCron = false;
    let actorUid = "cron_24x7";
    if (expectedCronSecret && cronHeader && constantTimeEqual(cronHeader, expectedCronSecret)) {
      isTrustedCron = true;
    } else if (serviceKey && bearerToken && constantTimeEqual(bearerToken, serviceKey)) {
      isTrustedCron = true;
    }

    if (!isTrustedCron) {
      if (!bearerToken) {
        return jsonResponse(401, { ok: false, errorCode: "UNAUTHORIZED", message: "Missing Admin Bearer token or cron secret." });
      }
      const caller = await verifyFirebaseIdToken(bearerToken);
      const admin = await isAuthorizedAdmin(caller);
      if (!admin) {
        return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Super Admin privileges required." });
      }
      actorUid = caller.uid;
    }

    if (action === "status") {
      const [cloud, metrics] = await Promise.all([
        loadCloudState(),
        supabaseRpc("get_supabase_usage_metrics", {}).catch(() => null)
      ]);
      return jsonResponse(200, {
        ok: true,
        schedulerStatus: cloud.schedulerStatus,
        migrationConfig: cloud.migrationCfg,
        metrics,
        latestRuns: cloud.latestRuns
      });
    }

    if (action === "unlock") {
      await supabaseRpc("release_cloud_scheduler_lock", {
        p_scheduler_id: "default",
        p_last_status: "MANUALLY_UNLOCKED",
        p_last_error: ""
      });
      return jsonResponse(200, { ok: true, unlocked: true });
    }

    if (action !== "run_tick") {
      return jsonResponse(400, { ok: false, errorCode: "INVALID_ACTION", message: `Unsupported action '${action}'.` });
    }

    const forceManual = Boolean(body?.forceManual) && !isTrustedCron;
    const triggerMode = String(body?.triggerMode || (forceManual ? "MANUAL_EDGE" : "CRON_24X7")).slice(0, 40);
    const cloud = await loadCloudState();
    const autoEnabled = Boolean(cloud.migrationCfg.autoMigrationEnabled);
    const autoCleanupEnabled = Boolean(cloud.migrationCfg.autoCleanupEnabled);
    const dbThreshold = Math.min(99, Math.max(10, Number(cloud.migrationCfg.dbMigrationThresholdPct || 80)));
    const storageThreshold = Math.min(99, Math.max(10, Number(cloud.migrationCfg.storageMigrationThresholdPct || 80)));
    const dbLimit = Math.max(10 * 1024 * 1024, Number(cloud.migrationCfg.dbLimitBytes || 524_288_000));
    const storageLimit = Math.max(10 * 1024 * 1024, Number(cloud.migrationCfg.storageLimitBytes || 1_073_741_824));

    const lockRes = (await supabaseRpc("acquire_cloud_scheduler_lock", {
      p_scheduler_id: "default",
      p_lock_owner: `${triggerMode}:${actorUid}`.slice(0, 90),
      p_ttl_seconds: 300,
      p_worker_type: "SUPABASE_EDGE_CRON"
    })) as Record<string, unknown>;

    if (!lockRes?.acquired) {
      return jsonResponse(200, {
        ok: true,
        skipped: true,
        reason: "LOCK_HELD",
        lockOwner: lockRes?.lockOwner || ""
      });
    }
    lockAcquired = true;

    const metricsBefore = (await supabaseRpc("get_supabase_usage_metrics", {})) as Record<string, unknown>;
    const dbUsed = Number(metricsBefore?.dbUsedBytes || 0);
    const storageUsed = Number(metricsBefore?.storageUsedBytes || 0);
    dbPct = Math.min(100, Math.round((dbUsed / dbLimit) * 100));
    storagePct = Math.min(100, Math.round((storageUsed / storageLimit) * 100));

    if (!autoEnabled && !forceManual) {
      await supabaseRpc("release_cloud_scheduler_lock", {
        p_scheduler_id: "default",
        p_last_status: "IDLE_DISABLED",
        p_last_error: "",
        p_db_pct: dbPct,
        p_storage_pct: storagePct,
        p_reclaimed_bytes: 0
      });
      lockAcquired = false;
      return jsonResponse(200, { ok: true, skipped: true, reason: "AUTO_MIGRATION_DISABLED", dbPct, storagePct });
    }

    const targetHost = cloud.providers.find(
      (p) => Boolean(p.enabled) && p.providerType === "PHP_HOSTING" && /^https:\/\//i.test(String(p.endpointUrl || ""))
    );

    if (!targetHost) {
      await supabaseRpc("release_cloud_scheduler_lock", {
        p_scheduler_id: "default",
        p_last_status: "SKIPPED_NO_VERIFIED_HOST",
        p_last_error: "No active HTTPS cPanel hosting provider connected. Supabase stays primary.",
        p_db_pct: dbPct,
        p_storage_pct: storagePct,
        p_reclaimed_bytes: 0
      });
      lockAcquired = false;
      return jsonResponse(200, { ok: true, skipped: true, reason: "NO_CPANEL_HOST", dbPct, storagePct });
    }

    const overDbThreshold = dbPct >= dbThreshold;
    const overStorageThreshold = storagePct >= storageThreshold;
    if (!forceManual && !overDbThreshold && !overStorageThreshold) {
      await supabaseRpc("release_cloud_scheduler_lock", {
        p_scheduler_id: "default",
        p_last_status: "IDLE_BELOW_THRESHOLD",
        p_last_error: "",
        p_db_pct: dbPct,
        p_storage_pct: storagePct,
        p_reclaimed_bytes: 0
      });
      lockAcquired = false;
      return jsonResponse(200, { ok: true, skipped: true, reason: "BELOW_THRESHOLD", dbPct, storagePct });
    }

    const targetId = String(targetHost.providerId || "cpanel_primary");
    const targetUrl = validateExternalHttpsUrl(String(targetHost.endpointUrl || ""));
    const secret = await fetchProviderSecret(targetId);
    if (!secret) {
      const msg = `Hosting secret missing for ${targetId}. Skipping migration without deleting any data.`;
      await logStorageError("supabase_primary", msg, targetId);
      await supabaseRpc("release_cloud_scheduler_lock", {
        p_scheduler_id: "default",
        p_last_status: "ERROR_SECRET_MISSING",
        p_last_error: msg,
        p_db_pct: dbPct,
        p_storage_pct: storagePct,
        p_reclaimed_bytes: 0
      });
      lockAcquired = false;
      return jsonResponse(200, { ok: false, errorCode: "SECRET_MISSING", message: msg });
    }

    const healthRes = await callPhpEndpoint({ endpointUrl: targetUrl, phpAction: "health", secret, method: "GET" });
    if (!healthRes.ok || !healthRes.data.storageWritable) {
      const msg = `cPanel host ${targetId} health/permission check failed. Migration aborted safely.`;
      await logStorageError("supabase_primary", msg, targetId);
      await supabaseRpc("release_cloud_scheduler_lock", {
        p_scheduler_id: "default",
        p_last_status: "ERROR_TARGET_UNHEALTHY",
        p_last_error: msg,
        p_db_pct: dbPct,
        p_storage_pct: storagePct,
        p_reclaimed_bytes: 0
      });
      lockAcquired = false;
      return jsonResponse(200, { ok: false, errorCode: "TARGET_UNHEALTHY", message: msg });
    }

    const doDb = Boolean(targetHost.supportsDatabase && targetHost.dbEnabled) && (forceManual || overDbThreshold);
    const doStorage = targetHost.supportsStorage !== false && (forceManual || overStorageThreshold);
    const scope = doDb && doStorage ? "BOTH" : doDb ? "DATABASE" : doStorage ? "STORAGE" : "BOTH";

    if (doDb) {
      await callPhpEndpoint({
        endpointUrl: targetUrl,
        phpAction: "db_init_schema",
        secret,
        method: "POST",
        jsonBody: { initializedByUid: actorUid }
      });
    }

    runId = `mig_cron_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const backupId = `bkp_cron_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const nowIso = new Date().toISOString();

    const runPayload: Record<string, unknown> = {
      run_id: runId,
      source_provider_id: "supabase_primary",
      target_provider_id: targetId,
      trigger_mode: triggerMode,
      scope,
      status: "RUNNING",
      total_items: 0,
      migrated_items: 0,
      verified_items: 0,
      cleaned_items: 0,
      failed_items: 0,
      total_bytes: 0,
      backup_manifest_id: backupId,
      last_cursor: "",
      error_summary: "",
      started_by_uid: actorUid,
      started_at: nowIso,
      updated_at: nowIso
    };
    await supabaseServiceFetch("/rest/v1/cloud_migration_runs?on_conflict=run_id", {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify(runPayload)
    });

    const backupEntries: Array<Record<string, unknown>> = [];
    const verifiedStorageItems: Array<{ itemId: string; bucket: string; objectPath: string; sha256: string; sizeBytes: number }> = [];
    let totalItems = 0;
    let migratedItems = 0;
    let verifiedItems = 0;
    let failedItems = 0;
    let totalBytes = 0;
    const errors: string[] = [];

    if (doDb) {
      for (const tbl of MIGRATION_TABLES) {
        if (PROTECTED_TABLES.has(tbl.table)) continue;
        const rowsResp = await supabaseServiceFetch(`/rest/v1/${tbl.table}?select=*&limit=200`);
        if (!rowsResp.ok) {
          errors.push(`Read ${tbl.table} HTTP ${rowsResp.status}`);
          continue;
        }
        const rows = (await rowsResp.json().catch(() => [])) as Array<Record<string, unknown>>;
        if (!Array.isArray(rows) || rows.length === 0) continue;

        for (let i = 0; i < rows.length; i += 30) {
          const batch = rows.slice(i, i + 30);
          totalItems += batch.length;
          const stamped = batch.map((r) => ({
            ...r,
            migrated_to_provider_id: targetId,
            migration_status: "MIGRATED"
          }));
          const upRes = await callPhpEndpoint({
            endpointUrl: targetUrl,
            phpAction: "db_upsert",
            secret,
            method: "POST",
            jsonBody: {
              table: tbl.cpanelTable,
              records: stamped,
              preserveTimestamps: true,
              isAdmin: true,
              actorUid
            }
          });
          if (upRes.ok) {
            migratedItems += batch.length;
            verifiedItems += batch.length;
            for (const r of batch) {
              const pkVal = String(r[tbl.pk] || "");
              const rowSize = JSON.stringify(r).length;
              totalBytes += rowSize;
              backupEntries.push({
                entityType: "table_row",
                table: tbl.table,
                pkCol: tbl.pk,
                pkVal,
                row: r
              });
            }
          } else {
            failedItems += batch.length;
            errors.push(`${tbl.table}: ${String(upRes.data.message || upRes.status)}`);
          }
        }
      }
    }

    if (doStorage) {
      const eligibleBuckets = MIGRATION_BUCKETS.filter((b) =>
        b.key === "verification" ? !targetHost.communityOnly : (!targetHost.communityOnly || ["community", "technicians"].includes(b.key))
      );
      for (const bInfo of eligibleBuckets) {
        const objects = await listSupabaseBucketObjects(bInfo.bucket);
        for (const obj of objects.slice(0, 60)) {
          totalItems += 1;
          const itemId = `it_${runId}_${bInfo.bucket}_${obj.name}`.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 120);
          try {
            const dlResp = await supabaseServiceFetch(
              `/storage/v1/object/${encodeURIComponent(bInfo.bucket)}/${obj.name.split("/").map(encodeURIComponent).join("/")}`
            );
            if (!dlResp.ok) throw new Error(`Download HTTP ${dlResp.status}`);
            const bytes = new Uint8Array(await dlResp.arrayBuffer());
            const hash = await sha256Hex(bytes);
            const uploadRes = await callPhpEndpoint({
              endpointUrl: targetUrl,
              phpAction: "upload",
              secret,
              method: "POST",
              jsonBody: {
                bucketName: bInfo.bucket,
                objectPath: obj.name,
                base64: uint8ToBase64(bytes),
                mimeType: obj.mimetype,
                preserveExactBytes: true,
                skipDedupe: true,
                uploadedByUid: actorUid
              }
            });
            if (!uploadRes.ok) {
              throw new Error(String(uploadRes.data.message || `Upload HTTP ${uploadRes.status}`));
            }
            const uploadedPath = String(uploadRes.data.storagePath || `${bInfo.bucket}/${obj.name}`);
            const verifyRes = await callPhpEndpoint({
              endpointUrl: targetUrl,
              phpAction: "verify_file",
              secret,
              method: "POST",
              jsonBody: { storagePath: uploadedPath, sha256: hash }
            });
            if (!verifyRes.ok || !verifyRes.data.exists || !verifyRes.data.shaMatch) {
              throw new Error(`SHA-256 verification failed for ${uploadedPath}`);
            }

            migratedItems += 1;
            verifiedItems += 1;
            const sizeBytes = Number(verifyRes.data.sizeBytes || bytes.byteLength);
            totalBytes += sizeBytes;
            verifiedStorageItems.push({ itemId, bucket: bInfo.bucket, objectPath: obj.name, sha256: hash, sizeBytes });
            backupEntries.push({
              entityType: "storage_object",
              bucket: bInfo.bucket,
              objectPath: obj.name,
              isPrivate: bInfo.isPrivate,
              targetStoragePath: uploadedPath,
              targetUrl: String(verifyRes.data.publicUrl || uploadRes.data.publicUrl || ""),
              sha256: hash,
              sizeBytes
            });
          } catch (err) {
            failedItems += 1;
            const msg = err instanceof Error ? err.message : String(err);
            errors.push(`${bInfo.bucket}/${obj.name}: ${msg}`);
            await supabaseServiceFetch("/rest/v1/cloud_migration_items?on_conflict=item_id", {
              method: "POST",
              headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
              body: JSON.stringify({
                item_id: itemId,
                run_id: runId,
                entity_type: "storage_object",
                table_or_bucket: bInfo.bucket,
                record_or_path: obj.name,
                source_provider_id: "supabase_primary",
                target_provider_id: targetId,
                status: "FAILED",
                error_message: msg.slice(0, 400)
              })
            }).catch(() => {});
          }
        }
      }
    }

    // Save recoverable backup manifest BEFORE any cleanup
    const manifestJson = {
      backupId,
      runId,
      createdAt: new Date().toISOString(),
      sourceProviderId: "supabase_primary",
      targetProviderId: targetId,
      scope,
      totalItems,
      verifiedItems,
      failedItems,
      totalBytes,
      entries: backupEntries
    };
    const manifestChecksum = await sha256Hex(new TextEncoder().encode(JSON.stringify(manifestJson)));
    const bkpResp = await supabaseServiceFetch("/rest/v1/cloud_backup_manifests?on_conflict=backup_id", {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify({
        backup_id: backupId,
        run_id: runId,
        source_provider_id: "supabase_primary",
        target_provider_id: targetId,
        item_count: backupEntries.length,
        total_bytes: totalBytes,
        checksum_sha256: manifestChecksum,
        manifest_json: manifestJson,
        status: "READY",
        created_by_uid: actorUid
      })
    });
    const backupSaved = bkpResp.ok;

    // Safe automated cleanup ONLY if ALL safety gates hold
    let cleanedItems = 0;
    if (
      autoCleanupEnabled &&
      backupSaved &&
      failedItems === 0 &&
      totalItems > 0 &&
      verifiedItems === totalItems &&
      verifiedStorageItems.length > 0
    ) {
      for (const st of verifiedStorageItems) {
        const recheck = await callPhpEndpoint({
          endpointUrl: targetUrl,
          phpAction: "verify_file",
          secret,
          method: "POST",
          jsonBody: { storagePath: `${st.bucket}/${st.objectPath}`, sha256: st.sha256 }
        });
        if (!recheck.ok || !recheck.data.exists || !recheck.data.shaMatch) {
          errors.push(`Cleanup stopped at ${st.bucket}/${st.objectPath}: target check failed`);
          break;
        }
        const delResp = await supabaseServiceFetch(
          `/storage/v1/object/${encodeURIComponent(st.bucket)}/${st.objectPath.split("/").map(encodeURIComponent).join("/")}`,
          { method: "DELETE" }
        );
        if (delResp.ok) {
          cleanedItems += 1;
          reclaimedBytes += st.sizeBytes;
        }
      }
    }

    const metricsAfter = (await supabaseRpc("get_supabase_usage_metrics", {}).catch(() => null)) as Record<string, unknown> | null;
    if (metricsAfter) {
      const storageAfter = Number(metricsAfter.storageUsedBytes || 0);
      const storageDelta = Math.max(0, storageUsed - storageAfter);
      if (storageDelta > reclaimedBytes) reclaimedBytes = storageDelta;
      dbPct = Math.min(100, Math.round((Number(metricsAfter.dbUsedBytes || dbUsed) / dbLimit) * 100));
      storagePct = Math.min(100, Math.round((storageAfter / storageLimit) * 100));
    }

    const finalStatus = failedItems === 0 ? "COMPLETED" : (verifiedItems > 0 ? "PARTIAL" : "FAILED");
    await supabaseServiceFetch("/rest/v1/cloud_migration_runs?on_conflict=run_id", {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify({
        ...runPayload,
        status: finalStatus,
        total_items: totalItems,
        migrated_items: migratedItems,
        verified_items: verifiedItems,
        cleaned_items: cleanedItems,
        failed_items: failedItems,
        total_bytes: totalBytes,
        error_summary: errors.slice(0, 10).join(" | ").slice(0, 1000),
        completed_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
    });

    if (failedItems > 0 && errors.length > 0) {
      await logStorageError("supabase_primary", `24x7 Migration ${finalStatus}: ${errors[0]}`, targetId);
    }

    await supabaseRpc("release_cloud_scheduler_lock", {
      p_scheduler_id: "default",
      p_last_status: finalStatus,
      p_last_run_id: runId,
      p_last_error: errors[0] ? errors[0].slice(0, 400) : "",
      p_db_pct: dbPct,
      p_storage_pct: storagePct,
      p_reclaimed_bytes: reclaimedBytes
    });
    lockAcquired = false;

    return jsonResponse(200, {
      ok: true,
      runId,
      backupId,
      status: finalStatus,
      totalItems,
      verifiedItems,
      cleanedItems,
      failedItems,
      reclaimedBytes,
      dbPct,
      storagePct
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Cloud migration worker error";
    await logStorageError("supabase_primary", message).catch(() => {});
    if (lockAcquired) {
      await supabaseRpc("release_cloud_scheduler_lock", {
        p_scheduler_id: "default",
        p_last_status: "ERROR",
        p_last_run_id: runId,
        p_last_error: message.slice(0, 400),
        p_db_pct: dbPct,
        p_storage_pct: storagePct,
        p_reclaimed_bytes: reclaimedBytes
      }).catch(() => {});
    }
    return jsonResponse(500, { ok: false, errorCode: "WORKER_ERROR", message });
  }
});
