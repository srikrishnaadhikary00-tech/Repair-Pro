// Repair Pro v3.0 — Unified Secure Backend API (Supabase Edge Function — Free Tier)
// Handles:
// - Firebase ID Token verification & user profile / FCM token sync
// - Community (posts, multi-photo, likes, comments & nested replies, save, report, moderation)
// - Technicians (registration, private verification doc protection, public directory, admin controls)
// - Repair PDFs & Circuit Diagrams (upload, publish/unpublish, edit, delete, download counter)
// - Multi-Cloud Storage Manager (Supabase primary + backup providers, test connection, automatic failover,
//   central file registry, migration, error logs — NEVER bypassing 401/403 auth errors)
// - AdMob Settings, Remote App Settings (v3.0), Users Management, Activity Logs, Error Logs & Health

import { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import {
  assertSuperAdmin,
  buildCorsHeaders,
  checkRateLimit,
  FIREBASE_PROJECT_ID,
  getServiceSupabase,
  HttpError,
  jsonResponse,
  VerifiedFirebaseUser,
  verifyFirebaseUser
} from "../_shared/firebase-auth.ts";
import {
  type AdapterDeps,
  isSafePublicHttpsUrl,
  normalizeCanonicalProviderType,
  StorageAdapterError,
  type StorageProviderConfig
} from "../_shared/storage-adapters.ts";
import {
  deleteStorageProviderSafe,
  enrichProviderMetadata,
  type ErrorLogInsert,
  type FileRegistryRow,
  migrateProviderFiles,
  mintAdminSignedVerificationUrl,
  type StorageRepository,
  testAndRecordProviderConnection,
  uploadWithFailover
} from "../_shared/storage-manager.ts";

function decodeBase64Bytes(b64: string): Uint8Array {
  const clean = b64.includes(",") ? b64.split(",").pop() || "" : b64;
  const bin = atob(clean);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

const ADAPTER_DEPS: AdapterDeps = {
  getEnv: (key: string) => Deno.env.get(key),
  fetchFn: (input, init) => fetch(input, init)
};

function createSupabaseStorageRepo(supabase: SupabaseClient): StorageRepository {
  return {
    async listEnabledProviders() {
      const { data } = await supabase
        .from("storage_providers")
        .select("*")
        .eq("is_enabled", true)
        .order("is_primary", { ascending: false })
        .order("is_backup", { ascending: false })
        .order("priority_order", { ascending: true });
      return (data || []) as StorageProviderConfig[];
    },
    async listAllProviders() {
      const { data } = await supabase
        .from("storage_providers")
        .select("*")
        .order("is_primary", { ascending: false })
        .order("priority_order", { ascending: true });
      return (data || []) as StorageProviderConfig[];
    },
    async getProviderById(id: string) {
      const { data } = await supabase
        .from("storage_providers")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      return (data as StorageProviderConfig | null) || null;
    },
    async getAutoFailoverSetting() {
      const { data } = await supabase
        .from("app_remote_settings")
        .select("storage_auto_failover")
        .eq("id", "default")
        .maybeSingle();
      return data?.storage_auto_failover !== false;
    },
    async updateProviderUsage(providerId: string, usedBytes: number) {
      await supabase
        .from("storage_providers")
        .update({ used_bytes: Math.max(0, usedBytes), updated_at: new Date().toISOString() })
        .eq("id", providerId);
    },
    async updateProviderTestResult(providerId: string, status: string, message: string) {
      await supabase
        .from("storage_providers")
        .update({
          last_test_status: status,
          last_test_message: message.slice(0, 300),
          last_test_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq("id", providerId);
    },
    async countProviderActiveFiles(providerId: string) {
      const { count } = await supabase
        .from("storage_file_registry")
        .select("id", { count: "exact", head: true })
        .eq("provider_id", providerId);
      return count ?? 0;
    },
    async getActiveFileCountsByProvider() {
      const { data } = await supabase
        .from("storage_file_registry")
        .select("provider_id");
      const counts: Record<string, number> = {};
      for (const row of data || []) {
        const pid = (row as { provider_id?: string | null }).provider_id;
        if (pid) counts[pid] = (counts[pid] || 0) + 1;
      }
      return counts;
    },
    async listProviderFiles(providerId: string, limit: number) {
      const { data } = await supabase
        .from("storage_file_registry")
        .select("*")
        .eq("provider_id", providerId)
        .order("created_at", { ascending: true })
        .limit(limit);
      return (data || []) as FileRegistryRow[];
    },
    async findFileByObjectPath(objectPath: string) {
      const { data } = await supabase
        .from("storage_file_registry")
        .select("*")
        .eq("object_path", objectPath)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      return (data as FileRegistryRow | null) || null;
    },
    async insertRegistryFile(entry: Omit<FileRegistryRow, "id" | "created_at">) {
      const { data, error } = await supabase
        .from("storage_file_registry")
        .insert(entry)
        .select()
        .single();
      if (error) throw new HttpError(500, "REGISTRY_INSERT_FAILED", error.message);
      return data as FileRegistryRow;
    },
    async updateRegistryFileAfterMigration(fileId: string, patch) {
      const { error } = await supabase
        .from("storage_file_registry")
        .update(patch)
        .eq("id", fileId);
      if (error) throw new HttpError(500, "REGISTRY_UPDATE_FAILED", error.message);
    },
    async updateRepairDocumentsAfterMigration(storageFileId: string, newFileUrl: string, newProviderId: string) {
      await supabase
        .from("repair_documents")
        .update({
          file_url: newFileUrl,
          storage_provider_id: newProviderId,
          updated_at: new Date().toISOString()
        })
        .eq("storage_file_id", storageFileId);
    },
    async deleteProviderRow(providerId: string) {
      const { error } = await supabase
        .from("storage_providers")
        .delete()
        .eq("id", providerId);
      if (error) {
        if (error.message.includes("PROVIDER_HAS_ACTIVE_FILES")) {
          throw new HttpError(409, "PROVIDER_HAS_ACTIVE_FILES", error.message);
        }
        throw new HttpError(500, "DB_ERROR", error.message);
      }
    },
    async insertErrorLog(entry: ErrorLogInsert) {
      await supabase.from("storage_error_logs").insert(entry);
    }
  };
}

async function logAdminActivity(
  supabase: SupabaseClient,
  user: VerifiedFirebaseUser,
  action: string,
  targetType: string,
  targetId: string,
  details: string
) {
  await supabase.from("admin_activity_logs").insert({
    admin_uid: user.uid,
    admin_email: user.email,
    action,
    target_type: targetType,
    target_id: targetId,
    details: details.slice(0, 500)
  });
}

// Storage orchestration now lives in ../_shared/storage-manager.ts and ../_shared/storage-adapters.ts

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: buildCorsHeaders(req) });
  }

  const supabase = getServiceSupabase();
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/repair-pro-api/, "") || "/";

  try {
    // Public connection health check
    if (path === "/health" && req.method === "GET") {
      const { count } = await supabase.from("storage_providers").select("id", { count: "exact", head: true });
      return jsonResponse(req, 200, {
        ok: true,
        appVersion: "3.0",
        firebaseProject: FIREBASE_PROJECT_ID,
        supabaseProject: "xuakzzjtcgcvudkgxpbd",
        storageProvidersCount: count ?? 0,
        timestamp: new Date().toISOString()
      });
    }

    // All other routes require verified Firebase ID token
    const user = await verifyFirebaseUser(req, supabase);
    if (!checkRateLimit(`api:${user.uid}`, 120, 60_000)) {
      throw new HttpError(429, "RATE_LIMITED", "Rate limit exceeded. Try again shortly.");
    }
    if (user.isBlocked) {
      throw new HttpError(403, "USER_BLOCKED", "Your account has been restricted by an administrator.");
    }

    const body = req.method !== "GET" && req.method !== "DELETE"
      ? await req.json().catch(() => ({}))
      : {};

    // ---------------- FCM TOKEN REGISTRATION ----------------
    if (path === "/fcm/register" && req.method === "POST") {
      const fcmToken = String(body.fcmToken || "").trim();
      if (!fcmToken) throw new HttpError(400, "MISSING_TOKEN", "fcmToken is required.");
      await supabase.from("user_fcm_tokens").upsert(
        {
          firebase_uid: user.uid,
          fcm_token: fcmToken,
          platform: String(body.platform || "android"),
          app_version: String(body.appVersion || "3.0"),
          is_active: true,
          updated_at: new Date().toISOString()
        },
        { onConflict: "fcm_token" }
      );
      return jsonResponse(req, 200, { ok: true });
    }

    // ---------------- FILE UPLOAD (MULTI-CLOUD WITH FAILOVER) ----------------
    if (path === "/storage/upload" && req.method === "POST") {
      const bucketName = String(body.bucket || "community-photos");
      const filename = String(body.filename || "upload.bin");
      const mimeType = String(body.mimeType || "application/octet-stream");
      const base64 = String(body.base64 || "");
      if (!base64) throw new HttpError(400, "MISSING_FILE", "Base64 file payload required.");
      if (bucketName === "repair-pdfs" || bucketName === "circuit-diagrams") {
        assertSuperAdmin(user);
      }
      const bytes = decodeBase64Bytes(base64);
      const repo = createSupabaseStorageRepo(supabase);
      const uploaded = await uploadWithFailover({
        repo,
        deps: ADAPTER_DEPS,
        uploaderUid: user.uid,
        bucketName,
        originalFilename: filename,
        mimeType,
        bytes,
        entityType: body.entityType ? String(body.entityType) : undefined,
        entityId: body.entityId ? String(body.entityId) : undefined
      });
      return jsonResponse(req, 200, { ok: true, ...uploaded });
    }

    // ---------------- COMMUNITY SYSTEM ----------------
    if (path === "/community/posts" && req.method === "GET") {
      const includeAll = url.searchParams.get("admin") === "true" && user.isSuperAdmin;
      let query = supabase
        .from("community_posts")
        .select("*")
        .eq("is_deleted", false)
        .order("created_at", { ascending: false })
        .limit(100);
      if (!includeAll) query = query.eq("moderation_status", "APPROVED");
      const { data: posts, error } = await query;
      if (error) throw new HttpError(500, "DB_ERROR", error.message);

      const { data: myLikes } = await supabase.from("community_likes").select("post_id").eq("user_uid", user.uid);
      const { data: mySaves } = await supabase.from("community_saved_posts").select("post_id").eq("user_uid", user.uid);
      return jsonResponse(req, 200, {
        ok: true,
        posts: posts || [],
        likedPostIds: (myLikes || []).map((x) => x.post_id),
        savedPostIds: (mySaves || []).map((x) => x.post_id)
      });
    }

    if (path === "/community/posts" && req.method === "POST") {
      const title = String(body.title || "").trim().slice(0, 140);
      const postBody = String(body.body || "").trim().slice(0, 2000);
      const categoryId = String(body.categoryId || "ac").slice(0, 32);
      if (postBody.length < 3) throw new HttpError(400, "INVALID_POST", "Post message is too short.");

      const { data: tech } = await supabase
        .from("technicians")
        .select("is_verified, approval_status")
        .eq("firebase_uid", user.uid)
        .maybeSingle();

      const { data: settings } = await supabase
        .from("app_remote_settings")
        .select("community_auto_approve")
        .eq("id", "default")
        .maybeSingle();

      const photoUrls: string[] = Array.isArray(body.photoUrls) ? body.photoUrls.slice(0, 5) : [];
      const storageFileIds: string[] = Array.isArray(body.storageFileIds) ? body.storageFileIds.slice(0, 5) : [];

      const { data: created, error } = await supabase
        .from("community_posts")
        .insert({
          author_uid: user.uid,
          author_name: user.name,
          author_avatar_url: user.picture || null,
          is_verified_technician: Boolean(tech?.is_verified && tech?.approval_status === "APPROVED"),
          category_id: categoryId,
          title,
          body: postBody,
          photo_urls: photoUrls,
          storage_file_ids: storageFileIds,
          moderation_status: settings?.community_auto_approve === false && !user.isSuperAdmin ? "PENDING" : "APPROVED"
        })
        .select()
        .single();
      if (error) throw new HttpError(500, "DB_ERROR", error.message);
      return jsonResponse(req, 201, { ok: true, post: created });
    }

    if (path === "/community/posts/edit" && req.method === "POST") {
      const postId = String(body.postId || "");
      const { data: existing } = await supabase.from("community_posts").select("author_uid").eq("id", postId).single();
      if (!existing) throw new HttpError(404, "NOT_FOUND", "Post not found.");
      if (existing.author_uid !== user.uid && !user.isSuperAdmin) {
        throw new HttpError(403, "FORBIDDEN", "You can only edit your own posts.");
      }
      const { data: updated, error } = await supabase
        .from("community_posts")
        .update({
          title: String(body.title || "").trim().slice(0, 140),
          body: String(body.body || "").trim().slice(0, 2000),
          updated_at: new Date().toISOString()
        })
        .eq("id", postId)
        .select()
        .single();
      if (error) throw new HttpError(500, "DB_ERROR", error.message);
      return jsonResponse(req, 200, { ok: true, post: updated });
    }

    if (path === "/community/posts/delete" && req.method === "POST") {
      const postId = String(body.postId || "");
      const { data: existing } = await supabase.from("community_posts").select("author_uid").eq("id", postId).single();
      if (!existing) throw new HttpError(404, "NOT_FOUND", "Post not found.");
      if (existing.author_uid !== user.uid && !user.isSuperAdmin) {
        throw new HttpError(403, "FORBIDDEN", "You can only delete your own posts.");
      }
      await supabase.from("community_posts").update({ is_deleted: true }).eq("id", postId);
      if (user.isSuperAdmin) await logAdminActivity(supabase, user, "DELETE_COMMUNITY_POST", "community_posts", postId, "Deleted post");
      return jsonResponse(req, 200, { ok: true });
    }

    if (path === "/community/like" && req.method === "POST") {
      const postId = String(body.postId || "");
      const { data: existing } = await supabase
        .from("community_likes")
        .select("post_id")
        .eq("post_id", postId)
        .eq("user_uid", user.uid)
        .maybeSingle();
      if (existing) {
        await supabase.from("community_likes").delete().eq("post_id", postId).eq("user_uid", user.uid);
      } else {
        await supabase.from("community_likes").insert({ post_id: postId, user_uid: user.uid });
      }
      const { count } = await supabase.from("community_likes").select("post_id", { count: "exact", head: true }).eq("post_id", postId);
      await supabase.from("community_posts").update({ likes_count: count ?? 0 }).eq("id", postId);
      return jsonResponse(req, 200, { ok: true, liked: !existing, likesCount: count ?? 0 });
    }

    if (path === "/community/save" && req.method === "POST") {
      const postId = String(body.postId || "");
      const { data: existing } = await supabase
        .from("community_saved_posts")
        .select("post_id")
        .eq("post_id", postId)
        .eq("user_uid", user.uid)
        .maybeSingle();
      if (existing) {
        await supabase.from("community_saved_posts").delete().eq("post_id", postId).eq("user_uid", user.uid);
      } else {
        await supabase.from("community_saved_posts").insert({ post_id: postId, user_uid: user.uid });
      }
      return jsonResponse(req, 200, { ok: true, saved: !existing });
    }

    if (path === "/community/comments" && req.method === "GET") {
      const postId = url.searchParams.get("postId") || "";
      const { data: comments } = await supabase
        .from("community_comments")
        .select("*")
        .eq("post_id", postId)
        .eq("is_deleted", false)
        .order("created_at", { ascending: true });
      return jsonResponse(req, 200, { ok: true, comments: comments || [] });
    }

    if (path === "/community/comments" && req.method === "POST") {
      const postId = String(body.postId || "");
      const commentBody = String(body.body || "").trim().slice(0, 1000);
      if (!postId || commentBody.length < 1) throw new HttpError(400, "INVALID_COMMENT", "Comment text required.");
      const { data: tech } = await supabase
        .from("technicians")
        .select("is_verified, approval_status")
        .eq("firebase_uid", user.uid)
        .maybeSingle();
      const { data: comment, error } = await supabase
        .from("community_comments")
        .insert({
          post_id: postId,
          parent_comment_id: body.parentCommentId || null,
          author_uid: user.uid,
          author_name: user.name,
          is_verified_technician: Boolean(tech?.is_verified && tech?.approval_status === "APPROVED"),
          body: commentBody
        })
        .select()
        .single();
      if (error) throw new HttpError(500, "DB_ERROR", error.message);
      const { count } = await supabase.from("community_comments").select("id", { count: "exact", head: true }).eq("post_id", postId).eq("is_deleted", false);
      await supabase.from("community_posts").update({ comments_count: count ?? 0 }).eq("id", postId);
      return jsonResponse(req, 201, { ok: true, comment, commentsCount: count ?? 0 });
    }

    if (path === "/community/report" && req.method === "POST") {
      const postId = String(body.postId || "");
      const reason = String(body.reason || "").trim().slice(0, 400);
      if (!postId || !reason) throw new HttpError(400, "INVALID_REPORT", "postId and reason required.");
      await supabase.from("community_reports").insert({ post_id: postId, reporter_uid: user.uid, reason });
      return jsonResponse(req, 201, { ok: true });
    }

    if (path === "/admin/community/moderate" && req.method === "POST") {
      assertSuperAdmin(user);
      const postId = String(body.postId || "");
      const status = String(body.status || "APPROVED").toUpperCase();
      if (!["PENDING", "APPROVED", "REJECTED"].includes(status)) throw new HttpError(400, "INVALID_STATUS", "Invalid status.");
      await supabase.from("community_posts").update({
        moderation_status: status,
        rejection_reason: body.reason ? String(body.reason).slice(0, 300) : null,
        updated_at: new Date().toISOString()
      }).eq("id", postId);
      await logAdminActivity(supabase, user, "MODERATE_POST", "community_posts", postId, `Status=${status}`);
      return jsonResponse(req, 200, { ok: true });
    }

    // ---------------- TECHNICIAN SYSTEM ----------------
    if (path === "/technicians" && req.method === "GET") {
      if (url.searchParams.get("admin") === "true" && user.isSuperAdmin) {
        const { data } = await supabase.from("technicians").select("*").order("created_at", { ascending: false });
        return jsonResponse(req, 200, { ok: true, technicians: data || [] });
      }
      // Ordinary users ONLY read from the strict public directory view (zero private verification docs!)
      const { data } = await supabase.from("technician_public_directory").select("*").order("is_verified", { ascending: false });
      return jsonResponse(req, 200, { ok: true, technicians: data || [] });
    }

    if (path === "/technicians/register" && req.method === "POST") {
      const fullName = String(body.fullName || user.name).trim().slice(0, 100);
      const serviceDetails = String(body.serviceDetails || "").trim().slice(0, 800);
      const serviceLocation = String(body.serviceLocation || "").trim().slice(0, 140);
      if (!fullName || !serviceDetails || !serviceLocation) {
        throw new HttpError(400, "INVALID_TECHNICIAN", "Name, service details, and location are required.");
      }
      const { data: tech, error } = await supabase
        .from("technicians")
        .upsert(
          {
            firebase_uid: user.uid,
            full_name: fullName,
            profile_photo_url: body.profilePhotoUrl || null,
            public_phone: body.publicPhone ? String(body.publicPhone).slice(0, 32) : null,
            service_details: serviceDetails,
            experience_years: Math.max(0, Math.min(70, Number(body.experienceYears) || 1)),
            service_location: serviceLocation,
            city: String(body.city || "").slice(0, 80),
            appliance_categories: Array.isArray(body.applianceCategories) ? body.applianceCategories : ["ac"],
            private_verification_docs: Array.isArray(body.verificationDocs) ? body.verificationDocs : [],
            approval_status: "PENDING",
            updated_at: new Date().toISOString()
          },
          { onConflict: "firebase_uid" }
        )
        .select("id, firebase_uid, full_name, approval_status, is_verified, is_active")
        .single();
      if (error) throw new HttpError(500, "DB_ERROR", error.message);
      return jsonResponse(req, 201, { ok: true, technician: tech });
    }

    if (path === "/admin/technicians/manage" && req.method === "POST") {
      assertSuperAdmin(user);
      const action = String(body.action || "").toUpperCase();
      const techId = String(body.technicianId || "");
      if (action === "CREATE") {
        const uid = String(body.firebaseUid || `tech_${Date.now()}`);
        await supabase.from("user_profiles").upsert({ firebase_uid: uid, display_name: String(body.fullName || "Technician"), role: "TECHNICIAN" });
        const { data: created, error } = await supabase.from("technicians").insert({
          firebase_uid: uid,
          full_name: String(body.fullName || "Technician").slice(0, 100),
          profile_photo_url: body.profilePhotoUrl || null,
          public_phone: body.publicPhone || null,
          service_details: String(body.serviceDetails || "Certified appliance technician").slice(0, 800),
          experience_years: Number(body.experienceYears) || 2,
          service_location: String(body.serviceLocation || "").slice(0, 140),
          city: String(body.city || "").slice(0, 80),
          appliance_categories: Array.isArray(body.applianceCategories) ? body.applianceCategories : ["ac"],
          approval_status: "APPROVED",
          is_verified: Boolean(body.isVerified),
          is_active: true
        }).select().single();
        if (error) throw new HttpError(500, "DB_ERROR", error.message);
        await logAdminActivity(supabase, user, "CREATE_TECHNICIAN", "technicians", created.id, created.full_name);
        return jsonResponse(req, 201, { ok: true, technician: created });
      }

      const updates: Record<string, unknown> = { reviewed_by_uid: user.uid, reviewed_at: new Date().toISOString(), updated_at: new Date().toISOString() };
      if (action === "APPROVE") { updates.approval_status = "APPROVED"; updates.is_active = true; }
      else if (action === "REJECT") { updates.approval_status = "REJECTED"; updates.is_verified = false; }
      else if (action === "VERIFY") { updates.is_verified = true; updates.approval_status = "APPROVED"; }
      else if (action === "UNVERIFY") { updates.is_verified = false; }
      else if (action === "BLOCK") { updates.is_blocked = true; updates.is_active = false; }
      else if (action === "UNBLOCK") { updates.is_blocked = false; updates.is_active = true; }
      else if (action === "EDIT") {
        if (body.fullName) updates.full_name = String(body.fullName).slice(0, 100);
        if (body.serviceDetails) updates.service_details = String(body.serviceDetails).slice(0, 800);
        if (body.serviceLocation) updates.service_location = String(body.serviceLocation).slice(0, 140);
        if (body.experienceYears !== undefined) updates.experience_years = Number(body.experienceYears);
        if (body.isActive !== undefined) updates.is_active = Boolean(body.isActive);
      }
      if (body.adminNote !== undefined) updates.admin_note = String(body.adminNote).slice(0, 400);

      await supabase.from("technicians").update(updates).eq("id", techId);
      await logAdminActivity(supabase, user, `TECHNICIAN_${action}`, "technicians", techId, JSON.stringify(updates).slice(0, 300));
      return jsonResponse(req, 200, { ok: true });
    }

    // ---------------- REPAIR PDFS & CIRCUIT DIAGRAMS ----------------
    if (path === "/documents" && req.method === "GET") {
      const includeAll = url.searchParams.get("admin") === "true" && user.isSuperAdmin;
      let query = supabase.from("repair_documents").select("*").order("created_at", { ascending: false }).limit(200);
      if (!includeAll) query = query.eq("is_published", true);
      const { data } = await query;
      return jsonResponse(req, 200, { ok: true, documents: data || [] });
    }

    if (path === "/admin/documents" && req.method === "POST") {
      assertSuperAdmin(user);
      const docPayload = {
        doc_type: String(body.docType || "PDF").toUpperCase(),
        category_id: String(body.categoryId || "ac"),
        brand_name: String(body.brandName || "Universal").slice(0, 80),
        model_name: String(body.modelName || "General").slice(0, 100),
        error_code: String(body.errorCode || "").toUpperCase().slice(0, 32),
        title: String(body.title || "Repair Document").slice(0, 180),
        description: String(body.description || "").slice(0, 1000),
        file_url: String(body.fileUrl || ""),
        storage_provider_id: body.storageProviderId || null,
        storage_file_id: body.storageFileId || null,
        mime_type: String(body.mimeType || "application/pdf"),
        file_size_bytes: Number(body.fileSizeBytes) || 0,
        is_published: body.isPublished !== false,
        uploaded_by_uid: user.uid,
        updated_at: new Date().toISOString()
      };
      if (body.id) {
        const { data: updated, error } = await supabase.from("repair_documents").update(docPayload).eq("id", body.id).select().single();
        if (error) throw new HttpError(500, "DB_ERROR", error.message);
        await logAdminActivity(supabase, user, "UPDATE_DOCUMENT", "repair_documents", body.id, docPayload.title);
        return jsonResponse(req, 200, { ok: true, document: updated });
      }
      const { data: created, error } = await supabase.from("repair_documents").insert(docPayload).select().single();
      if (error) throw new HttpError(500, "DB_ERROR", error.message);
      await logAdminActivity(supabase, user, "UPLOAD_DOCUMENT", "repair_documents", created.id, `${docPayload.doc_type}: ${docPayload.title}`);
      return jsonResponse(req, 201, { ok: true, document: created });
    }

    if (path === "/admin/documents/delete" && req.method === "POST") {
      assertSuperAdmin(user);
      const id = String(body.id || "");
      await supabase.from("repair_documents").delete().eq("id", id);
      await logAdminActivity(supabase, user, "DELETE_DOCUMENT", "repair_documents", id, "Deleted document");
      return jsonResponse(req, 200, { ok: true });
    }

    // ---------------- MULTI-CLOUD STORAGE MANAGER (ADMIN) ----------------
    if (path === "/admin/storage/overview" && req.method === "GET") {
      assertSuperAdmin(user);
      const repo = createSupabaseStorageRepo(supabase);
      const [providers, activeCounts, files, errors] = await Promise.all([
        repo.listAllProviders(),
        repo.getActiveFileCountsByProvider(),
        supabase.from("storage_file_registry").select("*").order("created_at", { ascending: false }).limit(100),
        supabase.from("storage_error_logs").select("*").order("created_at", { ascending: false }).limit(100)
      ]);
      const enriched = providers.map((p) => enrichProviderMetadata(p, ADAPTER_DEPS, activeCounts));
      return jsonResponse(req, 200, {
        ok: true,
        providers: enriched,
        files: files.data || [],
        errorLogs: errors.data || []
      });
    }

    if (path === "/admin/verification/signed-url" && req.method === "POST") {
      assertSuperAdmin(user);
      const repo = createSupabaseStorageRepo(supabase);
      const signed = await mintAdminSignedVerificationUrl({
        repo,
        deps: ADAPTER_DEPS,
        privateUrl: body.privateUrl ? String(body.privateUrl) : undefined,
        providerId: body.providerId ? String(body.providerId) : undefined,
        bucket: body.bucket ? String(body.bucket) : undefined,
        objectPath: body.objectPath ? String(body.objectPath) : undefined,
        expiresInSeconds: 120
      });
      await logAdminActivity(
        supabase,
        user,
        "VIEW_VERIFICATION_DOC",
        "technicians",
        String(body.privateUrl || body.objectPath || "verification"),
        "Minted 120s admin signed URL"
      );
      return jsonResponse(req, 200, { ok: true, ...signed });
    }

    if (path === "/admin/storage/providers" && req.method === "POST") {
      assertSuperAdmin(user);
      const endpointUrl = String(body.endpointUrl || "").trim();
      if (!isSafePublicHttpsUrl(endpointUrl)) {
        throw new HttpError(400, "UNSAFE_ENDPOINT", "Storage endpoint must be a public HTTPS URL.");
      }
      const rawPublicBase = String(body.publicBaseUrl || body.public_base_url || "").trim();
      if (rawPublicBase && !isSafePublicHttpsUrl(rawPublicBase)) {
        throw new HttpError(400, "UNSAFE_PUBLIC_BASE_URL", "Public CDN/base URL must be a valid public HTTPS URL.");
      }
      const isPrimary = Boolean(body.isPrimary);
      const normalizedType = normalizeCanonicalProviderType(body.providerType);
      const defaultSecretKey =
        normalizedType === "SUPABASE"
          ? "SUPABASE_SERVICE_ROLE_KEY"
          : normalizedType === "CLOUDFLARE_R2"
          ? "R2_STORAGE_CREDS"
          : normalizedType === "BACKBLAZE_B2"
          ? "B2_STORAGE_CREDS"
          : "S3_STORAGE_CREDS";
      const secretEnvKey = String(body.secretEnvKey || defaultSecretKey).trim().toUpperCase().replace(/[^A-Z0-9_]/g, "");
      if (secretEnvKey.length < 2) {
        throw new HttpError(400, "INVALID_SECRET_REF", "Provide a valid server secret environment variable name.");
      }

      const defaultRegion = normalizedType === "CLOUDFLARE_R2" ? "auto" : normalizedType === "CUSTOM_S3" ? "us-east-1" : "auto";
      const payload: Record<string, unknown> = {
        name: String(body.name || "Storage Provider").trim().slice(0, 100),
        provider_type: normalizedType,
        endpoint_url: endpointUrl,
        project_ref: body.projectRef ? String(body.projectRef).trim().slice(0, 80) : null,
        region: body.region ? String(body.region).trim().slice(0, 48) : defaultRegion,
        public_base_url: rawPublicBase || null,
        secret_env_key: secretEnvKey,
        is_enabled: isPrimary ? true : body.isEnabled !== false,
        is_primary: isPrimary,
        is_backup: isPrimary ? false : Boolean(body.isBackup),
        priority_order: isPrimary ? 1 : (Number(body.priorityOrder) || 10),
        capacity_bytes: Math.max(1024 * 1024, Number(body.capacityBytes) || 1073741824),
        auto_failover_enabled: body.autoFailoverEnabled !== false,
        created_by_uid: user.uid,
        updated_at: new Date().toISOString()
      };
      if (body.bucketMap && typeof body.bucketMap === "object") {
        payload.bucket_map = body.bucketMap;
      }

      const existingId = body.id ? String(body.id).trim() : "";
      const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(existingId);

      if (payload.is_primary) {
        await supabase
          .from("storage_providers")
          .update({ is_primary: false, updated_at: new Date().toISOString() })
          .neq("id", existingId || "00000000-0000-0000-0000-000000000000");
      }

      let savedRow: StorageProviderConfig | null = null;
      if (isUuid) {
        const { data: updated, error } = await supabase
          .from("storage_providers")
          .update(payload)
          .eq("id", existingId)
          .select()
          .maybeSingle();
        if (error) throw new HttpError(500, "DB_ERROR", error.message);
        savedRow = updated as StorageProviderConfig | null;
      }
      if (!savedRow) {
        const { data: created, error } = await supabase
          .from("storage_providers")
          .insert(payload)
          .select()
          .single();
        if (error) throw new HttpError(500, "DB_ERROR", error.message);
        savedRow = created as StorageProviderConfig;
      }

      const repo = createSupabaseStorageRepo(supabase);
      const [allProviders, activeCounts] = await Promise.all([
        repo.listAllProviders(),
        repo.getActiveFileCountsByProvider()
      ]);
      const enriched = allProviders.map((p) => enrichProviderMetadata(p, ADAPTER_DEPS, activeCounts));

      await logAdminActivity(
        supabase,
        user,
        isUuid ? "UPDATE_STORAGE_PROVIDER" : "ADD_STORAGE_PROVIDER",
        "storage_providers",
        savedRow.id,
        `${payload.name} (${payload.provider_type})`
      );
      return jsonResponse(req, isUuid ? 200 : 201, {
        ok: true,
        provider: enrichProviderMetadata(savedRow, ADAPTER_DEPS, activeCounts),
        providers: enriched
      });
    }

    if (path === "/admin/storage/providers/action" && req.method === "POST") {
      assertSuperAdmin(user);
      const repo = createSupabaseStorageRepo(supabase);
      const providerId = String(body.providerId || "").trim();
      const action = String(body.action || "").toUpperCase();
      const provider = await repo.getProviderById(providerId);
      if (!provider) throw new HttpError(404, "NOT_FOUND", "Storage provider not found.");

      let extraResult: Record<string, unknown> = {};
      if (action === "TEST") {
        const result = await testAndRecordProviderConnection(repo, provider, ADAPTER_DEPS);
        await logAdminActivity(supabase, user, "TEST_STORAGE_PROVIDER", "storage_providers", providerId, `${provider.name}: ${result.status}`);
        extraResult = result;
      } else if (action === "SET_PRIMARY") {
        await supabase.from("storage_providers").update({ is_primary: false, updated_at: new Date().toISOString() }).neq("id", providerId);
        await supabase.from("storage_providers").update({
          is_primary: true,
          is_backup: false,
          is_enabled: true,
          priority_order: 1,
          updated_at: new Date().toISOString()
        }).eq("id", providerId);
      } else if (action === "SET_BACKUP") {
        await supabase.from("storage_providers").update({
          is_backup: true,
          is_primary: false,
          is_enabled: true,
          priority_order: Math.max(2, Number(provider.priority_order) || 2),
          updated_at: new Date().toISOString()
        }).eq("id", providerId);
      } else if (action === "TOGGLE_BACKUP") {
        await supabase.from("storage_providers").update({
          is_backup: !provider.is_backup,
          updated_at: new Date().toISOString()
        }).eq("id", providerId);
      } else if (action === "TOGGLE_ENABLED") {
        await supabase.from("storage_providers").update({
          is_enabled: !provider.is_enabled,
          updated_at: new Date().toISOString()
        }).eq("id", providerId);
      } else if (action === "TOGGLE_FAILOVER") {
        await supabase.from("storage_providers").update({
          auto_failover_enabled: !provider.auto_failover_enabled,
          updated_at: new Date().toISOString()
        }).eq("id", providerId);
      } else if (action === "DELETE") {
        await deleteStorageProviderSafe(repo, providerId);
      } else if (action === "MIGRATE") {
        const targetProviderId = String(body.targetProviderId || "").trim();
        const limit = Number(body.limit) || 50;
        const migration = await migrateProviderFiles({
          repo,
          deps: ADAPTER_DEPS,
          sourceProviderId: providerId,
          targetProviderId,
          limit
        });
        await logAdminActivity(
          supabase,
          user,
          "MIGRATE_STORAGE_FILES",
          "storage_providers",
          providerId,
          `Migrated ${migration.migratedCount} files (${migration.bytesMigrated} bytes, sha256=${migration.checksumVerified}) -> ${targetProviderId}`
        );
        extraResult = migration;
      } else {
        throw new HttpError(400, "INVALID_ACTION", `Unsupported storage action: ${action}`);
      }

      const [allProviders, activeCounts] = await Promise.all([
        repo.listAllProviders(),
        repo.getActiveFileCountsByProvider()
      ]);
      const enriched = allProviders.map((p) => enrichProviderMetadata(p, ADAPTER_DEPS, activeCounts));

      if (action !== "TEST" && action !== "MIGRATE") {
        await logAdminActivity(supabase, user, `STORAGE_${action}`, "storage_providers", providerId, provider.name);
      }
      return jsonResponse(req, 200, { ok: true, ...extraResult, providers: enriched });
    }

    // ---------------- ADMIN DASHBOARD, USERS, NOTIFICATIONS, SETTINGS & LOGS ----------------
    if (path === "/admin/users" && req.method === "GET") {
      assertSuperAdmin(user);
      const { data } = await supabase.from("user_profiles").select("*").order("last_seen_at", { ascending: false }).limit(200);
      return jsonResponse(req, 200, { ok: true, users: data || [] });
    }

    if (path === "/admin/users/block" && req.method === "POST") {
      assertSuperAdmin(user);
      const targetUid = String(body.firebaseUid || "");
      const isBlocked = Boolean(body.isBlocked);
      await supabase.from("user_profiles").update({
        is_blocked: isBlocked,
        block_reason: body.reason ? String(body.reason).slice(0, 300) : null,
        updated_at: new Date().toISOString()
      }).eq("firebase_uid", targetUid);
      await logAdminActivity(supabase, user, isBlocked ? "BLOCK_USER" : "UNBLOCK_USER", "user_profiles", targetUid, String(body.reason || ""));
      return jsonResponse(req, 200, { ok: true });
    }

    if (path === "/notifications" && req.method === "GET") {
      const { data } = await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(50);
      return jsonResponse(req, 200, { ok: true, notifications: data || [] });
    }

    if (path === "/settings/remote" && req.method === "GET") {
      const [admob, remote] = await Promise.all([
        supabase.from("admob_settings").select("*").eq("id", "default").maybeSingle(),
        supabase.from("app_remote_settings").select("*").eq("id", "default").maybeSingle()
      ]);
      return jsonResponse(req, 200, { ok: true, admob: admob.data, remote: remote.data });
    }

    if (path === "/admin/settings/remote" && req.method === "POST") {
      assertSuperAdmin(user);
      if (body.admob) {
        await supabase.from("admob_settings").upsert({ id: "default", ...body.admob, updated_by_uid: user.uid, updated_at: new Date().toISOString() });
        await logAdminActivity(supabase, user, "UPDATE_ADMOB_SUPABASE", "admob_settings", "default", "Synced AdMob v3.0 config");
      }
      if (body.remote) {
        await supabase.from("app_remote_settings").upsert({ id: "default", ...body.remote, updated_by_uid: user.uid, updated_at: new Date().toISOString() });
        await logAdminActivity(supabase, user, "UPDATE_REMOTE_SETTINGS", "app_remote_settings", "default", "Updated remote v3.0 settings");
      }
      return jsonResponse(req, 200, { ok: true });
    }

    if (path === "/admin/logs" && req.method === "GET") {
      assertSuperAdmin(user);
      const [activity, errors] = await Promise.all([
        supabase.from("admin_activity_logs").select("*").order("created_at", { ascending: false }).limit(100),
        supabase.from("system_error_logs").select("*").order("created_at", { ascending: false }).limit(100)
      ]);
      return jsonResponse(req, 200, { ok: true, activityLogs: activity.data || [], errorLogs: errors.data || [] });
    }

    throw new HttpError(404, "ROUTE_NOT_FOUND", `Unknown endpoint: ${req.method} ${path}`);
  } catch (err) {
    const status = err instanceof HttpError || err instanceof StorageAdapterError ? err.status : 500;
    const code = err instanceof HttpError || err instanceof StorageAdapterError ? err.code : "API_INTERNAL_ERROR";
    const message = err instanceof Error ? err.message : "Unexpected backend error";
    return jsonResponse(req, status, { ok: false, code, error: message, keepSession: true });
  }
});
