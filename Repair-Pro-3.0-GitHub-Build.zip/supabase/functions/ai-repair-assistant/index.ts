// Repair Pro — AI Smart Repair Assistant Edge Function
// Supports Google Gemini, Groq, OpenRouter, OpenAI-Compatible, and Custom HTTPS Endpoints.
// Enforces:
//   - Firebase Authentication Bearer ID token
//   - Multi-provider Primary -> Secondary -> Backup automatic failover
//   - Free Only Mode + explicit admin authorization guard for any paid model/provider
//   - Admin-only restriction on providerOverride, modelOverride, endpointOverride, tempApiKey
//   - Strict SSRF & HTTPS endpoint validation (redirect: "error")
//   - Atomic server-side quota enforcement via PostgreSQL RPC reserve_ai_quota / release_ai_quota
//   - Private AI API keys kept strictly server-side (Edge Secrets / RLS-locked hosting_provider_secrets)

const PROJECT_ID = "gen-lang-client-0218221723";
const FIRESTORE_DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
const DEFAULT_FIREBASE_WEB_API_KEY = "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M";
const DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";

const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

type ProviderType = "GEMINI" | "GROQ" | "OPENROUTER" | "OPENAI_COMPATIBLE" | "CUSTOM_PROXY";
type ProviderRole = "PRIMARY" | "SECONDARY" | "BACKUP" | "DISABLED";

interface AiProviderProfile {
  providerId: string;
  label: string;
  providerType: ProviderType;
  role: ProviderRole;
  enabled: boolean;
  isFree: boolean;
  adminPaidApproved: boolean;
  endpointUrl: string;
  model: string;
  dailyLimit: number;
  perUserLimit: number;
}

interface AiRemoteConfig {
  aiEnabled: boolean;
  aiFreeOnlyMode: boolean;
  aiAllowPaidFallback: boolean;
  aiAutoFailoverEnabled: boolean;
  aiProvider: ProviderType;
  aiModel: string;
  aiEndpointUrl: string;
  aiDailyLimit: number;
  aiPerUserLimit: number;
  aiSystemInstructions: string;
  providers: AiProviderProfile[];
}

const PROVIDER_DEFAULTS: Record<ProviderType, { defaultEndpoint: string; defaultModel: string; allowedHost?: string }> = {
  GEMINI: {
    defaultEndpoint: "https://generativelanguage.googleapis.com",
    defaultModel: "gemini-2.5-flash",
    allowedHost: "generativelanguage.googleapis.com"
  },
  GROQ: {
    defaultEndpoint: "https://api.groq.com/openai/v1/chat/completions",
    defaultModel: "llama-3.3-70b-versatile",
    allowedHost: "api.groq.com"
  },
  OPENROUTER: {
    defaultEndpoint: "https://openrouter.ai/api/v1/chat/completions",
    defaultModel: "meta-llama/llama-3.3-70b-instruct:free",
    allowedHost: "openrouter.ai"
  },
  OPENAI_COMPATIBLE: {
    defaultEndpoint: "https://api.openai.com/v1/chat/completions",
    defaultModel: "gpt-4o-mini"
  },
  CUSTOM_PROXY: {
    defaultEndpoint: "",
    defaultModel: "custom-model"
  }
};

function jsonResponse(status: number, payload: Record<string, unknown>): Response {
  return new Response(JSON.stringify(payload), { status, headers: corsHeaders });
}

function normalizeProviderType(raw: unknown): ProviderType {
  const up = String(raw || "GEMINI").trim().toUpperCase();
  if (up === "GEMINI" || up === "GROQ" || up === "OPENROUTER" || up === "OPENAI_COMPATIBLE" || up === "CUSTOM_PROXY") {
    return up;
  }
  return "GEMINI";
}

function normalizeRole(raw: unknown): ProviderRole {
  const up = String(raw || "BACKUP").trim().toUpperCase();
  if (up === "PRIMARY" || up === "SECONDARY" || up === "BACKUP" || up === "DISABLED") {
    return up;
  }
  return "BACKUP";
}

function roleWeight(role: ProviderRole): number {
  switch (role) {
    case "PRIMARY": return 0;
    case "SECONDARY": return 1;
    case "BACKUP": return 2;
    default: return 3;
  }
}

function isIpv4Literal(host: string): boolean {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(host) || /^\d+$/.test(host) || /^0x[0-9a-f]+$/i.test(host);
}

function isPrivateOrBlockedHost(rawHost: string): boolean {
  const host = rawHost.replace(/^\[|\]$/g, "").toLowerCase();
  if (!host) return true;
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host.endsWith(".internal") ||
    host.endsWith(".localdomain") ||
    host === "metadata" ||
    host === "metadata.google.internal"
  ) {
    return true;
  }

  // Block raw IPv6 addresses (loopback ::1, link-local fe80::/10, ULA fc00::/7, IPv4-mapped ::ffff:, etc.)
  if (host.includes(":")) return true;

  // Block raw IPv4 / integer / hex IP literals so internal IPs (127.0.0.1, 169.254.169.254, 10.*, 172.16-31.*, 192.168.*, 100.64.*) cannot be targeted
  if (isIpv4Literal(host)) return true;

  // Require standard public FQDN with at least one dot
  if (!host.includes(".")) return true;

  return false;
}

function validateAiEndpointUrl(providerType: ProviderType, rawUrl: string): string {
  const candidate = (rawUrl || PROVIDER_DEFAULTS[providerType].defaultEndpoint).trim();
  if (!candidate) {
    throw new Error(`Endpoint URL is required for ${providerType}.`);
  }
  let parsed: URL;
  try {
    parsed = new URL(candidate);
  } catch {
    throw new Error(`Invalid endpoint URL for ${providerType}.`);
  }
  if (parsed.protocol !== "https:") {
    throw new Error("AI endpoint URL must strictly use HTTPS.");
  }
  if (parsed.username || parsed.password) {
    throw new Error("AI endpoint URL must not embed credentials.");
  }
  const host = parsed.hostname.toLowerCase();
  if (isPrivateOrBlockedHost(host)) {
    throw new Error(`Blocked or private host "${host}" is not allowed.`);
  }
  const requiredHost = PROVIDER_DEFAULTS[providerType].allowedHost;
  if (requiredHost && host !== requiredHost) {
    throw new Error(`${providerType} must use official host ${requiredHost}.`);
  }
  return parsed.toString();
}

function isOpenRouterFreeModel(model: string): boolean {
  const m = model.trim().toLowerCase();
  return m === "openrouter/free" || m.endsWith(":free");
}

function isProviderEligible(provider: AiProviderProfile, config: AiRemoteConfig): boolean {
  if (!provider.enabled || provider.role === "DISABLED") return false;
  if (config.aiFreeOnlyMode) {
    if (!provider.isFree) return false;
    if (provider.providerType === "OPENROUTER" && !isOpenRouterFreeModel(provider.model)) {
      return false;
    }
    return true;
  }
  if (!provider.isFree) {
    return config.aiAllowPaidFallback && provider.adminPaidApproved;
  }
  return true;
}

async function verifyFirebaseIdToken(idToken: string): Promise<{ uid: string; email: string; emailVerified: boolean }> {
  const webApiKey = Deno.env.get("FIREBASE_WEB_API_KEY") || DEFAULT_FIREBASE_WEB_API_KEY;
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(webApiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken })
  });
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(data?.error?.message || "Invalid or expired Firebase ID token.");
  }
  const user = data.users[0];
  return {
    uid: String(user.localId || ""),
    email: String(user.email || ""),
    emailVerified: Boolean(user.emailVerified)
  };
}

function base64UrlEncode(input: Uint8Array | string): string {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function pemToArrayBuffer(pem: string): ArrayBuffer {
  const clean = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s+/g, "");
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function getGoogleAccessToken(serviceAccount: { client_email: string; private_key: string; token_uri?: string }): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlEncode(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claimSet = base64UrlEncode(JSON.stringify({
    iss: serviceAccount.client_email,
    scope: "https://www.googleapis.com/auth/datastore",
    aud: serviceAccount.token_uri || "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600
  }));
  const signingInput = `${header}.${claimSet}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToArrayBuffer(serviceAccount.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(signingInput));
  const jwt = `${signingInput}.${base64UrlEncode(new Uint8Array(signature))}`;
  const resp = await fetch(serviceAccount.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt })
  });
  const data = await resp.json();
  if (!resp.ok || !data.access_token) throw new Error("Google OAuth2 failed");
  return data.access_token;
}

async function isAuthorizedAdmin(uid: string, email: string, emailVerified: boolean): Promise<boolean> {
  if (emailVerified && email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) return true;
  const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
  if (!saRaw.trim()) return false;
  try {
    const token = await getGoogleAccessToken(JSON.parse(saRaw));
    const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/admins/${encodeURIComponent(uid)}`;
    const resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    return resp.ok;
  } catch {
    return false;
  }
}

const DEFAULT_PROVIDER_LIST: AiProviderProfile[] = [
  {
    providerId: "gemini_free_primary",
    label: "Google Gemini (Free Tier)",
    providerType: "GEMINI",
    role: "PRIMARY",
    enabled: true,
    isFree: true,
    adminPaidApproved: false,
    endpointUrl: PROVIDER_DEFAULTS.GEMINI.defaultEndpoint,
    model: PROVIDER_DEFAULTS.GEMINI.defaultModel,
    dailyLimit: 500,
    perUserLimit: 15
  }
];

const DEFAULT_AI_CONFIG: AiRemoteConfig = {
  aiEnabled: true,
  aiFreeOnlyMode: true,
  aiAllowPaidFallback: false,
  aiAutoFailoverEnabled: true,
  aiProvider: "GEMINI",
  aiModel: "gemini-2.5-flash",
  aiEndpointUrl: "",
  aiDailyLimit: 500,
  aiPerUserLimit: 15,
  aiSystemInstructions: "",
  providers: DEFAULT_PROVIDER_LIST
};

function parseProvidersList(rawJson: string, fallbackType: ProviderType, fallbackModel: string, fallbackEndpoint: string, fallbackDailyLimit: number, fallbackUserLimit: number): AiProviderProfile[] {
  if (rawJson.trim()) {
    try {
      const arr = JSON.parse(rawJson);
      if (Array.isArray(arr) && arr.length > 0) {
        const mapped = arr.map((item: Record<string, unknown>, idx: number): AiProviderProfile => {
          const pType = normalizeProviderType(item.providerType);
          const defaults = PROVIDER_DEFAULTS[pType];
          const isFree = item.isFree !== undefined ? Boolean(item.isFree) : (pType === "GEMINI" || pType === "GROQ" || pType === "OPENROUTER");
          return {
            providerId: String(item.providerId || `ai_prov_${idx}`).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 64),
            label: String(item.label || item.providerName || pType).slice(0, 80),
            providerType: pType,
            role: normalizeRole(item.role),
            enabled: item.enabled !== false,
            isFree,
            adminPaidApproved: Boolean(item.adminPaidApproved),
            endpointUrl: String(item.endpointUrl || defaults.defaultEndpoint).trim(),
            model: String(item.model || defaults.defaultModel).trim().slice(0, 120),
            dailyLimit: Math.max(0, Number(item.dailyLimit ?? fallbackDailyLimit ?? 500)),
            perUserLimit: Math.max(0, Number(item.perUserLimit ?? fallbackUserLimit ?? 15))
          };
        });
        if (mapped.length > 0) return mapped;
      }
    } catch {
      // fall through to single-provider compat
    }
  }
  const defaults = PROVIDER_DEFAULTS[fallbackType];
  return [
    {
      providerId: `legacy_${fallbackType.toLowerCase()}`,
      label: `${fallbackType} Primary`,
      providerType: fallbackType,
      role: "PRIMARY",
      enabled: true,
      isFree: fallbackType === "GEMINI" || fallbackType === "GROQ" || fallbackType === "OPENROUTER",
      adminPaidApproved: false,
      endpointUrl: fallbackEndpoint || defaults.defaultEndpoint,
      model: fallbackModel || defaults.defaultModel,
      dailyLimit: fallbackDailyLimit,
      perUserLimit: fallbackUserLimit
    }
  ];
}

async function loadAiConfigFromFirestore(): Promise<AiRemoteConfig> {
  const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
  if (!saRaw.trim()) return DEFAULT_AI_CONFIG;
  try {
    const token = await getGoogleAccessToken(JSON.parse(saRaw));
    const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/app_settings/ai_config`;
    const resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!resp.ok) return DEFAULT_AI_CONFIG;
    const doc = await resp.json();
    const f = doc?.fields || {};
    const aiProvider = normalizeProviderType(f.aiProvider?.stringValue || "GEMINI");
    const aiModel = String(f.aiModel?.stringValue || PROVIDER_DEFAULTS[aiProvider].defaultModel);
    const aiEndpointUrl = String(f.aiEndpointUrl?.stringValue || "");
    const aiDailyLimit = Math.max(0, Number(f.aiDailyLimit?.integerValue ?? 500));
    const aiPerUserLimit = Math.max(0, Number(f.aiPerUserLimit?.integerValue ?? 15));
    const providersRaw = String(f.aiProvidersJson?.stringValue || "");

    return {
      aiEnabled: f.aiEnabled?.booleanValue !== undefined ? Boolean(f.aiEnabled.booleanValue) : true,
      aiFreeOnlyMode: f.aiFreeOnlyMode?.booleanValue !== undefined ? Boolean(f.aiFreeOnlyMode.booleanValue) : true,
      aiAllowPaidFallback: f.aiAllowPaidFallback?.booleanValue !== undefined ? Boolean(f.aiAllowPaidFallback.booleanValue) : false,
      aiAutoFailoverEnabled: f.aiAutoFailoverEnabled?.booleanValue !== undefined ? Boolean(f.aiAutoFailoverEnabled.booleanValue) : true,
      aiProvider,
      aiModel,
      aiEndpointUrl,
      aiDailyLimit,
      aiPerUserLimit,
      aiSystemInstructions: String(f.aiSystemInstructions?.stringValue || ""),
      providers: parseProvidersList(providersRaw, aiProvider, aiModel, aiEndpointUrl, aiDailyLimit, aiPerUserLimit)
    };
  } catch {
    return DEFAULT_AI_CONFIG;
  }
}

function getSupabaseServiceEnv() {
  const url = (Deno.env.get("SUPABASE_URL") || DEFAULT_SUPABASE_URL).replace(/\/+$/, "");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  return { url, serviceKey };
}

function envKeyForProviderType(providerType: ProviderType): string {
  switch (providerType) {
    case "GEMINI": return (Deno.env.get("GEMINI_API_KEY") || "").trim();
    case "GROQ": return (Deno.env.get("GROQ_API_KEY") || "").trim();
    case "OPENROUTER": return (Deno.env.get("OPENROUTER_API_KEY") || "").trim();
    case "OPENAI_COMPATIBLE": return (Deno.env.get("OPENAI_API_KEY") || Deno.env.get("CUSTOM_AI_API_KEY") || "").trim();
    case "CUSTOM_PROXY": return (Deno.env.get("CUSTOM_AI_API_KEY") || "").trim();
  }
}

async function fetchSecretFromVault(secretKeyId: string): Promise<string> {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey || !secretKeyId) return "";
  try {
    const resp = await fetch(
      `${url}/rest/v1/hosting_provider_secrets?provider_id=eq.${encodeURIComponent(secretKeyId)}&select=api_secret&limit=1`,
      { headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` } }
    );
    if (!resp.ok) return "";
    const rows = await resp.json();
    if (Array.isArray(rows) && rows[0]?.api_secret) {
      return String(rows[0].api_secret).trim();
    }
  } catch {
    // ignore
  }
  return "";
}

async function resolveProviderApiKey(providerType: ProviderType, providerId = ""): Promise<string> {
  if (providerId.trim()) {
    const cleanId = providerId.trim().replace(/[^a-zA-Z0-9_-]/g, "_");
    const specificVault = await fetchSecretFromVault(`ai_prov_key_${cleanId}`);
    if (specificVault) return specificVault;
  }
  const typeVault = await fetchSecretFromVault(`ai_key_${providerType.toLowerCase()}`);
  if (typeVault) return typeVault;

  return envKeyForProviderType(providerType);
}

async function saveAiProviderKey(params: {
  providerType: ProviderType;
  providerId: string;
  apiKey: string;
  adminUid: string;
}): Promise<string> {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey) throw new Error("SUPABASE_SERVICE_ROLE_KEY secret is not configured in Edge Function.");
  const cleanId = params.providerId.trim().replace(/[^a-zA-Z0-9_-]/g, "_");
  const vaultKeyId = cleanId
    ? `ai_prov_key_${cleanId}`
    : `ai_key_${params.providerType.toLowerCase()}`;

  const resp = await fetch(`${url}/rest/v1/hosting_provider_secrets?on_conflict=provider_id`, {
    method: "POST",
    headers: {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates,return=minimal"
    },
    body: JSON.stringify({
      provider_id: vaultKeyId.slice(0, 128),
      auth_mode: `AI_${params.providerType}`,
      api_secret: params.apiKey.trim(),
      updated_by_uid: params.adminUid,
      updated_at: new Date().toISOString()
    })
  });
  if (!resp.ok) {
    const txt = await resp.text().catch(() => "");
    throw new Error(`Could not save AI key (HTTP ${resp.status}): ${txt.slice(0, 150)}`);
  }
  return vaultKeyId;
}

async function reserveAiQuotaAtomic(params: {
  uid: string;
  providerId: string;
  globalLimit: number;
  userLimit: number;
  providerLimit: number;
}): Promise<{ allowed: boolean; blockedScope: string; reason: string; globalUsed: number; userUsed: number; providerUsed: number }> {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey) {
    return { allowed: true, blockedScope: "", reason: "", globalUsed: 0, userUsed: 0, providerUsed: 0 };
  }
  const today = new Date().toISOString().slice(0, 10);
  try {
    const resp = await fetch(`${url}/rest/v1/rpc/reserve_ai_quota`, {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        p_usage_date: today,
        p_user_id: params.uid,
        p_provider_id: params.providerId,
        p_global_limit: params.globalLimit,
        p_user_limit: params.userLimit,
        p_provider_limit: params.providerLimit
      })
    });
    if (resp.ok) {
      const data = await resp.json();
      return {
        allowed: Boolean(data?.allowed),
        blockedScope: String(data?.blocked_scope || ""),
        reason: String(data?.reason || ""),
        globalUsed: Number(data?.global_used || 0),
        userUsed: Number(data?.user_used || 0),
        providerUsed: Number(data?.provider_used || 0)
      };
    }
  } catch {
    // Fallback below if reserve_ai_quota RPC has not been applied yet
  }

  // Fallback read-check against ai_usage_logs so quota limits remain enforced even before migration update
  try {
    const [gResp, uResp, pResp] = await Promise.all([
      fetch(`${url}/rest/v1/ai_usage_logs?usage_date=eq.${today}&status=eq.SUCCESS&select=usage_id`, {
        headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` }
      }),
      fetch(`${url}/rest/v1/ai_usage_logs?usage_date=eq.${today}&user_id=eq.${encodeURIComponent(params.uid)}&status=eq.SUCCESS&select=usage_id`, {
        headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` }
      }),
      fetch(`${url}/rest/v1/ai_usage_logs?usage_date=eq.${today}&provider_id=eq.${encodeURIComponent(params.providerId)}&status=eq.SUCCESS&select=usage_id`, {
        headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` }
      })
    ]);
    const globalUsed = gResp.ok ? ((await gResp.json()) as unknown[]).length : 0;
    const userUsed = uResp.ok ? ((await uResp.json()) as unknown[]).length : 0;
    const providerUsed = pResp.ok ? ((await pResp.json()) as unknown[]).length : 0;
    if (params.globalLimit > 0 && globalUsed >= params.globalLimit) {
      return { allowed: false, blockedScope: "global", reason: "Global daily AI quota reached.", globalUsed, userUsed, providerUsed };
    }
    if (params.userLimit > 0 && userUsed >= params.userLimit) {
      return { allowed: false, blockedScope: "user", reason: `Your daily AI limit (${params.userLimit} requests/day) has been reached.`, globalUsed, userUsed, providerUsed };
    }
    if (params.providerLimit > 0 && providerUsed >= params.providerLimit) {
      return { allowed: false, blockedScope: "provider", reason: `Provider daily quota (${params.providerLimit}) reached.`, globalUsed, userUsed, providerUsed };
    }
    return { allowed: true, blockedScope: "", reason: "", globalUsed: globalUsed + 1, userUsed: userUsed + 1, providerUsed: providerUsed + 1 };
  } catch {
    return { allowed: false, blockedScope: "global", reason: "Quota verification service unavailable.", globalUsed: 0, userUsed: 0, providerUsed: 0 };
  }
}

async function releaseAiQuotaAtomic(uid: string, providerId: string) {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey) return;
  const today = new Date().toISOString().slice(0, 10);
  await fetch(`${url}/rest/v1/rpc/release_ai_quota`, {
    method: "POST",
    headers: {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      p_usage_date: today,
      p_user_id: uid,
      p_provider_id: providerId
    })
  }).catch(() => {});
}

async function logAiUsage(params: {
  uid: string;
  providerId: string;
  provider: string;
  modelName: string;
  appliance: string;
  language: string;
  isFree: boolean;
  failoverUsed: boolean;
  status: "SUCCESS" | "RATE_LIMITED" | "FAILED";
}) {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey) return;
  await fetch(`${url}/rest/v1/ai_usage_logs`, {
    method: "POST",
    headers: {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      usage_id: `aiu_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      user_id: params.uid,
      usage_date: new Date().toISOString().slice(0, 10),
      provider_id: params.providerId.slice(0, 80),
      provider: params.provider.slice(0, 40),
      model_name: params.modelName.slice(0, 80),
      appliance: params.appliance.slice(0, 60),
      language: ["en", "bn", "hi"].includes(params.language) ? params.language : "en",
      is_free: params.isFree,
      failover_used: params.failoverUsed,
      status: params.status
    })
  }).catch(() => {});
}

async function logAiError(uid: string, providerId: string, provider: string, model: string, errorCode: string, errorMessage: string) {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey) return;
  await fetch(`${url}/rest/v1/ai_error_logs`, {
    method: "POST",
    headers: {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      error_id: `aie_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      user_id: uid,
      provider_id: providerId.slice(0, 80),
      provider: provider.slice(0, 40),
      model_name: model.slice(0, 80),
      error_code: errorCode.slice(0, 64),
      error_message: errorMessage.slice(0, 600)
    })
  }).catch(() => {});
}

function buildSafetyDiagnosticPrompt(input: {
  appliance: string;
  brand: string;
  model: string;
  problem: string;
  errorCode: string;
  language: string;
  adminInstructions: string;
}): { systemPrompt: string; userPrompt: string } {
  const langLabel = input.language === "bn"
    ? "Bengali (বাংলা)"
    : input.language === "hi"
      ? "Hindi (हिंदी)"
      : "English";

  const systemPrompt = [
    "You are Repair Pro Smart Assistant, a careful appliance repair diagnostic helper for Air Conditioners, Refrigerators, and Washing Machines.",
    `Respond strictly in ${langLabel}.`,
    "CRITICAL ENGINEERING & SAFETY RULES:",
    "1. Distinguish clearly between POSSIBLE CAUSES vs CONFIRMED DIAGNOSIS. Do not claim a component is broken unless physical tests confirm it.",
    "2. NEVER invent or guess model-specific error code meanings, PCB pinouts, resistance values, capacitor ratings, or refrigerant charge specs if you are not 100% certain. If an error code or model cannot be verified with certainty, explicitly state that it could not be verified and advise checking the official service manual or OEM sticker.",
    "3. Always begin or include a clear ELECTRICAL & REFRIGERANT SAFETY WARNING (unplug mains power, discharge high-voltage capacitors, handle R600a/R32/R410A with certified tools and ventilation).",
    "4. Return clean valid JSON ONLY (no markdown fences) with these exact keys:",
    "   {",
    '     "safetyWarning": string,',
    '     "errorCodeStatus": "VERIFIED_GENERAL" | "UNVERIFIED" | "NOT_PROVIDED",',
    '     "errorCodeExplanation": string,',
    '     "possibleCauses": string[],',
    '     "componentsToInspect": string[],',
    '     "diagnosticChecks": string[],',
    '     "safeTroubleshootingSteps": string[],',
    '     "repairOptions": string[],',
    '     "followUpQuestions": string[],',
    '     "summaryNote": string',
    "   }",
    input.adminInstructions ? `ADMIN GUIDANCE: ${input.adminInstructions.slice(0, 1000)}` : ""
  ].filter(Boolean).join("\n");

  const userPrompt = [
    `Appliance Type: ${input.appliance}`,
    `Brand / Company: ${input.brand}`,
    `Model Number: ${input.model || "Not specified"}`,
    `Reported Symptoms / Problem: ${input.problem}`,
    `Displayed Error Code: ${input.errorCode || "None / Not entered"}`,
    `Preferred Output Language: ${langLabel}`
  ].join("\n");

  return { systemPrompt, userPrompt };
}

async function callGeminiAdapter(apiKey: string, model: string, systemPrompt: string, userPrompt: string): Promise<string> {
  const cleanModel = (model || "gemini-2.5-flash").replace(/^models\//, "");
  const endpoint = validateAiEndpointUrl(
    "GEMINI",
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cleanModel)}:generateContent`
  );
  const resp = await fetch(`${endpoint}?key=${encodeURIComponent(apiKey)}`, {
    method: "POST",
    redirect: "error",
    signal: AbortSignal.timeout(25_000),
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents: [{ role: "user", parts: [{ text: userPrompt }] }],
      generationConfig: {
        temperature: 0.2,
        responseMimeType: "application/json"
      }
    })
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    const err = new Error(data?.error?.message || `Gemini HTTP ${resp.status}`) as Error & { status?: number };
    err.status = resp.status;
    throw err;
  }
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
  if (!text.trim()) throw new Error("Gemini returned an empty response.");
  return text;
}

async function callOpenAiCompatibleAdapter(
  providerType: ProviderType,
  endpointUrl: string,
  apiKey: string,
  model: string,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  const target = validateAiEndpointUrl(providerType, endpointUrl);
  const headers: Record<string, string> = {
    Authorization: `Bearer ${apiKey}`,
    "Content-Type": "application/json"
  };
  if (providerType === "OPENROUTER") {
    headers["HTTP-Referer"] = "https://repairpro.app";
    headers["X-Title"] = "Repair Pro 3.0";
  }
  const resp = await fetch(target, {
    method: "POST",
    redirect: "error",
    signal: AbortSignal.timeout(25_000),
    headers,
    body: JSON.stringify({
      model: model || PROVIDER_DEFAULTS[providerType].defaultModel,
      temperature: 0.2,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ]
    })
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    const err = new Error(data?.error?.message || `${providerType} HTTP ${resp.status}`) as Error & { status?: number };
    err.status = resp.status;
    throw err;
  }
  const content = data?.choices?.[0]?.message?.content || data?.output_text || "";
  if (!String(content).trim()) throw new Error(`${providerType} returned empty output.`);
  return String(content);
}

async function invokeProvider(
  providerType: ProviderType,
  endpointUrl: string,
  apiKey: string,
  model: string,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  if (providerType === "GEMINI") {
    return await callGeminiAdapter(apiKey, model, systemPrompt, userPrompt);
  }
  return await callOpenAiCompatibleAdapter(providerType, endpointUrl, apiKey, model, systemPrompt, userPrompt);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse(405, { ok: false, errorCode: "METHOD_NOT_ALLOWED", message: "Use POST." });

  let callerUid = "";
  let activeProviderId = "";
  let activeProviderType: ProviderType = "GEMINI";
  let activeModel = "gemini-2.5-flash";

  try {
    const authHeader = req.headers.get("authorization") || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    if (!idToken) return jsonResponse(401, { ok: false, errorCode: "MISSING_AUTH_TOKEN", message: "Sign in with Google first." });
    const caller = await verifyFirebaseIdToken(idToken);
    callerUid = caller.uid;

    const body = await req.json();
    const action = String(body?.action || "diagnose").toLowerCase();
    const config = await loadAiConfigFromFirestore();

    // 1. Admin-only API key vault write
    if (action === "save_ai_key") {
      const admin = await isAuthorizedAdmin(caller.uid, caller.email, caller.emailVerified);
      if (!admin) return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Admin access required." });
      const targetType = normalizeProviderType(body?.providerOverride || config.aiProvider);
      const targetProviderId = String(body?.providerIdOverride || "").trim().slice(0, 64);
      const apiKey = String(body?.apiKey || "").trim();
      if (apiKey.length < 10) return jsonResponse(400, { ok: false, errorCode: "VALIDATION_ERROR", message: "Valid API key required." });
      const vaultKeyId = await saveAiProviderKey({
        providerType: targetType,
        providerId: targetProviderId,
        apiKey,
        adminUid: caller.uid
      });
      return jsonResponse(200, {
        ok: true,
        provider: targetType,
        providerId: targetProviderId,
        vaultKeyId,
        message: "AI provider API key saved securely on backend (never sent to APK or Firestore)."
      });
    }

    // 2. Admin-only provider connection test (overrides strictly gated behind admin RBAC)
    if (action === "test_connection") {
      const admin = await isAuthorizedAdmin(caller.uid, caller.email, caller.emailVerified);
      if (!admin) return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Admin access required." });

      const targetProviderId = String(body?.providerIdOverride || "").trim().slice(0, 64);
      const matchedProfile = targetProviderId
        ? config.providers.find((p) => p.providerId === targetProviderId)
        : undefined;
      const targetType = normalizeProviderType(body?.providerOverride || matchedProfile?.providerType || config.aiProvider);
      const targetModel = String(body?.modelOverride || matchedProfile?.model || config.aiModel || PROVIDER_DEFAULTS[targetType].defaultModel).trim();
      const rawEndpoint = String(body?.endpointOverride || matchedProfile?.endpointUrl || config.aiEndpointUrl || PROVIDER_DEFAULTS[targetType].defaultEndpoint).trim();
      const validatedEndpoint = validateAiEndpointUrl(targetType, rawEndpoint);

      activeProviderId = targetProviderId || `test_${targetType.toLowerCase()}`;
      activeProviderType = targetType;
      activeModel = targetModel;

      const apiKey = String(body?.tempApiKey || "").trim() || await resolveProviderApiKey(targetType, targetProviderId);
      if (!apiKey) {
        return jsonResponse(400, {
          ok: false,
          errorCode: "AI_KEY_MISSING",
          message: `No backend API key found for ${targetType}${targetProviderId ? ` (${targetProviderId})` : ""}. Save it via AI Key Vault or Supabase Edge Secrets.`
        });
      }

      const { systemPrompt, userPrompt } = buildSafetyDiagnosticPrompt({
        appliance: "Air Conditioner",
        brand: "Generic",
        model: "",
        problem: "Connection test: indoor blower fan does not start after power-on.",
        errorCode: "",
        language: "en",
        adminInstructions: ""
      });

      const raw = await invokeProvider(targetType, validatedEndpoint, apiKey, targetModel, systemPrompt, userPrompt);
      return jsonResponse(200, {
        ok: true,
        provider: targetType,
        providerId: activeProviderId,
        model: targetModel,
        sampleLength: raw.length,
        message: "AI provider connection verified successfully."
      });
    }

    if (action !== "diagnose") {
      return jsonResponse(400, { ok: false, errorCode: "UNKNOWN_ACTION", message: "Unsupported action." });
    }

    // 3. Reject any client-supplied override fields on diagnose endpoint
    const hasOverrideAttempt = [
      body?.providerOverride,
      body?.providerIdOverride,
      body?.modelOverride,
      body?.endpointOverride,
      body?.tempApiKey
    ].some((v) => v !== undefined && v !== null && String(v).trim() !== "");
    if (hasOverrideAttempt) {
      return jsonResponse(403, {
        ok: false,
        errorCode: "ADMIN_OVERRIDE_FORBIDDEN",
        message: "Provider, model, and endpoint overrides are restricted to authorized administrator connection tests."
      });
    }

    if (!config.aiEnabled) {
      return jsonResponse(503, { ok: false, errorCode: "AI_DISABLED", message: "AI Smart Repair Assistant is currently disabled by administrator." });
    }

    const appliance = String(body?.appliance || "").trim().slice(0, 60);
    const brand = String(body?.brand || "").trim().slice(0, 60);
    const model = String(body?.model || "").trim().slice(0, 80);
    const problem = String(body?.problem || "").trim().slice(0, 1200);
    const errorCode = String(body?.errorCode || "").trim().slice(0, 32);
    const language = ["en", "bn", "hi"].includes(String(body?.language)) ? String(body.language) : "en";

    if (!appliance || !brand || problem.length < 4) {
      return jsonResponse(400, {
        ok: false,
        errorCode: "VALIDATION_ERROR",
        message: "Appliance, Brand, and Problem description are required."
      });
    }

    // 4. Filter administrator-approved providers strictly respecting Free Only Mode & explicit paid authorization
    const approvedProviders = [...config.providers]
      .filter((p) => isProviderEligible(p, config))
      .sort((a, b) => roleWeight(a.role) - roleWeight(b.role));

    if (approvedProviders.length === 0) {
      return jsonResponse(503, {
        ok: false,
        errorCode: config.aiFreeOnlyMode ? "NO_APPROVED_FREE_PROVIDERS" : "NO_ENABLED_AI_PROVIDERS",
        message: config.aiFreeOnlyMode
          ? "No enabled free-tier AI providers are currently configured. Requests are blocked in Free Only Mode."
          : "No enabled administrator-approved AI providers are available."
      });
    }

    const providersToTry = config.aiAutoFailoverEnabled ? approvedProviders : approvedProviders.slice(0, 1);
    const { systemPrompt, userPrompt } = buildSafetyDiagnosticPrompt({
      appliance,
      brand,
      model,
      problem,
      errorCode,
      language,
      adminInstructions: config.aiSystemInstructions
    });

    let lastFailureMessage = "All approved AI providers are currently unavailable.";
    let quotaExhaustedCount = 0;

    for (let i = 0; i < providersToTry.length; i++) {
      const candidate = providersToTry[i];
      activeProviderId = candidate.providerId;
      activeProviderType = candidate.providerType;
      activeModel = candidate.model;
      const failoverUsed = i > 0;

      // SSRF guard on configured URL
      let safeEndpoint = "";
      try {
        safeEndpoint = validateAiEndpointUrl(candidate.providerType, candidate.endpointUrl);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Invalid endpoint URL";
        lastFailureMessage = msg;
        await logAiError(caller.uid, candidate.providerId, candidate.providerType, candidate.model, "INVALID_ENDPOINT", msg);
        continue;
      }

      const apiKey = await resolveProviderApiKey(candidate.providerType, candidate.providerId);
      if (!apiKey) {
        lastFailureMessage = `Backend API key missing for ${candidate.label}.`;
        await logAiError(caller.uid, candidate.providerId, candidate.providerType, candidate.model, "AI_KEY_MISSING", lastFailureMessage);
        continue;
      }

      // Atomic server-side quota reservation
      const quota = await reserveAiQuotaAtomic({
        uid: caller.uid,
        providerId: candidate.providerId,
        globalLimit: config.aiDailyLimit,
        userLimit: config.aiPerUserLimit,
        providerLimit: candidate.dailyLimit
      });

      if (!quota.allowed) {
        if (quota.blockedScope === "global" || quota.blockedScope === "user") {
          await logAiUsage({
            uid: caller.uid,
            providerId: candidate.providerId,
            provider: candidate.providerType,
            modelName: candidate.model,
            appliance,
            language,
            isFree: candidate.isFree,
            failoverUsed,
            status: "RATE_LIMITED"
          });
          return jsonResponse(429, {
            ok: false,
            errorCode: "QUOTA_EXCEEDED",
            message: quota.reason || "Daily AI quota reached.",
            userUsedToday: quota.userUsed,
            perUserLimit: config.aiPerUserLimit
          });
        }
        // Provider-specific quota reached -> allow automatic failover to next approved free provider
        quotaExhaustedCount++;
        lastFailureMessage = quota.reason || `Provider ${candidate.label} reached its daily quota.`;
        continue;
      }

      try {
        const rawText = await invokeProvider(
          candidate.providerType,
          safeEndpoint,
          apiKey,
          candidate.model,
          systemPrompt,
          userPrompt
        );

        let diagnosis: Record<string, unknown>;
        try {
          const cleaned = rawText.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
          diagnosis = JSON.parse(cleaned);
        } catch {
          diagnosis = {
            safetyWarning: "Disconnect mains power before inspection.",
            errorCodeStatus: errorCode ? "UNVERIFIED" : "NOT_PROVIDED",
            errorCodeExplanation: errorCode ? `Code ${errorCode} could not be parsed cleanly; consult the official service manual.` : "",
            possibleCauses: [],
            componentsToInspect: [],
            diagnosticChecks: [],
            safeTroubleshootingSteps: [rawText],
            repairOptions: [],
            followUpQuestions: [],
            summaryNote: "Review safety steps carefully."
          };
        }

        await logAiUsage({
          uid: caller.uid,
          providerId: candidate.providerId,
          provider: candidate.providerType,
          modelName: candidate.model,
          appliance,
          language,
          isFree: candidate.isFree,
          failoverUsed,
          status: "SUCCESS"
        });

        return jsonResponse(200, {
          ok: true,
          provider: candidate.providerType,
          providerId: candidate.providerId,
          providerLabel: candidate.label,
          model: candidate.model,
          isFree: candidate.isFree,
          failoverUsed,
          language,
          diagnosis,
          usage: {
            userUsedToday: quota.userUsed,
            perUserLimit: config.aiPerUserLimit,
            globalUsedToday: quota.globalUsed,
            dailyLimit: config.aiDailyLimit
          }
        });
      } catch (err) {
        // Refund quota slot since upstream provider failed to return a diagnosis
        await releaseAiQuotaAtomic(caller.uid, candidate.providerId);
        const status = (err as { status?: number })?.status;
        if (status === 429) quotaExhaustedCount++;
        const msg = err instanceof Error ? err.message : "AI upstream error";
        lastFailureMessage = msg;
        await logAiError(caller.uid, candidate.providerId, candidate.providerType, candidate.model, status ? `HTTP_${status}` : "UPSTREAM_ERROR", msg);
      }
    }

    const allQuotaExhausted = quotaExhaustedCount > 0 && quotaExhaustedCount >= providersToTry.length;
    await logAiUsage({
      uid: caller.uid,
      providerId: activeProviderId,
      provider: activeProviderType,
      modelName: activeModel,
      appliance,
      language,
      isFree: true,
      failoverUsed: providersToTry.length > 1,
      status: allQuotaExhausted ? "RATE_LIMITED" : "FAILED"
    });

    return jsonResponse(allQuotaExhausted ? 429 : 503, {
      ok: false,
      errorCode: allQuotaExhausted ? "ALL_FREE_QUOTAS_EXHAUSTED" : "ALL_PROVIDERS_UNAVAILABLE",
      message: allQuotaExhausted
        ? "All approved free AI provider quotas are exhausted for now. Paid fallback is disabled without administrator authorization."
        : `Could not reach any approved AI provider (${lastFailureMessage}).`
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "AI diagnosis failed";
    await logAiError(callerUid, activeProviderId, activeProviderType, activeModel, "AI_ERROR", msg);
    return jsonResponse(500, { ok: false, errorCode: "AI_ERROR", message: msg });
  }
});
