// Repair Pro v3.0 — Shared Firebase Identity Verification, RBAC, Rate Limiting & SSRF Protection
// Verifies Firebase ID tokens cryptographically using Google's official JWKS endpoint.
// Project ID pinned to: gen-lang-client-0218221723

import { createRemoteJWKSet, jwtVerify } from "https://deno.land/x/jose@v5.9.6/index.ts";
import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

export const FIREBASE_PROJECT_ID = "gen-lang-client-0218221723";
export const BOOTSTRAP_SUPER_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";

const GOOGLE_JWKS = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com")
);

export interface VerifiedFirebaseUser {
  uid: string;
  email: string;
  emailVerified: boolean;
  name: string;
  picture?: string;
  isSuperAdmin: boolean;
  role: string;
  isBlocked: boolean;
}

const ALLOWED_ORIGINS = new Set([
  "https://gen-lang-client-0218221723.web.app",
  "https://gen-lang-client-0218221723.firebaseapp.com",
  "http://localhost:5173",
  "http://localhost:3000",
  "http://127.0.0.1:5000",
  "http://127.0.0.1:8080"
]);

export function buildCorsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get("origin") || "";
  const allowedOrigin = ALLOWED_ORIGINS.has(origin) || origin.endsWith(".run.app")
    ? origin
    : "https://gen-lang-client-0218221723.web.app";
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-firebase-token",
    "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
    "Vary": "Origin"
  };
}

export function jsonResponse(req: Request, status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...buildCorsHeaders(req),
      "Content-Type": "application/json; charset=utf-8"
    }
  });
}

export function getServiceSupabase(): SupabaseClient {
  const url = Deno.env.get("SUPABASE_URL") || "https://xuakzzjtcgcvudkgxpbd.supabase.co";
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  if (!key) {
    throw new Error("Server misconfiguration: SUPABASE_SERVICE_ROLE_KEY is missing.");
  }
  return createClient(url, key, { auth: { persistSession: false } });
}

// Per-user in-memory sliding window rate limiter
const rateBuckets = new Map<string, { count: number; resetAt: number }>();

export function checkRateLimit(key: string, maxRequests = 60, windowMs = 60_000): boolean {
  const now = Date.now();
  const bucket = rateBuckets.get(key);
  if (!bucket || now > bucket.resetAt) {
    rateBuckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (bucket.count >= maxRequests) return false;
  bucket.count += 1;
  return true;
}

// Strict SSRF protection for storage provider URLs
export function isSafeExternalHttpsUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== "https:") return false;
    const host = parsed.hostname.toLowerCase();
    if (
      host === "localhost" ||
      host === "127.0.0.1" ||
      host === "::1" ||
      host.startsWith("10.") ||
      host.startsWith("192.168.") ||
      host.startsWith("169.254.") ||
      /^172\.(1[6-9]|2\d|3[0-1])\./.test(host) ||
      host.endsWith(".internal") ||
      host.endsWith(".local")
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

export async function verifyFirebaseUser(
  req: Request,
  supabase: SupabaseClient
): Promise<VerifiedFirebaseUser> {
  const authHeader = req.headers.get("x-firebase-token") || req.headers.get("authorization") || "";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();
  if (!token) {
    throw new HttpError(401, "AUTH_MISSING", "Missing Firebase authentication token.");
  }

  let payload: Record<string, unknown>;
  try {
    const verified = await jwtVerify(token, GOOGLE_JWKS, {
      issuer: `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`,
      audience: FIREBASE_PROJECT_ID
    });
    payload = verified.payload as Record<string, unknown>;
  } catch (err) {
    throw new HttpError(
      401,
      "AUTH_INVALID_TOKEN",
      `Invalid or expired Firebase ID token: ${err instanceof Error ? err.message : "verification failed"}`
    );
  }

  const uid = String(payload.sub || "").trim();
  if (!uid) {
    throw new HttpError(401, "AUTH_INVALID_SUB", "Firebase token is missing user UID.");
  }

  const email = String(payload.email || "").trim().toLowerCase();
  const emailVerified = Boolean(payload.email_verified);
  const name = String(payload.name || email.split("@")[0] || "Repair Pro User").slice(0, 80);
  const picture = typeof payload.picture === "string" ? payload.picture : undefined;

  const isBootstrap = emailVerified && email === BOOTSTRAP_SUPER_ADMIN_EMAIL.toLowerCase();

  // Upsert / fetch user_profiles record in Supabase
  const { data: existing } = await supabase
    .from("user_profiles")
    .select("role, is_blocked")
    .eq("firebase_uid", uid)
    .maybeSingle();

  let role = existing?.role || (isBootstrap ? "SUPER_ADMIN" : "USER");
  if (isBootstrap && role !== "SUPER_ADMIN") {
    role = "SUPER_ADMIN";
  }
  const isBlocked = Boolean(existing?.is_blocked) && !isBootstrap;

  if (!existing) {
    await supabase.from("user_profiles").upsert({
      firebase_uid: uid,
      email,
      display_name: name,
      avatar_url: picture || null,
      role,
      last_seen_at: new Date().toISOString()
    });
  } else {
    await supabase
      .from("user_profiles")
      .update({
        email: email || undefined,
        display_name: name,
        avatar_url: picture || null,
        role: isBootstrap ? "SUPER_ADMIN" : existing.role,
        last_seen_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq("firebase_uid", uid);
  }

  return {
    uid,
    email,
    emailVerified,
    name,
    picture,
    isSuperAdmin: isBootstrap || role === "SUPER_ADMIN",
    role,
    isBlocked
  };
}

export function assertSuperAdmin(user: VerifiedFirebaseUser): void {
  if (!user.isSuperAdmin) {
    throw new HttpError(403, "ADMIN_REQUIRED", "Super Admin privileges are required for this operation.");
  }
}

export class HttpError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
