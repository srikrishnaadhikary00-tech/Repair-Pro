// Repair Pro v3.0 — Multi-Cloud Storage Orchestrator (Failover, SHA-256 Migration, Privacy & Safe Deletion)
// Pure TypeScript using Web Standard APIs + StorageRepository interface (testable in Node 22 & Deno Edge).

import {
  type AdapterDeps,
  buildPrivateRef,
  createSignedReadUrl,
  deleteObject,
  downloadObject,
  hasServerSecretConfigured,
  normalizeCanonicalProviderType,
  resolveMappedBucket,
  sha256Hex,
  StorageAdapterError,
  type StorageProviderConfig,
  testProviderConnection,
  uploadObject
} from "./storage-adapters.ts";

export const ALLOWED_BUCKETS = new Set([
  "community-photos",
  "repair-pdfs",
  "circuit-diagrams",
  "technician-photos",
  "verification-documents"
]);

export const ALLOWED_MIME_BY_BUCKET: Record<string, Set<string>> = {
  "community-photos": new Set(["image/jpeg", "image/png", "image/webp"]),
  "technician-photos": new Set(["image/jpeg", "image/png", "image/webp"]),
  "repair-pdfs": new Set(["application/pdf"]),
  "circuit-diagrams": new Set(["image/jpeg", "image/png", "image/webp", "application/pdf"]),
  "verification-documents": new Set(["image/jpeg", "image/png", "image/webp", "application/pdf"])
};

export interface FileRegistryRow {
  id: string;
  provider_id: string | null;
  bucket_name: string;
  object_path: string;
  public_url: string | null;
  is_private: boolean;
  original_filename: string;
  mime_type: string;
  size_bytes: number;
  uploaded_by_uid: string;
  entity_type?: string | null;
  entity_id?: string | null;
  sha256_checksum?: string | null;
  migrated_from_provider_id?: string | null;
  migrated_at?: string | null;
  created_at?: string;
}

export interface ErrorLogInsert {
  provider_id?: string | null;
  provider_name?: string | null;
  operation: string;
  http_status?: number;
  error_code?: string;
  error_message: string;
  failed_over_to_provider_id?: string | null;
}

export interface StorageRepository {
  listEnabledProviders(): Promise<StorageProviderConfig[]>;
  listAllProviders(): Promise<StorageProviderConfig[]>;
  getProviderById(id: string): Promise<StorageProviderConfig | null>;
  getAutoFailoverSetting(): Promise<boolean>;
  updateProviderUsage(providerId: string, usedBytes: number): Promise<void>;
  updateProviderTestResult(
    providerId: string,
    status: string,
    message: string
  ): Promise<void>;
  countProviderActiveFiles(providerId: string): Promise<number>;
  getActiveFileCountsByProvider(): Promise<Record<string, number>>;
  listProviderFiles(providerId: string, limit: number): Promise<FileRegistryRow[]>;
  findFileByObjectPath(objectPath: string): Promise<FileRegistryRow | null>;
  insertRegistryFile(entry: Omit<FileRegistryRow, "id" | "created_at">): Promise<FileRegistryRow>;
  updateRegistryFileAfterMigration(
    fileId: string,
    patch: {
      provider_id: string;
      public_url: string;
      sha256_checksum: string;
      migrated_from_provider_id: string;
      migrated_at: string;
    }
  ): Promise<void>;
  updateRepairDocumentsAfterMigration(
    storageFileId: string,
    newFileUrl: string,
    newProviderId: string
  ): Promise<void>;
  deleteProviderRow(providerId: string): Promise<void>;
  insertErrorLog(entry: ErrorLogInsert): Promise<void>;
}

export function sanitizeFileName(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9._\-]/g, "_").slice(0, 90) || `file_${Date.now()}`;
}

export function enrichProviderMetadata(
  provider: StorageProviderConfig,
  deps: Pick<AdapterDeps, "getEnv">,
  activeCounts: Record<string, number>
) {
  return {
    ...provider,
    secret_configured: hasServerSecretConfigured(provider, deps.getEnv),
    active_files_count: activeCounts[provider.id] ?? 0
  };
}

export async function uploadWithFailover(params: {
  repo: StorageRepository;
  deps: AdapterDeps;
  uploaderUid: string;
  bucketName: string;
  originalFilename: string;
  mimeType: string;
  bytes: Uint8Array;
  entityType?: string;
  entityId?: string;
}) {
  const { repo, deps, uploaderUid, bucketName, originalFilename, mimeType, bytes, entityType, entityId } = params;

  if (!ALLOWED_BUCKETS.has(bucketName)) {
    throw new StorageAdapterError(400, "INVALID_BUCKET", `Unsupported bucket: ${bucketName}`);
  }
  if (!ALLOWED_MIME_BY_BUCKET[bucketName]?.has(mimeType)) {
    throw new StorageAdapterError(400, "INVALID_MIME", `File type ${mimeType} is not allowed in ${bucketName}.`);
  }
  const maxBytes = bucketName === "repair-pdfs" ? 20 * 1024 * 1024 : 10 * 1024 * 1024;
  if (bytes.byteLength === 0 || bytes.byteLength > maxBytes) {
    throw new StorageAdapterError(
      400,
      "INVALID_FILE_SIZE",
      `File size must be between 1 byte and ${Math.round(maxBytes / (1024 * 1024))} MB.`
    );
  }

  const [ordered, globalAutoFailover] = await Promise.all([
    repo.listEnabledProviders(),
    repo.getAutoFailoverSetting()
  ]);

  if (ordered.length === 0) {
    throw new StorageAdapterError(503, "NO_STORAGE_PROVIDER", "No enabled storage providers are configured.");
  }

  const safeName = sanitizeFileName(originalFilename);
  const objectPath = `${uploaderUid}/${Date.now()}_${crypto.randomUUID().slice(0, 8)}_${safeName}`;
  const contentSha256 = await sha256Hex(bytes);
  const isPrivate = bucketName === "verification-documents";

  let lastError: StorageAdapterError | null = null;
  let failedPrimaryId: string | null = null;

  for (let i = 0; i < ordered.length; i++) {
    const provider = ordered[i];
    const allowFailover = globalAutoFailover && provider.auto_failover_enabled;
    const overCapacity =
      provider.capacity_bytes > 0 && provider.used_bytes + bytes.byteLength > provider.capacity_bytes;

    if (overCapacity) {
      failedPrimaryId = failedPrimaryId || provider.id;
      await repo.insertErrorLog({
        provider_id: provider.id,
        provider_name: provider.name,
        operation: "UPLOAD_CAPACITY_CHECK",
        http_status: 507,
        error_code: "CAPACITY_LIMIT_REACHED",
        error_message: `Provider ${provider.name} reached configured capacity limit (${provider.used_bytes + bytes.byteLength} > ${provider.capacity_bytes}).${allowFailover ? " Failing over to backup provider." : " Auto-failover is disabled."}`
      });
      if (!allowFailover) {
        throw new StorageAdapterError(
          507,
          "CAPACITY_LIMIT_REACHED",
          `Primary provider ${provider.name} is full and auto-failover is disabled.`
        );
      }
      continue;
    }

    try {
      const result = await uploadObject(provider, bucketName, objectPath, bytes, mimeType, deps);
      const finalUrl = isPrivate
        ? (result.publicUrl.startsWith("private://")
            ? result.publicUrl
            : buildPrivateRef(provider.id, result.mappedBucket, objectPath))
        : result.publicUrl;

      await repo.updateProviderUsage(provider.id, provider.used_bytes + bytes.byteLength);

      const fileRow = await repo.insertRegistryFile({
        provider_id: provider.id,
        bucket_name: bucketName,
        object_path: objectPath,
        public_url: finalUrl,
        is_private: isPrivate,
        original_filename: safeName,
        mime_type: mimeType,
        size_bytes: bytes.byteLength,
        uploaded_by_uid: uploaderUid,
        entity_type: entityType || null,
        entity_id: entityId || null,
        sha256_checksum: contentSha256,
        migrated_from_provider_id: null,
        migrated_at: null
      });

      const failoverUsed = Boolean(failedPrimaryId && failedPrimaryId !== provider.id);
      if (failoverUsed) {
        await repo.insertErrorLog({
          provider_id: failedPrimaryId,
          provider_name: ordered[0]?.name || "Primary",
          operation: "FAILOVER_SUCCEEDED",
          http_status: 200,
          error_code: "FAILOVER_ACTIVE",
          error_message: `Automatically failed over upload to backup provider ${provider.name}.`,
          failed_over_to_provider_id: provider.id
        });
      }

      return {
        file: fileRow,
        providerId: provider.id,
        providerName: provider.name,
        publicUrl: finalUrl,
        sha256Checksum: contentSha256,
        mimeType,
        sizeBytes: bytes.byteLength,
        failoverUsed
      };
    } catch (err) {
      const httpErr =
        err instanceof StorageAdapterError
          ? err
          : new StorageAdapterError(503, "PROVIDER_UNAVAILABLE", err instanceof Error ? err.message : String(err));

      await repo.insertErrorLog({
        provider_id: provider.id,
        provider_name: provider.name,
        operation: "UPLOAD",
        http_status: httpErr.status,
        error_code: httpErr.code,
        error_message: httpErr.message.slice(0, 500)
      });

      // CRITICAL SECURITY REQUIREMENT: NEVER bypass authentication/authorization errors (401/403)!
      if (httpErr.status === 401 || httpErr.status === 403) {
        throw httpErr;
      }

      failedPrimaryId = failedPrimaryId || provider.id;
      lastError = httpErr;
      if (!allowFailover) break;
    }
  }

  throw (
    lastError ||
    new StorageAdapterError(503, "ALL_PROVIDERS_FAILED", "All configured storage providers are unavailable.")
  );
}

export async function testAndRecordProviderConnection(
  repo: StorageRepository,
  provider: StorageProviderConfig,
  deps: AdapterDeps
) {
  const result = await testProviderConnection(provider, deps);
  await repo.updateProviderTestResult(provider.id, result.status, result.message);
  if (!result.connected) {
    await repo.insertErrorLog({
      provider_id: provider.id,
      provider_name: provider.name,
      operation: "TEST_CONNECTION",
      http_status: result.httpStatus,
      error_code: result.status,
      error_message: result.message
    });
  }
  return result;
}

export async function migrateProviderFiles(params: {
  repo: StorageRepository;
  deps: AdapterDeps;
  sourceProviderId: string;
  targetProviderId: string;
  limit?: number;
}) {
  const { repo, deps, sourceProviderId, targetProviderId, limit = 50 } = params;
  if (!targetProviderId || sourceProviderId === targetProviderId) {
    throw new StorageAdapterError(400, "INVALID_MIGRATION_TARGET", "Select a different enabled target storage provider.");
  }

  const [source, target] = await Promise.all([
    repo.getProviderById(sourceProviderId),
    repo.getProviderById(targetProviderId)
  ]);
  if (!source) {
    throw new StorageAdapterError(404, "SOURCE_NOT_FOUND", "Source storage provider not found.");
  }
  if (!target) {
    throw new StorageAdapterError(404, "TARGET_NOT_FOUND", "Target storage provider not found.");
  }
  if (!target.is_enabled) {
    throw new StorageAdapterError(400, "TARGET_DISABLED", `Target provider ${target.name} is disabled.`);
  }
  // Ensure canonical type & credentials exist before beginning migration
  normalizeCanonicalProviderType(target.provider_type);
  if (!hasServerSecretConfigured(target, deps.getEnv)) {
    throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${target.secret_env_key} missing on target provider ${target.name}.`);
  }
  if (!hasServerSecretConfigured(source, deps.getEnv)) {
    throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${source.secret_env_key} missing on source provider ${source.name}.`);
  }

  const files = await repo.listProviderFiles(sourceProviderId, Math.max(1, Math.min(200, limit)));
  let migratedCount = 0;
  let failedCount = 0;
  let bytesMigrated = 0;
  let failedSourceCleanupCount = 0;
  let currentSourceUsed = source.used_bytes;
  let currentTargetUsed = target.used_bytes;
  const errors: string[] = [];

  for (const file of files) {
    try {
      // 1. Download bytes from source
      const bytes = await downloadObject(source, file.bucket_name, file.object_path, deps);
      const sourceSha = await sha256Hex(bytes);

      // 2. Verify against recorded checksum if available
      if (file.sha256_checksum && file.sha256_checksum.toLowerCase() !== sourceSha.toLowerCase()) {
        throw new StorageAdapterError(
          422,
          "CHECKSUM_MISMATCH_SOURCE",
          `Source SHA-256 mismatch for ${file.original_filename}: expected ${file.sha256_checksum}, got ${sourceSha}.`
        );
      }

      // 3. Enforce target capacity limit
      if (target.capacity_bytes > 0 && currentTargetUsed + bytes.byteLength > target.capacity_bytes) {
        throw new StorageAdapterError(
          507,
          "TARGET_CAPACITY_EXCEEDED",
          `Target provider ${target.name} does not have enough free space for ${file.original_filename}.`
        );
      }

      // 4. Upload to target
      const uploaded = await uploadObject(target, file.bucket_name, file.object_path, bytes, file.mime_type, deps);

      // 5. Read-back verification from target & compare SHA-256
      const readBackBytes = await downloadObject(target, file.bucket_name, file.object_path, deps);
      const targetSha = await sha256Hex(readBackBytes);
      if (targetSha !== sourceSha) {
        try {
          await deleteObject(target, file.bucket_name, file.object_path, deps);
        } catch (_) {
          // best effort cleanup of corrupt copy
        }
        throw new StorageAdapterError(
          500,
          "CHECKSUM_MISMATCH_TARGET",
          `Target read-back SHA-256 mismatch for ${file.original_filename}: expected ${sourceSha}, got ${targetSha}.`
        );
      }

      // 6. Compute safe URL (preserve private:// ref for verification documents)
      const isPrivate = file.is_private || file.bucket_name === "verification-documents";
      const mappedTargetBucket = uploaded.mappedBucket || resolveMappedBucket(target, file.bucket_name);
      const nextUrl = isPrivate
        ? (uploaded.publicUrl.startsWith("private://")
            ? uploaded.publicUrl
            : buildPrivateRef(target.id, mappedTargetBucket, file.object_path))
        : uploaded.publicUrl;

      // 7. Atomically update registry + linked repair_documents + provider usage
      await repo.updateRegistryFileAfterMigration(file.id, {
        provider_id: target.id,
        public_url: nextUrl,
        sha256_checksum: targetSha,
        migrated_from_provider_id: source.id,
        migrated_at: new Date().toISOString()
      });

      await repo.updateRepairDocumentsAfterMigration(file.id, nextUrl, target.id);

      currentSourceUsed = Math.max(0, currentSourceUsed - bytes.byteLength);
      currentTargetUsed += bytes.byteLength;
      await Promise.all([
        repo.updateProviderUsage(source.id, currentSourceUsed),
        repo.updateProviderUsage(target.id, currentTargetUsed)
      ]);

      // 8. Only delete source copy AFTER target checksum & registry update succeeded
      try {
        await deleteObject(source, file.bucket_name, file.object_path, deps);
      } catch (cleanupErr) {
        failedSourceCleanupCount += 1;
        await repo.insertErrorLog({
          provider_id: source.id,
          provider_name: source.name,
          operation: "MIGRATION_SOURCE_CLEANUP",
          http_status: 500,
          error_code: "SOURCE_CLEANUP_WARN",
          error_message: `Migrated ${file.original_filename} to ${target.name} safely, but source cleanup returned: ${cleanupErr instanceof Error ? cleanupErr.message : String(cleanupErr)}`
        });
      }

      migratedCount += 1;
      bytesMigrated += bytes.byteLength;
    } catch (err) {
      failedCount += 1;
      const httpErr =
        err instanceof StorageAdapterError
          ? err
          : new StorageAdapterError(500, "MIGRATION_FAILED", err instanceof Error ? err.message : String(err));
      errors.push(`${file.original_filename}: ${httpErr.message}`);
      await repo.insertErrorLog({
        provider_id: source.id,
        provider_name: source.name,
        operation: "MIGRATE_FILE",
        http_status: httpErr.status,
        error_code: httpErr.code,
        error_message: httpErr.message.slice(0, 500),
        failed_over_to_provider_id: target.id
      });
      // Immediately halt batch on auth or capacity errors so we don't thrash remaining files
      if (httpErr.status === 401 || httpErr.status === 403 || httpErr.status === 507) {
        break;
      }
    }
  }

  const remainingOnSource = await repo.countProviderActiveFiles(sourceProviderId);
  return {
    migratedCount,
    failedCount,
    bytesMigrated,
    remainingOnSource,
    failedSourceCleanupCount,
    checksumVerified: migratedCount > 0 && failedCount === 0,
    errors
  };
}

export async function deleteStorageProviderSafe(repo: StorageRepository, providerId: string) {
  const [provider, allProviders, activeFiles] = await Promise.all([
    repo.getProviderById(providerId),
    repo.listAllProviders(),
    repo.countProviderActiveFiles(providerId)
  ]);
  if (!provider) {
    throw new StorageAdapterError(404, "NOT_FOUND", "Storage provider not found.");
  }
  if (activeFiles > 0) {
    throw new StorageAdapterError(
      409,
      "PROVIDER_HAS_ACTIVE_FILES",
      `Cannot delete "${provider.name}" while ${activeFiles} active file(s) remain stored on it. Migrate all files to another provider first.`
    );
  }
  if (provider.is_primary && allProviders.length > 1) {
    throw new StorageAdapterError(
      400,
      "CANNOT_DELETE_PRIMARY_PROVIDER",
      "Assign another storage provider as Primary before deleting this one."
    );
  }
  const enabledCount = allProviders.filter((p) => p.is_enabled).length;
  if (provider.is_enabled && enabledCount <= 1) {
    throw new StorageAdapterError(400, "LAST_ENABLED_PROVIDER", "Cannot delete the only enabled storage provider.");
  }
  await repo.deleteProviderRow(providerId);
}

export async function mintAdminSignedVerificationUrl(params: {
  repo: StorageRepository;
  deps: AdapterDeps;
  privateUrl?: string;
  providerId?: string;
  bucket?: string;
  objectPath?: string;
  expiresInSeconds?: number;
}) {
  let providerId = String(params.providerId || "").trim();
  let bucket = String(params.bucket || "").trim();
  let objectPath = String(params.objectPath || "").trim();
  const privateUrl = String(params.privateUrl || "").trim();

  if (privateUrl.startsWith("private://")) {
    const rest = privateUrl.slice("private://".length);
    const parts = rest.split("/");
    if (parts.length >= 3) {
      providerId = parts[0];
      bucket = parts[1];
      objectPath = parts.slice(2).join("/");
    }
  }

  if (!providerId || !bucket || !objectPath) {
    throw new StorageAdapterError(400, "INVALID_PRIVATE_REF", "Valid privateUrl or providerId/bucket/objectPath required.");
  }

  // If the file was migrated to another provider, resolve its authoritative current provider_id + path
  const canonicalPathLookup = objectPath.includes("/")
    ? objectPath.replace(/^verification-documents\//, "")
    : objectPath;
  const registryFile = await params.repo.findFileByObjectPath(canonicalPathLookup);
  if (registryFile && registryFile.provider_id && registryFile.provider_id !== providerId) {
    providerId = registryFile.provider_id;
    if (registryFile.public_url?.startsWith("private://")) {
      const migratedParts = registryFile.public_url.slice("private://".length).split("/");
      if (migratedParts.length >= 3) {
        bucket = migratedParts[1];
        objectPath = migratedParts.slice(2).join("/");
      }
    }
  }

  const provider = await params.repo.getProviderById(providerId);
  if (!provider) {
    throw new StorageAdapterError(404, "NOT_FOUND", "Storage provider not found.");
  }

  return createSignedReadUrl(
    provider,
    bucket,
    objectPath,
    params.expiresInSeconds || 120,
    params.deps
  );
}
