// Repair Pro v3.0 — Multi-Cloud Storage Provider Adapters
// Standard Web APIs only (crypto.subtle, fetch, URL) — runs in both Deno Edge Runtime and Node 22+ tests.
// Zero hardcoded credentials; resolves all secrets dynamically from server-side environment variables.

export type CanonicalProviderType = "SUPABASE" | "CLOUDFLARE_R2" | "BACKBLAZE_B2" | "CUSTOM_S3";

export interface StorageProviderConfig {
  id: string;
  name: string;
  provider_type: string;
  endpoint_url: string;
  project_ref?: string | null;
  region?: string | null;
  public_base_url?: string | null;
  secret_env_key: string;
  bucket_map?: Record<string, string> | null;
  is_primary: boolean;
  is_backup: boolean;
  is_enabled: boolean;
  priority_order: number;
  capacity_bytes: number;
  used_bytes: number;
  auto_failover_enabled: boolean;
  last_test_status?: string;
  last_test_message?: string | null;
}

export class StorageAdapterError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export type EnvGetter = (key: string) => string | undefined;
export type FetchFn = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

export interface AdapterDeps {
  getEnv: EnvGetter;
  fetchFn: FetchFn;
}

const SUPPORTED_TYPES = new Set<CanonicalProviderType>([
  "SUPABASE",
  "CLOUDFLARE_R2",
  "BACKBLAZE_B2",
  "CUSTOM_S3"
]);

export function normalizeCanonicalProviderType(raw: unknown): CanonicalProviderType {
  const upper = String(raw || "SUPABASE").trim().toUpperCase();
  if (upper === "S3_COMPATIBLE" || upper === "CUSTOM_ENDPOINT" || upper === "AWS_S3" || upper === "S3") {
    return "CUSTOM_S3";
  }
  if (upper === "R2") return "CLOUDFLARE_R2";
  if (upper === "B2") return "BACKBLAZE_B2";
  if (SUPPORTED_TYPES.has(upper as CanonicalProviderType)) {
    return upper as CanonicalProviderType;
  }
  throw new StorageAdapterError(
    400,
    "UNSUPPORTED_PROVIDER_TYPE",
    `Unsupported storage provider type '${upper}'. Supported: SUPABASE, CLOUDFLARE_R2, BACKBLAZE_B2, CUSTOM_S3.`
  );
}

export function isSafePublicHttpsUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== "https:") return false;
    const host = parsed.hostname.toLowerCase();
    if (
      host === "localhost" ||
      host === "127.0.0.1" ||
      host === "::1" ||
      host === "0.0.0.0" ||
      host.startsWith("10.") ||
      host.startsWith("192.168.") ||
      host.startsWith("169.254.") ||
      /^172\.(1[6-9]|2\d|3[0-1])\./.test(host) ||
      host.endsWith(".internal") ||
      host.endsWith(".local")
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

export function resolveMappedBucket(provider: StorageProviderConfig, logicalBucket: string): string {
  const mapped = provider.bucket_map?.[logicalBucket];
  if (mapped && mapped.trim()) return mapped.trim();
  // For single-bucket external R2/B2/S3 accounts, project_ref often holds the bucket name
  if (provider.provider_type !== "SUPABASE" && provider.project_ref && provider.project_ref !== "default") {
    return provider.project_ref.trim();
  }
  return logicalBucket;
}

export function buildPrivateRef(providerId: string, bucket: string, objectPath: string): string {
  return `private://${providerId}/${bucket}/${objectPath}`;
}

export async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return bytesToHex(new Uint8Array(digest));
}

async function sha1Hex(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-1", bytes);
  return bytesToHex(new Uint8Array(digest));
}

function bytesToHex(bytes: Uint8Array): string {
  let out = "";
  for (let i = 0; i < bytes.length; i++) {
    out += bytes[i].toString(16).padStart(2, "0");
  }
  return out;
}

async function hmacSha256(key: Uint8Array | string, data: string): Promise<Uint8Array> {
  const enc = new TextEncoder();
  const keyBytes = typeof key === "string" ? enc.encode(key) : key;
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(data));
  return new Uint8Array(sig);
}

function encodeRfc3986(str: string): string {
  return encodeURIComponent(str).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());
}

function encodeObjectKeyPath(keyPath: string): string {
  return keyPath
    .split("/")
    .filter((s) => s.length > 0)
    .map(encodeRfc3986)
    .join("/");
}

interface S3Credentials {
  accessKeyId: string;
  secretAccessKey: string;
  sessionToken?: string;
  region?: string;
  publicBaseUrl?: string;
}

interface B2Credentials {
  mode: "NATIVE" | "S3";
  keyId?: string;
  applicationKey?: string;
  bucketId?: string;
  s3?: S3Credentials;
}

function tryParseJson(raw: string): Record<string, unknown> | null {
  const trimmed = raw.trim();
  if (!trimmed.startsWith("{")) return null;
  try {
    const parsed = JSON.parse(trimmed);
    return parsed && typeof parsed === "object" ? (parsed as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

function resolveS3Credentials(provider: StorageProviderConfig, getEnv: EnvGetter): S3Credentials | null {
  const keyName = provider.secret_env_key;
  const raw = (getEnv(keyName) || "").trim();
  const json = raw ? tryParseJson(raw) : null;
  if (json) {
    const accessKeyId = String(json.accessKeyId || json.ACCESS_KEY_ID || "").trim();
    const secretAccessKey = String(json.secretAccessKey || json.SECRET_ACCESS_KEY || "").trim();
    if (accessKeyId && secretAccessKey) {
      return {
        accessKeyId,
        secretAccessKey,
        sessionToken: json.sessionToken ? String(json.sessionToken).trim() : undefined,
        region: json.region ? String(json.region).trim() : undefined,
        publicBaseUrl: json.publicBaseUrl ? String(json.publicBaseUrl).trim() : undefined
      };
    }
  }

  // Support `accessKeyId:secretAccessKey` compact secret format or split env vars `<KEY>_ACCESS_KEY_ID` + `<KEY>_SECRET_ACCESS_KEY`
  if (raw.includes(":") && !raw.includes(" ")) {
    const idx = raw.indexOf(":");
    const accessKeyId = raw.slice(0, idx).trim();
    const secretAccessKey = raw.slice(idx + 1).trim();
    if (accessKeyId && secretAccessKey) {
      return {
        accessKeyId,
        secretAccessKey,
        region: (getEnv(`${keyName}_REGION`) || "").trim() || undefined,
        publicBaseUrl: (getEnv(`${keyName}_PUBLIC_BASE_URL`) || "").trim() || undefined
      };
    }
  }

  const splitAccess = (getEnv(`${keyName}_ACCESS_KEY_ID`) || "").trim();
  const splitSecret = (getEnv(`${keyName}_SECRET_ACCESS_KEY`) || "").trim();
  if (splitAccess && splitSecret) {
    return {
      accessKeyId: splitAccess,
      secretAccessKey: splitSecret,
      sessionToken: (getEnv(`${keyName}_SESSION_TOKEN`) || "").trim() || undefined,
      region: (getEnv(`${keyName}_REGION`) || "").trim() || undefined,
      publicBaseUrl: (getEnv(`${keyName}_PUBLIC_BASE_URL`) || "").trim() || undefined
    };
  }
  return null;
}

function resolveB2Credentials(provider: StorageProviderConfig, getEnv: EnvGetter): B2Credentials | null {
  const keyName = provider.secret_env_key;
  const raw = (getEnv(keyName) || "").trim();
  const json = raw ? tryParseJson(raw) : null;
  const host = (() => {
    try {
      return new URL(provider.endpoint_url).hostname.toLowerCase();
    } catch {
      return "";
    }
  })();

  if (json) {
    if (json.keyId && json.applicationKey) {
      return {
        mode: "NATIVE",
        keyId: String(json.keyId).trim(),
        applicationKey: String(json.applicationKey).trim(),
        bucketId: json.bucketId ? String(json.bucketId).trim() : undefined
      };
    }
    if (json.accessKeyId && json.secretAccessKey) {
      const s3 = resolveS3Credentials(provider, getEnv);
      if (s3) return { mode: "S3", s3 };
    }
  }

  const splitB2KeyId = (getEnv(`${keyName}_KEY_ID`) || "").trim();
  const splitB2AppKey = (getEnv(`${keyName}_APPLICATION_KEY`) || "").trim();
  if (splitB2KeyId && splitB2AppKey) {
    return {
      mode: "NATIVE",
      keyId: splitB2KeyId,
      applicationKey: splitB2AppKey,
      bucketId: (getEnv(`${keyName}_BUCKET_ID`) || "").trim() || undefined
    };
  }

  // If endpoint is B2 S3-compatible (`s3.<region>.backblazeb2.com`), prefer S3 SigV4 if S3 creds exist
  if (host.startsWith("s3.")) {
    const s3 = resolveS3Credentials(provider, getEnv);
    if (s3) return { mode: "S3", s3 };
  }

  // Compact `keyId:applicationKey`
  if (raw.includes(":") && !raw.includes(" ")) {
    const idx = raw.indexOf(":");
    const keyId = raw.slice(0, idx).trim();
    const applicationKey = raw.slice(idx + 1).trim();
    if (keyId && applicationKey) {
      return {
        mode: host.startsWith("s3.") ? "S3" : "NATIVE",
        keyId,
        applicationKey,
        bucketId: (getEnv(`${keyName}_BUCKET_ID`) || "").trim() || undefined,
        s3: host.startsWith("s3.") ? { accessKeyId: keyId, secretAccessKey: applicationKey } : undefined
      };
    }
  }

  const s3Fallback = resolveS3Credentials(provider, getEnv);
  if (s3Fallback) return { mode: "S3", s3: s3Fallback };
  return null;
}

export function hasServerSecretConfigured(provider: StorageProviderConfig, getEnv: EnvGetter): boolean {
  const type = (() => {
    try {
      return normalizeCanonicalProviderType(provider.provider_type);
    } catch {
      return "CUSTOM_S3" as CanonicalProviderType;
    }
  })();
  if (type === "SUPABASE") {
    return Boolean((getEnv(provider.secret_env_key) || "").trim());
  }
  if (type === "BACKBLAZE_B2") {
    return Boolean(resolveB2Credentials(provider, getEnv));
  }
  return Boolean(resolveS3Credentials(provider, getEnv));
}

// --- AWS SIGNATURE VERSION 4 SIGNING (R2 & S3 COMPATIBLE) ---
const EMPTY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

function formatAmzDates(date = new Date()): { amzDate: string; dateStamp: string } {
  const iso = date.toISOString().replace(/[:-]|\.\d{3}/g, "");
  return { amzDate: iso, dateStamp: iso.slice(0, 8) };
}

async function deriveSigningKey(secretAccessKey: string, dateStamp: string, region: string, service: string): Promise<Uint8Array> {
  const kDate = await hmacSha256("AWS4" + secretAccessKey, dateStamp);
  const kRegion = await hmacSha256(kDate, region);
  const kService = await hmacSha256(kRegion, service);
  return hmacSha256(kService, "aws4_request");
}

function buildCanonicalQuery(searchParams: URLSearchParams): string {
  const entries: [string, string][] = [];
  searchParams.forEach((value, key) => {
    entries.push([encodeRfc3986(key), encodeRfc3986(value)]);
  });
  entries.sort((a, b) => (a[0] === b[0] ? (a[1] < b[1] ? -1 : a[1] > b[1] ? 1 : 0) : a[0] < b[0] ? -1 : 1));
  return entries.map(([k, v]) => `${k}=${v}`).join("&");
}

export async function signAwsS3Request(params: {
  method: "GET" | "PUT" | "HEAD" | "DELETE";
  url: string;
  region: string;
  credentials: S3Credentials;
  payload?: Uint8Array;
  extraHeaders?: Record<string, string>;
  now?: Date;
}): Promise<Record<string, string>> {
  const parsed = new URL(params.url);
  const { amzDate, dateStamp } = formatAmzDates(params.now);
  const payloadHash = params.payload && params.payload.byteLength > 0
    ? await sha256Hex(params.payload)
    : EMPTY_SHA256;

  const headersToSign: Record<string, string> = {
    host: parsed.host,
    "x-amz-content-sha256": payloadHash,
    "x-amz-date": amzDate
  };
  if (params.credentials.sessionToken) {
    headersToSign["x-amz-security-token"] = params.credentials.sessionToken;
  }
  if (params.extraHeaders) {
    for (const [k, v] of Object.entries(params.extraHeaders)) {
      headersToSign[k.toLowerCase()] = v.trim();
    }
  }

  const sortedHeaderKeys = Object.keys(headersToSign).sort();
  const canonicalHeaders = sortedHeaderKeys.map((k) => `${k}:${headersToSign[k]}\n`).join("");
  const signedHeaders = sortedHeaderKeys.join(";");
  const canonicalUri = parsed.pathname || "/";
  const canonicalQuery = buildCanonicalQuery(parsed.searchParams);

  const canonicalRequest = [
    params.method,
    canonicalUri,
    canonicalQuery,
    canonicalHeaders,
    signedHeaders,
    payloadHash
  ].join("\n");

  const scope = `${dateStamp}/${params.region}/s3/aws4_request`;
  const stringToSign = [
    "AWS4-HMAC-SHA256",
    amzDate,
    scope,
    await sha256Hex(new TextEncoder().encode(canonicalRequest))
  ].join("\n");

  const signingKey = await deriveSigningKey(params.credentials.secretAccessKey, dateStamp, params.region, "s3");
  const signature = bytesToHex(await hmacSha256(signingKey, stringToSign));

  const authorization =
    `AWS4-HMAC-SHA256 Credential=${params.credentials.accessKeyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

  return {
    ...headersToSign,
    Authorization: authorization
  };
}

export async function createAwsS3PresignedGetUrl(params: {
  url: string;
  region: string;
  credentials: S3Credentials;
  expiresInSeconds: number;
  now?: Date;
}): Promise<string> {
  const parsed = new URL(params.url);
  const { amzDate, dateStamp } = formatAmzDates(params.now);
  const scope = `${dateStamp}/${params.region}/s3/aws4_request`;

  parsed.searchParams.set("X-Amz-Algorithm", "AWS4-HMAC-SHA256");
  parsed.searchParams.set("X-Amz-Credential", `${params.credentials.accessKeyId}/${scope}`);
  parsed.searchParams.set("X-Amz-Date", amzDate);
  parsed.searchParams.set("X-Amz-Expires", String(Math.max(10, Math.min(3600, params.expiresInSeconds))));
  parsed.searchParams.set("X-Amz-SignedHeaders", "host");
  if (params.credentials.sessionToken) {
    parsed.searchParams.set("X-Amz-Security-Token", params.credentials.sessionToken);
  }

  const canonicalQuery = buildCanonicalQuery(parsed.searchParams);
  const canonicalHeaders = `host:${parsed.host}\n`;
  const canonicalRequest = [
    "GET",
    parsed.pathname || "/",
    canonicalQuery,
    canonicalHeaders,
    "host",
    "UNSIGNED-PAYLOAD"
  ].join("\n");

  const stringToSign = [
    "AWS4-HMAC-SHA256",
    amzDate,
    scope,
    await sha256Hex(new TextEncoder().encode(canonicalRequest))
  ].join("\n");

  const signingKey = await deriveSigningKey(params.credentials.secretAccessKey, dateStamp, params.region, "s3");
  const signature = bytesToHex(await hmacSha256(signingKey, stringToSign));
  return `${parsed.origin}${parsed.pathname}?${canonicalQuery}&X-Amz-Signature=${signature}`;
}

// --- B2 NATIVE API v2 SESSION ---
interface B2Session {
  accountId: string;
  authorizationToken: string;
  apiUrl: string;
  downloadUrl: string;
  bucketId: string;
  bucketName: string;
}

async function authorizeB2Native(
  provider: StorageProviderConfig,
  creds: B2Credentials,
  mappedBucket: string,
  fetchFn: FetchFn
): Promise<B2Session> {
  if (!creds.keyId || !creds.applicationKey) {
    throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Backblaze B2 keyId/applicationKey missing for ${provider.secret_env_key}.`);
  }
  const authBase = provider.endpoint_url.replace(/\/+$/, "");
  const basic = btoa(`${creds.keyId}:${creds.applicationKey}`);
  const authRes = await fetchFn(`${authBase}/b2api/v2/b2_authorize_account`, {
    method: "GET",
    headers: { Authorization: `Basic ${basic}` }
  });
  if (authRes.status === 401 || authRes.status === 403) {
    throw new StorageAdapterError(authRes.status, "STORAGE_AUTH_ERROR", `Backblaze B2 rejected credentials (${authRes.status}).`);
  }
  if (!authRes.ok) {
    throw new StorageAdapterError(authRes.status, "STORAGE_UPLOAD_FAILED", `Backblaze B2 authorize failed: HTTP ${authRes.status}`);
  }
  const data = await authRes.json() as {
    accountId: string;
    authorizationToken: string;
    apiUrl: string;
    downloadUrl: string;
    allowed?: { bucketId?: string; bucketName?: string };
  };
  let bucketId = creds.bucketId || data.allowed?.bucketId || "";
  const bucketName = data.allowed?.bucketName || mappedBucket;

  if (!bucketId) {
    const listRes = await fetchFn(`${data.apiUrl}/b2api/v2/b2_list_buckets`, {
      method: "POST",
      headers: {
        Authorization: data.authorizationToken,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ accountId: data.accountId, bucketName })
    });
    if (listRes.status === 401 || listRes.status === 403) {
      throw new StorageAdapterError(listRes.status, "STORAGE_AUTH_ERROR", `Backblaze B2 bucket auth failed (${listRes.status}).`);
    }
    if (!listRes.ok) {
      throw new StorageAdapterError(listRes.status, "STORAGE_BUCKET_LOOKUP_FAILED", `B2 b2_list_buckets HTTP ${listRes.status}`);
    }
    const listJson = await listRes.json() as { buckets?: Array<{ bucketId: string; bucketName: string }> };
    const found = (listJson.buckets || []).find((b) => b.bucketName === bucketName) || listJson.buckets?.[0];
    if (!found?.bucketId) {
      throw new StorageAdapterError(404, "BUCKET_NOT_FOUND", `Backblaze B2 bucket '${bucketName}' not found.`);
    }
    bucketId = found.bucketId;
  }

  return {
    accountId: data.accountId,
    authorizationToken: data.authorizationToken,
    apiUrl: data.apiUrl.replace(/\/+$/, ""),
    downloadUrl: data.downloadUrl.replace(/\/+$/, ""),
    bucketId,
    bucketName
  };
}

function resolveS3ObjectUrl(provider: StorageProviderConfig, mappedBucket: string, objectPath: string): string {
  const base = provider.endpoint_url.replace(/\/+$/, "");
  const encodedObj = encodeObjectKeyPath(objectPath);
  const encodedBucket = encodeRfc3986(mappedBucket);
  return `${base}/${encodedBucket}/${encodedObj}`;
}

function resolveS3PublicUrl(
  provider: StorageProviderConfig,
  creds: S3Credentials,
  mappedBucket: string,
  objectPath: string,
  isPrivate: boolean
): string {
  if (isPrivate) {
    return buildPrivateRef(provider.id, mappedBucket, objectPath);
  }
  const customBase = (provider.public_base_url || creds.publicBaseUrl || "").trim().replace(/\/+$/, "");
  const encodedObj = encodeObjectKeyPath(objectPath);
  if (customBase && isSafePublicHttpsUrl(customBase)) {
    if (customBase.endsWith(`/${mappedBucket}`)) {
      return `${customBase}/${encodedObj}`;
    }
    return `${customBase}/${encodeRfc3986(mappedBucket)}/${encodedObj}`;
  }
  return resolveS3ObjectUrl(provider, mappedBucket, objectPath);
}

// --- ADAPTER OPERATIONS ---

export async function uploadObject(
  provider: StorageProviderConfig,
  logicalBucket: string,
  objectPath: string,
  bytes: Uint8Array,
  mimeType: string,
  deps: AdapterDeps
): Promise<{ publicUrl: string; httpStatus: number; mappedBucket: string }> {
  if (!isSafePublicHttpsUrl(provider.endpoint_url)) {
    throw new StorageAdapterError(400, "UNSAFE_ENDPOINT", "Storage provider endpoint URL failed HTTPS safety validation.");
  }
  const type = normalizeCanonicalProviderType(provider.provider_type);
  const mappedBucket = resolveMappedBucket(provider, logicalBucket);
  const isPrivate = logicalBucket === "verification-documents";

  if (type === "SUPABASE") {
    const serviceKey = (deps.getEnv(provider.secret_env_key) || "").trim();
    if (!serviceKey) {
      throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${provider.secret_env_key} is not configured on backend.`);
    }
    const base = provider.endpoint_url.replace(/\/+$/, "");
    const encBucket = encodeRfc3986(mappedBucket);
    const encObj = encodeObjectKeyPath(objectPath);
    const res = await deps.fetchFn(`${base}/storage/v1/object/${encBucket}/${encObj}`, {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        "Content-Type": mimeType,
        "x-upsert": "false"
      },
      body: bytes
    });
    if (res.status === 401 || res.status === 403) {
      throw new StorageAdapterError(res.status, "STORAGE_AUTH_ERROR", `Supabase storage rejected credentials (${res.status}).`);
    }
    if (!res.ok) {
      const msg = await res.text().catch(() => "");
      throw new StorageAdapterError(res.status, "STORAGE_UPLOAD_FAILED", `Supabase upload failed HTTP ${res.status}: ${msg.slice(0, 200)}`);
    }
    const publicUrl = isPrivate
      ? buildPrivateRef(provider.id, mappedBucket, objectPath)
      : `${base}/storage/v1/object/public/${encBucket}/${encObj}`;
    return { publicUrl, httpStatus: res.status, mappedBucket };
  }

  if (type === "BACKBLAZE_B2") {
    const b2Creds = resolveB2Credentials(provider, deps.getEnv);
    if (!b2Creds) {
      throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${provider.secret_env_key} is not configured for Backblaze B2.`);
    }
    if (b2Creds.mode === "NATIVE") {
      const session = await authorizeB2Native(provider, b2Creds, mappedBucket, deps.fetchFn);
      const getUpRes = await deps.fetchFn(`${session.apiUrl}/b2api/v2/b2_get_upload_url`, {
        method: "POST",
        headers: {
          Authorization: session.authorizationToken,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ bucketId: session.bucketId })
      });
      if (getUpRes.status === 401 || getUpRes.status === 403) {
        throw new StorageAdapterError(getUpRes.status, "STORAGE_AUTH_ERROR", `Backblaze B2 rejected upload authorization (${getUpRes.status}).`);
      }
      if (!getUpRes.ok) {
        throw new StorageAdapterError(getUpRes.status, "STORAGE_UPLOAD_FAILED", `B2 get_upload_url HTTP ${getUpRes.status}`);
      }
      const upMeta = await getUpRes.json() as { uploadUrl: string; authorizationToken: string };
      const sha1 = await sha1Hex(bytes);
      const fullKey = `${logicalBucket}/${objectPath}`;
      const upRes = await deps.fetchFn(upMeta.uploadUrl, {
        method: "POST",
        headers: {
          Authorization: upMeta.authorizationToken,
          "X-Bz-File-Name": encodeObjectKeyPath(fullKey),
          "Content-Type": mimeType,
          "X-Bz-Content-Sha1": sha1
        },
        body: bytes
      });
      if (upRes.status === 401 || upRes.status === 403) {
        throw new StorageAdapterError(upRes.status, "STORAGE_AUTH_ERROR", `Backblaze B2 rejected file upload (${upRes.status}).`);
      }
      if (!upRes.ok) {
        throw new StorageAdapterError(upRes.status, "STORAGE_UPLOAD_FAILED", `B2 upload HTTP ${upRes.status}`);
      }
      const publicUrl = isPrivate
        ? buildPrivateRef(provider.id, session.bucketName, fullKey)
        : (provider.public_base_url && isSafePublicHttpsUrl(provider.public_base_url)
            ? `${provider.public_base_url.replace(/\/+$/, "")}/${encodeObjectKeyPath(fullKey)}`
            : `${session.downloadUrl}/file/${encodeRfc3986(session.bucketName)}/${encodeObjectKeyPath(fullKey)}`);
      return { publicUrl, httpStatus: upRes.status, mappedBucket: session.bucketName };
    }
    // B2 S3-Compatible mode falls through to SigV4
    const s3Creds = b2Creds.s3!;
    const region = s3Creds.region || provider.region || "us-west-004";
    const fullKey = mappedBucket === logicalBucket ? objectPath : `${logicalBucket}/${objectPath}`;
    const targetUrl = resolveS3ObjectUrl(provider, mappedBucket, fullKey);
    const headers = await signAwsS3Request({
      method: "PUT",
      url: targetUrl,
      region,
      credentials: s3Creds,
      payload: bytes,
      extraHeaders: {
        "Content-Type": mimeType,
        ...(isPrivate ? { "x-amz-acl": "private" } : {})
      }
    });
    const res = await deps.fetchFn(targetUrl, { method: "PUT", headers, body: bytes });
    if (res.status === 401 || res.status === 403) {
      throw new StorageAdapterError(res.status, "STORAGE_AUTH_ERROR", `Provider ${provider.name} rejected credentials (${res.status}).`);
    }
    if (!res.ok) {
      throw new StorageAdapterError(res.status, "STORAGE_UPLOAD_FAILED", `Provider ${provider.name} returned HTTP ${res.status}.`);
    }
    return {
      publicUrl: resolveS3PublicUrl(provider, s3Creds, mappedBucket, fullKey, isPrivate),
      httpStatus: res.status,
      mappedBucket
    };
  }

  // CLOUDFLARE_R2 or CUSTOM_S3 (AWS SigV4)
  const s3Creds = resolveS3Credentials(provider, deps.getEnv);
  if (!s3Creds) {
    throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${provider.secret_env_key} (accessKeyId/secretAccessKey) is not configured.`);
  }
  const region = s3Creds.region || provider.region || (type === "CLOUDFLARE_R2" ? "auto" : "us-east-1");
  const fullKey = mappedBucket === logicalBucket ? objectPath : `${logicalBucket}/${objectPath}`;
  const targetUrl = resolveS3ObjectUrl(provider, mappedBucket, fullKey);
  const extraHeaders: Record<string, string> = { "Content-Type": mimeType };
  if (isPrivate && type === "CUSTOM_S3") {
    extraHeaders["x-amz-acl"] = "private";
  }
  const headers = await signAwsS3Request({
    method: "PUT",
    url: targetUrl,
    region,
    credentials: s3Creds,
    payload: bytes,
    extraHeaders
  });
  const res = await deps.fetchFn(targetUrl, { method: "PUT", headers, body: bytes });
  if (res.status === 401 || res.status === 403) {
    throw new StorageAdapterError(res.status, "STORAGE_AUTH_ERROR", `Provider ${provider.name} rejected credentials (${res.status}).`);
  }
  if (!res.ok) {
    throw new StorageAdapterError(res.status, "STORAGE_UPLOAD_FAILED", `Provider ${provider.name} returned HTTP ${res.status}.`);
  }
  return {
    publicUrl: resolveS3PublicUrl(provider, s3Creds, mappedBucket, fullKey, isPrivate),
    httpStatus: res.status,
    mappedBucket
  };
}

export async function downloadObject(
  provider: StorageProviderConfig,
  logicalBucket: string,
  objectPath: string,
  deps: AdapterDeps
): Promise<Uint8Array> {
  if (!isSafePublicHttpsUrl(provider.endpoint_url)) {
    throw new StorageAdapterError(400, "UNSAFE_ENDPOINT", "Storage provider endpoint URL failed HTTPS safety validation.");
  }
  const type = normalizeCanonicalProviderType(provider.provider_type);
  const mappedBucket = resolveMappedBucket(provider, logicalBucket);

  if (type === "SUPABASE") {
    const serviceKey = (deps.getEnv(provider.secret_env_key) || "").trim();
    if (!serviceKey) {
      throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${provider.secret_env_key} is not configured.`);
    }
    const base = provider.endpoint_url.replace(/\/+$/, "");
    const encBucket = encodeRfc3986(mappedBucket);
    const encObj = encodeObjectKeyPath(objectPath);
    const res = await deps.fetchFn(`${base}/storage/v1/object/authenticated/${encBucket}/${encObj}`, {
      method: "GET",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`
      }
    });
    if (res.status === 401 || res.status === 403) {
      throw new StorageAdapterError(res.status, "STORAGE_AUTH_ERROR", `Supabase rejected download auth (${res.status}).`);
    }
    if (!res.ok) {
      throw new StorageAdapterError(res.status, "STORAGE_DOWNLOAD_FAILED", `Supabase download failed HTTP ${res.status}`);
    }
    return new Uint8Array(await res.arrayBuffer());
  }

  if (type === "BACKBLAZE_B2") {
    const b2Creds = resolveB2Credentials(provider, deps.getEnv);
    if (!b2Creds) {
      throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${provider.secret_env_key} missing for B2 download.`);
    }
    if (b2Creds.mode === "NATIVE") {
      const session = await authorizeB2Native(provider, b2Creds, mappedBucket, deps.fetchFn);
      const key = objectPath.startsWith(`${logicalBucket}/`) ? objectPath : `${logicalBucket}/${objectPath}`;
      const res = await deps.fetchFn(
        `${session.downloadUrl}/file/${encodeRfc3986(session.bucketName)}/${encodeObjectKeyPath(key)}`,
        { method: "GET", headers: { Authorization: session.authorizationToken } }
      );
      if (res.status === 401 || res.status === 403) {
        throw new StorageAdapterError(res.status, "STORAGE_AUTH_ERROR", `Backblaze B2 rejected download (${res.status}).`);
      }
      if (!res.ok) {
        throw new StorageAdapterError(res.status, "STORAGE_DOWNLOAD_FAILED", `Backblaze B2 download HTTP ${res.status}`);
      }
      return new Uint8Array(await res.arrayBuffer());
    }
    const s3Creds = b2Creds.s3!;
    const region = s3Creds.region || provider.region || "us-west-004";
    const fullKey = mappedBucket === logicalBucket || objectPath.startsWith(`${logicalBucket}/`) ? objectPath : `${logicalBucket}/${objectPath}`;
    const targetUrl = resolveS3ObjectUrl(provider, mappedBucket, fullKey);
    const headers = await signAwsS3Request({ method: "GET", url: targetUrl, region, credentials: s3Creds });
    const res = await deps.fetchFn(targetUrl, { method: "GET", headers });
    if (res.status === 401 || res.status === 403) {
      throw new StorageAdapterError(res.status, "STORAGE_AUTH_ERROR", `B2 S3 rejected download (${res.status}).`);
    }
    if (!res.ok) {
      throw new StorageAdapterError(res.status, "STORAGE_DOWNLOAD_FAILED", `B2 S3 download HTTP ${res.status}`);
    }
    return new Uint8Array(await res.arrayBuffer());
  }

  const s3Creds = resolveS3Credentials(provider, deps.getEnv);
  if (!s3Creds) {
    throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${provider.secret_env_key} missing for download.`);
  }
  const region = s3Creds.region || provider.region || (type === "CLOUDFLARE_R2" ? "auto" : "us-east-1");
  const fullKey = mappedBucket === logicalBucket || objectPath.startsWith(`${logicalBucket}/`) ? objectPath : `${logicalBucket}/${objectPath}`;
  const targetUrl = resolveS3ObjectUrl(provider, mappedBucket, fullKey);
  const headers = await signAwsS3Request({ method: "GET", url: targetUrl, region, credentials: s3Creds });
  const res = await deps.fetchFn(targetUrl, { method: "GET", headers });
  if (res.status === 401 || res.status === 403) {
    throw new StorageAdapterError(res.status, "STORAGE_AUTH_ERROR", `Provider ${provider.name} rejected download (${res.status}).`);
  }
  if (!res.ok) {
    throw new StorageAdapterError(res.status, "STORAGE_DOWNLOAD_FAILED", `Download HTTP ${res.status}`);
  }
  return new Uint8Array(await res.arrayBuffer());
}

export async function deleteObject(
  provider: StorageProviderConfig,
  logicalBucket: string,
  objectPath: string,
  deps: AdapterDeps
): Promise<void> {
  if (!isSafePublicHttpsUrl(provider.endpoint_url)) return;
  const type = normalizeCanonicalProviderType(provider.provider_type);
  const mappedBucket = resolveMappedBucket(provider, logicalBucket);

  if (type === "SUPABASE") {
    const serviceKey = (deps.getEnv(provider.secret_env_key) || "").trim();
    if (!serviceKey) return;
    const base = provider.endpoint_url.replace(/\/+$/, "");
    const res = await deps.fetchFn(
      `${base}/storage/v1/object/${encodeRfc3986(mappedBucket)}/${encodeObjectKeyPath(objectPath)}`,
      {
        method: "DELETE",
        headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` }
      }
    );
    if (!res.ok && res.status !== 404) {
      throw new StorageAdapterError(res.status, "STORAGE_DELETE_FAILED", `Supabase delete HTTP ${res.status}`);
    }
    return;
  }

  if (type === "BACKBLAZE_B2") {
    const b2Creds = resolveB2Credentials(provider, deps.getEnv);
    if (!b2Creds) return;
    if (b2Creds.mode === "NATIVE") {
      const session = await authorizeB2Native(provider, b2Creds, mappedBucket, deps.fetchFn);
      const fullKey = objectPath.startsWith(`${logicalBucket}/`) ? objectPath : `${logicalBucket}/${objectPath}`;
      const listRes = await deps.fetchFn(`${session.apiUrl}/b2api/v2/b2_list_file_versions`, {
        method: "POST",
        headers: { Authorization: session.authorizationToken, "Content-Type": "application/json" },
        body: JSON.stringify({ bucketId: session.bucketId, startFileName: fullKey, prefix: fullKey, maxFileCount: 5 })
      });
      if (!listRes.ok) return;
      const listData = await listRes.json() as { files?: Array<{ fileId: string; fileName: string }> };
      const match = (listData.files || []).find((f) => f.fileName === fullKey);
      if (match) {
        await deps.fetchFn(`${session.apiUrl}/b2api/v2/b2_delete_file_version`, {
          method: "POST",
          headers: { Authorization: session.authorizationToken, "Content-Type": "application/json" },
          body: JSON.stringify({ fileName: match.fileName, fileId: match.fileId })
        });
      }
      return;
    }
    const s3Creds = b2Creds.s3!;
    const region = s3Creds.region || provider.region || "us-west-004";
    const fullKey = mappedBucket === logicalBucket || objectPath.startsWith(`${logicalBucket}/`) ? objectPath : `${logicalBucket}/${objectPath}`;
    const targetUrl = resolveS3ObjectUrl(provider, mappedBucket, fullKey);
    const headers = await signAwsS3Request({ method: "DELETE", url: targetUrl, region, credentials: s3Creds });
    const res = await deps.fetchFn(targetUrl, { method: "DELETE", headers });
    if (!res.ok && res.status !== 404) {
      throw new StorageAdapterError(res.status, "STORAGE_DELETE_FAILED", `B2 S3 delete HTTP ${res.status}`);
    }
    return;
  }

  const s3Creds = resolveS3Credentials(provider, deps.getEnv);
  if (!s3Creds) return;
  const region = s3Creds.region || provider.region || (type === "CLOUDFLARE_R2" ? "auto" : "us-east-1");
  const fullKey = mappedBucket === logicalBucket || objectPath.startsWith(`${logicalBucket}/`) ? objectPath : `${logicalBucket}/${objectPath}`;
  const targetUrl = resolveS3ObjectUrl(provider, mappedBucket, fullKey);
  const headers = await signAwsS3Request({ method: "DELETE", url: targetUrl, region, credentials: s3Creds });
  const res = await deps.fetchFn(targetUrl, { method: "DELETE", headers });
  if (!res.ok && res.status !== 404) {
    throw new StorageAdapterError(res.status, "STORAGE_DELETE_FAILED", `Delete HTTP ${res.status}`);
  }
}

export async function createSignedReadUrl(
  provider: StorageProviderConfig,
  bucketOrLogical: string,
  objectPath: string,
  expiresInSeconds: number,
  deps: AdapterDeps
): Promise<{ signedUrl: string; expiresInSeconds: number }> {
  if (!isSafePublicHttpsUrl(provider.endpoint_url)) {
    throw new StorageAdapterError(400, "UNSAFE_ENDPOINT", "Storage provider endpoint URL failed HTTPS safety validation.");
  }
  const type = normalizeCanonicalProviderType(provider.provider_type);
  const mappedBucket = resolveMappedBucket(provider, bucketOrLogical);
  const ttl = Math.max(30, Math.min(3600, expiresInSeconds || 120));

  if (type === "SUPABASE") {
    const serviceKey = (deps.getEnv(provider.secret_env_key) || "").trim();
    if (!serviceKey) {
      throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${provider.secret_env_key} not configured.`);
    }
    const base = provider.endpoint_url.replace(/\/+$/, "");
    const encBucket = encodeRfc3986(mappedBucket);
    const encObj = encodeObjectKeyPath(objectPath);
    const res = await deps.fetchFn(`${base}/storage/v1/object/sign/${encBucket}/${encObj}`, {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ expiresIn: ttl })
    });
    if (res.status === 401 || res.status === 403) {
      throw new StorageAdapterError(res.status, "STORAGE_AUTH_ERROR", `Supabase rejected signed URL request (${res.status}).`);
    }
    const json = await res.json().catch(() => ({})) as { signedURL?: string; signedUrl?: string; message?: string };
    const rel = json.signedURL || json.signedUrl || "";
    if (!res.ok || !rel) {
      throw new StorageAdapterError(res.status >= 400 ? res.status : 500, "SIGNED_URL_ERROR", json.message || "Unable to create Supabase signed URL.");
    }
    const signedUrl = rel.startsWith("https://")
      ? rel
      : rel.startsWith("/storage/v1")
      ? `${base}${rel}`
      : `${base}/storage/v1${rel.startsWith("/") ? "" : "/"}${rel}`;
    return { signedUrl, expiresInSeconds: ttl };
  }

  if (type === "BACKBLAZE_B2") {
    const b2Creds = resolveB2Credentials(provider, deps.getEnv);
    if (!b2Creds) {
      throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${provider.secret_env_key} not configured for B2.`);
    }
    if (b2Creds.mode === "NATIVE") {
      const session = await authorizeB2Native(provider, b2Creds, mappedBucket, deps.fetchFn);
      const key = objectPath;
      const res = await deps.fetchFn(`${session.apiUrl}/b2api/v2/b2_get_download_authorization`, {
        method: "POST",
        headers: {
          Authorization: session.authorizationToken,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          bucketId: session.bucketId,
          fileNamePrefix: key,
          validDurationInSeconds: ttl
        })
      });
      if (res.status === 401 || res.status === 403) {
        throw new StorageAdapterError(res.status, "STORAGE_AUTH_ERROR", `Backblaze B2 rejected download authorization (${res.status}).`);
      }
      const data = await res.json().catch(() => ({})) as { authorizationToken?: string; message?: string };
      if (!res.ok || !data.authorizationToken) {
        throw new StorageAdapterError(res.status >= 400 ? res.status : 500, "SIGNED_URL_ERROR", data.message || "Unable to create B2 download authorization.");
      }
      const signedUrl =
        `${session.downloadUrl}/file/${encodeRfc3986(session.bucketName)}/${encodeObjectKeyPath(key)}?Authorization=${encodeURIComponent(data.authorizationToken)}`;
      return { signedUrl, expiresInSeconds: ttl };
    }
    const s3Creds = b2Creds.s3!;
    const region = s3Creds.region || provider.region || "us-west-004";
    const targetUrl = resolveS3ObjectUrl(provider, mappedBucket, objectPath);
    const signedUrl = await createAwsS3PresignedGetUrl({
      url: targetUrl,
      region,
      credentials: s3Creds,
      expiresInSeconds: ttl
    });
    return { signedUrl, expiresInSeconds: ttl };
  }

  const s3Creds = resolveS3Credentials(provider, deps.getEnv);
  if (!s3Creds) {
    throw new StorageAdapterError(401, "STORAGE_AUTH_MISSING", `Secret ${provider.secret_env_key} not configured.`);
  }
  const region = s3Creds.region || provider.region || (type === "CLOUDFLARE_R2" ? "auto" : "us-east-1");
  const targetUrl = resolveS3ObjectUrl(provider, mappedBucket, objectPath);
  const signedUrl = await createAwsS3PresignedGetUrl({
    url: targetUrl,
    region,
    credentials: s3Creds,
    expiresInSeconds: ttl
  });
  return { signedUrl, expiresInSeconds: ttl };
}

export async function testProviderConnection(
  provider: StorageProviderConfig,
  deps: AdapterDeps
): Promise<{ connected: boolean; status: "CONNECTED" | "AUTH_ERROR" | "ERROR" | "UNAVAILABLE"; message: string; httpStatus: number; buckets?: string[] }> {
  if (!isSafePublicHttpsUrl(provider.endpoint_url)) {
    throw new StorageAdapterError(400, "UNSAFE_ENDPOINT", "Endpoint must be a valid public HTTPS URL.");
  }

  const type = normalizeCanonicalProviderType(provider.provider_type);
  if (!hasServerSecretConfigured(provider, deps.getEnv)) {
    return {
      connected: false,
      status: "AUTH_ERROR",
      httpStatus: 401,
      message: `Missing backend secret environment variable: ${provider.secret_env_key}`
    };
  }

  try {
    if (type === "SUPABASE") {
      const serviceKey = (deps.getEnv(provider.secret_env_key) || "").trim();
      const base = provider.endpoint_url.replace(/\/+$/, "");
      const res = await deps.fetchFn(`${base}/storage/v1/bucket`, {
        method: "GET",
        headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` }
      });
      if (res.status === 401 || res.status === 403) {
        return { connected: false, status: "AUTH_ERROR", httpStatus: res.status, message: `Supabase rejected service credentials (HTTP ${res.status})` };
      }
      if (!res.ok) {
        return { connected: false, status: "UNAVAILABLE", httpStatus: res.status, message: `Supabase returned HTTP ${res.status}` };
      }
      const list = (await res.json().catch(() => [])) as Array<{ id: string }>;
      const buckets = Array.isArray(list) ? list.map((b) => b.id) : [];
      return {
        connected: true,
        status: "CONNECTED",
        httpStatus: 200,
        buckets,
        message: `Connected. Buckets online (${buckets.length}): ${buckets.join(", ")}`
      };
    }

    if (type === "BACKBLAZE_B2") {
      const b2Creds = resolveB2Credentials(provider, deps.getEnv)!;
      if (b2Creds.mode === "NATIVE") {
        const mapped = resolveMappedBucket(provider, "community-photos");
        const session = await authorizeB2Native(provider, b2Creds, mapped, deps.fetchFn);
        return {
          connected: true,
          status: "CONNECTED",
          httpStatus: 200,
          buckets: [session.bucketName],
          message: `B2 Native authorized • Bucket '${session.bucketName}' verified`
        };
      }
      const s3Creds = b2Creds.s3!;
      const region = s3Creds.region || provider.region || "us-west-004";
      const bucket = resolveMappedBucket(provider, "community-photos");
      const listUrl = `${provider.endpoint_url.replace(/\/+$/, "")}/${encodeRfc3986(bucket)}?list-type=2&max-keys=1`;
      const headers = await signAwsS3Request({ method: "GET", url: listUrl, region, credentials: s3Creds });
      const res = await deps.fetchFn(listUrl, { method: "GET", headers });
      if (res.status === 401 || res.status === 403) {
        return { connected: false, status: "AUTH_ERROR", httpStatus: res.status, message: `B2 S3 rejected SigV4 credentials (HTTP ${res.status})` };
      }
      return {
        connected: res.ok,
        status: res.ok ? "CONNECTED" : "UNAVAILABLE",
        httpStatus: res.status,
        message: res.ok ? `B2 S3 SigV4 connected (${bucket})` : `B2 S3 endpoint responded HTTP ${res.status}`
      };
    }

    // CLOUDFLARE_R2 or CUSTOM_S3
    const s3Creds = resolveS3Credentials(provider, deps.getEnv)!;
    const region = s3Creds.region || provider.region || (type === "CLOUDFLARE_R2" ? "auto" : "us-east-1");
    const bucket = resolveMappedBucket(provider, "community-photos");
    const listUrl = `${provider.endpoint_url.replace(/\/+$/, "")}/${encodeRfc3986(bucket)}?list-type=2&max-keys=1`;
    const headers = await signAwsS3Request({ method: "GET", url: listUrl, region, credentials: s3Creds });
    const res = await deps.fetchFn(listUrl, { method: "GET", headers });
    if (res.status === 401 || res.status === 403) {
      return { connected: false, status: "AUTH_ERROR", httpStatus: res.status, message: `${provider.name} rejected SigV4 credentials (HTTP ${res.status})` };
    }
    if (!res.ok) {
      return { connected: false, status: "UNAVAILABLE", httpStatus: res.status, message: `${provider.name} returned HTTP ${res.status}` };
    }
    return {
      connected: true,
      status: "CONNECTED",
      httpStatus: res.status,
      buckets: [bucket],
      message: `${type} SigV4 connected • Bucket '${bucket}' verified`
    };
  } catch (err) {
    if (err instanceof StorageAdapterError) {
      const status = err.status === 401 || err.status === 403 ? "AUTH_ERROR" : "ERROR";
      return { connected: false, status, httpStatus: err.status, message: err.message };
    }
    return { connected: false, status: "ERROR", httpStatus: 503, message: err instanceof Error ? err.message : String(err) };
  }
}
