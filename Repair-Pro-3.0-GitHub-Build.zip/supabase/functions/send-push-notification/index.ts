// Repair Pro v3.0 — Secure Firebase FCM HTTP v1 Push Notification Edge Function
// Runs on Supabase Free Tier (zero Firebase Blaze billing required).
// Uses server-side FIREBASE_SERVICE_ACCOUNT_JSON secret to mint Google OAuth2 access tokens.
// NEVER exposes service account credentials to Android or Web Admin.

import {
  assertSuperAdmin,
  buildCorsHeaders,
  checkRateLimit,
  FIREBASE_PROJECT_ID,
  getServiceSupabase,
  HttpError,
  jsonResponse,
  verifyFirebaseUser
} from "../_shared/firebase-auth.ts";

interface ServiceAccount {
  client_email: string;
  private_key: string;
  project_id?: string;
}

function base64UrlEncode(data: Uint8Array | string): string {
  const bytes = typeof data === "string" ? new TextEncoder().encode(data) : data;
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function pemToArrayBuffer(pem: string): ArrayBuffer {
  const cleaned = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s+/g, "");
  const binary = atob(cleaned);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function mintGoogleOAuthAccessToken(sa: ServiceAccount): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlEncode(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = base64UrlEncode(
    JSON.stringify({
      iss: sa.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3500
    })
  );
  const unsigned = `${header}.${claim}`;
  const cryptoKey = await crypto.subtle.importKey(
    "pkcs8",
    pemToArrayBuffer(sa.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    cryptoKey,
    new TextEncoder().encode(unsigned)
  );
  const jwt = `${unsigned}.${base64UrlEncode(new Uint8Array(signature))}`;

  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  const tokenJson = await tokenRes.json();
  if (!tokenRes.ok || !tokenJson.access_token) {
    throw new Error(`OAuth2 token exchange failed: ${tokenJson.error_description || tokenRes.statusText}`);
  }
  return tokenJson.access_token;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: buildCorsHeaders(req) });
  }

  const supabase = getServiceSupabase();

  try {
    const user = await verifyFirebaseUser(req, supabase);
    assertSuperAdmin(user);

    if (!checkRateLimit(`push:${user.uid}`, 20, 60_000)) {
      throw new HttpError(429, "RATE_LIMITED", "Too many push notification requests. Please wait a minute.");
    }

    if (req.method !== "POST") {
      throw new HttpError(405, "METHOD_NOT_ALLOWED", "Use POST to send push notifications.");
    }

    const body = await req.json();
    const title = String(body.title || "").trim().slice(0, 120);
    const message = String(body.body || body.message || "").trim().slice(0, 500);
    const targetType = String(body.targetType || "ALL").toUpperCase();
    const targetUids: string[] = Array.isArray(body.targetUids)
      ? body.targetUids.map((x: unknown) => String(x).trim()).filter(Boolean)
      : [];

    if (!title || !message) {
      throw new HttpError(400, "INVALID_INPUT", "Notification title and message are required.");
    }
    if (!["ALL", "SELECTED", "TECHNICIANS"].includes(targetType)) {
      throw new HttpError(400, "INVALID_TARGET", "targetType must be ALL, SELECTED, or TECHNICIANS.");
    }
    if (targetType === "SELECTED" && targetUids.length === 0) {
      throw new HttpError(400, "MISSING_RECIPIENTS", "Select at least one user UID for SELECTED notifications.");
    }

    // Resolve recipient FCM tokens from Supabase
    let resolvedUids: string[] = targetUids;
    if (targetType === "TECHNICIANS") {
      const { data: techs } = await supabase
        .from("technicians")
        .select("firebase_uid")
        .eq("approval_status", "APPROVED")
        .eq("is_active", true)
        .eq("is_blocked", false);
      resolvedUids = (techs || []).map((t) => t.firebase_uid);
    }

    let tokenQuery = supabase
      .from("user_fcm_tokens")
      .select("firebase_uid, fcm_token")
      .eq("is_active", true);

    if (targetType === "SELECTED" || targetType === "TECHNICIANS") {
      if (resolvedUids.length === 0) {
        const { data: rec } = await supabase
          .from("notifications")
          .insert({
            title,
            body: message,
            target_type: targetType,
            target_uids: resolvedUids,
            sent_by_uid: user.uid,
            sent_by_email: user.email,
            total_targeted: 0,
            success_count: 0,
            failure_count: 0,
            delivery_status: "NO_RECIPIENTS",
            error_message: "No active registered FCM device tokens matched the selected audience."
          })
          .select()
          .single();
        return jsonResponse(req, 200, { ok: true, notification: rec, warning: "No registered FCM tokens matched." });
      }
      tokenQuery = tokenQuery.in("firebase_uid", resolvedUids);
    }

    const { data: tokenRows } = await tokenQuery;
    const tokens = (tokenRows || []).map((r) => r.fcm_token).filter(Boolean);

    const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
    let successCount = 0;
    let failureCount = 0;
    let deliveryStatus = "SENT";
    let errorMessage: string | null = null;

    if (!saRaw) {
      deliveryStatus = "LOGGED_PENDING_FCM_SECRET";
      errorMessage =
        "FIREBASE_SERVICE_ACCOUNT_JSON secret is not yet configured in Supabase Edge Function secrets. Notification saved to history; set secret to enable live FCM HTTP v1 push delivery.";
    } else if (tokens.length === 0) {
      deliveryStatus = "NO_TOKENS";
      errorMessage = "Notification saved to history, but 0 active device FCM tokens are registered yet.";
    } else {
      const sa = JSON.parse(saRaw) as ServiceAccount;
      const accessToken = await mintGoogleOAuthAccessToken(sa);
      const projectId = sa.project_id || FIREBASE_PROJECT_ID;
      const fcmEndpoint = `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`;

      for (const token of tokens) {
        const res = await fetch(fcmEndpoint, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            message: {
              token,
              notification: { title, body: message },
              android: {
                priority: "HIGH",
                notification: {
                  channel_id: "repair_pro_alerts",
                  sound: "default"
                }
              },
              data: {
                targetType,
                sentAt: new Date().toISOString(),
                appVersion: "3.0"
              }
            }
          })
        });
        if (res.ok) {
          successCount++;
        } else {
          failureCount++;
          const errText = await res.text();
          if (errText.includes("UNREGISTERED") || errText.includes("NOT_FOUND")) {
            await supabase.from("user_fcm_tokens").update({ is_active: false }).eq("fcm_token", token);
          }
          errorMessage = errText.slice(0, 300);
        }
      }
      deliveryStatus = failureCount === 0 ? "SENT" : successCount > 0 ? "PARTIAL" : "FAILED";
    }

    const { data: record } = await supabase
      .from("notifications")
      .insert({
        title,
        body: message,
        target_type: targetType,
        target_uids: resolvedUids,
        sent_by_uid: user.uid,
        sent_by_email: user.email,
        total_targeted: tokens.length,
        success_count: successCount,
        failure_count: failureCount,
        delivery_status: deliveryStatus,
        error_message: errorMessage
      })
      .select()
      .single();

    await supabase.from("admin_activity_logs").insert({
      admin_uid: user.uid,
      admin_email: user.email,
      action: "SEND_PUSH_NOTIFICATION",
      target_type: "notifications",
      target_id: record?.id || "push",
      details: `Target=${targetType}, Targeted=${tokens.length}, Sent=${successCount}, Status=${deliveryStatus}`
    });

    return jsonResponse(req, 200, {
      ok: true,
      notification: record,
      totalTargeted: tokens.length,
      successCount,
      failureCount,
      deliveryStatus,
      warning: errorMessage
    });
  } catch (err) {
    const status = err instanceof HttpError ? err.status : 500;
    const code = err instanceof HttpError ? err.code : "PUSH_INTERNAL_ERROR";
    const message = err instanceof Error ? err.message : "Unknown push notification error";

    // Log error cleanly — NEVER clears admin session
    try {
      await supabase.from("system_error_logs").insert({
        source: "send-push-notification",
        severity: status >= 500 ? "ERROR" : "WARN",
        message: message.slice(0, 500),
        context: { code, status }
      });
    } catch { /* ignore secondary log error */ }

    return jsonResponse(req, status, {
      ok: false,
      code,
      error: message,
      keepSession: true
    });
  }
});
