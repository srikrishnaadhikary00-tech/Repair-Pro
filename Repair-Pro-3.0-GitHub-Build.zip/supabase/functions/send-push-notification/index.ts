// Repair Pro — Canonical FCM HTTP v1 Push Notification Edge Function
// Uses Supabase Postgres (fcm_tokens, technicians, technician_verification_requests, admin_roles)
// and Firebase ONLY for ID token verification + FCM HTTP v1 dispatch.
// Required Supabase Edge Function Secrets:
//   FIREBASE_SERVICE_ACCOUNT_JSON  = Full JSON string of Firebase service account key (gen-lang-client-0218221723)
//   SUPABASE_URL                   = https://xuakzzjtcgcvudkgxpbd.supabase.co
//   SUPABASE_SERVICE_ROLE_KEY      = Service role key (server-side ONLY)
// Optional:
//   FIREBASE_WEB_API_KEY           = AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M

const PROJECT_ID = "gen-lang-client-0218221723";
const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
const DEFAULT_FIREBASE_WEB_API_KEY = "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M";
const DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";

const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

function jsonResponse(status: number, payload: Record<string, unknown>): Response {
  return new Response(JSON.stringify(payload), { status, headers: corsHeaders });
}

function getSupabaseServiceEnv() {
  const url = (Deno.env.get("SUPABASE_URL") || DEFAULT_SUPABASE_URL).replace(/\/+$/, "");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  return { url, serviceKey };
}

async function supabaseRequest(path: string, init: RequestInit = {}): Promise<Response> {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey) {
    throw new Error("SUPABASE_SERVICE_ROLE_KEY is missing in Edge Function secrets.");
  }
  const headers = new Headers(init.headers || {});
  headers.set("apikey", serviceKey);
  headers.set("Authorization", `Bearer ${serviceKey}`);
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  return await fetch(`${url}${path}`, { ...init, headers });
}

function base64UrlEncode(input: Uint8Array | string): string {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function pemToArrayBuffer(pem: string): ArrayBuffer {
  const clean = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s+/g, "");
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function getFcmAccessToken(serviceAccount: {
  client_email: string;
  private_key: string;
  token_uri?: string;
}): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlEncode(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claimSet = base64UrlEncode(
    JSON.stringify({
      iss: serviceAccount.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: serviceAccount.token_uri || "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600
    })
  );
  const signingInput = `${header}.${claimSet}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToArrayBuffer(serviceAccount.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    key,
    new TextEncoder().encode(signingInput)
  );
  const jwt = `${signingInput}.${base64UrlEncode(new Uint8Array(signature))}`;

  const tokenResp = await fetch(serviceAccount.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  const tokenData = await tokenResp.json();
  if (!tokenResp.ok || !tokenData.access_token) {
    throw new Error(`OAuth2 token exchange failed: ${tokenData.error_description || tokenData.error || tokenResp.status}`);
  }
  return tokenData.access_token;
}

interface VerifiedCaller {
  uid: string;
  email: string;
  emailVerified: boolean;
  claims: Record<string, unknown>;
}

async function verifyFirebaseIdToken(idToken: string): Promise<VerifiedCaller> {
  const webApiKey = Deno.env.get("FIREBASE_WEB_API_KEY") || DEFAULT_FIREBASE_WEB_API_KEY;
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(webApiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken })
  });
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(data?.error?.message || "Invalid or expired Firebase ID token.");
  }
  const user = data.users[0];
  let claims: Record<string, unknown> = {};
  if (typeof user.customAttributes === "string" && user.customAttributes.trim()) {
    try { claims = JSON.parse(user.customAttributes); } catch { claims = {}; }
  }
  return {
    uid: String(user.localId || ""),
    email: String(user.email || ""),
    emailVerified: Boolean(user.emailVerified),
    claims
  };
}

async function isAuthorizedAdmin(caller: VerifiedCaller): Promise<boolean> {
  if (caller.emailVerified && caller.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) {
    return true;
  }
  if (caller.claims?.admin === true || caller.claims?.repairproRole === "SUPER_ADMIN") {
    return true;
  }
  try {
    const resp = await supabaseRequest(
      `/rest/v1/admin_roles?user_id=eq.${encodeURIComponent(caller.uid)}&select=user_id&limit=1`
    );
    if (!resp.ok) return false;
    const rows = await resp.json();
    return Array.isArray(rows) && rows.length > 0;
  } catch {
    return false;
  }
}

async function resolveTargetTokensFromSupabase(
  audience: string,
  targetUids: string[],
  explicitTokens: string[]
): Promise<string[]> {
  const tokenSet = new Set<string>(explicitTokens.filter((t) => typeof t === "string" && t.length >= 10));

  if (audience === "SELECTED") {
    const cleanUids = targetUids.map((u) => u.trim()).filter(Boolean).slice(0, 200);
    if (cleanUids.length === 0) return Array.from(tokenSet);
    const inClause = cleanUids.map((u) => `"${u.replace(/"/g, "")}"`).join(",");
    const resp = await supabaseRequest(
      `/rest/v1/fcm_tokens?user_id=in.(${encodeURIComponent(inClause)})&select=token&limit=500`
    ).catch(() => null);
    if (resp && resp.ok) {
      const rows = await resp.json().catch(() => []);
      if (Array.isArray(rows)) {
        for (const r of rows) {
          const t = String(r?.token || "");
          if (t.length >= 10) tokenSet.add(t);
        }
      }
    }
    return Array.from(tokenSet);
  }

  if (audience === "TECHNICIANS") {
    const uidSet = new Set<string>();
    const [techResp, verResp] = await Promise.all([
      supabaseRequest(`/rest/v1/technicians?status=eq.ACTIVE&is_deleted=eq.false&select=linked_user_uid&limit=500`).catch(() => null),
      supabaseRequest(`/rest/v1/technician_verification_requests?status=eq.VERIFIED&select=user_id&limit=500`).catch(() => null)
    ]);
    if (techResp && techResp.ok) {
      const rows = await techResp.json().catch(() => []);
      if (Array.isArray(rows)) {
        for (const r of rows) {
          const uid = String(r?.linked_user_uid || "").trim();
          if (uid) uidSet.add(uid);
        }
      }
    }
    if (verResp && verResp.ok) {
      const rows = await verResp.json().catch(() => []);
      if (Array.isArray(rows)) {
        for (const r of rows) {
          const uid = String(r?.user_id || "").trim();
          if (uid) uidSet.add(uid);
        }
      }
    }
    const uidList = Array.from(uidSet).slice(0, 300);
    if (uidList.length > 0) {
      const inClause = uidList.map((u) => `"${u.replace(/"/g, "")}"`).join(",");
      const tokResp = await supabaseRequest(
        `/rest/v1/fcm_tokens?user_id=in.(${encodeURIComponent(inClause)})&select=token&limit=1000`
      ).catch(() => null);
      if (tokResp && tokResp.ok) {
        const rows = await tokResp.json().catch(() => []);
        if (Array.isArray(rows)) {
          for (const r of rows) {
            const t = String(r?.token || "");
            if (t.length >= 10) tokenSet.add(t);
          }
        }
      }
    }
    return Array.from(tokenSet);
  }

  // Default: ALL tokens stored in Supabase fcm_tokens
  const resp = await supabaseRequest(`/rest/v1/fcm_tokens?select=token&limit=1000`).catch(() => null);
  if (resp && resp.ok) {
    const rows = await resp.json().catch(() => []);
    if (Array.isArray(rows)) {
      for (const r of rows) {
        const t = String(r?.token || "");
        if (t.length >= 10) tokenSet.add(t);
      }
    }
  }
  return Array.from(tokenSet);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return jsonResponse(405, { ok: false, errorCode: "METHOD_NOT_ALLOWED", message: "Use POST." });
  }

  try {
    const authHeader = req.headers.get("authorization") || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    if (!idToken) {
      return jsonResponse(401, {
        ok: false,
        errorCode: "MISSING_AUTH_TOKEN",
        message: "Missing Firebase ID Bearer token. Your session was NOT signed out."
      });
    }

    let caller: VerifiedCaller;
    try {
      caller = await verifyFirebaseIdToken(idToken);
    } catch (authErr) {
      return jsonResponse(401, {
        ok: false,
        errorCode: "INVALID_AUTH_TOKEN",
        message: authErr instanceof Error ? authErr.message : "Firebase token verification failed."
      });
    }

    const allowed = await isAuthorizedAdmin(caller);
    if (!allowed) {
      return jsonResponse(403, {
        ok: false,
        errorCode: "FORBIDDEN",
        message: "Account does not have Super Admin permission in Supabase admin_roles or Firebase custom claims."
      });
    }

    const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
    if (!saRaw.trim()) {
      return jsonResponse(503, {
        ok: false,
        errorCode: "FCM_SERVICE_ACCOUNT_NOT_CONFIGURED",
        message: "FIREBASE_SERVICE_ACCOUNT_JSON secret is not configured in Supabase Edge Function secrets yet."
      });
    }

    const serviceAccount = JSON.parse(saRaw);
    const fcmAccessToken = await getFcmAccessToken(serviceAccount);

    const body = await req.json();
    const audience = ["ALL", "SELECTED", "TECHNICIANS"].includes(body?.audience) ? body.audience : "ALL";
    const title = String(body?.title || "").trim().slice(0, 140);
    const message = String(body?.message || body?.body || "").trim().slice(0, 1200);
    const imageUrl = typeof body?.imageUrl === "string" && body.imageUrl.startsWith("https://")
      ? body.imageUrl.trim().slice(0, 1000)
      : "";
    const route = String(body?.route || body?.targetRoute || "notifications").trim().slice(0, 160);
    const channel = String(body?.channel || "announcements").trim().slice(0, 40);
    const eventType = String(body?.eventType || "ANNOUNCEMENT").trim().slice(0, 64);
    const targetUids = Array.isArray(body?.targetUids) ? body.targetUids.map(String) : [];
    const explicitTokens = Array.isArray(body?.tokens) ? body.tokens.map(String) : [];

    if (title.length < 2 || message.length < 2) {
      return jsonResponse(400, {
        ok: false,
        errorCode: "VALIDATION_ERROR",
        message: "Notification title and message are required."
      });
    }

    const tokens = await resolveTargetTokensFromSupabase(audience, targetUids, explicitTokens);
    if (tokens.length === 0) {
      return jsonResponse(200, {
        ok: true,
        deliveryStatus: "IN_APP_ONLY",
        sentCount: 0,
        failedCount: 0,
        totalTargets: 0,
        message: "No registered Android FCM tokens matched the target audience yet."
      });
    }

    const androidChannelId = channel === "community"
      ? "repair_pro_community"
      : channel === "verification"
        ? "repair_pro_verification"
        : "repair_pro_announcements";

    let sentCount = 0;
    let failedCount = 0;
    const errors: string[] = [];

    const fcmEndpoint = `https://fcm.googleapis.com/v1/projects/${PROJECT_ID}/messages:send`;
    for (const token of tokens) {
      const fcmBody: Record<string, unknown> = {
        message: {
          token,
          notification: {
            title,
            body: message,
            ...(imageUrl ? { image: imageUrl } : {})
          },
          data: {
            title,
            body: message,
            channel,
            route,
            imageUrl,
            eventType
          },
          android: {
            priority: "HIGH",
            notification: {
              channel_id: androidChannelId,
              ...(imageUrl ? { image: imageUrl } : {})
            }
          }
        }
      };

      const res = await fetch(fcmEndpoint, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${fcmAccessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(fcmBody)
      });

      if (res.ok) {
        sentCount += 1;
      } else {
        failedCount += 1;
        const errPayload = await res.json().catch(() => ({}));
        const detail = errPayload?.error?.message || `HTTP ${res.status}`;
        if (errors.length < 5) errors.push(detail);
      }
    }

    const deliveryStatus = sentCount > 0 && failedCount === 0
      ? "SENT"
      : sentCount > 0
        ? "PARTIAL"
        : "FAILED";

    return jsonResponse(200, {
      ok: sentCount > 0,
      deliveryStatus,
      sentCount,
      failedCount,
      totalTargets: tokens.length,
      errors
    });
  } catch (err) {
    return jsonResponse(500, {
      ok: false,
      errorCode: "INTERNAL_ERROR",
      message: err instanceof Error ? err.message : "Unexpected FCM dispatch error"
    });
  }
});
