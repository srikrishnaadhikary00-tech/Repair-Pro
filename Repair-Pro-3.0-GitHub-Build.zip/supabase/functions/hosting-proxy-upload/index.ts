// Repair Pro — Secure Shared Hosting & Multi-Cloud Upload Proxy (Supabase Edge Function)
// Handles PHP Shared Hosting (Hostinger, BigRock, MilesWeb, GoDaddy, Namecheap, HostGator, cPanel)
// without exposing hosting secrets in Android APK or public Firestore settings.
//
// Required Edge Function Secrets:
//   SUPABASE_URL
//   SUPABASE_SERVICE_ROLE_KEY
// Optional Secrets:
//   FIREBASE_SERVICE_ACCOUNT_JSON (for admins/{uid} RBAC lookup for delegated admins)
//   FIREBASE_WEB_API_KEY
//   PHP_HOSTING_DEFAULT_SECRET

const PROJECT_ID = "gen-lang-client-0218221723";
const FIRESTORE_DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
const DEFAULT_FIREBASE_WEB_API_KEY = "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M";
const DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";

const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

function jsonResponse(status: number, payload: Record<string, unknown>): Response {
  return new Response(JSON.stringify(payload), { status, headers: corsHeaders });
}

async function verifyFirebaseIdToken(idToken: string): Promise<{ uid: string; email: string; emailVerified: boolean }> {
  const webApiKey = Deno.env.get("FIREBASE_WEB_API_KEY") || DEFAULT_FIREBASE_WEB_API_KEY;
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(webApiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken })
  });
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(data?.error?.message || "Invalid or expired Firebase ID token.");
  }
  const user = data.users[0];
  return {
    uid: String(user.localId || ""),
    email: String(user.email || ""),
    emailVerified: Boolean(user.emailVerified)
  };
}

function base64UrlEncode(input: Uint8Array | string): string {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function pemToArrayBuffer(pem: string): ArrayBuffer {
  const clean = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s+/g, "");
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function getGoogleAccessToken(serviceAccount: { client_email: string; private_key: string; token_uri?: string }): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlEncode(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claimSet = base64UrlEncode(JSON.stringify({
    iss: serviceAccount.client_email,
    scope: "https://www.googleapis.com/auth/datastore",
    aud: serviceAccount.token_uri || "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600
  }));
  const signingInput = `${header}.${claimSet}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToArrayBuffer(serviceAccount.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(signingInput));
  const jwt = `${signingInput}.${base64UrlEncode(new Uint8Array(signature))}`;
  const resp = await fetch(serviceAccount.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt })
  });
  const data = await resp.json();
  if (!resp.ok || !data.access_token) throw new Error("Google OAuth2 failed");
  return data.access_token;
}

async function isAuthorizedAdmin(uid: string, email: string, emailVerified: boolean): Promise<boolean> {
  if (emailVerified && email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) return true;
  const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
  if (!saRaw.trim()) return false;
  try {
    const token = await getGoogleAccessToken(JSON.parse(saRaw));
    const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/admins/${encodeURIComponent(uid)}`;
    const resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    return resp.ok;
  } catch {
    return false;
  }
}

async function hmacSha256Hex(secret: string, message: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function getSupabaseServiceEnv() {
  const url = (Deno.env.get("SUPABASE_URL") || DEFAULT_SUPABASE_URL).replace(/\/+$/, "");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  return { url, serviceKey };
}

async function fetchProviderSecret(providerId: string): Promise<string> {
  const cleanId = providerId.replace(/[^a-zA-Z0-9_-]/g, "_");
  const envSpecific = Deno.env.get(`HOSTING_SECRET_${cleanId.toUpperCase()}`) || "";
  if (envSpecific.trim()) return envSpecific.trim();

  const { url, serviceKey } = getSupabaseServiceEnv();
  if (serviceKey) {
    const resp = await fetch(
      `${url}/rest/v1/hosting_provider_secrets?provider_id=eq.${encodeURIComponent(providerId)}&select=api_secret&limit=1`,
      {
        headers: {
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`
        }
      }
    );
    if (resp.ok) {
      const rows = await resp.json();
      if (Array.isArray(rows) && rows[0]?.api_secret) {
        return String(rows[0].api_secret).trim();
      }
    }
  }
  return (Deno.env.get("PHP_HOSTING_DEFAULT_SECRET") || "").trim();
}

async function upsertProviderSecret(providerId: string, apiSecret: string, adminUid: string): Promise<void> {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey) {
    throw new Error("SUPABASE_SERVICE_ROLE_KEY is missing in Edge Function secrets.");
  }
  const resp = await fetch(`${url}/rest/v1/hosting_provider_secrets?on_conflict=provider_id`, {
    method: "POST",
    headers: {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates,return=minimal"
    },
    body: JSON.stringify({
      provider_id: providerId.slice(0, 128),
      auth_mode: "BEARER_OR_HMAC",
      api_secret: apiSecret.trim(),
      updated_by_uid: adminUid,
      updated_at: new Date().toISOString()
    })
  });
  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    throw new Error(`Could not save server secret (HTTP ${resp.status}): ${errText.slice(0, 180)}`);
  }
}

async function fetchProviderEndpointFromFirestore(providerId: string): Promise<{ endpointUrl: string; publicMediaBaseUrl: string } | null> {
  const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON") || "";
  if (!saRaw.trim()) return null;
  try {
    const token = await getGoogleAccessToken(JSON.parse(saRaw));
    const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/app_settings/storage_config`;
    const resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!resp.ok) return null;
    const doc = await resp.json();
    const providersRaw = doc?.fields?.providersJson?.stringValue;
    if (!providersRaw) return null;
    const list = JSON.parse(providersRaw);
    if (!Array.isArray(list)) return null;
    const matched = list.find((p: Record<string, unknown>) => String(p.providerId) === providerId);
    if (!matched) return null;
    return {
      endpointUrl: String(matched.uploadApiUrl || matched.endpointUrl || "").trim(),
      publicMediaBaseUrl: String(matched.publicMediaBaseUrl || matched.endpointUrl || "").trim()
    };
  } catch {
    return null;
  }
}

function buildPhpApiUrl(rawEndpoint: string, action: string, extraQuery = ""): string {
  const base = rawEndpoint.trim().replace(/\/+$/, "");
  const hasIndex = /\.php$/i.test(base);
  const scriptUrl = hasIndex ? base : `${base}/index.php`;
  const sep = scriptUrl.includes("?") ? "&" : "?";
  return `${scriptUrl}${sep}action=${encodeURIComponent(action)}${extraQuery ? "&" + extraQuery : ""}`;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return jsonResponse(405, { ok: false, errorCode: "METHOD_NOT_ALLOWED", message: "Use POST." });
  }

  try {
    const authHeader = req.headers.get("authorization") || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    if (!idToken) {
      return jsonResponse(401, { ok: false, errorCode: "MISSING_AUTH_TOKEN", message: "Firebase Bearer token required." });
    }
    const caller = await verifyFirebaseIdToken(idToken);
    const body = await req.json();
    const action = String(body?.action || "upload").toLowerCase();
    const providerId = String(body?.providerId || "").trim().slice(0, 128);

    // Admin-only secret storage (never echoes secret back!)
    if (action === "save_secret") {
      const admin = await isAuthorizedAdmin(caller.uid, caller.email, caller.emailVerified);
      if (!admin) return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Super Admin access required." });
      const apiSecret = String(body?.apiSecret || "").trim();
      if (!providerId || apiSecret.length < 16) {
        return jsonResponse(400, { ok: false, errorCode: "VALIDATION_ERROR", message: "providerId and strong apiSecret (>=16 chars) required." });
      }
      await upsertProviderSecret(providerId, apiSecret, caller.uid);
      return jsonResponse(200, { ok: true, providerId, message: "Hosting API secret stored securely on backend (never sent to APK)." });
    }

    if (action === "test_connection" || action === "list_files") {
      const admin = await isAuthorizedAdmin(caller.uid, caller.email, caller.emailVerified);
      if (!admin) return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Super Admin access required." });
      const endpointUrl = String(body?.uploadApiUrl || body?.endpointUrl || "").trim();
      if (!endpointUrl.startsWith("https://")) {
        return jsonResponse(400, { ok: false, errorCode: "INVALID_URL", message: "HTTPS PHP API URL required." });
      }
      const overrideSecret = String(body?.tempApiSecret || "").trim();
      const secret = overrideSecret || await fetchProviderSecret(providerId);
      if (!secret) {
        return jsonResponse(400, { ok: false, errorCode: "SECRET_MISSING", message: "No backend hosting secret found for this provider. Save the PHP config.php secret first." });
      }
      const phpAction = action === "test_connection" ? "health" : "list";
      const bucket = String(body?.bucketName || "community-photos").replace(/[^a-zA-Z0-9_-]/g, "");
      const targetUrl = buildPhpApiUrl(endpointUrl, phpAction, phpAction === "list" ? `bucket=${encodeURIComponent(bucket)}` : "");
      const ts = String(Math.floor(Date.now() / 1000));
      const sig = await hmacSha256Hex(secret, `${ts}|${phpAction}`);
      const resp = await fetch(targetUrl, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${secret}`,
          "X-RepairPro-Timestamp": ts,
          "X-RepairPro-Signature": sig
        }
      });
      const parsed = await resp.json().catch(() => ({}));
      if (!resp.ok || !parsed.ok) {
        return jsonResponse(resp.status || 502, {
          ok: false,
          errorCode: parsed.errorCode || "HOSTING_CHECK_FAILED",
          message: parsed.message || `PHP Hosting returned HTTP ${resp.status}`
        });
      }
      return jsonResponse(200, parsed);
    }

    if (action === "delete_file") {
      const admin = await isAuthorizedAdmin(caller.uid, caller.email, caller.emailVerified);
      if (!admin) return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Super Admin access required." });
      const endpointUrl = String(body?.uploadApiUrl || body?.endpointUrl || "").trim();
      const storagePath = String(body?.storagePath || "").trim();
      const secret = await fetchProviderSecret(providerId);
      if (!endpointUrl.startsWith("https://") || !storagePath || !secret) {
        return jsonResponse(400, { ok: false, errorCode: "INVALID_REQUEST", message: "Endpoint, storagePath, and backend secret are required." });
      }
      const ts = String(Math.floor(Date.now() / 1000));
      const sig = await hmacSha256Hex(secret, `${ts}|delete`);
      const resp = await fetch(buildPhpApiUrl(endpointUrl, "delete"), {
        method: "POST",
        headers: {
          Authorization: `Bearer ${secret}`,
          "X-RepairPro-Timestamp": ts,
          "X-RepairPro-Signature": sig,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ storagePath })
      });
      const parsed = await resp.json().catch(() => ({}));
      return jsonResponse(resp.status, parsed);
    }

    // Default: authenticated user upload forwarding to PHP Shared Hosting
    const bucketName = String(body?.bucketName || "community-photos").replace(/[^a-zA-Z0-9_-]/g, "");
    const objectPath = String(body?.objectPath || "").trim();
    const base64Data = String(body?.base64 || "").trim();
    let endpointUrl = String(body?.uploadApiUrl || body?.endpointUrl || "").trim();

    if (!endpointUrl && providerId) {
      const fsProv = await fetchProviderEndpointFromFirestore(providerId);
      if (fsProv?.endpointUrl) endpointUrl = fsProv.endpointUrl;
    }

    if (!endpointUrl.startsWith("https://") || !objectPath || !base64Data) {
      return jsonResponse(400, {
        ok: false,
        errorCode: "INVALID_UPLOAD_PAYLOAD",
        message: "HTTPS endpointUrl, objectPath, and base64 image data are required."
      });
    }

    const secret = await fetchProviderSecret(providerId);
    if (!secret) {
      return jsonResponse(503, {
        ok: false,
        errorCode: "HOSTING_SECRET_NOT_CONFIGURED",
        message: "Hosting API secret is not configured in backend secret store yet."
      });
    }

    const ts = String(Math.floor(Date.now() / 1000));
    const sig = await hmacSha256Hex(secret, `${ts}|upload`);
    const phpResp = await fetch(buildPhpApiUrl(endpointUrl, "upload"), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${secret}`,
        "X-RepairPro-Timestamp": ts,
        "X-RepairPro-Signature": sig,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        bucket: bucketName,
        objectPath,
        base64: base64Data,
        uploadedByUid: caller.uid
      })
    });

    const phpJson = await phpResp.json().catch(() => ({}));
    if (!phpResp.ok || !phpJson.ok || !phpJson.publicUrl) {
      return jsonResponse(phpResp.status >= 400 ? phpResp.status : 502, {
        ok: false,
        errorCode: phpJson.errorCode || "PHP_UPLOAD_FAILED",
        message: phpJson.message || `Shared hosting upload returned HTTP ${phpResp.status}`
      });
    }

    return jsonResponse(200, {
      ok: true,
      providerId,
      bucketName: phpJson.bucketName || bucketName,
      storagePath: phpJson.storagePath || `${bucketName}/${objectPath}`,
      publicUrl: phpJson.publicUrl,
      deduplicated: Boolean(phpJson.deduplicated),
      sizeBytes: Number(phpJson.sizeBytes || 0)
    });
  } catch (err) {
    return jsonResponse(500, {
      ok: false,
      errorCode: "INTERNAL_ERROR",
      message: err instanceof Error ? err.message : "Hosting proxy error"
    });
  }
});
