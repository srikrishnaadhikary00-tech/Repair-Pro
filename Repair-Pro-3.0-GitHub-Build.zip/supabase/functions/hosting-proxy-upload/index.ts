// Repair Pro — Secure Shared Hosting Media & External Multi-Database Proxy (Supabase Edge Function)
// Handles PHP Shared Hosting (Hostinger, BigRock, MilesWeb, GoDaddy, Namecheap, HostGator, cPanel)
// for both media/PDF uploads AND optional external MySQL/SQLite structured CRUD records,
// reading provider metadata and secrets strictly from Supabase Postgres (`storage_providers`, `app_settings`, `hosting_provider_secrets`).
//
// Required Edge Function Secrets:
//   SUPABASE_URL
//   SUPABASE_SERVICE_ROLE_KEY
// Optional Secrets:
//   FIREBASE_WEB_API_KEY
//   PHP_HOSTING_DEFAULT_SECRET

const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
const DEFAULT_FIREBASE_WEB_API_KEY = "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M";
const DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";

const ALLOWED_EXTERNAL_DB_TABLES = new Set([
  "community_posts",
  "community_comments",
  "community_likes",
  "community_bookmarks",
  "community_reports",
  "community_user_restrictions",
  "technicians",
  "technician_verification_requests",
  "technical_documents",
  "problem_reports",
  "catalog_entries",
  "repair_catalog_entries",
  "user_profiles",
  "saved_guides"
]);

const USER_WRITABLE_DB_TABLES = new Set([
  "community_posts",
  "community_comments",
  "community_likes",
  "community_bookmarks",
  "community_reports",
  "problem_reports",
  "technician_verification_requests",
  "user_profiles",
  "saved_guides"
]);

const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

function jsonResponse(status: number, payload: Record<string, unknown>): Response {
  return new Response(JSON.stringify(payload), { status, headers: corsHeaders });
}

function getSupabaseServiceEnv() {
  const url = (Deno.env.get("SUPABASE_URL") || DEFAULT_SUPABASE_URL).replace(/\/+$/, "");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  return { url, serviceKey };
}

async function supabaseRequest(path: string, init: RequestInit = {}): Promise<Response | null> {
  const { url, serviceKey } = getSupabaseServiceEnv();
  if (!serviceKey) return null;
  const headers = new Headers(init.headers || {});
  headers.set("apikey", serviceKey);
  headers.set("Authorization", `Bearer ${serviceKey}`);
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  return await fetch(`${url}${path}`, { ...init, headers });
}

interface VerifiedCaller {
  uid: string;
  email: string;
  emailVerified: boolean;
  claims: Record<string, unknown>;
}

async function verifyFirebaseIdToken(idToken: string): Promise<VerifiedCaller> {
  const webApiKey = Deno.env.get("FIREBASE_WEB_API_KEY") || DEFAULT_FIREBASE_WEB_API_KEY;
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(webApiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken })
  });
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(data?.error?.message || "Invalid or expired Firebase ID token.");
  }
  const user = data.users[0];
  let claims: Record<string, unknown> = {};
  if (typeof user.customAttributes === "string" && user.customAttributes.trim()) {
    try { claims = JSON.parse(user.customAttributes); } catch { claims = {}; }
  }
  return {
    uid: String(user.localId || ""),
    email: String(user.email || ""),
    emailVerified: Boolean(user.emailVerified),
    claims
  };
}

async function isAuthorizedAdmin(caller: VerifiedCaller): Promise<boolean> {
  if (caller.emailVerified && caller.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) return true;
  if (caller.claims?.admin === true || caller.claims?.repairproRole === "SUPER_ADMIN") return true;
  try {
    const resp = await supabaseRequest(
      `/rest/v1/admin_roles?user_id=eq.${encodeURIComponent(caller.uid)}&select=user_id&limit=1`
    );
    if (!resp || !resp.ok) return false;
    const rows = await resp.json();
    return Array.isArray(rows) && rows.length > 0;
  } catch {
    return false;
  }
}

async function isCallerAccountBlocked(caller: VerifiedCaller): Promise<boolean> {
  if (await isAuthorizedAdmin(caller)) return false;
  if (caller.claims?.blocked === true || caller.claims?.suspended === true || caller.claims?.communityRestricted === true) return true;
  try {
    const [profResp, commResp] = await Promise.all([
      supabaseRequest(`/rest/v1/user_profiles?user_id=eq.${encodeURIComponent(caller.uid)}&select=blocked,suspended,community_restricted&limit=1`),
      supabaseRequest(`/rest/v1/community_user_restrictions?user_id=eq.${encodeURIComponent(caller.uid)}&select=is_blocked,can_post&limit=1`)
    ]);
    if (profResp && profResp.ok) {
      const rows = await profResp.json();
      if (Array.isArray(rows) && rows[0] && (rows[0].blocked || rows[0].suspended || rows[0].community_restricted)) {
        return true;
      }
    }
    if (commResp && commResp.ok) {
      const crows = await commResp.json();
      if (Array.isArray(crows) && crows[0] && (crows[0].is_blocked || crows[0].can_post === false)) {
        return true;
      }
    }
    return false;
  } catch {
    return false;
  }
}

async function isCallerUploadBlocked(caller: VerifiedCaller): Promise<boolean> {
  if (await isCallerAccountBlocked(caller)) return true;
  if (caller.claims?.uploadRestricted === true) return true;
  try {
    const [profResp, commResp] = await Promise.all([
      supabaseRequest(`/rest/v1/user_profiles?user_id=eq.${encodeURIComponent(caller.uid)}&select=upload_restricted&limit=1`),
      supabaseRequest(`/rest/v1/community_user_restrictions?user_id=eq.${encodeURIComponent(caller.uid)}&select=can_upload_photo&limit=1`)
    ]);
    if (profResp && profResp.ok) {
      const rows = await profResp.json();
      if (Array.isArray(rows) && rows[0] && rows[0].upload_restricted) return true;
    }
    if (commResp && commResp.ok) {
      const crows = await commResp.json();
      if (Array.isArray(crows) && crows[0] && crows[0].can_upload_photo === false) return true;
    }
    return false;
  } catch {
    return false;
  }
}

function isIpv4Literal(host: string): boolean {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(host) || /^\d+$/.test(host) || /^0x[0-9a-f]+$/i.test(host);
}

function isPrivateOrBlockedHost(rawHost: string): boolean {
  const host = rawHost.replace(/^\[|\]$/g, "").toLowerCase();
  if (!host) return true;
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host.endsWith(".internal") ||
    host.endsWith(".localdomain") ||
    host === "metadata" ||
    host === "metadata.google.internal"
  ) {
    return true;
  }
  if (host.includes(":")) return true;
  if (isIpv4Literal(host)) return true;
  if (!host.includes(".")) return true;
  return false;
}

function validateExternalEndpoint(rawUrl: string): string {
  const trimmed = rawUrl.trim();
  if (!trimmed) throw new Error("HTTPS PHP Hosting endpoint URL is required.");
  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    throw new Error("Invalid PHP Hosting endpoint URL.");
  }
  if (parsed.protocol !== "https:") {
    throw new Error("Hosting API endpoint must strictly use HTTPS.");
  }
  if (parsed.username || parsed.password) {
    throw new Error("Hosting endpoint URL must not embed credentials.");
  }
  if (isPrivateOrBlockedHost(parsed.hostname)) {
    throw new Error(`Blocked or private host "${parsed.hostname}" is not permitted.`);
  }
  return parsed.toString();
}

async function hmacSha256Hex(secret: string, message: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function fetchProviderSecret(providerId: string): Promise<string> {
  const cleanId = providerId.replace(/[^a-zA-Z0-9_-]/g, "_");
  const envSpecific = Deno.env.get(`HOSTING_SECRET_${cleanId.toUpperCase()}`) || "";
  if (envSpecific.trim()) return envSpecific.trim();

  if (cleanId) {
    const resp = await supabaseRequest(
      `/rest/v1/hosting_provider_secrets?provider_id=eq.${encodeURIComponent(providerId)}&select=api_secret&limit=1`
    ).catch(() => null);
    if (resp && resp.ok) {
      const rows = await resp.json().catch(() => []);
      if (Array.isArray(rows) && rows[0]?.api_secret) {
        return String(rows[0].api_secret).trim();
      }
    }
  }
  return (Deno.env.get("PHP_HOSTING_DEFAULT_SECRET") || "").trim();
}

async function upsertProviderSecret(providerId: string, apiSecret: string, adminUid: string): Promise<void> {
  const resp = await supabaseRequest("/rest/v1/hosting_provider_secrets?on_conflict=provider_id", {
    method: "POST",
    headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
    body: JSON.stringify({
      provider_id: providerId.slice(0, 128),
      auth_mode: "BEARER_OR_HMAC",
      api_secret: apiSecret.trim(),
      updated_by_uid: adminUid,
      updated_at: new Date().toISOString()
    })
  });
  if (!resp || !resp.ok) {
    const errText = resp ? await resp.text().catch(() => "") : "SUPABASE_SERVICE_ROLE_KEY missing";
    throw new Error(`Could not save server secret: ${errText.slice(0, 180)}`);
  }
}

async function fetchProviderFromSupabase(providerId: string): Promise<{
  endpointUrl: string;
  publicMediaBaseUrl: string;
  dbEnabled: boolean;
  dbEngine: string;
} | null> {
  try {
    // 1. Check storage_providers table directly
    const provResp = await supabaseRequest(
      `/rest/v1/storage_providers?provider_id=eq.${encodeURIComponent(providerId)}&select=provider_id,endpoint_url,proxy_upload_url,public_media_base_url,provider_metadata,db_enabled,db_engine&limit=1`
    );
    if (provResp && provResp.ok) {
      const rows = await provResp.json().catch(() => []);
      if (Array.isArray(rows) && rows[0]) {
        const row = rows[0] as Record<string, unknown>;
        const meta = (row.provider_metadata || {}) as Record<string, unknown>;
        const ep = String(meta.uploadApiUrl || row.endpoint_url || "").trim();
        if (ep) {
          return {
            endpointUrl: ep,
            publicMediaBaseUrl: String(row.public_media_base_url || row.endpoint_url || "").trim(),
            dbEnabled: Boolean(row.db_enabled),
            dbEngine: String(row.db_engine || "MYSQL")
          };
        }
      }
    }

    // 2. Fallback to app_settings/storage_config payload.providers
    const cfgResp = await supabaseRequest(
      `/rest/v1/app_settings?setting_id=eq.storage_config&select=payload&limit=1`
    );
    if (cfgResp && cfgResp.ok) {
      const rows = await cfgResp.json().catch(() => []);
      const payload = (rows?.[0]?.payload || {}) as Record<string, unknown>;
      let list: unknown[] = [];
      if (Array.isArray(payload.providers)) list = payload.providers;
      else if (typeof payload.providersJson === "string" && payload.providersJson.trim()) {
        list = JSON.parse(payload.providersJson);
      }
      const matched = list.find((p) => String((p as Record<string, unknown>).providerId) === providerId) as Record<string, unknown> | undefined;
      if (matched) {
        return {
          endpointUrl: String(matched.uploadApiUrl || matched.endpointUrl || "").trim(),
          publicMediaBaseUrl: String(matched.publicMediaBaseUrl || matched.endpointUrl || "").trim(),
          dbEnabled: Boolean(matched.dbEnabled),
          dbEngine: String(matched.dbEngine || "MYSQL")
        };
      }
    }
    return null;
  } catch {
    return null;
  }
}

function buildPhpApiUrl(rawEndpoint: string, action: string, extraQuery = ""): string {
  const safeBase = validateExternalEndpoint(rawEndpoint).replace(/\/+$/, "");
  const hasPhpFile = /\.php$/i.test(safeBase);
  const scriptUrl = hasPhpFile ? safeBase : `${safeBase}/index.php`;
  const sep = scriptUrl.includes("?") ? "&" : "?";
  return `${scriptUrl}${sep}action=${encodeURIComponent(action)}${extraQuery ? "&" + extraQuery : ""}`;
}

async function callPhpHostingEndpoint(params: {
  endpointUrl: string;
  phpAction: string;
  secret: string;
  method?: "GET" | "POST";
  extraQuery?: string;
  jsonBody?: Record<string, unknown>;
}): Promise<{ status: number; ok: boolean; data: Record<string, unknown> }> {
  const targetUrl = buildPhpApiUrl(params.endpointUrl, params.phpAction, params.extraQuery || "");
  const ts = String(Math.floor(Date.now() / 1000));
  const sig = await hmacSha256Hex(params.secret, `${ts}|${params.phpAction}`);
  const headers: Record<string, string> = {
    Authorization: `Bearer ${params.secret}`,
    "X-RepairPro-Timestamp": ts,
    "X-RepairPro-Signature": sig
  };
  if (params.jsonBody) {
    headers["Content-Type"] = "application/json";
  }
  const resp = await fetch(targetUrl, {
    method: params.method || (params.jsonBody ? "POST" : "GET"),
    redirect: "error",
    signal: AbortSignal.timeout(25_000),
    headers,
    ...(params.jsonBody ? { body: JSON.stringify(params.jsonBody) } : {})
  });
  const data = await resp.json().catch(() => ({}));
  return {
    status: resp.status,
    ok: resp.ok && Boolean(data?.ok),
    data: (typeof data === "object" && data !== null ? data : {}) as Record<string, unknown>
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return jsonResponse(405, { ok: false, errorCode: "METHOD_NOT_ALLOWED", message: "Use POST." });
  }

  try {
    const authHeader = req.headers.get("authorization") || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    if (!idToken) {
      return jsonResponse(401, { ok: false, errorCode: "MISSING_AUTH_TOKEN", message: "Firebase Bearer token required." });
    }
    const caller = await verifyFirebaseIdToken(idToken);
    const body = await req.json();
    const action = String(body?.action || "upload").toLowerCase();
    const providerId = String(body?.providerId || "").trim().slice(0, 128);

    // 1. Admin-only secret storage (never echoes secret back!)
    if (action === "save_secret") {
      const admin = await isAuthorizedAdmin(caller);
      if (!admin) return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Super Admin access required." });
      const apiSecret = String(body?.apiSecret || "").trim();
      if (!providerId || apiSecret.length < 16) {
        return jsonResponse(400, { ok: false, errorCode: "VALIDATION_ERROR", message: "providerId and strong apiSecret (>=16 chars) required." });
      }
      await upsertProviderSecret(providerId, apiSecret, caller.uid);
      return jsonResponse(200, { ok: true, providerId, message: "Hosting API secret stored securely in Supabase backend vault." });
    }

    // 2. Admin-only hosting & external DB connection diagnostics / setup / listing
    if (action === "test_connection" || action === "list_files" || action === "db_health" || action === "db_init_schema") {
      const admin = await isAuthorizedAdmin(caller);
      if (!admin) return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Super Admin access required." });

      let endpointUrl = String(body?.uploadApiUrl || body?.endpointUrl || "").trim();
      if (!endpointUrl && providerId) {
        const prov = await fetchProviderFromSupabase(providerId);
        if (prov?.endpointUrl) endpointUrl = prov.endpointUrl;
      }
      endpointUrl = validateExternalEndpoint(endpointUrl);

      const overrideSecret = String(body?.tempApiSecret || "").trim();
      const secret = overrideSecret || await fetchProviderSecret(providerId);
      if (!secret) {
        return jsonResponse(400, {
          ok: false,
          errorCode: "SECRET_MISSING",
          message: "No backend hosting secret found for this provider. Save the PHP config.php secret first."
        });
      }

      const phpAction = action === "test_connection" ? "health" : action === "list_files" ? "list" : action;
      const bucket = String(body?.bucketName || "community-photos").replace(/[^a-zA-Z0-9_-]/g, "");
      const res = await callPhpHostingEndpoint({
        endpointUrl,
        phpAction,
        secret,
        method: action === "db_init_schema" ? "POST" : "GET",
        extraQuery: phpAction === "list" ? `bucket=${encodeURIComponent(bucket)}` : "",
        jsonBody: action === "db_init_schema" ? { initializedByUid: caller.uid } : undefined
      });
      if (!res.ok) {
        return jsonResponse(res.status >= 400 ? res.status : 502, {
          ok: false,
          errorCode: res.data.errorCode || "HOSTING_CHECK_FAILED",
          message: res.data.message || `PHP Hosting returned HTTP ${res.status}`
        });
      }
      return jsonResponse(200, res.data);
    }

    // 3. External SQL Database CRUD Proxy (authenticated with table & ownership checks)
    if (action === "db_query" || action === "db_upsert" || action === "db_update" || action === "db_delete") {
      const table = String(body?.table || "").trim();
      if (!ALLOWED_EXTERNAL_DB_TABLES.has(table)) {
        return jsonResponse(400, { ok: false, errorCode: "INVALID_TABLE", message: `Table '${table}' is not allowed on external DB proxy.` });
      }
      const admin = await isAuthorizedAdmin(caller);
      if (action !== "db_query") {
        if (!admin) {
          if (await isCallerAccountBlocked(caller)) {
            return jsonResponse(403, { ok: false, errorCode: "ACCOUNT_RESTRICTED", message: "Account is restricted." });
          }
          if (!USER_WRITABLE_DB_TABLES.has(table)) {
            return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: `Only admins may modify ${table}.` });
          }
          const rec = (body?.record || {}) as Record<string, unknown>;
          if (table === "community_posts" && String(rec.author_uid || rec.authorUid || caller.uid) !== caller.uid && action === "db_upsert") {
            return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Cannot author post for another UID." });
          }
          if (table === "community_posts" && (action === "db_upsert" || action === "db_update")) {
            const hasPhoto = Boolean(String(rec.photo_url || "").trim()) || (Array.isArray(rec.photo_urls) && rec.photo_urls.length > 0);
            if (hasPhoto && await isCallerUploadBlocked(caller)) {
              return jsonResponse(403, { ok: false, errorCode: "UPLOAD_RESTRICTED", message: "Photo uploads are disabled for your account; text-only posts are still allowed." });
            }
          }
          if (table === "problem_reports" && String(rec.user_id || rec.userId || caller.uid) !== caller.uid && action === "db_upsert") {
            return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Cannot submit report for another UID." });
          }
        }
      }

      let endpointUrl = String(body?.uploadApiUrl || body?.endpointUrl || "").trim();
      if (!endpointUrl && providerId) {
        const prov = await fetchProviderFromSupabase(providerId);
        if (prov?.endpointUrl) endpointUrl = prov.endpointUrl;
      }
      endpointUrl = validateExternalEndpoint(endpointUrl);
      const secret = await fetchProviderSecret(providerId);
      if (!secret) {
        return jsonResponse(503, { ok: false, errorCode: "HOSTING_SECRET_NOT_CONFIGURED", message: "Backend hosting secret not configured." });
      }

      const phpPayload: Record<string, unknown> = {
        table,
        actorUid: caller.uid,
        isAdmin: admin,
        recordId: String(body?.recordId || "").trim(),
        limit: Math.min(200, Math.max(1, Number(body?.limit || 80))),
        offset: Math.max(0, Number(body?.offset || 0)),
        filters: typeof body?.filters === "object" && body?.filters !== null ? body.filters : {},
        record: typeof body?.record === "object" && body?.record !== null ? body.record : {}
      };
      // Enforce caller UID and non-admin moderation invariants
      if (!admin && (action === "db_upsert" || action === "db_update") && typeof phpPayload.record === "object") {
        const rec = phpPayload.record as Record<string, unknown>;
        if (table === "community_posts") {
          rec.author_uid = caller.uid;
          rec.approval_status = "PENDING";
          delete rec.is_pinned;
          delete rec.is_hidden;
        }
        if (table === "community_comments") rec.author_uid = caller.uid;
        if (table === "community_likes" || table === "community_bookmarks" || table === "problem_reports" || table === "saved_guides" || table === "user_profiles" || table === "technician_verification_requests") {
          rec.user_id = caller.uid;
        }
        if (table === "community_reports") rec.reporter_uid = caller.uid;
      }

      const res = await callPhpHostingEndpoint({
        endpointUrl,
        phpAction: action,
        secret,
        method: "POST",
        jsonBody: phpPayload
      });
      if (!res.ok) {
        return jsonResponse(res.status >= 400 ? res.status : 502, {
          ok: false,
          errorCode: res.data.errorCode || "EXTERNAL_DB_ERROR",
          message: res.data.message || `External DB proxy returned HTTP ${res.status}`
        });
      }
      return jsonResponse(200, { ...res.data, providerId });
    }

    // 4. Delete hosted media file (owner or admin)
    if (action === "delete_file") {
      const admin = await isAuthorizedAdmin(caller);
      const storagePath = String(body?.storagePath || "").trim();
      const isOwner = Boolean(caller.uid && (storagePath.includes(`/${caller.uid}/`) || storagePath.startsWith(`${caller.uid}/`)));
      if (!admin && !isOwner) {
        return jsonResponse(403, { ok: false, errorCode: "FORBIDDEN", message: "Owner or Super Admin access required." });
      }
      let endpointUrl = String(body?.uploadApiUrl || body?.endpointUrl || "").trim();
      if (!endpointUrl && providerId) {
        const prov = await fetchProviderFromSupabase(providerId);
        if (prov?.endpointUrl) endpointUrl = prov.endpointUrl;
      }
      endpointUrl = validateExternalEndpoint(endpointUrl);
      const secret = await fetchProviderSecret(providerId);
      if (!storagePath || !secret) {
        return jsonResponse(400, { ok: false, errorCode: "INVALID_REQUEST", message: "Endpoint, storagePath, and backend secret are required." });
      }
      const res = await callPhpHostingEndpoint({
        endpointUrl,
        phpAction: "delete",
        secret,
        method: "POST",
        jsonBody: { storagePath }
      });
      return jsonResponse(res.status, res.data);
    }

    // 5. Default: authenticated user/admin upload forwarding to PHP Shared Hosting (supports Images & PDFs)
    if (await isCallerUploadBlocked(caller)) {
      return jsonResponse(403, {
        ok: false,
        errorCode: "UPLOAD_RESTRICTED",
        message: "Uploads are disabled for your account by an administrator."
      });
    }

    const bucketName = String(body?.bucketName || "community-photos").replace(/[^a-zA-Z0-9_-]/g, "");
    const objectPath = String(body?.objectPath || "").trim();
    const base64Data = String(body?.base64 || "").trim();
    const mimeType = String(body?.mimeType || "").trim().toLowerCase();
    let endpointUrl = String(body?.uploadApiUrl || body?.endpointUrl || "").trim();

    if (!endpointUrl && providerId) {
      const prov = await fetchProviderFromSupabase(providerId);
      if (prov?.endpointUrl) endpointUrl = prov.endpointUrl;
    }
    endpointUrl = validateExternalEndpoint(endpointUrl);

    if (!objectPath || !base64Data) {
      return jsonResponse(400, {
        ok: false,
        errorCode: "INVALID_UPLOAD_PAYLOAD",
        message: "HTTPS endpointUrl, objectPath, and base64 file data are required."
      });
    }
    const maxBase64Len = mimeType === "application/pdf" || objectPath.toLowerCase().endsWith(".pdf") ? 28_000_000 : 8_000_000;
    if (base64Data.length > maxBase64Len) {
      return jsonResponse(413, { ok: false, errorCode: "FILE_TOO_LARGE", message: "File exceeds proxy upload size limit." });
    }

    const secret = await fetchProviderSecret(providerId);
    if (!secret) {
      return jsonResponse(503, {
        ok: false,
        errorCode: "HOSTING_SECRET_NOT_CONFIGURED",
        message: "Hosting API secret is not configured in Supabase secret store yet."
      });
    }

    const res = await callPhpHostingEndpoint({
      endpointUrl,
      phpAction: "upload",
      secret,
      method: "POST",
      jsonBody: {
        bucket: bucketName,
        objectPath,
        base64: base64Data,
        mimeType,
        uploadedByUid: caller.uid
      }
    });

    if (!res.ok || !res.data.publicUrl) {
      return jsonResponse(res.status >= 400 ? res.status : 502, {
        ok: false,
        errorCode: res.data.errorCode || "PHP_UPLOAD_FAILED",
        message: res.data.message || `Shared hosting upload returned HTTP ${res.status}`
      });
    }

    return jsonResponse(200, {
      ok: true,
      providerId,
      bucketName: res.data.bucketName || bucketName,
      storagePath: res.data.storagePath || `${bucketName}/${objectPath}`,
      publicUrl: res.data.publicUrl,
      deduplicated: Boolean(res.data.deduplicated),
      sizeBytes: Number(res.data.sizeBytes || 0)
    });
  } catch (err) {
    return jsonResponse(500, {
      ok: false,
      errorCode: "INTERNAL_ERROR",
      message: err instanceof Error ? err.message : "Hosting proxy error"
    });
  }
});
