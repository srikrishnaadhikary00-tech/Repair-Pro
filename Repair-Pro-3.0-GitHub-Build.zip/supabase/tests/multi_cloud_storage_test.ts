import assert from "node:assert/strict";
import test from "node:test";
import {
  type AdapterDeps,
  createSignedReadUrl,
  hasServerSecretConfigured,
  normalizeCanonicalProviderType,
  sha256Hex,
  StorageAdapterError,
  type StorageProviderConfig,
  testProviderConnection,
  uploadObject
} from "../functions/_shared/storage-adapters.ts";
import {
  deleteStorageProviderSafe,
  type ErrorLogInsert,
  type FileRegistryRow,
  migrateProviderFiles,
  mintAdminSignedVerificationUrl,
  type StorageRepository,
  uploadWithFailover
} from "../functions/_shared/storage-manager.ts";

interface MockRemoteRequest {
  url: string;
  method: string;
  headers: Record<string, string>;
}

class InMemoryMultiCloudSim {
  objects = new Map<string, { bytes: Uint8Array; contentType: string }>();
  requests: MockRemoteRequest[] = [];
  forceStatusByHost = new Map<string, number>();
  corruptReadBackForProviderHost = new Set<string>();
  env: Record<string, string> = {};

  providers: StorageProviderConfig[] = [];
  files: FileRegistryRow[] = [];
  repairDocs: Array<{ id: string; storage_file_id: string; file_url: string; storage_provider_id: string }> = [];
  errorLogs: ErrorLogInsert[] = [];
  globalAutoFailover = true;

  getEnv = (key: string): string | undefined => this.env[key];

  private hostKey(urlStr: string): string {
    return new URL(urlStr).hostname.toLowerCase();
  }

  private normalizeHeaders(init?: RequestInit): Record<string, string> {
    const out: Record<string, string> = {};
    const h = init?.headers;
    if (!h) return out;
    if (h instanceof Headers) {
      h.forEach((v, k) => {
        out[k.toLowerCase()] = v;
      });
    } else if (Array.isArray(h)) {
      for (const [k, v] of h) out[k.toLowerCase()] = v;
    } else {
      for (const [k, v] of Object.entries(h)) out[k.toLowerCase()] = String(v);
    }
    return out;
  }

  private async bodyToBytes(body?: BodyInit | null): Promise<Uint8Array> {
    if (!body) return new Uint8Array(0);
    if (body instanceof Uint8Array) return new Uint8Array(body);
    if (typeof body === "string") return new TextEncoder().encode(body);
    if (body instanceof ArrayBuffer) return new Uint8Array(body);
    return new Uint8Array(0);
  }

  fetchFn: AdapterDeps["fetchFn"] = async (input, init) => {
    const urlStr = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    const method = (init?.method || "GET").toUpperCase();
    const headers = this.normalizeHeaders(init);
    this.requests.push({ url: urlStr, method, headers });

    const parsed = new URL(urlStr);
    const host = this.hostKey(urlStr);
    const forced = this.forceStatusByHost.get(host);
    if (forced !== undefined) {
      return new Response(JSON.stringify({ error: `Forced HTTP ${forced}` }), { status: forced });
    }

    // --- SUPABASE STORAGE MOCK ---
    if (host.endsWith(".supabase.co")) {
      const auth = headers["authorization"] || "";
      if (!auth.startsWith("Bearer ") || !headers["apikey"]) {
        return new Response("Unauthorized", { status: 401 });
      }
      if (parsed.pathname === "/storage/v1/bucket" && method === "GET") {
        return new Response(
          JSON.stringify([
            { id: "community-photos" },
            { id: "repair-pdfs" },
            { id: "circuit-diagrams" },
            { id: "technician-photos" },
            { id: "verification-documents" }
          ]),
          { status: 200 }
        );
      }
      if (parsed.pathname.startsWith("/storage/v1/object/sign/") && method === "POST") {
        const tail = parsed.pathname.slice("/storage/v1/object/sign/".length);
        return new Response(
          JSON.stringify({ signedURL: `/storage/v1/object/sign/${tail}?token=supa-signed-120s` }),
          { status: 200 }
        );
      }
      if (parsed.pathname.startsWith("/storage/v1/object/authenticated/") && method === "GET") {
        const key = `${host}:${parsed.pathname.slice("/storage/v1/object/authenticated/".length)}`;
        const stored = this.objects.get(key);
        if (!stored) return new Response("Not Found", { status: 404 });
        const bytes = this.corruptReadBackForProviderHost.has(host)
          ? new Uint8Array([...stored.bytes.slice(0, -1), stored.bytes[stored.bytes.length - 1] ^ 0xff])
          : stored.bytes;
        return new Response(bytes, { status: 200 });
      }
      if (parsed.pathname.startsWith("/storage/v1/object/")) {
        const key = `${host}:${parsed.pathname.slice("/storage/v1/object/".length)}`;
        if (method === "POST" || method === "PUT") {
          const bytes = await this.bodyToBytes(init?.body);
          this.objects.set(key, { bytes, contentType: headers["content-type"] || "application/octet-stream" });
          return new Response(JSON.stringify({ Key: key }), { status: 200 });
        }
        if (method === "DELETE") {
          this.objects.delete(key);
          return new Response(JSON.stringify({ deleted: true }), { status: 200 });
        }
      }
    }

    // --- BACKBLAZE B2 NATIVE API v2 MOCK ---
    if (host === "api.backblazeb2.com" || host === "api004.backblazeb2.com" || host === "f004.backblazeb2.com") {
      if (parsed.pathname === "/b2api/v2/b2_authorize_account") {
        if (!headers["authorization"]?.startsWith("Basic ")) return new Response("Unauthorized", { status: 401 });
        return new Response(
          JSON.stringify({
            accountId: "acc-b2-123",
            authorizationToken: "b2-auth-token-xyz",
            apiUrl: "https://api004.backblazeb2.com",
            downloadUrl: "https://f004.backblazeb2.com"
          }),
          { status: 200 }
        );
      }
      if (parsed.pathname === "/b2api/v2/b2_list_buckets") {
        if (headers["authorization"] !== "b2-auth-token-xyz") return new Response("Unauthorized", { status: 401 });
        return new Response(
          JSON.stringify({ buckets: [{ bucketId: "b2-bucket-id-1", bucketName: "repair-pro-b2" }] }),
          { status: 200 }
        );
      }
      if (parsed.pathname === "/b2api/v2/b2_get_upload_url") {
        if (headers["authorization"] !== "b2-auth-token-xyz") return new Response("Unauthorized", { status: 401 });
        return new Response(
          JSON.stringify({
            uploadUrl: "https://api004.backblazeb2.com/b2api/v2/b2_upload_target",
            authorizationToken: "b2-upload-token-1"
          }),
          { status: 200 }
        );
      }
      if (parsed.pathname === "/b2api/v2/b2_upload_target" && method === "POST") {
        if (headers["authorization"] !== "b2-upload-token-1" || !headers["x-bz-content-sha1"]) {
          return new Response("Unauthorized", { status: 401 });
        }
        const fileName = decodeURIComponent(headers["x-bz-file-name"] || "");
        const bytes = await this.bodyToBytes(init?.body);
        this.objects.set(`b2:${fileName}`, { bytes, contentType: headers["content-type"] || "application/octet-stream" });
        return new Response(JSON.stringify({ fileId: `file-${fileName}`, fileName }), { status: 200 });
      }
      if (parsed.pathname === "/b2api/v2/b2_get_download_authorization") {
        if (headers["authorization"] !== "b2-auth-token-xyz") return new Response("Unauthorized", { status: 401 });
        return new Response(JSON.stringify({ authorizationToken: "b2-dl-token-120s" }), { status: 200 });
      }
      if (parsed.pathname === "/b2api/v2/b2_list_file_versions") {
        const bodyJson = JSON.parse(String(init?.body || "{}")) as { prefix?: string };
        const fileName = bodyJson.prefix || "";
        return new Response(
          JSON.stringify({ files: this.objects.has(`b2:${fileName}`) ? [{ fileId: `file-${fileName}`, fileName }] : [] }),
          { status: 200 }
        );
      }
      if (parsed.pathname === "/b2api/v2/b2_delete_file_version") {
        const bodyJson = JSON.parse(String(init?.body || "{}")) as { fileName?: string };
        this.objects.delete(`b2:${bodyJson.fileName || ""}`);
        return new Response(JSON.stringify({ deleted: true }), { status: 200 });
      }
      if (parsed.pathname.startsWith("/file/") && method === "GET") {
        const afterFile = parsed.pathname.slice("/file/".length);
        const slash = afterFile.indexOf("/");
        const key = decodeURIComponent(afterFile.slice(slash + 1));
        const stored = this.objects.get(`b2:${key}`);
        if (!stored) return new Response("Not Found", { status: 404 });
        return new Response(stored.bytes, { status: 200 });
      }
    }

    // --- CLOUDFLARE R2 / B2 S3 / CUSTOM S3 (SIGV4) MOCK ---
    const auth = headers["authorization"] || "";
    if (!auth.startsWith("AWS4-HMAC-SHA256 Credential=") || !headers["x-amz-date"] || !headers["x-amz-content-sha256"]) {
      return new Response("Missing AWS SigV4 signature", { status: 403 });
    }
    if (parsed.searchParams.get("list-type") === "2" && method === "GET") {
      return new Response("<ListBucketResult><Name>ok</Name></ListBucketResult>", { status: 200 });
    }
    const objKey = `${host}:${decodeURIComponent(parsed.pathname)}`;
    if (method === "PUT") {
      const bytes = await this.bodyToBytes(init?.body);
      this.objects.set(objKey, { bytes, contentType: headers["content-type"] || "application/octet-stream" });
      return new Response("", { status: 200 });
    }
    if (method === "GET") {
      const stored = this.objects.get(objKey);
      if (!stored) return new Response("Not Found", { status: 404 });
      const bytes = this.corruptReadBackForProviderHost.has(host)
        ? new Uint8Array(stored.bytes.map((b, idx) => (idx === 0 ? b ^ 0xff : b)))
        : stored.bytes;
      return new Response(bytes, { status: 200 });
    }
    if (method === "DELETE") {
      this.objects.delete(objKey);
      return new Response("", { status: 204 });
    }
    return new Response("Unhandled mock endpoint", { status: 404 });
  };

  deps(): AdapterDeps {
    return { getEnv: this.getEnv, fetchFn: this.fetchFn };
  }

  repo(): StorageRepository {
    const sim = this;
    return {
      async listEnabledProviders() {
        return sim.providers
          .filter((p) => p.is_enabled)
          .sort((a, b) => {
            if (a.is_primary !== b.is_primary) return a.is_primary ? -1 : 1;
            if (a.is_backup !== b.is_backup) return a.is_backup ? -1 : 1;
            return a.priority_order - b.priority_order;
          });
      },
      async listAllProviders() {
        return [...sim.providers];
      },
      async getProviderById(id: string) {
        return sim.providers.find((p) => p.id === id) || null;
      },
      async getAutoFailoverSetting() {
        return sim.globalAutoFailover;
      },
      async updateProviderUsage(providerId: string, usedBytes: number) {
        const p = sim.providers.find((x) => x.id === providerId);
        if (p) p.used_bytes = Math.max(0, usedBytes);
      },
      async updateProviderTestResult(providerId: string, status: string, message: string) {
        const p = sim.providers.find((x) => x.id === providerId);
        if (p) {
          p.last_test_status = status;
          p.last_test_message = message;
        }
      },
      async countProviderActiveFiles(providerId: string) {
        return sim.files.filter((f) => f.provider_id === providerId).length;
      },
      async getActiveFileCountsByProvider() {
        const counts: Record<string, number> = {};
        for (const f of sim.files) {
          if (f.provider_id) counts[f.provider_id] = (counts[f.provider_id] || 0) + 1;
        }
        return counts;
      },
      async listProviderFiles(providerId: string, limit: number) {
        return sim.files.filter((f) => f.provider_id === providerId).slice(0, limit);
      },
      async findFileByObjectPath(objectPath: string) {
        return sim.files.find((f) => f.object_path === objectPath) || null;
      },
      async insertRegistryFile(entry) {
        const row: FileRegistryRow = {
          ...entry,
          id: `file-${sim.files.length + 1}`,
          created_at: new Date().toISOString()
        };
        sim.files.push(row);
        return row;
      },
      async updateRegistryFileAfterMigration(fileId, patch) {
        const f = sim.files.find((x) => x.id === fileId);
        if (f) {
          f.provider_id = patch.provider_id;
          f.public_url = patch.public_url;
          f.sha256_checksum = patch.sha256_checksum;
          f.migrated_from_provider_id = patch.migrated_from_provider_id;
          f.migrated_at = patch.migrated_at;
        }
      },
      async updateRepairDocumentsAfterMigration(storageFileId, newFileUrl, newProviderId) {
        for (const doc of sim.repairDocs) {
          if (doc.storage_file_id === storageFileId) {
            doc.file_url = newFileUrl;
            doc.storage_provider_id = newProviderId;
          }
        }
      },
      async deleteProviderRow(providerId: string) {
        // Mirror the Postgres BEFORE DELETE trigger guard as well
        const active = sim.files.filter((f) => f.provider_id === providerId).length;
        if (active > 0) {
          throw new Error(`PROVIDER_HAS_ACTIVE_FILES: ${active} files remain`);
        }
        sim.providers = sim.providers.filter((p) => p.id !== providerId);
      },
      async insertErrorLog(entry) {
        sim.errorLogs.push(entry);
      }
    };
  }
}

function makeSupabaseProvider(overrides: Partial<StorageProviderConfig> = {}): StorageProviderConfig {
  return {
    id: "prov-supa",
    name: "Supabase Primary",
    provider_type: "SUPABASE",
    endpoint_url: "https://xuakzzjtcgcvudkgxpbd.supabase.co",
    project_ref: "xuakzzjtcgcvudkgxpbd",
    region: "auto",
    secret_env_key: "SUPABASE_SERVICE_ROLE_KEY",
    is_primary: true,
    is_backup: false,
    is_enabled: true,
    priority_order: 1,
    capacity_bytes: 1_000_000,
    used_bytes: 0,
    auto_failover_enabled: true,
    ...overrides
  };
}

function makeR2Provider(overrides: Partial<StorageProviderConfig> = {}): StorageProviderConfig {
  return {
    id: "prov-r2",
    name: "Cloudflare R2 Backup",
    provider_type: "CLOUDFLARE_R2",
    endpoint_url: "https://acct123.r2.cloudflarestorage.com",
    project_ref: "repair-pro-r2",
    region: "auto",
    public_base_url: "https://cdn.repairpro.example.com",
    secret_env_key: "R2_STORAGE_CREDS",
    is_primary: false,
    is_backup: true,
    is_enabled: true,
    priority_order: 2,
    capacity_bytes: 5_000_000,
    used_bytes: 0,
    auto_failover_enabled: true,
    ...overrides
  };
}

function makeB2NativeProvider(overrides: Partial<StorageProviderConfig> = {}): StorageProviderConfig {
  return {
    id: "prov-b2",
    name: "Backblaze B2 Native",
    provider_type: "BACKBLAZE_B2",
    endpoint_url: "https://api.backblazeb2.com",
    project_ref: "repair-pro-b2",
    region: "us-west-004",
    secret_env_key: "B2_STORAGE_CREDS",
    is_primary: false,
    is_backup: true,
    is_enabled: true,
    priority_order: 3,
    capacity_bytes: 5_000_000,
    used_bytes: 0,
    auto_failover_enabled: true,
    ...overrides
  };
}

function makeCustomS3Provider(overrides: Partial<StorageProviderConfig> = {}): StorageProviderConfig {
  return {
    id: "prov-s3",
    name: "Amazon S3 Backup",
    provider_type: "CUSTOM_S3",
    endpoint_url: "https://s3.us-east-1.amazonaws.com",
    project_ref: "repair-pro-s3",
    region: "us-east-1",
    secret_env_key: "S3_STORAGE_CREDS",
    is_primary: false,
    is_backup: false,
    is_enabled: true,
    priority_order: 4,
    capacity_bytes: 5_000_000,
    used_bytes: 0,
    auto_failover_enabled: true,
    ...overrides
  };
}

function seedAllSecrets(sim: InMemoryMultiCloudSim) {
  sim.env.SUPABASE_SERVICE_ROLE_KEY = "sb-service-role-secret";
  sim.env.R2_STORAGE_CREDS = JSON.stringify({
    accessKeyId: "r2-ak-id",
    secretAccessKey: "r2-secret-key",
    region: "auto"
  });
  sim.env.B2_STORAGE_CREDS = JSON.stringify({
    keyId: "b2-key-id",
    applicationKey: "b2-app-key"
  });
  sim.env.S3_STORAGE_CREDS_ACCESS_KEY_ID = "aws-ak-id";
  sim.env.S3_STORAGE_CREDS_SECRET_ACCESS_KEY = "aws-secret-key";
}

test("provider type normalization rejects unsupported providers such as CLOUDINARY", () => {
  assert.equal(normalizeCanonicalProviderType("r2"), "CLOUDFLARE_R2");
  assert.equal(normalizeCanonicalProviderType("b2"), "BACKBLAZE_B2");
  assert.equal(normalizeCanonicalProviderType("s3_compatible"), "CUSTOM_S3");
  assert.throws(() => normalizeCanonicalProviderType("CLOUDINARY"), (err: unknown) => {
    return err instanceof StorageAdapterError && err.code === "UNSUPPORTED_PROVIDER_TYPE";
  });
});

test("all four storage adapters authenticate properly and testProviderConnection verifies health and 401/403", async () => {
  const sim = new InMemoryMultiCloudSim();
  seedAllSecrets(sim);
  const providers = [
    makeSupabaseProvider(),
    makeR2Provider(),
    makeB2NativeProvider(),
    makeCustomS3Provider()
  ];
  for (const p of providers) {
    assert.equal(hasServerSecretConfigured(p, sim.getEnv), true, `${p.provider_type} secret missing`);
    const res = await testProviderConnection(p, sim.deps());
    assert.equal(res.connected, true, `${p.provider_type} failed testConnection: ${res.message}`);
    assert.equal(res.status, "CONNECTED");
  }

  // Verify SigV4 authorization header was sent for R2 and S3
  const r2Req = sim.requests.find((r) => r.url.includes("r2.cloudflarestorage.com"));
  assert.ok(r2Req);
  assert.match(r2Req.headers["authorization"], /^AWS4-HMAC-SHA256 Credential=r2-ak-id\/\d{8}\/auto\/s3\/aws4_request/);

  // Verify 401/403 surfaces as AUTH_ERROR cleanly
  sim.forceStatusByHost.set("s3.us-east-1.amazonaws.com", 403);
  const failedS3 = await testProviderConnection(makeCustomS3Provider(), sim.deps());
  assert.equal(failedS3.connected, false);
  assert.equal(failedS3.status, "AUTH_ERROR");
  assert.equal(failedS3.httpStatus, 403);
});

test("primary capacity limit triggers automatic failover to enabled backup without APK change", async () => {
  const sim = new InMemoryMultiCloudSim();
  seedAllSecrets(sim);
  const primary = makeSupabaseProvider({ capacity_bytes: 100, used_bytes: 95 });
  const backupR2 = makeR2Provider({ is_backup: true, capacity_bytes: 10_000, used_bytes: 0 });
  sim.providers = [primary, backupR2];

  const payload = new TextEncoder().encode("PDF-BYTES-FOR-REPAIR-MANUAL-123456");
  const uploaded = await uploadWithFailover({
    repo: sim.repo(),
    deps: sim.deps(),
    uploaderUid: "admin-uid-1",
    bucketName: "repair-pdfs",
    originalFilename: "daikin-vrv.pdf",
    mimeType: "application/pdf",
    bytes: payload
  });

  assert.equal(uploaded.failoverUsed, true);
  assert.equal(uploaded.providerId, "prov-r2");
  assert.match(uploaded.publicUrl, /^https:\/\/cdn\.repairpro\.example\.com\//);
  assert.equal(backupR2.used_bytes, payload.byteLength);
  assert.ok(sim.errorLogs.some((e) => e.operation === "UPLOAD_CAPACITY_CHECK" && e.http_status === 507));
  assert.ok(sim.errorLogs.some((e) => e.operation === "FAILOVER_SUCCEEDED" && e.failed_over_to_provider_id === "prov-r2"));

  // When auto_failover_enabled is false, capacity overflow must reject with 507 and NOT fail over
  primary.auto_failover_enabled = false;
  await assert.rejects(
    () =>
      uploadWithFailover({
        repo: sim.repo(),
        deps: sim.deps(),
        uploaderUid: "admin-uid-1",
        bucketName: "repair-pdfs",
        originalFilename: "fail.pdf",
        mimeType: "application/pdf",
        bytes: payload
      }),
    (err: unknown) => err instanceof StorageAdapterError && err.status === 507 && err.code === "CAPACITY_LIMIT_REACHED"
  );
});

test("uploadWithFailover strictly NEVER bypasses 401 or 403 auth errors", async () => {
  const sim = new InMemoryMultiCloudSim();
  seedAllSecrets(sim);
  const primary = makeSupabaseProvider();
  const backupR2 = makeR2Provider();
  sim.providers = [primary, backupR2];

  sim.forceStatusByHost.set("xuakzzjtcgcvudkgxpbd.supabase.co", 401);
  await assert.rejects(
    () =>
      uploadWithFailover({
        repo: sim.repo(),
        deps: sim.deps(),
        uploaderUid: "u-1",
        bucketName: "community-photos",
        originalFilename: "ac.jpg",
        mimeType: "image/jpeg",
        bytes: new TextEncoder().encode("jpeg-bytes")
      }),
    (err: unknown) => err instanceof StorageAdapterError && err.status === 401
  );
  // Backup must not have received any upload
  assert.equal(sim.files.length, 0);
  assert.equal(backupR2.used_bytes, 0);
});

test("real file migration copies bytes, verifies SHA-256, updates linked repair_documents, rebalances quota, and unlocks safe deletion", async () => {
  const sim = new InMemoryMultiCloudSim();
  seedAllSecrets(sim);
  const supa = makeSupabaseProvider({ is_primary: true });
  const r2 = makeR2Provider({ is_primary: false, is_backup: true });
  const b2 = makeB2NativeProvider({ is_primary: false, is_backup: true });
  sim.providers = [supa, r2, b2];

  const docBytes = new TextEncoder().encode("SAMSUNG-INVERTER-SERVICE-MANUAL-CONTENT-SHA256");
  const expectedSha = await sha256Hex(docBytes);

  const up = await uploadWithFailover({
    repo: sim.repo(),
    deps: sim.deps(),
    uploaderUid: "admin-1",
    bucketName: "repair-pdfs",
    originalFilename: "samsung.pdf",
    mimeType: "application/pdf",
    bytes: docBytes
  });
  sim.repairDocs.push({
    id: "doc-1",
    storage_file_id: up.file.id,
    file_url: up.publicUrl,
    storage_provider_id: supa.id
  });

  // 1. Attempt deleting source provider BEFORE migration -> must fail with 409 PROVIDER_HAS_ACTIVE_FILES
  supa.is_primary = false;
  r2.is_primary = true;
  await assert.rejects(
    () => deleteStorageProviderSafe(sim.repo(), supa.id),
    (err: unknown) => err instanceof StorageAdapterError && err.status === 409 && err.code === "PROVIDER_HAS_ACTIVE_FILES"
  );

  // 2. Inject corruption on B2 target read-back? Wait: let's test R2 checksum mismatch first, verify source stays intact
  sim.corruptReadBackForProviderHost.add("acct123.r2.cloudflarestorage.com");
  const badMigration = await migrateProviderFiles({
    repo: sim.repo(),
    deps: sim.deps(),
    sourceProviderId: supa.id,
    targetProviderId: r2.id
  });
  assert.equal(badMigration.migratedCount, 0);
  assert.equal(badMigration.failedCount, 1);
  assert.equal(badMigration.remainingOnSource, 1);
  assert.equal(sim.files[0].provider_id, supa.id);
  assert.equal(sim.repairDocs[0].storage_provider_id, supa.id);

  // 3. Clear corruption and run real migration Supabase -> Cloudflare R2
  sim.corruptReadBackForProviderHost.clear();
  const okMigration = await migrateProviderFiles({
    repo: sim.repo(),
    deps: sim.deps(),
    sourceProviderId: supa.id,
    targetProviderId: r2.id
  });
  assert.equal(okMigration.migratedCount, 1);
  assert.equal(okMigration.failedCount, 0);
  assert.equal(okMigration.remainingOnSource, 0);
  assert.equal(okMigration.checksumVerified, true);
  assert.equal(sim.files[0].provider_id, r2.id);
  assert.equal(sim.files[0].sha256_checksum, expectedSha);
  assert.equal(sim.repairDocs[0].storage_provider_id, r2.id);
  assert.match(sim.repairDocs[0].file_url, /^https:\/\/cdn\.repairpro\.example\.com\//);
  assert.equal(supa.used_bytes, 0);
  assert.equal(r2.used_bytes, docBytes.byteLength);

  // 4. Now source provider has 0 active files and is non-primary -> safe deletion succeeds
  await deleteStorageProviderSafe(sim.repo(), supa.id);
  assert.equal(sim.providers.some((p) => p.id === supa.id), false);

  // 5. Migrate further R2 -> Backblaze B2 Native API v2
  b2.is_primary = true;
  r2.is_primary = false;
  const b2Migration = await migrateProviderFiles({
    repo: sim.repo(),
    deps: sim.deps(),
    sourceProviderId: r2.id,
    targetProviderId: b2.id
  });
  assert.equal(b2Migration.migratedCount, 1);
  assert.equal(sim.files[0].provider_id, b2.id);
  assert.match(sim.repairDocs[0].file_url, /^https:\/\/f004\.backblazeb2\.com\/file\/repair-pro-b2\//);
});

test("private verification documents never use public CDN URLs and mint 120s signed URLs across all 4 providers and post-migration", async () => {
  const sim = new InMemoryMultiCloudSim();
  seedAllSecrets(sim);
  const providers = [
    makeSupabaseProvider({ is_primary: true }),
    makeR2Provider({ is_primary: false }),
    makeB2NativeProvider({ is_primary: false }),
    makeCustomS3Provider({ is_primary: false })
  ];
  sim.providers = providers;

  // Test private upload & 120s signed URL minting on each provider independently
  for (const p of providers) {
    // Upload directly via adapter and verify private:// reference
    const bytes = new TextEncoder().encode(`ID-CARD-BYTES-${p.id}`);
    const objPath = `tech_user/${p.id}_nid.jpg`;
    const up = await uploadObject(p, "verification-documents", objPath, bytes, "image/jpeg", sim.deps());
    assert.ok(up.publicUrl.startsWith(`private://${p.id}/`), `${p.provider_type} leaked public URL: ${up.publicUrl}`);
    assert.equal(up.publicUrl.includes("cdn.repairpro.example.com"), false);

    // Record in registry
    await sim.repo().insertRegistryFile({
      provider_id: p.id,
      bucket_name: "verification-documents",
      object_path: objPath,
      public_url: up.publicUrl,
      is_private: true,
      original_filename: `${p.id}_nid.jpg`,
      mime_type: "image/jpeg",
      size_bytes: bytes.byteLength,
      uploaded_by_uid: "tech_user",
      sha256_checksum: await sha256Hex(bytes)
    });

    const signed = await mintAdminSignedVerificationUrl({
      repo: sim.repo(),
      deps: sim.deps(),
      privateUrl: up.publicUrl,
      expiresInSeconds: 120
    });
    assert.equal(signed.expiresInSeconds, 120);
    assert.match(signed.signedUrl, /^https:\/\//);

    if (p.provider_type === "CLOUDFLARE_R2" || p.provider_type === "CUSTOM_S3") {
      assert.match(signed.signedUrl, /X-Amz-Algorithm=AWS4-HMAC-SHA256/);
      assert.match(signed.signedUrl, /X-Amz-Expires=120/);
      assert.match(signed.signedUrl, /X-Amz-Signature=[0-9a-f]{64}/);
    } else if (p.provider_type === "BACKBLAZE_B2") {
      assert.match(signed.signedUrl, /Authorization=b2-dl-token-120s/);
    } else {
      assert.match(signed.signedUrl, /token=supa-signed-120s/);
    }
  }

  // Test migrating the private document from Supabase -> R2 preserves privacy & resolves signed URL via registry!
  const supaPrivateRef = sim.files[0].public_url!;
  const mig = await migrateProviderFiles({
    repo: sim.repo(),
    deps: sim.deps(),
    sourceProviderId: "prov-supa",
    targetProviderId: "prov-r2",
    limit: 1
  });
  assert.equal(mig.migratedCount, 1);
  assert.ok(sim.files[0].public_url!.startsWith("private://prov-r2/"));

  // Even if technician record still has the old private://prov-supa/... pointer, resolver finds prov-r2 & mints R2 presigned URL
  const postMigSigned = await mintAdminSignedVerificationUrl({
    repo: sim.repo(),
    deps: sim.deps(),
    privateUrl: supaPrivateRef,
    expiresInSeconds: 120
  });
  assert.match(postMigSigned.signedUrl, /^https:\/\/acct123\.r2\.cloudflarestorage\.com\//);
  assert.match(postMigSigned.signedUrl, /X-Amz-Signature=[0-9a-f]{64}/);

  // Also sanity-check direct createSignedReadUrl works for all types
  const directB2 = await createSignedReadUrl(providers[2], "repair-pro-b2", "verification-documents/tech_user/prov-b2_nid.jpg", 90, sim.deps());
  assert.equal(directB2.expiresInSeconds, 90);
});
