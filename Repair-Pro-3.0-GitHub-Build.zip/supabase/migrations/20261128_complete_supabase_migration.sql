-- Repair Pro — Complete Supabase Primary Backend Migration (Auth/FCM Only on Firebase)
-- Supabase Project Reference: xuakzzjtcgcvudkgxpbd
-- Safe & Idempotent: Preserves all existing tables, rows, buckets, and user data.
-- Run this script in Supabase Dashboard -> SQL Editor AFTER schema.sql, 20261126, and 20261127.

BEGIN;

-- =========================================================================
-- 1. ADDITIVE COLUMNS FOR USER PROFILES, MULTI-DB HOSTING & ADMIN TOOLS
-- =========================================================================
DO $$
BEGIN
  IF to_regclass('public.user_profiles') IS NOT NULL THEN
    ALTER TABLE public.user_profiles
      ADD COLUMN IF NOT EXISTS photo_url TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS photo_storage_path TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS photo_provider_id TEXT NOT NULL DEFAULT '';
  END IF;

  IF to_regclass('public.technicians') IS NOT NULL THEN
    ALTER TABLE public.technicians
      ADD COLUMN IF NOT EXISTS photo_provider_id TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS storage_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
      ADD COLUMN IF NOT EXISTS external_record_id TEXT NOT NULL DEFAULT '';
  END IF;

  IF to_regclass('public.technician_verification_requests') IS NOT NULL THEN
    ALTER TABLE public.technician_verification_requests
      ADD COLUMN IF NOT EXISTS profile_photo_provider_id TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS credential_doc_provider_id TEXT NOT NULL DEFAULT '';
  END IF;

  IF to_regclass('public.technical_documents') IS NOT NULL THEN
    ALTER TABLE public.technical_documents
      ADD COLUMN IF NOT EXISTS external_record_id TEXT NOT NULL DEFAULT '';
  END IF;

  IF to_regclass('public.community_posts') IS NOT NULL THEN
    ALTER TABLE public.community_posts
      ADD COLUMN IF NOT EXISTS storage_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
      ADD COLUMN IF NOT EXISTS external_record_id TEXT NOT NULL DEFAULT '';
  END IF;

  IF to_regclass('public.ai_error_logs') IS NOT NULL THEN
    ALTER TABLE public.ai_error_logs
      ADD COLUMN IF NOT EXISTS resolved BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();
  END IF;

  IF to_regclass('public.storage_providers') IS NOT NULL THEN
    ALTER TABLE public.storage_providers
      DROP CONSTRAINT IF EXISTS storage_providers_provider_type_check;

    ALTER TABLE public.storage_providers
      ADD CONSTRAINT storage_providers_provider_type_check
      CHECK (provider_type IN (
        'SUPABASE_STORAGE',
        'PHP_HOSTING',
        'EXTERNAL_DB',
        'S3_COMPATIBLE',
        'CLOUDFLARE_R2',
        'GOOGLE_CLOUD_STORAGE',
        'FIREBASE_LEGACY'
      ));

    ALTER TABLE public.storage_providers
      ADD COLUMN IF NOT EXISTS community_only BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS bucket_user_profiles TEXT NOT NULL DEFAULT 'user-avatars',
      ADD COLUMN IF NOT EXISTS category_mappings JSONB NOT NULL DEFAULT '{}'::JSONB,
      ADD COLUMN IF NOT EXISTS supports_storage BOOLEAN NOT NULL DEFAULT TRUE,
      ADD COLUMN IF NOT EXISTS supports_database BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS db_enabled BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS db_engine TEXT NOT NULL DEFAULT 'MYSQL';
  END IF;
END $$;

-- =========================================================================
-- 2. MIGRATED USER-SCOPED TABLES (REPLACING FIRESTORE SUBCOLLECTIONS)
-- =========================================================================
CREATE TABLE IF NOT EXISTS public.saved_guides (
  user_id TEXT NOT NULL,
  guide_id TEXT NOT NULL,
  category_id TEXT NOT NULL DEFAULT '',
  brand_name TEXT NOT NULL DEFAULT '',
  model_series TEXT NOT NULL DEFAULT '',
  code TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL DEFAULT '',
  summary TEXT NOT NULL DEFAULT '',
  entry_type TEXT NOT NULL DEFAULT 'ERROR_CODE',
  saved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, guide_id)
);

CREATE INDEX IF NOT EXISTS idx_saved_guides_user
  ON public.saved_guides (user_id, saved_at DESC);

CREATE TABLE IF NOT EXISTS public.read_announcements (
  user_id TEXT NOT NULL,
  announcement_id TEXT NOT NULL,
  read_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, announcement_id)
);

CREATE INDEX IF NOT EXISTS idx_read_announcements_user
  ON public.read_announcements (user_id, read_at DESC);

ALTER TABLE public.saved_guides ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.read_announcements ENABLE ROW LEVEL SECURITY;

-- =========================================================================
-- 3. STORAGE BUCKETS & AUTHENTICATED PROFILE / TECHNICIAN PHOTO POLICIES
-- =========================================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  ('user-avatars', 'user-avatars', TRUE, 5242880, ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp'])
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- Public read across public media buckets including user-avatars & technician-photos
DROP POLICY IF EXISTS "public_read_media_buckets" ON storage.objects;
CREATE POLICY "public_read_media_buckets" ON storage.objects
  FOR SELECT USING (
    bucket_id IN ('community-photos', 'technician-photos', 'repair-pdfs', 'circuit-diagrams', 'user-avatars')
  );

-- Allow x-upsert updates on owner folder in community-photos & verification-documents
DROP POLICY IF EXISTS "community_photos_auth_update" ON storage.objects;
CREATE POLICY "community_photos_auth_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id = 'community-photos'
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  )
  WITH CHECK (
    bucket_id = 'community-photos'
    AND public.is_user_active()
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

DROP POLICY IF EXISTS "verification_docs_auth_update" ON storage.objects;
CREATE POLICY "verification_docs_auth_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id = 'verification-documents'
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  )
  WITH CHECK (
    bucket_id = 'verification-documents'
    AND public.is_user_active()
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

-- User avatars: owner UID folder or Admin can insert/update/delete
DROP POLICY IF EXISTS "user_avatars_auth_insert" ON storage.objects;
CREATE POLICY "user_avatars_auth_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'user-avatars'
    AND public.is_user_active()
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

DROP POLICY IF EXISTS "user_avatars_auth_update" ON storage.objects;
CREATE POLICY "user_avatars_auth_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id = 'user-avatars'
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  )
  WITH CHECK (
    bucket_id = 'user-avatars'
    AND public.is_user_active()
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

DROP POLICY IF EXISTS "user_avatars_auth_delete" ON storage.objects;
CREATE POLICY "user_avatars_auth_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'user-avatars'
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

-- Technician photos: allow active applicants to upload their OWN public profile avatar under {uid}/..., plus Admin full access
DROP POLICY IF EXISTS "technician_photos_owner_or_admin_insert" ON storage.objects;
CREATE POLICY "technician_photos_owner_or_admin_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'technician-photos'
    AND public.is_user_active()
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

DROP POLICY IF EXISTS "technician_photos_owner_or_admin_update" ON storage.objects;
CREATE POLICY "technician_photos_owner_or_admin_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id = 'technician-photos'
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  )
  WITH CHECK (
    bucket_id = 'technician-photos'
    AND public.is_user_active()
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

DROP POLICY IF EXISTS "technician_photos_owner_or_admin_delete" ON storage.objects;
CREATE POLICY "technician_photos_owner_or_admin_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'technician-photos'
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

-- Keep admin-only storage writes on repair-pdfs and circuit-diagrams
DROP POLICY IF EXISTS "admin_buckets_insert" ON storage.objects;
CREATE POLICY "admin_buckets_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id IN ('technician-photos', 'repair-pdfs', 'circuit-diagrams', 'user-avatars')
    AND public.is_repairpro_admin()
  );

DROP POLICY IF EXISTS "admin_buckets_update" ON storage.objects;
CREATE POLICY "admin_buckets_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id IN ('technician-photos', 'repair-pdfs', 'circuit-diagrams', 'community-photos', 'verification-documents', 'user-avatars')
    AND public.is_repairpro_admin()
  );

DROP POLICY IF EXISTS "admin_buckets_delete" ON storage.objects;
CREATE POLICY "admin_buckets_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id IN ('technician-photos', 'repair-pdfs', 'circuit-diagrams', 'user-avatars')
    AND public.is_repairpro_admin()
  );

-- =========================================================================
-- 4. COMPLETE ROW LEVEL SECURITY POLICIES ACROSS ALL SUPABASE TABLES
-- =========================================================================
DO $$
BEGIN
  -- Community likes
  IF to_regclass('public.community_likes') IS NOT NULL THEN
    DROP POLICY IF EXISTS "community_likes_public_read" ON public.community_likes;
    CREATE POLICY "community_likes_public_read" ON public.community_likes
      FOR SELECT USING (TRUE);

    DROP POLICY IF EXISTS "community_likes_owner_insert" ON public.community_likes;
    CREATE POLICY "community_likes_owner_insert" ON public.community_likes
      FOR INSERT TO authenticated
      WITH CHECK (
        public.is_user_active()
        AND (user_id = public.firebase_uid() OR public.is_repairpro_admin())
      );

    DROP POLICY IF EXISTS "community_likes_owner_delete" ON public.community_likes;
    CREATE POLICY "community_likes_owner_delete" ON public.community_likes
      FOR DELETE TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  -- Community bookmarks
  IF to_regclass('public.community_bookmarks') IS NOT NULL THEN
    DROP POLICY IF EXISTS "community_bookmarks_owner_or_admin" ON public.community_bookmarks;
    CREATE POLICY "community_bookmarks_owner_or_admin" ON public.community_bookmarks
      FOR ALL TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin())
      WITH CHECK (
        (user_id = public.firebase_uid() AND public.is_user_active())
        OR public.is_repairpro_admin()
      );
  END IF;

  -- Community comments
  IF to_regclass('public.community_comments') IS NOT NULL THEN
    DROP POLICY IF EXISTS "community_comments_public_read" ON public.community_comments;
    CREATE POLICY "community_comments_public_read" ON public.community_comments
      FOR SELECT USING (TRUE);

    DROP POLICY IF EXISTS "community_comments_auth_insert" ON public.community_comments;
    CREATE POLICY "community_comments_auth_insert" ON public.community_comments
      FOR INSERT TO authenticated
      WITH CHECK (
        public.is_user_active()
        AND (author_uid = public.firebase_uid() OR public.is_repairpro_admin())
      );

    DROP POLICY IF EXISTS "community_comments_owner_or_admin_update" ON public.community_comments;
    CREATE POLICY "community_comments_owner_or_admin_update" ON public.community_comments
      FOR UPDATE TO authenticated
      USING (author_uid = public.firebase_uid() OR public.is_repairpro_admin())
      WITH CHECK (author_uid = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "community_comments_owner_or_admin_delete" ON public.community_comments;
    CREATE POLICY "community_comments_owner_or_admin_delete" ON public.community_comments
      FOR DELETE TO authenticated
      USING (author_uid = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  -- Community reports
  IF to_regclass('public.community_reports') IS NOT NULL THEN
    DROP POLICY IF EXISTS "community_reports_owner_or_admin_select" ON public.community_reports;
    CREATE POLICY "community_reports_owner_or_admin_select" ON public.community_reports
      FOR SELECT TO authenticated
      USING (reporter_uid = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "community_reports_auth_insert" ON public.community_reports;
    CREATE POLICY "community_reports_auth_insert" ON public.community_reports
      FOR INSERT TO authenticated
      WITH CHECK (
        public.is_user_active()
        AND (reporter_uid = public.firebase_uid() OR public.is_repairpro_admin())
      );

    DROP POLICY IF EXISTS "community_reports_admin_manage" ON public.community_reports;
    CREATE POLICY "community_reports_admin_manage" ON public.community_reports
      FOR UPDATE TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());

    DROP POLICY IF EXISTS "community_reports_admin_delete" ON public.community_reports;
    CREATE POLICY "community_reports_admin_delete" ON public.community_reports
      FOR DELETE TO authenticated
      USING (public.is_repairpro_admin());
  END IF;

  -- Community user restrictions
  IF to_regclass('public.community_user_restrictions') IS NOT NULL THEN
    DROP POLICY IF EXISTS "community_restrictions_self_or_admin_select" ON public.community_user_restrictions;
    CREATE POLICY "community_restrictions_self_or_admin_select" ON public.community_user_restrictions
      FOR SELECT TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "community_restrictions_admin_manage" ON public.community_user_restrictions;
    CREATE POLICY "community_restrictions_admin_manage" ON public.community_user_restrictions
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  -- Problem reports
  IF to_regclass('public.problem_reports') IS NOT NULL THEN
    DROP POLICY IF EXISTS "problem_reports_owner_or_admin_select" ON public.problem_reports;
    CREATE POLICY "problem_reports_owner_or_admin_select" ON public.problem_reports
      FOR SELECT TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "problem_reports_auth_insert" ON public.problem_reports;
    CREATE POLICY "problem_reports_auth_insert" ON public.problem_reports
      FOR INSERT TO authenticated
      WITH CHECK (
        public.is_user_active()
        AND (user_id = public.firebase_uid() OR public.is_repairpro_admin())
      );

    DROP POLICY IF EXISTS "problem_reports_admin_manage" ON public.problem_reports;
    CREATE POLICY "problem_reports_admin_manage" ON public.problem_reports
      FOR UPDATE TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());

    DROP POLICY IF EXISTS "problem_reports_owner_or_admin_delete" ON public.problem_reports;
    CREATE POLICY "problem_reports_owner_or_admin_delete" ON public.problem_reports
      FOR DELETE TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  -- Saved guides
  IF to_regclass('public.saved_guides') IS NOT NULL THEN
    DROP POLICY IF EXISTS "saved_guides_owner_or_admin" ON public.saved_guides;
    CREATE POLICY "saved_guides_owner_or_admin" ON public.saved_guides
      FOR ALL TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin())
      WITH CHECK (user_id = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  -- User notifications
  IF to_regclass('public.user_notifications') IS NOT NULL THEN
    DROP POLICY IF EXISTS "user_notifications_owner_or_admin_select" ON public.user_notifications;
    CREATE POLICY "user_notifications_owner_or_admin_select" ON public.user_notifications
      FOR SELECT TO authenticated
      USING (recipient_uid = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "user_notifications_auth_insert" ON public.user_notifications;
    CREATE POLICY "user_notifications_auth_insert" ON public.user_notifications
      FOR INSERT TO authenticated
      WITH CHECK (
        public.is_repairpro_admin()
        OR (public.is_user_active() AND actor_uid = public.firebase_uid())
      );

    DROP POLICY IF EXISTS "user_notifications_owner_or_admin_update" ON public.user_notifications;
    CREATE POLICY "user_notifications_owner_or_admin_update" ON public.user_notifications
      FOR UPDATE TO authenticated
      USING (recipient_uid = public.firebase_uid() OR public.is_repairpro_admin())
      WITH CHECK (recipient_uid = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "user_notifications_owner_or_admin_delete" ON public.user_notifications;
    CREATE POLICY "user_notifications_owner_or_admin_delete" ON public.user_notifications
      FOR DELETE TO authenticated
      USING (recipient_uid = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  -- Announcements & read announcements
  IF to_regclass('public.announcements') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_announcements" ON public.announcements;
    CREATE POLICY "public_read_announcements" ON public.announcements
      FOR SELECT USING (TRUE);

    DROP POLICY IF EXISTS "announcements_admin_manage" ON public.announcements;
    CREATE POLICY "announcements_admin_manage" ON public.announcements
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  IF to_regclass('public.read_announcements') IS NOT NULL THEN
    DROP POLICY IF EXISTS "read_announcements_owner_or_admin" ON public.read_announcements;
    CREATE POLICY "read_announcements_owner_or_admin" ON public.read_announcements
      FOR ALL TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin())
      WITH CHECK (user_id = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  -- FCM tokens & push history
  IF to_regclass('public.fcm_tokens') IS NOT NULL THEN
    DROP POLICY IF EXISTS "fcm_tokens_owner_or_admin" ON public.fcm_tokens;
    CREATE POLICY "fcm_tokens_owner_or_admin" ON public.fcm_tokens
      FOR ALL TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin())
      WITH CHECK (user_id = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  IF to_regclass('public.push_notification_history') IS NOT NULL THEN
    DROP POLICY IF EXISTS "push_history_admin_manage" ON public.push_notification_history;
    CREATE POLICY "push_history_admin_manage" ON public.push_notification_history
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  -- Storage providers (metadata only — secrets stay strictly in hosting_provider_secrets!)
  IF to_regclass('public.storage_providers') IS NOT NULL THEN
    DROP POLICY IF EXISTS "storage_providers_public_read" ON public.storage_providers;
    CREATE POLICY "storage_providers_public_read" ON public.storage_providers
      FOR SELECT USING (TRUE);

    DROP POLICY IF EXISTS "storage_providers_admin_manage" ON public.storage_providers;
    CREATE POLICY "storage_providers_admin_manage" ON public.storage_providers
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  -- Storage files registry
  IF to_regclass('public.storage_files') IS NOT NULL THEN
    DROP POLICY IF EXISTS "storage_files_public_read" ON public.storage_files;
    CREATE POLICY "storage_files_public_read" ON public.storage_files
      FOR SELECT USING (TRUE);

    DROP POLICY IF EXISTS "storage_files_auth_insert" ON public.storage_files;
    CREATE POLICY "storage_files_auth_insert" ON public.storage_files
      FOR INSERT TO authenticated
      WITH CHECK (uploaded_by_uid = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "storage_files_admin_manage" ON public.storage_files;
    CREATE POLICY "storage_files_admin_manage" ON public.storage_files
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  -- App settings: public read for client configs, admin write
  IF to_regclass('public.app_settings') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_app_settings" ON public.app_settings;
    CREATE POLICY "public_read_app_settings" ON public.app_settings
      FOR SELECT USING (
        setting_id IN ('global_config', 'admob_config', 'storage_config', 'ai_config', 'billing_config')
        OR public.is_repairpro_admin()
      );

    DROP POLICY IF EXISTS "app_settings_admin_manage" ON public.app_settings;
    CREATE POLICY "app_settings_admin_manage" ON public.app_settings
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  -- Admin roles: self or admin read, admin write
  IF to_regclass('public.admin_roles') IS NOT NULL THEN
    DROP POLICY IF EXISTS "admin_roles_admin_manage" ON public.admin_roles;
    CREATE POLICY "admin_roles_admin_manage" ON public.admin_roles
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  -- AI error logs: admin can mark resolved
  IF to_regclass('public.ai_error_logs') IS NOT NULL THEN
    DROP POLICY IF EXISTS "ai_errors_admin_update" ON public.ai_error_logs;
    CREATE POLICY "ai_errors_admin_update" ON public.ai_error_logs
      FOR UPDATE TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  -- User profiles: allow owner delete during self-deletion
  IF to_regclass('public.user_profiles') IS NOT NULL THEN
    DROP POLICY IF EXISTS "user_profiles_owner_or_admin_delete" ON public.user_profiles;
    CREATE POLICY "user_profiles_owner_or_admin_delete" ON public.user_profiles
      FOR DELETE TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;
END $$;

-- =========================================================================
-- 5. ATOMIC COMMUNITY RPC FUNCTIONS (CONSISTENT COUNTERS UNDER CONCURRENCY)
-- =========================================================================
CREATE OR REPLACE FUNCTION public.toggle_community_like(p_post_id TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_existed BOOLEAN := FALSE;
  v_new_count INTEGER := 0;
BEGIN
  IF v_uid = '' OR NOT public.is_user_active() THEN
    RAISE EXCEPTION 'Unauthorized or restricted user';
  END IF;

  SELECT EXISTS(
    SELECT 1 FROM public.community_likes WHERE post_id = p_post_id AND user_id = v_uid
  ) INTO v_existed;

  IF v_existed THEN
    DELETE FROM public.community_likes WHERE post_id = p_post_id AND user_id = v_uid;
  ELSE
    INSERT INTO public.community_likes (post_id, user_id)
    VALUES (p_post_id, v_uid)
    ON CONFLICT (post_id, user_id) DO NOTHING;
  END IF;

  SELECT COUNT(*)::INTEGER INTO v_new_count
  FROM public.community_likes
  WHERE post_id = p_post_id;

  UPDATE public.community_posts
  SET like_count = v_new_count, updated_at = NOW()
  WHERE post_id = p_post_id;

  RETURN jsonb_build_object(
    'liked', NOT v_existed,
    'like_count', v_new_count
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.add_community_comment(
  p_comment_id TEXT,
  p_post_id TEXT,
  p_parent_comment_id TEXT,
  p_reply_to_author_name TEXT,
  p_author_name TEXT,
  p_author_verified BOOLEAN,
  p_body TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_new_count INTEGER := 0;
  v_clean_body TEXT := trim(COALESCE(p_body, ''));
BEGIN
  IF v_uid = '' OR NOT public.is_user_active() THEN
    RAISE EXCEPTION 'Unauthorized or restricted user';
  END IF;

  IF length(v_clean_body) = 0 OR length(v_clean_body) > 1000 THEN
    RAISE EXCEPTION 'Comment body must be between 1 and 1000 characters';
  END IF;

  INSERT INTO public.community_comments (
    comment_id, post_id, parent_comment_id, reply_to_author_name,
    author_uid, author_name, author_verified, body
  ) VALUES (
    p_comment_id,
    p_post_id,
    COALESCE(p_parent_comment_id, ''),
    COALESCE(p_reply_to_author_name, ''),
    v_uid,
    COALESCE(NULLIF(trim(p_author_name), ''), 'Technician'),
    COALESCE(p_author_verified, FALSE),
    v_clean_body
  );

  SELECT COUNT(*)::INTEGER INTO v_new_count
  FROM public.community_comments
  WHERE post_id = p_post_id;

  UPDATE public.community_posts
  SET comment_count = v_new_count, updated_at = NOW()
  WHERE post_id = p_post_id;

  RETURN jsonb_build_object(
    'comment_id', p_comment_id,
    'comment_count', v_new_count
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.delete_community_comment(
  p_comment_id TEXT,
  p_post_id TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_owner TEXT := '';
  v_new_count INTEGER := 0;
BEGIN
  IF v_uid = '' THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  SELECT author_uid INTO v_owner
  FROM public.community_comments
  WHERE comment_id = p_comment_id;

  IF v_owner IS NULL THEN
    RETURN jsonb_build_object('deleted', FALSE, 'comment_count', 0);
  END IF;

  IF v_owner <> v_uid AND NOT public.is_repairpro_admin() THEN
    RAISE EXCEPTION 'Forbidden: only the author or an admin can delete this comment';
  END IF;

  DELETE FROM public.community_comments
  WHERE comment_id = p_comment_id;

  SELECT COUNT(*)::INTEGER INTO v_new_count
  FROM public.community_comments
  WHERE post_id = p_post_id;

  UPDATE public.community_posts
  SET comment_count = v_new_count, updated_at = NOW()
  WHERE post_id = p_post_id;

  RETURN jsonb_build_object(
    'deleted', TRUE,
    'comment_count', v_new_count
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.submit_community_report(
  p_report_id TEXT,
  p_post_id TEXT,
  p_comment_id TEXT,
  p_reporter_name TEXT,
  p_reason TEXT,
  p_details TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_new_count INTEGER := 0;
BEGIN
  IF v_uid = '' OR NOT public.is_user_active() THEN
    RAISE EXCEPTION 'Unauthorized or restricted user';
  END IF;

  INSERT INTO public.community_reports (
    report_id, post_id, comment_id, reporter_uid, reporter_name, reason, details, status
  ) VALUES (
    p_report_id,
    p_post_id,
    COALESCE(p_comment_id, ''),
    v_uid,
    COALESCE(NULLIF(trim(p_reporter_name), ''), 'Repair Pro User'),
    COALESCE(NULLIF(trim(p_reason), ''), 'OTHER'),
    COALESCE(p_details, ''),
    'OPEN'
  );

  SELECT COUNT(*)::INTEGER INTO v_new_count
  FROM public.community_reports
  WHERE post_id = p_post_id AND status IN ('OPEN', 'REVIEWED');

  UPDATE public.community_posts
  SET report_count = v_new_count, updated_at = NOW()
  WHERE post_id = p_post_id;

  RETURN jsonb_build_object(
    'report_id', p_report_id,
    'report_count', v_new_count
  );
END;
$$;

REVOKE ALL ON FUNCTION public.toggle_community_like(TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.toggle_community_like(TEXT) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.add_community_comment(TEXT, TEXT, TEXT, TEXT, TEXT, BOOLEAN, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.add_community_comment(TEXT, TEXT, TEXT, TEXT, TEXT, BOOLEAN, TEXT) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.delete_community_comment(TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_community_comment(TEXT, TEXT) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.submit_community_report(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.submit_community_report(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated, service_role;

-- =========================================================================
-- 6. SEED DEFAULT USER-AVATAR BUCKET & CATEGORY ROUTING ON SUPABASE PRIMARY
-- =========================================================================
UPDATE public.storage_providers
SET
  bucket_user_profiles = COALESCE(NULLIF(bucket_user_profiles, ''), 'user-avatars'),
  supports_storage = TRUE,
  category_mappings = CASE
    WHEN category_mappings = '{}'::JSONB THEN jsonb_build_object(
      'community', 'supabase_primary',
      'technicians', 'supabase_primary',
      'pdfs', 'supabase_primary',
      'diagrams', 'supabase_primary',
      'verification', 'supabase_primary',
      'user_profiles', 'supabase_primary'
    )
    ELSE category_mappings
  END
WHERE provider_id = 'supabase_primary';

COMMIT;
