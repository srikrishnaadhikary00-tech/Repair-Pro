-- Repair Pro — Community Open-Posting for All Registered Users + 24x7 Server-Side Migration Scheduler
-- Safe, additive, idempotent migration. Preserves all existing data, auth, and schemas.

-- =========================================================================
-- 1. GRANULAR COMMUNITY PERMISSION HELPERS (NO VERIFIED-TECH RESTRICTION)
-- =========================================================================
-- Every registered authenticated user (normal user, unverified technician,
-- verified technician, or admin) can create posts, like, comment, and delete
-- their own posts unless explicitly blocked, suspended, or restricted by Admin.

CREATE OR REPLACE FUNCTION public.can_user_post_community()
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_blocked_claim BOOLEAN := LOWER(COALESCE(auth.jwt() ->> 'blocked', 'false')) = 'true'
                             OR LOWER(COALESCE(auth.jwt() ->> 'suspended', 'false')) = 'true'
                             OR LOWER(COALESCE(auth.jwt() ->> 'communityRestricted', 'false')) = 'true';
  v_profile_blocked BOOLEAN := FALSE;
  v_comm_restricted BOOLEAN := FALSE;
BEGIN
  IF v_uid = '' THEN
    RETURN FALSE;
  END IF;

  IF public.is_repairpro_admin() THEN
    RETURN TRUE;
  END IF;

  IF v_blocked_claim THEN
    RETURN FALSE;
  END IF;

  IF to_regclass('public.user_profiles') IS NOT NULL THEN
    SELECT COALESCE(bool_or(blocked OR suspended OR COALESCE(community_restricted, FALSE)), FALSE)
    INTO v_profile_blocked
    FROM public.user_profiles
    WHERE user_id = v_uid;
    IF v_profile_blocked THEN
      RETURN FALSE;
    END IF;
  END IF;

  IF to_regclass('public.community_user_restrictions') IS NOT NULL THEN
    SELECT COALESCE(bool_or(COALESCE(is_blocked, FALSE) OR (NOT COALESCE(can_post, TRUE))), FALSE)
    INTO v_comm_restricted
    FROM public.community_user_restrictions
    WHERE user_id = v_uid;
    IF v_comm_restricted THEN
      RETURN FALSE;
    END IF;
  END IF;

  RETURN TRUE;
END;
$$;

CREATE OR REPLACE FUNCTION public.can_user_comment_community()
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_blocked_claim BOOLEAN := LOWER(COALESCE(auth.jwt() ->> 'blocked', 'false')) = 'true'
                             OR LOWER(COALESCE(auth.jwt() ->> 'suspended', 'false')) = 'true'
                             OR LOWER(COALESCE(auth.jwt() ->> 'communityRestricted', 'false')) = 'true';
  v_profile_blocked BOOLEAN := FALSE;
  v_comm_restricted BOOLEAN := FALSE;
BEGIN
  IF v_uid = '' THEN
    RETURN FALSE;
  END IF;

  IF public.is_repairpro_admin() THEN
    RETURN TRUE;
  END IF;

  IF v_blocked_claim THEN
    RETURN FALSE;
  END IF;

  IF to_regclass('public.user_profiles') IS NOT NULL THEN
    SELECT COALESCE(bool_or(blocked OR suspended OR COALESCE(community_restricted, FALSE)), FALSE)
    INTO v_profile_blocked
    FROM public.user_profiles
    WHERE user_id = v_uid;
    IF v_profile_blocked THEN
      RETURN FALSE;
    END IF;
  END IF;

  IF to_regclass('public.community_user_restrictions') IS NOT NULL THEN
    SELECT COALESCE(bool_or(COALESCE(is_blocked, FALSE) OR (NOT COALESCE(can_comment, TRUE))), FALSE)
    INTO v_comm_restricted
    FROM public.community_user_restrictions
    WHERE user_id = v_uid;
    IF v_comm_restricted THEN
      RETURN FALSE;
    END IF;
  END IF;

  RETURN TRUE;
END;
$$;

CREATE OR REPLACE FUNCTION public.can_user_upload_community_photo()
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_upload_claim BOOLEAN := LOWER(COALESCE(auth.jwt() ->> 'uploadRestricted', 'false')) = 'true';
  v_profile_upload_blocked BOOLEAN := FALSE;
  v_comm_photo_blocked BOOLEAN := FALSE;
BEGIN
  IF NOT public.can_user_post_community() THEN
    RETURN FALSE;
  END IF;

  IF public.is_repairpro_admin() THEN
    RETURN TRUE;
  END IF;

  IF v_upload_claim THEN
    RETURN FALSE;
  END IF;

  IF to_regclass('public.user_profiles') IS NOT NULL THEN
    SELECT COALESCE(bool_or(COALESCE(upload_restricted, FALSE)), FALSE)
    INTO v_profile_upload_blocked
    FROM public.user_profiles
    WHERE user_id = v_uid;
    IF v_profile_upload_blocked THEN
      RETURN FALSE;
    END IF;
  END IF;

  IF to_regclass('public.community_user_restrictions') IS NOT NULL THEN
    SELECT COALESCE(bool_or(NOT COALESCE(can_upload_photo, TRUE)), FALSE)
    INTO v_comm_photo_blocked
    FROM public.community_user_restrictions
    WHERE user_id = v_uid;
    IF v_comm_photo_blocked THEN
      RETURN FALSE;
    END IF;
  END IF;

  RETURN TRUE;
END;
$$;

-- =========================================================================
-- 2. COMMUNITY RLS POLICIES (OPEN TO ALL ACTIVE REGISTERED USERS)
-- =========================================================================
DO $$
BEGIN
  IF to_regclass('public.community_posts') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_approved_posts" ON public.community_posts;
    CREATE POLICY "public_read_approved_posts" ON public.community_posts
      FOR SELECT USING (
        (approval_status = 'APPROVED' AND is_hidden = FALSE AND is_deleted = FALSE)
        OR author_uid = public.firebase_uid()
        OR public.is_repairpro_admin()
      );

    DROP POLICY IF EXISTS "community_posts_auth_write" ON public.community_posts;
    CREATE POLICY "community_posts_auth_write" ON public.community_posts
      FOR INSERT TO authenticated
      WITH CHECK (
        public.is_repairpro_admin()
        OR (
          public.can_user_post_community()
          AND author_uid = public.firebase_uid()
          AND approval_status = 'PENDING'
          AND COALESCE(is_pinned, FALSE) = FALSE
          AND COALESCE(is_hidden, FALSE) = FALSE
          AND (
            (COALESCE(photo_url, '') = '' AND COALESCE(jsonb_array_length(COALESCE(photo_urls, '[]'::jsonb)), 0) = 0)
            OR public.can_user_upload_community_photo()
          )
        )
      );

    DROP POLICY IF EXISTS "community_posts_owner_or_admin_update" ON public.community_posts;
    CREATE POLICY "community_posts_owner_or_admin_update" ON public.community_posts
      FOR UPDATE TO authenticated
      USING (
        public.is_repairpro_admin()
        OR (author_uid = public.firebase_uid() AND public.can_user_post_community())
      )
      WITH CHECK (
        public.is_repairpro_admin()
        OR (
          author_uid = public.firebase_uid()
          AND public.can_user_post_community()
          AND approval_status = 'PENDING'
          AND (
            (COALESCE(photo_url, '') = '' AND COALESCE(jsonb_array_length(COALESCE(photo_urls, '[]'::jsonb)), 0) = 0)
            OR public.can_user_upload_community_photo()
          )
        )
      );

    DROP POLICY IF EXISTS "community_posts_owner_or_admin_delete" ON public.community_posts;
    CREATE POLICY "community_posts_owner_or_admin_delete" ON public.community_posts
      FOR DELETE TO authenticated
      USING (author_uid = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  IF to_regclass('public.community_comments') IS NOT NULL THEN
    DROP POLICY IF EXISTS "community_comments_auth_insert" ON public.community_comments;
    CREATE POLICY "community_comments_auth_insert" ON public.community_comments
      FOR INSERT TO authenticated
      WITH CHECK (
        public.can_user_comment_community()
        AND (author_uid = public.firebase_uid() OR public.is_repairpro_admin())
      );

    DROP POLICY IF EXISTS "community_comments_owner_or_admin_update" ON public.community_comments;
    CREATE POLICY "community_comments_owner_or_admin_update" ON public.community_comments
      FOR UPDATE TO authenticated
      USING (
        public.is_repairpro_admin()
        OR (author_uid = public.firebase_uid() AND public.can_user_comment_community())
      )
      WITH CHECK (
        public.is_repairpro_admin()
        OR (author_uid = public.firebase_uid() AND public.can_user_comment_community())
      );

    DROP POLICY IF EXISTS "community_comments_owner_or_admin_delete" ON public.community_comments;
    CREATE POLICY "community_comments_owner_or_admin_delete" ON public.community_comments
      FOR DELETE TO authenticated
      USING (author_uid = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;
END $$;

-- Update community-photos storage bucket upload policy to enforce upload restrictions cleanly
-- while allowing ALL non-restricted registered users (normal, unverified, verified) to upload
DROP POLICY IF EXISTS "community_photos_auth_insert" ON storage.objects;
CREATE POLICY "community_photos_auth_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'community-photos'
    AND public.can_user_upload_community_photo()
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

-- Update Community RPCs so restricted users cannot like/comment/report while all active users can
CREATE OR REPLACE FUNCTION public.toggle_community_like(p_post_id TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_existed BOOLEAN := FALSE;
  v_new_count INTEGER := 0;
BEGIN
  IF v_uid = '' OR NOT public.can_user_post_community() THEN
    RAISE EXCEPTION 'Unauthorized or restricted user';
  END IF;

  SELECT EXISTS(
    SELECT 1 FROM public.community_likes WHERE post_id = p_post_id AND user_id = v_uid
  ) INTO v_existed;

  IF v_existed THEN
    DELETE FROM public.community_likes WHERE post_id = p_post_id AND user_id = v_uid;
  ELSE
    INSERT INTO public.community_likes (post_id, user_id)
    VALUES (p_post_id, v_uid)
    ON CONFLICT (post_id, user_id) DO NOTHING;
  END IF;

  SELECT COUNT(*)::INTEGER INTO v_new_count
  FROM public.community_likes
  WHERE post_id = p_post_id;

  UPDATE public.community_posts
  SET like_count = v_new_count, updated_at = NOW()
  WHERE post_id = p_post_id;

  RETURN jsonb_build_object(
    'liked', NOT v_existed,
    'like_count', v_new_count
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.add_community_comment(
  p_comment_id TEXT,
  p_post_id TEXT,
  p_parent_comment_id TEXT,
  p_reply_to_author_name TEXT,
  p_author_name TEXT,
  p_author_verified BOOLEAN,
  p_body TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_new_count INTEGER := 0;
  v_clean_body TEXT := trim(COALESCE(p_body, ''));
BEGIN
  IF v_uid = '' OR NOT public.can_user_comment_community() THEN
    RAISE EXCEPTION 'Unauthorized or restricted user';
  END IF;

  IF length(v_clean_body) = 0 OR length(v_clean_body) > 1000 THEN
    RAISE EXCEPTION 'Comment body must be between 1 and 1000 characters';
  END IF;

  INSERT INTO public.community_comments (
    comment_id, post_id, parent_comment_id, reply_to_author_name,
    author_uid, author_name, author_verified, body
  ) VALUES (
    p_comment_id,
    p_post_id,
    COALESCE(p_parent_comment_id, ''),
    COALESCE(p_reply_to_author_name, ''),
    v_uid,
    COALESCE(NULLIF(trim(p_author_name), ''), 'Repair Pro Member'),
    COALESCE(p_author_verified, FALSE),
    v_clean_body
  );

  SELECT COUNT(*)::INTEGER INTO v_new_count
  FROM public.community_comments
  WHERE post_id = p_post_id;

  UPDATE public.community_posts
  SET comment_count = v_new_count, updated_at = NOW()
  WHERE post_id = p_post_id;

  RETURN jsonb_build_object(
    'comment_id', p_comment_id,
    'comment_count', v_new_count
  );
END;
$$;

-- =========================================================================
-- 3. 24x7 SERVER-SIDE SCHEDULER STATUS, LOCKS & SAFE CAPACITY RECLAMATION
-- =========================================================================
CREATE TABLE IF NOT EXISTS public.cloud_scheduler_status (
  scheduler_id TEXT PRIMARY KEY DEFAULT 'default',
  worker_type TEXT NOT NULL DEFAULT 'SUPABASE_EDGE_CRON',
  status TEXT NOT NULL DEFAULT 'IDLE',
  lock_owner TEXT NOT NULL DEFAULT '',
  locked_until TIMESTAMPTZ,
  last_run_at TIMESTAMPTZ,
  last_success_at TIMESTAMPTZ,
  last_run_id TEXT NOT NULL DEFAULT '',
  last_status TEXT NOT NULL DEFAULT 'NEVER_RUN',
  last_error TEXT NOT NULL DEFAULT '',
  last_db_pct INTEGER NOT NULL DEFAULT 0,
  last_storage_pct INTEGER NOT NULL DEFAULT 0,
  reclaimed_bytes BIGINT NOT NULL DEFAULT 0,
  next_suggested_run_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.cloud_scheduler_status ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "cloud_scheduler_admin_manage" ON public.cloud_scheduler_status;
CREATE POLICY "cloud_scheduler_admin_manage" ON public.cloud_scheduler_status
  FOR ALL TO authenticated
  USING (public.is_repairpro_admin())
  WITH CHECK (public.is_repairpro_admin());

INSERT INTO public.cloud_scheduler_status (scheduler_id, worker_type, status, last_status)
VALUES ('default', 'SUPABASE_EDGE_CRON', 'IDLE', 'READY')
ON CONFLICT (scheduler_id) DO NOTHING;

-- Allow both authenticated Super Admin AND server-side service_role workers
CREATE OR REPLACE FUNCTION public.get_supabase_usage_metrics()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, storage
AS $$
DECLARE
  v_db_bytes BIGINT := 0;
  v_storage_bytes BIGINT := 0;
  v_storage_count BIGINT := 0;
  v_buckets JSONB := '[]'::JSONB;
  v_tables JSONB := '{}'::JSONB;
  v_is_service BOOLEAN := (auth.role() = 'service_role') OR (current_user IN ('service_role', 'postgres', 'supabase_admin'));
BEGIN
  IF NOT v_is_service AND NOT public.is_repairpro_admin() THEN
    RAISE EXCEPTION 'Admin or service_role privileges required for live usage metrics';
  END IF;

  v_db_bytes := pg_database_size(current_database())::BIGINT;

  SELECT
    COALESCE(SUM(COALESCE((metadata->>'size')::BIGINT, 0)), 0)::BIGINT,
    COALESCE(COUNT(*), 0)::BIGINT
  INTO v_storage_bytes, v_storage_count
  FROM storage.objects;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'bucketId', b.id,
        'objectCount', COALESCE(s.obj_count, 0),
        'usedBytes', COALESCE(s.total_bytes, 0)
      )
      ORDER BY b.id
    ),
    '[]'::JSONB
  )
  INTO v_buckets
  FROM storage.buckets b
  LEFT JOIN (
    SELECT
      bucket_id,
      COUNT(*)::BIGINT AS obj_count,
      COALESCE(SUM(COALESCE((metadata->>'size')::BIGINT, 0)), 0)::BIGINT AS total_bytes
    FROM storage.objects
    GROUP BY bucket_id
  ) s ON s.bucket_id = b.id;

  v_tables := jsonb_build_object(
    'community_posts', COALESCE((SELECT COUNT(*) FROM public.community_posts), 0),
    'technicians', COALESCE((SELECT COUNT(*) FROM public.technicians), 0),
    'technician_verification_requests', COALESCE((SELECT COUNT(*) FROM public.technician_verification_requests), 0),
    'technical_documents', COALESCE((SELECT COUNT(*) FROM public.technical_documents), 0),
    'problem_reports', COALESCE((SELECT COUNT(*) FROM public.problem_reports), 0),
    'repair_catalog_entries', COALESCE((SELECT COUNT(*) FROM public.repair_catalog_entries), 0),
    'user_profiles', COALESCE((SELECT COUNT(*) FROM public.user_profiles), 0)
  );

  RETURN jsonb_build_object(
    'ok', TRUE,
    'dbUsedBytes', v_db_bytes,
    'dbLimitBytes', 524288000,
    'storageUsedBytes', v_storage_bytes,
    'storageObjectCount', v_storage_count,
    'storageLimitBytes', 1073741824,
    'buckets', v_buckets,
    'tables', v_tables,
    'measuredAt', NOW()
  );
END;
$$;

REVOKE ALL ON FUNCTION public.get_supabase_usage_metrics() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_supabase_usage_metrics() TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.acquire_cloud_scheduler_lock(
  p_scheduler_id TEXT DEFAULT 'default',
  p_lock_owner TEXT DEFAULT 'edge_cron',
  p_ttl_seconds INTEGER DEFAULT 300,
  p_worker_type TEXT DEFAULT 'SUPABASE_EDGE_CRON'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_is_service BOOLEAN := (auth.role() = 'service_role') OR (current_user IN ('service_role', 'postgres', 'supabase_admin'));
  v_now TIMESTAMPTZ := NOW();
  v_ttl INTEGER := GREATEST(30, LEAST(1800, COALESCE(p_ttl_seconds, 300)));
  v_acquired BOOLEAN := FALSE;
  v_row public.cloud_scheduler_status%ROWTYPE;
BEGIN
  IF NOT v_is_service AND NOT public.is_repairpro_admin() THEN
    RAISE EXCEPTION 'Admin or service_role required for scheduler lock';
  END IF;

  INSERT INTO public.cloud_scheduler_status (scheduler_id, worker_type, status)
  VALUES (p_scheduler_id, p_worker_type, 'IDLE')
  ON CONFLICT (scheduler_id) DO NOTHING;

  UPDATE public.cloud_scheduler_status
  SET
    status = 'RUNNING',
    worker_type = COALESCE(NULLIF(p_worker_type, ''), worker_type),
    lock_owner = COALESCE(NULLIF(p_lock_owner, ''), 'worker'),
    locked_until = v_now + make_interval(secs => v_ttl),
    last_run_at = v_now,
    updated_at = v_now
  WHERE scheduler_id = p_scheduler_id
    AND (
      status <> 'RUNNING'
      OR locked_until IS NULL
      OR locked_until < v_now
      OR lock_owner = p_lock_owner
    )
  RETURNING * INTO v_row;

  v_acquired := FOUND;
  IF NOT v_acquired THEN
    SELECT * INTO v_row FROM public.cloud_scheduler_status WHERE scheduler_id = p_scheduler_id;
  END IF;

  RETURN jsonb_build_object(
    'acquired', v_acquired,
    'schedulerId', v_row.scheduler_id,
    'status', v_row.status,
    'lockOwner', v_row.lock_owner,
    'lockedUntil', v_row.locked_until
  );
END;
$$;

REVOKE ALL ON FUNCTION public.acquire_cloud_scheduler_lock(TEXT, TEXT, INTEGER, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.acquire_cloud_scheduler_lock(TEXT, TEXT, INTEGER, TEXT) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.release_cloud_scheduler_lock(
  p_scheduler_id TEXT DEFAULT 'default',
  p_last_status TEXT DEFAULT 'COMPLETED',
  p_last_run_id TEXT DEFAULT '',
  p_last_error TEXT DEFAULT '',
  p_db_pct INTEGER DEFAULT 0,
  p_storage_pct INTEGER DEFAULT 0,
  p_reclaimed_bytes BIGINT DEFAULT 0
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_is_service BOOLEAN := (auth.role() = 'service_role') OR (current_user IN ('service_role', 'postgres', 'supabase_admin'));
  v_now TIMESTAMPTZ := NOW();
  v_is_err BOOLEAN := UPPER(COALESCE(p_last_status, '')) LIKE '%ERROR%' OR UPPER(COALESCE(p_last_status, '')) = 'FAILED';
BEGIN
  IF NOT v_is_service AND NOT public.is_repairpro_admin() THEN
    RAISE EXCEPTION 'Admin or service_role required for scheduler unlock';
  END IF;

  UPDATE public.cloud_scheduler_status
  SET
    status = CASE WHEN v_is_err THEN 'ERROR' ELSE 'IDLE' END,
    lock_owner = '',
    locked_until = NULL,
    last_run_id = COALESCE(NULLIF(p_last_run_id, ''), last_run_id),
    last_status = COALESCE(NULLIF(p_last_status, ''), 'COMPLETED'),
    last_error = COALESCE(p_last_error, ''),
    last_success_at = CASE WHEN NOT v_is_err THEN v_now ELSE last_success_at END,
    last_db_pct = GREATEST(0, COALESCE(p_db_pct, 0)),
    last_storage_pct = GREATEST(0, COALESCE(p_storage_pct, 0)),
    reclaimed_bytes = COALESCE(reclaimed_bytes, 0) + GREATEST(0, COALESCE(p_reclaimed_bytes, 0)),
    next_suggested_run_at = v_now + interval '15 minutes',
    updated_at = v_now
  WHERE scheduler_id = p_scheduler_id;

  RETURN jsonb_build_object('ok', TRUE, 'releasedAt', v_now);
END;
$$;

REVOKE ALL ON FUNCTION public.release_cloud_scheduler_lock(TEXT, TEXT, TEXT, TEXT, INTEGER, INTEGER, BIGINT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.release_cloud_scheduler_lock(TEXT, TEXT, TEXT, TEXT, INTEGER, INTEGER, BIGINT) TO authenticated, service_role;

-- Safe record cleanup RPC: strictly blocks auth/config/system/manifest tables
CREATE OR REPLACE FUNCTION public.reclaim_migrated_record_safe(
  p_table TEXT,
  p_pk_col TEXT,
  p_pk_val TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_is_service BOOLEAN := (auth.role() = 'service_role') OR (current_user IN ('service_role', 'postgres', 'supabase_admin'));
  v_deleted INTEGER := 0;
BEGIN
  IF NOT v_is_service AND NOT public.is_repairpro_admin() THEN
    RAISE EXCEPTION 'Admin or service_role privileges required for cleanup';
  END IF;

  IF p_table IN (
    'admin_roles', 'app_settings', 'user_profiles', 'fcm_tokens',
    'ai_providers', 'ai_configs', 'storage_providers', 'hosting_provider_secrets',
    'cloud_manifest', 'cloud_migration_runs', 'cloud_migration_items',
    'cloud_backup_manifests', 'cloud_scheduler_status', 'audit_logs', 'storage_error_logs'
  ) THEN
    RAISE EXCEPTION 'Protected system/auth/config table "%" cannot be deleted during cleanup', p_table;
  END IF;

  IF p_table NOT IN (
    'community_posts', 'community_comments', 'community_likes',
    'community_bookmarks', 'community_reports', 'problem_reports', 'saved_guides'
  ) THEN
    RAISE EXCEPTION 'Table "%" is not eligible for automated row cleanup', p_table;
  END IF;

  IF p_pk_col NOT IN ('post_id', 'comment_id', 'like_id', 'bookmark_id', 'report_id', 'guide_id', 'id') THEN
    RAISE EXCEPTION 'Invalid primary key column "%"', p_pk_col;
  END IF;

  IF COALESCE(trim(p_pk_val), '') = '' THEN
    RAISE EXCEPTION 'Primary key value required';
  END IF;

  EXECUTE format('DELETE FROM public.%I WHERE %I = $1', p_table, p_pk_col) USING p_pk_val;
  GET DIAGNOSTICS v_deleted = ROW_COUNT;

  RETURN jsonb_build_object(
    'ok', TRUE,
    'table', p_table,
    'deletedCount', v_deleted
  );
END;
$$;

REVOKE ALL ON FUNCTION public.reclaim_migrated_record_safe(TEXT, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.reclaim_migrated_record_safe(TEXT, TEXT, TEXT) TO authenticated, service_role;

-- =========================================================================
-- 4. OPTIONAL 24x7 PG_CRON SCHEDULE SETUP (DOCUMENTED TEMPLATE)
-- =========================================================================
-- To run the 24x7 worker automatically inside Supabase even when browsers & phones are closed:
-- 1. Enable extensions `pg_cron` and `pg_net` in Supabase Dashboard -> Database -> Extensions.
-- 2. Store Edge Function secret `CRON_SECRET` in Supabase Dashboard -> Edge Functions -> Secrets.
-- 3. Execute once in SQL Editor (replace YOUR_CRON_SECRET):
--
-- SELECT cron.schedule(
--   'repairpro-cloud-migration-worker-every-15m',
--   '*/15 * * * *',
--   $$
--   SELECT net.http_post(
--     url := 'https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/cloud-migration-worker',
--     headers := jsonb_build_object(
--       'Content-Type', 'application/json',
--       'x-cron-secret', 'YOUR_CRON_SECRET'
--     ),
--     body := jsonb_build_object('action', 'run_tick', 'triggerMode', 'CRON_24X7')
--   );
--   $$
-- );
