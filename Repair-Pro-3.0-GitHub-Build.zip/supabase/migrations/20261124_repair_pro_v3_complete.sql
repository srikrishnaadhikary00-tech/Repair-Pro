-- ============================================================================
-- REPAIR PRO VERSION 3.0 — COMPLETE SUPABASE SQL MIGRATION & RLS POLICIES
-- Project: Repair-Pro (xuakzzjtcgcvudkgxpbd)
-- URL: https://xuakzzjtcgcvudkgxpbd.supabase.co
-- Safe & Idempotent: Preserves all existing data and storage buckets.
-- ============================================================================

create extension if not exists "pgcrypto";

-- 1. USER PROFILES (Linked to Firebase Auth UID)
create table if not exists public.user_profiles (
  firebase_uid text primary key,
  email text not null default '',
  display_name text not null default 'Repair Pro User',
  avatar_url text,
  role text not null default 'USER' check (role in ('USER', 'TECHNICIAN', 'CONTENT_EDITOR', 'SUPER_ADMIN')),
  preferred_language text not null default 'en' check (preferred_language in ('en', 'bn', 'hi')),
  ad_consent_granted boolean not null default true,
  is_blocked boolean not null default false,
  block_reason text,
  app_version text not null default '3.0',
  last_seen_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_user_profiles_role on public.user_profiles(role);
create index if not exists idx_user_profiles_blocked on public.user_profiles(is_blocked);

-- 2. FCM DEVICE TOKENS (Push Notifications)
create table if not exists public.user_fcm_tokens (
  id uuid primary key default gen_random_uuid(),
  firebase_uid text not null references public.user_profiles(firebase_uid) on delete cascade,
  fcm_token text not null unique,
  platform text not null default 'android' check (platform in ('android', 'ios', 'web')),
  app_version text not null default '3.0',
  is_active boolean not null default true,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists idx_user_fcm_tokens_uid on public.user_fcm_tokens(firebase_uid);

-- 3. MULTI-CLOUD STORAGE PROVIDERS (Zero plaintext secrets in DB — references secret_env_key only)
create table if not exists public.storage_providers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  provider_type text not null check (provider_type in ('SUPABASE', 'CLOUDFLARE_R2', 'BACKBLAZE_B2', 'CLOUDINARY', 'CUSTOM_S3')),
  endpoint_url text not null,
  project_ref text,
  region text not null default 'auto',
  public_base_url text,
  secret_env_key text not null default 'SUPABASE_SERVICE_ROLE_KEY',
  bucket_map jsonb not null default '{
    "community-photos": "community-photos",
    "repair-pdfs": "repair-pdfs",
    "circuit-diagrams": "circuit-diagrams",
    "technician-photos": "technician-photos",
    "verification-documents": "verification-documents"
  }'::jsonb,
  is_primary boolean not null default false,
  is_backup boolean not null default false,
  is_enabled boolean not null default true,
  priority_order integer not null default 10,
  capacity_bytes bigint not null default 1073741824, -- 1 GB Supabase free default
  used_bytes bigint not null default 0,
  auto_failover_enabled boolean not null default true,
  last_test_status text not null default 'UNTESTED',
  last_test_message text,
  last_test_at timestamptz,
  created_by_uid text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.storage_providers add column if not exists region text not null default 'auto';
alter table public.storage_providers add column if not exists public_base_url text;

-- Seed Primary Supabase Storage Provider (Repair-Pro) idempotently
insert into public.storage_providers (
  name, provider_type, endpoint_url, project_ref, secret_env_key,
  is_primary, is_backup, is_enabled, priority_order, capacity_bytes, last_test_status
)
select
  'Supabase Primary (Repair-Pro)',
  'SUPABASE',
  'https://xuakzzjtcgcvudkgxpbd.supabase.co',
  'xuakzzjtcgcvudkgxpbd',
  'SUPABASE_SERVICE_ROLE_KEY',
  true,
  false,
  true,
  1,
  1073741824,
  'CONNECTED'
where not exists (
  select 1 from public.storage_providers where project_ref = 'xuakzzjtcgcvudkgxpbd'
);

-- 4. CENTRAL FILE REGISTRY (Tracks all uploads across primary & backup providers)
create table if not exists public.storage_file_registry (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.storage_providers(id) on delete set null,
  bucket_name text not null check (bucket_name in (
    'community-photos', 'repair-pdfs', 'circuit-diagrams', 'technician-photos', 'verification-documents'
  )),
  object_path text not null,
  public_url text,
  is_private boolean not null default false,
  original_filename text not null,
  mime_type text not null,
  size_bytes bigint not null default 0,
  uploaded_by_uid text not null,
  entity_type text,
  entity_id text,
  sha256_checksum text,
  migrated_from_provider_id uuid,
  migrated_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.storage_file_registry add column if not exists sha256_checksum text;
alter table public.storage_file_registry add column if not exists migrated_at timestamptz;

create index if not exists idx_file_registry_bucket on public.storage_file_registry(bucket_name);
create index if not exists idx_file_registry_provider on public.storage_file_registry(provider_id);

-- Guard: prevent deleting any storage provider that still owns active files in registry or repair_documents
create or replace function public.prevent_delete_storage_provider_with_active_files()
returns trigger
language plpgsql
as $$
declare
  active_registry_count integer;
begin
  select count(*) into active_registry_count
  from public.storage_file_registry
  where provider_id = old.id;

  if active_registry_count > 0 then
    raise exception 'PROVIDER_HAS_ACTIVE_FILES: Migrate % active file(s) from provider % before deleting.', active_registry_count, old.name;
  end if;

  return old;
end;
$$;

drop trigger if exists trg_prevent_delete_storage_provider_with_files on public.storage_providers;
create trigger trg_prevent_delete_storage_provider_with_files
  before delete on public.storage_providers
  for each row
  execute function public.prevent_delete_storage_provider_with_active_files();

-- 5. STORAGE CONNECTION & FAILOVER ERROR LOGS
create table if not exists public.storage_error_logs (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.storage_providers(id) on delete set null,
  provider_name text,
  operation text not null,
  http_status integer,
  error_code text,
  error_message text not null,
  failed_over_to_provider_id uuid,
  created_at timestamptz not null default now()
);

-- 6. TECHNICIANS & VERIFICATION SYSTEM
create table if not exists public.technicians (
  id uuid primary key default gen_random_uuid(),
  firebase_uid text not null unique references public.user_profiles(firebase_uid) on delete cascade,
  full_name text not null,
  profile_photo_url text,
  public_phone text,
  service_details text not null,
  experience_years integer not null default 1 check (experience_years >= 0 and experience_years <= 70),
  service_location text not null,
  city text not null default '',
  appliance_categories text[] not null default array['ac']::text[],
  -- PRIVATE verification fields (never exposed in public directory view)
  private_verification_docs jsonb not null default '[]'::jsonb,
  private_id_number_masked text,
  approval_status text not null default 'PENDING' check (approval_status in ('PENDING', 'APPROVED', 'REJECTED')),
  is_verified boolean not null default false,
  is_active boolean not null default true,
  is_blocked boolean not null default false,
  admin_note text,
  reviewed_by_uid text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_technicians_status on public.technicians(approval_status, is_active, is_blocked);

-- Strict Public View: Ordinary users ONLY see approved, active, non-blocked technicians & ZERO private verification documents
create or replace view public.technician_public_directory as
select
  id,
  firebase_uid,
  full_name,
  profile_photo_url,
  public_phone,
  service_details,
  experience_years,
  service_location,
  city,
  appliance_categories,
  is_verified,
  is_active,
  created_at,
  updated_at
from public.technicians
where approval_status = 'APPROVED'
  and is_active = true
  and is_blocked = false;

-- 7. COMMUNITY SYSTEM (Posts, Multiple Photos, Likes, Comments & Replies, Saves, Reports)
create table if not exists public.community_posts (
  id uuid primary key default gen_random_uuid(),
  author_uid text not null references public.user_profiles(firebase_uid) on delete cascade,
  author_name text not null,
  author_avatar_url text,
  is_verified_technician boolean not null default false,
  category_id text not null default 'ac',
  title text not null default '',
  body text not null,
  photo_urls jsonb not null default '[]'::jsonb,
  storage_file_ids jsonb not null default '[]'::jsonb,
  likes_count integer not null default 0,
  comments_count integer not null default 0,
  moderation_status text not null default 'APPROVED' check (moderation_status in ('PENDING', 'APPROVED', 'REJECTED')),
  rejection_reason text,
  is_deleted boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_community_posts_status on public.community_posts(moderation_status, is_deleted, created_at desc);
create index if not exists idx_community_posts_author on public.community_posts(author_uid);

create table if not exists public.community_likes (
  post_id uuid not null references public.community_posts(id) on delete cascade,
  user_uid text not null references public.user_profiles(firebase_uid) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_uid)
);

create table if not exists public.community_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.community_posts(id) on delete cascade,
  parent_comment_id uuid references public.community_comments(id) on delete cascade,
  author_uid text not null references public.user_profiles(firebase_uid) on delete cascade,
  author_name text not null,
  is_verified_technician boolean not null default false,
  body text not null,
  is_deleted boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists idx_community_comments_post on public.community_comments(post_id, created_at asc);

create table if not exists public.community_saved_posts (
  post_id uuid not null references public.community_posts(id) on delete cascade,
  user_uid text not null references public.user_profiles(firebase_uid) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_uid)
);

create table if not exists public.community_reports (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.community_posts(id) on delete cascade,
  reporter_uid text not null references public.user_profiles(firebase_uid) on delete cascade,
  reason text not null,
  status text not null default 'OPEN' check (status in ('OPEN', 'REVIEWED', 'DISMISSED', 'ACTIONED')),
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 8. REPAIR DOCUMENTS (PDFs, Circuit Diagrams, Service Manuals)
create table if not exists public.repair_documents (
  id uuid primary key default gen_random_uuid(),
  doc_type text not null check (doc_type in ('PDF', 'CIRCUIT_DIAGRAM', 'SERVICE_MANUAL')),
  category_id text not null default 'ac',
  brand_name text not null default 'Universal',
  model_name text not null default 'General',
  error_code text not null default '',
  title text not null,
  description text not null default '',
  file_url text not null,
  storage_provider_id uuid references public.storage_providers(id) on delete set null,
  storage_file_id uuid references public.storage_file_registry(id) on delete set null,
  mime_type text not null default 'application/pdf',
  file_size_bytes bigint not null default 0,
  is_published boolean not null default true,
  downloads_count integer not null default 0,
  uploaded_by_uid text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_repair_documents_filter on public.repair_documents(doc_type, category_id, is_published);

-- 9. PUSH NOTIFICATIONS & HISTORY
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  target_type text not null check (target_type in ('ALL', 'SELECTED', 'TECHNICIANS', 'COMMUNITY_EVENT')),
  target_uids text[] not null default array[]::text[],
  sent_by_uid text not null,
  sent_by_email text not null default '',
  total_targeted integer not null default 0,
  success_count integer not null default 0,
  failure_count integer not null default 0,
  delivery_status text not null default 'QUEUED',
  error_message text,
  created_at timestamptz not null default now()
);

-- 10. ADMOB & REMOTE APP SETTINGS (Version 3.0)
create table if not exists public.admob_settings (
  id text primary key default 'default',
  ads_global_enabled boolean not null default true,
  emergency_kill_switch boolean not null default false,
  banner_enabled boolean not null default true,
  interstitial_enabled boolean not null default false,
  rewarded_enabled boolean not null default true,
  native_enabled boolean not null default false,
  app_open_enabled boolean not null default false,
  test_mode boolean not null default true,
  ac_ads_enabled boolean not null default true,
  fridge_ads_enabled boolean not null default true,
  washer_ads_enabled boolean not null default true,
  interstitial_cooldown_min integer not null default 3,
  session_frequency_cap integer not null default 6,
  android_app_id text not null default 'ca-app-pub-3940256099942544~3347511713',
  android_banner_id text not null default 'ca-app-pub-3940256099942544/6300978111',
  android_interstitial_id text not null default 'ca-app-pub-3940256099942544/1033173712',
  android_rewarded_id text not null default 'ca-app-pub-3940256099942544/5224354917',
  android_native_id text not null default 'ca-app-pub-3940256099942544/2247696110',
  android_app_open_id text not null default 'ca-app-pub-3940256099942544/9257395921',
  ios_app_id text not null default 'ca-app-pub-3940256099942544~1458002511',
  ios_banner_id text not null default 'ca-app-pub-3940256099942544/2934735716',
  updated_by_uid text,
  updated_at timestamptz not null default now()
);

insert into public.admob_settings (id) values ('default') on conflict (id) do nothing;

create table if not exists public.app_remote_settings (
  id text primary key default 'default',
  latest_version_name text not null default '3.0',
  latest_version_code integer not null default 3,
  min_supported_version text not null default '3.0',
  force_update boolean not null default false,
  announcement text not null default '',
  maintenance_notice text not null default '',
  community_enabled boolean not null default true,
  community_auto_approve boolean not null default true,
  technicians_enabled boolean not null default true,
  documents_enabled boolean not null default true,
  notifications_enabled boolean not null default true,
  storage_auto_failover boolean not null default true,
  updated_by_uid text,
  updated_at timestamptz not null default now()
);

insert into public.app_remote_settings (id) values ('default') on conflict (id) do nothing;

-- 11. ADMIN ACTIVITY LOGS & SYSTEM ERROR LOGS
create table if not exists public.admin_activity_logs (
  id uuid primary key default gen_random_uuid(),
  admin_uid text not null,
  admin_email text not null,
  action text not null,
  target_type text not null,
  target_id text not null,
  details text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.system_error_logs (
  id uuid primary key default gen_random_uuid(),
  source text not null,
  severity text not null default 'ERROR' check (severity in ('WARN', 'ERROR', 'CRITICAL')),
  actor_uid text,
  message text not null,
  context jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) — ZERO-TRUST BY DEFAULT
-- All authenticated writes flow through our Firebase-verified Supabase Edge
-- Functions using service_role; direct anon access is strictly limited to
-- public read-only catalog/approved content, protecting all private PII.
-- ============================================================================

alter table public.user_profiles enable row level security;
alter table public.user_fcm_tokens enable row level security;
alter table public.storage_providers enable row level security;
alter table public.storage_file_registry enable row level security;
alter table public.storage_error_logs enable row level security;
alter table public.technicians enable row level security;
alter table public.community_posts enable row level security;
alter table public.community_likes enable row level security;
alter table public.community_comments enable row level security;
alter table public.community_saved_posts enable row level security;
alter table public.community_reports enable row level security;
alter table public.repair_documents enable row level security;
alter table public.notifications enable row level security;
alter table public.admob_settings enable row level security;
alter table public.app_remote_settings enable row level security;
alter table public.admin_activity_logs enable row level security;
alter table public.system_error_logs enable row level security;

-- Public read-only policies for non-sensitive approved content
drop policy if exists "read_approved_community_posts" on public.community_posts;
create policy "read_approved_community_posts"
  on public.community_posts for select
  using (moderation_status = 'APPROVED' and is_deleted = false);

drop policy if exists "read_community_comments" on public.community_comments;
create policy "read_community_comments"
  on public.community_comments for select
  using (is_deleted = false);

drop policy if exists "read_published_repair_documents" on public.repair_documents;
create policy "read_published_repair_documents"
  on public.repair_documents for select
  using (is_published = true);

drop policy if exists "read_admob_settings" on public.admob_settings;
create policy "read_admob_settings"
  on public.admob_settings for select
  using (true);

drop policy if exists "read_remote_settings" on public.app_remote_settings;
create policy "read_remote_settings"
  on public.app_remote_settings for select
  using (true);

-- Explicitly deny direct anon reads on sensitive tables (Edge Functions mediate after Firebase JWT verification):
-- user_profiles, user_fcm_tokens, technicians (raw table w/ private_verification_docs),
-- storage_providers, storage_error_logs, community_reports, notifications, admin_activity_logs, system_error_logs.
-- Note: RLS enabled with no anon SELECT/INSERT/UPDATE/DELETE policies denies all anon access by default.

-- ============================================================================
-- STORAGE BUCKETS (REUSE EXISTING BUCKETS SAFELY)
-- ============================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('community-photos', 'community-photos', true, 5242880, array['image/jpeg', 'image/png', 'image/webp']),
  ('repair-pdfs', 'repair-pdfs', true, 20971520, array['application/pdf']),
  ('circuit-diagrams', 'circuit-diagrams', true, 10485760, array['image/jpeg', 'image/png', 'image/webp', 'application/pdf']),
  ('technician-photos', 'technician-photos', true, 5242880, array['image/jpeg', 'image/png', 'image/webp']),
  ('verification-documents', 'verification-documents', false, 10485760, array['image/jpeg', 'image/png', 'image/webp', 'application/pdf'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Public read policies ONLY for public media buckets (NEVER for verification-documents!)
drop policy if exists "public_read_repair_pro_media" on storage.objects;
create policy "public_read_repair_pro_media"
  on storage.objects for select
  using (bucket_id in ('community-photos', 'repair-pdfs', 'circuit-diagrams', 'technician-photos'));

-- Block direct unauthenticated uploads to storage.objects (all uploads go through verified Edge Functions with Multi-Cloud Failover)
drop policy if exists "deny_anon_direct_writes" on storage.objects;
create policy "deny_anon_direct_writes"
  on storage.objects for insert
  with check (false);
