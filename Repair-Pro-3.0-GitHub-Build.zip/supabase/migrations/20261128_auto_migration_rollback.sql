-- ============================================================================
-- Repair Pro: Optional Rollback Script for Automatic Cloud Migration Schema
-- Run ONLY if intentionally reverting the 20261128_auto_migration_and_failover
-- migration tracking objects. Core user/app data tables remain untouched.
-- ============================================================================

DROP FUNCTION IF EXISTS public.get_supabase_usage_metrics();

DROP POLICY IF EXISTS "cloud_manifest_admin_manage" ON public.cloud_manifest;
DROP POLICY IF EXISTS "cloud_manifest_public_read" ON public.cloud_manifest;
DROP POLICY IF EXISTS "cloud_backup_manifests_admin_manage" ON public.cloud_backup_manifests;
DROP POLICY IF EXISTS "cloud_migration_items_admin_manage" ON public.cloud_migration_items;
DROP POLICY IF EXISTS "cloud_migration_runs_admin_manage" ON public.cloud_migration_runs;

DROP TABLE IF EXISTS public.cloud_manifest;
DROP TABLE IF EXISTS public.cloud_migration_items;
DROP TABLE IF EXISTS public.cloud_migration_runs;
DROP TABLE IF EXISTS public.cloud_backup_manifests;

DELETE FROM public.app_settings WHERE setting_id = 'migration_config';
