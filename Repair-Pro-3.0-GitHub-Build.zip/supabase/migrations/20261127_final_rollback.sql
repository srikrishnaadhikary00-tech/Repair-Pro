-- Repair Pro — Safe Non-Destructive Rollback Script for Stage 1 / Stage 2 Security Migration
-- Restores compatibility public SELECT policies without deleting any tables, columns, buckets, or user rows.

BEGIN;

-- Restore public_read_app_settings if Stage 2 replaced it
DO $$
BEGIN
  IF to_regclass('public.app_settings') IS NOT NULL THEN
    DROP POLICY IF EXISTS "authenticated_read_app_settings" ON public.app_settings;
    DROP POLICY IF EXISTS "public_read_app_settings" ON public.app_settings;
    CREATE POLICY "public_read_app_settings" ON public.app_settings
      FOR SELECT USING (
        setting_id IN ('global_config', 'admob_config', 'storage_config', 'ai_config', 'billing_config')
      );
  END IF;
END $$;

COMMIT;
