-- Repair Pro — Stage 2 Post-Rollout Security Cleanup
-- Supabase Project Reference: xuakzzjtcgcvudkgxpbd
-- IMPORTANT: Run this script ONLY AFTER:
--   1. 20261127_final_security_and_admin_migration.sql (Stage 1) has succeeded,
--   2. Firebase Third-Party Auth is enabled in Supabase Dashboard -> Authentication -> Third-Party Auth,
--   3. Custom claims (`role: "authenticated"`) are applied via Edge Function or scripts/set-firebase-custom-claims.mjs,
--   4. Legacy pre-1.2.0 APK users have upgraded to versionCode >= 3 (1.2.0).

BEGIN;

-- Drop any legacy permissive anon/public policies that may have existed in older installs
DO $$
DECLARE
  pol RECORD;
BEGIN
  -- 1. Remove any anon-writable or overly broad storage.objects policies not owned by Stage 1
  FOR pol IN
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'storage'
      AND tablename = 'objects'
      AND (
        policyname ILIKE '%anon%'
        OR policyname ILIKE '%allow_all%'
        OR policyname ILIKE '%unrestricted%'
      )
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON storage.objects', pol.policyname);
  END LOOP;

  -- 2. Restrict public.app_settings / public.announcements / catalog SELECT to authenticated Firebase sessions
  IF to_regclass('public.app_settings') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_app_settings" ON public.app_settings;
    CREATE POLICY "authenticated_read_app_settings" ON public.app_settings
      FOR SELECT TO authenticated
      USING (
        setting_id IN ('global_config', 'admob_config', 'storage_config', 'ai_config', 'billing_config')
        OR public.is_repairpro_admin()
      );
  END IF;

  -- 3. Remove any leftover anon policies on protected user/admin tables
  FOR pol IN
    SELECT tablename, policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN (
        'user_profiles', 'technician_verification_requests', 'technician_customers',
        'technician_invoices', 'technician_invoice_payments', 'hosting_provider_secrets',
        'ai_usage_counters', 'audit_logs', 'push_notification_history'
      )
      AND (roles @> ARRAY['anon']::name[] OR roles @> ARRAY['public']::name[])
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', pol.policyname, pol.tablename);
  END LOOP;
END $$;

COMMIT;
