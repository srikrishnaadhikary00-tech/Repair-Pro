-- ============================================================================
-- Repair Pro: Additive Automatic Cloud Migration, Backup & Failover Schema
-- Safe additive migration: preserves all existing tables, rows, buckets & RLS.
-- ============================================================================

-- 1. Extend storage_providers constraint & tracking columns cleanly
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.storage_providers'::regclass
      AND conname = 'storage_providers_provider_type_check'
  ) THEN
    ALTER TABLE public.storage_providers DROP CONSTRAINT storage_providers_provider_type_check;
  END IF;
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;

ALTER TABLE public.storage_providers
  ADD CONSTRAINT storage_providers_provider_type_check
  CHECK (provider_type IN (
    'SUPABASE_STORAGE',
    'PHP_HOSTING',
    'EXTERNAL_DB',
    'S3_COMPATIBLE',
    'CLOUDFLARE_R2',
    'GOOGLE_CLOUD_STORAGE',
    'FIREBASE_LEGACY'
  ));

ALTER TABLE public.storage_providers
  ADD COLUMN IF NOT EXISTS hosting_vendor TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS public_media_base_url TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS community_only BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS supports_storage BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS supports_database BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS db_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS db_engine TEXT NOT NULL DEFAULT 'MYSQL',
  ADD COLUMN IF NOT EXISTS bucket_user_profiles TEXT NOT NULL DEFAULT 'user-avatars',
  ADD COLUMN IF NOT EXISTS category_mappings JSONB NOT NULL DEFAULT '{}'::JSONB,
  ADD COLUMN IF NOT EXISTS provider_metadata JSONB NOT NULL DEFAULT '{}'::JSONB,
  ADD COLUMN IF NOT EXISTS migration_threshold_pct INTEGER NOT NULL DEFAULT 80,
  ADD COLUMN IF NOT EXISTS db_limit_bytes BIGINT NOT NULL DEFAULT 524288000,
  ADD COLUMN IF NOT EXISTS db_used_bytes BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS health_details JSONB NOT NULL DEFAULT '{}'::JSONB;

-- 2. Additive migration/checksum tracking columns on core content tables
ALTER TABLE IF EXISTS public.community_posts
  ADD COLUMN IF NOT EXISTS storage_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  ADD COLUMN IF NOT EXISTS external_record_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migrated_to_provider_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS checksum_sha256 TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migration_status TEXT NOT NULL DEFAULT 'ACTIVE';

ALTER TABLE IF EXISTS public.technicians
  ADD COLUMN IF NOT EXISTS storage_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  ADD COLUMN IF NOT EXISTS external_record_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migrated_to_provider_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS checksum_sha256 TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migration_status TEXT NOT NULL DEFAULT 'ACTIVE';

ALTER TABLE IF EXISTS public.technician_verification_requests
  ADD COLUMN IF NOT EXISTS profile_photo_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  ADD COLUMN IF NOT EXISTS credential_doc_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  ADD COLUMN IF NOT EXISTS storage_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  ADD COLUMN IF NOT EXISTS external_record_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migrated_to_provider_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS checksum_sha256 TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migration_status TEXT NOT NULL DEFAULT 'ACTIVE';

ALTER TABLE IF EXISTS public.technical_documents
  ADD COLUMN IF NOT EXISTS storage_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  ADD COLUMN IF NOT EXISTS external_record_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migrated_to_provider_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS checksum_sha256 TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migration_status TEXT NOT NULL DEFAULT 'ACTIVE';

ALTER TABLE IF EXISTS public.problem_reports
  ADD COLUMN IF NOT EXISTS storage_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  ADD COLUMN IF NOT EXISTS external_record_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migrated_to_provider_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migration_status TEXT NOT NULL DEFAULT 'ACTIVE';

ALTER TABLE IF EXISTS public.repair_catalog_entries
  ADD COLUMN IF NOT EXISTS storage_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  ADD COLUMN IF NOT EXISTS external_record_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migrated_to_provider_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migration_status TEXT NOT NULL DEFAULT 'ACTIVE';

ALTER TABLE IF EXISTS public.user_profiles
  ADD COLUMN IF NOT EXISTS photo_storage_path TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS photo_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  ADD COLUMN IF NOT EXISTS migrated_to_provider_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS migration_status TEXT NOT NULL DEFAULT 'ACTIVE';

-- 3. Automatic Migration & Verified Backup Tracking Tables
CREATE TABLE IF NOT EXISTS public.cloud_migration_runs (
  run_id TEXT PRIMARY KEY,
  source_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  target_provider_id TEXT NOT NULL,
  trigger_mode TEXT NOT NULL DEFAULT 'MANUAL' CHECK (trigger_mode IN ('MANUAL', 'AUTO_DB', 'AUTO_STORAGE', 'FAILOVER_SYNC')),
  scope TEXT NOT NULL DEFAULT 'BOTH' CHECK (scope IN ('DATABASE', 'STORAGE', 'BOTH')),
  status TEXT NOT NULL DEFAULT 'RUNNING' CHECK (status IN ('PENDING', 'RUNNING', 'COMPLETED', 'PARTIAL', 'FAILED', 'ROLLED_BACK')),
  total_items INTEGER NOT NULL DEFAULT 0,
  migrated_items INTEGER NOT NULL DEFAULT 0,
  verified_items INTEGER NOT NULL DEFAULT 0,
  cleaned_items INTEGER NOT NULL DEFAULT 0,
  failed_items INTEGER NOT NULL DEFAULT 0,
  total_bytes BIGINT NOT NULL DEFAULT 0,
  backup_manifest_id TEXT NOT NULL DEFAULT '',
  last_cursor TEXT NOT NULL DEFAULT '',
  error_summary TEXT NOT NULL DEFAULT '',
  started_by_uid TEXT NOT NULL DEFAULT '',
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.cloud_migration_items (
  item_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL REFERENCES public.cloud_migration_runs(run_id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('table_row', 'storage_object')),
  table_or_bucket TEXT NOT NULL,
  record_or_path TEXT NOT NULL,
  source_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  target_provider_id TEXT NOT NULL,
  checksum_sha256 TEXT NOT NULL DEFAULT '',
  byte_size BIGINT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'COPIED', 'VERIFIED', 'ROUTED', 'CLEANED_UP', 'FAILED', 'ROLLED_BACK')),
  retry_count INTEGER NOT NULL DEFAULT 0,
  target_url TEXT NOT NULL DEFAULT '',
  error_message TEXT NOT NULL DEFAULT '',
  snapshot_json JSONB NOT NULL DEFAULT '{}'::JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cloud_migration_items_run_status
  ON public.cloud_migration_items (run_id, status);

CREATE TABLE IF NOT EXISTS public.cloud_backup_manifests (
  backup_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL DEFAULT '',
  source_provider_id TEXT NOT NULL DEFAULT 'supabase_primary',
  target_provider_id TEXT NOT NULL DEFAULT '',
  item_count INTEGER NOT NULL DEFAULT 0,
  total_bytes BIGINT NOT NULL DEFAULT 0,
  checksum_sha256 TEXT NOT NULL DEFAULT '',
  manifest_json JSONB NOT NULL DEFAULT '{}'::JSONB,
  status TEXT NOT NULL DEFAULT 'READY' CHECK (status IN ('READY', 'RESTORED', 'ARCHIVED')),
  created_by_uid TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.cloud_manifest (
  manifest_key TEXT PRIMARY KEY,
  payload_json JSONB NOT NULL DEFAULT '{}'::JSONB,
  config_version BIGINT NOT NULL DEFAULT 1,
  updated_by_uid TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. RLS Policies (Super Admin Only for Migration & Backup Tables; public read on app_settings migration_config)
ALTER TABLE public.cloud_migration_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cloud_migration_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cloud_backup_manifests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cloud_manifest ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "cloud_migration_runs_admin_manage" ON public.cloud_migration_runs;
CREATE POLICY "cloud_migration_runs_admin_manage" ON public.cloud_migration_runs
  FOR ALL TO authenticated
  USING (public.is_repairpro_admin())
  WITH CHECK (public.is_repairpro_admin());

DROP POLICY IF EXISTS "cloud_migration_items_admin_manage" ON public.cloud_migration_items;
CREATE POLICY "cloud_migration_items_admin_manage" ON public.cloud_migration_items
  FOR ALL TO authenticated
  USING (public.is_repairpro_admin())
  WITH CHECK (public.is_repairpro_admin());

DROP POLICY IF EXISTS "cloud_backup_manifests_admin_manage" ON public.cloud_backup_manifests;
CREATE POLICY "cloud_backup_manifests_admin_manage" ON public.cloud_backup_manifests
  FOR ALL TO authenticated
  USING (public.is_repairpro_admin())
  WITH CHECK (public.is_repairpro_admin());

DROP POLICY IF EXISTS "cloud_manifest_public_read" ON public.cloud_manifest;
CREATE POLICY "cloud_manifest_public_read" ON public.cloud_manifest
  FOR SELECT USING (TRUE);

DROP POLICY IF EXISTS "cloud_manifest_admin_manage" ON public.cloud_manifest;
CREATE POLICY "cloud_manifest_admin_manage" ON public.cloud_manifest
  FOR ALL TO authenticated
  USING (public.is_repairpro_admin())
  WITH CHECK (public.is_repairpro_admin());

DO $$
BEGIN
  IF to_regclass('public.app_settings') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_app_settings" ON public.app_settings;
    CREATE POLICY "public_read_app_settings" ON public.app_settings
      FOR SELECT USING (
        setting_id IN ('global_config', 'admob_config', 'storage_config', 'migration_config', 'ai_config', 'billing_config')
        OR public.is_repairpro_admin()
      );
  END IF;
END $$;

-- 5. Live Supabase Database & Storage Usage RPC (Admin Only, Non-Destructive)
CREATE OR REPLACE FUNCTION public.get_supabase_usage_metrics()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, storage
AS $$
DECLARE
  v_db_bytes BIGINT := 0;
  v_storage_bytes BIGINT := 0;
  v_storage_count BIGINT := 0;
  v_buckets JSONB := '[]'::JSONB;
  v_tables JSONB := '{}'::JSONB;
BEGIN
  IF NOT public.is_repairpro_admin() THEN
    RAISE EXCEPTION 'Admin privileges required for live usage metrics';
  END IF;

  v_db_bytes := pg_database_size(current_database())::BIGINT;

  SELECT
    COALESCE(SUM(COALESCE((metadata->>'size')::BIGINT, 0)), 0)::BIGINT,
    COALESCE(COUNT(*), 0)::BIGINT
  INTO v_storage_bytes, v_storage_count
  FROM storage.objects;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'bucketId', b.id,
        'objectCount', COALESCE(s.obj_count, 0),
        'usedBytes', COALESCE(s.total_bytes, 0)
      )
      ORDER BY b.id
    ),
    '[]'::JSONB
  )
  INTO v_buckets
  FROM storage.buckets b
  LEFT JOIN (
    SELECT
      bucket_id,
      COUNT(*)::BIGINT AS obj_count,
      COALESCE(SUM(COALESCE((metadata->>'size')::BIGINT, 0)), 0)::BIGINT AS total_bytes
    FROM storage.objects
    GROUP BY bucket_id
  ) s ON s.bucket_id = b.id;

  v_tables := jsonb_build_object(
    'community_posts', COALESCE((SELECT COUNT(*) FROM public.community_posts), 0),
    'technicians', COALESCE((SELECT COUNT(*) FROM public.technicians), 0),
    'technician_verification_requests', COALESCE((SELECT COUNT(*) FROM public.technician_verification_requests), 0),
    'technical_documents', COALESCE((SELECT COUNT(*) FROM public.technical_documents), 0),
    'problem_reports', COALESCE((SELECT COUNT(*) FROM public.problem_reports), 0),
    'repair_catalog_entries', COALESCE((SELECT COUNT(*) FROM public.repair_catalog_entries), 0),
    'user_profiles', COALESCE((SELECT COUNT(*) FROM public.user_profiles), 0)
  );

  RETURN jsonb_build_object(
    'ok', TRUE,
    'dbUsedBytes', v_db_bytes,
    'dbLimitBytes', 524288000,
    'storageUsedBytes', v_storage_bytes,
    'storageObjectCount', v_storage_count,
    'storageLimitBytes', 1073741824,
    'buckets', v_buckets,
    'tables', v_tables,
    'measuredAt', NOW()
  );
END;
$$;

REVOKE ALL ON FUNCTION public.get_supabase_usage_metrics() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_supabase_usage_metrics() TO authenticated;

-- 6. Seed non-secret default migration_config if absent
INSERT INTO public.app_settings (setting_id, config_type, payload, updated_by_uid)
VALUES (
  'migration_config',
  'MIGRATION',
  jsonb_build_object(
    'configType', 'MIGRATION',
    'autoFailoverEnabled', TRUE,
    'autoMigrationEnabled', FALSE,
    'autoCleanupEnabled', FALSE,
    'dbMigrationThresholdPct', 80,
    'storageMigrationThresholdPct', 80,
    'dbLimitBytes', 524288000,
    'storageLimitBytes', 1073741824,
    'fallbackDiscoveryUrls', jsonb_build_array(),
    'configVersion', 1
  ),
  'bootstrap_admin'
) ON CONFLICT (setting_id) DO NOTHING;
