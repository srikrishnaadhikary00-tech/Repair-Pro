-- Repair Pro Phase 2 — Additive, Non-Destructive Supabase Migration (Hardened + Atomic AI Quotas)
-- Supabase Project Reference: xuakzzjtcgcvudkgxpbd
-- Review carefully and run manually in Supabase Dashboard -> SQL Editor.
-- Safe & idempotent: guards optional tables from schema.sql via to_regclass() and never drops existing tables/data.

BEGIN;

-- 1. Safely extend storage_providers & community_posts ONLY if those tables already exist
DO $$
BEGIN
  IF to_regclass('public.storage_providers') IS NOT NULL THEN
    ALTER TABLE public.storage_providers
      DROP CONSTRAINT IF EXISTS storage_providers_provider_type_check;

    ALTER TABLE public.storage_providers
      ADD CONSTRAINT storage_providers_provider_type_check
      CHECK (provider_type IN (
        'SUPABASE_STORAGE',
        'PHP_HOSTING',
        'S3_COMPATIBLE',
        'CLOUDFLARE_R2',
        'GOOGLE_CLOUD_STORAGE',
        'FIREBASE_LEGACY'
      ));

    ALTER TABLE public.storage_providers
      ADD COLUMN IF NOT EXISTS hosting_vendor TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS public_media_base_url TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS health_check_path TEXT NOT NULL DEFAULT '?action=health',
      ADD COLUMN IF NOT EXISTS provider_metadata JSONB NOT NULL DEFAULT '{}'::JSONB;
  END IF;

  IF to_regclass('public.community_posts') IS NOT NULL THEN
    ALTER TABLE public.community_posts
      ADD COLUMN IF NOT EXISTS photo_provider_ids TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[];
  END IF;
END $$;

-- 2. Private Server-Only Hosting & AI Provider Secrets (NEVER exposed via PostgREST anon key)
CREATE TABLE IF NOT EXISTS public.hosting_provider_secrets (
  provider_id TEXT PRIMARY KEY,
  auth_mode TEXT NOT NULL DEFAULT 'BEARER_OR_HMAC',
  api_secret TEXT NOT NULL DEFAULT '',
  custom_headers JSONB NOT NULL DEFAULT '{}'::JSONB,
  updated_by_uid TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.hosting_provider_secrets ENABLE ROW LEVEL SECURITY;
-- Zero public policies on hosting_provider_secrets: accessible ONLY to Edge Functions using service_role!

-- 3. AI Smart Repair Assistant Usage, Atomic Daily Counters & Error Logs
CREATE TABLE IF NOT EXISTS public.ai_usage_logs (
  usage_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  usage_date DATE NOT NULL DEFAULT CURRENT_DATE,
  provider_id TEXT NOT NULL DEFAULT '',
  provider TEXT NOT NULL DEFAULT 'GEMINI',
  model_name TEXT NOT NULL DEFAULT '',
  appliance TEXT NOT NULL DEFAULT '',
  language TEXT NOT NULL DEFAULT 'en' CHECK (language IN ('en', 'bn', 'hi')),
  tokens_estimated INTEGER NOT NULL DEFAULT 0,
  is_free BOOLEAN NOT NULL DEFAULT TRUE,
  failover_used BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'SUCCESS' CHECK (status IN ('SUCCESS', 'RATE_LIMITED', 'FAILED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Ensure additive columns exist even if ai_usage_logs was created by an earlier Phase 2 run
ALTER TABLE public.ai_usage_logs
  ADD COLUMN IF NOT EXISTS provider_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS is_free BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS failover_used BOOLEAN NOT NULL DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_ai_usage_date_user
  ON public.ai_usage_logs (usage_date, user_id);

CREATE INDEX IF NOT EXISTS idx_ai_usage_date_provider
  ON public.ai_usage_logs (usage_date, provider_id);

CREATE TABLE IF NOT EXISTS public.ai_usage_counters (
  usage_date DATE NOT NULL,
  scope_key TEXT NOT NULL,
  used_count INTEGER NOT NULL DEFAULT 0 CHECK (used_count >= 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (usage_date, scope_key)
);

ALTER TABLE public.ai_usage_counters ENABLE ROW LEVEL SECURITY;
-- Zero public policies on ai_usage_counters: mutated atomically ONLY via service_role RPC!

CREATE TABLE IF NOT EXISTS public.ai_error_logs (
  error_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL DEFAULT '',
  provider_id TEXT NOT NULL DEFAULT '',
  provider TEXT NOT NULL DEFAULT '',
  model_name TEXT NOT NULL DEFAULT '',
  error_code TEXT NOT NULL DEFAULT '',
  error_message TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.ai_error_logs
  ADD COLUMN IF NOT EXISTS provider_id TEXT NOT NULL DEFAULT '';

ALTER TABLE public.ai_usage_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_error_logs ENABLE ROW LEVEL SECURITY;

-- Atomic server-side quota reservation (prevents concurrent race conditions / quota bypass)
CREATE OR REPLACE FUNCTION public.reserve_ai_quota(
  p_usage_date DATE,
  p_user_id TEXT,
  p_provider_id TEXT,
  p_global_limit INTEGER,
  p_user_limit INTEGER,
  p_provider_limit INTEGER
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_global_key TEXT := 'global';
  v_provider_key TEXT := 'provider:' || COALESCE(NULLIF(trim(p_provider_id), ''), 'default');
  v_user_key TEXT := 'user:' || COALESCE(NULLIF(trim(p_user_id), ''), 'anonymous');
  v_global_used INTEGER := 0;
  v_provider_used INTEGER := 0;
  v_user_used INTEGER := 0;
BEGIN
  -- Ensure counter rows exist without failing under concurrency
  INSERT INTO public.ai_usage_counters (usage_date, scope_key, used_count)
  VALUES
    (p_usage_date, v_global_key, 0),
    (p_usage_date, v_provider_key, 0),
    (p_usage_date, v_user_key, 0)
  ON CONFLICT (usage_date, scope_key) DO NOTHING;

  -- Lock rows in deterministic alphabetical scope_key order to prevent deadlocks
  SELECT used_count INTO v_global_used
  FROM public.ai_usage_counters
  WHERE usage_date = p_usage_date AND scope_key = v_global_key
  FOR UPDATE;

  SELECT used_count INTO v_provider_used
  FROM public.ai_usage_counters
  WHERE usage_date = p_usage_date AND scope_key = v_provider_key
  FOR UPDATE;

  SELECT used_count INTO v_user_used
  FROM public.ai_usage_counters
  WHERE usage_date = p_usage_date AND scope_key = v_user_key
  FOR UPDATE;

  IF p_global_limit > 0 AND v_global_used >= p_global_limit THEN
    RETURN jsonb_build_object(
      'allowed', FALSE,
      'blocked_scope', 'global',
      'reason', 'Global daily AI quota reached. Please try again tomorrow.',
      'global_used', v_global_used,
      'user_used', v_user_used,
      'provider_used', v_provider_used
    );
  END IF;

  IF p_user_limit > 0 AND v_user_used >= p_user_limit THEN
    RETURN jsonb_build_object(
      'allowed', FALSE,
      'blocked_scope', 'user',
      'reason', format('Your daily AI limit (%s requests/day) has been reached.', p_user_limit),
      'global_used', v_global_used,
      'user_used', v_user_used,
      'provider_used', v_provider_used
    );
  END IF;

  IF p_provider_limit > 0 AND v_provider_used >= p_provider_limit THEN
    RETURN jsonb_build_object(
      'allowed', FALSE,
      'blocked_scope', 'provider',
      'reason', format('Provider daily quota (%s requests/day) reached.', p_provider_limit),
      'global_used', v_global_used,
      'user_used', v_user_used,
      'provider_used', v_provider_used
    );
  END IF;

  UPDATE public.ai_usage_counters
  SET used_count = used_count + 1, updated_at = NOW()
  WHERE usage_date = p_usage_date
    AND scope_key IN (v_global_key, v_provider_key, v_user_key);

  RETURN jsonb_build_object(
    'allowed', TRUE,
    'blocked_scope', '',
    'reason', '',
    'global_used', v_global_used + 1,
    'user_used', v_user_used + 1,
    'provider_used', v_provider_used + 1
  );
END;
$$;

-- Refund reserved slot cleanly if upstream AI call failed before generating a diagnosis
CREATE OR REPLACE FUNCTION public.release_ai_quota(
  p_usage_date DATE,
  p_user_id TEXT,
  p_provider_id TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_global_key TEXT := 'global';
  v_provider_key TEXT := 'provider:' || COALESCE(NULLIF(trim(p_provider_id), ''), 'default');
  v_user_key TEXT := 'user:' || COALESCE(NULLIF(trim(p_user_id), ''), 'anonymous');
BEGIN
  UPDATE public.ai_usage_counters
  SET used_count = GREATEST(0, used_count - 1), updated_at = NOW()
  WHERE usage_date = p_usage_date
    AND scope_key IN (v_global_key, v_provider_key, v_user_key);
END;
$$;

REVOKE ALL ON FUNCTION public.reserve_ai_quota(DATE, TEXT, TEXT, INTEGER, INTEGER, INTEGER) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.reserve_ai_quota(DATE, TEXT, TEXT, INTEGER, INTEGER, INTEGER) TO service_role;

REVOKE ALL ON FUNCTION public.release_ai_quota(DATE, TEXT, TEXT) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.release_ai_quota(DATE, TEXT, TEXT) TO service_role;

-- 4. Technician Billing Cloud Backup Tables (strictly technician-scoped via Edge/Service or JWT)
CREATE TABLE IF NOT EXISTS public.technician_customers (
  customer_id TEXT PRIMARY KEY,
  technician_uid TEXT NOT NULL,
  name TEXT NOT NULL,
  mobile_number TEXT NOT NULL,
  address TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tech_customers_owner
  ON public.technician_customers (technician_uid, updated_at DESC);

CREATE TABLE IF NOT EXISTS public.technician_invoices (
  invoice_id TEXT PRIMARY KEY,
  invoice_number TEXT NOT NULL,
  technician_uid TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  customer_mobile TEXT NOT NULL,
  customer_address TEXT NOT NULL DEFAULT '',
  appliance_category TEXT NOT NULL DEFAULT '',
  appliance_brand TEXT NOT NULL DEFAULT '',
  model_number TEXT NOT NULL DEFAULT '',
  serial_number TEXT NOT NULL DEFAULT '',
  reported_problem TEXT NOT NULL DEFAULT '',
  work_done TEXT NOT NULL DEFAULT '',
  parts_used TEXT NOT NULL DEFAULT '',
  parts_quantity INTEGER NOT NULL DEFAULT 0,
  parts_charges NUMERIC(12, 2),
  service_charges NUMERIC(12, 2),
  visiting_charges NUMERIC(12, 2),
  other_charges NUMERIC(12, 2),
  discount_amount NUMERIC(12, 2),
  total_bill NUMERIC(12, 2),
  amount_received NUMERIC(12, 2),
  remaining_balance NUMERIC(12, 2),
  payment_status TEXT NOT NULL DEFAULT 'AMOUNT_NOT_ENTERED'
    CHECK (payment_status IN ('FULLY_PAID', 'PARTIALLY_PAID', 'UNPAID', 'AMOUNT_NOT_ENTERED')),
  payment_method TEXT NOT NULL DEFAULT '',
  payment_due_date TEXT NOT NULL DEFAULT '',
  warranty_info TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  reminder_date TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tech_invoices_owner
  ON public.technician_invoices (technician_uid, updated_at DESC);

CREATE TABLE IF NOT EXISTS public.technician_invoice_payments (
  payment_id TEXT PRIMARY KEY,
  invoice_id TEXT NOT NULL,
  technician_uid TEXT NOT NULL,
  amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
  payment_method TEXT NOT NULL DEFAULT 'CASH',
  note TEXT NOT NULL DEFAULT '',
  idempotency_key TEXT NOT NULL DEFAULT '',
  paid_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tech_payments_invoice
  ON public.technician_invoice_payments (technician_uid, invoice_id, paid_at DESC);

ALTER TABLE public.technician_customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.technician_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.technician_invoice_payments ENABLE ROW LEVEL SECURITY;

-- 5. Safely extend app_settings read policy ONLY if public.app_settings exists
DO $$
BEGIN
  IF to_regclass('public.app_settings') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_app_settings" ON public.app_settings;
    CREATE POLICY "public_read_app_settings" ON public.app_settings
      FOR SELECT USING (
        setting_id IN ('global_config', 'admob_config', 'storage_config', 'ai_config', 'billing_config')
      );
  END IF;
END $$;

COMMIT;
