-- Repair Pro Phase 2 — Safe Rollback Script
-- Run manually in Supabase SQL Editor ONLY if rolling back Phase 2 schema additions.
-- Does NOT drop existing Repair Pro core tables or Supabase Storage buckets.

BEGIN;

DO $$
BEGIN
  IF to_regclass('public.app_settings') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_app_settings" ON public.app_settings;
    CREATE POLICY "public_read_app_settings" ON public.app_settings
      FOR SELECT USING (setting_id IN ('global_config', 'admob_config', 'storage_config'));
  END IF;
END $$;

DROP FUNCTION IF EXISTS public.release_ai_quota(DATE, TEXT, TEXT);
DROP FUNCTION IF EXISTS public.reserve_ai_quota(DATE, TEXT, TEXT, INTEGER, INTEGER, INTEGER);

DROP TABLE IF EXISTS public.technician_invoice_payments;
DROP TABLE IF EXISTS public.technician_invoices;
DROP TABLE IF EXISTS public.technician_customers;
DROP TABLE IF EXISTS public.ai_error_logs;
DROP TABLE IF EXISTS public.ai_usage_counters;
DROP TABLE IF EXISTS public.ai_usage_logs;
DROP TABLE IF EXISTS public.hosting_provider_secrets;

DO $$
BEGIN
  IF to_regclass('public.community_posts') IS NOT NULL THEN
    ALTER TABLE public.community_posts
      DROP COLUMN IF EXISTS photo_provider_ids;
  END IF;

  IF to_regclass('public.storage_providers') IS NOT NULL THEN
    ALTER TABLE public.storage_providers
      DROP COLUMN IF EXISTS hosting_vendor,
      DROP COLUMN IF EXISTS public_media_base_url,
      DROP COLUMN IF EXISTS health_check_path,
      DROP COLUMN IF EXISTS provider_metadata;

    ALTER TABLE public.storage_providers
      DROP CONSTRAINT IF EXISTS storage_providers_provider_type_check;

    ALTER TABLE public.storage_providers
      ADD CONSTRAINT storage_providers_provider_type_check
      CHECK (provider_type IN (
        'SUPABASE_STORAGE',
        'S3_COMPATIBLE',
        'CLOUDFLARE_R2',
        'GOOGLE_CLOUD_STORAGE',
        'FIREBASE_LEGACY'
      ));
  END IF;
END $$;

COMMIT;
