-- Repair Pro — Rollback / Verification Notes for 20261128_complete_supabase_migration.sql
-- Do NOT blindly drop tables containing live migrated user records.
-- Use these targeted statements ONLY if you need to revert specific new policies or RPCs:

-- DROP FUNCTION IF EXISTS public.toggle_community_like(TEXT);
-- DROP FUNCTION IF EXISTS public.add_community_comment(TEXT, TEXT, TEXT, TEXT, TEXT, BOOLEAN, TEXT);
-- DROP FUNCTION IF EXISTS public.delete_community_comment(TEXT, TEXT);
-- DROP FUNCTION IF EXISTS public.submit_community_report(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT);

-- DROP POLICY IF EXISTS "technician_photos_owner_or_admin_insert" ON storage.objects;
-- DROP POLICY IF EXISTS "technician_photos_owner_or_admin_update" ON storage.objects;
-- DROP POLICY IF EXISTS "technician_photos_owner_or_admin_delete" ON storage.objects;
-- DROP POLICY IF EXISTS "user_avatars_auth_insert" ON storage.objects;
-- DROP POLICY IF EXISTS "user_avatars_auth_update" ON storage.objects;
-- DROP POLICY IF EXISTS "user_avatars_auth_delete" ON storage.objects;
