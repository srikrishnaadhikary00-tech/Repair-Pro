-- Rollback for 20261128_community_all_users_and_cron_migration.sql
-- Removes only additive scheduler table/functions without deleting user/community data.

DROP FUNCTION IF EXISTS public.reclaim_migrated_record_safe(TEXT, TEXT, TEXT);
DROP FUNCTION IF EXISTS public.release_cloud_scheduler_lock(TEXT, TEXT, TEXT, TEXT, INTEGER, INTEGER, BIGINT);
DROP FUNCTION IF EXISTS public.acquire_cloud_scheduler_lock(TEXT, TEXT, INTEGER, TEXT);
DROP TABLE IF EXISTS public.cloud_scheduler_status;
DROP FUNCTION IF EXISTS public.can_user_upload_community_photo();
DROP FUNCTION IF EXISTS public.can_user_comment_community();
DROP FUNCTION IF EXISTS public.can_user_post_community();
