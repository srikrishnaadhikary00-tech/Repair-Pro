-- Repair Pro — Final Stable Release: Stage 1 Additive Security & Admin Full-Control Migration
-- Supabase Project Reference: xuakzzjtcgcvudkgxpbd
-- SAFE & IDEMPOTENT: Never drops existing tables, buckets, or user data.
-- Run Stage 1 BEFORE or alongside the v1.2.0 (versionCode 3) APK rollout.
-- After all active APK users upgrade to v1.2.0, optionally run 20261127_remove_temp_anon_policies.sql.

BEGIN;

-- =========================================================================
-- 1. FIREBASE THIRD-PARTY AUTH JWT HELPERS (Supabase Auth -> Firebase)
-- =========================================================================
-- Expects Firebase ID token in Authorization: Bearer <idToken> with custom claim role = 'authenticated'.
CREATE OR REPLACE FUNCTION public.firebase_uid()
RETURNS TEXT
LANGUAGE SQL
STABLE
AS $$
  SELECT COALESCE(
    NULLIF(auth.jwt() ->> 'sub', ''),
    NULLIF(auth.jwt() ->> 'user_id', ''),
    ''
  );
$$;

CREATE OR REPLACE FUNCTION public.is_repairpro_admin()
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_email TEXT := LOWER(COALESCE(auth.jwt() ->> 'email', ''));
  v_email_verified BOOLEAN := LOWER(COALESCE(auth.jwt() ->> 'email_verified', 'false')) = 'true';
  v_claim_admin BOOLEAN := LOWER(COALESCE(auth.jwt() ->> 'admin', 'false')) = 'true'
                           OR LOWER(COALESCE(auth.jwt() -> 'claims' ->> 'admin', 'false')) = 'true';
  v_claim_role TEXT := COALESCE(auth.jwt() ->> 'repairproRole', auth.jwt() ->> 'role', '');
  v_in_table BOOLEAN := FALSE;
BEGIN
  IF v_uid = '' THEN
    RETURN FALSE;
  END IF;

  IF v_email_verified AND v_email = 'srikrishnaadhikary00@gmail.com' THEN
    RETURN TRUE;
  END IF;

  IF v_claim_admin OR v_claim_role = 'SUPER_ADMIN' THEN
    RETURN TRUE;
  END IF;

  IF to_regclass('public.admin_roles') IS NOT NULL THEN
    SELECT EXISTS(
      SELECT 1 FROM public.admin_roles WHERE user_id = v_uid
    ) INTO v_in_table;
    IF v_in_table THEN
      RETURN TRUE;
    END IF;
  END IF;

  RETURN FALSE;
END;
$$;

CREATE OR REPLACE FUNCTION public.is_user_active()
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid TEXT := public.firebase_uid();
  v_blocked_claim BOOLEAN := LOWER(COALESCE(auth.jwt() ->> 'blocked', 'false')) = 'true'
                             OR LOWER(COALESCE(auth.jwt() ->> 'suspended', 'false')) = 'true';
  v_profile_blocked BOOLEAN := FALSE;
BEGIN
  IF v_uid = '' THEN
    RETURN FALSE;
  END IF;

  IF public.is_repairpro_admin() THEN
    RETURN TRUE;
  END IF;

  IF v_blocked_claim THEN
    RETURN FALSE;
  END IF;

  IF to_regclass('public.user_profiles') IS NOT NULL THEN
    SELECT COALESCE(bool_or(blocked OR suspended), FALSE)
    INTO v_profile_blocked
    FROM public.user_profiles
    WHERE user_id = v_uid;
    IF v_profile_blocked THEN
      RETURN FALSE;
    END IF;
  END IF;

  RETURN TRUE;
END;
$$;

-- =========================================================================
-- 2. ADDITIVE COLUMNS FOR MODERATION, SOFT-DELETE & OFFLINE SYNC CONTROL
-- =========================================================================
DO $$
BEGIN
  IF to_regclass('public.user_profiles') IS NOT NULL THEN
    ALTER TABLE public.user_profiles
      ADD COLUMN IF NOT EXISTS account_status TEXT NOT NULL DEFAULT 'ACTIVE',
      ADD COLUMN IF NOT EXISTS blocked BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS suspended BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS community_restricted BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS upload_restricted BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS moderation_reason TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS moderated_by_uid TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS moderated_at TIMESTAMPTZ;
  END IF;

  IF to_regclass('public.community_posts') IS NOT NULL THEN
    ALTER TABLE public.community_posts
      ADD COLUMN IF NOT EXISTS photo_provider_ids TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
      ADD COLUMN IF NOT EXISTS is_hidden BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS deleted_by_uid TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;
  END IF;

  IF to_regclass('public.technicians') IS NOT NULL THEN
    ALTER TABLE public.technicians
      ADD COLUMN IF NOT EXISTS is_suspended BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;
  END IF;

  IF to_regclass('public.technical_documents') IS NOT NULL THEN
    ALTER TABLE public.technical_documents
      ADD COLUMN IF NOT EXISTS offline_available BOOLEAN NOT NULL DEFAULT TRUE,
      ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN NOT NULL DEFAULT FALSE;
  END IF;

  IF to_regclass('public.audit_logs') IS NOT NULL THEN
    ALTER TABLE public.audit_logs
      ADD COLUMN IF NOT EXISTS result TEXT NOT NULL DEFAULT 'SUCCESS';
  END IF;
END $$;

-- =========================================================================
-- 3. HARDEN STORAGE BUCKETS & AUTHENTICATED FIREBASE JWT STORAGE POLICIES
-- =========================================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  ('community-photos', 'community-photos', TRUE, 5242880, ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp']),
  ('technician-photos', 'technician-photos', TRUE, 5242880, ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp']),
  ('repair-pdfs', 'repair-pdfs', TRUE, 20971520, ARRAY['application/pdf']),
  ('circuit-diagrams', 'circuit-diagrams', TRUE, 20971520, ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf']),
  ('verification-documents', 'verification-documents', FALSE, 10485760, ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf'])
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- Public read on non-sensitive public media buckets
DROP POLICY IF EXISTS "public_read_media_buckets" ON storage.objects;
CREATE POLICY "public_read_media_buckets" ON storage.objects
  FOR SELECT USING (
    bucket_id IN ('community-photos', 'technician-photos', 'repair-pdfs', 'circuit-diagrams')
  );

-- Private verification-documents read: ONLY owner UID folder or verified Admin
DROP POLICY IF EXISTS "verification_docs_owner_or_admin_read" ON storage.objects;
CREATE POLICY "verification_docs_owner_or_admin_read" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'verification-documents'
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
    )
  );

-- Community photos upload/delete: Active Firebase-authenticated owner (in ${uid}/... or legacy prefix) or Admin
DROP POLICY IF EXISTS "community_photos_auth_insert" ON storage.objects;
CREATE POLICY "community_photos_auth_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'community-photos'
    AND public.is_user_active()
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

DROP POLICY IF EXISTS "community_photos_auth_delete" ON storage.objects;
CREATE POLICY "community_photos_auth_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'community-photos'
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

-- Verification documents upload/delete: Active owner UID folder or Admin
DROP POLICY IF EXISTS "verification_docs_auth_insert" ON storage.objects;
CREATE POLICY "verification_docs_auth_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'verification-documents'
    AND public.is_user_active()
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

DROP POLICY IF EXISTS "verification_docs_auth_delete" ON storage.objects;
CREATE POLICY "verification_docs_auth_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'verification-documents'
    AND (
      public.is_repairpro_admin()
      OR (storage.foldername(name))[1] = public.firebase_uid()
      OR name LIKE (public.firebase_uid() || '/%')
    )
  );

-- Admin-only storage writes & deletes for technician-photos, repair-pdfs, circuit-diagrams
DROP POLICY IF EXISTS "admin_buckets_insert" ON storage.objects;
CREATE POLICY "admin_buckets_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id IN ('technician-photos', 'repair-pdfs', 'circuit-diagrams')
    AND public.is_repairpro_admin()
  );

DROP POLICY IF EXISTS "admin_buckets_update" ON storage.objects;
CREATE POLICY "admin_buckets_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id IN ('technician-photos', 'repair-pdfs', 'circuit-diagrams', 'community-photos', 'verification-documents')
    AND public.is_repairpro_admin()
  );

DROP POLICY IF EXISTS "admin_buckets_delete" ON storage.objects;
CREATE POLICY "admin_buckets_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id IN ('technician-photos', 'repair-pdfs', 'circuit-diagrams')
    AND public.is_repairpro_admin()
  );

-- =========================================================================
-- 4. AUTHENTICATED FIREBASE JWT RLS POLICIES ON PUBLIC TABLES
-- =========================================================================
DO $$
BEGIN
  -- User profiles: owner or admin
  IF to_regclass('public.user_profiles') IS NOT NULL THEN
    DROP POLICY IF EXISTS "user_profiles_owner_or_admin_select" ON public.user_profiles;
    CREATE POLICY "user_profiles_owner_or_admin_select" ON public.user_profiles
      FOR SELECT TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "user_profiles_owner_insert" ON public.user_profiles;
    CREATE POLICY "user_profiles_owner_insert" ON public.user_profiles
      FOR INSERT TO authenticated
      WITH CHECK (
        (user_id = public.firebase_uid() AND blocked = FALSE AND suspended = FALSE)
        OR public.is_repairpro_admin()
      );

    DROP POLICY IF EXISTS "user_profiles_owner_or_admin_update" ON public.user_profiles;
    CREATE POLICY "user_profiles_owner_or_admin_update" ON public.user_profiles
      FOR UPDATE TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin())
      WITH CHECK (user_id = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  -- Published catalog, active non-suspended technicians, non-deleted docs, visible approved posts
  IF to_regclass('public.repair_catalog_entries') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_published_catalog" ON public.repair_catalog_entries;
    CREATE POLICY "public_read_published_catalog" ON public.repair_catalog_entries
      FOR SELECT USING (published = TRUE OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "admin_manage_catalog" ON public.repair_catalog_entries;
    CREATE POLICY "admin_manage_catalog" ON public.repair_catalog_entries
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  IF to_regclass('public.technicians') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_active_technicians" ON public.technicians;
    CREATE POLICY "public_read_active_technicians" ON public.technicians
      FOR SELECT USING (
        (status = 'ACTIVE' AND blocked = FALSE AND is_suspended = FALSE AND is_deleted = FALSE)
        OR public.is_repairpro_admin()
      );

    DROP POLICY IF EXISTS "admin_manage_technicians" ON public.technicians;
    CREATE POLICY "admin_manage_technicians" ON public.technicians
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  IF to_regclass('public.technical_documents') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_published_docs" ON public.technical_documents;
    CREATE POLICY "public_read_published_docs" ON public.technical_documents
      FOR SELECT USING (
        (published = TRUE AND is_deleted = FALSE)
        OR public.is_repairpro_admin()
      );

    DROP POLICY IF EXISTS "admin_manage_docs" ON public.technical_documents;
    CREATE POLICY "admin_manage_docs" ON public.technical_documents
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  IF to_regclass('public.community_posts') IS NOT NULL THEN
    DROP POLICY IF EXISTS "public_read_approved_posts" ON public.community_posts;
    CREATE POLICY "public_read_approved_posts" ON public.community_posts
      FOR SELECT USING (
        (approval_status = 'APPROVED' AND is_hidden = FALSE AND is_deleted = FALSE)
        OR author_uid = public.firebase_uid()
        OR public.is_repairpro_admin()
      );

    DROP POLICY IF EXISTS "community_posts_auth_write" ON public.community_posts;
    CREATE POLICY "community_posts_auth_write" ON public.community_posts
      FOR INSERT TO authenticated
      WITH CHECK (
        public.is_user_active()
        AND (author_uid = public.firebase_uid() OR public.is_repairpro_admin())
      );

    DROP POLICY IF EXISTS "community_posts_owner_or_admin_update" ON public.community_posts;
    CREATE POLICY "community_posts_owner_or_admin_update" ON public.community_posts
      FOR UPDATE TO authenticated
      USING (author_uid = public.firebase_uid() OR public.is_repairpro_admin())
      WITH CHECK (author_uid = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "community_posts_owner_or_admin_delete" ON public.community_posts;
    CREATE POLICY "community_posts_owner_or_admin_delete" ON public.community_posts
      FOR DELETE TO authenticated
      USING (author_uid = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  -- Verification requests: owner or admin ONLY
  IF to_regclass('public.technician_verification_requests') IS NOT NULL THEN
    DROP POLICY IF EXISTS "verification_requests_owner_or_admin" ON public.technician_verification_requests;
    CREATE POLICY "verification_requests_owner_or_admin" ON public.technician_verification_requests
      FOR ALL TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin())
      WITH CHECK (
        (user_id = public.firebase_uid() AND public.is_user_active())
        OR public.is_repairpro_admin()
      );
  END IF;

  -- Storage upload history & error logs
  IF to_regclass('public.storage_upload_history') IS NOT NULL THEN
    DROP POLICY IF EXISTS "storage_history_owner_or_admin" ON public.storage_upload_history;
    CREATE POLICY "storage_history_owner_or_admin" ON public.storage_upload_history
      FOR SELECT TO authenticated
      USING (uploaded_by_uid = public.firebase_uid() OR public.is_repairpro_admin());

    DROP POLICY IF EXISTS "storage_history_insert" ON public.storage_upload_history;
    CREATE POLICY "storage_history_insert" ON public.storage_upload_history
      FOR INSERT TO authenticated
      WITH CHECK (uploaded_by_uid = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  IF to_regclass('public.storage_error_logs') IS NOT NULL THEN
    DROP POLICY IF EXISTS "storage_errors_admin_select" ON public.storage_error_logs;
    CREATE POLICY "storage_errors_admin_select" ON public.storage_error_logs
      FOR SELECT TO authenticated
      USING (public.is_repairpro_admin());

    DROP POLICY IF EXISTS "storage_errors_auth_insert" ON public.storage_error_logs;
    CREATE POLICY "storage_errors_auth_insert" ON public.storage_error_logs
      FOR INSERT TO authenticated
      WITH CHECK (actor_uid = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  -- Technician billing cloud backup tables: strict technician owner isolation
  IF to_regclass('public.technician_customers') IS NOT NULL THEN
    DROP POLICY IF EXISTS "tech_customers_owner_only" ON public.technician_customers;
    CREATE POLICY "tech_customers_owner_only" ON public.technician_customers
      FOR ALL TO authenticated
      USING (technician_uid = public.firebase_uid())
      WITH CHECK (technician_uid = public.firebase_uid());
  END IF;

  IF to_regclass('public.technician_invoices') IS NOT NULL THEN
    DROP POLICY IF EXISTS "tech_invoices_owner_only" ON public.technician_invoices;
    CREATE POLICY "tech_invoices_owner_only" ON public.technician_invoices
      FOR ALL TO authenticated
      USING (technician_uid = public.firebase_uid())
      WITH CHECK (technician_uid = public.firebase_uid());
  END IF;

  IF to_regclass('public.technician_invoice_payments') IS NOT NULL THEN
    DROP POLICY IF EXISTS "tech_payments_owner_only" ON public.technician_invoice_payments;
    CREATE POLICY "tech_payments_owner_only" ON public.technician_invoice_payments
      FOR ALL TO authenticated
      USING (technician_uid = public.firebase_uid())
      WITH CHECK (technician_uid = public.firebase_uid());
  END IF;

  -- AI logs: own user read or admin read; mutations stay service_role/RPC only
  IF to_regclass('public.ai_usage_logs') IS NOT NULL THEN
    DROP POLICY IF EXISTS "ai_usage_owner_or_admin_read" ON public.ai_usage_logs;
    CREATE POLICY "ai_usage_owner_or_admin_read" ON public.ai_usage_logs
      FOR SELECT TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;

  IF to_regclass('public.ai_error_logs') IS NOT NULL THEN
    DROP POLICY IF EXISTS "ai_errors_admin_read" ON public.ai_error_logs;
    CREATE POLICY "ai_errors_admin_read" ON public.ai_error_logs
      FOR SELECT TO authenticated
      USING (public.is_repairpro_admin());
  END IF;

  -- Audit logs & admin roles
  IF to_regclass('public.audit_logs') IS NOT NULL THEN
    DROP POLICY IF EXISTS "audit_logs_admin_only" ON public.audit_logs;
    CREATE POLICY "audit_logs_admin_only" ON public.audit_logs
      FOR ALL TO authenticated
      USING (public.is_repairpro_admin())
      WITH CHECK (public.is_repairpro_admin());
  END IF;

  IF to_regclass('public.admin_roles') IS NOT NULL THEN
    DROP POLICY IF EXISTS "admin_roles_self_or_admin" ON public.admin_roles;
    CREATE POLICY "admin_roles_self_or_admin" ON public.admin_roles
      FOR SELECT TO authenticated
      USING (user_id = public.firebase_uid() OR public.is_repairpro_admin());
  END IF;
END $$;

COMMIT;
