# Repair Pro — Automatic Cloud Migration, Failover & Direct Multi-Cloud Access Guide

This guide covers operating **Repair Pro** in **Supabase-primary mode** today and connecting a future **cPanel PHP + MySQL** hosting server directly from the **Web Admin Panel** with **zero Android APK updates**.

---

## 1. Current Operation (Supabase Primary — No cPanel Yet)

- **Firebase** (`gen-lang-client-0218221723`) is used **only** for:
  - Google Sign-In & Firebase Authentication / Session Management
  - Firebase Cloud Messaging (FCM) via `https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-push-notification`
- **Supabase** (`https://xuakzzjtcgcvudkgxpbd.supabase.co`) remains the active primary **Database** and **File Storage** provider.
- While no cPanel provider is connected and enabled:
  - All user app reads, writes, photo compression/deduplication, PDF uploads, verification documents, and admin actions run directly on Supabase.
  - `autoMigrationEnabled` and `autoCleanupEnabled` default to `false`.
  - **No Supabase records or files are ever modified or deleted** when secondary hosting is unavailable.

### Apply Additive Supabase Migration (Safe, Non-Destructive)

Run both additive SQL migrations once in the Supabase SQL Editor (neither drops, resets, or truncates any existing tables or rows):

- Migration 1: `supabase/migrations/20261128_auto_migration_and_failover.sql` (rollback: `supabase/migrations/20261128_auto_migration_rollback.sql`)
- Migration 2: `supabase/migrations/20261128_community_all_users_and_cron_migration.sql` (rollback: `supabase/migrations/20261128_community_all_users_and_cron_rollback.sql`)

They add:
- Migration tracking & scheduler tables: `cloud_migration_runs`, `cloud_migration_items`, `cloud_backup_manifests`, `cloud_manifest`, `cloud_scheduler_status`
- Additive tracking columns (`storage_provider_id`, `migrated_at`, `source_provider_id`, `migration_status`)
- Open Community RLS helpers & RPCs (`can_user_post_community()`, `can_user_comment_community()`, `can_user_upload_community_photo()`, `toggle_community_like`, `add_community_comment`)
- Scheduler locks & safe cleanup RPCs (`get_supabase_usage_metrics()`, `acquire_cloud_scheduler_lock()`, `release_cloud_scheduler_lock()`, `reclaim_migrated_record_safe()`)
- Default `migration_config` row in `app_settings`

---

## 2. Future cPanel PHP + MySQL Hosting Setup

When you purchase or provision cPanel hosting with HTTPS, PHP 8.0+, OpenSSL, PDO MySQL, and a MySQL 8 / MariaDB 10.4+ database:

1. **Upload Backend Files**
   Upload the contents of `hosting-php-api/` to a dedicated HTTPS directory on your cPanel server (for example `https://media.yourdomain.com/repairpro-api/`).
   - Ensure `private_uploads/.htaccess` and `uploads/verification-documents/.htaccess` are uploaded so direct unauthenticated HTTP access to verification KYC documents is blocked (`Require all denied`).
2. **Create `config.php`**
   Copy `hosting-php-api/config.example.php` to `hosting-php-api/config.php` and configure:
   - `firebase_project_id`: `gen-lang-client-0218221723`
   - `db`: your cPanel MySQL host, database name, user, and password (kept strictly on the cPanel server — **never** put DB passwords in Android or Web Admin JS)
   - `private_dir`: `__DIR__ . '/private_uploads'`
   - `private_buckets`: `['verification-documents']`
   - `api_secret`: strong random secret (only needed if you also route through the optional Edge proxy; direct Android/Web Admin clients authenticate natively using **Firebase RS256 ID tokens**)
   - `cron_secret`: strong random secret protecting `cron_migrate.php` or `cron_tick` when triggered over HTTPS
   - `supabase_url` & `supabase_service_role_key` *(optional, server-only)*: allows cPanel cron to ping `cloud-migration-worker` when automated triggers run from cPanel
   - `cors_origins`: your Web Admin origin(s)
3. **Initialize the MySQL Schema**
   Either import `hosting-php-api/cpanel_schema.sql` (20 tables including `cloud_scheduler_status` and `storage_error_logs`) via phpMyAdmin, OR click **Initialize / Verify cPanel MySQL Schema** inside the Web Admin Panel after entering the HTTPS endpoint URL.

---

## 3. Connecting & Verifying cPanel in the Web Admin Panel (No APK Update Needed)

Open **Web Admin Panel -> Cloud Storage & Multi-Cloud Hosting -> cPanel / PHP Hosting Connection**:

1. Enter your cPanel API HTTPS URL (e.g., `https://media.yourdomain.com/repairpro-api/index.php`) and public media base URL.
2. Enable **PHP Hosting + MySQL Database (`dbEnabled`)** as needed. Leave **Community Photos Only** unchecked if you also want cPanel to store backups/failover for PDFs, Technician Photos, Diagrams, and Private Verification Documents (automatically isolated inside `private_uploads/`).
3. Click **Check cPanel Pre-Activation Readiness**:
   - Verifies HTTPS connectivity (`health`)
   - Verifies Firebase Admin RS256 token authentication & `admin_roles` authorization
   - Verifies writable public upload directory and private `private_uploads/` directory
   - Verifies `.htaccess` / direct public access blocking on private uploads
   - Verifies MySQL connectivity and schema readiness (`db_health`)
   - Verifies available server storage & DB free capacity
4. Click **Save Multi-Cloud Routing** (or **Save Migration Settings**). This updates both Supabase `app_settings` / `storage_providers` and pushes a secret-free discovery manifest (`save_manifest`) to your cPanel server.

> **Important Security Guarantee:** Neither Android nor the Web Admin JS stores MySQL usernames/passwords, `api_secret`, `cron_secret`, or Supabase `service_role` keys. All clients authenticate directly to cPanel using Firebase RS256 ID Tokens verified against Google's public x509 certificates.

---

## 4. 24x7 Server-Side Automatic Migration Scheduler (Runs With Browsers & Phones Off)

Two coordinated server-side workers keep migration and threshold checks running continuously without keeping any browser or phone open:

### Option A — Supabase `pg_cron` + Edge Function (`cloud-migration-worker`)
1. Deploy the Edge Function `supabase/functions/cloud-migration-worker/index.ts`.
2. In **Supabase Dashboard -> Edge Functions -> Secrets**, add `CRON_SECRET` (random 32+ character string) alongside `SUPABASE_SERVICE_ROLE_KEY`.
3. Enable `pg_cron` and `pg_net` in **Supabase Dashboard -> Database -> Extensions**.
4. Schedule the cron job in SQL Editor (see the template at the bottom of `supabase/migrations/20261128_community_all_users_and_cron_migration.sql`) to call `cloud-migration-worker` every 15 minutes with header `x-cron-secret`.

### Option B — cPanel Cron Job (`hosting-php-api/cron_migrate.php`)
In **cPanel -> Cron Jobs**, add a recurring job (e.g., every 15 minutes):
```bash
php -q /home/YOUR_CPANEL_USER/public_html/repairpro-api/cron_migrate.php >/dev/null 2>&1
```
- Uses `flock()` file locking plus MySQL `cloud_scheduler_status` heartbeat logging to prevent overlapping runs.
- Rejects unauthenticated web requests unless `X-RepairPro-Cron-Secret` matches `cron_secret` in `config.php`.
- Safely exits without modifying data when `autoMigrationEnabled` is disabled or no verified target host is active.

In **Web Admin Panel -> Storage & Multi-Cloud Hosting**, the **24x7 Server-Side Migration Scheduler** card lets Super Admins inspect live worker status, last run time, reclaimed bytes, and trigger an immediate server worker tick (`Run Worker Tick Now`).

---

## 5. Automatic Migration, Safe Cleanup, Protected Records & Failover

### Threshold Monitoring & Auto-Migration
- In **Automatic Migration, Failover & Safe Cleanup**, set:
  - **DB Migration Threshold (%)** (default `80%`)
  - **Storage Migration Threshold (%)** (default `80%`)
  - **Fallback Discovery URLs** (your cPanel `index.php` HTTPS URLs so clients still discover routing if Supabase is paused or offline)
  - Toggle **Automatic Migration** ON once a healthy cPanel host is connected.
- When Supabase DB or Storage exceeds the configured threshold and a healthy cPanel provider is ready:
  - Admin or the 24x7 worker runs chunked, resumable, retried migration preserving IDs, timestamps, user ownership, permissions, and file paths.
  - Every migrated file is verified using **SHA-256 checksum parity** (`verify_file`) and exact byte preservation before being marked `VERIFIED`.
  - Before any migration or cleanup starts, an export backup manifest (`cloud_backup_manifests`) is generated with downloadable JSON recovery metadata.

### Protected System/Auth Tables & Safe Cleanup Verification
- **Protected Tables (`PROTECTED_MIGRATION_TABLES`)** — **never deleted** during automated cleanup:
  - `admin_roles`, `app_settings`, `user_profiles`, `fcm_tokens`, `ai_providers`, `ai_configs`, `storage_providers`, `hosting_provider_secrets`, `cloud_manifest`, `cloud_migration_runs`, `cloud_migration_items`, `cloud_backup_manifests`, `cloud_scheduler_status`, `audit_logs`, `storage_error_logs`, `community_user_restrictions`.
- Cleanup **CANNOT** execute (`canExecuteCleanup === false`) unless ALL of the following are true:
  1. Admin explicitly enabled **Auto Cleanup** (`autoCleanupEnabled = true`).
  2. Target cPanel host passed health & connectivity checks right before cleanup.
  3. Zero migration items failed (`failedItems === 0`).
  4. 100% of migrated items passed checksum/row verification (`verifiedItems === totalItems > 0`).
  5. Every target object passes `verify_file` existence + SHA-256 verification right before source deletion.
- Both Web Admin (`executeVerifiedCleanup`) and the Edge Worker (`cloud-migration-worker`) re-query `get_supabase_usage_metrics()` before and after deletion to calculate actual **reclaimed capacity (`reclaimedBytes` / `verifiedReclamation`)** and log it to `cloud_scheduler_status`.

### Automatic Failover, Dual-Cloud Merged Reads & Availability Warnings
- **Writes / Uploads:**
  - If Supabase is PRIMARY and returns quota/storage/DB full (`507`, `413`, `quota`, `insufficient storage`, `exceeded`) or outage/paused (`503`, timeout, connection failure), Android and Web Admin fail over directly to cPanel HTTPS + MySQL without requiring Supabase to succeed first.
  - If cPanel is PRIMARY, writes go directly to cPanel first with Supabase kept as fallback if configured.
- **Reads:**
  - Android (`MultiCloudStorageRouter.readMergedRows`) and Web Admin (`multiCloudDbQuery`) read from **both** Supabase and enabled cPanel MySQL providers together, deduplicating by primary key and newest timestamp.
  - If one provider is temporarily unreachable while another succeeds, available records continue loading normally and a non-blocking banner (`cloudAvailabilityNotice` / `#cloud-partial-availability-banner`) informs users/admins which source is temporarily unavailable.
- **Private Verification Documents:**
  - Verification KYC documents on cPanel live in `private_uploads/` and require short-lived HMAC signed URLs (`create_private_download_token` -> `download_private`) plus Firebase ID token verification.

---

## 6. Open Community Posting & Moderation Rules

All active registered users—**Normal Users**, **Unverified Technicians**, **Verified Technicians**, and **Admins**—have equal access across Android, Web Admin, Supabase RLS/RPCs, and cPanel PHP/MySQL to:
- View merged old + new posts (single-photo, multi-photo 1–4, text-only, photo-only, and text+photo posts)
- Create text-only, photo-only, text+photo, and multi-photo (1–4) posts
- Like/unlike posts, comment/reply, report content, and delete their own posts & comments

Moderation enforcement across all layers (`can_user_post_community()`, `can_user_comment_community()`, `can_user_upload_community_photo()`, `hosting-proxy-upload`, and `hosting-php-api/index.php`):
- **`blocked`, `suspended`, or `community_restricted`** (or `can_post = false` in `community_user_restrictions`): blocks posting, commenting, liking, and photo uploads.
- **`upload_restricted`** (or `can_upload_photo = false`): blocks community image uploads and posts containing photo attachments while **preserving text-only posting and commenting**.
- Non-admin posts always enforce `approval_status = 'PENDING'` on insert/update until reviewed in the Web Admin Panel.

---

## 7. Rollback & Recovery

1. **Rollback Database Migrations in Supabase (if ever needed):**
   Run `supabase/migrations/20261128_community_all_users_and_cron_rollback.sql` and/or `supabase/migrations/20261128_auto_migration_rollback.sql`.
2. **Switch Primary Provider Back:** In Web Admin -> **Automatic Migration, Failover & Safe Cleanup**, change **Primary Database Provider** back to **Supabase (Primary)** and click **Save Migration Settings**. Because old Supabase rows are preserved unless explicitly cleaned after 100% verification, switching back is instant.
3. **Restore from Backup Manifest:** Use **Restore Backup Manifest** in the **Cloud Backup Manifests** card to re-upsert backed-up rows and restore files into your target provider.

---

## 8. Troubleshooting

- **cPanel 401 / Token Rejected:** Verify `firebase_project_id` in `hosting-php-api/config.php` equals `gen-lang-client-0218221723`, and ensure server PHP `openssl` + outbound HTTPS to `www.googleapis.com` (for Google x509 public certs) are enabled.
- **Private URL returns 403:** Ensure the signed-in account is either an active admin in `admin_roles` (or `srikrishnaadhikary00@gmail.com`) or the document owner.
- **Supabase Offline Config Discovery:** Confirm your cPanel `index.php` URL is listed under **Fallback Discovery URLs** and that you clicked **Save Migration Settings** at least once so `save_manifest` persists `cloud_manifest` on cPanel.
- **24x7 Edge Worker Returns 401 on Cron:** Confirm `CRON_SECRET` is configured in Supabase Edge Function secrets and passed via `x-cron-secret` in your `pg_cron` job.
