# Repair Pro — Remote Admin Control vs. APK Update Matrix

This matrix clarifies what Super Admins can change **instantly from the Web Admin Panel or Android Super Admin screen** (no new APK required) versus changes that still require an Android APK release.

---

## 1. Remotely Controllable Without Releasing a New APK

| Area | Controlled Setting / Collection | Effect on User App |
| :--- | :--- | :--- |
| **Catalog & Repair Guides** | `catalog_entries` | Add, edit, localize (`EN`/`BN`/`HI`), attach media/PDFs, unpublish, or delete AC/Fridge/Washer guides and error codes. |
| **PDF Manuals & Diagrams** | `technical_documents` | Upload, replace files, soft-delete/restore, and toggle **`offlineAvailable`** (immediately removes revoked offline PDFs from device cache on sync). |
| **Feature Switches** | `app_settings/global_config` | Live enable/disable for Community, Technician Directory, Invoice Billing, Verification, OCR Scanner, Problem Reports, and PDFs/Diagrams. |
| **Maintenance & Updates** | `app_settings/global_config` | Toggle `maintenanceMode` with custom notice; show soft update prompt (`latestVersionCode`) or blocking update gate (`forceUpdate` + `minSupportedVersionCode` + `updateUrl`). |
| **AdMob Monetization** | `app_settings/admob_config` | Emergency kill switch, test/live ad unit IDs, ad format flags, category toggles, cooldown, and session caps. |
| **AI Assistant Routing** | `app_settings/ai_config` | Toggle AI visibility, **Free Only Mode**, Primary/Secondary/Backup provider ordering (Gemini/Groq/OpenRouter), daily/per-user quotas, system instructions, supported appliances/languages. |
| **Invoice & Reminder Templates** | `app_settings/billing_config` | Toggle billing/WhatsApp/SMS features, edit invoice business header/terms, and customize `EN`/`BN`/`HI` reminder templates. |
| **User Moderation** | `users` + Firebase Custom Claims (`admin-user-management`) | Suspend/block accounts, restrict community posting or file uploads, sync claims, or permanently delete non-bootstrap accounts. |
| **Technicians & Verifications** | `technicians`, `technician_verification_requests` | Approve/reject/suspend technicians, edit details, remove photos, soft-delete/restore. |
| **Community Moderation** | `community_posts`, `community_reports`, `community_user_restrictions` | Approve, reject, edit, pin/unpin, hide/unhide, strip photos, soft-delete/restore, and resolve user reports. |
| **Announcements & Push** | `announcements`, `push_notifications` | Publish in-app banners and dispatch targeted FCM push notifications (`ALL`, `TECHNICIANS`, `SELECTED`). |
| **Storage Failover** | `app_settings/storage_config` | Configure primary/backup media storage routing, image compression bounds, and duplicate detection. |

---

## 2. Changes That Require a New Android APK Release

- Modifying `applicationId`, package signing keystore, AndroidManifest permissions, or `minSdk`/`targetSdk`.
- Adding native Android libraries, new Jetpack Compose screens, or new Room database entities/schema migrations.
- Modifying built-in offline seed catalogs (`SeedDataPart1` / `SeedDataPart2`) bundled inside the APK.
- Changing AdMob SDK initialization metadata in `AndroidManifest.xml` (`APPLICATION_ID` meta-tag).
- Changing local APK `versionCode` / `versionName` (`app/build.gradle.kts`).
