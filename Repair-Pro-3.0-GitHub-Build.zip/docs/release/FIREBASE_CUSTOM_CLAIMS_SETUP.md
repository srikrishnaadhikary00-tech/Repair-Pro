# Firebase Custom Claims & Supabase Third-Party Auth Setup

Repair Pro uses **Firebase Authentication** together with **Supabase Third-Party Auth**. Supabase Storage and PostgREST RLS inspect JWT claims issued inside the Firebase ID token.

---

## 1. Required Claims Schema

| Claim | User Value | Super Admin Value | Purpose |
| :--- | :--- | :--- | :--- |
| `role` | `"authenticated"` | `"authenticated"` | Maps Firebase JWT to Supabase `authenticated` Postgres role |
| `admin` | `false` | `true` | Recognized by `firestore.rules`, `storage.rules`, Supabase RLS, and Edge Functions |
| `repairproRole` | `"USER"` | `"SUPER_ADMIN"` | Granular Repair Pro role tag |
| `blocked` | `false` / `true` | `false` | Enforced in rules & auth checks for account-level blocks |
| `suspended` | `false` / `true` | `false` | Enforced in rules & auth checks for temporary suspensions |
| `communityRestricted` | `false` / `true` | `false` | Blocks community posting/commenting |
| `uploadRestricted` | `false` / `true` | `false` | Blocks storage uploads (`community-photos`, `verification-documents`) |

> **Important Security Note:** Never mint or store Firebase custom claims inside the Android APK or public client storage. Claims must only be written server-side by Firebase Admin SDK (`scripts/set-firebase-custom-claims.mjs` or the `admin-user-management` Supabase Edge Function).

---

## 2. Option A — One-Time CLI Script (Bootstrap Super Admin)

Use `/scripts/set-firebase-custom-claims.mjs` with a Firebase Admin service account JSON (kept strictly off-device and outside the repository):

```bash
GOOGLE_APPLICATION_CREDENTIALS=/secure/path/service-account.json \
  node scripts/set-firebase-custom-claims.mjs \
  --email srikrishnaadhikary00@gmail.com \
  --admin true
```

Optional flags:
- `--uid <firebase_uid>` — target by UID instead of email lookup
- `--admin false` — provision `"role": "authenticated"`, `"admin": false`, `"repairproRole": "USER"`
- `--service-account <path.json>` — explicit path instead of env var

---

## 3. Option B — In-App / Web Admin Self-Sync (`admin-user-management`)

Once the `admin-user-management` Edge Function is deployed with Firebase Admin credentials on Supabase:
- **Web Super Admin Panel:** Open **Users & Account Moderation** and click **Sync My Claims**.
- **Android Super Admin Screen:** Open the **Users** tab and tap **Sync My Claims**.
- For existing non-admin app users, `admin-user-management` `ensure_self_claims` (or Admin moderation actions `SYNC_CLAIMS` / `SUSPEND` / `BLOCK`) provisions `role: "authenticated"`.

---

## 4. Activating Updated Claims in Clients

Firebase ID tokens cache claims for up to 1 hour unless forcibly refreshed:
1. Both Android (`SupabaseClient` / `Auth`) and Web Admin (`supabaseFetchWithAuth`) automatically force-refresh (`getIdToken(true)`) once on HTTP `401`.
2. After initial bootstrap claims provisioning, sign out and sign back in once to guarantee immediate propagation across Firestore, Storage, and Supabase.
