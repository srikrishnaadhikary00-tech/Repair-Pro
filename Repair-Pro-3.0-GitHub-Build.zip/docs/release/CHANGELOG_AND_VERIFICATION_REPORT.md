# Repair Pro — Final All-in-One Stable Release Changelog & Verification Report (v1.2.0 / versionCode 3)

## 1. Changelog Summary

### Authentication, Security & Backend Hardening
- **Firebase + Supabase Third-Party Auth:** Standardized `SupabaseClient` and Web Admin (`supabaseFetchWithAuth`) to send `apikey: <public_anon_key>` and `Authorization: Bearer <Firebase ID Token>` with automatic single-retry forced refresh (`getIdToken(true)`) on HTTP `401`.
- **Upload Integrity & Magic Bytes:** Enforced client-side and proxy-side magic-byte inspection (`FF D8 FF` JPEG, `89 50 4E 47` PNG, `RIFF...WEBP` WebP, `%PDF-` PDF), size limits (`5 MB` images, `10 MB` verification docs, `20 MB` PDFs/diagrams), and `x-upsert: false`.
- **Zero-Trust Rules & RLS:** Updated `firestore.rules` (using null-safe `.get(...)` moderation defaults and short-circuited `community_posts` updates), `storage.rules`, and additive Supabase SQL migrations (`20261127_final_security_and_admin_migration.sql`, `20261127_remove_temp_anon_policies.sql`, `20261127_final_rollback.sql`).
- **Private Verification Credentials:** Added short-lived signed URL resolution (`create_signed_url`) via the `admin-user-management` Edge Function for `verification-documents`.
- **Custom Claims Provisioning:** Added `/scripts/set-firebase-custom-claims.mjs` and in-app/Web Admin **Sync My Claims** support (`role: "authenticated"`, `admin`, `repairproRole`).

### Admin Full Control (Android Super Admin & Web Admin Panel)
- **Users & Account Moderation:** Suspend/unsuspend, block/unblock, restrict/allow community access, restrict/allow file uploads, restore all, sync claims, and confirmation-gated permanent deletion via `admin-user-management`.
- **Remote Global Config & Version Gating:** Added remote `maintenanceMode`, `forceUpdate`, `minSupportedVersionCode`, `latestVersionName`/`latestVersionCode`, `schemaVersion`, `updateMessage`, `updateUrl`, and 7 live module switches (`community`, `technicians`, `billing`, `verification`, `scanner`, `reports`, `pdfs`).
- **Expanded Content Moderation:**
  - **Technicians:** Suspend/unsuspend, remove photo, soft-delete/restore.
  - **Community Posts:** `HIDDEN` queue filter, post editing, hide/unhide, per-photo removal, soft-delete/restore.
  - **PDF Manuals & Circuit Diagrams:** Admin `offlineAvailable` toggle, file replacement, soft-delete/restore, and automatic purge of revoked/deleted offline PDFs (`OfflinePdfCacheManager.syncWithApprovedDocuments`).
  - **Audit Logging:** Standardized `SUCCESS` / `FAILED` result logging.

### Preserved Systems
- Preserved existing `OnlinePdfViewerScreen` (`MediaViewerScreens.kt`), package `com.aistudio.repairpro.kxmvqz`, Firebase project `gen-lang-client-0218221723`, named Firestore database `ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8`, Supabase project `xuakzzjtcgcvudkgxpbd`, FCM endpoint, Room billing tables (`customers`, `invoices`, `invoice_payments`), AdMob controls, Aurora Glass UI, and navigation.

---

## 2. Verification Report

| Check / Suite | Result | Details |
| :--- | :--- | :--- |
| **Android Build (`compile_applet` & `:app:assembleDebug`)** | **PASS** | Compiled and assembled Debug APK cleanly (`BUILD SUCCESSFUL`). |
| **Android Unit & Robolectric Suite (`gradle :app:testDebugUnitTest`)** | **PASS** | **51 / 51 tests passed** across 10 suites (`CommunityLogicUnitTest`: 6, `ExampleRobolectricTest`: 1, `ExampleUnitTest`: 1, `FinalReleaseSecurityAndAdminUnitTest`: 7, `FindTechnicianRobolectricTest`: 3, `MultiCloudAndPushUnitTest`: 9, `Phase2BillingAndAiUnitTest`: 8, `RepairProV2UnitTest`: 6, `SuperAdminRobolectricTest`: 5, `V2FeaturesUnitTest`: 5). `0` failures, `0` skipped. |
| **Firestore Security Rules Emulator Tests (`firestore.test.js`)** | **PASS** | **6 / 6 tests passed** against local Firestore Emulator (`firebase emulators:exec --only firestore`). |
| **Web Admin & Scripts JS Syntax (`node --check`)** | **PASS** | `web-admin/firebase-config.js`, `web-admin/app.js`, and `scripts/set-firebase-custom-claims.mjs` passed with exit code `0`. |
| **Live Physical Device / ADB Instrumented UI Execution** | **NOT TESTED** | No Android Emulator or ADB runtime exists in the cloud build container; Compose UI journeys were verified via Robolectric on JVM instead. |
| **Live Cloud Deployment & Production Traffic** | **NOT TESTED** | Per instructions, live Firebase rules, Edge Functions, SQL migrations, and push broadcasts were not mutated in production without explicit user approval. |
