# Repair Pro — Web Super Admin Panel Guide

Location: `/web-admin/` (`index.html`, `app.js`, `firebase-config.js`)

---

## 1. Authentication & Security Model

- Sign-in uses **Firebase Google Sign-In** (popup or redirect fallback) against project `gen-lang-client-0218221723` and named Firestore database `ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8`.
- **Supabase Requests:** `supabaseFetchWithAuth` always sends:
  - `apikey`: Supabase public anon key only
  - `Authorization`: `Bearer <Firebase ID Token>` with automatic single-retry forced token refresh (`getIdToken(true)`) on `401`
- **File Uploads:** Enforces client-side magic-byte inspection (`FF D8 FF` JPEG, `89 50 4E 47` PNG, `RIFF...WEBP` WebP, `%PDF-` PDF) and `x-upsert: false` before hitting Storage.
- **No Private Secrets in Browser:** Service account keys, `service_role` keys, and AI provider secret keys are never saved in `firebase-config.js` or Firestore.

---

## 2. Admin Modules Overview

| Section | Capabilities |
| :--- | :--- |
| **Dashboard & Metrics** | Real-time counts for published catalog items, pending reports, pending verifications, community posts, technicians, users, and AdMob status. |
| **Catalog & Repair Guides** | Publish/edit multilingual (`EN` / `BN` / `HI`) error codes and troubleshooting guides with optional photo, PDF manual, and circuit diagram attachments. |
| **Technicians Directory** | Create, edit, toggle `ACTIVE`/`INACTIVE`, **Suspend/Unsuspend**, **Remove Photo**, **Soft Delete/Restore**, and permanently delete technician records synced to Firestore + Supabase. |
| **Verification Queue** | Review `PENDING`, `VERIFIED`, `REJECTED`, and `SUSPENDED` technician applications; preview private `verification-documents` credentials via short-lived signed URLs (`create_signed_url`). |
| **Community Moderation** | Filter by `PENDING`, `APPROVED`, `REJECTED`, `HIDDEN`, `REPORTS`, or `ALL`; approve/reject, **Edit Post**, **Pin/Unpin**, **Hide/Unhide**, remove individual post photos, **Soft Delete/Restore**, block author, or permanently delete. |
| **PDFs & Diagrams** | Upload PDF manuals (`<20 MB`) or high-res diagrams; toggle **`offlineAvailable`** (allow/disable offline PDF save on Android), **Replace File**, **Soft Delete/Restore**, or delete. |
| **Push Notifications** | Broadcast announcements + FCM notifications (`ALL`, `TECHNICIANS`, or `SELECTED` users) via `send-push-notification` with live delivery status & failure telemetry. |
| **Users & Account Moderation** | Search/filter users; run **Sync My Claims**, **Suspend / Unsuspend**, **Block / Unblock**, **Restrict / Allow Community**, **Restrict / Allow Uploads**, **Restore All**, and confirmation-gated permanent account delete via `admin-user-management`. |
| **AdMob Controls** | Global kill switch, test/live unit mode, per-category toggles (`AC`, `Fridge`, `Washer`), banner/interstitial/rewarded flags, cooldown & frequency cap. |
| **AI Assistant & Billing** | Dedicated presets for Google Gemini, Groq, and OpenRouter; **Free Only Mode**; Primary/Secondary/Backup failover; Billing invoice & WhatsApp/SMS reminder templates (`EN`/`BN`/`HI`). |
| **Global App Settings** | Configure `maintenanceMode`, `minSupportedVersionCode`, `latestVersionName` / `latestVersionCode`, `schemaVersion`, `forceUpdate`, `updateMessage`, `updateUrl` (`https://`), and 7 live module feature flags (`community`, `technicians`, `billing`, `verification`, `scanner`, `reports`, `pdfs`). |
| **Storage & Hosting Manager** | Multi-cloud routing (`Supabase`, `PHP Shared Hosting`, `S3`, `Cloudflare R2`, `GCS`), upload failover logs, and private bucket signed preview links. |
| **Audit Logs** | Immutable admin action log showing actor email, action type, target, details, and `SUCCESS`/`FAILED` result. |
