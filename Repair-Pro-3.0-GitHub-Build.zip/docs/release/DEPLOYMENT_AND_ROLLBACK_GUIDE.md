# Repair Pro — Deployment & Rollback Guide (v1.2.0 / versionCode 3)

This guide covers safe additive deployment and rollback for **Repair Pro** (`com.aistudio.repairpro.kxmvqz`) without resetting or deleting existing user accounts, uploaded media, or Room billing data.

---

## 1. Preserved Cloud & App Identifiers

| Component | Identifier / Endpoint |
| :--- | :--- |
| Android `applicationId` | `com.aistudio.repairpro.kxmvqz` |
| Android `namespace` | `com.example` |
| Firebase Project | `gen-lang-client-0218221723` |
| Named Firestore Database | `ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8` |
| Bootstrap Super Admin | `srikrishnaadhikary00@gmail.com` |
| Supabase Project | `xuakzzjtcgcvudkgxpbd` (`https://xuakzzjtcgcvudkgxpbd.supabase.co`) |
| FCM Push Endpoint | `https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-push-notification` |
| Admin User Management Endpoint | `https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/admin-user-management` |

---

## 2. Pre-Deployment Checklist

1. **Secrets & Environment Variables (Never inside APK or Web JS):**
   - Android build `.env` / AI Studio Secrets: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `FIREBASE_WEB_CLIENT_ID` (must end in `.apps.googleusercontent.com`), `FCM_BACKEND_ENDPOINT`, `FIREBASE_APPCHECK_DEBUG_TOKEN` (debug only).
   - Supabase Edge Function Secrets: `FIREBASE_PROJECT_ID`, `FIREBASE_SERVICE_ACCOUNT_JSON` (or Auth Admin credentials for `admin-user-management` & `send-fcm-v1`), AI provider keys (`GEMINI_API_KEY`, `GROQ_API_KEY`, `OPENROUTER_API_KEY`).
   - Do **not** commit `.env`, `google-services.json`, `debug.keystore`, or upload keystores to source control.
2. **Firebase Third-Party Auth in Supabase:**
   - Enable Firebase Auth provider inside Supabase Authentication -> Sign In / Providers (`gen-lang-client-0218221723`).
   - Ensure Firebase custom claims include `role: "authenticated"` (see `FIREBASE_CUSTOM_CLAIMS_SETUP.md`).

---

## 3. Recommended Deployment Order

### Step 1: Apply Additive Supabase SQL Migrations
Run migrations in order (additive `CREATE TABLE IF NOT EXISTS`, `ALTER TABLE ... ADD COLUMN IF NOT EXISTS`, RLS policies):
1. `supabase/migrations/20261126_phase2_additive_migration.sql` (if not already applied)
2. `supabase/migrations/20261127_final_security_and_admin_migration.sql`
3. After verifying Firebase Third-Party Auth + custom claims are active for all signed-in users:
   - Review and apply `supabase/migrations/20261127_remove_temp_anon_policies.sql` so anonymous uploads/deletes on storage buckets and direct `anon` writes are permanently closed.

### Step 2: Deploy Supabase Edge Functions
Deploy via Supabase CLI (only with explicit operator approval):
- `admin-user-management` (required for Super Admin user moderation, blocking, suspension, confirmation-gated account deletion, custom claims sync, and signed URLs for private `verification-documents`)
- `hosting-proxy-upload`
- `ai-repair-assistant`
- Existing push function (`send-push-notification` / `supabase/functions/send-fcm-v1`)

### Step 3: Deploy Firebase Security Rules & Indexes
- Deploy `firestore.rules` to database `ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8`
- Deploy `firestore.indexes.json`
- Deploy `storage.rules`

### Step 4: Provision Bootstrap Admin Custom Claims
Follow `FIREBASE_CUSTOM_CLAIMS_SETUP.md` (either via `scripts/set-firebase-custom-claims.mjs` or the `Sync My Claims` button inside Web Admin / Android Super Admin).

### Step 5: Deploy Web Super Admin Panel (`web-admin/`)
- Deploy `/web-admin` (`index.html`, `app.js`, `firebase-config.js`) to your HTTPS static host (Netlify / Firebase Hosting).
- Configure Google Auth authorized domains in Firebase Console for the Web Admin hostname.

### Step 6: Build & Distribute Signed Android APK / AAB
- Build release artifact (`gradle :app:bundleRelease` or `gradle :app:assembleRelease`) with CI/upload keystore environment variables (`KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`).
- Test upgrade installation over the previous APK (`versionCode` 2 -> `3`) to verify Room billing data (`customers`, `invoices`, `invoice_payments`) and user preferences remain intact.

---

## 4. Rollback Procedures

### Cloud SQL Rollback
- If `20261127_final_security_and_admin_migration.sql` introduces an unexpected schema/policy conflict:
  - Run `supabase/migrations/20261127_final_rollback.sql` (reverts newly added RLS/columns safely without dropping existing user/technician/post data).
- For Phase 2 migration rollback, use `supabase/migrations/20261126_phase2_rollback.sql`.

### Firebase Rules Rollback
- Restore the previous rule version from **Firebase Console -> Firestore / Storage -> Rules -> Version History** and click **Publish**.

### Remote App Behavior Rollback (Without Releasing a New APK)
- **Feature outage:** Disable affected module flags in `app_settings/global_config` (`communityEnabled`, `techniciansEnabled`, `billingEnabled`, `verificationEnabled`, `scannerEnabled`, `reportsEnabled`, `pdfsEnabled`, or `maintenanceMode`).
- **AdMob issue:** Toggle `emergencyKillSwitch = true` in `app_settings/admob_config`.
- **AI provider issue:** Disable the failing provider or enable `aiFreeOnlyMode = true` in `app_settings/ai_config`.
- **Force user upgrade:** Raise `minSupportedVersionCode` and set `forceUpdate = true` with `https://` `updateUrl` in `app_settings/global_config`.
