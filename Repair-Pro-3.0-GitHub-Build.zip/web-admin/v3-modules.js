// Repair Pro v3.0 — Web Super Admin Panel v3.0 Modules
// Implements: Push Notification Center (Logout-Bug Free), Multi-Cloud Storage Manager,
// Technicians Verification, Community Moderation, PDF & Circuit Diagrams, Users Management,
// and Firebase/Supabase Health Monitoring.
import {
  collection,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";
import {
  SUPABASE_URL,
  SUPABASE_PROJECT_REF,
  getSupabaseAnonKey,
  setSupabaseAnonKey
} from "./firebase-config.js";

const $ = (id) => document.getElementById(id);

const VALID_PROVIDER_TYPES = new Set([
  "SUPABASE",
  "CLOUDFLARE_R2",
  "BACKBLAZE_B2",
  "CUSTOM_S3"
]);

function normalizeProviderType(raw) {
  const upper = String(raw || "SUPABASE").trim().toUpperCase();
  if (upper === "S3_COMPATIBLE" || upper === "CUSTOM_ENDPOINT" || upper === "AWS_S3" || upper === "S3") return "CUSTOM_S3";
  if (upper === "R2") return "CLOUDFLARE_R2";
  if (upper === "B2") return "BACKBLAZE_B2";
  return VALID_PROVIDER_TYPES.has(upper) ? upper : "CUSTOM_S3";
}

function mapSupabaseProviderRow(row) {
  return {
    id: String(row.id || ""),
    name: String(row.name || "Storage Provider"),
    providerType: normalizeProviderType(row.provider_type ?? row.providerType),
    endpointUrl: String(row.endpoint_url ?? row.endpointUrl ?? ""),
    projectRef: String(row.project_ref ?? row.projectRef ?? row.bucketName ?? "default"),
    region: String(row.region ?? "auto"),
    publicBaseUrl: String(row.public_base_url ?? row.publicBaseUrl ?? ""),
    secretEnvKey: String(row.secret_env_key ?? row.secretEnvKey ?? "SUPABASE_SERVICE_ROLE_KEY"),
    secretConfigured: row.secret_configured !== undefined ? Boolean(row.secret_configured) : null,
    activeFilesCount: Number(row.active_files_count ?? row.activeFilesCount ?? 0),
    primary: Boolean(row.is_primary ?? row.primary),
    backup: Boolean(row.is_backup ?? row.backup),
    enabled: row.is_enabled !== undefined ? Boolean(row.is_enabled) : Boolean(row.enabled ?? true),
    autoFailoverEnabled: row.auto_failover_enabled !== undefined
      ? Boolean(row.auto_failover_enabled)
      : Boolean(row.autoFailoverEnabled ?? true),
    priorityOrder: Number(row.priority_order ?? row.priorityOrder ?? 10),
    capacityBytes: Number(row.capacity_bytes ?? row.capacityBytes ?? 1073741824),
    usedBytes: Number(row.used_bytes ?? row.usedBytes ?? 0),
    lastTestStatus: String(row.last_test_status ?? row.lastTestStatus ?? "UNTESTED"),
    lastTestMessage: String(row.last_test_message ?? row.lastTestMessage ?? ""),
    authoritativeSource: "supabase"
  };
}

export function createV3AdminController({ db, getCurrentUser, showToast, logAudit, sanitizeId, onCountsChanged }) {
  const state = {
    users: [],
    technicians: [],
    posts: [],
    communityReports: [],
    documents: [],
    notifications: [],
    providers: [],
    supabaseProviders: null,
    fileRegistry: [],
    supabaseFiles: null,
    errorLogs: [],
    supabaseErrorLogs: null
  };

  function getActiveProviders() {
    return Array.isArray(state.supabaseProviders) ? state.supabaseProviders : [];
  }

  function setBanner(elId, type, message) {
    const el = $(elId);
    if (!el) return;
    el.className = `alert-banner alert-${type}`;
    el.textContent = message;
    el.classList.remove("hidden");
  }

  /**
   * Session-safe authenticated call to Supabase Edge Functions.
   * CRITICAL: HTTP 401/403/500 responses NEVER sign out or redirect the Super Admin.
   */
  async function callSupabaseEdge(fnName, method = "GET", bodyObj = null, queryPath = "") {
    const user = getCurrentUser();
    if (!user) {
      return { ok: false, status: 0, error: "Not signed in." };
    }
    const anonKey = getSupabaseAnonKey();
    if (!anonKey) {
      return {
        ok: false,
        status: 0,
        error: "Supabase public Anon Key not configured yet. Open 'Firebase & Supabase Status' tab to add it."
      };
    }
    try {
      const idToken = await user.getIdToken(false);
      const url = `${SUPABASE_URL}/functions/v1/${fnName}${queryPath}`;
      const headers = {
        apikey: anonKey,
        Authorization: `Bearer ${anonKey}`,
        "x-firebase-token": idToken
      };
      const opts = { method, headers };
      if (bodyObj !== null && method !== "GET") {
        headers["Content-Type"] = "application/json";
        opts.body = JSON.stringify(bodyObj);
      }
      const res = await fetch(url, opts);
      const text = await res.text();
      let data = {};
      try { data = JSON.parse(text); } catch (_) { data = { raw: text }; }
      if (!res.ok) {
        return {
          ok: false,
          status: res.status,
          error: data.error || data.message || `HTTP ${res.status} from ${fnName}`,
          data
        };
      }
      return { ok: true, status: res.status, data };
    } catch (err) {
      return { ok: false, status: 0, error: err?.message || "Network error contacting Supabase Edge Function" };
    }
  }

  async function mirrorProvidersToFirestore(supabaseRows) {
    if (!Array.isArray(supabaseRows) || supabaseRows.length === 0) return;
    const mapped = supabaseRows.map(mapSupabaseProviderRow);
    const activeIds = new Set(mapped.map((p) => p.id));

    for (const p of mapped) {
      try {
        await setDoc(doc(db, "storage_providers", p.id), {
          name: p.name.slice(0, 100),
          providerType: p.providerType,
          endpointUrl: p.endpointUrl.slice(0, 300),
          projectRef: p.projectRef.slice(0, 80),
          secretEnvKey: p.secretEnvKey.slice(0, 80),
          primary: p.primary,
          backup: p.backup,
          enabled: p.enabled,
          autoFailoverEnabled: p.autoFailoverEnabled,
          capacityBytes: p.capacityBytes,
          usedBytes: p.usedBytes,
          lastTestStatus: p.lastTestStatus,
          lastTestMessage: p.lastTestMessage.slice(0, 300),
          updatedAt: serverTimestamp()
        });
      } catch (err) {
        console.warn("Mirror provider to Firestore skipped:", p.id, err?.message);
      }
    }

    // Remove stale Firestore docs no longer present in authoritative Supabase registry
    for (const existing of state.providers) {
      if (existing.id && !activeIds.has(existing.id)) {
        try {
          await deleteDoc(doc(db, "storage_providers", existing.id));
        } catch (_) {}
      }
    }
  }

  async function refreshStorageOverviewFromSupabase(showFeedback = false) {
    if (!getSupabaseAnonKey()) {
      state.supabaseProviders = null;
      state.supabaseFiles = null;
      state.supabaseErrorLogs = null;
      renderStorageProviders();
      renderFileRegistry();
      renderErrorLogs();
      onCountsChanged(state);
      return false;
    }

    const res = await callSupabaseEdge("repair-pro-api", "GET", null, "/admin/storage/overview");
    if (res.ok && res.data) {
      const rawProviders = Array.isArray(res.data.providers) ? res.data.providers : [];
      state.supabaseProviders = rawProviders.map(mapSupabaseProviderRow);
      state.supabaseFiles = Array.isArray(res.data.files) ? res.data.files : [];
      state.supabaseErrorLogs = Array.isArray(res.data.errorLogs) ? res.data.errorLogs : [];

      renderStorageProviders();
      renderFileRegistry();
      renderErrorLogs();
      onCountsChanged(state);
      mirrorProvidersToFirestore(rawProviders);

      if (showFeedback) {
        setBanner("storage-action-banner", "success", `Synced ${state.supabaseProviders.length} authoritative provider(s) from Supabase.`);
      }
      return true;
    } else if (showFeedback) {
      setBanner("storage-action-banner", "warn", `Supabase registry sync notice: ${res.error}`);
    }
    return false;
  }

  async function syncRemoteSettings({ admob = null, remote = null } = {}) {
    if (!getSupabaseAnonKey()) return { ok: false, skipped: true };
    return callSupabaseEdge("repair-pro-api", "POST", { admob, remote }, "/admin/settings/remote");
  }

  function attachStreams() {
    const unsubs = [];
    const safeSub = (colName, assign, render) => {
      unsubs.push(
        onSnapshot(
          collection(db, colName),
          (snap) => {
            assign(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
            render();
            onCountsChanged(state);
          },
          (err) => {
            console.warn(`Stream ${colName} error:`, err?.message);
          }
        )
      );
    };

    safeSub("users", (v) => { state.users = v; }, renderUsers);
    safeSub("technicians", (v) => { state.technicians = v; }, renderTechnicians);
    safeSub("community_posts", (v) => { state.posts = v; }, renderCommunity);
    safeSub("community_reports", (v) => { state.communityReports = v; }, renderCommunityReports);
    safeSub("repair_documents", (v) => { state.documents = v; }, renderDocuments);
    safeSub("notifications", (v) => {
      state.notifications = v.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    }, renderNotifications);
    safeSub("storage_providers", (v) => {
      state.providers = v.sort((a, b) => Number(Boolean(b.primary)) - Number(Boolean(a.primary)));
    }, renderStorageProviders);
    safeSub("storage_file_registry", (v) => { state.fileRegistry = v; }, renderFileRegistry);
    safeSub("error_logs", (v) => {
      state.errorLogs = v.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    }, renderErrorLogs);

    return unsubs;
  }

  // ---------------- PUSH NOTIFICATION CENTER (LOGOUT BUG & IMMUTABLE RULE FIXED) ----------------
  function initPushCenter() {
    $("push-target-type")?.addEventListener("change", () => {
      $("push-uids-wrap")?.classList.toggle("hidden", $("push-target-type").value !== "SELECTED");
    });

    $("push-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      e.stopPropagation();

      const user = getCurrentUser();
      if (!user) return;

      const title = $("push-title").value.trim();
      const body = $("push-body").value.trim();
      const targetType = $("push-target-type").value;
      const targetUids = $("push-uids").value.split(",").map((s) => s.trim()).filter(Boolean);

      if (!title || !body) {
        setBanner("push-result-banner", "error", "Please enter both a Notification Title and Message Body.");
        return;
      }

      const sendBtn = $("push-send-btn");
      sendBtn.disabled = true;
      sendBtn.textContent = "Sending…";

      try {
        const notifId = sanitizeId(`notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);

        // Step 1: Dispatch FCM HTTP v1 first (notifications/ rules allow create-once only: allow update: if false)
        const edgeRes = await callSupabaseEdge("send-push-notification", "POST", {
          notificationId: notifId,
          title,
          body,
          targetType,
          targetUids
        });

        let deliveryStatus = "SAVED_IN_APP_INBOX";
        let totalTargeted = targetUids.length;
        let successCount = 0;
        let failureCount = 0;
        let errorMessage = "";

        if (edgeRes.ok) {
          successCount = Number(edgeRes.data?.successCount ?? edgeRes.data?.sentCount ?? 0);
          failureCount = Number(edgeRes.data?.failureCount ?? edgeRes.data?.failedCount ?? 0);
          totalTargeted = Number(edgeRes.data?.totalTargeted ?? targetUids.length);
          deliveryStatus = String(
            edgeRes.data?.deliveryStatus || (successCount > 0 ? "SENT" : "NO_ACTIVE_TOKENS")
          );
          errorMessage = String(edgeRes.data?.warning || "").slice(0, 400);
        } else {
          deliveryStatus = "EDGE_PENDING";
          errorMessage = String(edgeRes.error || "Edge dispatch unavailable").slice(0, 400);
        }

        // Step 2: Single immutable create into Firestore notifications inbox
        await setDoc(doc(db, "notifications", notifId), {
          title: title.slice(0, 120),
          body: body.slice(0, 500),
          targetType,
          targetUids,
          sentByUid: user.uid,
          sentByEmail: (user.email || "").slice(0, 160),
          totalTargeted,
          successCount,
          failureCount,
          deliveryStatus: deliveryStatus.slice(0, 64),
          errorMessage,
          createdAt: serverTimestamp()
        });

        if (edgeRes.ok) {
          setBanner(
            "push-result-banner",
            "success",
            `Notification saved & dispatched (${deliveryStatus})! Targeted: ${totalTargeted}, Sent: ${successCount}, Failed: ${failureCount}. Session preserved.`
          );
          $("push-title").value = "";
          $("push-body").value = "";
        } else {
          setBanner(
            "push-result-banner",
            "warn",
            `Saved to in-app Notification Inbox, but FCM Edge dispatch returned (${edgeRes.status || "config"}): ${edgeRes.error}. Super Admin session safely preserved.`
          );
        }

        await logAudit("SEND_PUSH_NOTIFICATION", "notifications", notifId, `Target=${targetType}, Status=${deliveryStatus}`);
      } catch (err) {
        setBanner("push-result-banner", "error", `Push error: ${err?.message || "Unknown error"} (Super Admin session preserved).`);
      } finally {
        sendBtn.disabled = false;
        sendBtn.textContent = "Send Push Notification";
      }
    });
  }

  function renderNotifications() {
    const list = $("notifications-list");
    if (!list) return;
    list.replaceChildren();
    if (state.notifications.length === 0) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "No push notifications sent yet.";
      list.append(p);
      return;
    }
    state.notifications.slice(0, 30).forEach((n) => {
      const row = document.createElement("div");
      row.className = "list-item";
      const left = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = n.title || "(Untitled)";
      const body = document.createElement("div");
      body.style.fontSize = "13px";
      body.style.color = "var(--text-muted)";
      body.textContent = n.body || "";
      const sent = n.successCount ?? n.sentCount ?? 0;
      const failed = n.failureCount ?? n.failedCount ?? 0;
      const note = n.errorMessage || n.errorSummary || "";
      const meta = document.createElement("div");
      meta.style.fontSize = "11px";
      meta.style.color = "var(--cyan)";
      meta.textContent = `Target: ${n.targetType || "ALL"} • Sent: ${sent} • Failed: ${failed}${note ? ` • Note: ${note}` : ""}`;
      left.append(title, body, meta);

      const badge = document.createElement("span");
      badge.className = n.deliveryStatus === "SENT" ? "badge badge-green" : "badge badge-amber";
      badge.textContent = n.deliveryStatus || "QUEUED";
      row.append(left, badge);
      list.append(row);
    });
  }

  // ---------------- PDF & CIRCUIT DIAGRAM MANAGER ----------------
  function initDocumentsManager() {
    $("document-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const user = getCurrentUser();
      if (!user) return;

      const title = $("doc-title").value.trim();
      const docType = $("doc-type").value;
      const categoryId = $("doc-category").value;
      let fileUrl = $("doc-url").value.trim();
      const fileInput = $("doc-file-input");
      const btn = $("doc-submit-btn");

      if (!title) return;
      btn.disabled = true;
      btn.textContent = "Publishing…";

      let uploadedMime = docType === "CIRCUIT_DIAGRAM" ? "image/jpeg" : "application/pdf";
      let uploadedSizeBytes = 0;
      let uploadedProviderId = "";

      try {
        if (fileInput?.files && fileInput.files.length > 0) {
          const file = fileInput.files[0];
          const b64 = await fileToBase64(file);
          const bucket = docType === "CIRCUIT_DIAGRAM" ? "circuit-diagrams" : "repair-pdfs";
          const mimeType = file.type || (docType === "CIRCUIT_DIAGRAM" ? "image/jpeg" : "application/pdf");
          const upRes = await callSupabaseEdge("repair-pro-api", "POST", {
            bucket,
            filename: file.name,
            mimeType,
            base64: b64,
            entityType: "repair_document",
            entityId: $("doc-id").value.trim() || undefined
          }, "/storage/upload");

          const publicUrl = upRes.data?.publicUrl || upRes.data?.url || "";
          if (upRes.ok && publicUrl) {
            fileUrl = publicUrl;
            uploadedMime = upRes.data?.mimeType || mimeType;
            uploadedSizeBytes = Number(upRes.data?.sizeBytes || file.size || 0);
            uploadedProviderId = String(upRes.data?.providerId || "");
            const failoverTag = upRes.data?.failoverUsed ? " (via Automatic Failover)" : "";
            setBanner("doc-status-box", "success", `Uploaded via "${upRes.data.providerName || upRes.data.providerId || "Primary"}"${failoverTag}!`);
            refreshStorageOverviewFromSupabase(false);
          } else {
            setBanner("doc-status-box", "error", `Upload failed (${upRes.error}). You may also paste a direct HTTPS file URL.`);
            return;
          }
        }

        if (!fileUrl) {
          setBanner("doc-status-box", "error", "Provide either a Direct File URL or choose a file to upload.");
          return;
        }

        const rawId = $("doc-id").value.trim();
        const docId = sanitizeId(rawId || `doc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
        const docRef = doc(db, "repair_documents", docId);
        const existingSnap = rawId ? await getDoc(docRef) : null;

        const payload = {
          docType,
          categoryId,
          brandName: ($("doc-brand").value.trim() || "Universal").slice(0, 80),
          modelName: $("doc-model").value.trim().slice(0, 100),
          errorCode: $("doc-error-code").value.trim().toUpperCase().slice(0, 32),
          title: title.slice(0, 180),
          description: $("doc-desc").value.trim().slice(0, 1000),
          fileUrl: fileUrl.slice(0, 1000),
          mimeType: uploadedMime,
          fileSizeBytes: uploadedSizeBytes,
          storageProviderId: uploadedProviderId,
          published: $("doc-published").checked,
          uploadedByUid: user.uid,
          updatedAt: serverTimestamp()
        };

        if (existingSnap && existingSnap.exists()) {
          await updateDoc(docRef, payload);
        } else {
          await setDoc(docRef, { ...payload, createdAt: serverTimestamp() });
        }

        await logAudit("PUBLISH_DOCUMENT", "repair_documents", docId, `${docType}: ${title}`);
        $("document-form").reset();
        $("doc-id").value = "";
        $("doc-published").checked = true;
        showToast(`Published "${title}"!`);
      } catch (err) {
        setBanner("doc-status-box", "error", `Save failed: ${err.message}`);
      } finally {
        btn.disabled = false;
        btn.textContent = "Save & Publish Document";
      }
    });
  }

  function renderDocuments() {
    const list = $("documents-list");
    if (!list) return;
    list.replaceChildren();
    if (state.documents.length === 0) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "No PDFs or Circuit Diagrams published yet.";
      list.append(p);
      return;
    }
    state.documents.forEach((d) => {
      const row = document.createElement("div");
      row.className = "list-item";
      const left = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = `[${d.docType}] ${d.title}`;
      const meta = document.createElement("div");
      meta.style.fontSize = "12px";
      meta.style.color = "var(--text-muted)";
      meta.textContent = `${(d.categoryId || "").toUpperCase()} • ${d.brandName || ""} ${d.modelName || ""} ${d.errorCode ? `• Code ${d.errorCode}` : ""} • ${d.published ? "PUBLISHED" : "DRAFT"}`;
      left.append(title, meta);

      const actions = document.createElement("div");
      actions.style.display = "flex";
      actions.style.gap = "6px";

      const toggleBtn = document.createElement("button");
      toggleBtn.type = "button";
      toggleBtn.className = "btn btn-outline btn-sm";
      toggleBtn.textContent = d.published ? "Unpublish" : "Publish";
      toggleBtn.addEventListener("click", async () => {
        await updateDoc(doc(db, "repair_documents", d.id), { published: !d.published, updatedAt: serverTimestamp() });
        showToast(d.published ? "Unpublished document" : "Published document");
      });

      const delBtn = document.createElement("button");
      delBtn.type = "button";
      delBtn.className = "btn btn-danger btn-sm";
      delBtn.textContent = "Delete";
      delBtn.addEventListener("click", async () => {
        await deleteDoc(doc(db, "repair_documents", d.id));
        await logAudit("DELETE_DOCUMENT", "repair_documents", d.id, d.title || d.id);
        showToast("Deleted document");
      });

      actions.append(toggleBtn, delBtn);
      row.append(left, actions);
      list.append(row);
    });
  }

  // ---------------- TECHNICIANS MANAGEMENT ----------------
  function renderTechnicians() {
    const list = $("technicians-list");
    if (!list) return;
    list.replaceChildren();
    if (state.technicians.length === 0) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "No technician registrations submitted yet.";
      list.append(p);
      return;
    }
    state.technicians.forEach((t) => {
      const row = document.createElement("div");
      row.className = "list-item";
      const left = document.createElement("div");
      const name = document.createElement("strong");
      name.textContent = `${t.fullName || "Unnamed"} ${t.verified ? "✓ VERIFIED" : ""}`;
      const meta = document.createElement("div");
      meta.style.fontSize = "12px";
      meta.style.color = "var(--text-muted)";
      meta.textContent = `${t.city || ""} • ${t.serviceLocation || ""} • ${t.experienceYears || 0} yrs • ${t.publicPhone || ""} • Status: ${t.approvalStatus || "PENDING"}${t.blocked ? " • BLOCKED" : ""}`;
      left.append(name, meta);

      const actions = document.createElement("div");
      actions.style.display = "flex";
      actions.style.gap = "6px";
      actions.style.flexWrap = "wrap";

      const addAct = (label, cls, patch) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = `btn ${cls} btn-sm`;
        b.textContent = label;
        b.addEventListener("click", async () => {
          await updateDoc(doc(db, "technicians", t.id), { ...patch, updatedAt: serverTimestamp() });
          await logAudit("MANAGE_TECHNICIAN", "technicians", t.id, `${label}: ${t.fullName}`);
          showToast(`Updated technician ${t.fullName}`);
        });
        actions.append(b);
      };

      const viewIdBtn = document.createElement("button");
      viewIdBtn.type = "button";
      viewIdBtn.className = "btn btn-outline btn-sm";
      viewIdBtn.textContent = "Inspect ID";
      viewIdBtn.addEventListener("click", async () => {
        try {
          const privSnap = await getDoc(doc(db, "technicians", t.id, "private_verification", "primary_id"));
          if (!privSnap.exists() || !privSnap.data()?.docUrl) {
            showToast("No private ID document uploaded by this technician.");
            return;
          }
          const rawUrl = String(privSnap.data().docUrl);
          if (rawUrl.startsWith("private://")) {
            const signedRes = await callSupabaseEdge("repair-pro-api", "POST", { privateUrl: rawUrl }, "/admin/verification/signed-url");
            if (signedRes.ok && signedRes.data?.signedUrl) {
              window.open(signedRes.data.signedUrl, "_blank", "noopener,noreferrer");
            } else {
              showToast(`Unable to mint signed URL: ${signedRes.error}`);
            }
          } else if (rawUrl.startsWith("https://")) {
            window.open(rawUrl, "_blank", "noopener,noreferrer");
          }
        } catch (err) {
          showToast(`Verification check failed: ${err?.message || "Permission denied"}`);
        }
      });

      addAct("Approve & Verify", "btn-success", { approvalStatus: "APPROVED", verified: true, active: true, blocked: false });
      addAct("Reject", "btn-outline", { approvalStatus: "REJECTED", verified: false, active: false });
      addAct(t.blocked ? "Unblock" : "Block", "btn-danger", { blocked: !t.blocked, active: Boolean(t.blocked) });
      actions.append(viewIdBtn);

      row.append(left, actions);
      list.append(row);
    });
  }

  // ---------------- COMMUNITY MODERATION ----------------
  function renderCommunity() {
    const list = $("community-list");
    if (!list) return;
    list.replaceChildren();
    if (state.posts.length === 0) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "No community posts yet.";
      list.append(p);
      return;
    }
    state.posts.forEach((p) => {
      const row = document.createElement("div");
      row.className = "list-item";
      const left = document.createElement("div");
      const statusLabel = p.moderationStatus || "APPROVED";
      const t = document.createElement("strong");
      t.textContent = `${p.title || "(No title)"} [${statusLabel}]`;
      const body = document.createElement("div");
      body.style.fontSize = "13px";
      body.style.color = "var(--text-muted)";
      body.textContent = `${p.authorName || "User"} • ${(p.categoryId || "").toUpperCase()} • Likes: ${p.likesCount || 0} • ${String(p.body || "").slice(0, 140)}`;
      left.append(t, body);

      const actions = document.createElement("div");
      actions.style.display = "flex";
      actions.style.gap = "6px";

      const appBtn = document.createElement("button");
      appBtn.type = "button";
      appBtn.className = "btn btn-success btn-sm";
      appBtn.textContent = "Approve";
      appBtn.addEventListener("click", async () => {
        await updateDoc(doc(db, "community_posts", p.id), {
          moderationStatus: "APPROVED",
          rejectionReason: "",
          updatedAt: serverTimestamp()
        });
        await logAudit("MODERATE_POST", "community_posts", p.id, "APPROVED");
        showToast("Post approved");
      });

      const rejectBtn = document.createElement("button");
      rejectBtn.type = "button";
      rejectBtn.className = "btn btn-outline btn-sm";
      rejectBtn.textContent = "Reject / Hide";
      rejectBtn.addEventListener("click", async () => {
        await updateDoc(doc(db, "community_posts", p.id), {
          moderationStatus: "REJECTED",
          rejectionReason: "Removed by moderator",
          updatedAt: serverTimestamp()
        });
        await logAudit("MODERATE_POST", "community_posts", p.id, "REJECTED");
        showToast("Post hidden (REJECTED)");
      });

      const delBtn = document.createElement("button");
      delBtn.type = "button";
      delBtn.className = "btn btn-danger btn-sm";
      delBtn.textContent = "Delete";
      delBtn.addEventListener("click", async () => {
        await deleteDoc(doc(db, "community_posts", p.id));
        await logAudit("DELETE_COMMUNITY_POST", "community_posts", p.id, p.title || p.id);
        showToast("Post deleted");
      });

      actions.append(appBtn, rejectBtn, delBtn);
      row.append(left, actions);
      list.append(row);
    });
  }

  function renderCommunityReports() {
    const list = $("community-reports-list");
    if (!list) return;
    list.replaceChildren();
    if (state.communityReports.length === 0) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "No flagged community posts.";
      list.append(p);
      return;
    }
    state.communityReports.forEach((r) => {
      const row = document.createElement("div");
      row.className = "list-item";
      const left = document.createElement("div");
      left.textContent = `Post ${r.postId} — Reason: ${r.reason} (${r.status})`;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn btn-outline btn-sm";
      btn.textContent = "Mark Resolved";
      btn.addEventListener("click", async () => {
        await updateDoc(doc(db, "community_reports", r.id), { status: "RESOLVED" });
        showToast("Report resolved");
      });
      row.append(left, btn);
      list.append(row);
    });
  }

  // ---------------- USERS MANAGEMENT ----------------
  function renderUsers() {
    const list = $("users-list");
    if (!list) return;
    list.replaceChildren();
    if (state.users.length === 0) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "No users synced yet.";
      list.append(p);
      return;
    }
    state.users.forEach((u) => {
      const blocked = Boolean(u.isBlocked);
      const row = document.createElement("div");
      row.className = "list-item";
      const left = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = `${u.displayName || "Repair Pro User"} ${blocked ? "(BLOCKED)" : ""}`;
      const meta = document.createElement("div");
      meta.style.fontSize = "12px";
      meta.style.color = "var(--text-muted)";
      meta.textContent = `${u.email || ""} • UID: ${u.id} • Lang: ${(u.preferredLanguage || "en").toUpperCase()}`;
      left.append(title, meta);

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = blocked ? "btn btn-success btn-sm" : "btn btn-danger btn-sm";
      btn.textContent = blocked ? "Unblock User" : "Block User";
      btn.addEventListener("click", async () => {
        const nextBlocked = !blocked;
        await updateDoc(doc(db, "users", u.id), { isBlocked: nextBlocked, updatedAt: serverTimestamp() });
        await logAudit(nextBlocked ? "BLOCK_USER" : "UNBLOCK_USER", "users", u.id, u.email || u.id);
        showToast(nextBlocked ? "User blocked" : "User unblocked");
      });
      row.append(left, btn);
      list.append(row);
    });
  }

  // ---------------- MULTI-CLOUD STORAGE MANAGER (SUPABASE AUTHORITATIVE) ----------------
  function resetStorageForm() {
    $("storage-provider-form")?.reset();
    if ($("sp-id")) $("sp-id").value = "";
    if ($("sp-region")) $("sp-region").value = "auto";
    if ($("storage-form-heading")) $("storage-form-heading").textContent = "Multi-Cloud Storage Manager & Automatic Failover";
    if ($("sp-submit-btn")) $("sp-submit-btn").textContent = "+ Save Storage Provider";
    $("sp-cancel-edit-btn")?.classList.add("hidden");
  }

  function initStorageManager() {
    $("refresh-storage-btn")?.addEventListener("click", () => refreshStorageOverviewFromSupabase(true));
    $("sp-cancel-edit-btn")?.addEventListener("click", resetStorageForm);

    $("storage-provider-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const user = getCurrentUser();
      if (!user) return;
      const existingId = ($("sp-id")?.value || "").trim();
      const name = $("sp-name").value.trim();
      const endpointUrl = $("sp-endpoint").value.trim();
      if (!name || !endpointUrl) return;

      if (!getSupabaseAnonKey()) {
        setBanner(
          "storage-action-banner",
          "error",
          "Cannot register storage provider: Supabase Public Anon Key is missing. Configure it in 'Firebase & Supabase Status' first (Firestore-only registration fallback has been removed)."
        );
        return;
      }

      const providerType = normalizeProviderType($("sp-type").value);
      const projectRef = $("sp-bucket").value.trim() || "default";
      const region = ($("sp-region")?.value || "").trim() || (providerType === "CLOUDFLARE_R2" ? "auto" : "us-east-1");
      const publicBaseUrl = ($("sp-public-base")?.value || "").trim();
      const quotaMb = Math.max(50, Number($("sp-quota").value) || 1024);
      const capacityBytes = quotaMb * 1024 * 1024;
      const defaultSecret = providerType === "SUPABASE"
        ? "SUPABASE_SERVICE_ROLE_KEY"
        : providerType === "CLOUDFLARE_R2"
        ? "R2_STORAGE_CREDS"
        : providerType === "BACKBLAZE_B2"
        ? "B2_STORAGE_CREDS"
        : "S3_STORAGE_CREDS";
      const secretEnvKey = ($("sp-secret-ref").value.trim() || defaultSecret).toUpperCase().replace(/[^A-Z0-9_]/g, "");
      const existingList = getActiveProviders();
      const existingRow = existingList.find((x) => x.id === existingId);
      const isPrimary = existingRow ? existingRow.primary : existingList.length === 0;

      const edgeRes = await callSupabaseEdge("repair-pro-api", "POST", {
        id: existingId || undefined,
        name,
        providerType,
        endpointUrl,
        projectRef,
        region,
        publicBaseUrl: publicBaseUrl || undefined,
        secretEnvKey,
        capacityBytes,
        isPrimary,
        isBackup: existingRow ? existingRow.backup : !isPrimary,
        isEnabled: existingRow ? existingRow.enabled : true,
        autoFailoverEnabled: existingRow ? existingRow.autoFailoverEnabled : true
      }, "/admin/storage/providers");

      if (edgeRes.ok && edgeRes.data?.provider) {
        const rawList = Array.isArray(edgeRes.data.providers) ? edgeRes.data.providers : [edgeRes.data.provider];
        state.supabaseProviders = rawList.map(mapSupabaseProviderRow);
        renderStorageProviders();
        onCountsChanged(state);
        await mirrorProvidersToFirestore(rawList);
        await logAudit(existingId ? "UPDATE_STORAGE_PROVIDER" : "ADD_STORAGE_PROVIDER", "storage_providers", edgeRes.data.provider.id, `${name} (${endpointUrl})`);
        const secState = edgeRes.data.provider.secret_configured ? "Secret active" : `Set secret ${secretEnvKey} in Supabase Secrets`;
        setBanner("storage-action-banner", "success", `Saved "${name}" to authoritative Supabase registry (${secState}).`);
        resetStorageForm();
      } else {
        setBanner("storage-action-banner", "error", `Authoritative Supabase registration failed: ${edgeRes.error}`);
      }
    });
  }

  async function runProviderAction(provider, action, extraBody = {}) {
    if (!getSupabaseAnonKey()) {
      setBanner("storage-action-banner", "error", "Configure Supabase Anon Key in 'Firebase & Supabase Status' to run authoritative storage actions.");
      return;
    }
    const res = await callSupabaseEdge("repair-pro-api", "POST", {
      providerId: provider.id,
      action,
      ...extraBody
    }, "/admin/storage/providers/action");

    if (res.ok) {
      if (Array.isArray(res.data?.providers)) {
        state.supabaseProviders = res.data.providers.map(mapSupabaseProviderRow);
        renderStorageProviders();
        onCountsChanged(state);
        await mirrorProvidersToFirestore(res.data.providers);
      } else {
        await refreshStorageOverviewFromSupabase(false);
      }
      if (action === "TEST") {
        const status = res.data?.status || "CONNECTED";
        const msg = res.data?.message || "Healthy";
        setBanner("storage-action-banner", res.data?.connected ? "success" : "warn", `${provider.name}: ${status} — ${msg}`);
      } else if (action === "MIGRATE") {
        const count = Number(res.data?.migratedCount || 0);
        const failed = Number(res.data?.failedCount || 0);
        const kb = Math.round(Number(res.data?.bytesMigrated || 0) / 1024);
        const shaNote = res.data?.checksumVerified ? "SHA-256 verified" : "check error logs";
        setBanner(
          "storage-action-banner",
          failed === 0 ? "success" : "warn",
          `Migrated ${count} file(s) (${kb} KB, ${shaNote})${failed > 0 ? `, ${failed} failed` : ""}. Remaining on ${provider.name}: ${res.data?.remainingOnSource ?? 0}.`
        );
        await refreshStorageOverviewFromSupabase(false);
      } else {
        showToast(`Updated ${provider.name} (${action})`);
      }
    } else {
      setBanner("storage-action-banner", "error", `${provider.name} (${action}): ${res.error}`);
    }
  }

  function renderStorageProviders() {
    const list = $("storage-providers-list");
    if (!list) return;
    list.replaceChildren();
    if (!getSupabaseAnonKey()) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "Configure your Supabase Public Anon Key in 'Firebase & Supabase Status' to load the authoritative storage registry.";
      list.append(p);
      return;
    }
    const providers = getActiveProviders();
    if (providers.length === 0) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "No storage providers returned yet. Click 'Refresh Registry' or add one above.";
      list.append(p);
      return;
    }

    providers.forEach((p) => {
      const row = document.createElement("div");
      row.className = "list-item";
      row.style.flexDirection = "column";
      row.style.alignItems = "stretch";
      row.style.gap = "10px";

      const left = document.createElement("div");
      const title = document.createElement("strong");
      const roleTag = p.primary ? "★ PRIMARY" : p.backup ? "• BACKUP" : "• STANDBY";
      const stateTag = p.enabled ? "" : " (DISABLED)";
      const foTag = p.autoFailoverEnabled ? " • Auto-Failover ON" : " • Auto-Failover OFF";
      const secTag = p.secretConfigured === true
        ? " • Secret OK"
        : p.secretConfigured === false
        ? ` • Secret Missing (${p.secretEnvKey})`
        : "";
      title.textContent = `${p.name} (${p.providerType}) ${roleTag}${stateTag}${foTag}${secTag}`;

      const usedMb = Math.round((p.usedBytes || 0) / (1024 * 1024));
      const quotaMb = Math.max(1, Math.round((p.capacityBytes || 1073741824) / (1024 * 1024)));
      const meta = document.createElement("div");
      meta.style.fontSize = "12px";
      meta.style.color = "var(--text-muted)";
      meta.textContent = `${p.endpointUrl} • Bucket/Ref: ${p.projectRef || "default"} • Region: ${p.region || "auto"} • Active Files: ${p.activeFilesCount || 0} • ${usedMb}/${quotaMb} MB • Health: ${p.lastTestStatus || "UNTESTED"} ${p.lastTestMessage ? `(${p.lastTestMessage})` : ""}`;
      left.append(title, meta);

      const actions = document.createElement("div");
      actions.style.display = "flex";
      actions.style.gap = "6px";
      actions.style.flexWrap = "wrap";
      actions.style.alignItems = "center";

      const mkBtn = (text, cls, handler, disabled = false) => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = `btn ${cls} btn-sm`;
        btn.textContent = text;
        btn.disabled = disabled;
        btn.addEventListener("click", handler);
        return btn;
      };

      actions.append(
        mkBtn("Edit", "btn-outline", () => {
          if ($("sp-id")) $("sp-id").value = p.id;
          $("sp-name").value = p.name;
          $("sp-type").value = p.providerType;
          $("sp-endpoint").value = p.endpointUrl;
          $("sp-bucket").value = p.projectRef || "";
          if ($("sp-region")) $("sp-region").value = p.region || "auto";
          if ($("sp-public-base")) $("sp-public-base").value = p.publicBaseUrl || "";
          $("sp-quota").value = String(Math.max(50, Math.round((p.capacityBytes || 1073741824) / (1024 * 1024))));
          $("sp-secret-ref").value = p.secretEnvKey || "";
          if ($("storage-form-heading")) $("storage-form-heading").textContent = `Editing Storage Provider: ${p.name}`;
          if ($("sp-submit-btn")) $("sp-submit-btn").textContent = "Save Provider Changes";
          $("sp-cancel-edit-btn")?.classList.remove("hidden");
          $("storage-provider-form")?.scrollIntoView({ behavior: "smooth" });
        }),
        mkBtn("Test Connection", "btn-outline", () => runProviderAction(p, "TEST")),
        mkBtn("Set Primary", "btn-success", () => runProviderAction(p, "SET_PRIMARY")),
        mkBtn("Set Backup", "btn-outline", () => runProviderAction(p, "SET_BACKUP")),
        mkBtn(p.autoFailoverEnabled ? "Failover Off" : "Failover On", "btn-outline", () => runProviderAction(p, "TOGGLE_FAILOVER")),
        mkBtn(p.enabled ? "Disable" : "Enable", "btn-outline", () => runProviderAction(p, "TOGGLE_ENABLED")),
        mkBtn(
          p.activeFilesCount > 0 ? `Delete (${p.activeFilesCount} files)` : "Delete",
          "btn-danger",
          () => runProviderAction(p, "DELETE"),
          p.activeFilesCount > 0
        )
      );

      // Safe SHA-256 verified file migration controls
      const otherTargets = providers.filter((other) => other.id !== p.id && other.enabled);
      if ((p.activeFilesCount || 0) > 0 && otherTargets.length > 0) {
        const targetSelect = document.createElement("select");
        targetSelect.style.padding = "4px 8px";
        targetSelect.style.fontSize = "12px";
        otherTargets.forEach((optP) => {
          const opt = document.createElement("option");
          opt.value = optP.id;
          opt.textContent = `Migrate → ${optP.name}`;
          targetSelect.append(opt);
        });
        actions.append(
          targetSelect,
          mkBtn("Migrate Files", "btn-primary", () =>
            runProviderAction(p, "MIGRATE", { targetProviderId: targetSelect.value })
          )
        );
      }

      row.append(left, actions);
      list.append(row);
    });
  }

  function renderFileRegistry() {
    const list = $("file-registry-list");
    if (!list) return;
    list.replaceChildren();
    const files = Array.isArray(state.supabaseFiles) ? state.supabaseFiles : state.fileRegistry;
    if (files.length === 0) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "Uploaded files are indexed in Supabase storage_file_registry with provider ID, bucket, MIME type, SHA-256 checksum, and size.";
      list.append(p);
      return;
    }
    files.slice(0, 30).forEach((f) => {
      const row = document.createElement("div");
      row.className = "list-item";
      const left = document.createElement("div");
      const fileName = f.original_filename || f.fileName || f.id;
      const providerId = f.provider_id || f.providerId || "-";
      const bucketName = f.bucket_name || f.bucketName || "-";
      const sizeKb = f.size_bytes ? `${Math.max(1, Math.round(f.size_bytes / 1024))} KB` : "";
      const sha = f.sha256_checksum ? ` • sha256:${String(f.sha256_checksum).slice(0, 10)}…` : "";
      left.textContent = `${fileName} • Bucket: ${bucketName} • Provider: ${providerId}${sizeKb ? ` • ${sizeKb}` : ""}${sha}${f.is_private ? " • PRIVATE" : ""}`;
      row.append(left);
      list.append(row);
    });
  }

  // ---------------- HEALTH & ERROR LOGS ----------------
  function initHealthPanel() {
    const existing = getSupabaseAnonKey();
    if ($("supabase-anon-key-input") && existing) {
      $("supabase-anon-key-input").value = existing;
    }

    $("supabase-key-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      setSupabaseAnonKey($("supabase-anon-key-input").value);
      await checkSupabaseHealth();
      await refreshStorageOverviewFromSupabase(false);
    });

    $("test-supabase-health-btn")?.addEventListener("click", async () => {
      await checkSupabaseHealth();
      await refreshStorageOverviewFromSupabase(false);
    });
  }

  async function checkSupabaseHealth() {
    const badge = $("supabase-health-badge");
    const msg = $("supabase-health-msg");
    if (!badge || !msg) return;
    badge.className = "badge badge-amber";
    badge.textContent = "CHECKING…";

    const res = await callSupabaseEdge("repair-pro-api", "GET", null, "/health");
    if (res.ok) {
      badge.className = "badge badge-green";
      badge.textContent = "CONNECTED";
      msg.textContent = `Edge API healthy on ${SUPABASE_PROJECT_REF} • v${res.data?.version || res.data?.appVersion || "3.0"}`;
    } else {
      badge.className = "badge badge-red";
      badge.textContent = "ACTION REQUIRED";
      msg.textContent = res.error;
    }
  }

  function renderErrorLogs() {
    const list = $("error-logs-list");
    if (!list) return;
    list.replaceChildren();
    const combined = [
      ...(Array.isArray(state.supabaseErrorLogs)
        ? state.supabaseErrorLogs.map((e) => ({
            severity: `HTTP ${e.http_status || 500}`,
            source: `${e.provider_name || "storage"} (${e.operation || e.error_code || "UPLOAD"})`,
            message: e.error_message || ""
          }))
        : []),
      ...state.errorLogs
    ];
    if (combined.length === 0) {
      const p = document.createElement("p");
      p.className = "subtitle";
      p.textContent = "No system or storage failover errors logged.";
      list.append(p);
      return;
    }
    combined.slice(0, 30).forEach((e) => {
      const row = document.createElement("div");
      row.className = "list-item";
      const left = document.createElement("div");
      const title = document.createElement("strong");
      title.style.color = "var(--error)";
      title.textContent = `[${e.severity || "ERROR"}] ${e.source || "system"}`;
      const desc = document.createElement("div");
      desc.style.fontSize = "13px";
      desc.textContent = e.message || "";
      left.append(title, desc);
      row.append(left);
      list.append(row);
    });
  }

  function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const s = String(reader.result || "");
        resolve(s.includes(",") ? s.split(",")[1] : s);
      };
      reader.onerror = () => reject(new Error("Failed to read file"));
      reader.readAsDataURL(file);
    });
  }

  initPushCenter();
  initDocumentsManager();
  initStorageManager();
  initHealthPanel();

  return {
    state,
    attachStreams,
    checkSupabaseHealth,
    refreshStorageOverviewFromSupabase,
    syncRemoteSettings,
    getActiveProviders
  };
}

