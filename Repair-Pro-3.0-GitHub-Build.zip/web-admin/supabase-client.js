import {
  DEFAULT_SUPABASE_BUCKETS,
  FREE_TIER_STORAGE_LIMIT_BYTES,
  SUPABASE_URL
} from "./firebase-config.js";

const STORAGE_KEY_ANON = "repairpro_supabase_anon_key";
const STORAGE_KEY_URL = "repairpro_supabase_url";

export function getSupabaseUrl() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_URL);
    if (saved && /^https:\/\//i.test(saved)) return saved.replace(/\/+$/, "");
  } catch { /* ignore */ }
  return SUPABASE_URL.replace(/\/+$/, "");
}

export function setSupabaseUrl(url) {
  const clean = String(url || "").trim().replace(/\/+$/, "");
  if (!/^https:\/\//i.test(clean)) return;
  try { localStorage.setItem(STORAGE_KEY_URL, clean); } catch { /* ignore */ }
}

export function getSupabaseAnonKey() {
  try {
    return (localStorage.getItem(STORAGE_KEY_ANON) || "").trim();
  } catch {
    return "";
  }
}

export function setSupabaseAnonKey(key) {
  const clean = String(key || "").trim();
  try {
    if (clean) localStorage.setItem(STORAGE_KEY_ANON, clean);
  } catch { /* ignore */ }
}

export async function sbFetch(path, options = {}, currentUser = null) {
  const anonKey = getSupabaseAnonKey();
  if (!anonKey) {
    throw new Error("Supabase Public Anon Key is missing. Paste it on the Login screen or Storage Manager.");
  }
  const url = path.startsWith("http") ? path : `${getSupabaseUrl()}${path}`;
  const run = async (forceRefresh) => {
    const bearer = currentUser ? await currentUser.getIdToken(forceRefresh) : anonKey;
    return fetch(url, {
      ...options,
      headers: {
        apikey: anonKey,
        Authorization: `Bearer ${bearer}`,
        ...(options.headers || {})
      }
    });
  };
  let resp = await run(false);
  if (resp.status === 401 && currentUser) {
    resp = await run(true);
  }
  return resp;
}

export async function sbSelect(table, query = "", currentUser = null) {
  const q = query ? (query.startsWith("?") ? query : `?${query}`) : "?select=*";
  const resp = await sbFetch(`/rest/v1/${table}${q}`, { method: "GET" }, currentUser);
  if (!resp.ok) {
    const txt = await resp.text().catch(() => "");
    throw new Error(`Supabase SELECT ${table} HTTP ${resp.status}: ${txt.slice(0, 180)}`);
  }
  return await resp.json();
}

export async function sbUpsert(table, rowOrRows, onConflict, currentUser) {
  const q = onConflict ? `?on_conflict=${encodeURIComponent(onConflict)}` : "";
  const resp = await sbFetch(`/rest/v1/${table}${q}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates,return=representation"
    },
    body: JSON.stringify(rowOrRows)
  }, currentUser);
  if (!resp.ok) {
    const txt = await resp.text().catch(() => "");
    throw new Error(`Supabase UPSERT ${table} HTTP ${resp.status}: ${txt.slice(0, 200)}`);
  }
  return await resp.json().catch(() => []);
}

export async function sbUpdate(table, filterQuery, patch, currentUser) {
  const q = filterQuery.startsWith("?") ? filterQuery : `?${filterQuery}`;
  const resp = await sbFetch(`/rest/v1/${table}${q}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      Prefer: "return=representation"
    },
    body: JSON.stringify(patch)
  }, currentUser);
  if (!resp.ok) {
    const txt = await resp.text().catch(() => "");
    throw new Error(`Supabase PATCH ${table} HTTP ${resp.status}: ${txt.slice(0, 200)}`);
  }
  return await resp.json().catch(() => []);
}

export async function sbDelete(table, filterQuery, currentUser) {
  const q = filterQuery.startsWith("?") ? filterQuery : `?${filterQuery}`;
  const resp = await sbFetch(`/rest/v1/${table}${q}`, { method: "DELETE" }, currentUser);
  if (!resp.ok) {
    const txt = await resp.text().catch(() => "");
    throw new Error(`Supabase DELETE ${table} HTTP ${resp.status}: ${txt.slice(0, 200)}`);
  }
}

export async function sbGetSetting(settingId, currentUser = null) {
  const rows = await sbSelect(
    "app_settings",
    `setting_id=eq.${encodeURIComponent(settingId)}&select=setting_id,config_type,payload,updated_at&limit=1`,
    currentUser
  );
  return Array.isArray(rows) && rows[0] ? rows[0].payload || {} : null;
}

export async function sbSaveSetting(settingId, configType, payload, actorUid, currentUser) {
  await sbUpsert("app_settings", {
    setting_id: settingId,
    config_type: configType,
    payload,
    updated_by_uid: actorUid || ""
  }, "setting_id", currentUser);
}

export async function fileToBase64(fileOrBlob) {
  const buf = await fileOrBlob.arrayBuffer();
  const bytes = new Uint8Array(buf);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

// =========================================================================
// ROW MAPPERS (Supabase snake_case <-> Web Admin camelCase)
// =========================================================================

const parseStringArray = (val, fallbackJson, def = []) => {
  if (Array.isArray(val)) return val;
  const raw = typeof fallbackJson === "string" && fallbackJson.trim() ? fallbackJson : (typeof val === "string" && val.trim() ? val : "");
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    } catch { /* ignore */ }
  }
  return def;
};

export const mapCatalogRow = (r) => ({
  id: r.id,
  entryType: r.entry_type || "ERROR_CODE",
  categoryId: r.category_id || "ac",
  brandName: r.brand_name || "",
  modelSeries: r.model_series || "",
  code: r.code || "",
  titleEn: r.title_en || "",
  titleBn: r.title_bn || "",
  titleHi: r.title_hi || "",
  summaryEn: r.summary_en || "",
  summaryBn: r.summary_bn || "",
  summaryHi: r.summary_hi || "",
  stepsEn: r.steps_en || "",
  stepsBn: r.steps_bn || "",
  stepsHi: r.steps_hi || "",
  safetyWarningEn: r.safety_warning_en || "",
  verificationStatus: r.verification_status || "VERIFIED",
  published: r.published !== false && Number(r.published) !== 0,
  revision: Number(r.revision || 1),
  storageProviderId: r.storage_provider_id || "supabase_primary",
  updatedAt: r.updated_at,
  createdAt: r.created_at
});

export const mapTechRow = (r) => ({
  id: r.technician_id,
  technicianId: r.technician_id,
  fullName: r.full_name || "",
  photoUrl: r.photo_url || "",
  photoStoragePath: r.photo_storage_path || "",
  photoProviderId: r.photo_provider_id || "",
  mobileNumber: r.mobile_number || "",
  fullAddress: r.full_address || "",
  state: r.state || "",
  district: r.district || "",
  cityArea: r.city_area || "",
  pinCode: r.pin_code || "",
  serviceCategories: parseStringArray(r.service_categories, r.service_categories_json, ["AC"]),
  experience: r.experience || "",
  bio: r.bio || "",
  verificationStatus: r.verification_status || "VERIFIED",
  blocked: Boolean(Number(r.blocked ?? 0) || r.blocked === true),
  isSuspended: Boolean(Number(r.is_suspended ?? 0) || r.is_suspended === true),
  isDeleted: Boolean(Number(r.is_deleted ?? 0) || r.is_deleted === true),
  status: r.status || "ACTIVE",
  storageProviderId: r.storage_provider_id || "supabase_primary",
  updatedAt: r.updated_at
});

export const mapVerificationRow = (r) => ({
  id: r.user_id,
  userId: r.user_id,
  fullName: r.full_name || "",
  mobileNumber: r.mobile_number || "",
  fullAddress: r.full_address || "",
  state: r.state || "",
  district: r.district || "",
  cityArea: r.city_area || "",
  pinCode: r.pin_code || "",
  serviceCategories: parseStringArray(r.service_categories, r.service_categories_json, ["AC"]),
  experience: r.experience || "",
  bio: r.bio || "",
  profilePhotoUrl: r.profile_photo_url || "",
  profilePhotoStoragePath: r.profile_photo_storage_path || "",
  profilePhotoProviderId: r.profile_photo_provider_id || "",
  credentialDocUrl: r.credential_doc_url || "",
  credentialDocStoragePath: r.credential_doc_storage_path || "",
  credentialDocProviderId: r.credential_doc_provider_id || "",
  credentialDocName: r.credential_doc_name || "",
  status: r.status || "PENDING",
  rejectionReason: r.rejection_reason || "",
  storageProviderId: r.storage_provider_id || "supabase_primary",
  updatedAt: r.updated_at
});

export const mapCommunityPostRow = (r) => ({
  id: r.post_id,
  postId: r.post_id,
  authorUid: r.author_uid || "",
  authorName: r.author_name || "",
  authorVerified: Boolean(Number(r.author_verified ?? 0) || r.author_verified === true),
  category: r.category || "General",
  brandName: r.brand_name || "",
  modelName: r.model_name || "",
  errorCode: r.error_code || "",
  title: r.title || "",
  body: r.body || "",
  photoUrl: r.photo_url || "",
  photoStoragePath: r.photo_storage_path || "",
  photoUrls: parseStringArray(r.photo_urls, r.photo_urls_json, []),
  photoStoragePaths: parseStringArray(r.photo_storage_paths, r.photo_storage_paths_json, []),
  photoProviderIds: parseStringArray(r.photo_provider_ids, r.photo_provider_ids_json, []),
  isPinned: Boolean(Number(r.is_pinned ?? 0) || r.is_pinned === true),
  isHidden: Boolean(Number(r.is_hidden ?? 0) || r.is_hidden === true),
  isDeleted: Boolean(Number(r.is_deleted ?? 0) || r.is_deleted === true),
  approvalStatus: r.approval_status || "PENDING",
  storageProviderId: r.storage_provider_id || "supabase_primary",
  createdAt: r.created_at
});

export const mapCommunityReportRow = (r) => ({
  id: r.report_id,
  reportId: r.report_id,
  postId: r.post_id,
  commentId: r.comment_id || "",
  reporterUid: r.reporter_uid || "",
  reporterName: r.reporter_name || "",
  reason: r.reason || "OTHER",
  details: r.details || "",
  status: r.status || "OPEN",
  createdAt: r.created_at
});

export const mapCommunityRestrictionRow = (r) => ({
  id: r.user_id,
  userId: r.user_id,
  userName: r.user_name || "",
  reason: r.reason || "",
  createdAt: r.created_at
});

export const mapDocumentRow = (r) => ({
  id: r.doc_id,
  docId: r.doc_id,
  docType: r.doc_type || "PDF_MANUAL",
  categoryId: r.category_id || "ac",
  brandName: r.brand_name || "",
  modelName: r.model_name || "",
  linkedEntryId: r.linked_entry_id || "",
  title: r.title || "",
  description: r.description || "",
  fileUrl: r.file_url || "",
  storagePath: r.storage_path || "",
  storageProviderId: r.storage_provider_id || "supabase_primary",
  mimeType: r.mime_type || "application/pdf",
  fileSizeBytes: Number(r.file_size_bytes || 0),
  published: r.published !== false && Number(r.published) !== 0,
  offlineAvailable: Boolean(Number(r.offline_available ?? 0) || r.offline_available === true),
  isDeleted: Boolean(Number(r.is_deleted ?? 0) || r.is_deleted === true),
  updatedAt: r.updated_at
});

export const mapAnnouncementRow = (r) => ({
  id: r.announcement_id,
  announcementId: r.announcement_id,
  title: r.title || "",
  body: r.body || "",
  category: r.category || "GENERAL",
  imageUrl: r.image_url || "",
  targetRoute: r.target_route || "",
  createdAt: r.created_at
});

export const mapPushHistoryRow = (r) => ({
  id: r.push_id,
  pushId: r.push_id,
  audience: r.audience || "ALL",
  eventType: r.event_type || "ANNOUNCEMENT",
  title: r.title || "",
  body: r.body || "",
  imageUrl: r.image_url || "",
  targetRoute: r.target_route || "",
  deliveryStatus: r.delivery_status || "QUEUED",
  sentCount: Number(r.sent_count || 0),
  failedCount: Number(r.failed_count || 0),
  errorMessage: r.error_message || "",
  createdAt: r.created_at
});

export const mapUserRow = (r) => ({
  id: r.user_id,
  userId: r.user_id,
  displayName: r.display_name || "Repair Pro User",
  email: r.email || "",
  photoUrl: r.photo_url || "",
  isVerifiedTechnician: Boolean(r.is_verified_technician),
  accountStatus: r.account_status || "ACTIVE",
  blocked: Boolean(r.blocked),
  suspended: Boolean(r.suspended),
  communityRestricted: Boolean(r.community_restricted),
  uploadRestricted: Boolean(r.upload_restricted),
  moderationReason: r.moderation_reason || ""
});

export const mapProblemReportRow = (r) => ({
  id: r.report_id,
  reportId: r.report_id,
  userId: r.user_id || "",
  categoryId: r.category_id || "ac",
  brandName: r.brand_name || "",
  errorCode: r.error_code || "",
  description: r.description || "",
  status: r.status || "PENDING",
  createdAt: r.created_at
});

export const mapAuditLogRow = (r) => ({
  id: r.log_id,
  logId: r.log_id,
  adminUid: r.admin_uid || "",
  adminEmail: r.admin_email || "",
  action: r.action || "",
  targetType: r.target_type || "",
  targetId: r.target_id || "",
  details: r.details || "",
  result: r.result || "SUCCESS",
  createdAt: r.created_at
});

export const mapUploadHistoryRow = (r) => ({
  id: r.upload_id,
  providerId: r.provider_id || "",
  bucketName: r.bucket_name || "",
  objectPath: r.object_path || "",
  publicUrl: r.public_url || "",
  mimeType: r.mime_type || "",
  sizeBytes: Number(r.size_bytes || 0),
  failoverUsed: Boolean(r.failover_used),
  status: r.status || "SUCCESS",
  createdAt: r.created_at
});

export const mapStorageErrorRow = (r) => ({
  id: r.error_id,
  providerId: r.provider_id || "",
  bucketName: r.bucket_name || "",
  objectPath: r.object_path || "",
  errorMessage: r.error_message || "",
  failoverTargetId: r.failover_target_id || "",
  resolved: Boolean(r.resolved),
  createdAt: r.created_at
});

export const mapAiErrorRow = (r) => ({
  id: r.error_id,
  provider: r.provider || "",
  modelName: r.model_name || "",
  errorMessage: r.error_message || "",
  resolved: Boolean(r.resolved),
  createdAt: r.created_at
});

export const mapAdminRoleRow = (r) => ({
  id: r.user_id,
  userId: r.user_id,
  email: r.email || "",
  role: r.role || "CONTENT_EDITOR",
  createdAt: r.created_at
});

export const mapStorageProviderRow = (r) => {
  const meta = r.provider_metadata && typeof r.provider_metadata === "object" ? r.provider_metadata : {};
  return {
    providerId: r.provider_id,
    providerName: r.provider_name,
    providerType: r.provider_type,
    endpointUrl: r.endpoint_url,
    publicAnonKey: r.public_anon_key || "",
    proxyUploadUrl: r.proxy_upload_url || "",
    hostingVendor: r.hosting_vendor || "",
    publicMediaBaseUrl: r.public_media_base_url || "",
    communityOnly: Boolean(r.community_only),
    supportsStorage: r.supports_storage !== false,
    supportsDatabase: Boolean(r.supports_database),
    dbEnabled: Boolean(r.db_enabled),
    dbEngine: r.db_engine || "MYSQL",
    role: r.role || "BACKUP",
    enabled: r.enabled !== false,
    capacityLimitBytes: Number(r.capacity_limit_bytes || FREE_TIER_STORAGE_LIMIT_BYTES),
    usedBytes: Number(r.used_bytes || 0),
    lastStatus: r.last_status || "READY",
    categoryMappings: r.category_mappings && typeof r.category_mappings === "object" ? r.category_mappings : {},
    buckets: {
      community: r.bucket_community || DEFAULT_SUPABASE_BUCKETS.community,
      technicians: r.bucket_technicians || DEFAULT_SUPABASE_BUCKETS.technicians,
      pdfs: r.bucket_pdfs || DEFAULT_SUPABASE_BUCKETS.pdfs,
      diagrams: r.bucket_diagrams || DEFAULT_SUPABASE_BUCKETS.diagrams,
      verification: r.bucket_verification || DEFAULT_SUPABASE_BUCKETS.verification,
      user_profiles: r.bucket_user_profiles || DEFAULT_SUPABASE_BUCKETS.user_profiles
    },
    meta
  };
};

export async function syncStorageProvidersTable(providers, categoryMappings, actorUid, currentUser) {
  const rows = (providers || []).map((p) => {
    const b = p.buckets || DEFAULT_SUPABASE_BUCKETS;
    return {
      provider_id: p.providerId,
      provider_name: p.providerName,
      provider_type: p.providerType,
      endpoint_url: p.endpointUrl,
      public_anon_key: p.providerType === "SUPABASE_STORAGE" ? (p.publicAnonKey || "") : "",
      proxy_upload_url: p.proxyUploadUrl || "",
      hosting_vendor: p.hostingVendor || "",
      public_media_base_url: p.publicMediaBaseUrl || "",
      community_only: Boolean(p.communityOnly),
      supports_storage: p.supportsStorage !== false,
      supports_database: Boolean(p.supportsDatabase),
      db_enabled: Boolean(p.dbEnabled),
      db_engine: p.dbEngine || "MYSQL",
      bucket_community: b.community || DEFAULT_SUPABASE_BUCKETS.community,
      bucket_technicians: b.technicians || DEFAULT_SUPABASE_BUCKETS.technicians,
      bucket_pdfs: b.pdfs || DEFAULT_SUPABASE_BUCKETS.pdfs,
      bucket_diagrams: b.diagrams || DEFAULT_SUPABASE_BUCKETS.diagrams,
      bucket_verification: b.verification || DEFAULT_SUPABASE_BUCKETS.verification,
      bucket_user_profiles: b.user_profiles || DEFAULT_SUPABASE_BUCKETS.user_profiles,
      category_mappings: categoryMappings || {},
      role: p.role || "BACKUP",
      enabled: Boolean(p.enabled),
      capacity_limit_bytes: Number(p.capacityLimitBytes || FREE_TIER_STORAGE_LIMIT_BYTES),
      used_bytes: Number(p.usedBytes || 0),
      last_status: p.lastStatus || "READY",
      updated_by_uid: actorUid || ""
    };
  });
  if (rows.length) {
    await sbUpsert("storage_providers", rows, "provider_id", currentUser);
  }
}
