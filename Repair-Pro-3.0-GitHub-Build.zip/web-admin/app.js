import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import {
  browserLocalPersistence,
  getAuth,
  getRedirectResult,
  GoogleAuthProvider,
  onAuthStateChanged,
  setPersistence,
  signInWithPopup,
  signInWithRedirect,
  signOut
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  initializeFirestore,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import {
  deleteObject,
  getDownloadURL,
  getStorage,
  ref as storageRef,
  uploadBytesResumable
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-storage.js";
import {
  BOOTSTRAP_SUPER_ADMIN_EMAIL,
  DEFAULT_AI_PROXY_URL,
  DEFAULT_FCM_ENDPOINT,
  DEFAULT_HOSTING_PROXY_URL,
  DEFAULT_SUPABASE_BUCKETS,
  FIRESTORE_DATABASE_ID,
  FREE_TIER_STORAGE_LIMIT_BYTES,
  SUPABASE_PROJECT_REF,
  SUPABASE_URL,
  firebaseConfig
} from "./firebase-config.js";

// Initialize Firebase App & Persistent Auth Session (prevents reload/session loss)
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
setPersistence(auth, browserLocalPersistence).catch((err) => {
  console.warn("Persistence setup note:", err?.message || err);
});

const db = initializeFirestore(app, {}, FIRESTORE_DATABASE_ID);
const firebaseStorage = getStorage(app);

// Global defensive submit handler: never allow accidental browser GET/POST page reload
document.addEventListener("submit", (event) => {
  event.preventDefault();
});

const $ = (id) => document.getElementById(id);

const SECTION_TITLES = {
  dashboard: "Dashboard Overview",
  appliances: "Appliances & Multilingual Categories",
  catalog: "Error Codes & Guides",
  technicians: "Technician Management",
  verification: "Technician Verification Queue",
  community: "Technician Community Moderation",
  documents: "PDF Manuals & Circuit Diagrams",
  announcements: "Push Notifications & Alerts",
  storage: "Storage & Web Hosting Manager",
  ai: "AI Smart Repair Assistant",
  billing: "Billing, Invoices & Payment Reminders",
  reports: "User Problem Reports",
  admob: "Google AdMob Remote Controls",
  settings: "Online-Only App Settings",
  roles: "Admin Roles & Audit Logs"
};

let currentUser = null;
let currentIsBootstrapAdmin = false;
let unsubs = [];

let cachedCatalog = [];
let cachedReports = [];
let cachedAuditLogs = [];
let cachedTechnicians = [];
let cachedVerifications = [];
let cachedCommunityPosts = [];
let cachedCommunityReports = [];
let cachedCommunityRestrictions = [];
let cachedDocuments = [];
let cachedAnnouncements = [];
let cachedPushHistory = [];
let cachedUsers = [];
let cachedUploadHistory = [];
let cachedErrorLogs = [];
let cachedAiErrorLogs = [];

let pendingTechPhotoFile = null;
let removeTechPhotoRequested = false;

const DEFAULT_AI_BRANDS_JSON = JSON.stringify({
  "Air Conditioner": ["LG", "Voltas", "Daikin", "Blue Star", "Samsung", "Lloyd", "Hitachi", "Carrier", "Godrej", "Haier", "Whirlpool"],
  "Refrigerator": ["LG", "Samsung", "Whirlpool", "Godrej", "Haier", "Bosch", "Electrolux", "Voltas Beko"],
  "Washing Machine": ["LG", "Samsung", "Whirlpool", "IFB", "Bosch", "Haier", "Godrej", "Voltas Beko"]
}, null, 2);

const DEFAULT_BILLING_TEMPLATES = {
  en: "Hello {customerName}, your Repair Pro service invoice #{invoiceNumber} for {appliance} has a pending balance of {remainingBalance}. Total: {totalBill}, Paid: {amountReceived}. Due date: {dueDate}. Thank you!",
  bn: "নমস্কার {customerName}, আপনার {appliance} সার্ভিস ইনভয়েস #{invoiceNumber}-এর বকেয়া পরিমাণ {remainingBalance}। মোট বিল: {totalBill}, জমা: {amountReceived}। শেষ তারিখ: {dueDate}। ধন্যবাদ!",
  hi: "नमस्ते {customerName}, आपके {appliance} सर्विस इनवॉइस #{invoiceNumber} की बकाया राशि {remainingBalance} है। कुल बिल: {totalBill}, प्राप्त: {amountReceived}। अंतिम तिथि: {dueDate}। धन्यवाद!"
};

let storageState = {
  autoFailoverEnabled: true,
  fcmBackendUrl: DEFAULT_FCM_ENDPOINT,
  hostingProxyUrl: DEFAULT_HOSTING_PROXY_URL,
  compressionMaxDim: 1440,
  compressionQuality: 82,
  compressionMaxSizeKb: 4500,
  duplicateCheckEnabled: true,
  providers: [defaultSupabasePrimaryProvider()]
};

const AI_PROVIDER_PRESETS = {
  GEMINI: {
    label: "Google Gemini (Free Tier)",
    endpointUrl: "https://generativelanguage.googleapis.com",
    model: "gemini-2.5-flash",
    isFree: true
  },
  GROQ: {
    label: "Groq (Free Tier)",
    endpointUrl: "https://api.groq.com/openai/v1/chat/completions",
    model: "llama-3.3-70b-versatile",
    isFree: true
  },
  OPENROUTER: {
    label: "OpenRouter (Free Models)",
    endpointUrl: "https://openrouter.ai/api/v1/chat/completions",
    model: "meta-llama/llama-3.3-70b-instruct:free",
    isFree: true
  },
  OPENAI_COMPATIBLE: {
    label: "OpenAI-Compatible",
    endpointUrl: "https://api.openai.com/v1/chat/completions",
    model: "gpt-4o-mini",
    isFree: false
  },
  CUSTOM_PROXY: {
    label: "Custom HTTPS Endpoint",
    endpointUrl: "",
    model: "custom-model",
    isFree: true
  }
};

function defaultGeminiFreeProvider() {
  return {
    providerId: "gemini_free_primary",
    label: "Google Gemini (Free Tier)",
    providerType: "GEMINI",
    role: "PRIMARY",
    enabled: true,
    isFree: true,
    adminPaidApproved: false,
    endpointUrl: AI_PROVIDER_PRESETS.GEMINI.endpointUrl,
    model: AI_PROVIDER_PRESETS.GEMINI.model,
    dailyLimit: 500,
    perUserLimit: 15
  };
}

function normalizeAiProviderProfile(raw, idx = 0) {
  const validTypes = ["GEMINI", "GROQ", "OPENROUTER", "OPENAI_COMPATIBLE", "CUSTOM_PROXY"];
  const rawType = String(raw?.providerType || "GEMINI").trim().toUpperCase();
  const providerType = validTypes.includes(rawType) ? rawType : "GEMINI";
  const preset = AI_PROVIDER_PRESETS[providerType] || AI_PROVIDER_PRESETS.GEMINI;
  const validRoles = ["PRIMARY", "SECONDARY", "BACKUP", "DISABLED"];
  const rawRole = String(raw?.role || "BACKUP").trim().toUpperCase();
  const role = validRoles.includes(rawRole) ? rawRole : "BACKUP";
  const providerId = String(raw?.providerId || `ai_${providerType.toLowerCase()}_${idx}`)
    .replace(/[^a-zA-Z0-9_-]/g, "_")
    .slice(0, 64);

  return {
    providerId: providerId || `ai_prov_${idx}`,
    label: String(raw?.label || preset.label).trim().slice(0, 80),
    providerType,
    role,
    enabled: raw?.enabled !== false,
    isFree: raw?.isFree !== undefined ? Boolean(raw.isFree) : Boolean(preset.isFree),
    adminPaidApproved: Boolean(raw?.adminPaidApproved),
    endpointUrl: String(raw?.endpointUrl || preset.endpointUrl).trim().slice(0, 500),
    model: String(raw?.model || preset.model).trim().slice(0, 120),
    dailyLimit: Math.min(1000000, Math.max(0, Math.round(Number(raw?.dailyLimit ?? 500)))),
    perUserLimit: Math.min(1000, Math.max(0, Math.round(Number(raw?.perUserLimit ?? 15))))
  };
}

function normalizeAiProvidersList(rawJson, fallbackType = "GEMINI", fallbackModel = "gemini-2.5-flash", fallbackEndpoint = "") {
  if (typeof rawJson === "string" && rawJson.trim()) {
    try {
      const arr = JSON.parse(rawJson);
      if (Array.isArray(arr) && arr.length) {
        return arr.map((item, idx) => normalizeAiProviderProfile(item, idx));
      }
    } catch {
      // fall through
    }
  }
  if (fallbackType && fallbackType !== "GEMINI") {
    return [
      normalizeAiProviderProfile({
        providerId: `legacy_${fallbackType.toLowerCase()}`,
        label: AI_PROVIDER_PRESETS[fallbackType]?.label || fallbackType,
        providerType: fallbackType,
        role: "PRIMARY",
        enabled: true,
        isFree: fallbackType === "GROQ" || fallbackType === "OPENROUTER",
        adminPaidApproved: false,
        endpointUrl: fallbackEndpoint || AI_PROVIDER_PRESETS[fallbackType]?.endpointUrl || "",
        model: fallbackModel || AI_PROVIDER_PRESETS[fallbackType]?.model || ""
      }, 0)
    ];
  }
  return [defaultGeminiFreeProvider()];
}

function sanitizeAiProvidersForFirestore(providers) {
  return JSON.stringify((providers || []).map((p, idx) => normalizeAiProviderProfile(p, idx)));
}

let aiState = {
  aiEnabled: true,
  showAiNavItem: true,
  aiFreeOnlyMode: true,
  aiAllowPaidFallback: false,
  aiAutoFailoverEnabled: true,
  aiProvider: "GEMINI",
  aiModel: "gemini-2.5-flash",
  aiEndpointUrl: "",
  aiProxyEndpoint: DEFAULT_AI_PROXY_URL,
  aiDailyLimit: 500,
  aiPerUserLimit: 15,
  aiProviders: [defaultGeminiFreeProvider()],
  aiProvidersJson: JSON.stringify([defaultGeminiFreeProvider()]),
  aiSupportedAppliances: ["Air Conditioner", "Refrigerator", "Washing Machine"],
  aiBrandsModelsJson: DEFAULT_AI_BRANDS_JSON,
  aiSupportedLanguages: ["en", "bn", "hi"],
  aiSystemInstructions: ""
};

let billingState = {
  invoiceEnabled: true,
  whatsappReminderEnabled: true,
  smsReminderEnabled: true,
  invoiceBusinessTitle: "Repair Pro Service Invoice",
  invoiceTermsNote: "Thank you for choosing our appliance service. Retain this invoice for service reference.",
  reminderTemplatesJson: JSON.stringify(DEFAULT_BILLING_TEMPLATES),
  billingSupportedLanguages: ["en", "bn", "hi"]
};

function defaultSupabasePrimaryProvider() {
  return {
    providerId: "supabase_primary",
    providerName: `Supabase Free Plan (${SUPABASE_PROJECT_REF})`,
    providerType: "SUPABASE_STORAGE",
    endpointUrl: SUPABASE_URL,
    publicAnonKey: "",
    proxyUploadUrl: "",
    hostingVendor: "",
    publicMediaBaseUrl: "",
    communityOnly: false,
    role: "PRIMARY",
    enabled: true,
    capacityLimitBytes: FREE_TIER_STORAGE_LIMIT_BYTES,
    usedBytes: 0,
    lastStatus: "CONFIGURED",
    buckets: { ...DEFAULT_SUPABASE_BUCKETS }
  };
}

function defaultFirebaseLegacyProvider() {
  return {
    providerId: "firebase_legacy_backup",
    providerName: "Firebase Storage (Legacy Compatibility)",
    providerType: "FIREBASE_LEGACY",
    endpointUrl: `https://${firebaseConfig.storageBucket}`,
    publicAnonKey: "",
    proxyUploadUrl: "",
    role: "BACKUP",
    enabled: false,
    capacityLimitBytes: FREE_TIER_STORAGE_LIMIT_BYTES,
    usedBytes: 0,
    lastStatus: "STANDBY",
    buckets: { ...DEFAULT_SUPABASE_BUCKETS }
  };
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function safeHref(url) {
  const s = String(url || "").trim();
  return /^https?:\/\//i.test(s) ? s : "#";
}

function formatBytes(bytes) {
  const n = Number(bytes || 0);
  if (!Number.isFinite(n) || n <= 0) return "0 B";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(2)} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function slugId(prefix = "id") {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}_${Date.now()}_${rand}`.replace(/[^a-zA-Z0-9_-]/g, "_");
}

function showToast(message, isError = false) {
  const el = $("toast");
  if (!el) return;
  el.textContent = String(message || "");
  el.style.borderColor = isError ? "rgba(255, 77, 106, 0.7)" : "rgba(0, 216, 255, 0.55)";
  el.classList.remove("hidden");
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => el.classList.add("hidden"), 4200);
}

function setBanner(elId, message, variant = "info") {
  const el = $(elId);
  if (!el) return;
  el.classList.remove(
    "hidden",
    "info", "success", "warning", "error",
    "alert-success", "alert-warning", "alert-error", "alert-info"
  );
  el.classList.add(variant, `alert-${variant}`);
  el.textContent = String(message || "");
}

function openConfirmModal(title, message, okLabel = "Delete Permanently") {
  return new Promise((resolve) => {
    const modal = $("confirm-modal");
    const titleEl = $("confirm-modal-title");
    const msgEl = $("confirm-modal-message");
    const okBtn = $("confirm-modal-ok");
    const cancelBtn = $("confirm-modal-cancel");
    if (!modal || !okBtn || !cancelBtn) {
      resolve(window.confirm(`${title}\n\n${message}`));
      return;
    }
    titleEl.textContent = title;
    msgEl.textContent = message;
    okBtn.textContent = okLabel;
    modal.classList.remove("hidden");

    const cleanup = (result) => {
      modal.classList.add("hidden");
      okBtn.onclick = null;
      cancelBtn.onclick = null;
      modal.onclick = null;
      resolve(result);
    };
    okBtn.onclick = () => cleanup(true);
    cancelBtn.onclick = () => cleanup(false);
    modal.onclick = (ev) => {
      if (ev.target === modal) cleanup(false);
    };
  });
}

function formatTs(ts) {
  if (!ts) return "Just now";
  try {
    if (typeof ts.toDate === "function") return ts.toDate().toLocaleString();
    if (ts instanceof Date) return ts.toLocaleString();
    return new Date(ts).toLocaleString();
  } catch {
    return "Just now";
  }
}

function normalizeProvider(raw) {
  const base = raw?.providerType === "FIREBASE_LEGACY"
    ? defaultFirebaseLegacyProvider()
    : defaultSupabasePrimaryProvider();
  const buckets = { ...DEFAULT_SUPABASE_BUCKETS, ...(raw?.buckets || {}) };
  const pType = String(raw?.providerType || base.providerType);
  return {
    providerId: String(raw?.providerId || slugId("prov")).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 64),
    providerName: String(raw?.providerName || base.providerName).slice(0, 80),
    providerType: pType,
    endpointUrl: String(raw?.endpointUrl || base.endpointUrl).trim().replace(/\/+$/, ""),
    publicAnonKey: String(raw?.publicAnonKey || "").trim(),
    proxyUploadUrl: String(raw?.proxyUploadUrl || "").trim(),
    hostingVendor: String(raw?.hostingVendor || "").trim().slice(0, 60),
    publicMediaBaseUrl: String(raw?.publicMediaBaseUrl || "").trim().replace(/\/+$/, "").slice(0, 400),
    communityOnly: raw?.communityOnly !== undefined ? Boolean(raw.communityOnly) : pType === "PHP_HOSTING",
    role: ["PRIMARY", "BACKUP", "DISABLED"].includes(raw?.role) ? raw.role : "BACKUP",
    enabled: raw?.enabled !== false,
    capacityLimitBytes: Math.max(1024 * 1024, Number(raw?.capacityLimitBytes || FREE_TIER_STORAGE_LIMIT_BYTES)),
    usedBytes: Math.max(0, Number(raw?.usedBytes || 0)),
    lastStatus: String(raw?.lastStatus || "READY").slice(0, 40),
    buckets
  };
}

function sanitizeProvidersForFirestore(providers) {
  return (providers || []).map((p) => ({
    providerId: p.providerId,
    providerName: p.providerName,
    providerType: p.providerType,
    endpointUrl: p.endpointUrl,
    // Public anon key is a client-safe Supabase key; private PHP/S3/R2/service_role keys are NEVER stored in Firestore.
    publicAnonKey: p.providerType === "SUPABASE_STORAGE" ? (p.publicAnonKey || "") : "",
    proxyUploadUrl: p.proxyUploadUrl || "",
    hostingVendor: p.hostingVendor || "",
    publicMediaBaseUrl: p.publicMediaBaseUrl || "",
    communityOnly: Boolean(p.communityOnly),
    role: p.role,
    enabled: Boolean(p.enabled),
    capacityLimitBytes: Number(p.capacityLimitBytes || FREE_TIER_STORAGE_LIMIT_BYTES),
    usedBytes: Number(p.usedBytes || 0),
    lastStatus: p.lastStatus || "READY",
    buckets: p.buckets || { ...DEFAULT_SUPABASE_BUCKETS }
  }));
}

function getBucketNameForCategory(provider, bucketKey) {
  const b = provider?.buckets || DEFAULT_SUPABASE_BUCKETS;
  return b[bucketKey] || DEFAULT_SUPABASE_BUCKETS[bucketKey] || "community-photos";
}

function getOrderedActiveProviders() {
  const enabled = (storageState.providers || []).filter((p) => p.enabled && p.role !== "DISABLED");
  const primary = enabled.filter((p) => p.role === "PRIMARY");
  const backups = enabled.filter((p) => p.role !== "PRIMARY");
  if (!storageState.autoFailoverEnabled) {
    return primary.length ? [primary[0]] : backups.slice(0, 1);
  }
  return [...primary, ...backups];
}

// =========================================================================
// NAVIGATION & SECTION SWITCHING
// =========================================================================

function activateSection(section) {
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.section === section);
  });
  document.querySelectorAll(".admin-section").forEach((sec) => {
    sec.classList.toggle("hidden", sec.id !== `sec-${section}`);
  });
  if ($("section-title")) {
    $("section-title").textContent = SECTION_TITLES[section] || "Super Admin Console";
  }
}

document.querySelectorAll(".nav-btn").forEach((btn) => {
  btn.addEventListener("click", () => activateSection(btn.dataset.section));
});

$("quick-new-entry-btn")?.addEventListener("click", () => {
  activateSection("catalog");
  $("cat-title-en")?.focus();
});

$("quick-push-btn")?.addEventListener("click", () => {
  activateSection("announcements");
  $("push-title")?.focus();
});

// =========================================================================
// FIREBASE AUTHENTICATION & ADMIN RBAC (PERSISTENT — NO ACCIDENTAL LOGOUT)
// =========================================================================

if ($("db-id-preview")) {
  $("db-id-preview").textContent = FIRESTORE_DATABASE_ID;
}

getRedirectResult(auth).catch((err) => {
  if (err && $("login-error")) {
    $("login-error").textContent = err.message || "Google Redirect sign-in failed.";
    $("login-error").classList.remove("hidden");
  }
});

$("google-login-btn")?.addEventListener("click", async () => {
  $("login-error")?.classList.add("hidden");
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: "select_account" });
    await signInWithPopup(auth, provider);
  } catch (err) {
    if ($("login-error")) {
      $("login-error").textContent = `${err.message || "Popup sign-in failed."} (Try Redirect button for Safari/iOS).`;
      $("login-error").classList.remove("hidden");
    }
  }
});

$("google-redirect-btn")?.addEventListener("click", async () => {
  $("login-error")?.classList.add("hidden");
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: "select_account" });
    await signInWithRedirect(auth, provider);
  } catch (err) {
    if ($("login-error")) {
      $("login-error").textContent = err.message || "Redirect sign-in failed.";
      $("login-error").classList.remove("hidden");
    }
  }
});

async function explicitSignOut() {
  clearSubscriptions();
  await signOut(auth);
}

$("signout-btn")?.addEventListener("click", explicitSignOut);
$("denied-signout-btn")?.addEventListener("click", explicitSignOut);

function clearSubscriptions() {
  unsubs.forEach((fn) => {
    try {
      fn();
    } catch {
      // ignore
    }
  });
  unsubs = [];
}

onAuthStateChanged(auth, async (user) => {
  clearSubscriptions();
  currentUser = user;

  if (!user) {
    $("login-view")?.classList.remove("hidden");
    $("denied-view")?.classList.add("hidden");
    $("admin-shell")?.classList.add("hidden");
    return;
  }

  let hasAdminAccess = false;
  let isBootstrap = false;
  try {
    isBootstrap = Boolean(
      user.emailVerified &&
      String(user.email || "").toLowerCase() === BOOTSTRAP_SUPER_ADMIN_EMAIL.toLowerCase()
    );
    if (isBootstrap) {
      hasAdminAccess = true;
    } else {
      const adminSnap = await getDoc(doc(db, "admins", user.uid));
      hasAdminAccess = adminSnap.exists();
    }
  } catch (err) {
    // Only deny if the role check itself explicitly failed; never throw/crash.
    console.warn("Admin verification check failed:", err?.message || err);
    hasAdminAccess = isBootstrap;
  }

  currentIsBootstrapAdmin = isBootstrap;
  if (!hasAdminAccess) {
    $("login-view")?.classList.add("hidden");
    $("admin-shell")?.classList.add("hidden");
    $("denied-view")?.classList.remove("hidden");
    if ($("denied-message")) {
      $("denied-message").textContent = `Signed in as ${user.email || user.uid}, which is not authorized in admins/${user.uid}.`;
    }
    return;
  }

  $("login-view")?.classList.add("hidden");
  $("denied-view")?.classList.add("hidden");
  $("admin-shell")?.classList.remove("hidden");
  if ($("admin-email-badge")) {
    $("admin-email-badge").textContent = `${isBootstrap ? "Bootstrap Super Admin" : "Admin"} • ${user.email || user.uid}`;
  }
  $("roles-manager-card")?.classList.toggle("hidden", !isBootstrap);
  subscribeAllStreams();
});

async function writeAuditLog(action, targetType, targetId, details) {
  if (!currentUser) return;
  try {
    const id = slugId("log");
    await setDoc(doc(db, "audit_logs", id), {
      adminUid: currentUser.uid,
      adminEmail: String(currentUser.email || "admin@repairpro").slice(0, 160),
      action: String(action).slice(0, 100),
      targetType: String(targetType).slice(0, 64),
      targetId: String(targetId).slice(0, 128),
      details: String(details || "Updated via Web Super Admin").slice(0, 500),
      createdAt: serverTimestamp()
    });
  } catch (err) {
    console.warn("Audit log write skipped:", err?.message || err);
  }
}

// =========================================================================
// FIRESTORE REAL-TIME STREAMS
// =========================================================================

function safeSub(refOrQuery, onData, label) {
  const unsub = onSnapshot(
    refOrQuery,
    (snap) => onData(snap),
    (err) => {
      // NEVER sign out on transient snapshot/permission errors!
      console.warn(`Firestore stream (${label}) note:`, err?.code || err?.message);
    }
  );
  unsubs.push(unsub);
}

function subscribeAllStreams() {
  safeSub(query(collection(db, "catalog_entries"), orderBy("updatedAt", "desc")), (snap) => {
    cachedCatalog = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderDashboardStats();
    renderCatalogList();
    renderAppliancesGrid();
  }, "catalog_entries");

  safeSub(query(collection(db, "technicians"), orderBy("updatedAt", "desc")), (snap) => {
    cachedTechnicians = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderDashboardStats();
    renderTechniciansSection();
  }, "technicians");

  safeSub(query(collection(db, "technician_verification_requests"), orderBy("updatedAt", "desc")), (snap) => {
    cachedVerifications = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderDashboardStats();
    renderVerificationSection();
  }, "technician_verification_requests");

  safeSub(query(collection(db, "community_posts"), orderBy("createdAt", "desc")), (snap) => {
    cachedCommunityPosts = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderDashboardStats();
    renderCommunitySection();
  }, "community_posts");

  safeSub(query(collection(db, "community_reports"), orderBy("createdAt", "desc")), (snap) => {
    cachedCommunityReports = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderCommunitySection();
  }, "community_reports");

  safeSub(collection(db, "community_user_restrictions"), (snap) => {
    cachedCommunityRestrictions = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderCommunitySection();
  }, "community_user_restrictions");

  safeSub(query(collection(db, "technical_documents"), orderBy("updatedAt", "desc")), (snap) => {
    cachedDocuments = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderDashboardStats();
    renderDocumentsList();
  }, "technical_documents");

  safeSub(query(collection(db, "announcements"), orderBy("createdAt", "desc")), (snap) => {
    cachedAnnouncements = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderAnnouncementsList();
  }, "announcements");

  safeSub(query(collection(db, "push_notifications"), orderBy("createdAt", "desc")), (snap) => {
    cachedPushHistory = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderPushHistory();
  }, "push_notifications");

  safeSub(collection(db, "users"), (snap) => {
    cachedUsers = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderPushUserChips();
  }, "users");

  safeSub(query(collection(db, "problem_reports"), orderBy("createdAt", "desc")), (snap) => {
    cachedReports = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderDashboardStats();
    renderReportsList();
  }, "problem_reports");

  safeSub(query(collection(db, "audit_logs"), orderBy("createdAt", "desc")), (snap) => {
    cachedAuditLogs = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderDashboardStats();
    renderAuditLogs();
  }, "audit_logs");

  safeSub(doc(db, "app_settings", "admob_config"), (snap) => {
    if (snap.exists()) populateAdMobForm(snap.data());
  }, "admob_config");

  safeSub(doc(db, "app_settings", "global_config"), (snap) => {
    if (snap.exists()) populateGlobalSettingsForm(snap.data());
  }, "global_config");

  safeSub(doc(db, "app_settings", "storage_config"), (snap) => {
    if (snap.exists()) {
      const data = snap.data();
      let parsedProviders = [];
      try {
        parsedProviders = JSON.parse(data.providersJson || "[]");
      } catch {
        parsedProviders = [];
      }
      const normalized = Array.isArray(parsedProviders) && parsedProviders.length > 0
        ? parsedProviders.map(normalizeProvider)
        : [defaultSupabasePrimaryProvider()];
      const rawFcm = String(data.fcmBackendUrl || "").trim();
      const effectiveFcm = (!rawFcm || /\/send-fcm-v1$/i.test(rawFcm))
        ? DEFAULT_FCM_ENDPOINT
        : rawFcm;
      const rawProxy = String(data.hostingProxyUrl || "").trim();
      const effectiveProxy = /^https:\/\//i.test(rawProxy) ? rawProxy : DEFAULT_HOSTING_PROXY_URL;
      storageState = {
        autoFailoverEnabled: data.autoFailoverEnabled !== false,
        fcmBackendUrl: effectiveFcm,
        hostingProxyUrl: effectiveProxy,
        compressionMaxDim: Math.min(4096, Math.max(480, Number(data.compressionMaxDim || 1440))),
        compressionQuality: Math.min(100, Math.max(40, Number(data.compressionQuality || 82))),
        compressionMaxSizeKb: Math.min(5120, Math.max(100, Number(data.compressionMaxSizeKb || 4500))),
        duplicateCheckEnabled: data.duplicateCheckEnabled !== false,
        providers: normalized
      };
    } else {
      storageState = {
        autoFailoverEnabled: true,
        fcmBackendUrl: DEFAULT_FCM_ENDPOINT,
        hostingProxyUrl: DEFAULT_HOSTING_PROXY_URL,
        compressionMaxDim: 1440,
        compressionQuality: 82,
        compressionMaxSizeKb: 4500,
        duplicateCheckEnabled: true,
        providers: [defaultSupabasePrimaryProvider()]
      };
    }
    syncStorageFormsFromState();
    renderStorageManager();
    renderDashboardStats();
  }, "storage_config");

  safeSub(doc(db, "app_settings", "ai_config"), (snap) => {
    if (snap.exists()) {
      const d = snap.data();
      const validAiProviders = ["GEMINI", "GROQ", "OPENROUTER", "OPENAI_COMPATIBLE", "CUSTOM_PROXY"];
      const aiProvider = validAiProviders.includes(d.aiProvider) ? d.aiProvider : "GEMINI";
      const aiModel = String(d.aiModel || AI_PROVIDER_PRESETS[aiProvider]?.model || "gemini-2.5-flash");
      const aiEndpointUrl = String(d.aiEndpointUrl || "");
      const aiProviders = normalizeAiProvidersList(d.aiProvidersJson, aiProvider, aiModel, aiEndpointUrl);
      aiState = {
        aiEnabled: d.aiEnabled !== false,
        showAiNavItem: d.showAiNavItem !== false,
        aiFreeOnlyMode: d.aiFreeOnlyMode !== undefined ? Boolean(d.aiFreeOnlyMode) : true,
        aiAllowPaidFallback: Boolean(d.aiAllowPaidFallback),
        aiAutoFailoverEnabled: d.aiAutoFailoverEnabled !== undefined ? Boolean(d.aiAutoFailoverEnabled) : true,
        aiProvider,
        aiModel,
        aiEndpointUrl,
        aiProxyEndpoint: /^https:\/\//i.test(String(d.aiProxyEndpoint || "")) ? String(d.aiProxyEndpoint) : DEFAULT_AI_PROXY_URL,
        aiDailyLimit: Math.max(0, Number(d.aiDailyLimit ?? 500)),
        aiPerUserLimit: Math.max(0, Number(d.aiPerUserLimit ?? 15)),
        aiProviders,
        aiProvidersJson: sanitizeAiProvidersForFirestore(aiProviders),
        aiSupportedAppliances: Array.isArray(d.aiSupportedAppliances) && d.aiSupportedAppliances.length
          ? d.aiSupportedAppliances
          : ["Air Conditioner", "Refrigerator", "Washing Machine"],
        aiBrandsModelsJson: String(d.aiBrandsModelsJson || DEFAULT_AI_BRANDS_JSON),
        aiSupportedLanguages: Array.isArray(d.aiSupportedLanguages) && d.aiSupportedLanguages.length
          ? d.aiSupportedLanguages
          : ["en", "bn", "hi"],
        aiSystemInstructions: String(d.aiSystemInstructions || "")
      };
    }
    populateAiForm();
    renderAiProvidersManager();
    renderAiStats();
  }, "ai_config");

  safeSub(doc(db, "app_settings", "billing_config"), (snap) => {
    if (snap.exists()) {
      const d = snap.data();
      billingState = {
        invoiceEnabled: d.invoiceEnabled !== false,
        whatsappReminderEnabled: d.whatsappReminderEnabled !== false,
        smsReminderEnabled: d.smsReminderEnabled !== false,
        invoiceBusinessTitle: String(d.invoiceBusinessTitle || "Repair Pro Service Invoice"),
        invoiceTermsNote: String(d.invoiceTermsNote || billingState.invoiceTermsNote),
        reminderTemplatesJson: String(d.reminderTemplatesJson || JSON.stringify(DEFAULT_BILLING_TEMPLATES)),
        billingSupportedLanguages: Array.isArray(d.billingSupportedLanguages) && d.billingSupportedLanguages.length
          ? d.billingSupportedLanguages
          : ["en", "bn", "hi"]
      };
    }
    populateBillingForm();
  }, "billing_config");

  safeSub(query(collection(db, "ai_error_logs"), orderBy("createdAt", "desc")), (snap) => {
    cachedAiErrorLogs = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderAiStats();
    renderAiErrorLogs();
  }, "ai_error_logs");

  safeSub(query(collection(db, "storage_upload_history"), orderBy("createdAt", "desc")), (snap) => {
    cachedUploadHistory = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderUploadHistory();
    renderStorageStats();
  }, "storage_upload_history");

  safeSub(query(collection(db, "storage_error_logs"), orderBy("createdAt", "desc")), (snap) => {
    cachedErrorLogs = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderErrorLogs();
    renderStorageStats();
  }, "storage_error_logs");

  if (currentIsBootstrapAdmin) {
    safeSub(collection(db, "admins"), (snap) => {
      renderRolesList(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    }, "admins");
  }
}

// =========================================================================
// MULTI-CLOUD STORAGE ADAPTERS & AUTOMATIC FAILOVER ENGINE
// =========================================================================

function getPrimarySupabaseProvider() {
  return (storageState.providers || []).find((p) => p.providerType === "SUPABASE_STORAGE" && p.enabled)
    || (storageState.providers || []).find((p) => p.providerType === "SUPABASE_STORAGE")
    || defaultSupabasePrimaryProvider();
}

async function supabaseUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType) {
  const endpoint = String(provider.endpointUrl || SUPABASE_URL).replace(/\/+$/, "");
  const anonKey = String(provider.publicAnonKey || "").trim();
  if (!endpoint || !anonKey) {
    throw new Error("Supabase URL or Public Anon Key is missing in Multi-Cloud Storage Manager.");
  }
  const cleanPath = String(objectPath).replace(/^\/+/, "");
  const url = `${endpoint}/storage/v1/object/${encodeURIComponent(bucketName)}/${cleanPath.split("/").map(encodeURIComponent).join("/")}`;
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      apikey: anonKey,
      Authorization: `Bearer ${anonKey}`,
      "Content-Type": contentType || fileOrBlob.type || "application/octet-stream",
      "x-upsert": "true"
    },
    body: fileOrBlob
  });
  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    throw new Error(`Supabase Storage HTTP ${resp.status}: ${errText.slice(0, 220)}`);
  }
  const isPrivateBucket = bucketName === "verification-documents";
  const publicUrl = isPrivateBucket
    ? `${endpoint}/storage/v1/object/authenticated/${bucketName}/${cleanPath}`
    : `${endpoint}/storage/v1/object/public/${bucketName}/${cleanPath}`;
  return {
    providerId: provider.providerId,
    providerName: provider.providerName,
    bucketName,
    storagePath: `${bucketName}/${cleanPath}`,
    objectPath: cleanPath,
    publicUrl,
    sizeBytes: Number(fileOrBlob.size || 0)
  };
}

async function supabaseListObjects(provider, bucketName) {
  const endpoint = String(provider.endpointUrl || SUPABASE_URL).replace(/\/+$/, "");
  const anonKey = String(provider.publicAnonKey || "").trim();
  if (!endpoint || !anonKey) {
    throw new Error("Configure Supabase Public Anon Key in Storage Manager to list files.");
  }
  const resp = await fetch(`${endpoint}/storage/v1/object/list/${encodeURIComponent(bucketName)}`, {
    method: "POST",
    headers: {
      apikey: anonKey,
      Authorization: `Bearer ${anonKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ prefix: "", limit: 100, offset: 0, sortBy: { column: "created_at", order: "desc" } })
  });
  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    throw new Error(`List failed HTTP ${resp.status}: ${errText.slice(0, 200)}`);
  }
  const items = await resp.json();
  return (Array.isArray(items) ? items : []).filter((it) => it && it.name && it.id !== null);
}

async function supabaseDeleteObject(provider, bucketName, objectPath) {
  const endpoint = String(provider.endpointUrl || SUPABASE_URL).replace(/\/+$/, "");
  const anonKey = String(provider.publicAnonKey || "").trim();
  if (!endpoint || !anonKey) {
    throw new Error("Supabase Public Anon Key required to delete object.");
  }
  const cleanPath = String(objectPath).replace(/^\/+/, "");
  const resp = await fetch(`${endpoint}/storage/v1/object/${encodeURIComponent(bucketName)}`, {
    method: "DELETE",
    headers: {
      apikey: anonKey,
      Authorization: `Bearer ${anonKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ prefixes: [cleanPath] })
  });
  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    throw new Error(`Delete failed HTTP ${resp.status}: ${errText.slice(0, 180)}`);
  }
}

async function signedProxyUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType) {
  const proxyUrl = String(provider.proxyUploadUrl || "").trim();
  if (!proxyUrl || !/^https:\/\//i.test(proxyUrl)) {
    throw new Error(`${provider.providerName} requires a configured HTTPS Signed Upload Proxy URL.`);
  }
  const idToken = currentUser ? await currentUser.getIdToken() : "";
  const signResp = await fetch(proxyUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(idToken ? { Authorization: `Bearer ${idToken}` } : {})
    },
    body: JSON.stringify({
      providerId: provider.providerId,
      providerType: provider.providerType,
      bucketName,
      objectPath,
      contentType: contentType || fileOrBlob.type || "application/octet-stream",
      sizeBytes: Number(fileOrBlob.size || 0)
    })
  });
  if (!signResp.ok) {
    const txt = await signResp.text().catch(() => "");
    throw new Error(`Signed upload proxy HTTP ${signResp.status}: ${txt.slice(0, 180)}`);
  }
  const signed = await signResp.json();
  if (!signed?.uploadUrl || !signed?.publicUrl) {
    throw new Error("Signed upload proxy returned incomplete uploadUrl/publicUrl.");
  }
  const putResp = await fetch(signed.uploadUrl, {
    method: "PUT",
    headers: { "Content-Type": contentType || fileOrBlob.type || "application/octet-stream" },
    body: fileOrBlob
  });
  if (!putResp.ok) {
    throw new Error(`Direct object PUT failed HTTP ${putResp.status}`);
  }
  return {
    providerId: provider.providerId,
    providerName: provider.providerName,
    bucketName,
    storagePath: `${bucketName}/${objectPath}`,
    objectPath,
    publicUrl: signed.publicUrl,
    sizeBytes: Number(fileOrBlob.size || 0)
  };
}

async function firebaseLegacyUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType, onProgress) {
  const fullPath = `${bucketName}/${String(objectPath).replace(/^\/+/, "")}`;
  const ref = storageRef(firebaseStorage, fullPath);
  const task = uploadBytesResumable(ref, fileOrBlob, {
    contentType: contentType || fileOrBlob.type || "application/octet-stream"
  });
  await new Promise((resolve, reject) => {
    task.on(
      "state_changed",
      (snap) => {
        if (onProgress && snap.totalBytes > 0) {
          onProgress(snap.bytesTransferred / snap.totalBytes);
        }
      },
      (err) => reject(err),
      () => resolve()
    );
  });
  const url = await getDownloadURL(ref);
  return {
    providerId: provider.providerId,
    providerName: provider.providerName,
    bucketName,
    storagePath: fullPath,
    objectPath,
    publicUrl: url,
    sizeBytes: Number(fileOrBlob.size || 0)
  };
}

async function logUploadHistory(record) {
  if (!currentUser) return;
  try {
    const uploadId = slugId("upl");
    await setDoc(doc(db, "storage_upload_history", uploadId), {
      uploadId,
      providerId: String(record.providerId).slice(0, 128),
      bucketName: String(record.bucketName).slice(0, 128),
      objectPath: String(record.objectPath).slice(0, 320),
      publicUrl: String(record.publicUrl || "").slice(0, 1000),
      mimeType: String(record.mimeType || "application/octet-stream").slice(0, 100),
      sizeBytes: Math.max(0, Math.round(Number(record.sizeBytes || 0))),
      failoverUsed: Boolean(record.failoverUsed),
      status: record.status === "FAILED" ? "FAILED" : "SUCCESS",
      uploadedByUid: currentUser.uid,
      createdAt: serverTimestamp()
    });
  } catch (err) {
    console.warn("Could not record storage_upload_history:", err?.message || err);
  }
}

async function logStorageError(providerId, bucketName, objectPath, errorMessage, failoverTargetId = "") {
  if (!currentUser) return;
  try {
    const errorId = slugId("err");
    await setDoc(doc(db, "storage_error_logs", errorId), {
      errorId,
      providerId: String(providerId || "unknown").slice(0, 128),
      bucketName: String(bucketName || "").slice(0, 128),
      objectPath: String(objectPath || "").slice(0, 320),
      errorMessage: String(errorMessage || "Upload error").slice(0, 600),
      failoverTargetId: String(failoverTargetId || "").slice(0, 128),
      actorUid: currentUser.uid,
      resolved: false,
      createdAt: serverTimestamp()
    });
  } catch (err) {
    console.warn("Could not record storage_error_logs:", err?.message || err);
  }
}

async function uploadWithProvider(provider, bucketName, objectPath, fileOrBlob, contentType, onProgress) {
  if (onProgress) onProgress(0.2);
  if (provider.providerType === "SUPABASE_STORAGE") {
    const res = await supabaseUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType);
    if (onProgress) onProgress(1);
    return res;
  }
  if (provider.providerType === "FIREBASE_LEGACY") {
    return await firebaseLegacyUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType, onProgress);
  }
  const res = await signedProxyUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType);
  if (onProgress) onProgress(1);
  return res;
}

async function multiCloudUpload({ bucketKey, objectPath, fileOrBlob, contentType, onProgress }) {
  const candidates = getOrderedActiveProviders();
  if (!candidates.length) {
    throw new Error("No enabled storage providers configured in Multi-Cloud Storage Manager.");
  }

  let lastError = null;
  let failoverUsed = false;

  for (let i = 0; i < candidates.length; i += 1) {
    const provider = candidates[i];
    const bucketName = getBucketNameForCategory(provider, bucketKey);
    try {
      const result = await uploadWithProvider(provider, bucketName, objectPath, fileOrBlob, contentType, onProgress);
      provider.usedBytes = Number(provider.usedBytes || 0) + Number(fileOrBlob.size || 0);
      provider.lastStatus = "HEALTHY";
      await logUploadHistory({
        providerId: provider.providerId,
        bucketName,
        objectPath,
        publicUrl: result.publicUrl,
        mimeType: contentType || fileOrBlob.type,
        sizeBytes: fileOrBlob.size,
        failoverUsed,
        status: "SUCCESS"
      });
      return { ...result, failoverUsed };
    } catch (err) {
      lastError = err;
      provider.lastStatus = "ERROR";
      const nextProvider = candidates[i + 1];
      await logStorageError(
        provider.providerId,
        bucketName,
        objectPath,
        err?.message || "Upload failed",
        nextProvider ? nextProvider.providerId : ""
      );
      if (nextProvider) {
        failoverUsed = true;
      }
    }
  }

  await logUploadHistory({
    providerId: candidates[0].providerId,
    bucketName: getBucketNameForCategory(candidates[0], bucketKey),
    objectPath,
    publicUrl: "",
    mimeType: contentType || fileOrBlob.type,
    sizeBytes: fileOrBlob.size,
    failoverUsed,
    status: "FAILED"
  });

  throw lastError || new Error("All configured storage providers failed.");
}

// =========================================================================
// DASHBOARD & APPLIANCES RENDERING
// =========================================================================

function renderDashboardStats() {
  if ($("stat-catalog")) $("stat-catalog").textContent = String(cachedCatalog.length);
  if ($("stat-published")) $("stat-published").textContent = String(cachedCatalog.filter((c) => c.published).length);
  if ($("stat-technicians")) $("stat-technicians").textContent = String(cachedTechnicians.filter((t) => t.status === "ACTIVE").length);
  if ($("stat-verifications-pending")) $("stat-verifications-pending").textContent = String(cachedVerifications.filter((v) => v.status === "PENDING").length);
  if ($("stat-community-pending")) $("stat-community-pending").textContent = String(cachedCommunityPosts.filter((p) => p.approvalStatus === "PENDING").length);
  if ($("stat-documents")) $("stat-documents").textContent = String(cachedDocuments.length);
  if ($("stat-reports")) $("stat-reports").textContent = String(cachedReports.filter((r) => r.status === "PENDING").length);
  if ($("stat-logs")) $("stat-logs").textContent = String(cachedAuditLogs.length);

  const primary = (storageState.providers || []).find((p) => p.enabled && p.role === "PRIMARY") || storageState.providers[0];
  if ($("stat-storage-primary")) {
    $("stat-storage-primary").textContent = primary ? primary.providerName.split(" ")[0] : "Supabase";
  }

  const barsEl = $("category-bars");
  if (!barsEl) return;
  const counts = {
    ac: cachedCatalog.filter((c) => c.categoryId === "ac").length,
    fridge: cachedCatalog.filter((c) => c.categoryId === "fridge").length,
    washer: cachedCatalog.filter((c) => c.categoryId === "washer").length
  };
  const max = Math.max(1, counts.ac, counts.fridge, counts.washer);
  barsEl.innerHTML = [
    ["Air Conditioner (AC)", counts.ac],
    ["Refrigerator (Fridge)", counts.fridge],
    ["Washing Machine", counts.washer]
  ].map(([label, count]) => `
    <div style="margin-bottom:10px;">
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
        <span>${label}</span><strong>${count} entries</strong>
      </div>
      <div class="progress-track"><div class="progress-fill" style="width:${Math.round((count / max) * 100)}%;"></div></div>
    </div>
  `).join("");
}

function renderAppliancesGrid() {
  const grid = $("appliances-grid");
  if (!grid) return;
  const defaults = [
    { id: "ac", name: "Air Conditioner (AC)", sub: "Split, Inverter, Window, PCB & Compressor" },
    { id: "fridge", name: "Refrigerator (Fridge)", sub: "Inverter Fridge, Frost-Free, Defrost & Thermostat" },
    { id: "washer", name: "Washing Machine", sub: "Front Load, Top Load, Drain Pump & Inverter Motor" }
  ];
  const customCats = cachedCatalog.filter((c) => c.entryType === "CATEGORY");
  const all = [
    ...defaults.map((d) => ({
      ...d,
      count: cachedCatalog.filter((c) => c.categoryId === d.id && c.entryType !== "CATEGORY").length
    })),
    ...customCats.map((c) => ({
      id: c.categoryId,
      name: c.titleEn || c.categoryId,
      sub: `${c.titleBn || ""} ${c.titleHi || ""}`.trim() || "Custom Cloud Category",
      count: cachedCatalog.filter((x) => x.categoryId === c.categoryId && x.entryType !== "CATEGORY").length
    }))
  ];
  grid.innerHTML = all.map((c) => `
    <div class="card">
      <div class="badge badge-cyan">${escapeHtml(c.id.toUpperCase())}</div>
      <h3 style="margin:8px 0 4px;">${escapeHtml(c.name)}</h3>
      <p style="font-size:12px;color:var(--text-muted);margin:0 0 8px;">${escapeHtml(c.sub)}</p>
      <div style="font-size:13px;font-weight:700;color:var(--success);">${c.count} live cloud entries</div>
    </div>
  `).join("");
}

$("new-category-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const catId = $("new-cat-id").value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
  const titleEn = $("new-cat-en").value.trim();
  if (!catId || !titleEn) {
    showToast("Category ID and English name are required.", true);
    return;
  }
  const docId = `cat_${catId}`;
  try {
    await setDoc(doc(db, "catalog_entries", docId), {
      entryType: "CATEGORY",
      categoryId: catId,
      brandName: "",
      modelSeries: "",
      code: "",
      titleEn,
      titleBn: $("new-cat-bn").value.trim(),
      titleHi: $("new-cat-hi").value.trim(),
      summaryEn: `${titleEn} diagnostic category`,
      summaryBn: "",
      summaryHi: "",
      stepsEn: "",
      stepsBn: "",
      stepsHi: "",
      safetyWarningEn: "Disconnect power before servicing.",
      verificationStatus: "VERIFIED",
      published: true,
      revision: 1,
      updatedByUid: currentUser.uid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    await writeAuditLog("CREATE_CATEGORY", "catalog_entries", docId, `Published category ${catId}`);
    $("new-category-form").reset();
    showToast("Appliance category published.");
  } catch (err) {
    showToast(`Failed to publish category: ${err.message}`, true);
  }
});

// =========================================================================
// ERROR CODES & MULTILINGUAL CATALOG
// =========================================================================

function resetCatalogForm() {
  $("catalog-form")?.reset();
  if ($("cat-doc-id")) $("cat-doc-id").value = "";
  if ($("catalog-form-heading")) $("catalog-form-heading").textContent = "Create / Publish Multilingual Entry";
  $("cancel-edit-btn")?.classList.add("hidden");
}

$("cancel-edit-btn")?.addEventListener("click", resetCatalogForm);
$("catalog-filter")?.addEventListener("change", renderCatalogList);

$("catalog-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const existingId = $("cat-doc-id").value.trim();
  const docId = existingId || slugId("cat");
  const titleEn = $("cat-title-en").value.trim();
  const summaryEn = $("cat-summary-en").value.trim();
  if (!titleEn || !summaryEn) {
    showToast("English title and summary are required.", true);
    return;
  }
  const existingItem = existingId ? cachedCatalog.find((c) => c.id === existingId) : null;
  try {
    if (existingId && existingItem) {
      await updateDoc(doc(db, "catalog_entries", docId), {
        brandName: $("cat-brand").value.trim(),
        modelSeries: $("cat-model").value.trim(),
        code: $("cat-code").value.trim(),
        titleEn,
        titleBn: $("cat-title-bn").value.trim(),
        titleHi: $("cat-title-hi").value.trim(),
        summaryEn,
        summaryBn: $("cat-summary-bn").value.trim(),
        summaryHi: $("cat-summary-hi").value.trim(),
        stepsEn: $("cat-steps-en").value.trim(),
        stepsBn: $("cat-steps-bn").value.trim(),
        stepsHi: $("cat-steps-hi").value.trim(),
        safetyWarningEn: $("cat-safety-en").value.trim(),
        verificationStatus: $("cat-verification").value,
        published: $("cat-published").checked,
        revision: Math.min(10000, Number(existingItem.revision || 1) + 1),
        updatedByUid: currentUser.uid,
        updatedAt: serverTimestamp()
      });
      await writeAuditLog("UPDATE_CATALOG_ENTRY", "catalog_entries", docId, titleEn);
    } else {
      await setDoc(doc(db, "catalog_entries", docId), {
        entryType: $("cat-entry-type").value,
        categoryId: $("cat-category-id").value,
        brandName: $("cat-brand").value.trim(),
        modelSeries: $("cat-model").value.trim(),
        code: $("cat-code").value.trim(),
        titleEn,
        titleBn: $("cat-title-bn").value.trim(),
        titleHi: $("cat-title-hi").value.trim(),
        summaryEn,
        summaryBn: $("cat-summary-bn").value.trim(),
        summaryHi: $("cat-summary-hi").value.trim(),
        stepsEn: $("cat-steps-en").value.trim(),
        stepsBn: $("cat-steps-bn").value.trim(),
        stepsHi: $("cat-steps-hi").value.trim(),
        safetyWarningEn: $("cat-safety-en").value.trim(),
        verificationStatus: $("cat-verification").value,
        published: $("cat-published").checked,
        revision: 1,
        updatedByUid: currentUser.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      await writeAuditLog("CREATE_CATALOG_ENTRY", "catalog_entries", docId, titleEn);
    }
    resetCatalogForm();
    showToast("Catalog entry synced to Firestore.");
  } catch (err) {
    showToast(`Save failed: ${err.message}`, true);
  }
});

function renderCatalogList() {
  const listEl = $("catalog-list");
  if (!listEl) return;
  const filter = $("catalog-filter")?.value || "all";
  const items = cachedCatalog.filter((c) => filter === "all" || c.categoryId === filter);
  if (!items.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No cloud catalog entries found for this filter.</span></div>`;
    return;
  }
  listEl.innerHTML = items.map((c) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge badge-cyan">${escapeHtml(c.entryType)}</span>
          <span class="badge ${c.published ? "badge-green" : "badge-warn"}">${c.published ? "LIVE" : "DRAFT"}</span>
          <strong style="margin-left:6px;">${escapeHtml(c.brandName ? `${c.brandName} ${c.code || ""} — ` : "")}${escapeHtml(c.titleEn)}</strong>
        </div>
        <div style="display:flex;gap:8px;">
          <button type="button" class="btn btn-outline btn-sm" data-cat-edit="${escapeHtml(c.id)}">Edit</button>
          <button type="button" class="btn btn-danger btn-sm" data-cat-del="${escapeHtml(c.id)}">Delete</button>
        </div>
      </div>
      <div style="font-size:13px;color:var(--text-muted);">${escapeHtml(c.summaryEn)}</div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-cat-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const item = cachedCatalog.find((x) => x.id === btn.dataset.catEdit);
      if (!item) return;
      $("cat-doc-id").value = item.id;
      $("cat-entry-type").value = item.entryType || "ERROR_CODE";
      $("cat-category-id").value = item.categoryId || "ac";
      $("cat-brand").value = item.brandName || "";
      $("cat-model").value = item.modelSeries || "";
      $("cat-code").value = item.code || "";
      $("cat-verification").value = item.verificationStatus || "VERIFIED";
      $("cat-title-en").value = item.titleEn || "";
      $("cat-title-bn").value = item.titleBn || "";
      $("cat-title-hi").value = item.titleHi || "";
      $("cat-summary-en").value = item.summaryEn || "";
      $("cat-summary-bn").value = item.summaryBn || "";
      $("cat-summary-hi").value = item.summaryHi || "";
      $("cat-steps-en").value = item.stepsEn || "";
      $("cat-steps-bn").value = item.stepsBn || "";
      $("cat-steps-hi").value = item.stepsHi || "";
      $("cat-safety-en").value = item.safetyWarningEn || "";
      $("cat-published").checked = Boolean(item.published);
      $("catalog-form-heading").textContent = `Editing ${item.titleEn}`;
      $("cancel-edit-btn")?.classList.remove("hidden");
      $("catalog-form")?.scrollIntoView({ behavior: "smooth" });
    });
  });

  listEl.querySelectorAll("[data-cat-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.catDel;
      if (!(await openConfirmModal("Delete Catalog Entry", `Permanently delete catalog entry ${id}?`))) return;
      try {
        await deleteDoc(doc(db, "catalog_entries", id));
        await writeAuditLog("DELETE_CATALOG_ENTRY", "catalog_entries", id, "Deleted catalog entry");
        showToast("Catalog entry deleted.");
      } catch (err) {
        showToast(`Delete failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// TECHNICIAN MANAGEMENT (MULTI-CLOUD PHOTO UPLOAD + CRUD)
// =========================================================================

function updateTechPhotoPreview(url, name = "RP") {
  const wrap = $("tech-photo-preview-wrap");
  if (!wrap) return;
  if (url) {
    wrap.outerHTML = `<img id="tech-photo-preview-wrap" class="tech-avatar" src="${escapeHtml(safeHref(url))}" alt="Technician Photo" />`;
    $("tech-remove-photo-btn")?.classList.remove("hidden");
  } else {
    const initials = String(name || "RP").trim().slice(0, 2).toUpperCase() || "RP";
    wrap.outerHTML = `<div id="tech-photo-preview-wrap" class="tech-avatar-fallback">${escapeHtml(initials)}</div>`;
    $("tech-remove-photo-btn")?.classList.add("hidden");
  }
}

$("tech-photo-input")?.addEventListener("change", (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    showToast("Profile photo must be 5 MB or less.", true);
    e.target.value = "";
    return;
  }
  pendingTechPhotoFile = file;
  removeTechPhotoRequested = false;
  updateTechPhotoPreview(URL.createObjectURL(file));
  if ($("tech-photo-status")) {
    $("tech-photo-status").textContent = `Ready to upload "${file.name}" via Multi-Cloud Storage Router.`;
  }
});

$("tech-remove-photo-btn")?.addEventListener("click", () => {
  pendingTechPhotoFile = null;
  removeTechPhotoRequested = true;
  if ($("tech-photo-input")) $("tech-photo-input").value = "";
  updateTechPhotoPreview("");
});

function resetTechnicianForm() {
  $("technician-form")?.reset();
  if ($("tech-doc-id")) $("tech-doc-id").value = "";
  if ($("tech-existing-photo-url")) $("tech-existing-photo-url").value = "";
  if ($("tech-existing-photo-path")) $("tech-existing-photo-path").value = "";
  pendingTechPhotoFile = null;
  removeTechPhotoRequested = false;
  updateTechPhotoPreview("");
  $("tech-cancel-edit-btn")?.classList.add("hidden");
  $("tech-form-error")?.classList.add("hidden");
  $("tech-upload-progress-wrap")?.classList.add("hidden");
  if ($("tech-form-heading")) $("tech-form-heading").textContent = "Add New Technician";
}

$("tech-cancel-edit-btn")?.addEventListener("click", resetTechnicianForm);
$("tech-reset-btn")?.addEventListener("click", resetTechnicianForm);

$("technician-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  $("tech-form-error")?.classList.add("hidden");
  const categories = Array.from(document.querySelectorAll(".tech-cat-checkbox"))
    .filter((cb) => cb.checked)
    .map((cb) => cb.value);
  if (!categories.length) {
    if ($("tech-form-error")) {
      $("tech-form-error").textContent = "Select at least one service category.";
      $("tech-form-error").classList.remove("hidden");
    }
    return;
  }

  const existingId = $("tech-doc-id").value.trim();
  const techId = existingId || slugId("tech");
  let photoUrl = removeTechPhotoRequested ? "" : ($("tech-existing-photo-url").value.trim() || "");
  let photoStoragePath = removeTechPhotoRequested ? "" : ($("tech-existing-photo-path").value.trim() || "");

  try {
    if (pendingTechPhotoFile) {
      $("tech-upload-progress-wrap")?.classList.remove("hidden");
      const ext = (pendingTechPhotoFile.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
      const uploaded = await multiCloudUpload({
        bucketKey: "technicians",
        objectPath: `${techId}_${Date.now()}.${ext}`,
        fileOrBlob: pendingTechPhotoFile,
        contentType: pendingTechPhotoFile.type || "image/jpeg",
        onProgress: (p) => {
          if ($("tech-upload-progress-fill")) $("tech-upload-progress-fill").style.width = `${Math.round(p * 100)}%`;
        }
      });
      photoUrl = uploaded.publicUrl;
      photoStoragePath = uploaded.storagePath;
    }

    const baseFields = {
      fullName: $("tech-full-name").value.trim(),
      photoUrl,
      photoStoragePath,
      mobileNumber: $("tech-mobile").value.trim(),
      fullAddress: $("tech-address").value.trim(),
      state: $("tech-state").value.trim(),
      district: $("tech-district").value.trim(),
      cityArea: $("tech-city-area").value.trim(),
      pinCode: $("tech-pin-code").value.trim(),
      serviceCategories: categories,
      experience: $("tech-experience").value.trim(),
      status: $("tech-status").value,
      updatedByUid: currentUser.uid,
      updatedAt: serverTimestamp()
    };

    if (existingId) {
      await updateDoc(doc(db, "technicians", techId), baseFields);
      await writeAuditLog("UPDATE_TECHNICIAN", "technicians", techId, baseFields.fullName);
    } else {
      await setDoc(doc(db, "technicians", techId), {
        technicianId: techId,
        ...baseFields,
        createdAt: serverTimestamp()
      });
      await writeAuditLog("CREATE_TECHNICIAN", "technicians", techId, baseFields.fullName);
    }
    resetTechnicianForm();
    showToast("Technician saved successfully.");
  } catch (err) {
    if ($("tech-form-error")) {
      $("tech-form-error").textContent = err.message || "Failed to save technician.";
      $("tech-form-error").classList.remove("hidden");
    }
    showToast(`Technician save failed: ${err.message}`, true);
  }
});

["tech-search-input", "tech-filter-district", "tech-filter-category", "tech-filter-status"].forEach((id) => {
  $(id)?.addEventListener("input", renderTechniciansSection);
  $(id)?.addEventListener("change", renderTechniciansSection);
});

function renderTechniciansSection() {
  if ($("tech-stat-total")) $("tech-stat-total").textContent = String(cachedTechnicians.length);
  if ($("tech-stat-active")) $("tech-stat-active").textContent = String(cachedTechnicians.filter((t) => t.status === "ACTIVE").length);
  if ($("tech-stat-inactive")) $("tech-stat-inactive").textContent = String(cachedTechnicians.filter((t) => t.status !== "ACTIVE").length);

  const distSelect = $("tech-filter-district");
  if (distSelect) {
    const prev = distSelect.value || "all";
    const districts = Array.from(new Set(cachedTechnicians.map((t) => t.district).filter(Boolean))).sort();
    distSelect.innerHTML = `<option value="all">All Districts</option>` +
      districts.map((d) => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join("");
    distSelect.value = districts.includes(prev) ? prev : "all";
  }

  const qText = ($("tech-search-input")?.value || "").trim().toLowerCase();
  const dFilter = $("tech-filter-district")?.value || "all";
  const cFilter = $("tech-filter-category")?.value || "all";
  const sFilter = $("tech-filter-status")?.value || "all";

  const filtered = cachedTechnicians.filter((t) => {
    const matchesSearch = !qText ||
      String(t.fullName || "").toLowerCase().includes(qText) ||
      String(t.mobileNumber || "").toLowerCase().includes(qText) ||
      String(t.cityArea || "").toLowerCase().includes(qText);
    const matchesDist = dFilter === "all" || t.district === dFilter;
    const matchesCat = cFilter === "all" || (Array.isArray(t.serviceCategories) && t.serviceCategories.includes(cFilter));
    const matchesStatus = sFilter === "all" || t.status === sFilter;
    return matchesSearch && matchesDist && matchesCat && matchesStatus;
  });

  if ($("tech-filtered-count")) $("tech-filtered-count").textContent = `${filtered.length} shown`;
  const listEl = $("technicians-list");
  if (!listEl) return;
  if (!filtered.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No technicians match the active filters.</span></div>`;
    return;
  }

  listEl.innerHTML = filtered.map((t) => `
    <div class="list-item">
      <div class="list-header">
        <div class="tech-row">
          ${t.photoUrl
            ? `<img class="tech-avatar" src="${escapeHtml(safeHref(t.photoUrl))}" alt="${escapeHtml(t.fullName)}" />`
            : `<div class="tech-avatar-fallback">${escapeHtml(String(t.fullName || "RP").slice(0, 2).toUpperCase())}</div>`
          }
          <div>
            <strong>${escapeHtml(t.fullName)}</strong>
            ${t.verificationStatus === "VERIFIED" ? `<span class="badge badge-green">VERIFIED</span>` : ""}
            <span class="badge ${t.status === "ACTIVE" ? "badge-cyan" : "badge-warn"}">${escapeHtml(t.status)}</span>
            <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(t.mobileNumber)} • ${escapeHtml(t.cityArea)}, ${escapeHtml(t.district)} (${escapeHtml(t.pinCode)})</div>
            <div style="font-size:12px;color:var(--cyan);">${escapeHtml((t.serviceCategories || []).join(", "))} ${t.experience ? `• ${escapeHtml(t.experience)}` : ""}</div>
          </div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="button" class="btn btn-outline btn-sm" data-tech-edit="${escapeHtml(t.id)}">Edit</button>
          <button type="button" class="btn btn-outline btn-sm" data-tech-toggle="${escapeHtml(t.id)}">${t.status === "ACTIVE" ? "Deactivate" : "Activate"}</button>
          <button type="button" class="btn btn-danger btn-sm" data-tech-del="${escapeHtml(t.id)}">Delete</button>
        </div>
      </div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-tech-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const t = cachedTechnicians.find((x) => x.id === btn.dataset.techEdit);
      if (!t) return;
      $("tech-doc-id").value = t.id;
      $("tech-existing-photo-url").value = t.photoUrl || "";
      $("tech-existing-photo-path").value = t.photoStoragePath || "";
      $("tech-full-name").value = t.fullName || "";
      $("tech-mobile").value = t.mobileNumber || "";
      $("tech-experience").value = t.experience || "";
      $("tech-status").value = t.status || "ACTIVE";
      $("tech-address").value = t.fullAddress || "";
      $("tech-state").value = t.state || "";
      $("tech-district").value = t.district || "";
      $("tech-city-area").value = t.cityArea || "";
      $("tech-pin-code").value = t.pinCode || "";
      document.querySelectorAll(".tech-cat-checkbox").forEach((cb) => {
        cb.checked = Array.isArray(t.serviceCategories) && t.serviceCategories.includes(cb.value);
      });
      updateTechPhotoPreview(t.photoUrl || "", t.fullName || "RP");
      $("tech-form-heading").textContent = `Editing ${t.fullName}`;
      $("tech-cancel-edit-btn")?.classList.remove("hidden");
      $("technician-form")?.scrollIntoView({ behavior: "smooth" });
    });
  });

  listEl.querySelectorAll("[data-tech-toggle]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const t = cachedTechnicians.find((x) => x.id === btn.dataset.techToggle);
      if (!t || !currentUser) return;
      const nextStatus = t.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
      try {
        await updateDoc(doc(db, "technicians", t.id), {
          status: nextStatus,
          updatedByUid: currentUser.uid,
          updatedAt: serverTimestamp()
        });
        await writeAuditLog("TOGGLE_TECHNICIAN_STATUS", "technicians", t.id, `${t.fullName} -> ${nextStatus}`);
        showToast(`Technician set to ${nextStatus}.`);
      } catch (err) {
        showToast(`Status toggle failed: ${err.message}`, true);
      }
    });
  });

  listEl.querySelectorAll("[data-tech-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.techDel;
      if (!(await openConfirmModal("Delete Technician", `Remove technician ${id} permanently?`))) return;
      try {
        await deleteDoc(doc(db, "technicians", id));
        await writeAuditLog("DELETE_TECHNICIAN", "technicians", id, "Removed technician");
        showToast("Technician deleted.");
      } catch (err) {
        showToast(`Delete failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// PUSH NOTIFICATIONS (FCM HTTP v1 + IN-APP ALERTS — NEVER LOGS OUT)
// =========================================================================

$("push-audience")?.addEventListener("change", () => {
  const audience = $("push-audience").value;
  $("push-selected-users-wrap")?.classList.toggle("hidden", audience !== "SELECTED");
});

function renderPushUserChips() {
  const wrap = $("push-user-chips");
  if (!wrap) return;
  if (!cachedUsers.length) {
    wrap.innerHTML = `<span style="font-size:12px;color:var(--text-muted);">No user profiles loaded yet.</span>`;
    return;
  }
  const selected = new Set(
    ($("push-selected-uids")?.value || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
  );
  wrap.innerHTML = cachedUsers.slice(0, 60).map((u) => {
    const uid = u.userId || u.id;
    const label = `${u.displayName || "User"}${u.isVerifiedTechnician ? " ✓" : ""} (${uid.slice(0, 6)})`;
    return `<button type="button" class="user-chip ${selected.has(uid) ? "selected" : ""}" data-pick-uid="${escapeHtml(uid)}">${escapeHtml(label)}</button>`;
  }).join("");

  wrap.querySelectorAll("[data-pick-uid]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const uid = btn.dataset.pickUid;
      const input = $("push-selected-uids");
      const current = new Set(
        (input.value || "").split(",").map((s) => s.trim()).filter(Boolean)
      );
      if (current.has(uid)) current.delete(uid);
      else current.add(uid);
      input.value = Array.from(current).join(", ");
      renderPushUserChips();
    });
  });
}

$("push-selected-uids")?.addEventListener("input", renderPushUserChips);

$("push-image-file")?.addEventListener("change", async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    setBanner("push-result-banner", "Notification image must be 5 MB or less.", "error");
    return;
  }
  setBanner("push-result-banner", "Uploading notification image through Multi-Cloud Storage...", "info");
  try {
    const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
    const uploaded = await multiCloudUpload({
      bucketKey: "community",
      objectPath: `push_images/${Date.now()}.${ext}`,
      fileOrBlob: file,
      contentType: file.type || "image/jpeg"
    });
    if ($("push-image-url")) $("push-image-url").value = uploaded.publicUrl;
    setBanner(
      "push-result-banner",
      `Image uploaded to ${uploaded.providerName}${uploaded.failoverUsed ? " (Failover used)" : ""}.`,
      "success"
    );
  } catch (err) {
    setBanner("push-result-banner", `Image upload failed: ${err.message}. You can still send without an image.`, "warning");
  }
});

async function createInAppNotificationForUsers({ targetUids, type, title, body, imageUrl = "", targetRoute = "notifications" }) {
  if (!currentUser || !Array.isArray(targetUids) || !targetUids.length) return;
  const uniqueUids = Array.from(new Set(targetUids.filter(Boolean))).slice(0, 200);
  await Promise.allSettled(
    uniqueUids.map((recipientUid) => {
      const notifId = slugId("notif");
      return setDoc(doc(db, "user_notifications", notifId), {
        notificationId: notifId,
        recipientUid,
        actorUid: currentUser.uid,
        type,
        title: String(title).slice(0, 140),
        body: String(body).slice(0, 600),
        imageUrl: /^https:\/\//i.test(imageUrl) ? imageUrl : "",
        targetRoute: String(targetRoute || "notifications").slice(0, 160),
        isRead: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    })
  );
}

async function sendAutomatedPushAndInApp({ audience, targetUids = [], eventType, title, body, imageUrl = "", targetRoute = "notifications" }) {
  if (!currentUser) return;
  const cleanTitle = String(title || "").trim().slice(0, 140);
  const cleanBody = String(body || "").trim().slice(0, 1200);
  const cleanImage = /^https:\/\//i.test(String(imageUrl || "").trim()) ? String(imageUrl).trim() : "";

  if (audience === "ALL") {
    const annId = slugId("ann");
    const cat = ["GENERAL", "UPDATE", "GUIDE", "NEW_GUIDE", "NEW_PDF", "SAFETY", "COMMUNITY"].includes(eventType)
      ? eventType
      : "GENERAL";
    await setDoc(doc(db, "announcements", annId), {
      announcementId: annId,
      title: cleanTitle,
      body: cleanBody,
      category: cat,
      imageUrl: cleanImage,
      targetRoute: String(targetRoute || "notifications").slice(0, 160),
      createdByUid: currentUser.uid,
      createdAt: serverTimestamp()
    });
  } else {
    let resolvedUids = targetUids;
    if (audience === "TECHNICIANS" && !resolvedUids.length) {
      resolvedUids = cachedUsers.filter((u) => u.isVerifiedTechnician).map((u) => u.userId || u.id);
    }
    const notifType = ["POST_APPROVED", "POST_REJECTED", "VERIFICATION_APPROVED", "VERIFICATION_REJECTED", "VERIFICATION_SUSPENDED", "NEW_PDF", "ANNOUNCEMENT"].includes(eventType)
      ? eventType
      : "ANNOUNCEMENT";
    await createInAppNotificationForUsers({
      targetUids: resolvedUids,
      type: notifType,
      title: cleanTitle,
      body: cleanBody,
      imageUrl: cleanImage,
      targetRoute
    });
  }

  const rawEndpoint = ($("push-endpoint-url")?.value || storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT).trim();
  const endpoint = (!rawEndpoint || /\/send-fcm-v1$/i.test(rawEndpoint))
    ? DEFAULT_FCM_ENDPOINT
    : rawEndpoint;
  const pushId = slugId("push");
  let deliveryStatus = "IN_APP_ONLY";
  let sentCount = 0;
  let failedCount = 0;
  let errorMessage = "";

  if (endpoint && /^https?:\/\//i.test(endpoint)) {
    try {
      const idToken = await currentUser.getIdToken(false);
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${idToken}`
        },
        body: JSON.stringify({
          audience,
          targetUids,
          eventType,
          title: cleanTitle,
          body: cleanBody,
          imageUrl: cleanImage,
          targetRoute
        })
      });
      const payload = await response.json().catch(() => ({}));
      if (response.ok && payload.ok !== false) {
        sentCount = Number(payload.sentCount || 0);
        failedCount = Number(payload.failedCount || 0);
        deliveryStatus = payload.deliveryStatus || (sentCount > 0 ? (failedCount > 0 ? "PARTIAL" : "SENT") : "SENT");
        errorMessage = payload.message ? String(payload.message).slice(0, 500) : "";
      } else {
        deliveryStatus = "FAILED";
        errorMessage = `FCM backend HTTP ${response.status}: ${payload?.error || payload?.message || response.statusText}`.slice(0, 500);
      }
    } catch (err) {
      deliveryStatus = "FAILED";
      errorMessage = `FCM network/CORS error (session kept active): ${err?.message || err}`.slice(0, 500);
    }
  }

  try {
    await setDoc(doc(db, "push_notifications", pushId), {
      pushId,
      audience,
      eventType: String(eventType || "ANNOUNCEMENT").slice(0, 64),
      title: cleanTitle,
      body: cleanBody,
      imageUrl: cleanImage,
      targetRoute: String(targetRoute || "notifications").slice(0, 160),
      targetUids: Array.isArray(targetUids) ? targetUids.slice(0, 500) : [],
      deliveryStatus,
      sentCount,
      failedCount,
      errorMessage,
      createdByUid: currentUser.uid,
      createdAt: serverTimestamp()
    });
  } catch (err) {
    console.warn("push_notifications history log failed:", err?.message || err);
  }

  return { deliveryStatus, sentCount, failedCount, errorMessage };
}

async function handlePushSend(inAppOnly) {
  if (!currentUser) {
    setBanner("push-result-banner", "Please wait for Admin session verification before sending.", "warning");
    return;
  }
  const audience = $("push-audience")?.value || "ALL";
  const eventType = $("push-event-type")?.value || "ANNOUNCEMENT";
  const title = ($("push-title")?.value || "").trim();
  const body = ($("push-message")?.value || "").trim();
  const imageUrl = ($("push-image-url")?.value || "").trim();
  const targetRoute = $("push-route")?.value || "notifications";

  if (title.length < 2 || body.length < 2) {
    setBanner("push-result-banner", "Enter both a notification title (2+ chars) and message (2+ chars).", "error");
    return;
  }
  if (imageUrl && !/^https:\/\//i.test(imageUrl)) {
    setBanner("push-result-banner", "Optional notification image URL must start with https://.", "error");
    return;
  }

  let targetUids = [];
  if (audience === "SELECTED") {
    targetUids = ($("push-selected-uids")?.value || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (!targetUids.length) {
      setBanner("push-result-banner", "Select at least one target user UID for Selected Users audience.", "error");
      return;
    }
  } else if (audience === "TECHNICIANS") {
    targetUids = cachedUsers.filter((u) => u.isVerifiedTechnician).map((u) => u.userId || u.id);
  }

  const sendBtn = $("send-push-btn");
  const inAppBtn = $("save-inapp-only-btn");
  if (sendBtn) sendBtn.disabled = true;
  if (inAppBtn) inAppBtn.disabled = true;
  setBanner("push-result-banner", inAppOnly ? "Publishing in-app alert..." : "Dispatching FCM HTTP v1 push notification...", "info");

  try {
    if (inAppOnly) {
      if (audience === "ALL") {
        const annId = slugId("ann");
        await setDoc(doc(db, "announcements", annId), {
          announcementId: annId,
          title: title.slice(0, 140),
          body: body.slice(0, 1200),
          category: ["GENERAL", "UPDATE", "GUIDE", "NEW_GUIDE", "NEW_PDF", "SAFETY", "COMMUNITY"].includes(eventType) ? eventType : "GENERAL",
          imageUrl,
          targetRoute,
          createdByUid: currentUser.uid,
          createdAt: serverTimestamp()
        });
      } else {
        await createInAppNotificationForUsers({
          targetUids,
          type: eventType === "NEW_PDF" ? "NEW_PDF" : "ANNOUNCEMENT",
          title,
          body,
          imageUrl,
          targetRoute
        });
      }
      const pushId = slugId("push");
      await setDoc(doc(db, "push_notifications", pushId), {
        pushId,
        audience,
        eventType,
        title: title.slice(0, 140),
        body: body.slice(0, 1200),
        imageUrl,
        targetRoute,
        targetUids: targetUids.slice(0, 500),
        deliveryStatus: "IN_APP_ONLY",
        sentCount: 0,
        failedCount: 0,
        errorMessage: "",
        createdByUid: currentUser.uid,
        createdAt: serverTimestamp()
      });
      setBanner("push-result-banner", "In-app alert published without signing out or reloading.", "success");
      showToast("In-app notification published.");
    } else {
      const result = await sendAutomatedPushAndInApp({
        audience,
        targetUids,
        eventType,
        title,
        body,
        imageUrl,
        targetRoute
      });
      await writeAuditLog("SEND_PUSH_NOTIFICATION", "push_notifications", audience, `${title} (${result.deliveryStatus})`);
      if (result.deliveryStatus === "SENT" || result.deliveryStatus === "PARTIAL") {
        setBanner(
          "push-result-banner",
          `Push dispatched (${result.deliveryStatus}): ${result.sentCount} delivered, ${result.failedCount} failed. In-app notification synced.`,
          "success"
        );
        showToast(`Push sent to ${result.sentCount} device(s).`);
      } else {
        // Crucial: stay on Admin page, never log out!
        setBanner(
          "push-result-banner",
          `In-app alert saved, but FCM HTTP v1 push failed (${result.errorMessage}). Your Admin session stays active.`,
          "warning"
        );
        showToast("In-app saved; check FCM endpoint notice.", true);
      }
    }
    $("push-notification-form")?.reset();
    if ($("push-endpoint-url")) $("push-endpoint-url").value = storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT;
    $("push-selected-users-wrap")?.classList.add("hidden");
  } catch (err) {
    // Crucial fix: NEVER trigger signOut or redirect on any error!
    setBanner("push-result-banner", `Push request error (Admin session preserved): ${err.message}`, "error");
    showToast(`Push error: ${err.message}`, true);
  } finally {
    if (sendBtn) sendBtn.disabled = false;
    if (inAppBtn) inAppBtn.disabled = false;
  }
}

// Explicit click handlers + form submit prevention fix the login redirect bug
$("send-push-btn")?.addEventListener("click", (e) => {
  e.preventDefault();
  handlePushSend(false);
});
$("save-inapp-only-btn")?.addEventListener("click", (e) => {
  e.preventDefault();
  handlePushSend(true);
});
$("push-notification-form")?.addEventListener("submit", (e) => {
  e.preventDefault();
  handlePushSend(false);
});

function renderPushHistory() {
  const listEl = $("push-history-list");
  if (!listEl) return;
  if (!cachedPushHistory.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No push notification campaigns logged yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedPushHistory.slice(0, 40).map((p) => {
    const badgeClass = p.deliveryStatus === "SENT" ? "badge-green"
      : p.deliveryStatus === "FAILED" ? "badge-err"
      : p.deliveryStatus === "PARTIAL" ? "badge-warn" : "badge-cyan";
    return `
      <div class="list-item">
        <div class="list-header">
          <div>
            <span class="badge ${badgeClass}">${escapeHtml(p.deliveryStatus)}</span>
            <span class="badge badge-cyan">${escapeHtml(p.audience)}</span>
            <strong style="margin-left:6px;">${escapeHtml(p.title)}</strong>
          </div>
          <span style="font-size:11px;color:var(--text-muted);">${escapeHtml(formatTs(p.createdAt))}</span>
        </div>
        <div style="font-size:13px;color:var(--text-muted);margin-bottom:4px;">${escapeHtml(p.body)}</div>
        <div style="font-size:12px;color:var(--text-muted);">
          Sent: <strong>${Number(p.sentCount || 0)}</strong> • Failed: <strong>${Number(p.failedCount || 0)}</strong>
          ${p.imageUrl ? ` • <a href="${escapeHtml(safeHref(p.imageUrl))}" target="_blank" rel="noopener">Image</a>` : ""}
          ${p.errorMessage ? `<div style="color:var(--warning);margin-top:4px;">${escapeHtml(p.errorMessage)}</div>` : ""}
        </div>
      </div>
    `;
  }).join("");
}

function renderAnnouncementsList() {
  const listEl = $("announcements-list");
  if (!listEl) return;
  if (!cachedAnnouncements.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No in-app announcements published yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedAnnouncements.slice(0, 30).map((a) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge badge-cyan">${escapeHtml(a.category || "GENERAL")}</span>
          <strong style="margin-left:6px;">${escapeHtml(a.title)}</strong>
        </div>
        <button type="button" class="btn btn-danger btn-sm" data-ann-del="${escapeHtml(a.id)}">Delete</button>
      </div>
      <div style="font-size:13px;color:var(--text-muted);">${escapeHtml(a.body)}</div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-ann-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.annDel;
      try {
        await deleteDoc(doc(db, "announcements", id));
        showToast("Announcement deleted.");
      } catch (err) {
        showToast(`Delete failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// TECHNICIAN VERIFICATION QUEUE (+ AUTO NOTIFICATION)
// =========================================================================

$("ver-filter-status")?.addEventListener("change", renderVerificationSection);

function renderVerificationSection() {
  if ($("ver-stat-pending")) $("ver-stat-pending").textContent = String(cachedVerifications.filter((v) => v.status === "PENDING").length);
  if ($("ver-stat-verified")) $("ver-stat-verified").textContent = String(cachedVerifications.filter((v) => v.status === "VERIFIED").length);
  if ($("ver-stat-rejected")) $("ver-stat-rejected").textContent = String(cachedVerifications.filter((v) => ["REJECTED", "SUSPENDED"].includes(v.status)).length);

  const filter = $("ver-filter-status")?.value || "PENDING";
  const items = cachedVerifications.filter((v) => filter === "ALL" || v.status === filter);
  const listEl = $("verification-requests-list");
  if (!listEl) return;
  if (!items.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No verification applications in this queue.</span></div>`;
    return;
  }

  listEl.innerHTML = items.map((v) => {
    const badge = v.status === "VERIFIED" ? "badge-green"
      : v.status === "PENDING" ? "badge-warn" : "badge-err";
    return `
      <div class="list-item">
        <div class="list-header">
          <div>
            <strong>${escapeHtml(v.fullName)}</strong>
            <span class="badge ${badge}">${escapeHtml(v.status)}</span>
            <div style="font-size:12px;color:var(--text-muted);">UID: ${escapeHtml(v.userId)} • ${escapeHtml(v.mobileNumber)} • ${escapeHtml(v.cityArea)}, ${escapeHtml(v.district)} (${escapeHtml(v.pinCode)})</div>
            <div style="font-size:12px;color:var(--cyan);">${escapeHtml((v.serviceCategories || []).join(", "))} ${v.experience ? `• ${escapeHtml(v.experience)}` : ""}</div>
            ${v.credentialDocUrl ? `<div style="font-size:12px;margin-top:4px;"><a href="${escapeHtml(safeHref(v.credentialDocUrl))}" target="_blank" rel="noopener">View Submitted Document (${escapeHtml(v.credentialDocName || "file")})</a></div>` : ""}
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button type="button" class="btn btn-success btn-sm" data-ver-action="VERIFIED" data-ver-uid="${escapeHtml(v.id)}">Approve</button>
            <button type="button" class="btn btn-danger btn-sm" data-ver-action="REJECTED" data-ver-uid="${escapeHtml(v.id)}">Reject</button>
            <button type="button" class="btn btn-outline btn-sm" data-ver-action="SUSPENDED" data-ver-uid="${escapeHtml(v.id)}">Suspend</button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  listEl.querySelectorAll("[data-ver-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!currentUser) return;
      const uid = btn.dataset.verUid;
      const nextStatus = btn.dataset.verAction;
      const req = cachedVerifications.find((x) => x.id === uid);
      if (!req) return;
      const reason = nextStatus === "VERIFIED"
        ? ""
        : (window.prompt(`Enter ${nextStatus.toLowerCase()} note for ${req.fullName}:`, "") || "").trim();
      try {
        await updateDoc(doc(db, "technician_verification_requests", uid), {
          status: nextStatus,
          rejectionReason: reason,
          reviewedByUid: currentUser.uid,
          updatedAt: serverTimestamp()
        });
        await updateDoc(doc(db, "users", uid), {
          isVerifiedTechnician: nextStatus === "VERIFIED",
          updatedAt: serverTimestamp()
        }).catch(() => {});

        const techDocId = `tech_${uid}`;
        if (nextStatus === "VERIFIED") {
          await setDoc(doc(db, "technicians", techDocId), {
            technicianId: techDocId,
            fullName: req.fullName,
            photoUrl: req.profilePhotoUrl || "",
            photoStoragePath: req.profilePhotoStoragePath || "",
            mobileNumber: req.mobileNumber,
            fullAddress: req.fullAddress,
            state: req.state,
            district: req.district,
            cityArea: req.cityArea,
            pinCode: req.pinCode,
            serviceCategories: req.serviceCategories || ["AC"],
            experience: req.experience || "",
            bio: req.bio || "",
            verificationStatus: "VERIFIED",
            blocked: false,
            linkedUserUid: uid,
            status: "ACTIVE",
            updatedByUid: currentUser.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          }, { merge: true });
        }

        const title = nextStatus === "VERIFIED"
          ? "Technician Verification Approved"
          : nextStatus === "SUSPENDED" ? "Technician Verification Suspended" : "Technician Verification Update";
        const body = nextStatus === "VERIFIED"
          ? "Congratulations! Your verified technician badge is now live in Repair Pro."
          : (reason || `Your verification status is now ${nextStatus}.`);
        await sendAutomatedPushAndInApp({
          audience: "SELECTED",
          targetUids: [uid],
          eventType: `VERIFICATION_${nextStatus}`,
          title,
          body,
          targetRoute: "verification"
        });
        await writeAuditLog("REVIEW_VERIFICATION", "technician_verification_requests", uid, `${req.fullName} -> ${nextStatus}`);
        showToast(`Application marked ${nextStatus} & user notified.`);
      } catch (err) {
        showToast(`Verification update failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// COMMUNITY MODERATION (+ AUTO POST APPROVAL NOTIFICATIONS)
// =========================================================================

$("comm-filter-status")?.addEventListener("change", renderCommunitySection);
$("comm-filter-category")?.addEventListener("change", renderCommunitySection);

function renderCommunitySection() {
  if ($("comm-stat-pending")) $("comm-stat-pending").textContent = String(cachedCommunityPosts.filter((p) => p.approvalStatus === "PENDING").length);
  if ($("comm-stat-approved")) $("comm-stat-approved").textContent = String(cachedCommunityPosts.filter((p) => p.approvalStatus === "APPROVED").length);
  if ($("comm-stat-rejected")) $("comm-stat-rejected").textContent = String(cachedCommunityPosts.filter((p) => p.approvalStatus === "REJECTED").length);
  if ($("comm-stat-reports")) $("comm-stat-reports").textContent = String(cachedCommunityReports.filter((r) => r.status === "OPEN").length);

  const sFilter = $("comm-filter-status")?.value || "PENDING";
  const cFilter = $("comm-filter-category")?.value || "ALL";
  const posts = cachedCommunityPosts.filter((p) =>
    (sFilter === "ALL" || p.approvalStatus === sFilter) &&
    (cFilter === "ALL" || p.category === cFilter)
  );

  const postsEl = $("community-posts-list");
  if (postsEl) {
    postsEl.innerHTML = posts.length
      ? posts.map((p) => `
          <div class="list-item">
            <div class="list-header">
              <div>
                <span class="badge ${p.approvalStatus === "APPROVED" ? "badge-green" : p.approvalStatus === "PENDING" ? "badge-warn" : "badge-err"}">${escapeHtml(p.approvalStatus)}</span>
                ${p.isPinned ? `<span class="badge badge-cyan">PINNED</span>` : ""}
                <strong style="margin-left:6px;">${escapeHtml(p.title)}</strong>
                <div style="font-size:12px;color:var(--text-muted);">By ${escapeHtml(p.authorName)} • ${escapeHtml(p.category)} • ${escapeHtml(formatTs(p.createdAt))}</div>
              </div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button type="button" class="btn btn-success btn-sm" data-post-mod="APPROVED" data-post-id="${escapeHtml(p.id)}">Approve</button>
                <button type="button" class="btn btn-danger btn-sm" data-post-mod="REJECTED" data-post-id="${escapeHtml(p.id)}">Reject</button>
                <button type="button" class="btn btn-outline btn-sm" data-post-pin="${escapeHtml(p.id)}">${p.isPinned ? "Unpin" : "Pin"}</button>
                <button type="button" class="btn btn-outline btn-sm" data-post-block="${escapeHtml(p.authorUid)}" data-author-name="${escapeHtml(p.authorName)}">Block User</button>
              </div>
            </div>
            <div style="font-size:13px;color:var(--text-muted);">${escapeHtml(p.body)}</div>
          </div>
        `).join("")
      : `<div class="list-item"><span style="color:var(--text-muted);">No community posts in this filter.</span></div>`;

    postsEl.querySelectorAll("[data-post-mod]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!currentUser) return;
        const postId = btn.dataset.postId;
        const nextStatus = btn.dataset.postMod;
        const post = cachedCommunityPosts.find((x) => x.id === postId);
        if (!post) return;
        try {
          await updateDoc(doc(db, "community_posts", postId), {
            approvalStatus: nextStatus,
            reviewedByUid: currentUser.uid,
            updatedAt: serverTimestamp()
          });
          if (post.authorUid) {
            await sendAutomatedPushAndInApp({
              audience: "SELECTED",
              targetUids: [post.authorUid],
              eventType: nextStatus === "APPROVED" ? "POST_APPROVED" : "POST_REJECTED",
              title: nextStatus === "APPROVED" ? "Community Post Approved" : "Community Post Update",
              body: nextStatus === "APPROVED"
                ? `Your post "${post.title}" is now live in the Technician Community.`
                : `Your post "${post.title}" was not approved by moderators.`,
              targetRoute: "community"
            });
          }
          await writeAuditLog("MODERATE_COMMUNITY_POST", "community_posts", postId, `${post.title} -> ${nextStatus}`);
          showToast(`Post marked ${nextStatus} & author notified.`);
        } catch (err) {
          showToast(`Moderation failed: ${err.message}`, true);
        }
      });
    });

    postsEl.querySelectorAll("[data-post-pin]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const post = cachedCommunityPosts.find((x) => x.id === btn.dataset.postPin);
        if (!post) return;
        try {
          await updateDoc(doc(db, "community_posts", post.id), {
            isPinned: !post.isPinned,
            updatedAt: serverTimestamp()
          });
          showToast(post.isPinned ? "Post unpinned." : "Post pinned to top.");
        } catch (err) {
          showToast(`Pin failed: ${err.message}`, true);
        }
      });
    });

    postsEl.querySelectorAll("[data-post-block]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!currentUser) return;
        const uid = btn.dataset.postBlock;
        const name = btn.dataset.authorName || "User";
        const reason = (window.prompt(`Reason for blocking ${name} from posting:`, "Community guideline violation") || "").trim();
        if (!reason) return;
        try {
          await setDoc(doc(db, "community_user_restrictions", uid), {
            userId: uid,
            userName: name.slice(0, 80),
            reason: reason.slice(0, 400),
            blockedByUid: currentUser.uid,
            createdAt: serverTimestamp()
          });
          showToast(`${name} blocked from community posting.`);
        } catch (err) {
          showToast(`Block failed: ${err.message}`, true);
        }
      });
    });
  }

  const reportsEl = $("community-reports-list");
  if (reportsEl) {
    reportsEl.innerHTML = cachedCommunityReports.length
      ? cachedCommunityReports.map((r) => `
          <div class="list-item">
            <div class="list-header">
              <strong>${escapeHtml(r.reason)} — Post ${escapeHtml(r.postId)}</strong>
              <span class="badge ${r.status === "OPEN" ? "badge-warn" : "badge-green"}">${escapeHtml(r.status)}</span>
            </div>
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">Reported by ${escapeHtml(r.reporterName)} • ${escapeHtml(r.details || "")}</div>
            <button type="button" class="btn btn-outline btn-sm" data-creport-resolve="${escapeHtml(r.id)}">Mark Resolved</button>
          </div>
        `).join("")
      : `<div class="list-item"><span style="color:var(--text-muted);">No community reports found.</span></div>`;
    reportsEl.querySelectorAll("[data-creport-resolve]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await updateDoc(doc(db, "community_reports", btn.dataset.creportResolve), {
            status: "RESOLVED",
            updatedAt: serverTimestamp()
          });
          showToast("Report marked resolved.");
        } catch (err) {
          showToast(`Update failed: ${err.message}`, true);
        }
      });
    });
  }

  const restrEl = $("community-restrictions-list");
  if (restrEl) {
    restrEl.innerHTML = cachedCommunityRestrictions.length
      ? cachedCommunityRestrictions.map((r) => `
          <div class="list-item">
            <div class="list-header">
              <div><strong>${escapeHtml(r.userName || r.userId)}</strong><div style="font-size:12px;color:var(--text-muted);">${escapeHtml(r.reason)}</div></div>
              <button type="button" class="btn btn-outline btn-sm" data-unblock-uid="${escapeHtml(r.id)}">Unblock</button>
            </div>
          </div>
        `).join("")
      : `<div class="list-item"><span style="color:var(--text-muted);">No blocked community users.</span></div>`;
    restrEl.querySelectorAll("[data-unblock-uid]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await deleteDoc(doc(db, "community_user_restrictions", btn.dataset.unblockUid));
          showToast("User unblocked.");
        } catch (err) {
          showToast(`Unblock failed: ${err.message}`, true);
        }
      });
    });
  }
}

// =========================================================================
// PDF MANUALS & CIRCUIT DIAGRAMS (MULTI-CLOUD UPLOAD + AUTO PUSH)
// =========================================================================

$("tech-doc-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const file = $("doc-file-input")?.files?.[0];
  const title = $("doc-title")?.value.trim();
  if (!file || !title) {
    showToast("Select a PDF/image file and enter a title.", true);
    return;
  }
  if (file.size > 20 * 1024 * 1024) {
    showToast("Technical documents must be 20 MB or smaller.", true);
    return;
  }
  const docType = $("doc-type").value;
  const bucketKey = docType === "PDF_MANUAL" ? "pdfs" : docType === "CIRCUIT_DIAGRAM" ? "diagrams" : "community";
  const docId = slugId("doc");
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-60);
  const uploadBtn = $("doc-upload-btn");
  if (uploadBtn) uploadBtn.disabled = true;
  $("doc-upload-progress-wrap")?.classList.remove("hidden");

  try {
    const uploaded = await multiCloudUpload({
      bucketKey,
      objectPath: `${docId}_${safeName}`,
      fileOrBlob: file,
      contentType: file.type || (docType === "PDF_MANUAL" ? "application/pdf" : "image/png"),
      onProgress: (p) => {
        if ($("doc-upload-progress-fill")) $("doc-upload-progress-fill").style.width = `${Math.round(p * 100)}%`;
      }
    });

    await setDoc(doc(db, "technical_documents", docId), {
      docId,
      docType,
      categoryId: $("doc-category").value,
      brandName: $("doc-brand").value.trim(),
      modelName: $("doc-model").value.trim(),
      linkedEntryId: $("doc-linked-entry").value.trim(),
      title,
      description: $("doc-description").value.trim(),
      fileUrl: uploaded.publicUrl,
      storagePath: uploaded.storagePath,
      mimeType: file.type || "application/pdf",
      fileSizeBytes: Number(file.size || 0),
      published: $("doc-published").checked,
      uploadedByUid: currentUser.uid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    if ($("doc-notify-users")?.checked && $("doc-published")?.checked) {
      await sendAutomatedPushAndInApp({
        audience: "ALL",
        eventType: "NEW_PDF",
        title: `New ${docType === "PDF_MANUAL" ? "PDF Manual" : "Diagram"}: ${title}`.slice(0, 140),
        body: `${$("doc-brand").value.trim() || "Repair Pro"} technical resource is now available to view in the app.`,
        targetRoute: "documents"
      });
    }

    await writeAuditLog("UPLOAD_TECHNICAL_DOCUMENT", "technical_documents", docId, `${title} -> ${uploaded.providerName}`);
    $("tech-doc-form")?.reset();
    showToast(`Document uploaded to ${uploaded.providerName}${uploaded.failoverUsed ? " (Failover)" : ""}.`);
  } catch (err) {
    showToast(`Document upload failed: ${err.message}`, true);
  } finally {
    if (uploadBtn) uploadBtn.disabled = false;
  }
});

function renderDocumentsList() {
  const listEl = $("technical-documents-list");
  if (!listEl) return;
  if (!cachedDocuments.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No technical documents uploaded yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedDocuments.map((d) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge badge-cyan">${escapeHtml(d.docType)}</span>
          <span class="badge ${d.published ? "badge-green" : "badge-warn"}">${d.published ? "LIVE" : "HIDDEN"}</span>
          <strong style="margin-left:6px;">${escapeHtml(d.title)}</strong>
          <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(d.categoryId.toUpperCase())} ${d.brandName ? `• ${escapeHtml(d.brandName)}` : ""} • ${formatBytes(d.fileSizeBytes)}</div>
        </div>
        <div style="display:flex;gap:8px;">
          <a class="btn btn-outline btn-sm" href="${escapeHtml(safeHref(d.fileUrl))}" target="_blank" rel="noopener">Open</a>
          <button type="button" class="btn btn-danger btn-sm" data-doc-del="${escapeHtml(d.id)}">Delete</button>
        </div>
      </div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-doc-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.docDel;
      if (!(await openConfirmModal("Delete Technical Document", `Delete document ${id}?`))) return;
      try {
        await deleteDoc(doc(db, "technical_documents", id));
        await writeAuditLog("DELETE_TECHNICAL_DOCUMENT", "technical_documents", id, "Removed document");
        showToast("Document removed.");
      } catch (err) {
        showToast(`Delete failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// MULTI-CLOUD STORAGE MANAGER UI
// =========================================================================

function syncStorageFormsFromState() {
  const supa = getPrimarySupabaseProvider();
  if ($("st-supabase-url")) $("st-supabase-url").value = supa.endpointUrl || SUPABASE_URL;
  if ($("st-supabase-anon-key")) $("st-supabase-anon-key").value = supa.publicAnonKey || "";
  if ($("st-fcm-endpoint")) $("st-fcm-endpoint").value = storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT;
  if ($("st-hosting-proxy-url")) $("st-hosting-proxy-url").value = storageState.hostingProxyUrl || DEFAULT_HOSTING_PROXY_URL;
  if ($("st-comp-max-dim")) $("st-comp-max-dim").value = storageState.compressionMaxDim || 1440;
  if ($("st-comp-quality")) $("st-comp-quality").value = storageState.compressionQuality || 82;
  if ($("st-comp-max-kb")) $("st-comp-max-kb").value = storageState.compressionMaxSizeKb || 4500;
  if ($("st-duplicate-check")) $("st-duplicate-check").checked = storageState.duplicateCheckEnabled !== false;
  if ($("push-endpoint-url") && !$("push-endpoint-url").value) {
    $("push-endpoint-url").value = storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT;
  }
  if ($("st-auto-failover")) $("st-auto-failover").checked = storageState.autoFailoverEnabled !== false;

  const phpProv = (storageState.providers || []).find((p) => p.providerType === "PHP_HOSTING");
  if (phpProv) {
    if ($("php-vendor") && phpProv.hostingVendor) $("php-vendor").value = phpProv.hostingVendor;
    if ($("php-name")) $("php-name").value = phpProv.providerName || "";
    if ($("php-endpoint-url")) $("php-endpoint-url").value = phpProv.endpointUrl || "";
    if ($("php-public-base-url")) $("php-public-base-url").value = phpProv.publicMediaBaseUrl || "";
    if ($("php-role")) $("php-role").value = phpProv.role === "PRIMARY" ? "PRIMARY" : "BACKUP";
    if ($("php-capacity-mb")) $("php-capacity-mb").value = Math.round((phpProv.capacityLimitBytes || 5368709120) / (1024 * 1024));
    if ($("php-community-only")) $("php-community-only").checked = phpProv.communityOnly !== false;
  }
}

async function persistStorageConfigToFirestore() {
  if (!currentUser) return;
  const cleanProviders = sanitizeProvidersForFirestore(storageState.providers);
  await setDoc(doc(db, "app_settings", "storage_config"), {
    configType: "STORAGE",
    autoFailoverEnabled: Boolean(storageState.autoFailoverEnabled),
    fcmBackendUrl: String(storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT).trim().slice(0, 500),
    hostingProxyUrl: String(storageState.hostingProxyUrl || DEFAULT_HOSTING_PROXY_URL).trim().slice(0, 500),
    compressionMaxDim: Math.min(4096, Math.max(480, Math.round(Number(storageState.compressionMaxDim || 1440)))),
    compressionQuality: Math.min(100, Math.max(40, Math.round(Number(storageState.compressionQuality || 82)))),
    compressionMaxSizeKb: Math.min(5120, Math.max(100, Math.round(Number(storageState.compressionMaxSizeKb || 4500)))),
    duplicateCheckEnabled: Boolean(storageState.duplicateCheckEnabled),
    providersJson: JSON.stringify(cleanProviders).slice(0, 20000),
    updatedByUid: currentUser.uid,
    updatedAt: serverTimestamp()
  }, { merge: true });
}

$("storage-connection-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const supaUrl = ($("st-supabase-url")?.value || SUPABASE_URL).trim().replace(/\/+$/, "");
  const supaAnon = ($("st-supabase-anon-key")?.value || "").trim();
  const fcmUrl = ($("st-fcm-endpoint")?.value || DEFAULT_FCM_ENDPOINT).trim();
  const proxyUrl = ($("st-hosting-proxy-url")?.value || DEFAULT_HOSTING_PROXY_URL).trim();
  const maxDim = Math.min(4096, Math.max(480, Math.round(Number($("st-comp-max-dim")?.value || 1440))));
  const quality = Math.min(100, Math.max(40, Math.round(Number($("st-comp-quality")?.value || 82))));
  const maxKb = Math.min(5120, Math.max(100, Math.round(Number($("st-comp-max-kb")?.value || 4500))));
  const dupCheck = $("st-duplicate-check") ? Boolean($("st-duplicate-check").checked) : true;
  const autoFailover = Boolean($("st-auto-failover")?.checked);

  let foundSupa = false;
  storageState.providers = (storageState.providers || []).map((p) => {
    if (p.providerId === "supabase_primary" || (!foundSupa && p.providerType === "SUPABASE_STORAGE")) {
      foundSupa = true;
      return {
        ...p,
        endpointUrl: supaUrl,
        publicAnonKey: supaAnon,
        lastStatus: supaAnon ? "CONFIGURED" : "NEEDS_ANON_KEY"
      };
    }
    return p;
  });
  if (!foundSupa) {
    storageState.providers.unshift({
      ...defaultSupabasePrimaryProvider(),
      endpointUrl: supaUrl,
      publicAnonKey: supaAnon
    });
  }
  storageState.autoFailoverEnabled = autoFailover;
  storageState.fcmBackendUrl = fcmUrl;
  storageState.hostingProxyUrl = /^https:\/\//i.test(proxyUrl) ? proxyUrl : DEFAULT_HOSTING_PROXY_URL;
  storageState.compressionMaxDim = maxDim;
  storageState.compressionQuality = quality;
  storageState.compressionMaxSizeKb = maxKb;
  storageState.duplicateCheckEnabled = dupCheck;
  if ($("push-endpoint-url")) $("push-endpoint-url").value = fcmUrl;

  try {
    await persistStorageConfigToFirestore();
    await writeAuditLog("UPDATE_STORAGE_CONFIG", "app_settings", "storage_config", `Primary=${supaUrl}, Failover=${autoFailover}, MaxDim=${maxDim}`);
    setBanner("storage-config-banner", "Storage & compression settings saved and synced to Firestore app_settings/storage_config.", "success");
    showToast("Storage config synced.");
  } catch (err) {
    setBanner("storage-config-banner", `Failed to save storage config: ${err.message}`, "error");
  }
});

async function callHostingProxy(payload) {
  if (!currentUser) throw new Error("Sign in as Super Admin first.");
  const proxyUrl = String(storageState.hostingProxyUrl || DEFAULT_HOSTING_PROXY_URL).trim();
  const idToken = await currentUser.getIdToken();
  const resp = await fetch(proxyUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${idToken}`
    },
    body: JSON.stringify(payload)
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok || data.ok === false) {
    throw new Error(data.message || `Hosting proxy HTTP ${resp.status}`);
  }
  return data;
}

function getOrBuildPhpProviderDraft() {
  const vendor = ($("php-vendor")?.value || "Hostinger").trim();
  const name = ($("php-name")?.value || `${vendor} Shared Hosting`).trim();
  const endpointUrl = ($("php-endpoint-url")?.value || "").trim().replace(/\/+$/, "");
  const publicMediaBaseUrl = ($("php-public-base-url")?.value || "").trim().replace(/\/+$/, "");
  const role = ($("php-role")?.value || "BACKUP") === "PRIMARY" ? "PRIMARY" : "BACKUP";
  const capMb = Math.max(100, Number($("php-capacity-mb")?.value || 5120));
  const communityOnly = $("php-community-only") ? Boolean($("php-community-only").checked) : true;
  const existing = (storageState.providers || []).find((p) => p.providerType === "PHP_HOSTING");
  return {
    providerId: existing?.providerId || `php_${vendor.toLowerCase().replace(/[^a-z0-9]+/g, "_")}`,
    providerName: name,
    providerType: "PHP_HOSTING",
    endpointUrl,
    publicAnonKey: "",
    proxyUploadUrl: storageState.hostingProxyUrl || DEFAULT_HOSTING_PROXY_URL,
    hostingVendor: vendor,
    publicMediaBaseUrl,
    communityOnly,
    role,
    enabled: true,
    capacityLimitBytes: capMb * 1024 * 1024,
    usedBytes: existing?.usedBytes || 0,
    lastStatus: existing?.lastStatus || "CONFIGURED",
    buckets: { ...DEFAULT_SUPABASE_BUCKETS }
  };
}

$("php-vendor")?.addEventListener("change", () => {
  const v = $("php-vendor").value;
  if ($("php-name") && !$("php-name").value.trim()) {
    $("php-name").value = `${v} Community Media`;
  }
});

$("php-hosting-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const draft = getOrBuildPhpProviderDraft();
  if (!/^https:\/\//i.test(draft.endpointUrl) || !/^https:\/\//i.test(draft.publicMediaBaseUrl)) {
    setBanner("php-hosting-banner", "Both PHP API Endpoint URL and Public Media Base URL must start with https://", "error");
    return;
  }
  const secret = ($("php-api-secret")?.value || "").trim();
  if (secret && secret.length < 16) {
    setBanner("php-hosting-banner", "PHP API Secret must be at least 16 characters.", "error");
    return;
  }
  try {
    if (secret) {
      await callHostingProxy({ action: "save_secret", providerId: draft.providerId, apiSecret: secret });
      if ($("php-api-secret")) $("php-api-secret").value = "";
    }
    const normalized = normalizeProvider(draft);
    const others = (storageState.providers || []).filter((p) => p.providerId !== normalized.providerId);
    const updatedList = normalized.role === "PRIMARY"
      ? others.map((p) => (p.role === "PRIMARY" ? { ...p, role: "BACKUP" } : p))
      : others;
    storageState.providers = [...updatedList, normalized];
    await persistStorageConfigToFirestore();
    await writeAuditLog("SAVE_PHP_HOSTING", "app_settings", "storage_config", `${normalized.hostingVendor}: ${normalized.endpointUrl} (communityOnly=${normalized.communityOnly})`);
    setBanner("php-hosting-banner", `Shared hosting provider "${normalized.providerName}" saved & synced.${secret ? " Secret stored securely on backend." : ""}`, "success");
    showToast("Shared web hosting saved.");
  } catch (err) {
    setBanner("php-hosting-banner", `Could not save shared hosting: ${err.message}`, "error");
  }
});

$("php-save-secret-btn")?.addEventListener("click", async () => {
  const draft = getOrBuildPhpProviderDraft();
  const secret = ($("php-api-secret")?.value || "").trim();
  if (secret.length < 16) {
    setBanner("php-hosting-banner", "Enter a strong PHP API Secret (at least 16 characters) matching config.php.", "error");
    return;
  }
  try {
    await callHostingProxy({ action: "save_secret", providerId: draft.providerId, apiSecret: secret });
    if ($("php-api-secret")) $("php-api-secret").value = "";
    setBanner("php-hosting-banner", `Backend hosting secret saved securely for ${draft.providerId} (never written to Firestore or APK).`, "success");
    showToast("Hosting secret stored.");
  } catch (err) {
    setBanner("php-hosting-banner", `Failed to store hosting secret: ${err.message}`, "error");
  }
});

$("php-test-btn")?.addEventListener("click", async () => {
  const draft = getOrBuildPhpProviderDraft();
  if (!/^https:\/\//i.test(draft.endpointUrl)) {
    setBanner("php-hosting-banner", "Enter your HTTPS PHP API Endpoint URL first (e.g. https://yourdomain.com/repairpro-api/index.php).", "error");
    return;
  }
  setBanner("php-hosting-banner", "Testing shared hosting PHP API health & upload directory permissions...", "info");
  try {
    const tempSecret = ($("php-api-secret")?.value || "").trim();
    const res = await callHostingProxy({
      action: "test_connection",
      providerId: draft.providerId,
      uploadApiUrl: draft.endpointUrl,
      endpointUrl: draft.endpointUrl,
      tempApiSecret: tempSecret || undefined
    });
    const phpVer = res.phpVersion ? `PHP ${res.phpVersion}` : "PHP OK";
    const writable = res.uploadsWritable ? "uploads writable" : "check folder permissions";
    setBanner("php-hosting-banner", `Connected to ${draft.hostingVendor}! (${phpVer}, ${writable}).`, "success");
    showToast("Shared hosting connection verified.");
  } catch (err) {
    setBanner("php-hosting-banner", `Connection check failed: ${err.message}`, "error");
  }
});

$("st-test-failover-btn")?.addEventListener("click", async () => {
  const ordered = getOrderedActiveProviders();
  if (ordered.length < 2) {
    setBanner("storage-config-banner", "Add and enable at least one BACKUP provider below to test multi-cloud failover.", "warning");
    return;
  }
  const primary = ordered[0];
  const backup = ordered[1];
  await logStorageError(primary.providerId, "diagnostic-check", "failover_dry_run", "Simulated primary outage check (Admin Test)", backup.providerId);
  setBanner(
    "storage-config-banner",
    `Failover verified: Primary "${primary.providerName}" -> Backup "${backup.providerName}" (Auto-Failover ${storageState.autoFailoverEnabled ? "ON" : "OFF"}).`,
    "success"
  );
});

$("add-provider-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const pType = $("prov-type").value;
  const pName = $("prov-name").value.trim();
  const pEndpoint = $("prov-endpoint").value.trim().replace(/\/+$/, "");
  const pKeyOrProxy = $("prov-key-or-proxy").value.trim();
  const capMb = Math.max(100, Number($("prov-capacity-mb").value || 1024));
  const role = $("prov-role").value;

  if (!pName || !pEndpoint) {
    showToast("Provider name and endpoint URL are required.", true);
    return;
  }

  const newProv = normalizeProvider({
    providerId: slugId("prov"),
    providerName: pName,
    providerType: pType,
    endpointUrl: pEndpoint,
    publicAnonKey: pType === "SUPABASE_STORAGE" ? pKeyOrProxy : "",
    proxyUploadUrl: pType !== "SUPABASE_STORAGE" && pType !== "FIREBASE_LEGACY" ? pKeyOrProxy : "",
    role,
    enabled: true,
    capacityLimitBytes: capMb * 1024 * 1024,
    usedBytes: 0,
    lastStatus: "ADDED"
  });

  if (role === "PRIMARY") {
    storageState.providers = storageState.providers.map((p) => (p.role === "PRIMARY" ? { ...p, role: "BACKUP" } : p));
  }
  storageState.providers.push(newProv);

  try {
    await persistStorageConfigToFirestore();
    await writeAuditLog("ADD_STORAGE_PROVIDER", "app_settings", "storage_config", `${pName} (${pType})`);
    $("add-provider-form").reset();
    showToast(`Added storage provider "${pName}".`);
  } catch (err) {
    showToast(`Failed to add provider: ${err.message}`, true);
  }
});

async function testProviderConnection(provider) {
  try {
    if (provider.providerType === "SUPABASE_STORAGE") {
      if (!provider.publicAnonKey) {
        throw new Error("Public Anon Key is required to test Supabase Storage.");
      }
      const resp = await fetch(`${provider.endpointUrl}/storage/v1/bucket`, {
        headers: {
          apikey: provider.publicAnonKey,
          Authorization: `Bearer ${provider.publicAnonKey}`
        }
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      provider.lastStatus = "ONLINE";
      showToast(`${provider.providerName} connected (HTTP ${resp.status}).`);
    } else if (provider.providerType === "PHP_HOSTING") {
      await callHostingProxy({
        action: "test_connection",
        providerId: provider.providerId,
        uploadApiUrl: provider.endpointUrl,
        endpointUrl: provider.endpointUrl
      });
      provider.lastStatus = "ONLINE";
      showToast(`${provider.providerName} PHP Hosting API verified.`);
    } else if (provider.providerType === "FIREBASE_LEGACY") {
      provider.lastStatus = "READY";
      showToast("Firebase Storage Legacy Compatibility adapter ready.");
    } else {
      if (!provider.proxyUploadUrl) throw new Error("Signed Upload Proxy URL not configured.");
      provider.lastStatus = "PROXY_SET";
      showToast(`Signed proxy configured at ${provider.proxyUploadUrl}.`);
    }
    await persistStorageConfigToFirestore();
  } catch (err) {
    provider.lastStatus = "ERROR";
    showToast(`Connection test failed for ${provider.providerName}: ${err.message}`, true);
    renderStorageManager();
  }
}

function renderStorageStats() {
  const primary = (storageState.providers || []).find((p) => p.enabled && p.role === "PRIMARY") || storageState.providers[0];
  if ($("st-stat-active-primary")) $("st-stat-active-primary").textContent = primary ? primary.providerName : "Supabase";
  if ($("st-stat-providers")) $("st-stat-providers").textContent = String((storageState.providers || []).length);
  const trackedBytes = cachedUploadHistory
    .filter((u) => u.status === "SUCCESS")
    .reduce((acc, u) => acc + Number(u.sizeBytes || 0), 0);
  if ($("st-stat-used")) $("st-stat-used").textContent = formatBytes(trackedBytes);
  if ($("st-stat-errors")) $("st-stat-errors").textContent = String(cachedErrorLogs.filter((e) => !e.resolved).length);
}

function renderStorageManager() {
  renderStorageStats();
  const listEl = $("storage-providers-list");
  if (listEl) {
    listEl.innerHTML = (storageState.providers || []).map((p) => {
      const pct = Math.min(100, Math.round((Number(p.usedBytes || 0) / Math.max(1, Number(p.capacityLimitBytes || 1))) * 100));
      const scopeTag = p.providerType === "PHP_HOSTING"
        ? `<span class="badge badge-cyan">${p.communityOnly ? "COMMUNITY ONLY" : "ALL BUCKETS"}</span>`
        : "";
      return `
        <div class="list-item">
          <div class="list-header">
            <div>
              <span class="badge ${p.role === "PRIMARY" ? "badge-green" : p.enabled ? "badge-cyan" : "badge-err"}">${escapeHtml(p.role)}</span>
              <span class="badge ${p.enabled ? "badge-green" : "badge-warn"}">${p.enabled ? "ENABLED" : "DISABLED"}</span>
              ${scopeTag}
              <strong style="margin-left:6px;">${escapeHtml(p.providerName)}</strong>
              <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(p.providerType)}${p.hostingVendor ? ` (${escapeHtml(p.hostingVendor)})` : ""} • ${escapeHtml(p.endpointUrl)} • Status: ${escapeHtml(p.lastStatus)}</div>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;">
              <button type="button" class="btn btn-outline btn-sm" data-prov-test="${escapeHtml(p.providerId)}">Test</button>
              <button type="button" class="btn btn-outline btn-sm" data-prov-role="PRIMARY" data-prov-id="${escapeHtml(p.providerId)}">Set Primary</button>
              <button type="button" class="btn btn-outline btn-sm" data-prov-role="BACKUP" data-prov-id="${escapeHtml(p.providerId)}">Set Backup</button>
              <button type="button" class="btn btn-outline btn-sm" data-prov-toggle="${escapeHtml(p.providerId)}">${p.enabled ? "Disable" : "Enable"}</button>
            </div>
          </div>
          <div class="progress-track" style="margin-top:8px;"><div class="progress-fill" style="width:${pct}%;"></div></div>
          <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Used ${formatBytes(p.usedBytes)} / ${formatBytes(p.capacityLimitBytes)} (${pct}%)</div>
        </div>
      `;
    }).join("");

    listEl.querySelectorAll("[data-prov-test]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const prov = storageState.providers.find((x) => x.providerId === btn.dataset.provTest);
        if (prov) testProviderConnection(prov);
      });
    });

    listEl.querySelectorAll("[data-prov-role]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const targetId = btn.dataset.provId;
        const nextRole = btn.dataset.provRole;
        storageState.providers = storageState.providers.map((p) => {
          if (p.providerId === targetId) return { ...p, role: nextRole, enabled: true };
          if (nextRole === "PRIMARY" && p.role === "PRIMARY") return { ...p, role: "BACKUP" };
          return p;
        });
        await persistStorageConfigToFirestore();
        showToast(`Provider updated to ${nextRole}.`);
      });
    });

    listEl.querySelectorAll("[data-prov-toggle]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const targetId = btn.dataset.provToggle;
        storageState.providers = storageState.providers.map((p) =>
          p.providerId === targetId ? { ...p, enabled: !p.enabled } : p
        );
        await persistStorageConfigToFirestore();
        showToast("Provider availability updated.");
      });
    });
  }

  const fmProv = $("fm-provider-select");
  if (fmProv) {
    const prev = fmProv.value;
    fmProv.innerHTML = (storageState.providers || [])
      .filter((p) => p.providerType === "SUPABASE_STORAGE" || p.providerType === "PHP_HOSTING")
      .map((p) => `<option value="${escapeHtml(p.providerId)}">${escapeHtml(p.providerName)}</option>`)
      .join("");
    if (prev) fmProv.value = prev;
  }
}

$("fm-refresh-btn")?.addEventListener("click", async () => {
  const filesEl = $("storage-files-list");
  if (!filesEl) return;
  const provId = $("fm-provider-select")?.value;
  const prov = (storageState.providers || []).find((p) => p.providerId === provId) || getPrimarySupabaseProvider();
  const bucket = $("fm-bucket-select")?.value || "community-photos";
  filesEl.innerHTML = `<div class="list-item">Loading files from ${escapeHtml(bucket)}...</div>`;
  try {
    if (prov.providerType === "PHP_HOSTING") {
      const res = await callHostingProxy({
        action: "list_files",
        providerId: prov.providerId,
        uploadApiUrl: prov.endpointUrl,
        endpointUrl: prov.endpointUrl,
        bucketName: bucket
      });
      const items = Array.isArray(res.files) ? res.files : [];
      if (!items.length) {
        filesEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No files uploaded to PHP folder "${escapeHtml(bucket)}" yet.</span></div>`;
        return;
      }
      filesEl.innerHTML = items.map((it) => `
        <div class="list-item">
          <div class="list-header">
            <div>
              <strong>${escapeHtml(it.name || it.storagePath || "file")}</strong>
              <div style="font-size:12px;color:var(--text-muted);">${formatBytes(it.sizeBytes || 0)} • ${escapeHtml(it.updatedAt || "")}</div>
            </div>
            <div style="display:flex;gap:8px;">
              ${it.publicUrl ? `<a class="btn btn-outline btn-sm" href="${escapeHtml(safeHref(it.publicUrl))}" target="_blank" rel="noopener">Open</a>` : ""}
              <button type="button" class="btn btn-danger btn-sm" data-php-del="${escapeHtml(it.storagePath || `${bucket}/${it.name}`)}">Delete</button>
            </div>
          </div>
        </div>
      `).join("");

      filesEl.querySelectorAll("[data-php-del]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const storagePath = btn.dataset.phpDel;
          if (!(await openConfirmModal("Delete Shared Hosting File", `Delete "${storagePath}" from ${prov.providerName}?`))) return;
          try {
            await callHostingProxy({
              action: "delete_file",
              providerId: prov.providerId,
              uploadApiUrl: prov.endpointUrl,
              endpointUrl: prov.endpointUrl,
              storagePath
            });
            showToast(`Deleted ${storagePath}.`);
            $("fm-refresh-btn")?.click();
          } catch (err) {
            showToast(`Delete failed: ${err.message}`, true);
          }
        });
      });
      return;
    }

    const items = await supabaseListObjects(prov, bucket);
    if (!items.length) {
      filesEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">Bucket "${escapeHtml(bucket)}" has no files yet.</span></div>`;
      return;
    }
    const endpoint = prov.endpointUrl;
    filesEl.innerHTML = items.map((it) => {
      const url = bucket === "verification-documents"
        ? `${endpoint}/storage/v1/object/authenticated/${bucket}/${it.name}`
        : `${endpoint}/storage/v1/object/public/${bucket}/${it.name}`;
      return `
        <div class="list-item">
          <div class="list-header">
            <div>
              <strong>${escapeHtml(it.name)}</strong>
              <div style="font-size:12px;color:var(--text-muted);">${formatBytes(it.metadata?.size || 0)} • ${escapeHtml(it.created_at || "")}</div>
            </div>
            <div style="display:flex;gap:8px;">
              <a class="btn btn-outline btn-sm" href="${escapeHtml(safeHref(url))}" target="_blank" rel="noopener">Open</a>
              <button type="button" class="btn btn-danger btn-sm" data-fm-del="${escapeHtml(it.name)}">Delete</button>
            </div>
          </div>
        </div>
      `;
    }).join("");

    filesEl.querySelectorAll("[data-fm-del]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const path = btn.dataset.fmDel;
        if (!(await openConfirmModal("Delete Cloud File", `Delete "${path}" from ${bucket}?`))) return;
        try {
          await supabaseDeleteObject(prov, bucket, path);
          showToast(`Deleted ${path}.`);
          $("fm-refresh-btn")?.click();
        } catch (err) {
          showToast(`Delete failed: ${err.message}`, true);
        }
      });
    });
  } catch (err) {
    filesEl.innerHTML = `<div class="list-item" style="color:var(--warning);">${escapeHtml(err.message)}</div>`;
  }
});

function renderUploadHistory() {
  const listEl = $("storage-upload-history-list");
  if (!listEl) return;
  if (!cachedUploadHistory.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No multi-cloud uploads recorded yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedUploadHistory.slice(0, 30).map((u) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge ${u.status === "SUCCESS" ? "badge-green" : "badge-err"}">${escapeHtml(u.status)}</span>
          ${u.failoverUsed ? `<span class="badge badge-warn">FAILOVER</span>` : ""}
          <strong style="margin-left:6px;">${escapeHtml(u.bucketName)}/${escapeHtml(u.objectPath)}</strong>
        </div>
        <span style="font-size:12px;color:var(--text-muted);">${escapeHtml(u.providerId)} • ${formatBytes(u.sizeBytes)}</span>
      </div>
    </div>
  `).join("");
}

function renderErrorLogs() {
  const listEl = $("storage-error-logs-list");
  if (!listEl) return;
  if (!cachedErrorLogs.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No storage failover or connection errors logged.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedErrorLogs.slice(0, 30).map((e) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge ${e.resolved ? "badge-green" : "badge-err"}">${e.resolved ? "RESOLVED" : "ALERT"}</span>
          <strong style="margin-left:6px;">${escapeHtml(e.providerId)}</strong>
          ${e.failoverTargetId ? ` &rarr; <span class="badge badge-cyan">Failover: ${escapeHtml(e.failoverTargetId)}</span>` : ""}
        </div>
        ${!e.resolved ? `<button type="button" class="btn btn-outline btn-sm" data-err-resolve="${escapeHtml(e.id)}">Resolve</button>` : ""}
      </div>
      <div style="font-size:12px;color:var(--warning);margin-top:4px;">${escapeHtml(e.errorMessage)}</div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-err-resolve]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await updateDoc(doc(db, "storage_error_logs", btn.dataset.errResolve), { resolved: true });
        showToast("Storage alert marked resolved.");
      } catch (err) {
        showToast(`Resolve failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// AI ASSISTANT MANAGEMENT (PHASE 2 — MULTI-PROVIDER FREE-FIRST ROUTING)
// =========================================================================

function isOpenRouterFreeModelName(model) {
  const m = String(model || "").trim().toLowerCase();
  return m === "openrouter/free" || m.endsWith(":free");
}

function isAiProfileEligible(p) {
  if (!p || !p.enabled || p.role === "DISABLED") return false;
  if (aiState.aiFreeOnlyMode) {
    if (!p.isFree) return false;
    if (p.providerType === "OPENROUTER" && !isOpenRouterFreeModelName(p.model)) return false;
    return true;
  }
  if (!p.isFree) {
    return Boolean(aiState.aiAllowPaidFallback && p.adminPaidApproved);
  }
  return true;
}

function aiRoleWeight(role) {
  switch (role) {
    case "PRIMARY": return 0;
    case "SECONDARY": return 1;
    case "BACKUP": return 2;
    default: return 3;
  }
}

function populateAiForm() {
  if ($("ai-enabled")) $("ai-enabled").checked = aiState.aiEnabled !== false;
  if ($("ai-show-nav")) $("ai-show-nav").checked = aiState.showAiNavItem !== false;
  if ($("ai-free-only-mode")) $("ai-free-only-mode").checked = aiState.aiFreeOnlyMode !== false;
  if ($("ai-allow-paid-fallback")) $("ai-allow-paid-fallback").checked = Boolean(aiState.aiAllowPaidFallback);
  if ($("ai-auto-failover")) $("ai-auto-failover").checked = aiState.aiAutoFailoverEnabled !== false;
  if ($("ai-provider")) $("ai-provider").value = aiState.aiProvider || "GEMINI";
  if ($("ai-model")) $("ai-model").value = aiState.aiModel || "gemini-2.5-flash";
  if ($("ai-endpoint-url")) $("ai-endpoint-url").value = aiState.aiEndpointUrl || "";
  if ($("ai-proxy-endpoint")) $("ai-proxy-endpoint").value = aiState.aiProxyEndpoint || DEFAULT_AI_PROXY_URL;
  if ($("ai-daily-limit")) $("ai-daily-limit").value = aiState.aiDailyLimit ?? 500;
  if ($("ai-per-user-limit")) $("ai-per-user-limit").value = aiState.aiPerUserLimit ?? 15;
  if ($("ai-appliances")) $("ai-appliances").value = (aiState.aiSupportedAppliances || []).join(", ");
  if ($("ai-brands-json")) $("ai-brands-json").value = aiState.aiBrandsModelsJson || DEFAULT_AI_BRANDS_JSON;
  if ($("ai-system-instructions")) $("ai-system-instructions").value = aiState.aiSystemInstructions || "";
  const langs = new Set(aiState.aiSupportedLanguages || ["en", "bn", "hi"]);
  if ($("ai-lang-en")) $("ai-lang-en").checked = langs.has("en");
  if ($("ai-lang-bn")) $("ai-lang-bn").checked = langs.has("bn");
  if ($("ai-lang-hi")) $("ai-lang-hi").checked = langs.has("hi");
  if ($("ai-key-provider")) $("ai-key-provider").value = aiState.aiProvider || "GEMINI";
}

function renderAiStats() {
  if ($("ai-stat-status")) {
    const modeLabel = aiState.aiFreeOnlyMode ? "FREE ONLY" : (aiState.aiAllowPaidFallback ? "PAID AUTH" : "FREE DEFAULT");
    $("ai-stat-status").textContent = aiState.aiEnabled ? `ENABLED (${modeLabel})` : "DISABLED";
    $("ai-stat-status").style.color = aiState.aiEnabled ? "var(--success)" : "var(--error)";
  }
  const activeOrdered = [...(aiState.aiProviders || [])]
    .filter((p) => isAiProfileEligible(p))
    .sort((a, b) => aiRoleWeight(a.role) - aiRoleWeight(b.role));
  if ($("ai-stat-provider")) {
    $("ai-stat-provider").textContent = activeOrdered[0]
      ? `${activeOrdered[0].providerType} (${activeOrdered.length})`
      : `${aiState.aiProvider || "GEMINI"} (0 ready)`;
  }
  if ($("ai-stat-limits")) $("ai-stat-limits").textContent = `${aiState.aiDailyLimit} / ${aiState.aiPerUserLimit}`;
  if ($("ai-stat-errors")) $("ai-stat-errors").textContent = String(cachedAiErrorLogs.filter((e) => !e.resolved).length);
}

function fillAiProviderFormFromPreset(presetKey, suggestedRole = "SECONDARY") {
  const preset = AI_PROVIDER_PRESETS[presetKey] || AI_PROVIDER_PRESETS.GEMINI;
  if ($("ai-prof-id")) $("ai-prof-id").value = "";
  if ($("ai-prof-type")) $("ai-prof-type").value = presetKey;
  if ($("ai-prof-label")) $("ai-prof-label").value = preset.label;
  if ($("ai-prof-role")) $("ai-prof-role").value = suggestedRole;
  if ($("ai-prof-model")) $("ai-prof-model").value = preset.model;
  if ($("ai-prof-endpoint")) $("ai-prof-endpoint").value = preset.endpointUrl;
  if ($("ai-prof-daily-limit")) $("ai-prof-daily-limit").value = preset.isFree ? 400 : 100;
  if ($("ai-prof-user-limit")) $("ai-prof-user-limit").value = 15;
  if ($("ai-prof-enabled")) $("ai-prof-enabled").checked = true;
  if ($("ai-prof-is-free")) $("ai-prof-is-free").checked = Boolean(preset.isFree);
  if ($("ai-prof-paid-approved")) $("ai-prof-paid-approved").checked = false;
  if ($("ai-prof-api-key")) $("ai-prof-api-key").value = "";
}

$("ai-preset-gemini-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("GEMINI", "PRIMARY"));
$("ai-preset-groq-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("GROQ", "SECONDARY"));
$("ai-preset-openrouter-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("OPENROUTER", "BACKUP"));
$("ai-preset-openai-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("OPENAI_COMPATIBLE", "BACKUP"));
$("ai-preset-custom-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("CUSTOM_PROXY", "BACKUP"));

$("ai-prof-type")?.addEventListener("change", () => {
  if ($("ai-prof-id")?.value) return; // keep values when editing an existing profile
  const selectedType = $("ai-prof-type")?.value || "GEMINI";
  const preset = AI_PROVIDER_PRESETS[selectedType] || AI_PROVIDER_PRESETS.GEMINI;
  if ($("ai-prof-label")) $("ai-prof-label").value = preset.label;
  if ($("ai-prof-model")) $("ai-prof-model").value = preset.model;
  if ($("ai-prof-endpoint")) $("ai-prof-endpoint").value = preset.endpointUrl;
  if ($("ai-prof-is-free")) $("ai-prof-is-free").checked = Boolean(preset.isFree);
});

$("ai-provider")?.addEventListener("change", () => {
  const selectedType = $("ai-provider")?.value || "GEMINI";
  const preset = AI_PROVIDER_PRESETS[selectedType];
  if (!preset) return;
  if ($("ai-model")) $("ai-model").value = preset.model;
  if ($("ai-endpoint-url")) $("ai-endpoint-url").value = preset.endpointUrl;
});

$("ai-prof-reset-btn")?.addEventListener("click", () => {
  fillAiProviderFormFromPreset("GROQ", "SECONDARY");
  setBanner("ai-providers-banner", "Profile form reset.", "info");
});

function buildCurrentAiConfigPayload(overrides = {}) {
  const brandsRaw = ($("ai-brands-json")?.value || aiState.aiBrandsModelsJson || DEFAULT_AI_BRANDS_JSON).trim();
  const appliances = ($("ai-appliances")?.value || (aiState.aiSupportedAppliances || []).join(","))
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 20);
  if (!appliances.length) appliances.push("Air Conditioner", "Refrigerator", "Washing Machine");

  const langs = ["en", "bn", "hi"].filter((code) => $(`ai-lang-${code}`)?.checked);
  if (!langs.length) langs.push("en");

  const proxyUrl = ($("ai-proxy-endpoint")?.value || aiState.aiProxyEndpoint || DEFAULT_AI_PROXY_URL).trim();
  const providersList = overrides.aiProviders || aiState.aiProviders || [defaultGeminiFreeProvider()];
  const orderedPrimary = [...providersList]
    .filter((p) => p.enabled && p.role !== "DISABLED")
    .sort((a, b) => aiRoleWeight(a.role) - aiRoleWeight(b.role))[0];

  return {
    configType: "AI",
    aiEnabled: Boolean($("ai-enabled")?.checked ?? aiState.aiEnabled),
    showAiNavItem: Boolean($("ai-show-nav")?.checked ?? aiState.showAiNavItem),
    aiFreeOnlyMode: Boolean($("ai-free-only-mode")?.checked ?? aiState.aiFreeOnlyMode),
    aiAllowPaidFallback: Boolean($("ai-allow-paid-fallback")?.checked ?? aiState.aiAllowPaidFallback),
    aiAutoFailoverEnabled: Boolean($("ai-auto-failover")?.checked ?? aiState.aiAutoFailoverEnabled),
    aiProvider: orderedPrimary?.providerType || $("ai-provider")?.value || aiState.aiProvider || "GEMINI",
    aiModel: (orderedPrimary?.model || $("ai-model")?.value || aiState.aiModel || "gemini-2.5-flash").trim().slice(0, 120),
    aiEndpointUrl: (orderedPrimary?.endpointUrl || $("ai-endpoint-url")?.value || aiState.aiEndpointUrl || "").trim().slice(0, 500),
    aiProxyEndpoint: (/^https:\/\//i.test(proxyUrl) ? proxyUrl : DEFAULT_AI_PROXY_URL).slice(0, 500),
    aiDailyLimit: Math.min(1000000, Math.max(0, Math.round(Number($("ai-daily-limit")?.value ?? aiState.aiDailyLimit ?? 500)))),
    aiPerUserLimit: Math.min(1000, Math.max(0, Math.round(Number($("ai-per-user-limit")?.value ?? aiState.aiPerUserLimit ?? 15)))),
    aiProvidersJson: sanitizeAiProvidersForFirestore(providersList),
    aiSupportedAppliances: appliances,
    aiBrandsModelsJson: brandsRaw.slice(0, 10000),
    aiSupportedLanguages: langs,
    aiSystemInstructions: ($("ai-system-instructions")?.value || aiState.aiSystemInstructions || "").trim().slice(0, 2000),
    updatedByUid: currentUser.uid,
    updatedAt: serverTimestamp()
  };
}

async function persistAiProvidersToFirestore(nextProviders, auditDetail) {
  aiState.aiProviders = nextProviders;
  aiState.aiProvidersJson = sanitizeAiProvidersForFirestore(nextProviders);
  const payload = buildCurrentAiConfigPayload({ aiProviders: nextProviders });
  await setDoc(doc(db, "app_settings", "ai_config"), payload, { merge: true });
  await writeAuditLog("UPDATE_AI_PROVIDERS", "app_settings", "ai_config", auditDetail);
  renderAiProvidersManager();
  renderAiStats();
}

function renderAiProvidersManager() {
  const listEl = $("ai-providers-list");
  const keyProvSel = $("ai-key-provider-id");
  const ordered = [...(aiState.aiProviders || [])].sort((a, b) => aiRoleWeight(a.role) - aiRoleWeight(b.role));

  if (keyProvSel) {
    const prev = keyProvSel.value;
    keyProvSel.innerHTML = `<option value="">Preset Default Key</option>` +
      ordered.map((p) => `<option value="${escapeHtml(p.providerId)}">${escapeHtml(p.label)} (${escapeHtml(p.providerId)})</option>`).join("");
    if (prev && ordered.some((p) => p.providerId === prev)) {
      keyProvSel.value = prev;
    }
  }

  if (!listEl) return;
  if (!ordered.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No AI provider profiles configured yet. Click a Free preset above to add Gemini, Groq, or OpenRouter.</span></div>`;
    return;
  }

  listEl.innerHTML = ordered.map((p) => {
    const eligible = isAiProfileEligible(p);
    const tierBadge = p.isFree
      ? (p.providerType === "OPENROUTER" && !isOpenRouterFreeModelName(p.model)
          ? `<span class="badge badge-warn">OPENROUTER NON-:FREE (BLOCKED IN FREE MODE)</span>`
          : `<span class="badge badge-green">FREE TIER</span>`)
      : (p.adminPaidApproved && aiState.aiAllowPaidFallback && !aiState.aiFreeOnlyMode
          ? `<span class="badge badge-warn">PAID (ADMIN AUTHORIZED)</span>`
          : `<span class="badge badge-err">PAID (BLOCKED)</span>`);
    const roleBadgeClass = p.role === "PRIMARY" ? "badge-green" : p.role === "SECONDARY" ? "badge-cyan" : p.role === "BACKUP" ? "badge-warn" : "badge-err";
    return `
      <div class="list-item">
        <div class="list-header">
          <div>
            <span class="badge ${roleBadgeClass}">${escapeHtml(p.role)}</span>
            <span class="badge ${p.enabled ? "badge-green" : "badge-err"}">${p.enabled ? "ENABLED" : "DISABLED"}</span>
            ${tierBadge}
            <span class="badge ${eligible ? "badge-cyan" : "badge-warn"}">${eligible ? "ACTIVE IN CHAIN" : "SKIPPED"}</span>
            <strong style="margin-left:6px;">${escapeHtml(p.label)}</strong>
            <div style="font-size:12px;color:var(--text-muted);margin-top:4px;">
              ${escapeHtml(p.providerType)} • Model: <code>${escapeHtml(p.model)}</code> • Daily Cap: ${Number(p.dailyLimit || 0)} • User Cap: ${Number(p.perUserLimit || 0)}
            </div>
            <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">
              Endpoint: ${escapeHtml(p.endpointUrl || "Default")} • ID: <code>${escapeHtml(p.providerId)}</code>
            </div>
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-test="${escapeHtml(p.providerId)}">Test</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-key="${escapeHtml(p.providerId)}">Vault Key</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-edit="${escapeHtml(p.providerId)}">Edit</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-role="PRIMARY" data-ai-prof-id="${escapeHtml(p.providerId)}">Primary</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-role="SECONDARY" data-ai-prof-id="${escapeHtml(p.providerId)}">Secondary</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-role="BACKUP" data-ai-prof-id="${escapeHtml(p.providerId)}">Backup</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-toggle="${escapeHtml(p.providerId)}">${p.enabled ? "Disable" : "Enable"}</button>
            <button type="button" class="btn btn-danger btn-sm" data-ai-prof-del="${escapeHtml(p.providerId)}">Remove</button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  listEl.querySelectorAll("[data-ai-prof-test]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const prov = (aiState.aiProviders || []).find((x) => x.providerId === btn.dataset.aiProfTest);
      if (!prov) return;
      setBanner("ai-providers-banner", `Testing admin connection to ${prov.label} (${prov.model})...`, "info");
      try {
        const res = await callAiAssistantEndpoint({
          action: "test_connection",
          providerIdOverride: prov.providerId,
          providerOverride: prov.providerType,
          modelOverride: prov.model,
          endpointOverride: prov.endpointUrl
        });
        setBanner("ai-providers-banner", `Connected to ${res.provider} (${res.model})! Sample length: ${res.sampleLength} chars.`, "success");
        showToast(`${prov.label} verified.`);
      } catch (err) {
        setBanner("ai-providers-banner", `Test failed for ${prov.label}: ${err.message}`, "error");
      }
    });
  });

  listEl.querySelectorAll("[data-ai-prof-key]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const prov = (aiState.aiProviders || []).find((x) => x.providerId === btn.dataset.aiProfKey);
      if (!prov) return;
      if ($("ai-key-provider")) $("ai-key-provider").value = prov.providerType;
      if ($("ai-key-provider-id")) $("ai-key-provider-id").value = prov.providerId;
      $("ai-api-key")?.focus();
      setBanner("ai-key-banner", `Ready to store server-only API key for "${prov.label}" (${prov.providerId}).`, "info");
    });
  });

  listEl.querySelectorAll("[data-ai-prof-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const prov = (aiState.aiProviders || []).find((x) => x.providerId === btn.dataset.aiProfEdit);
      if (!prov) return;
      if ($("ai-prof-id")) $("ai-prof-id").value = prov.providerId;
      if ($("ai-prof-type")) $("ai-prof-type").value = prov.providerType;
      if ($("ai-prof-label")) $("ai-prof-label").value = prov.label;
      if ($("ai-prof-role")) $("ai-prof-role").value = prov.role;
      if ($("ai-prof-model")) $("ai-prof-model").value = prov.model;
      if ($("ai-prof-endpoint")) $("ai-prof-endpoint").value = prov.endpointUrl;
      if ($("ai-prof-daily-limit")) $("ai-prof-daily-limit").value = prov.dailyLimit;
      if ($("ai-prof-user-limit")) $("ai-prof-user-limit").value = prov.perUserLimit;
      if ($("ai-prof-enabled")) $("ai-prof-enabled").checked = prov.enabled !== false;
      if ($("ai-prof-is-free")) $("ai-prof-is-free").checked = Boolean(prov.isFree);
      if ($("ai-prof-paid-approved")) $("ai-prof-paid-approved").checked = Boolean(prov.adminPaidApproved);
      if ($("ai-prof-api-key")) $("ai-prof-api-key").value = "";
      $("ai-prof-label")?.focus();
      setBanner("ai-providers-banner", `Editing "${prov.label}".`, "info");
    });
  });

  listEl.querySelectorAll("[data-ai-prof-role]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const targetId = btn.dataset.aiProfId;
      const nextRole = btn.dataset.aiProfRole;
      const nextProviders = (aiState.aiProviders || []).map((p) => {
        if (p.providerId === targetId) return { ...p, role: nextRole, enabled: true };
        if (nextRole === "PRIMARY" && p.role === "PRIMARY") return { ...p, role: "SECONDARY" };
        if (nextRole === "SECONDARY" && p.role === "SECONDARY") return { ...p, role: "BACKUP" };
        return p;
      });
      try {
        await persistAiProvidersToFirestore(nextProviders, `Set ${targetId} role=${nextRole}`);
        showToast(`AI provider role updated to ${nextRole}.`);
      } catch (err) {
        setBanner("ai-providers-banner", `Role update failed: ${err.message}`, "error");
      }
    });
  });

  listEl.querySelectorAll("[data-ai-prof-toggle]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const targetId = btn.dataset.aiProfToggle;
      const nextProviders = (aiState.aiProviders || []).map((p) =>
        p.providerId === targetId ? { ...p, enabled: !p.enabled } : p
      );
      try {
        await persistAiProvidersToFirestore(nextProviders, `Toggled ${targetId}`);
        showToast("AI provider status updated.");
      } catch (err) {
        setBanner("ai-providers-banner", `Status update failed: ${err.message}`, "error");
      }
    });
  });

  listEl.querySelectorAll("[data-ai-prof-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const targetId = btn.dataset.aiProfDel;
      if ((aiState.aiProviders || []).length <= 1) {
        setBanner("ai-providers-banner", "Keep at least one AI provider profile configured (you can disable it instead).", "warning");
        return;
      }
      if (!(await openConfirmModal("Remove AI Provider Profile", `Remove provider profile "${targetId}"?`))) return;
      const nextProviders = (aiState.aiProviders || []).filter((p) => p.providerId !== targetId);
      try {
        await persistAiProvidersToFirestore(nextProviders, `Removed ${targetId}`);
        showToast("AI provider profile removed.");
      } catch (err) {
        setBanner("ai-providers-banner", `Remove failed: ${err.message}`, "error");
      }
    });
  });
}

$("ai-provider-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const existingId = ($("ai-prof-id")?.value || "").trim();
  const providerType = $("ai-prof-type")?.value || "GEMINI";
  const label = ($("ai-prof-label")?.value || "").trim();
  const role = $("ai-prof-role")?.value || "SECONDARY";
  const model = ($("ai-prof-model")?.value || "").trim();
  const endpointUrl = ($("ai-prof-endpoint")?.value || "").trim();
  const isFree = Boolean($("ai-prof-is-free")?.checked);
  const adminPaidApproved = Boolean($("ai-prof-paid-approved")?.checked);
  const enabled = Boolean($("ai-prof-enabled")?.checked);
  const dailyLimit = Math.min(1000000, Math.max(0, Math.round(Number($("ai-prof-daily-limit")?.value ?? 400))));
  const perUserLimit = Math.min(1000, Math.max(0, Math.round(Number($("ai-prof-user-limit")?.value ?? 15))));
  const optionalApiKey = ($("ai-prof-api-key")?.value || "").trim();

  if (!label || !model || !/^https:\/\//i.test(endpointUrl)) {
    setBanner("ai-providers-banner", "Display Label, Model ID, and a valid HTTPS Endpoint URL are required.", "error");
    return;
  }
  if (!isFree && adminPaidApproved && $("ai-free-only-mode")?.checked) {
    setBanner("ai-providers-banner", "Paid usage will remain blocked while Free Only Mode is enabled above.", "warning");
  }
  if (providerType === "OPENROUTER" && isFree && !isOpenRouterFreeModelName(model)) {
    setBanner("ai-providers-banner", "OpenRouter models in Free Only Mode must end with ':free' (or use 'openrouter/free').", "error");
    return;
  }

  const profileId = existingId || `${providerType.toLowerCase()}_${Date.now().toString(36)}`;
  const profile = normalizeAiProviderProfile({
    providerId: profileId,
    label,
    providerType,
    role,
    enabled,
    isFree,
    adminPaidApproved,
    endpointUrl,
    model,
    dailyLimit,
    perUserLimit
  });

  let nextProviders = [...(aiState.aiProviders || [])];
  if (role === "PRIMARY") {
    nextProviders = nextProviders.map((p) => (p.providerId !== profileId && p.role === "PRIMARY" ? { ...p, role: "SECONDARY" } : p));
  }
  const idx = nextProviders.findIndex((p) => p.providerId === profileId);
  if (idx >= 0) {
    nextProviders[idx] = profile;
  } else {
    nextProviders.push(profile);
  }

  try {
    if (optionalApiKey) {
      if (optionalApiKey.length < 10) {
        setBanner("ai-providers-banner", "Optional API key must be at least 10 characters.", "error");
        return;
      }
      await callAiAssistantEndpoint({
        action: "save_ai_key",
        providerOverride: providerType,
        providerIdOverride: profileId,
        apiKey: optionalApiKey
      });
      if ($("ai-prof-api-key")) $("ai-prof-api-key").value = "";
    }
    await persistAiProvidersToFirestore(nextProviders, `${idx >= 0 ? "Updated" : "Added"} ${profileId} (${providerType}, ${role}, free=${isFree})`);
    if ($("ai-prof-id")) $("ai-prof-id").value = "";
    setBanner("ai-providers-banner", `Saved AI provider "${label}" (${role}) and published configuration.${optionalApiKey ? " API key stored securely on backend." : ""}`, "success");
    showToast(`Saved ${label}.`);
  } catch (err) {
    setBanner("ai-providers-banner", `Failed to save AI provider profile: ${err.message}`, "error");
  }
});

$("ai-config-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const brandsRaw = ($("ai-brands-json")?.value || DEFAULT_AI_BRANDS_JSON).trim();
  try {
    const parsed = JSON.parse(brandsRaw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("Brands JSON must be an object mapping appliance names to brand arrays.");
    }
  } catch (err) {
    setBanner("ai-config-banner", `Invalid Brands JSON: ${err.message}`, "error");
    return;
  }

  const appliances = ($("ai-appliances")?.value || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 20);
  if (!appliances.length) {
    setBanner("ai-config-banner", "Provide at least one supported appliance.", "error");
    return;
  }

  const freeOnly = Boolean($("ai-free-only-mode")?.checked);
  const allowPaidFallback = Boolean($("ai-allow-paid-fallback")?.checked);
  if (freeOnly && allowPaidFallback) {
    setBanner("ai-config-banner", "Paid fallback remains disabled while Free Only Mode is checked. Uncheck Free Only Mode to authorize paid fallback.", "warning");
  }

  const payload = buildCurrentAiConfigPayload();
  try {
    await setDoc(doc(db, "app_settings", "ai_config"), payload, { merge: true });
    await writeAuditLog(
      "UPDATE_AI_CONFIG",
      "app_settings",
      "ai_config",
      `enabled=${payload.aiEnabled}, freeOnly=${payload.aiFreeOnlyMode}, paidAuth=${payload.aiAllowPaidFallback}, failover=${payload.aiAutoFailoverEnabled}, provider=${payload.aiProvider}`
    );
    setBanner("ai-config-banner", "AI Assistant configuration published to app_settings/ai_config. Android reflects changes live.", "success");
    showToast("AI settings published.");
  } catch (err) {
    setBanner("ai-config-banner", `Failed to publish AI settings: ${err.message}`, "error");
  }
});

async function callAiAssistantEndpoint(payload) {
  if (!currentUser) throw new Error("Sign in as Super Admin first.");
  const url = String($("ai-proxy-endpoint")?.value || aiState.aiProxyEndpoint || DEFAULT_AI_PROXY_URL).trim();
  const idToken = await currentUser.getIdToken();
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${idToken}`
    },
    body: JSON.stringify(payload)
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok || data.ok === false) {
    throw new Error(data.message || `AI Endpoint HTTP ${resp.status}`);
  }
  return data;
}

$("ai-secret-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const providerOverride = $("ai-key-provider")?.value || "GEMINI";
  const providerIdOverride = ($("ai-key-provider-id")?.value || "").trim();
  const apiKey = ($("ai-api-key")?.value || "").trim();
  if (apiKey.length < 10) {
    setBanner("ai-key-banner", "Enter a valid AI API key (at least 10 characters).", "error");
    return;
  }
  try {
    await callAiAssistantEndpoint({
      action: "save_ai_key",
      providerOverride,
      providerIdOverride: providerIdOverride || undefined,
      apiKey
    });
    if ($("ai-api-key")) $("ai-api-key").value = "";
    setBanner("ai-key-banner", `API key for ${providerOverride}${providerIdOverride ? ` (${providerIdOverride})` : ""} stored securely on backend (never sent to Firestore or APK).`, "success");
    showToast("AI key stored securely.");
  } catch (err) {
    setBanner("ai-key-banner", `Failed to save AI key: ${err.message}`, "error");
  }
});

$("ai-test-btn")?.addEventListener("click", async () => {
  const providerIdOverride = ($("ai-key-provider-id")?.value || "").trim();
  const matched = providerIdOverride
    ? (aiState.aiProviders || []).find((p) => p.providerId === providerIdOverride)
    : undefined;
  const providerOverride = matched?.providerType || $("ai-key-provider")?.value || $("ai-provider")?.value || "GEMINI";
  const modelOverride = matched?.model || ($("ai-model")?.value || AI_PROVIDER_PRESETS[providerOverride]?.model || "gemini-2.5-flash").trim();
  const endpointOverride = matched?.endpointUrl || ($("ai-endpoint-url")?.value || AI_PROVIDER_PRESETS[providerOverride]?.endpointUrl || "").trim();
  const tempApiKey = ($("ai-api-key")?.value || "").trim();
  setBanner("ai-key-banner", `Testing admin connection to ${providerOverride} (${modelOverride})...`, "info");
  try {
    const res = await callAiAssistantEndpoint({
      action: "test_connection",
      providerIdOverride: providerIdOverride || undefined,
      providerOverride,
      modelOverride,
      endpointOverride,
      tempApiKey: tempApiKey || undefined
    });
    setBanner("ai-key-banner", `Connected cleanly to ${res.provider} (${res.model})! Sample response length: ${res.sampleLength} chars.`, "success");
    showToast("AI connection verified.");
  } catch (err) {
    setBanner("ai-key-banner", `AI connection test failed: ${err.message}`, "error");
  }
});

function renderAiErrorLogs() {
  const listEl = $("ai-error-logs-list");
  if (!listEl) return;
  if (!cachedAiErrorLogs.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No AI diagnostic errors recorded.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedAiErrorLogs.slice(0, 30).map((e) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge ${e.resolved ? "badge-green" : "badge-err"}">${e.resolved ? "RESOLVED" : "ERROR"}</span>
          <strong style="margin-left:6px;">${escapeHtml(e.provider || "AI")} ${e.modelName ? `(${escapeHtml(e.modelName)})` : ""}</strong>
          <span style="font-size:11px;color:var(--text-muted);margin-left:6px;">${escapeHtml(formatTs(e.createdAt))}</span>
        </div>
        ${!e.resolved ? `<button type="button" class="btn btn-outline btn-sm" data-ai-err-resolve="${escapeHtml(e.id)}">Resolve</button>` : ""}
      </div>
      <div style="font-size:12px;color:var(--warning);margin-top:4px;">${escapeHtml(e.errorMessage || "Unknown error")}</div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-ai-err-resolve]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await updateDoc(doc(db, "ai_error_logs", btn.dataset.aiErrResolve), { resolved: true });
        showToast("AI error marked resolved.");
      } catch (err) {
        showToast(`Resolve failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// BILLING, PDF INVOICE & MANUAL PAYMENT REMINDERS CONFIG (PHASE 2)
// =========================================================================

function populateBillingForm() {
  if ($("bill-invoice-enabled")) $("bill-invoice-enabled").checked = billingState.invoiceEnabled !== false;
  if ($("bill-whatsapp-enabled")) $("bill-whatsapp-enabled").checked = billingState.whatsappReminderEnabled !== false;
  if ($("bill-sms-enabled")) $("bill-sms-enabled").checked = billingState.smsReminderEnabled !== false;
  if ($("bill-business-title")) $("bill-business-title").value = billingState.invoiceBusinessTitle || "Repair Pro Service Invoice";
  if ($("bill-terms-note")) $("bill-terms-note").value = billingState.invoiceTermsNote || "";

  let templates = { ...DEFAULT_BILLING_TEMPLATES };
  try {
    const parsed = JSON.parse(billingState.reminderTemplatesJson || "{}");
    templates = { ...templates, ...parsed };
  } catch {
    // keep defaults
  }
  if ($("bill-tpl-en")) $("bill-tpl-en").value = templates.en || DEFAULT_BILLING_TEMPLATES.en;
  if ($("bill-tpl-bn")) $("bill-tpl-bn").value = templates.bn || DEFAULT_BILLING_TEMPLATES.bn;
  if ($("bill-tpl-hi")) $("bill-tpl-hi").value = templates.hi || DEFAULT_BILLING_TEMPLATES.hi;

  const langs = new Set(billingState.billingSupportedLanguages || ["en", "bn", "hi"]);
  if ($("bill-lang-en")) $("bill-lang-en").checked = langs.has("en");
  if ($("bill-lang-bn")) $("bill-lang-bn").checked = langs.has("bn");
  if ($("bill-lang-hi")) $("bill-lang-hi").checked = langs.has("hi");
}

$("billing-config-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const langs = ["en", "bn", "hi"].filter((code) => $(`bill-lang-${code}`)?.checked);
  if (!langs.length) langs.push("en");

  const templatesJson = JSON.stringify({
    en: ($("bill-tpl-en")?.value || DEFAULT_BILLING_TEMPLATES.en).trim().slice(0, 1200),
    bn: ($("bill-tpl-bn")?.value || DEFAULT_BILLING_TEMPLATES.bn).trim().slice(0, 1200),
    hi: ($("bill-tpl-hi")?.value || DEFAULT_BILLING_TEMPLATES.hi).trim().slice(0, 1200)
  }).slice(0, 8000);

  const payload = {
    configType: "BILLING",
    invoiceEnabled: Boolean($("bill-invoice-enabled")?.checked),
    whatsappReminderEnabled: Boolean($("bill-whatsapp-enabled")?.checked),
    smsReminderEnabled: Boolean($("bill-sms-enabled")?.checked),
    invoiceBusinessTitle: ($("bill-business-title")?.value || "Repair Pro Service Invoice").trim().slice(0, 120),
    invoiceTermsNote: ($("bill-terms-note")?.value || "").trim().slice(0, 600),
    reminderTemplatesJson: templatesJson,
    billingSupportedLanguages: langs,
    updatedByUid: currentUser.uid,
    updatedAt: serverTimestamp()
  };

  try {
    await setDoc(doc(db, "app_settings", "billing_config"), payload, { merge: true });
    await writeAuditLog("UPDATE_BILLING_CONFIG", "app_settings", "billing_config", `invoices=${payload.invoiceEnabled}, whatsapp=${payload.whatsappReminderEnabled}, sms=${payload.smsReminderEnabled}`);
    setBanner("billing-config-banner", "Billing, PDF Invoice & Payment Reminder settings published to app_settings/billing_config.", "success");
    showToast("Billing settings published.");
  } catch (err) {
    setBanner("billing-config-banner", `Failed to save billing config: ${err.message}`, "error");
  }
});

// =========================================================================
// REPORTS, ADMOB, ONLINE SETTINGS, ROLES & AUDIT LOGS
// =========================================================================

function renderReportsList() {
  const listEl = $("reports-list");
  if (!listEl) return;
  if (!cachedReports.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No problem reports submitted yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedReports.map((r) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <strong>${escapeHtml(r.brandName)} ${r.errorCode ? `(${escapeHtml(r.errorCode)})` : ""}</strong>
          <span class="badge ${r.status === "PUBLISHED" ? "badge-green" : r.status === "PENDING" ? "badge-warn" : "badge-cyan"}">${escapeHtml(r.status)}</span>
        </div>
        <div style="display:flex;gap:6px;">
          <button type="button" class="btn btn-outline btn-sm" data-rep-status="REVIEWED" data-rep-id="${escapeHtml(r.id)}">Review</button>
          <button type="button" class="btn btn-success btn-sm" data-rep-status="PUBLISHED" data-rep-id="${escapeHtml(r.id)}">Mark Published</button>
        </div>
      </div>
      <div style="font-size:13px;color:var(--text-muted);">${escapeHtml(r.description)}</div>
    </div>
  `).join("");
  listEl.querySelectorAll("[data-rep-status]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await updateDoc(doc(db, "problem_reports", btn.dataset.repId), {
          status: btn.dataset.repStatus,
          updatedAt: serverTimestamp()
        });
        showToast(`Report updated to ${btn.dataset.repStatus}.`);
      } catch (err) {
        showToast(`Update failed: ${err.message}`, true);
      }
    });
  });
}

function populateAdMobForm(d) {
  if ($("ad-global")) $("ad-global").checked = d.adsGlobalEnabled !== false;
  if ($("ad-kill")) $("ad-kill").checked = Boolean(d.emergencyKillSwitch);
  if ($("ad-banner")) $("ad-banner").checked = d.bannerEnabled !== false;
  if ($("ad-interstitial")) $("ad-interstitial").checked = d.interstitialEnabled !== false;
  if ($("ad-rewarded")) $("ad-rewarded").checked = Boolean(d.rewardedEnabled);
  if ($("ad-native")) $("ad-native").checked = Boolean(d.nativeEnabled);
  if ($("ad-test")) $("ad-test").checked = d.testMode !== false;
  if ($("ad-ac")) $("ad-ac").checked = d.acAdsEnabled !== false;
  if ($("ad-fridge")) $("ad-fridge").checked = d.fridgeAdsEnabled !== false;
  if ($("ad-washer")) $("ad-washer").checked = d.washerAdsEnabled !== false;
  if ($("ad-cooldown")) $("ad-cooldown").value = d.interstitialCooldownMin || 3;
  if ($("ad-cap")) $("ad-cap").value = d.sessionFrequencyCap || 6;
  if ($("ad-android-app")) $("ad-android-app").value = d.androidAppId || "";
  if ($("ad-android-banner")) $("ad-android-banner").value = d.androidBannerId || "";
  if ($("ad-android-interstitial")) $("ad-android-interstitial").value = d.androidInterstitialId || "";
  if ($("ad-android-rewarded")) $("ad-android-rewarded").value = d.androidRewardedId || "";
  if ($("ad-ios-app")) $("ad-ios-app").value = d.iosAppId || "";
  if ($("ad-ios-banner")) $("ad-ios-banner").value = d.iosBannerId || "";
}

$("admob-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  try {
    await setDoc(doc(db, "app_settings", "admob_config"), {
      configType: "ADMOB",
      adsGlobalEnabled: $("ad-global").checked,
      emergencyKillSwitch: $("ad-kill").checked,
      bannerEnabled: $("ad-banner").checked,
      interstitialEnabled: $("ad-interstitial").checked,
      rewardedEnabled: $("ad-rewarded").checked,
      nativeEnabled: $("ad-native").checked,
      testMode: $("ad-test").checked,
      acAdsEnabled: $("ad-ac").checked,
      fridgeAdsEnabled: $("ad-fridge").checked,
      washerAdsEnabled: $("ad-washer").checked,
      interstitialCooldownMin: Math.min(60, Math.max(1, Number($("ad-cooldown").value || 3))),
      sessionFrequencyCap: Math.min(50, Math.max(1, Number($("ad-cap").value || 6))),
      androidAppId: $("ad-android-app").value.trim(),
      androidBannerId: $("ad-android-banner").value.trim(),
      androidInterstitialId: $("ad-android-interstitial").value.trim(),
      androidRewardedId: $("ad-android-rewarded").value.trim(),
      iosAppId: $("ad-ios-app").value.trim(),
      iosBannerId: $("ad-ios-banner").value.trim(),
      updatedByUid: currentUser.uid,
      updatedAt: serverTimestamp()
    }, { merge: true });
    await writeAuditLog("UPDATE_ADMOB_CONFIG", "app_settings", "admob_config", "Updated AdMob controls");
    showToast("AdMob configuration published.");
  } catch (err) {
    showToast(`AdMob update failed: ${err.message}`, true);
  }
});

function populateGlobalSettingsForm(d) {
  if ($("set-announcement")) $("set-announcement").value = d.announcement || "";
  if ($("set-maintenance")) $("set-maintenance").value = d.maintenanceNotice || "";
  if ($("set-min-version")) $("set-min-version").value = d.minSupportedVersion || "2.0.0";
}

$("global-settings-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  try {
    await setDoc(doc(db, "app_settings", "global_config"), {
      configType: "GLOBAL",
      announcement: $("set-announcement").value.trim().slice(0, 400),
      maintenanceNotice: $("set-maintenance").value.trim().slice(0, 400),
      minSupportedVersion: $("set-min-version").value.trim().slice(0, 32) || "2.0.0",
      updatedByUid: currentUser.uid,
      updatedAt: serverTimestamp()
    }, { merge: true });
    await writeAuditLog("UPDATE_GLOBAL_CONFIG", "app_settings", "global_config", "Updated online app settings");
    showToast("Online app settings published.");
  } catch (err) {
    showToast(`Save failed: ${err.message}`, true);
  }
});

function exportJsonBackup() {
  const payload = {
    exportedAt: new Date().toISOString(),
    catalogEntries: cachedCatalog,
    technicians: cachedTechnicians,
    technicalDocuments: cachedDocuments,
    storageConfig: storageState,
    aiConfig: aiState,
    billingConfig: billingState
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `repairpro-backup-${Date.now()}.json`;
  a.click();
}

$("quick-export-btn")?.addEventListener("click", exportJsonBackup);
$("download-backup-btn")?.addEventListener("click", exportJsonBackup);

$("register-self-admin-btn")?.addEventListener("click", async () => {
  if (!currentUser) return;
  try {
    await setDoc(doc(db, "admins", currentUser.uid), {
      userId: currentUser.uid,
      role: "SUPER_ADMIN",
      createdAt: serverTimestamp()
    });
    showToast("Your UID is now registered in admins/.");
  } catch (err) {
    showToast(`Failed: ${err.message}`, true);
  }
});

$("role-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const uid = $("role-uid").value.trim();
  const role = $("role-name").value;
  if (!uid) return;
  try {
    await setDoc(doc(db, "admins", uid), {
      userId: uid,
      role,
      createdAt: serverTimestamp()
    });
    await writeAuditLog("GRANT_ADMIN_ROLE", "admins", uid, `Role=${role}`);
    $("role-form").reset();
    showToast(`Granted ${role} to ${uid}.`);
  } catch (err) {
    showToast(`Role update failed: ${err.message}`, true);
  }
});

function renderRolesList(roles) {
  const listEl = $("roles-list");
  if (!listEl) return;
  listEl.innerHTML = roles.length
    ? roles.map((r) => `
        <div class="list-item">
          <div class="list-header">
            <div><strong>${escapeHtml(r.userId)}</strong> <span class="badge badge-cyan">${escapeHtml(r.role)}</span></div>
            <button type="button" class="btn btn-danger btn-sm" data-role-del="${escapeHtml(r.id)}">Revoke</button>
          </div>
        </div>
      `).join("")
    : `<div class="list-item"><span style="color:var(--text-muted);">No extra admin entries yet.</span></div>`;

  listEl.querySelectorAll("[data-role-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await deleteDoc(doc(db, "admins", btn.dataset.roleDel));
        showToast("Admin role revoked.");
      } catch (err) {
        showToast(`Revoke failed: ${err.message}`, true);
      }
    });
  });
}

function renderAuditLogs() {
  const listEl = $("audit-list");
  if (!listEl) return;
  listEl.innerHTML = cachedAuditLogs.length
    ? cachedAuditLogs.slice(0, 50).map((l) => `
        <div class="list-item">
          <div class="list-header">
            <strong>${escapeHtml(l.action)}</strong>
            <span style="font-size:11px;color:var(--text-muted);">${escapeHtml(formatTs(l.createdAt))}</span>
          </div>
          <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(l.adminEmail)} • ${escapeHtml(l.targetType)}/${escapeHtml(l.targetId)} — ${escapeHtml(l.details)}</div>
        </div>
      `).join("")
    : `<div class="list-item"><span style="color:var(--text-muted);">No audit logs yet.</span></div>`;
}
