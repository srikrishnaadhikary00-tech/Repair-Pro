import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import {
  browserLocalPersistence,
  getAuth,
  getRedirectResult,
  GoogleAuthProvider,
  onAuthStateChanged,
  setPersistence,
  signInWithPopup,
  signInWithRedirect,
  signOut
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import {
  BOOTSTRAP_SUPER_ADMIN_EMAIL,
  DEFAULT_ADMIN_USER_MANAGEMENT_URL,
  DEFAULT_AI_PROXY_URL,
  DEFAULT_FCM_ENDPOINT,
  DEFAULT_HOSTING_PROXY_URL,
  DEFAULT_STORAGE_ROUTING,
  DEFAULT_SUPABASE_BUCKETS,
  FREE_TIER_STORAGE_LIMIT_BYTES,
  LEGACY_FIRESTORE_DATABASE_ID,
  SUPABASE_PROJECT_REF,
  SUPABASE_URL,
  firebaseConfig
} from "./firebase-config.js";
import {
  fileToBase64,
  getSupabaseAnonKey,
  getSupabaseUrl,
  mapAdminRoleRow,
  mapAiErrorRow,
  mapAnnouncementRow,
  mapAuditLogRow,
  mapCatalogRow,
  mapCommunityPostRow,
  mapCommunityReportRow,
  mapCommunityRestrictionRow,
  mapDocumentRow,
  mapProblemReportRow,
  mapPushHistoryRow,
  mapStorageErrorRow,
  mapStorageProviderRow,
  mapTechRow,
  mapUploadHistoryRow,
  mapUserRow,
  mapVerificationRow,
  sbDelete,
  sbGetSetting,
  sbSaveSetting,
  sbSelect,
  sbUpdate,
  sbUpsert,
  setSupabaseAnonKey,
  setSupabaseUrl,
  syncStorageProvidersTable
} from "./supabase-client.js";
import {
  callCpanelDirect,
  defaultMigrationConfig,
  evaluateMigrationThresholds,
  executeVerifiedCleanup,
  fetchCpanelUsageMetrics,
  fetchDiscoveryFromExternalHosts,
  fetchSchedulerStatus,
  fetchSupabaseUsageMetrics,
  getPartialCloudFailures,
  loadDiscoveryCache,
  multiCloudDbDelete,
  multiCloudDbQuery,
  multiCloudDbUpdate,
  multiCloudDbUpsert,
  normalizeMigrationConfig,
  openPrivateCredentialDocument,
  restoreFromBackupManifest,
  retryFailedMigrationItems,
  runCloudMigration,
  saveDiscoveryCache,
  syncDiscoveryManifestToExternalHosts,
  triggerServerSideMigrationTick,
  validateCpanelHostingReadiness
} from "./cloud-migration.js";

// Initialize Firebase App & Persistent Auth Session (Auth & FCM ONLY)
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
setPersistence(auth, browserLocalPersistence).catch((err) => {
  console.warn("Persistence setup note:", err?.message || err);
});

// Global defensive submit handler: never allow accidental browser GET/POST page reload
document.addEventListener("submit", (event) => {
  event.preventDefault();
});

const $ = (id) => document.getElementById(id);

const SECTION_TITLES = {
  dashboard: "Dashboard Overview",
  appliances: "Appliances & Multilingual Categories",
  catalog: "Error Codes & Guides",
  technicians: "Technician Management",
  verification: "Technician Verification Queue",
  community: "Technician Community Moderation",
  documents: "PDF Manuals & Circuit Diagrams",
  announcements: "Push Notifications & Alerts",
  storage: "Storage & Web Hosting Manager",
  ai: "Repair Pro AI",
  billing: "Billing, Invoices & Payment Reminders",
  reports: "User Problem Reports",
  admob: "Google AdMob Remote Controls",
  settings: "Online-Only App Settings",
  users: "Users & Account Moderation",
  roles: "Admin Roles & Audit Logs"
};

let currentUser = null;
let currentIsBootstrapAdmin = false;
let pollTimer = null;

let cachedCatalog = [];
let cachedReports = [];
let cachedAuditLogs = [];
let cachedTechnicians = [];
let cachedVerifications = [];
let cachedCommunityPosts = [];
let cachedCommunityReports = [];
let cachedCommunityRestrictions = [];
let cachedDocuments = [];
let cachedAnnouncements = [];
let cachedPushHistory = [];
let cachedUsers = [];
let cachedUploadHistory = [];
let cachedErrorLogs = [];
let cachedAiErrorLogs = [];
let cachedAdminRoles = [];

let pendingTechPhotoFile = null;
let removeTechPhotoRequested = false;

const DEFAULT_AI_BRANDS_JSON = JSON.stringify({
  "Air Conditioner": ["LG", "Voltas", "Daikin", "Blue Star", "Samsung", "Lloyd", "Hitachi", "Carrier", "Godrej", "Haier", "Whirlpool"],
  "Refrigerator": ["LG", "Samsung", "Whirlpool", "Godrej", "Haier", "Bosch", "Electrolux", "Voltas Beko"],
  "Washing Machine": ["LG", "Samsung", "Whirlpool", "IFB", "Bosch", "Haier", "Godrej", "Voltas Beko"]
}, null, 2);

const DEFAULT_BILLING_TEMPLATES = {
  en: "Hello {customerName}, your Repair Pro service invoice #{invoiceNumber} for {appliance} has a pending balance of {remainingBalance}. Total: {totalBill}, Paid: {amountReceived}. Due date: {dueDate}. Thank you!",
  bn: "নমস্কার {customerName}, আপনার {appliance} সার্ভিস ইনভয়েস #{invoiceNumber}-এর বকেয়া পরিমাণ {remainingBalance}। মোট বিল: {totalBill}, জমা: {amountReceived}। শেষ তারিখ: {dueDate}। ধন্যবাদ!",
  hi: "नमस्ते {customerName}, आपके {appliance} सर्विस इनवॉइस #{invoiceNumber} की बकाया राशि {remainingBalance} है। कुल बिल: {totalBill}, प्राप्त: {amountReceived}। अंतिम तिथि: {dueDate}। धन्यवाद!"
};

let storageState = {
  autoFailoverEnabled: true,
  fcmBackendUrl: DEFAULT_FCM_ENDPOINT,
  hostingProxyUrl: DEFAULT_HOSTING_PROXY_URL,
  compressionMaxDim: 1440,
  compressionQuality: 82,
  compressionMaxSizeKb: 4500,
  duplicateCheckEnabled: true,
  categoryMappings: { ...DEFAULT_STORAGE_ROUTING },
  providers: [defaultSupabasePrimaryProvider()]
};

let migrationConfigState = defaultMigrationConfig();
let cachedMigrationRuns = [];
let cachedBackupManifests = [];
let latestSupabaseMetrics = null;
let latestCpanelStats = null;
let autoMigrationRunning = false;

const AI_PROVIDER_PRESETS = {
  GEMINI: {
    label: "Google Gemini (Free Tier)",
    endpointUrl: "https://generativelanguage.googleapis.com",
    model: "gemini-2.5-flash",
    isFree: true
  },
  GROQ: {
    label: "Groq (Free Tier)",
    endpointUrl: "https://api.groq.com/openai/v1/chat/completions",
    model: "llama-3.3-70b-versatile",
    isFree: true
  },
  OPENROUTER: {
    label: "OpenRouter (Free Models)",
    endpointUrl: "https://openrouter.ai/api/v1/chat/completions",
    model: "meta-llama/llama-3.3-70b-instruct:free",
    isFree: true
  },
  OPENAI_COMPATIBLE: {
    label: "OpenAI-Compatible",
    endpointUrl: "https://api.openai.com/v1/chat/completions",
    model: "gpt-4o-mini",
    isFree: false
  },
  CUSTOM_PROXY: {
    label: "Custom HTTPS Endpoint",
    endpointUrl: "",
    model: "custom-model",
    isFree: true
  }
};

function defaultGeminiFreeProvider() {
  return {
    providerId: "gemini_free_primary",
    label: "Google Gemini (Free Tier)",
    providerType: "GEMINI",
    role: "PRIMARY",
    enabled: true,
    isFree: true,
    adminPaidApproved: false,
    endpointUrl: AI_PROVIDER_PRESETS.GEMINI.endpointUrl,
    model: AI_PROVIDER_PRESETS.GEMINI.model,
    dailyLimit: 500,
    perUserLimit: 15
  };
}

function normalizeAiProviderProfile(raw, idx = 0) {
  const validTypes = ["GEMINI", "GROQ", "OPENROUTER", "OPENAI_COMPATIBLE", "CUSTOM_PROXY"];
  const rawType = String(raw?.providerType || "GEMINI").trim().toUpperCase();
  const providerType = validTypes.includes(rawType) ? rawType : "GEMINI";
  const preset = AI_PROVIDER_PRESETS[providerType] || AI_PROVIDER_PRESETS.GEMINI;
  const validRoles = ["PRIMARY", "SECONDARY", "BACKUP", "DISABLED"];
  const rawRole = String(raw?.role || "BACKUP").trim().toUpperCase();
  const role = validRoles.includes(rawRole) ? rawRole : "BACKUP";
  const providerId = String(raw?.providerId || `ai_${providerType.toLowerCase()}_${idx}`)
    .replace(/[^a-zA-Z0-9_-]/g, "_")
    .slice(0, 64);

  return {
    providerId: providerId || `ai_prov_${idx}`,
    label: String(raw?.label || preset.label).trim().slice(0, 80),
    providerType,
    role,
    enabled: raw?.enabled !== false,
    isFree: raw?.isFree !== undefined ? Boolean(raw.isFree) : Boolean(preset.isFree),
    adminPaidApproved: Boolean(raw?.adminPaidApproved),
    endpointUrl: String(raw?.endpointUrl || preset.endpointUrl).trim().slice(0, 500),
    model: String(raw?.model || preset.model).trim().slice(0, 120),
    dailyLimit: Math.min(1000000, Math.max(0, Math.round(Number(raw?.dailyLimit ?? 500)))),
    perUserLimit: Math.min(1000, Math.max(0, Math.round(Number(raw?.perUserLimit ?? 15))))
  };
}

function normalizeAiProvidersList(rawJson, fallbackType = "GEMINI", fallbackModel = "gemini-2.5-flash", fallbackEndpoint = "") {
  if (typeof rawJson === "string" && rawJson.trim()) {
    try {
      const arr = JSON.parse(rawJson);
      if (Array.isArray(arr) && arr.length) {
        return arr.map((item, idx) => normalizeAiProviderProfile(item, idx));
      }
    } catch {
      // fall through
    }
  }
  if (fallbackType && fallbackType !== "GEMINI") {
    return [
      normalizeAiProviderProfile({
        providerId: `legacy_${fallbackType.toLowerCase()}`,
        label: AI_PROVIDER_PRESETS[fallbackType]?.label || fallbackType,
        providerType: fallbackType,
        role: "PRIMARY",
        enabled: true,
        isFree: fallbackType === "GROQ" || fallbackType === "OPENROUTER",
        adminPaidApproved: false,
        endpointUrl: fallbackEndpoint || AI_PROVIDER_PRESETS[fallbackType]?.endpointUrl || "",
        model: fallbackModel || AI_PROVIDER_PRESETS[fallbackType]?.model || ""
      }, 0)
    ];
  }
  return [defaultGeminiFreeProvider()];
}

function sanitizeAiProvidersForFirestore(providers) {
  return JSON.stringify((providers || []).map((p, idx) => normalizeAiProviderProfile(p, idx)));
}

let aiState = {
  aiEnabled: true,
  showAiNavItem: true,
  aiFreeOnlyMode: true,
  aiAllowPaidFallback: false,
  aiAutoFailoverEnabled: true,
  aiProvider: "GEMINI",
  aiModel: "gemini-2.5-flash",
  aiEndpointUrl: "",
  aiProxyEndpoint: DEFAULT_AI_PROXY_URL,
  aiDailyLimit: 500,
  aiPerUserLimit: 15,
  aiProviders: [defaultGeminiFreeProvider()],
  aiProvidersJson: JSON.stringify([defaultGeminiFreeProvider()]),
  aiSupportedAppliances: ["Air Conditioner", "Refrigerator", "Washing Machine"],
  aiBrandsModelsJson: DEFAULT_AI_BRANDS_JSON,
  aiSupportedLanguages: ["en", "bn", "hi"],
  aiSystemInstructions: ""
};

let billingState = {
  invoiceEnabled: true,
  whatsappReminderEnabled: true,
  smsReminderEnabled: true,
  invoiceBusinessTitle: "Repair Pro Service Invoice",
  invoiceTermsNote: "Thank you for choosing our appliance service. Retain this invoice for service reference.",
  reminderTemplatesJson: JSON.stringify(DEFAULT_BILLING_TEMPLATES),
  billingSupportedLanguages: ["en", "bn", "hi"]
};

function defaultSupabasePrimaryProvider() {
  return {
    providerId: "supabase_primary",
    providerName: `Supabase Free Plan (${SUPABASE_PROJECT_REF})`,
    providerType: "SUPABASE_STORAGE",
    endpointUrl: getSupabaseUrl() || SUPABASE_URL,
    publicAnonKey: getSupabaseAnonKey(),
    proxyUploadUrl: "",
    hostingVendor: "",
    publicMediaBaseUrl: "",
    communityOnly: false,
    supportsStorage: true,
    supportsDatabase: false,
    dbEnabled: false,
    dbEngine: "MYSQL",
    role: "PRIMARY",
    enabled: true,
    capacityLimitBytes: FREE_TIER_STORAGE_LIMIT_BYTES,
    usedBytes: 0,
    lastStatus: "CONFIGURED",
    buckets: { ...DEFAULT_SUPABASE_BUCKETS }
  };
}

function defaultFirebaseLegacyProvider() {
  return {
    providerId: "firebase_legacy_backup",
    providerName: "Firebase Storage (Legacy Compatibility)",
    providerType: "FIREBASE_LEGACY",
    endpointUrl: `https://${firebaseConfig.storageBucket}`,
    publicAnonKey: "",
    proxyUploadUrl: "",
    role: "BACKUP",
    enabled: false,
    capacityLimitBytes: FREE_TIER_STORAGE_LIMIT_BYTES,
    usedBytes: 0,
    lastStatus: "STANDBY",
    buckets: { ...DEFAULT_SUPABASE_BUCKETS }
  };
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function safeHref(url) {
  const s = String(url || "").trim();
  return /^https?:\/\//i.test(s) ? s : "#";
}

function formatBytes(bytes) {
  const n = Number(bytes || 0);
  if (!Number.isFinite(n) || n <= 0) return "0 B";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(2)} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function slugId(prefix = "id") {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}_${Date.now()}_${rand}`.replace(/[^a-zA-Z0-9_-]/g, "_");
}

function showToast(message, isError = false) {
  const el = $("toast");
  if (!el) return;
  el.textContent = String(message || "");
  el.style.borderColor = isError ? "rgba(255, 77, 106, 0.7)" : "rgba(0, 216, 255, 0.55)";
  el.classList.remove("hidden");
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => el.classList.add("hidden"), 4200);
}

function setBanner(elId, message, variant = "info") {
  const el = $(elId);
  if (!el) return;
  el.classList.remove(
    "hidden",
    "info", "success", "warning", "error",
    "alert-success", "alert-warning", "alert-error", "alert-info"
  );
  el.classList.add(variant, `alert-${variant}`);
  el.textContent = String(message || "");
}

function openConfirmModal(title, message, okLabel = "Delete Permanently") {
  return new Promise((resolve) => {
    const modal = $("confirm-modal");
    const titleEl = $("confirm-modal-title");
    const msgEl = $("confirm-modal-message");
    const okBtn = $("confirm-modal-ok");
    const cancelBtn = $("confirm-modal-cancel");
    if (!modal || !okBtn || !cancelBtn) {
      resolve(window.confirm(`${title}\n\n${message}`));
      return;
    }
    titleEl.textContent = title;
    msgEl.textContent = message;
    okBtn.textContent = okLabel;
    modal.classList.remove("hidden");

    const cleanup = (result) => {
      modal.classList.add("hidden");
      okBtn.onclick = null;
      cancelBtn.onclick = null;
      modal.onclick = null;
      resolve(result);
    };
    okBtn.onclick = () => cleanup(true);
    cancelBtn.onclick = () => cleanup(false);
    modal.onclick = (ev) => {
      if (ev.target === modal) cleanup(false);
    };
  });
}

function formatTs(ts) {
  if (!ts) return "Just now";
  try {
    if (typeof ts.toDate === "function") return ts.toDate().toLocaleString();
    if (ts instanceof Date) return ts.toLocaleString();
    return new Date(ts).toLocaleString();
  } catch {
    return "Just now";
  }
}

function normalizeProvider(raw) {
  const base = raw?.providerType === "FIREBASE_LEGACY"
    ? defaultFirebaseLegacyProvider()
    : defaultSupabasePrimaryProvider();
  const buckets = { ...DEFAULT_SUPABASE_BUCKETS, ...(raw?.buckets || {}) };
  const pType = String(raw?.providerType || base.providerType);
  const rawAnon = String(raw?.publicAnonKey || "").trim();
  const effectiveAnon = pType === "SUPABASE_STORAGE" ? (rawAnon || getSupabaseAnonKey()) : "";
  return {
    providerId: String(raw?.providerId || slugId("prov")).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 64),
    providerName: String(raw?.providerName || base.providerName).slice(0, 80),
    providerType: pType,
    endpointUrl: String(raw?.endpointUrl || base.endpointUrl).trim().replace(/\/+$/, ""),
    publicAnonKey: effectiveAnon,
    proxyUploadUrl: String(raw?.proxyUploadUrl || "").trim(),
    hostingVendor: String(raw?.hostingVendor || "").trim().slice(0, 60),
    publicMediaBaseUrl: String(raw?.publicMediaBaseUrl || "").trim().replace(/\/+$/, "").slice(0, 400),
    communityOnly: raw?.communityOnly !== undefined ? Boolean(raw.communityOnly) : pType === "PHP_HOSTING",
    supportsStorage: raw?.supportsStorage !== undefined ? Boolean(raw.supportsStorage) : true,
    supportsDatabase: Boolean(raw?.supportsDatabase),
    dbEnabled: Boolean(raw?.dbEnabled),
    dbEngine: ["MYSQL", "SQLITE"].includes(String(raw?.dbEngine || "").toUpperCase()) ? String(raw.dbEngine).toUpperCase() : "MYSQL",
    role: ["PRIMARY", "BACKUP", "DISABLED"].includes(raw?.role) ? raw.role : "BACKUP",
    enabled: raw?.enabled !== false,
    capacityLimitBytes: Math.max(1024 * 1024, Number(raw?.capacityLimitBytes || FREE_TIER_STORAGE_LIMIT_BYTES)),
    usedBytes: Math.max(0, Number(raw?.usedBytes || 0)),
    lastStatus: String(raw?.lastStatus || "READY").slice(0, 40),
    buckets
  };
}

function sanitizeProvidersForStorage(providers) {
  return (providers || []).map((p) => ({
    providerId: p.providerId,
    providerName: p.providerName,
    providerType: p.providerType,
    endpointUrl: p.endpointUrl,
    // Public anon key is a client-safe Supabase key; private PHP/S3/R2/service_role keys are NEVER stored in public DB.
    publicAnonKey: p.providerType === "SUPABASE_STORAGE" ? (p.publicAnonKey || getSupabaseAnonKey() || "") : "",
    proxyUploadUrl: p.proxyUploadUrl || "",
    hostingVendor: p.hostingVendor || "",
    publicMediaBaseUrl: p.publicMediaBaseUrl || "",
    communityOnly: Boolean(p.communityOnly),
    supportsStorage: p.supportsStorage !== false,
    supportsDatabase: Boolean(p.supportsDatabase),
    dbEnabled: Boolean(p.dbEnabled),
    dbEngine: p.dbEngine || "MYSQL",
    role: p.role,
    enabled: Boolean(p.enabled),
    capacityLimitBytes: Number(p.capacityLimitBytes || FREE_TIER_STORAGE_LIMIT_BYTES),
    usedBytes: Number(p.usedBytes || 0),
    lastStatus: p.lastStatus || "READY",
    buckets: p.buckets || { ...DEFAULT_SUPABASE_BUCKETS }
  }));
}

function getBucketNameForCategory(provider, bucketKey) {
  const b = provider?.buckets || DEFAULT_SUPABASE_BUCKETS;
  return b[bucketKey] || DEFAULT_SUPABASE_BUCKETS[bucketKey] || "community-photos";
}

function isProviderEligibleForBucket(provider, bucketKey) {
  if (!provider || !provider.enabled || provider.role === "DISABLED") return false;
  if (provider.supportsStorage === false) return false;
  if (provider.providerType === "PHP_HOSTING" && provider.communityOnly && bucketKey && !["community", "technicians"].includes(bucketKey)) {
    return false;
  }
  return true;
}

function getOrderedActiveProviders(bucketKey = "") {
  const enabled = (storageState.providers || []).filter((p) => isProviderEligibleForBucket(p, bucketKey));
  const primary = enabled.filter((p) => p.role === "PRIMARY");
  const backups = enabled.filter((p) => p.role !== "PRIMARY");
  const mappedId = bucketKey ? storageState.categoryMappings?.[bucketKey] : "";
  const mappedProv = mappedId ? enabled.find((p) => p.providerId === mappedId) : null;
  const chain = [];
  if (mappedProv) chain.push(mappedProv);
  for (const p of [...primary, ...backups]) {
    if (!chain.some((x) => x.providerId === p.providerId)) chain.push(p);
  }
  if (!storageState.autoFailoverEnabled) {
    return chain.slice(0, 1);
  }
  return chain;
}

// =========================================================================
// NAVIGATION, MOBILE DRAWER & SECTION SWITCHING
// =========================================================================

function closeMobileMoreDrawer() {
  $("mobile-more-sheet")?.classList.add("hidden");
  $("mobile-more-backdrop")?.classList.add("hidden");
  $("mobile-more-btn")?.setAttribute("aria-expanded", "false");
}

function openMobileMoreDrawer() {
  $("mobile-more-sheet")?.classList.remove("hidden");
  $("mobile-more-backdrop")?.classList.remove("hidden");
  $("mobile-more-btn")?.setAttribute("aria-expanded", "true");
}

function activateSection(section) {
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.section === section);
  });
  const bottomTabs = new Set(["dashboard", "users", "community", "technicians"]);
  document.querySelectorAll(".mobile-nav-btn[data-section]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.section === section);
  });
  if ($("mobile-more-btn")) {
    $("mobile-more-btn").classList.toggle("active", !bottomTabs.has(section));
  }
  document.querySelectorAll(".mobile-more-item").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.section === section);
  });
  document.querySelectorAll(".admin-section").forEach((sec) => {
    sec.classList.toggle("hidden", sec.id !== `sec-${section}`);
  });
  if ($("section-title")) {
    $("section-title").textContent = SECTION_TITLES[section] || "Super Admin Console";
  }
  closeMobileMoreDrawer();
}

document.querySelectorAll(".nav-btn").forEach((btn) => {
  btn.addEventListener("click", () => activateSection(btn.dataset.section));
});

document.querySelectorAll(".mobile-nav-btn[data-section]").forEach((btn) => {
  btn.addEventListener("click", () => activateSection(btn.dataset.section));
});

$("mobile-more-btn")?.addEventListener("click", () => {
  const isHidden = $("mobile-more-sheet")?.classList.contains("hidden");
  if (isHidden) openMobileMoreDrawer();
  else closeMobileMoreDrawer();
});
$("mobile-more-close-btn")?.addEventListener("click", closeMobileMoreDrawer);
$("mobile-more-backdrop")?.addEventListener("click", closeMobileMoreDrawer);
document.querySelectorAll(".mobile-more-item[data-section]").forEach((btn) => {
  btn.addEventListener("click", () => activateSection(btn.dataset.section));
});

$("quick-new-entry-btn")?.addEventListener("click", () => {
  activateSection("catalog");
  $("cat-title-en")?.focus();
});

$("quick-push-btn")?.addEventListener("click", () => {
  activateSection("announcements");
  $("push-title")?.focus();
});

// =========================================================================
// FIREBASE AUTHENTICATION & SUPABASE ADMIN RBAC (PERSISTENT)
// =========================================================================

if ($("db-id-preview")) {
  $("db-id-preview").textContent = LEGACY_FIRESTORE_DATABASE_ID;
}

if ($("login-supabase-anon-key")) {
  const savedAnon = getSupabaseAnonKey();
  if (savedAnon) $("login-supabase-anon-key").value = savedAnon;
  $("login-supabase-anon-key").addEventListener("change", (e) => {
    setSupabaseAnonKey(e.target.value);
  });
}

function saveLoginAnonKeyIfEntered() {
  const val = ($("login-supabase-anon-key")?.value || "").trim();
  if (val) setSupabaseAnonKey(val);
}

getRedirectResult(auth).catch((err) => {
  if (err && $("login-error")) {
    $("login-error").textContent = err.message || "Google Redirect sign-in failed.";
    $("login-error").classList.remove("hidden");
  }
});

$("google-login-btn")?.addEventListener("click", async () => {
  $("login-error")?.classList.add("hidden");
  saveLoginAnonKeyIfEntered();
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: "select_account" });
    await signInWithPopup(auth, provider);
  } catch (err) {
    if ($("login-error")) {
      $("login-error").textContent = `${err.message || "Popup sign-in failed."} (Try Redirect button for Safari/iOS).`;
      $("login-error").classList.remove("hidden");
    }
  }
});

$("google-redirect-btn")?.addEventListener("click", async () => {
  $("login-error")?.classList.add("hidden");
  saveLoginAnonKeyIfEntered();
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: "select_account" });
    await signInWithRedirect(auth, provider);
  } catch (err) {
    if ($("login-error")) {
      $("login-error").textContent = err.message || "Redirect sign-in failed.";
      $("login-error").classList.remove("hidden");
    }
  }
});

async function explicitSignOut() {
  clearSubscriptions();
  closeMobileMoreDrawer();
  await signOut(auth);
}

$("signout-btn")?.addEventListener("click", explicitSignOut);
$("denied-signout-btn")?.addEventListener("click", explicitSignOut);
$("mobile-more-signout-btn")?.addEventListener("click", explicitSignOut);

function clearSubscriptions() {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
}

onAuthStateChanged(auth, async (user) => {
  clearSubscriptions();
  currentUser = user;

  if (!user) {
    $("login-view")?.classList.remove("hidden");
    $("denied-view")?.classList.add("hidden");
    $("admin-shell")?.classList.add("hidden");
    return;
  }

  let hasAdminAccess = false;
  let isBootstrap = false;
  try {
    isBootstrap = Boolean(
      user.emailVerified &&
      String(user.email || "").toLowerCase() === BOOTSTRAP_SUPER_ADMIN_EMAIL.toLowerCase()
    );
    if (isBootstrap) {
      hasAdminAccess = true;
    } else if (getSupabaseAnonKey()) {
      try {
        const rows = await sbSelect(
          "admin_roles",
          `user_id=eq.${encodeURIComponent(user.uid)}&select=user_id,role&limit=1`,
          user
        );
        hasAdminAccess = Array.isArray(rows) && rows.length > 0;
      } catch (supaRoleErr) {
        const cachedCfg = loadDiscoveryCache();
        const extUrls = (cachedCfg?.providers || [])
          .filter((p) => p.enabled && p.providerType === "PHP_HOSTING" && p.supportsDatabase && p.dbEnabled && /^https:\/\//i.test(p.endpointUrl || ""))
          .map((p) => p.endpointUrl);
        for (const ep of extUrls) {
          try {
            const res = await callCpanelDirect(ep, "db_query", {
              table: "admin_roles",
              filters: { user_id: user.uid },
              limit: 1
            }, user);
            if (Array.isArray(res.rows) && res.rows.length > 0) {
              hasAdminAccess = true;
              break;
            }
          } catch { /* ignore */ }
        }
        if (!hasAdminAccess) throw supaRoleErr;
      }
    }
  } catch (err) {
    console.warn("Admin verification check failed:", err?.message || err);
    hasAdminAccess = isBootstrap;
  }

  currentIsBootstrapAdmin = isBootstrap;
  if (!hasAdminAccess) {
    $("login-view")?.classList.add("hidden");
    $("admin-shell")?.classList.add("hidden");
    $("denied-view")?.classList.remove("hidden");
    if ($("denied-message")) {
      $("denied-message").textContent = `Signed in as ${user.email || user.uid}, which is not authorized in Supabase admin_roles/${user.uid}.`;
    }
    return;
  }

  $("login-view")?.classList.add("hidden");
  $("denied-view")?.classList.add("hidden");
  $("admin-shell")?.classList.remove("hidden");
  if ($("admin-email-badge")) {
    $("admin-email-badge").textContent = `${isBootstrap ? "Bootstrap Super Admin" : "Admin"} • ${user.email || user.uid}`;
  }
  $("roles-manager-card")?.classList.toggle("hidden", !isBootstrap);
  subscribeAllStreams();
});

async function writeAuditLog(action, targetType, targetId, details, result = "SUCCESS") {
  if (!currentUser || !getSupabaseAnonKey()) return;
  try {
    const logId = slugId("log");
    const normalizedResult = result === "FAILED" ? "FAILED" : "SUCCESS";
    await sbUpsert("audit_logs", {
      log_id: logId,
      admin_uid: currentUser.uid,
      admin_email: String(currentUser.email || "admin@repairpro").slice(0, 160),
      action: String(action).slice(0, 100),
      target_type: String(targetType).slice(0, 64),
      target_id: String(targetId).slice(0, 128),
      details: String(details || "Updated via Web Super Admin").slice(0, 500),
      result: normalizedResult
    }, "log_id", currentUser);
  } catch (err) {
    console.warn("Audit log write skipped:", err?.message || err);
  }
}

// =========================================================================
// SUPABASE POSTGRES DATA SYNC & POLLING STREAMS
// =========================================================================

function applyStorageConfigPayload(data = {}, providerRows = []) {
  let parsedProviders = [];
  if (Array.isArray(data.providers) && data.providers.length) {
    parsedProviders = data.providers;
  } else {
    try {
      parsedProviders = JSON.parse(data.providersJson || "[]");
    } catch {
      parsedProviders = [];
    }
  }
  const mergedMap = new Map();
  const mappedTableProviders = Array.isArray(providerRows) ? providerRows.map(mapStorageProviderRow) : [];
  for (const p of mappedTableProviders) mergedMap.set(p.providerId, normalizeProvider(p));
  for (const p of parsedProviders) {
    const norm = normalizeProvider(p);
    const existing = mergedMap.get(norm.providerId);
    mergedMap.set(norm.providerId, existing ? { ...existing, ...norm } : norm);
  }
  const normalized = mergedMap.size > 0
    ? Array.from(mergedMap.values())
    : [defaultSupabasePrimaryProvider()];

  const supa = normalized.find((p) => p.providerType === "SUPABASE_STORAGE");
  if (supa?.publicAnonKey && !getSupabaseAnonKey()) {
    setSupabaseAnonKey(supa.publicAnonKey);
  }

  const rawFcm = String(data.fcmBackendUrl || "").trim();
  const effectiveFcm = (!rawFcm || /\/send-fcm-v1$/i.test(rawFcm)) ? DEFAULT_FCM_ENDPOINT : rawFcm;
  const rawProxy = String(data.hostingProxyUrl || "").trim();
  const effectiveProxy = /^https:\/\//i.test(rawProxy) ? rawProxy : DEFAULT_HOSTING_PROXY_URL;
  const rawMappings = (data.categoryMappings && typeof data.categoryMappings === "object")
    ? data.categoryMappings
    : (mappedTableProviders.find((p) => p.providerId === "supabase_primary")?.categoryMappings || {});

  storageState = {
    autoFailoverEnabled: data.autoFailoverEnabled !== false,
    fcmBackendUrl: effectiveFcm,
    hostingProxyUrl: effectiveProxy,
    compressionMaxDim: Math.min(4096, Math.max(480, Number(data.compressionMaxDim || 1440))),
    compressionQuality: Math.min(100, Math.max(40, Number(data.compressionQuality || 82))),
    compressionMaxSizeKb: Math.min(5120, Math.max(100, Number(data.compressionMaxSizeKb || 4500))),
    duplicateCheckEnabled: data.duplicateCheckEnabled !== false,
    categoryMappings: { ...DEFAULT_STORAGE_ROUTING, ...rawMappings },
    providers: normalized
  };
  syncStorageFormsFromState();
  renderStorageManager();
  renderCategoryRoutingSelects();
  renderDashboardStats();
}

function applyAiConfigPayload(d = {}) {
  const validAiProviders = ["GEMINI", "GROQ", "OPENROUTER", "OPENAI_COMPATIBLE", "CUSTOM_PROXY"];
  const aiProvider = validAiProviders.includes(d.aiProvider) ? d.aiProvider : "GEMINI";
  const aiModel = String(d.aiModel || AI_PROVIDER_PRESETS[aiProvider]?.model || "gemini-2.5-flash");
  const aiEndpointUrl = String(d.aiEndpointUrl || "");
  const aiProviders = normalizeAiProvidersList(d.aiProvidersJson, aiProvider, aiModel, aiEndpointUrl);
  aiState = {
    aiEnabled: d.aiEnabled !== false,
    showAiNavItem: d.showAiNavItem !== false,
    aiFreeOnlyMode: d.aiFreeOnlyMode !== undefined ? Boolean(d.aiFreeOnlyMode) : true,
    aiAllowPaidFallback: Boolean(d.aiAllowPaidFallback),
    aiAutoFailoverEnabled: d.aiAutoFailoverEnabled !== undefined ? Boolean(d.aiAutoFailoverEnabled) : true,
    aiProvider,
    aiModel,
    aiEndpointUrl,
    aiProxyEndpoint: /^https:\/\//i.test(String(d.aiProxyEndpoint || "")) ? String(d.aiProxyEndpoint) : DEFAULT_AI_PROXY_URL,
    aiDailyLimit: Math.max(0, Number(d.aiDailyLimit ?? 500)),
    aiPerUserLimit: Math.max(0, Number(d.aiPerUserLimit ?? 15)),
    aiProviders,
    aiProvidersJson: sanitizeAiProvidersForFirestore(aiProviders),
    aiSupportedAppliances: Array.isArray(d.aiSupportedAppliances) && d.aiSupportedAppliances.length
      ? d.aiSupportedAppliances
      : ["Air Conditioner", "Refrigerator", "Washing Machine"],
    aiBrandsModelsJson: String(d.aiBrandsModelsJson || DEFAULT_AI_BRANDS_JSON),
    aiSupportedLanguages: Array.isArray(d.aiSupportedLanguages) && d.aiSupportedLanguages.length
      ? d.aiSupportedLanguages
      : ["en", "bn", "hi"],
    aiSystemInstructions: String(d.aiSystemInstructions || "")
  };
  populateAiForm();
  renderAiProvidersManager();
  renderAiStats();
}

function applyBillingConfigPayload(d = {}) {
  billingState = {
    invoiceEnabled: d.invoiceEnabled !== false,
    whatsappReminderEnabled: d.whatsappReminderEnabled !== false,
    smsReminderEnabled: d.smsReminderEnabled !== false,
    invoiceBusinessTitle: String(d.invoiceBusinessTitle || "Repair Pro Service Invoice"),
    invoiceTermsNote: String(d.invoiceTermsNote || billingState.invoiceTermsNote),
    reminderTemplatesJson: String(d.reminderTemplatesJson || JSON.stringify(DEFAULT_BILLING_TEMPLATES)),
    billingSupportedLanguages: Array.isArray(d.billingSupportedLanguages) && d.billingSupportedLanguages.length
      ? d.billingSupportedLanguages
      : ["en", "bn", "hi"]
  };
  populateBillingForm();
}

async function refreshTable(name) {
  if (!currentUser) return;
  try {
    switch (name) {
      case "repair_catalog_entries": {
        const rows = await multiCloudDbQuery({
          table: "repair_catalog_entries",
          cpanelTable: "catalog_entries",
          categoryKey: "community",
          supabaseQuery: "select=*&order=updated_at.desc&limit=500",
          orderBy: "updated_at",
          pkFields: ["id"],
          currentUser,
          storageState
        });
        cachedCatalog = rows.map(mapCatalogRow);
        renderDashboardStats();
        renderCatalogList();
        renderAppliancesGrid();
        break;
      }
      case "technicians": {
        const rows = await multiCloudDbQuery({
          table: "technicians",
          categoryKey: "technicians",
          supabaseQuery: "select=*&order=updated_at.desc&limit=400",
          orderBy: "updated_at",
          pkFields: ["technician_id", "id"],
          currentUser,
          storageState
        });
        cachedTechnicians = rows.map(mapTechRow);
        renderDashboardStats();
        renderTechniciansSection();
        break;
      }
      case "technician_verification_requests": {
        const rows = await multiCloudDbQuery({
          table: "technician_verification_requests",
          categoryKey: "verification",
          supabaseQuery: "select=*&order=updated_at.desc&limit=300",
          orderBy: "updated_at",
          pkFields: ["user_id", "id"],
          currentUser,
          storageState
        });
        cachedVerifications = rows.map(mapVerificationRow);
        renderDashboardStats();
        renderVerificationSection();
        break;
      }
      case "community_posts": {
        const rows = await multiCloudDbQuery({
          table: "community_posts",
          categoryKey: "community",
          supabaseQuery: "select=*&order=created_at.desc&limit=400",
          orderBy: "created_at",
          pkFields: ["post_id", "id"],
          currentUser,
          storageState
        });
        cachedCommunityPosts = rows.map(mapCommunityPostRow);
        renderDashboardStats();
        renderCommunitySection();
        break;
      }
      case "community_reports": {
        const rows = await multiCloudDbQuery({
          table: "community_reports",
          categoryKey: "community",
          supabaseQuery: "select=*&order=created_at.desc&limit=200",
          orderBy: "created_at",
          pkFields: ["report_id", "id"],
          currentUser,
          storageState
        });
        cachedCommunityReports = rows.map(mapCommunityReportRow);
        renderCommunitySection();
        break;
      }
      case "community_user_restrictions": {
        const rows = await multiCloudDbQuery({
          table: "community_user_restrictions",
          categoryKey: "community",
          supabaseQuery: "select=*&order=created_at.desc&limit=200",
          orderBy: "created_at",
          pkFields: ["user_id", "id"],
          currentUser,
          storageState
        });
        cachedCommunityRestrictions = rows.map(mapCommunityRestrictionRow);
        renderCommunitySection();
        break;
      }
      case "technical_documents": {
        const rows = await multiCloudDbQuery({
          table: "technical_documents",
          categoryKey: "pdfs",
          supabaseQuery: "select=*&order=updated_at.desc&limit=400",
          orderBy: "updated_at",
          pkFields: ["doc_id", "id"],
          currentUser,
          storageState
        });
        cachedDocuments = rows.map(mapDocumentRow);
        renderDashboardStats();
        renderDocumentsList();
        break;
      }
      case "announcements": {
        if (!getSupabaseAnonKey()) break;
        const rows = await sbSelect("announcements", "select=*&order=created_at.desc&limit=100", currentUser);
        cachedAnnouncements = rows.map(mapAnnouncementRow);
        renderAnnouncementsList();
        break;
      }
      case "push_notification_history": {
        if (!getSupabaseAnonKey()) break;
        const rows = await sbSelect("push_notification_history", "select=*&order=created_at.desc&limit=100", currentUser);
        cachedPushHistory = rows.map(mapPushHistoryRow);
        renderPushHistory();
        break;
      }
      case "user_profiles": {
        const rows = await multiCloudDbQuery({
          table: "user_profiles",
          categoryKey: "user_profiles",
          supabaseQuery: "select=*&order=updated_at.desc&limit=500",
          orderBy: "updated_at",
          pkFields: ["user_id", "id"],
          currentUser,
          storageState
        });
        cachedUsers = rows.map(mapUserRow);
        renderPushUserChips();
        renderUsersSection();
        break;
      }
      case "problem_reports": {
        const rows = await multiCloudDbQuery({
          table: "problem_reports",
          categoryKey: "community",
          supabaseQuery: "select=*&order=created_at.desc&limit=200",
          orderBy: "created_at",
          pkFields: ["report_id", "id"],
          currentUser,
          storageState
        });
        cachedReports = rows.map(mapProblemReportRow);
        renderDashboardStats();
        renderReportsList();
        break;
      }
      case "audit_logs": {
        if (!getSupabaseAnonKey()) break;
        const rows = await sbSelect("audit_logs", "select=*&order=created_at.desc&limit=150", currentUser);
        cachedAuditLogs = rows.map(mapAuditLogRow);
        renderDashboardStats();
        renderAuditLogs();
        break;
      }
      case "storage_upload_history": {
        if (!getSupabaseAnonKey()) break;
        const rows = await sbSelect("storage_upload_history", "select=*&order=created_at.desc&limit=150", currentUser);
        cachedUploadHistory = rows.map(mapUploadHistoryRow);
        renderUploadHistory();
        renderStorageStats();
        break;
      }
      case "storage_error_logs": {
        if (!getSupabaseAnonKey()) break;
        const rows = await sbSelect("storage_error_logs", "select=*&order=created_at.desc&limit=150", currentUser);
        cachedErrorLogs = rows.map(mapStorageErrorRow);
        renderErrorLogs();
        renderStorageStats();
        break;
      }
      case "ai_error_logs": {
        if (!getSupabaseAnonKey()) break;
        const rows = await sbSelect("ai_error_logs", "select=*&order=created_at.desc&limit=150", currentUser);
        cachedAiErrorLogs = rows.map(mapAiErrorRow);
        renderAiStats();
        renderAiErrorLogs();
        break;
      }
      case "admin_roles": {
        if (currentIsBootstrapAdmin) {
          const rows = await multiCloudDbQuery({
            table: "admin_roles",
            categoryKey: "community",
            supabaseQuery: "select=*&order=created_at.desc&limit=100",
            orderBy: "created_at",
            pkFields: ["user_id"],
            currentUser,
            storageState
          });
          cachedAdminRoles = rows.map(mapAdminRoleRow);
          renderRolesList(cachedAdminRoles);
        }
        break;
      }
      case "cloud_migration_runs": {
        const rows = await multiCloudDbQuery({
          table: "cloud_migration_runs",
          categoryKey: "community",
          supabaseQuery: "select=*&order=started_at.desc&limit=50",
          orderBy: "started_at",
          pkFields: ["run_id"],
          currentUser,
          storageState
        });
        cachedMigrationRuns = rows;
        renderMigrationRunsList();
        break;
      }
      case "cloud_backup_manifests": {
        const rows = await multiCloudDbQuery({
          table: "cloud_backup_manifests",
          categoryKey: "community",
          supabaseQuery: "select=*&order=created_at.desc&limit=30",
          orderBy: "created_at",
          pkFields: ["backup_id"],
          currentUser,
          storageState
        });
        cachedBackupManifests = rows;
        renderBackupManifestsList();
        break;
      }
      default:
        break;
    }
  } catch (err) {
    console.warn(`Cloud refresh (${name}) note:`, err?.message || err);
  }
}

async function refreshAllStreams() {
  if (!currentUser) return;
  const cachedManifest = loadDiscoveryCache();

  if (!getSupabaseAnonKey() && !cachedManifest) {
    syncStorageFormsFromState();
    renderStorageManager();
    renderCategoryRoutingSelects();
    showToast("Paste Supabase Public Anon Key in Storage Manager to sync database tables.", true);
    return;
  }

  let settingsMap = new Map();
  let providerRows = [];
  let loadedFromSupabase = false;

  if (getSupabaseAnonKey()) {
    const [settingsRes, storageProvsRes] = await Promise.allSettled([
      sbSelect("app_settings", "select=setting_id,config_type,payload,updated_at", currentUser),
      sbSelect("storage_providers", "select=*", currentUser)
    ]);
    if (settingsRes.status === "fulfilled" && Array.isArray(settingsRes.value)) {
      settingsRes.value.forEach((row) => settingsMap.set(row.setting_id, row.payload || {}));
      loadedFromSupabase = true;
    }
    if (storageProvsRes.status === "fulfilled" && Array.isArray(storageProvsRes.value)) {
      providerRows = storageProvsRes.value;
    }
  }

  if (!loadedFromSupabase) {
    const candidateDiscoveryUrls = Array.from(new Set([
      ...(migrationConfigState?.fallbackDiscoveryUrls || []),
      ...(cachedManifest?.fallbackDiscoveryUrls || []),
      ...((cachedManifest?.providers || []).filter((p) => p.enabled && p.providerType === "PHP_HOSTING").map((p) => p.endpointUrl))
    ]));
    const discovered = (await fetchDiscoveryFromExternalHosts(candidateDiscoveryUrls)) || cachedManifest;
    if (discovered) {
      applyStorageConfigPayload(discovered, []);
      migrationConfigState = normalizeMigrationConfig(discovered);
      syncMigrationUiFromState();
    }
  } else {
    if (settingsMap.has("admob_config")) populateAdMobForm(settingsMap.get("admob_config"));
    if (settingsMap.has("global_config")) populateGlobalSettingsForm(settingsMap.get("global_config"));
    applyStorageConfigPayload(settingsMap.get("storage_config") || {}, providerRows);
    migrationConfigState = normalizeMigrationConfig({
      ...(settingsMap.get("storage_config") || {}),
      ...(settingsMap.get("migration_config") || {})
    });
    syncMigrationUiFromState();
    applyAiConfigPayload(settingsMap.get("ai_config") || {});
    applyBillingConfigPayload(settingsMap.get("billing_config") || {});
    saveDiscoveryCache({
      ...storageState,
      ...migrationConfigState
    });
  }

  const tables = [
    "repair_catalog_entries",
    "technicians",
    "technician_verification_requests",
    "community_posts",
    "community_reports",
    "community_user_restrictions",
    "technical_documents",
    "announcements",
    "push_notification_history",
    "user_profiles",
    "problem_reports",
    "audit_logs",
    "ai_error_logs",
    "storage_upload_history",
    "storage_error_logs",
    "cloud_migration_runs",
    "cloud_backup_manifests"
  ];
  if (currentIsBootstrapAdmin) tables.push("admin_roles");
  await Promise.allSettled(tables.map((t) => refreshTable(t)));
  renderPartialCloudAvailabilityBanner();
  refreshLiveUsageAndThresholdMonitor().catch(() => {});
  refreshSchedulerStatusCard().catch(() => {});
}

function subscribeAllStreams() {
  refreshAllStreams();
  pollTimer = setInterval(() => {
    if (currentUser && document.visibilityState !== "hidden") {
      refreshAllStreams();
    }
  }, 20000);
}

// =========================================================================
// MULTI-CLOUD STORAGE ADAPTERS & AUTOMATIC FAILOVER ENGINE
// =========================================================================

function getPrimarySupabaseProvider() {
  return (storageState.providers || []).find((p) => p.providerType === "SUPABASE_STORAGE" && p.enabled)
    || (storageState.providers || []).find((p) => p.providerType === "SUPABASE_STORAGE")
    || defaultSupabasePrimaryProvider();
}

async function validateMagicBytesForFile(fileOrBlob, expectedMime = "") {
  const mime = String(expectedMime || fileOrBlob?.type || "").toLowerCase();
  const buf = await fileOrBlob.slice(0, 12).arrayBuffer();
  const b = new Uint8Array(buf);
  const isJpeg = b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
  const isPng = b.length >= 4 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47;
  const isWebp =
    b.length >= 12 &&
    b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
    b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50;
  const isPdf = b.length >= 5 && b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46 && b[4] === 0x2d;

  if (mime.includes("pdf")) {
    if (!isPdf) throw new Error("Invalid PDF signature: file header does not start with %PDF-.");
    return;
  }
  if (mime.includes("jpeg") || mime.includes("jpg")) {
    if (!isJpeg) throw new Error("Invalid JPEG signature.");
    return;
  }
  if (mime.includes("png")) {
    if (!isPng) throw new Error("Invalid PNG signature.");
    return;
  }
  if (mime.includes("webp")) {
    if (!isWebp) throw new Error("Invalid WebP signature.");
    return;
  }
  if (!isJpeg && !isPng && !isWebp && !isPdf) {
    throw new Error("Unsupported file format. Only JPEG, PNG, WebP, or PDF files are permitted.");
  }
}

async function supabaseFetchWithAuth(provider, url, options = {}) {
  const anonKey = String(provider?.publicAnonKey || getSupabaseAnonKey() || "").trim();
  if (!anonKey) {
    throw new Error("Supabase Public Anon Key is missing in Multi-Cloud Storage Manager.");
  }
  const makeRequest = async (forceRefresh) => {
    const authToken = currentUser ? await currentUser.getIdToken(forceRefresh) : anonKey;
    return fetch(url, {
      ...options,
      headers: {
        apikey: anonKey,
        Authorization: `Bearer ${authToken}`,
        ...(options.headers || {})
      }
    });
  };
  let resp = await makeRequest(false);
  if (resp.status === 401 && currentUser) {
    resp = await makeRequest(true);
  }
  return resp;
}

async function supabaseUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType) {
  const endpoint = String(provider.endpointUrl || getSupabaseUrl() || SUPABASE_URL).replace(/\/+$/, "");
  const anonKey = String(provider.publicAnonKey || getSupabaseAnonKey() || "").trim();
  if (!endpoint || !anonKey) {
    throw new Error("Supabase URL or Public Anon Key is missing in Multi-Cloud Storage Manager.");
  }
  const effectiveType = contentType || fileOrBlob.type || "application/octet-stream";
  await validateMagicBytesForFile(fileOrBlob, effectiveType);

  const cleanPath = String(objectPath).replace(/^\/+/, "");
  const url = `${endpoint}/storage/v1/object/${encodeURIComponent(bucketName)}/${cleanPath.split("/").map(encodeURIComponent).join("/")}`;
  const resp = await supabaseFetchWithAuth(provider, url, {
    method: "POST",
    headers: {
      "Content-Type": effectiveType,
      "x-upsert": "false"
    },
    body: fileOrBlob
  });
  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    throw new Error(`Supabase Storage HTTP ${resp.status}: ${errText.slice(0, 220)}`);
  }
  const isPrivateBucket = bucketName === "verification-documents";
  const publicUrl = isPrivateBucket
    ? `${endpoint}/storage/v1/object/authenticated/${bucketName}/${cleanPath}`
    : `${endpoint}/storage/v1/object/public/${bucketName}/${cleanPath}`;
  return {
    providerId: provider.providerId,
    providerName: provider.providerName,
    bucketName,
    storagePath: `${bucketName}/${cleanPath}`,
    objectPath: cleanPath,
    publicUrl,
    sizeBytes: Number(fileOrBlob.size || 0)
  };
}

async function supabaseCreateSignedUrl(provider, bucketName, objectPath, expiresIn = 300) {
  const cleanPath = String(objectPath || "")
    .replace(/^\/+/, "")
    .replace(new RegExp(`^${bucketName}/`), "");
  if (!cleanPath) throw new Error("Object path is required to sign URL.");

  if (currentUser) {
    try {
      const edgeRes = await callAdminUserManagementFn({
        action: "create_signed_url",
        bucket: bucketName,
        storagePath: cleanPath,
        expiresIn
      });
      if (edgeRes?.signedUrl) return edgeRes.signedUrl;
    } catch (edgeErr) {
      console.warn("Edge signed URL fallback to direct Storage API:", edgeErr?.message || edgeErr);
    }
  }

  const endpoint = String(provider?.endpointUrl || SUPABASE_URL).replace(/\/+$/, "");
  const signUrl = `${endpoint}/storage/v1/object/sign/${encodeURIComponent(bucketName)}/${cleanPath.split("/").map(encodeURIComponent).join("/")}`;
  const resp = await supabaseFetchWithAuth(provider, signUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ expiresIn })
  });
  const payload = await resp.json().catch(() => ({}));
  if (!resp.ok || !payload?.signedURL) {
    throw new Error(payload?.message || payload?.error || `Signed URL failed HTTP ${resp.status}`);
  }
  const raw = String(payload.signedURL);
  return raw.startsWith("http") ? raw : `${endpoint}/storage/v1${raw.startsWith("/") ? "" : "/"}${raw}`;
}

async function supabaseListObjects(provider, bucketName) {
  const endpoint = String(provider.endpointUrl || SUPABASE_URL).replace(/\/+$/, "");
  const resp = await supabaseFetchWithAuth(provider, `${endpoint}/storage/v1/object/list/${encodeURIComponent(bucketName)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prefix: "", limit: 100, offset: 0, sortBy: { column: "created_at", order: "desc" } })
  });
  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    throw new Error(`List failed HTTP ${resp.status}: ${errText.slice(0, 200)}`);
  }
  const items = await resp.json();
  return (Array.isArray(items) ? items : []).filter((it) => it && it.name && it.id !== null);
}

async function supabaseDeleteObject(provider, bucketName, objectPath) {
  const endpoint = String(provider.endpointUrl || SUPABASE_URL).replace(/\/+$/, "");
  const cleanPath = String(objectPath).replace(/^\/+/, "");
  const resp = await supabaseFetchWithAuth(provider, `${endpoint}/storage/v1/object/${encodeURIComponent(bucketName)}`, {
    method: "DELETE",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prefixes: [cleanPath] })
  });
  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    throw new Error(`Delete failed HTTP ${resp.status}: ${errText.slice(0, 180)}`);
  }
}

async function signedProxyUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType) {
  const proxyUrl = String(provider.proxyUploadUrl || "").trim();
  if (!proxyUrl || !/^https:\/\//i.test(proxyUrl)) {
    throw new Error(`${provider.providerName} requires a configured HTTPS Signed Upload Proxy URL.`);
  }
  const idToken = currentUser ? await currentUser.getIdToken() : "";
  const signResp = await fetch(proxyUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(idToken ? { Authorization: `Bearer ${idToken}` } : {})
    },
    body: JSON.stringify({
      providerId: provider.providerId,
      providerType: provider.providerType,
      bucketName,
      objectPath,
      contentType: contentType || fileOrBlob.type || "application/octet-stream",
      sizeBytes: Number(fileOrBlob.size || 0)
    })
  });
  if (!signResp.ok) {
    const txt = await signResp.text().catch(() => "");
    throw new Error(`Signed upload proxy HTTP ${signResp.status}: ${txt.slice(0, 180)}`);
  }
  const signed = await signResp.json();
  if (!signed?.uploadUrl || !signed?.publicUrl) {
    throw new Error("Signed upload proxy returned incomplete uploadUrl/publicUrl.");
  }
  const putResp = await fetch(signed.uploadUrl, {
    method: "PUT",
    headers: { "Content-Type": contentType || fileOrBlob.type || "application/octet-stream" },
    body: fileOrBlob
  });
  if (!putResp.ok) {
    throw new Error(`Direct object PUT failed HTTP ${putResp.status}`);
  }
  return {
    providerId: provider.providerId,
    providerName: provider.providerName,
    bucketName,
    storagePath: `${bucketName}/${objectPath}`,
    objectPath,
    publicUrl: signed.publicUrl,
    sizeBytes: Number(fileOrBlob.size || 0)
  };
}

async function phpHostingUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType, onProgress) {
  const effectiveType = contentType || fileOrBlob.type || "application/octet-stream";
  await validateMagicBytesForFile(fileOrBlob, effectiveType);
  if (onProgress) onProgress(0.35);
  const base64 = await fileToBase64(fileOrBlob);
  if (onProgress) onProgress(0.65);

  const cleanPath = String(objectPath).replace(/^\/+/, "");
  let res;
  try {
    res = await callCpanelDirect(provider.endpointUrl, "upload", {
      bucketName,
      objectPath: cleanPath,
      base64,
      mimeType: effectiveType
    }, currentUser);
  } catch (directErr) {
    const msg = String(directErr?.message || "").toLowerCase();
    if ((msg.includes("401") || msg.includes("unauthorized") || msg.includes("api_secret")) && storageState.hostingProxyUrl) {
      res = await callHostingProxy({
        action: "upload",
        providerId: provider.providerId,
        uploadApiUrl: provider.endpointUrl,
        endpointUrl: provider.endpointUrl,
        bucketName,
        objectPath: cleanPath,
        base64,
        mimeType: effectiveType
      });
    } else {
      throw directErr;
    }
  }
  if (onProgress) onProgress(1);
  return {
    providerId: provider.providerId,
    providerName: provider.providerName,
    bucketName: res.bucketName || bucketName,
    storagePath: res.storagePath || `${bucketName}/${cleanPath}`,
    objectPath: cleanPath,
    publicUrl: res.publicUrl,
    sizeBytes: Number(res.sizeBytes || fileOrBlob.size || 0)
  };
}

async function logUploadHistory(record) {
  if (!currentUser || !getSupabaseAnonKey()) return;
  try {
    const uploadId = slugId("upl");
    await sbUpsert("storage_upload_history", {
      upload_id: uploadId,
      provider_id: String(record.providerId).slice(0, 128),
      bucket_name: String(record.bucketName).slice(0, 128),
      object_path: String(record.objectPath).slice(0, 320),
      public_url: String(record.publicUrl || "").slice(0, 1000),
      mime_type: String(record.mimeType || "application/octet-stream").slice(0, 100),
      size_bytes: Math.max(0, Math.round(Number(record.sizeBytes || 0))),
      failover_used: Boolean(record.failoverUsed),
      status: record.status === "FAILED" ? "FAILED" : "SUCCESS",
      uploaded_by_uid: currentUser.uid
    }, "upload_id", currentUser);
    refreshTable("storage_upload_history");
  } catch (err) {
    console.warn("Could not record storage_upload_history:", err?.message || err);
  }
}

async function logStorageError(providerId, bucketName, objectPath, errorMessage, failoverTargetId = "") {
  if (!currentUser || !getSupabaseAnonKey()) return;
  try {
    const errorId = slugId("err");
    await sbUpsert("storage_error_logs", {
      error_id: errorId,
      provider_id: String(providerId || "unknown").slice(0, 128),
      bucket_name: String(bucketName || "").slice(0, 128),
      object_path: String(objectPath || "").slice(0, 320),
      error_message: String(errorMessage || "Upload error").slice(0, 600),
      failover_target_id: String(failoverTargetId || "").slice(0, 128),
      actor_uid: currentUser.uid,
      resolved: false
    }, "error_id", currentUser);
    refreshTable("storage_error_logs");
  } catch (err) {
    console.warn("Could not record storage_error_logs:", err?.message || err);
  }
}

async function uploadWithProvider(provider, bucketName, objectPath, fileOrBlob, contentType, onProgress) {
  if (onProgress) onProgress(0.2);
  if (provider.providerType === "SUPABASE_STORAGE") {
    const res = await supabaseUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType);
    if (onProgress) onProgress(1);
    return res;
  }
  if (provider.providerType === "PHP_HOSTING") {
    return await phpHostingUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType, onProgress);
  }
  if (provider.providerType === "FIREBASE_LEGACY") {
    throw new Error("Firebase Storage has been removed; configure Supabase or Shared Hosting.");
  }
  const res = await signedProxyUploadObject(provider, bucketName, objectPath, fileOrBlob, contentType);
  if (onProgress) onProgress(1);
  return res;
}

async function multiCloudUpload({ bucketKey, objectPath, fileOrBlob, contentType, onProgress }) {
  const candidates = getOrderedActiveProviders(bucketKey);
  if (!candidates.length) {
    throw new Error("No enabled storage providers configured for this category in Multi-Cloud Storage Manager.");
  }

  let lastError = null;
  let failoverUsed = false;

  for (let i = 0; i < candidates.length; i += 1) {
    const provider = candidates[i];
    const bucketName = getBucketNameForCategory(provider, bucketKey);
    try {
      const result = await uploadWithProvider(provider, bucketName, objectPath, fileOrBlob, contentType, onProgress);
      provider.usedBytes = Number(provider.usedBytes || 0) + Number(fileOrBlob.size || 0);
      provider.lastStatus = "HEALTHY";
      await logUploadHistory({
        providerId: provider.providerId,
        bucketName,
        objectPath,
        publicUrl: result.publicUrl,
        mimeType: contentType || fileOrBlob.type,
        sizeBytes: fileOrBlob.size,
        failoverUsed,
        status: "SUCCESS"
      });
      return { ...result, failoverUsed };
    } catch (err) {
      lastError = err;
      provider.lastStatus = "ERROR";
      const nextProvider = candidates[i + 1];
      await logStorageError(
        provider.providerId,
        bucketName,
        objectPath,
        err?.message || "Upload failed",
        nextProvider ? nextProvider.providerId : ""
      );
      if (nextProvider) {
        failoverUsed = true;
      }
    }
  }

  await logUploadHistory({
    providerId: candidates[0].providerId,
    bucketName: getBucketNameForCategory(candidates[0], bucketKey),
    objectPath,
    publicUrl: "",
    mimeType: contentType || fileOrBlob.type,
    sizeBytes: fileOrBlob.size,
    failoverUsed,
    status: "FAILED"
  });

  throw lastError || new Error("All configured storage providers failed.");
}

// =========================================================================
// DASHBOARD & APPLIANCES RENDERING
// =========================================================================

function renderDashboardStats() {
  if ($("stat-catalog")) $("stat-catalog").textContent = String(cachedCatalog.length);
  if ($("stat-published")) $("stat-published").textContent = String(cachedCatalog.filter((c) => c.published).length);
  if ($("stat-technicians")) $("stat-technicians").textContent = String(cachedTechnicians.filter((t) => t.status === "ACTIVE").length);
  if ($("stat-verifications-pending")) $("stat-verifications-pending").textContent = String(cachedVerifications.filter((v) => v.status === "PENDING").length);
  if ($("stat-community-pending")) $("stat-community-pending").textContent = String(cachedCommunityPosts.filter((p) => p.approvalStatus === "PENDING").length);
  if ($("stat-documents")) $("stat-documents").textContent = String(cachedDocuments.length);
  if ($("stat-reports")) $("stat-reports").textContent = String(cachedReports.filter((r) => r.status === "PENDING").length);
  if ($("stat-logs")) $("stat-logs").textContent = String(cachedAuditLogs.length);

  const primary = (storageState.providers || []).find((p) => p.enabled && p.role === "PRIMARY") || storageState.providers[0];
  if ($("stat-storage-primary")) {
    $("stat-storage-primary").textContent = primary ? primary.providerName.split(" ")[0] : "Supabase";
  }

  const barsEl = $("category-bars");
  if (!barsEl) return;
  const counts = {
    ac: cachedCatalog.filter((c) => c.categoryId === "ac").length,
    fridge: cachedCatalog.filter((c) => c.categoryId === "fridge").length,
    washer: cachedCatalog.filter((c) => c.categoryId === "washer").length
  };
  const max = Math.max(1, counts.ac, counts.fridge, counts.washer);
  barsEl.innerHTML = [
    ["Air Conditioner (AC)", counts.ac],
    ["Refrigerator (Fridge)", counts.fridge],
    ["Washing Machine", counts.washer]
  ].map(([label, count]) => `
    <div style="margin-bottom:10px;">
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
        <span>${label}</span><strong>${count} entries</strong>
      </div>
      <div class="progress-track"><div class="progress-fill" style="width:${Math.round((count / max) * 100)}%;"></div></div>
    </div>
  `).join("");
}

function renderAppliancesGrid() {
  const grid = $("appliances-grid");
  if (!grid) return;
  const defaults = [
    { id: "ac", name: "Air Conditioner (AC)", sub: "Split, Inverter, Window, PCB & Compressor" },
    { id: "fridge", name: "Refrigerator (Fridge)", sub: "Inverter Fridge, Frost-Free, Defrost & Thermostat" },
    { id: "washer", name: "Washing Machine", sub: "Front Load, Top Load, Drain Pump & Inverter Motor" }
  ];
  const customCats = cachedCatalog.filter((c) => c.entryType === "CATEGORY");
  const all = [
    ...defaults.map((d) => ({
      ...d,
      count: cachedCatalog.filter((c) => c.categoryId === d.id && c.entryType !== "CATEGORY").length
    })),
    ...customCats.map((c) => ({
      id: c.categoryId,
      name: c.titleEn || c.categoryId,
      sub: `${c.titleBn || ""} ${c.titleHi || ""}`.trim() || "Custom Cloud Category",
      count: cachedCatalog.filter((x) => x.categoryId === c.categoryId && x.entryType !== "CATEGORY").length
    }))
  ];
  grid.innerHTML = all.map((c) => `
    <div class="card">
      <div class="badge badge-cyan">${escapeHtml(c.id.toUpperCase())}</div>
      <h3 style="margin:8px 0 4px;">${escapeHtml(c.name)}</h3>
      <p style="font-size:12px;color:var(--text-muted);margin:0 0 8px;">${escapeHtml(c.sub)}</p>
      <div style="font-size:13px;font-weight:700;color:var(--success);">${c.count} live cloud entries</div>
    </div>
  `).join("");
}

$("new-category-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const catId = $("new-cat-id").value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
  const titleEn = $("new-cat-en").value.trim();
  if (!catId || !titleEn) {
    showToast("Category ID and English name are required.", true);
    return;
  }
  const docId = `cat_${catId}`;
  try {
    await multiCloudDbUpsert({
      table: "repair_catalog_entries",
      cpanelTable: "catalog_entries",
      categoryKey: "community",
      record: {
        id: docId,
        entry_type: "CATEGORY",
        category_id: catId,
        brand_name: "",
        model_series: "",
        code: "",
        title_en: titleEn,
        title_bn: $("new-cat-bn").value.trim(),
        title_hi: $("new-cat-hi").value.trim(),
        summary_en: `${titleEn} diagnostic category`,
        summary_bn: "",
        summary_hi: "",
        steps_en: "",
        steps_bn: "",
        steps_hi: "",
        safety_warning_en: "Disconnect power before servicing.",
        verification_status: "VERIFIED",
        published: true,
        revision: 1,
        updated_by_uid: currentUser.uid
      },
      onConflict: "id",
      currentUser,
      storageState,
      migrationConfig: migrationConfigState
    });
    await writeAuditLog("CREATE_CATEGORY", "repair_catalog_entries", docId, `Published category ${catId}`);
    $("new-category-form").reset();
    await refreshTable("repair_catalog_entries");
    showToast("Appliance category published.");
  } catch (err) {
    showToast(`Failed to publish category: ${err.message}`, true);
  }
});

// =========================================================================
// ERROR CODES & MULTILINGUAL CATALOG
// =========================================================================

function resetCatalogForm() {
  $("catalog-form")?.reset();
  if ($("cat-doc-id")) $("cat-doc-id").value = "";
  if ($("catalog-form-heading")) $("catalog-form-heading").textContent = "Create / Publish Multilingual Entry";
  $("cancel-edit-btn")?.classList.add("hidden");
}

$("cancel-edit-btn")?.addEventListener("click", resetCatalogForm);
$("catalog-filter")?.addEventListener("change", renderCatalogList);

$("catalog-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const existingId = $("cat-doc-id").value.trim();
  const docId = existingId || slugId("cat");
  const titleEn = $("cat-title-en").value.trim();
  const summaryEn = $("cat-summary-en").value.trim();
  if (!titleEn || !summaryEn) {
    showToast("English title and summary are required.", true);
    return;
  }
  const existingItem = existingId ? cachedCatalog.find((c) => c.id === existingId) : null;
  try {
    if (existingId && existingItem) {
      await multiCloudDbUpdate({
        table: "repair_catalog_entries",
        cpanelTable: "catalog_entries",
        categoryKey: "community",
        recordId: docId,
        supabaseFilter: `id=eq.${encodeURIComponent(docId)}`,
        patch: {
          brand_name: $("cat-brand").value.trim(),
          model_series: $("cat-model").value.trim(),
          code: $("cat-code").value.trim(),
          title_en: titleEn,
          title_bn: $("cat-title-bn").value.trim(),
          title_hi: $("cat-title-hi").value.trim(),
          summary_en: summaryEn,
          summary_bn: $("cat-summary-bn").value.trim(),
          summary_hi: $("cat-summary-hi").value.trim(),
          steps_en: $("cat-steps-en").value.trim(),
          steps_bn: $("cat-steps-bn").value.trim(),
          steps_hi: $("cat-steps-hi").value.trim(),
          safety_warning_en: $("cat-safety-en").value.trim(),
          verification_status: $("cat-verification").value,
          published: $("cat-published").checked,
          revision: Math.min(10000, Number(existingItem.revision || 1) + 1),
          updated_by_uid: currentUser.uid
        },
        currentUser,
        storageState,
        migrationConfig: migrationConfigState
      });
      await writeAuditLog("UPDATE_CATALOG_ENTRY", "repair_catalog_entries", docId, titleEn);
    } else {
      await multiCloudDbUpsert({
        table: "repair_catalog_entries",
        cpanelTable: "catalog_entries",
        categoryKey: "community",
        record: {
          id: docId,
          entry_type: $("cat-entry-type").value,
          category_id: $("cat-category-id").value,
          brand_name: $("cat-brand").value.trim(),
          model_series: $("cat-model").value.trim(),
          code: $("cat-code").value.trim(),
          title_en: titleEn,
          title_bn: $("cat-title-bn").value.trim(),
          title_hi: $("cat-title-hi").value.trim(),
          summary_en: summaryEn,
          summary_bn: $("cat-summary-bn").value.trim(),
          summary_hi: $("cat-summary-hi").value.trim(),
          steps_en: $("cat-steps-en").value.trim(),
          steps_bn: $("cat-steps-bn").value.trim(),
          steps_hi: $("cat-steps-hi").value.trim(),
          safety_warning_en: $("cat-safety-en").value.trim(),
          verification_status: $("cat-verification").value,
          published: $("cat-published").checked,
          revision: 1,
          updated_by_uid: currentUser.uid
        },
        onConflict: "id",
        currentUser,
        storageState,
        migrationConfig: migrationConfigState
      });
      await writeAuditLog("CREATE_CATALOG_ENTRY", "repair_catalog_entries", docId, titleEn);
    }
    resetCatalogForm();
    await refreshTable("repair_catalog_entries");
    showToast("Catalog entry synced.");
  } catch (err) {
    showToast(`Save failed: ${err.message}`, true);
  }
});

function renderCatalogList() {
  const listEl = $("catalog-list");
  if (!listEl) return;
  const filter = $("catalog-filter")?.value || "all";
  const items = cachedCatalog.filter((c) => filter === "all" || c.categoryId === filter);
  if (!items.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No cloud catalog entries found for this filter.</span></div>`;
    return;
  }
  listEl.innerHTML = items.map((c) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge badge-cyan">${escapeHtml(c.entryType)}</span>
          <span class="badge ${c.published ? "badge-green" : "badge-warn"}">${c.published ? "LIVE" : "DRAFT"}</span>
          <strong style="margin-left:6px;">${escapeHtml(c.brandName ? `${c.brandName} ${c.code || ""} — ` : "")}${escapeHtml(c.titleEn)}</strong>
        </div>
        <div style="display:flex;gap:8px;">
          <button type="button" class="btn btn-outline btn-sm" data-cat-edit="${escapeHtml(c.id)}">Edit</button>
          <button type="button" class="btn btn-danger btn-sm" data-cat-del="${escapeHtml(c.id)}">Delete</button>
        </div>
      </div>
      <div style="font-size:13px;color:var(--text-muted);">${escapeHtml(c.summaryEn)}</div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-cat-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const item = cachedCatalog.find((x) => x.id === btn.dataset.catEdit);
      if (!item) return;
      $("cat-doc-id").value = item.id;
      $("cat-entry-type").value = item.entryType || "ERROR_CODE";
      $("cat-category-id").value = item.categoryId || "ac";
      $("cat-brand").value = item.brandName || "";
      $("cat-model").value = item.modelSeries || "";
      $("cat-code").value = item.code || "";
      $("cat-verification").value = item.verificationStatus || "VERIFIED";
      $("cat-title-en").value = item.titleEn || "";
      $("cat-title-bn").value = item.titleBn || "";
      $("cat-title-hi").value = item.titleHi || "";
      $("cat-summary-en").value = item.summaryEn || "";
      $("cat-summary-bn").value = item.summaryBn || "";
      $("cat-summary-hi").value = item.summaryHi || "";
      $("cat-steps-en").value = item.stepsEn || "";
      $("cat-steps-bn").value = item.stepsBn || "";
      $("cat-steps-hi").value = item.stepsHi || "";
      $("cat-safety-en").value = item.safetyWarningEn || "";
      $("cat-published").checked = Boolean(item.published);
      $("catalog-form-heading").textContent = `Editing ${item.titleEn}`;
      $("cancel-edit-btn")?.classList.remove("hidden");
      $("catalog-form")?.scrollIntoView({ behavior: "smooth" });
    });
  });

  listEl.querySelectorAll("[data-cat-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.catDel;
      if (!(await openConfirmModal("Delete Catalog Entry", `Permanently delete catalog entry ${id}?`))) return;
      try {
        await multiCloudDbDelete({
          table: "repair_catalog_entries",
          cpanelTable: "catalog_entries",
          categoryKey: "community",
          recordId: id,
          supabaseFilter: `id=eq.${encodeURIComponent(id)}`,
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await writeAuditLog("DELETE_CATALOG_ENTRY", "repair_catalog_entries", id, "Deleted catalog entry");
        await refreshTable("repair_catalog_entries");
        showToast("Catalog entry deleted.");
      } catch (err) {
        showToast(`Delete failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// TECHNICIAN MANAGEMENT (MULTI-CLOUD PHOTO UPLOAD + CRUD)
// =========================================================================

function updateTechPhotoPreview(url, name = "RP") {
  const wrap = $("tech-photo-preview-wrap");
  if (!wrap) return;
  if (url) {
    wrap.outerHTML = `<img id="tech-photo-preview-wrap" class="tech-avatar" src="${escapeHtml(safeHref(url))}" alt="Technician Photo" />`;
    $("tech-remove-photo-btn")?.classList.remove("hidden");
  } else {
    const initials = String(name || "RP").trim().slice(0, 2).toUpperCase() || "RP";
    wrap.outerHTML = `<div id="tech-photo-preview-wrap" class="tech-avatar-fallback">${escapeHtml(initials)}</div>`;
    $("tech-remove-photo-btn")?.classList.add("hidden");
  }
}

$("tech-photo-input")?.addEventListener("change", (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    showToast("Profile photo must be 5 MB or less.", true);
    e.target.value = "";
    return;
  }
  pendingTechPhotoFile = file;
  removeTechPhotoRequested = false;
  updateTechPhotoPreview(URL.createObjectURL(file));
  if ($("tech-photo-status")) {
    $("tech-photo-status").textContent = `Ready to upload "${file.name}" via Multi-Cloud Storage Router.`;
  }
});

$("tech-remove-photo-btn")?.addEventListener("click", () => {
  pendingTechPhotoFile = null;
  removeTechPhotoRequested = true;
  if ($("tech-photo-input")) $("tech-photo-input").value = "";
  updateTechPhotoPreview("");
});

function resetTechnicianForm() {
  $("technician-form")?.reset();
  if ($("tech-doc-id")) $("tech-doc-id").value = "";
  if ($("tech-existing-photo-url")) $("tech-existing-photo-url").value = "";
  if ($("tech-existing-photo-path")) $("tech-existing-photo-path").value = "";
  pendingTechPhotoFile = null;
  removeTechPhotoRequested = false;
  updateTechPhotoPreview("");
  $("tech-cancel-edit-btn")?.classList.add("hidden");
  $("tech-form-error")?.classList.add("hidden");
  $("tech-upload-progress-wrap")?.classList.add("hidden");
  if ($("tech-form-heading")) $("tech-form-heading").textContent = "Add New Technician";
}

$("tech-cancel-edit-btn")?.addEventListener("click", resetTechnicianForm);
$("tech-reset-btn")?.addEventListener("click", resetTechnicianForm);

$("technician-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  $("tech-form-error")?.classList.add("hidden");
  const categories = Array.from(document.querySelectorAll(".tech-cat-checkbox"))
    .filter((cb) => cb.checked)
    .map((cb) => cb.value);
  if (!categories.length) {
    if ($("tech-form-error")) {
      $("tech-form-error").textContent = "Select at least one service category.";
      $("tech-form-error").classList.remove("hidden");
    }
    return;
  }

  const existingId = $("tech-doc-id").value.trim();
  const techId = existingId || slugId("tech");
  let photoUrl = removeTechPhotoRequested ? "" : ($("tech-existing-photo-url").value.trim() || "");
  let photoStoragePath = removeTechPhotoRequested ? "" : ($("tech-existing-photo-path").value.trim() || "");
  let photoProviderId = removeTechPhotoRequested ? "" : (cachedTechnicians.find((x) => x.id === existingId)?.photoProviderId || "");

  try {
    if (pendingTechPhotoFile) {
      $("tech-upload-progress-wrap")?.classList.remove("hidden");
      const ext = (pendingTechPhotoFile.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
      const uploaded = await multiCloudUpload({
        bucketKey: "technicians",
        objectPath: `${techId}_${Date.now()}.${ext}`,
        fileOrBlob: pendingTechPhotoFile,
        contentType: pendingTechPhotoFile.type || "image/jpeg",
        onProgress: (p) => {
          if ($("tech-upload-progress-fill")) $("tech-upload-progress-fill").style.width = `${Math.round(p * 100)}%`;
        }
      });
      photoUrl = uploaded.publicUrl;
      photoStoragePath = uploaded.storagePath;
      photoProviderId = uploaded.providerId || "supabase_primary";
    }

    const baseFields = {
      full_name: $("tech-full-name").value.trim(),
      photo_url: photoUrl,
      photo_storage_path: photoStoragePath,
      photo_provider_id: photoProviderId,
      mobile_number: $("tech-mobile").value.trim(),
      full_address: $("tech-address").value.trim(),
      state: $("tech-state").value.trim(),
      district: $("tech-district").value.trim(),
      city_area: $("tech-city-area").value.trim(),
      pin_code: $("tech-pin-code").value.trim(),
      service_categories: categories,
      experience: $("tech-experience").value.trim(),
      status: $("tech-status").value,
      updated_by_uid: currentUser.uid
    };

    if (existingId) {
      await multiCloudDbUpdate({
        table: "technicians",
        categoryKey: "technicians",
        recordId: techId,
        supabaseFilter: `technician_id=eq.${encodeURIComponent(techId)}`,
        patch: baseFields,
        currentUser,
        storageState,
        migrationConfig: migrationConfigState
      });
      await writeAuditLog("UPDATE_TECHNICIAN", "technicians", techId, baseFields.full_name);
    } else {
      await multiCloudDbUpsert({
        table: "technicians",
        categoryKey: "technicians",
        record: {
          technician_id: techId,
          ...baseFields
        },
        onConflict: "technician_id",
        currentUser,
        storageState,
        migrationConfig: migrationConfigState
      });
      await writeAuditLog("CREATE_TECHNICIAN", "technicians", techId, baseFields.full_name);
    }
    resetTechnicianForm();
    await refreshTable("technicians");
    showToast("Technician saved.");
  } catch (err) {
    if ($("tech-form-error")) {
      $("tech-form-error").textContent = err.message || "Failed to save technician.";
      $("tech-form-error").classList.remove("hidden");
    }
    showToast(`Technician save failed: ${err.message}`, true);
  }
});

["tech-search-input", "tech-filter-district", "tech-filter-category", "tech-filter-status"].forEach((id) => {
  $(id)?.addEventListener("input", renderTechniciansSection);
  $(id)?.addEventListener("change", renderTechniciansSection);
});

function renderTechniciansSection() {
  if ($("tech-stat-total")) $("tech-stat-total").textContent = String(cachedTechnicians.length);
  if ($("tech-stat-active")) $("tech-stat-active").textContent = String(cachedTechnicians.filter((t) => t.status === "ACTIVE").length);
  if ($("tech-stat-inactive")) $("tech-stat-inactive").textContent = String(cachedTechnicians.filter((t) => t.status !== "ACTIVE").length);

  const distSelect = $("tech-filter-district");
  if (distSelect) {
    const prev = distSelect.value || "all";
    const districts = Array.from(new Set(cachedTechnicians.map((t) => t.district).filter(Boolean))).sort();
    distSelect.innerHTML = `<option value="all">All Districts</option>` +
      districts.map((d) => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join("");
    distSelect.value = districts.includes(prev) ? prev : "all";
  }

  const qText = ($("tech-search-input")?.value || "").trim().toLowerCase();
  const dFilter = $("tech-filter-district")?.value || "all";
  const cFilter = $("tech-filter-category")?.value || "all";
  const sFilter = $("tech-filter-status")?.value || "all";

  const filtered = cachedTechnicians.filter((t) => {
    const matchesSearch = !qText ||
      String(t.fullName || "").toLowerCase().includes(qText) ||
      String(t.mobileNumber || "").toLowerCase().includes(qText) ||
      String(t.cityArea || "").toLowerCase().includes(qText);
    const matchesDist = dFilter === "all" || t.district === dFilter;
    const matchesCat = cFilter === "all" || (Array.isArray(t.serviceCategories) && t.serviceCategories.includes(cFilter));
    const matchesStatus = sFilter === "all" || t.status === sFilter;
    return matchesSearch && matchesDist && matchesCat && matchesStatus;
  });

  if ($("tech-filtered-count")) $("tech-filtered-count").textContent = `${filtered.length} shown`;
  const listEl = $("technicians-list");
  if (!listEl) return;
  if (!filtered.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No technicians match the active filters.</span></div>`;
    return;
  }

  listEl.innerHTML = filtered.map((t) => `
    <div class="list-item">
      <div class="list-header">
        <div class="tech-row">
          ${t.photoUrl
            ? `<img class="tech-avatar" src="${escapeHtml(safeHref(t.photoUrl))}" alt="${escapeHtml(t.fullName)}" />`
            : `<div class="tech-avatar-fallback">${escapeHtml(String(t.fullName || "RP").slice(0, 2).toUpperCase())}</div>`
          }
          <div>
            <strong>${escapeHtml(t.fullName)}</strong>
            ${t.verificationStatus === "VERIFIED" ? `<span class="badge badge-green">VERIFIED</span>` : ""}
            <span class="badge ${t.status === "ACTIVE" ? "badge-cyan" : "badge-warn"}">${escapeHtml(t.status)}</span>
            ${t.isSuspended ? `<span class="badge badge-warn">SUSPENDED</span>` : ""}
            ${t.isDeleted ? `<span class="badge badge-err">SOFT DELETED</span>` : ""}
            <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(t.mobileNumber)} • ${escapeHtml(t.cityArea)}, ${escapeHtml(t.district)} (${escapeHtml(t.pinCode)})</div>
            <div style="font-size:12px;color:var(--cyan);">${escapeHtml((t.serviceCategories || []).join(", "))} ${t.experience ? `• ${escapeHtml(t.experience)}` : ""}</div>
          </div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="button" class="btn btn-outline btn-sm" data-tech-edit="${escapeHtml(t.id)}">Edit</button>
          <button type="button" class="btn btn-outline btn-sm" data-tech-toggle="${escapeHtml(t.id)}">${t.status === "ACTIVE" ? "Deactivate" : "Activate"}</button>
          <button type="button" class="btn btn-outline btn-sm" data-tech-suspend="${escapeHtml(t.id)}">${t.isSuspended ? "Unsuspend" : "Suspend"}</button>
          ${t.photoUrl ? `<button type="button" class="btn btn-outline btn-sm" data-tech-rm-photo="${escapeHtml(t.id)}">Remove Photo</button>` : ""}
          <button type="button" class="btn btn-outline btn-sm" data-tech-soft-del="${escapeHtml(t.id)}">${t.isDeleted ? "Restore" : "Soft Delete"}</button>
          <button type="button" class="btn btn-danger btn-sm" data-tech-del="${escapeHtml(t.id)}">Delete</button>
        </div>
      </div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-tech-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const t = cachedTechnicians.find((x) => x.id === btn.dataset.techEdit);
      if (!t) return;
      $("tech-doc-id").value = t.id;
      $("tech-existing-photo-url").value = t.photoUrl || "";
      $("tech-existing-photo-path").value = t.photoStoragePath || "";
      $("tech-full-name").value = t.fullName || "";
      $("tech-mobile").value = t.mobileNumber || "";
      $("tech-experience").value = t.experience || "";
      $("tech-status").value = t.status || "ACTIVE";
      $("tech-address").value = t.fullAddress || "";
      $("tech-state").value = t.state || "";
      $("tech-district").value = t.district || "";
      $("tech-city-area").value = t.cityArea || "";
      $("tech-pin-code").value = t.pinCode || "";
      document.querySelectorAll(".tech-cat-checkbox").forEach((cb) => {
        cb.checked = Array.isArray(t.serviceCategories) && t.serviceCategories.includes(cb.value);
      });
      updateTechPhotoPreview(t.photoUrl || "", t.fullName || "RP");
      $("tech-form-heading").textContent = `Editing ${t.fullName}`;
      $("tech-cancel-edit-btn")?.classList.remove("hidden");
      $("technician-form")?.scrollIntoView({ behavior: "smooth" });
    });
  });

  listEl.querySelectorAll("[data-tech-toggle]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const t = cachedTechnicians.find((x) => x.id === btn.dataset.techToggle);
      if (!t || !currentUser) return;
      const nextStatus = t.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
      try {
        await multiCloudDbUpdate({
          table: "technicians",
          categoryKey: "technicians",
          recordId: t.id,
          supabaseFilter: `technician_id=eq.${encodeURIComponent(t.id)}`,
          patch: {
            status: nextStatus,
            updated_by_uid: currentUser.uid
          },
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await writeAuditLog("TOGGLE_TECHNICIAN_STATUS", "technicians", t.id, `${t.fullName} -> ${nextStatus}`);
        await refreshTable("technicians");
        showToast(`Technician set to ${nextStatus}.`);
      } catch (err) {
        showToast(`Status toggle failed: ${err.message}`, true);
      }
    });
  });

  listEl.querySelectorAll("[data-tech-suspend]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const t = cachedTechnicians.find((x) => x.id === btn.dataset.techSuspend);
      if (!t || !currentUser) return;
      const nextSuspended = !Boolean(t.isSuspended);
      try {
        await multiCloudDbUpdate({
          table: "technicians",
          categoryKey: "technicians",
          recordId: t.id,
          supabaseFilter: `technician_id=eq.${encodeURIComponent(t.id)}`,
          patch: {
            is_suspended: nextSuspended,
            updated_by_uid: currentUser.uid
          },
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await writeAuditLog(nextSuspended ? "SUSPEND_TECHNICIAN" : "UNSUSPEND_TECHNICIAN", "technicians", t.id, t.fullName);
        await refreshTable("technicians");
        showToast(nextSuspended ? "Technician suspended from directory." : "Technician unsuspended.");
      } catch (err) {
        showToast(`Update failed: ${err.message}`, true);
      }
    });
  });

  listEl.querySelectorAll("[data-tech-rm-photo]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const t = cachedTechnicians.find((x) => x.id === btn.dataset.techRmPhoto);
      if (!t || !currentUser) return;
      if (!(await openConfirmModal("Remove Technician Photo", `Remove profile photo from ${t.fullName}?`, "Remove Photo"))) return;
      try {
        await multiCloudDbUpdate({
          table: "technicians",
          categoryKey: "technicians",
          recordId: t.id,
          supabaseFilter: `technician_id=eq.${encodeURIComponent(t.id)}`,
          patch: {
            photo_url: "",
            photo_storage_path: "",
            photo_provider_id: "",
            updated_by_uid: currentUser.uid
          },
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await writeAuditLog("REMOVE_TECHNICIAN_PHOTO", "technicians", t.id, t.fullName);
        await refreshTable("technicians");
        showToast("Technician photo removed.");
      } catch (err) {
        showToast(`Remove photo failed: ${err.message}`, true);
      }
    });
  });

  listEl.querySelectorAll("[data-tech-soft-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const t = cachedTechnicians.find((x) => x.id === btn.dataset.techSoftDel);
      if (!t || !currentUser) return;
      const nextDeleted = !Boolean(t.isDeleted);
      try {
        const patch = {
          is_deleted: nextDeleted,
          deleted_at: nextDeleted ? new Date().toISOString() : null,
          updated_by_uid: currentUser.uid
        };
        await multiCloudDbUpdate({
          table: "technicians",
          categoryKey: "technicians",
          recordId: t.id,
          supabaseFilter: `technician_id=eq.${encodeURIComponent(t.id)}`,
          patch,
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await writeAuditLog(nextDeleted ? "SOFT_DELETE_TECHNICIAN" : "RESTORE_TECHNICIAN", "technicians", t.id, t.fullName);
        await refreshTable("technicians");
        showToast(nextDeleted ? "Technician soft-deleted from public directory." : "Technician restored.");
      } catch (err) {
        showToast(`Soft delete failed: ${err.message}`, true);
      }
    });
  });

  listEl.querySelectorAll("[data-tech-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.techDel;
      if (!(await openConfirmModal("Delete Technician", `Remove technician ${id} permanently?`))) return;
      try {
        await multiCloudDbDelete({
          table: "technicians",
          categoryKey: "technicians",
          recordId: id,
          supabaseFilter: `technician_id=eq.${encodeURIComponent(id)}`,
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await writeAuditLog("DELETE_TECHNICIAN", "technicians", id, "Removed technician");
        await refreshTable("technicians");
        showToast("Technician deleted.");
      } catch (err) {
        showToast(`Delete failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// PUSH NOTIFICATIONS (FCM HTTP v1 + IN-APP ALERTS — NEVER LOGS OUT)
// =========================================================================

$("push-audience")?.addEventListener("change", () => {
  const audience = $("push-audience").value;
  $("push-selected-users-wrap")?.classList.toggle("hidden", audience !== "SELECTED");
});

function renderPushUserChips() {
  const wrap = $("push-user-chips");
  if (!wrap) return;
  if (!cachedUsers.length) {
    wrap.innerHTML = `<span style="font-size:12px;color:var(--text-muted);">No user profiles loaded yet.</span>`;
    return;
  }
  const selected = new Set(
    ($("push-selected-uids")?.value || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
  );
  wrap.innerHTML = cachedUsers.slice(0, 60).map((u) => {
    const uid = u.userId || u.id;
    const label = `${u.displayName || "User"}${u.isVerifiedTechnician ? " ✓" : ""} (${uid.slice(0, 6)})`;
    return `<button type="button" class="user-chip ${selected.has(uid) ? "selected" : ""}" data-pick-uid="${escapeHtml(uid)}">${escapeHtml(label)}</button>`;
  }).join("");

  wrap.querySelectorAll("[data-pick-uid]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const uid = btn.dataset.pickUid;
      const input = $("push-selected-uids");
      const current = new Set(
        (input.value || "").split(",").map((s) => s.trim()).filter(Boolean)
      );
      if (current.has(uid)) current.delete(uid);
      else current.add(uid);
      input.value = Array.from(current).join(", ");
      renderPushUserChips();
    });
  });
}

$("push-selected-uids")?.addEventListener("input", renderPushUserChips);

$("push-image-file")?.addEventListener("change", async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    setBanner("push-result-banner", "Notification image must be 5 MB or less.", "error");
    return;
  }
  setBanner("push-result-banner", "Uploading notification image through Multi-Cloud Storage...", "info");
  try {
    const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
    const uploaded = await multiCloudUpload({
      bucketKey: "community",
      objectPath: `push_images/${Date.now()}.${ext}`,
      fileOrBlob: file,
      contentType: file.type || "image/jpeg"
    });
    if ($("push-image-url")) $("push-image-url").value = uploaded.publicUrl;
    setBanner(
      "push-result-banner",
      `Image uploaded to ${uploaded.providerName}${uploaded.failoverUsed ? " (Failover used)" : ""}.`,
      "success"
    );
  } catch (err) {
    setBanner("push-result-banner", `Image upload failed: ${err.message}. You can still send without an image.`, "warning");
  }
});

async function createInAppNotificationForUsers({ targetUids, type, title, body, imageUrl = "", targetRoute = "notifications" }) {
  if (!currentUser || !Array.isArray(targetUids) || !targetUids.length) return;
  const uniqueUids = Array.from(new Set(targetUids.filter(Boolean))).slice(0, 200);
  const cleanTitle = String(title).slice(0, 140);
  const cleanBody = String(body).slice(0, 600);
  const cleanImg = /^https:\/\//i.test(imageUrl) ? imageUrl : "";
  const cleanRoute = String(targetRoute || "notifications").slice(0, 160);
  const rows = uniqueUids.map((recipientUid) => ({
    notification_id: slugId("notif"),
    recipient_uid: recipientUid,
    actor_uid: currentUser.uid,
    type,
    title: cleanTitle,
    body: cleanBody,
    image_url: cleanImg,
    target_route: cleanRoute,
    is_read: false
  }));
  await sbUpsert("user_notifications", rows, "notification_id", currentUser);
}

async function sendAutomatedPushAndInApp({ audience, targetUids = [], eventType, title, body, imageUrl = "", targetRoute = "notifications" }) {
  if (!currentUser) return;
  const cleanTitle = String(title || "").trim().slice(0, 140);
  const cleanBody = String(body || "").trim().slice(0, 1200);
  const cleanImage = /^https:\/\//i.test(String(imageUrl || "").trim()) ? String(imageUrl).trim() : "";

  if (audience === "ALL") {
    const annId = slugId("ann");
    const cat = ["GENERAL", "UPDATE", "GUIDE", "NEW_GUIDE", "NEW_PDF", "SAFETY", "COMMUNITY"].includes(eventType)
      ? eventType
      : "GENERAL";
    await sbUpsert("announcements", {
      announcement_id: annId,
      title: cleanTitle,
      body: cleanBody,
      category: cat,
      image_url: cleanImage,
      target_route: String(targetRoute || "notifications").slice(0, 160),
      created_by_uid: currentUser.uid
    }, "announcement_id", currentUser);
    refreshTable("announcements");
  } else {
    let resolvedUids = targetUids;
    if (audience === "TECHNICIANS" && !resolvedUids.length) {
      resolvedUids = cachedUsers.filter((u) => u.isVerifiedTechnician).map((u) => u.userId || u.id);
    }
    const notifType = ["POST_APPROVED", "POST_REJECTED", "VERIFICATION_APPROVED", "VERIFICATION_REJECTED", "VERIFICATION_SUSPENDED", "NEW_PDF", "ANNOUNCEMENT"].includes(eventType)
      ? eventType
      : "ANNOUNCEMENT";
    await createInAppNotificationForUsers({
      targetUids: resolvedUids,
      type: notifType,
      title: cleanTitle,
      body: cleanBody,
      imageUrl: cleanImage,
      targetRoute
    });
  }

  const rawEndpoint = ($("push-endpoint-url")?.value || storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT).trim();
  const endpoint = (!rawEndpoint || /\/send-fcm-v1$/i.test(rawEndpoint))
    ? DEFAULT_FCM_ENDPOINT
    : rawEndpoint;
  const pushId = slugId("push");
  let deliveryStatus = "IN_APP_ONLY";
  let sentCount = 0;
  let failedCount = 0;
  let errorMessage = "";

  if (endpoint && /^https?:\/\//i.test(endpoint)) {
    try {
      const idToken = await currentUser.getIdToken(false);
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${idToken}`
        },
        body: JSON.stringify({
          audience,
          targetUids,
          eventType,
          title: cleanTitle,
          body: cleanBody,
          imageUrl: cleanImage,
          targetRoute
        })
      });
      const payload = await response.json().catch(() => ({}));
      if (response.ok && payload.ok !== false) {
        sentCount = Number(payload.sentCount || 0);
        failedCount = Number(payload.failedCount || 0);
        deliveryStatus = payload.deliveryStatus || (sentCount > 0 ? (failedCount > 0 ? "PARTIAL" : "SENT") : "SENT");
        errorMessage = payload.message ? String(payload.message).slice(0, 500) : "";
      } else {
        deliveryStatus = "FAILED";
        errorMessage = `FCM backend HTTP ${response.status}: ${payload?.error || payload?.message || response.statusText}`.slice(0, 500);
      }
    } catch (err) {
      deliveryStatus = "FAILED";
      errorMessage = `FCM network/CORS error (session kept active): ${err?.message || err}`.slice(0, 500);
    }
  }

  try {
    await sbUpsert("push_notification_history", {
      push_id: pushId,
      audience,
      event_type: String(eventType || "ANNOUNCEMENT").slice(0, 64),
      title: cleanTitle,
      body: cleanBody,
      image_url: cleanImage,
      target_route: String(targetRoute || "notifications").slice(0, 160),
      target_uids: Array.isArray(targetUids) ? targetUids.slice(0, 500) : [],
      delivery_status: deliveryStatus,
      sent_count: sentCount,
      failed_count: failedCount,
      error_message: errorMessage,
      created_by_uid: currentUser.uid,
      created_by_email: currentUser.email || ""
    }, "push_id", currentUser);
    refreshTable("push_notification_history");
  } catch (err) {
    console.warn("push_notification_history log failed:", err?.message || err);
  }

  return { deliveryStatus, sentCount, failedCount, errorMessage };
}

async function handlePushSend(inAppOnly) {
  if (!currentUser) {
    setBanner("push-result-banner", "Please wait for Admin session verification before sending.", "warning");
    return;
  }
  const audience = $("push-audience")?.value || "ALL";
  const eventType = $("push-event-type")?.value || "ANNOUNCEMENT";
  const title = ($("push-title")?.value || "").trim();
  const body = ($("push-message")?.value || "").trim();
  const imageUrl = ($("push-image-url")?.value || "").trim();
  const targetRoute = $("push-route")?.value || "notifications";

  if (title.length < 2 || body.length < 2) {
    setBanner("push-result-banner", "Enter both a notification title (2+ chars) and message (2+ chars).", "error");
    return;
  }
  if (imageUrl && !/^https:\/\//i.test(imageUrl)) {
    setBanner("push-result-banner", "Optional notification image URL must start with https://.", "error");
    return;
  }

  let targetUids = [];
  if (audience === "SELECTED") {
    targetUids = ($("push-selected-uids")?.value || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (!targetUids.length) {
      setBanner("push-result-banner", "Select at least one target user UID for Selected Users audience.", "error");
      return;
    }
  } else if (audience === "TECHNICIANS") {
    targetUids = cachedUsers.filter((u) => u.isVerifiedTechnician).map((u) => u.userId || u.id);
  }

  const sendBtn = $("send-push-btn");
  const inAppBtn = $("save-inapp-only-btn");
  if (sendBtn) sendBtn.disabled = true;
  if (inAppBtn) inAppBtn.disabled = true;
  setBanner("push-result-banner", inAppOnly ? "Publishing in-app alert..." : "Dispatching FCM HTTP v1 push notification...", "info");

  try {
    if (inAppOnly) {
      if (audience === "ALL") {
        const annId = slugId("ann");
        await sbUpsert("announcements", {
          announcement_id: annId,
          title: title.slice(0, 140),
          body: body.slice(0, 1200),
          category: ["GENERAL", "UPDATE", "GUIDE", "NEW_GUIDE", "NEW_PDF", "SAFETY", "COMMUNITY"].includes(eventType) ? eventType : "GENERAL",
          image_url: imageUrl,
          target_route: targetRoute,
          created_by_uid: currentUser.uid
        }, "announcement_id", currentUser);
        refreshTable("announcements");
      } else {
        await createInAppNotificationForUsers({
          targetUids,
          type: eventType === "NEW_PDF" ? "NEW_PDF" : "ANNOUNCEMENT",
          title,
          body,
          imageUrl,
          targetRoute
        });
      }
      const pushId = slugId("push");
      await sbUpsert("push_notification_history", {
        push_id: pushId,
        audience,
        event_type: eventType,
        title: title.slice(0, 140),
        body: body.slice(0, 1200),
        image_url: imageUrl,
        target_route: targetRoute,
        target_uids: targetUids.slice(0, 500),
        delivery_status: "IN_APP_ONLY",
        sent_count: 0,
        failed_count: 0,
        error_message: "",
        created_by_uid: currentUser.uid,
        created_by_email: currentUser.email || ""
      }, "push_id", currentUser);
      refreshTable("push_notification_history");
      setBanner("push-result-banner", "In-app alert published without signing out or reloading.", "success");
      showToast("In-app notification published.");
    } else {
      const result = await sendAutomatedPushAndInApp({
        audience,
        targetUids,
        eventType,
        title,
        body,
        imageUrl,
        targetRoute
      });
      await writeAuditLog("SEND_PUSH_NOTIFICATION", "push_notifications", audience, `${title} (${result.deliveryStatus})`);
      if (result.deliveryStatus === "SENT" || result.deliveryStatus === "PARTIAL") {
        setBanner(
          "push-result-banner",
          `Push dispatched (${result.deliveryStatus}): ${result.sentCount} delivered, ${result.failedCount} failed. In-app notification synced.`,
          "success"
        );
        showToast(`Push sent to ${result.sentCount} device(s).`);
      } else {
        // Crucial: stay on Admin page, never log out!
        setBanner(
          "push-result-banner",
          `In-app alert saved, but FCM HTTP v1 push failed (${result.errorMessage}). Your Admin session stays active.`,
          "warning"
        );
        showToast("In-app saved; check FCM endpoint notice.", true);
      }
    }
    $("push-notification-form")?.reset();
    if ($("push-endpoint-url")) $("push-endpoint-url").value = storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT;
    $("push-selected-users-wrap")?.classList.add("hidden");
  } catch (err) {
    // Crucial fix: NEVER trigger signOut or redirect on any error!
    setBanner("push-result-banner", `Push request error (Admin session preserved): ${err.message}`, "error");
    showToast(`Push error: ${err.message}`, true);
  } finally {
    if (sendBtn) sendBtn.disabled = false;
    if (inAppBtn) inAppBtn.disabled = false;
  }
}

// Explicit click handlers + form submit prevention fix the login redirect bug
$("send-push-btn")?.addEventListener("click", (e) => {
  e.preventDefault();
  handlePushSend(false);
});
$("save-inapp-only-btn")?.addEventListener("click", (e) => {
  e.preventDefault();
  handlePushSend(true);
});
$("push-notification-form")?.addEventListener("submit", (e) => {
  e.preventDefault();
  handlePushSend(false);
});

function renderPushHistory() {
  const listEl = $("push-history-list");
  if (!listEl) return;
  if (!cachedPushHistory.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No push notification campaigns logged yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedPushHistory.slice(0, 40).map((p) => {
    const badgeClass = p.deliveryStatus === "SENT" ? "badge-green"
      : p.deliveryStatus === "FAILED" ? "badge-err"
      : p.deliveryStatus === "PARTIAL" ? "badge-warn" : "badge-cyan";
    return `
      <div class="list-item">
        <div class="list-header">
          <div>
            <span class="badge ${badgeClass}">${escapeHtml(p.deliveryStatus)}</span>
            <span class="badge badge-cyan">${escapeHtml(p.audience)}</span>
            <strong style="margin-left:6px;">${escapeHtml(p.title)}</strong>
          </div>
          <span style="font-size:11px;color:var(--text-muted);">${escapeHtml(formatTs(p.createdAt))}</span>
        </div>
        <div style="font-size:13px;color:var(--text-muted);margin-bottom:4px;">${escapeHtml(p.body)}</div>
        <div style="font-size:12px;color:var(--text-muted);">
          Sent: <strong>${Number(p.sentCount || 0)}</strong> • Failed: <strong>${Number(p.failedCount || 0)}</strong>
          ${p.imageUrl ? ` • <a href="${escapeHtml(safeHref(p.imageUrl))}" target="_blank" rel="noopener">Image</a>` : ""}
          ${p.errorMessage ? `<div style="color:var(--warning);margin-top:4px;">${escapeHtml(p.errorMessage)}</div>` : ""}
        </div>
      </div>
    `;
  }).join("");
}

function renderAnnouncementsList() {
  const listEl = $("announcements-list");
  if (!listEl) return;
  if (!cachedAnnouncements.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No in-app announcements published yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedAnnouncements.slice(0, 30).map((a) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge badge-cyan">${escapeHtml(a.category || "GENERAL")}</span>
          <strong style="margin-left:6px;">${escapeHtml(a.title)}</strong>
        </div>
        <button type="button" class="btn btn-danger btn-sm" data-ann-del="${escapeHtml(a.id)}">Delete</button>
      </div>
      <div style="font-size:13px;color:var(--text-muted);">${escapeHtml(a.body)}</div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-ann-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.annDel;
      try {
        await sbDelete("announcements", `announcement_id=eq.${encodeURIComponent(id)}`, currentUser);
        await refreshTable("announcements");
        showToast("Announcement deleted.");
      } catch (err) {
        showToast(`Delete failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// TECHNICIAN VERIFICATION QUEUE (+ AUTO NOTIFICATION)
// =========================================================================

$("ver-filter-status")?.addEventListener("change", renderVerificationSection);

function renderVerificationSection() {
  if ($("ver-stat-pending")) $("ver-stat-pending").textContent = String(cachedVerifications.filter((v) => v.status === "PENDING").length);
  if ($("ver-stat-verified")) $("ver-stat-verified").textContent = String(cachedVerifications.filter((v) => v.status === "VERIFIED").length);
  if ($("ver-stat-rejected")) $("ver-stat-rejected").textContent = String(cachedVerifications.filter((v) => ["REJECTED", "SUSPENDED"].includes(v.status)).length);

  const filter = $("ver-filter-status")?.value || "PENDING";
  const items = cachedVerifications.filter((v) => filter === "ALL" || v.status === filter);
  const listEl = $("verification-requests-list");
  if (!listEl) return;
  if (!items.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No verification applications in this queue.</span></div>`;
    return;
  }

  listEl.innerHTML = items.map((v) => {
    const badge = v.status === "VERIFIED" ? "badge-green"
      : v.status === "PENDING" ? "badge-warn" : "badge-err";
    return `
      <div class="list-item">
        <div class="list-header">
          <div>
            <strong>${escapeHtml(v.fullName)}</strong>
            <span class="badge ${badge}">${escapeHtml(v.status)}</span>
            <div style="font-size:12px;color:var(--text-muted);">UID: ${escapeHtml(v.userId)} • ${escapeHtml(v.mobileNumber)} • ${escapeHtml(v.cityArea)}, ${escapeHtml(v.district)} (${escapeHtml(v.pinCode)})</div>
            <div style="font-size:12px;color:var(--cyan);">${escapeHtml((v.serviceCategories || []).join(", "))} ${v.experience ? `• ${escapeHtml(v.experience)}` : ""}</div>
            ${(v.credentialDocUrl || v.credentialDocStoragePath) ? `<div style="font-size:12px;margin-top:6px;"><button type="button" class="btn btn-outline btn-sm" data-ver-doc="${escapeHtml(v.id)}">View Credential Document (${escapeHtml(v.credentialDocName || "file")})</button></div>` : ""}
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button type="button" class="btn btn-success btn-sm" data-ver-action="VERIFIED" data-ver-uid="${escapeHtml(v.id)}">Approve</button>
            <button type="button" class="btn btn-danger btn-sm" data-ver-action="REJECTED" data-ver-uid="${escapeHtml(v.id)}">Reject</button>
            <button type="button" class="btn btn-outline btn-sm" data-ver-action="SUSPENDED" data-ver-uid="${escapeHtml(v.id)}">Suspend</button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  listEl.querySelectorAll("[data-ver-doc]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const v = cachedVerifications.find((x) => x.id === btn.dataset.verDoc);
      if (!v) return;
      try {
        const prov = getPrimarySupabaseProvider();
        const url = await openPrivateCredentialDocument(v, storageState, currentUser, prov, supabaseCreateSignedUrl);
        window.open(url, "_blank", "noopener,noreferrer");
      } catch (err) {
        showToast(`Signed document error: ${err.message}`, true);
      }
    });
  });

  listEl.querySelectorAll("[data-ver-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!currentUser) return;
      const uid = btn.dataset.verUid;
      const nextStatus = btn.dataset.verAction;
      const req = cachedVerifications.find((x) => x.id === uid);
      if (!req) return;
      const reason = nextStatus === "VERIFIED"
        ? ""
        : (window.prompt(`Enter ${nextStatus.toLowerCase()} note for ${req.fullName}:`, "") || "").trim();
      try {
        await multiCloudDbUpdate({
          table: "technician_verification_requests",
          categoryKey: "verification",
          recordId: uid,
          supabaseFilter: `user_id=eq.${encodeURIComponent(uid)}`,
          patch: {
            status: nextStatus,
            rejection_reason: reason,
            reviewed_by_uid: currentUser.uid
          },
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await multiCloudDbUpdate({
          table: "user_profiles",
          categoryKey: "user_profiles",
          recordId: uid,
          supabaseFilter: `user_id=eq.${encodeURIComponent(uid)}`,
          patch: {
            is_verified_technician: nextStatus === "VERIFIED"
          },
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        }).catch(() => {});

        const techDocId = `tech_${uid}`;
        if (nextStatus === "VERIFIED") {
          await multiCloudDbUpsert({
            table: "technicians",
            categoryKey: "technicians",
            record: {
              technician_id: techDocId,
              full_name: req.fullName,
              photo_url: req.profilePhotoUrl || "",
              photo_storage_path: req.profilePhotoStoragePath || "",
              photo_provider_id: req.profilePhotoProviderId || "supabase_primary",
              mobile_number: req.mobileNumber,
              full_address: req.fullAddress,
              state: req.state,
              district: req.district,
              city_area: req.cityArea,
              pin_code: req.pinCode,
              service_categories: req.serviceCategories || ["AC"],
              experience: req.experience || "",
              bio: req.bio || "",
              verification_status: "VERIFIED",
              blocked: false,
              linked_user_uid: uid,
              status: "ACTIVE",
              updated_by_uid: currentUser.uid
            },
            onConflict: "technician_id",
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
        }

        const title = nextStatus === "VERIFIED"
          ? "Technician Verification Approved"
          : nextStatus === "SUSPENDED" ? "Technician Verification Suspended" : "Technician Verification Update";
        const body = nextStatus === "VERIFIED"
          ? "Congratulations! Your verified technician badge is now live in Repair Pro."
          : (reason || `Your verification status is now ${nextStatus}.`);
        await sendAutomatedPushAndInApp({
          audience: "SELECTED",
          targetUids: [uid],
          eventType: `VERIFICATION_${nextStatus}`,
          title,
          body,
          targetRoute: "verification"
        });
        await writeAuditLog("REVIEW_VERIFICATION", "technician_verification_requests", uid, `${req.fullName} -> ${nextStatus}`);
        await Promise.allSettled([
          refreshTable("technician_verification_requests"),
          refreshTable("user_profiles"),
          refreshTable("technicians")
        ]);
        showToast(`Application marked ${nextStatus} & user notified.`);
      } catch (err) {
        showToast(`Verification update failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// COMMUNITY MODERATION (+ AUTO POST APPROVAL NOTIFICATIONS)
// =========================================================================

$("comm-filter-status")?.addEventListener("change", renderCommunitySection);
$("comm-filter-category")?.addEventListener("change", renderCommunitySection);

function renderCommunitySection() {
  if ($("comm-stat-pending")) $("comm-stat-pending").textContent = String(cachedCommunityPosts.filter((p) => p.approvalStatus === "PENDING").length);
  if ($("comm-stat-approved")) $("comm-stat-approved").textContent = String(cachedCommunityPosts.filter((p) => p.approvalStatus === "APPROVED").length);
  if ($("comm-stat-rejected")) $("comm-stat-rejected").textContent = String(cachedCommunityPosts.filter((p) => p.approvalStatus === "REJECTED").length);
  if ($("comm-stat-reports")) $("comm-stat-reports").textContent = String(cachedCommunityReports.filter((r) => r.status === "OPEN").length);

  const sFilter = $("comm-filter-status")?.value || "PENDING";
  const cFilter = $("comm-filter-category")?.value || "ALL";
  const posts = cachedCommunityPosts.filter((p) => {
    const matchesStatus = sFilter === "ALL"
      ? true
      : sFilter === "HIDDEN"
        ? (Boolean(p.isHidden) || Boolean(p.isDeleted))
        : (p.approvalStatus === sFilter && !p.isDeleted);
    const matchesCat = cFilter === "ALL" || p.category === cFilter;
    return matchesStatus && matchesCat;
  });

  const postsEl = $("community-posts-list");
  if (postsEl) {
    postsEl.innerHTML = posts.length
      ? posts.map((p) => {
          const urls = Array.isArray(p.photoUrls) && p.photoUrls.length
            ? p.photoUrls
            : (p.photoUrl ? [p.photoUrl] : []);
          const photosHtml = urls.length
            ? `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;">` +
              urls.map((u, idx) => `
                <div style="display:flex;flex-direction:column;gap:4px;align-items:flex-start;">
                  <a href="${escapeHtml(safeHref(u))}" target="_blank" rel="noopener">
                    <img src="${escapeHtml(safeHref(u))}" alt="Post photo ${idx + 1}" style="width:76px;height:76px;object-fit:cover;border-radius:8px;border:1px solid var(--border);" />
                  </a>
                  <button type="button" class="btn btn-danger btn-sm" style="padding:2px 6px;font-size:11px;" data-post-rm-photo="${escapeHtml(p.id)}" data-photo-idx="${idx}">Remove Photo</button>
                </div>
              `).join("") +
              `</div>`
            : "";
          return `
            <div class="list-item">
              <div class="list-header">
                <div>
                  <span class="badge ${p.approvalStatus === "APPROVED" ? "badge-green" : p.approvalStatus === "PENDING" ? "badge-warn" : "badge-err"}">${escapeHtml(p.approvalStatus)}</span>
                  ${p.isPinned ? `<span class="badge badge-cyan">PINNED</span>` : ""}
                  ${p.isHidden ? `<span class="badge badge-warn">HIDDEN</span>` : ""}
                  ${p.isDeleted ? `<span class="badge badge-err">SOFT DELETED</span>` : ""}
                  <strong style="margin-left:6px;">${escapeHtml(p.title)}</strong>
                  <div style="font-size:12px;color:var(--text-muted);">By ${escapeHtml(p.authorName)} • ${escapeHtml(p.category)} ${p.brandName ? `• ${escapeHtml(p.brandName)}` : ""} ${p.errorCode ? `(${escapeHtml(p.errorCode)})` : ""} • ${escapeHtml(formatTs(p.createdAt))}</div>
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                  <button type="button" class="btn btn-success btn-sm" data-post-mod="APPROVED" data-post-id="${escapeHtml(p.id)}">Approve</button>
                  <button type="button" class="btn btn-danger btn-sm" data-post-mod="REJECTED" data-post-id="${escapeHtml(p.id)}">Reject</button>
                  <button type="button" class="btn btn-outline btn-sm" data-post-pin="${escapeHtml(p.id)}">${p.isPinned ? "Unpin" : "Pin"}</button>
                  <button type="button" class="btn btn-outline btn-sm" data-post-hide="${escapeHtml(p.id)}">${p.isHidden ? "Unhide" : "Hide"}</button>
                  <button type="button" class="btn btn-outline btn-sm" data-post-edit="${escapeHtml(p.id)}">Edit</button>
                  <button type="button" class="btn btn-outline btn-sm" data-post-soft-del="${escapeHtml(p.id)}">${p.isDeleted ? "Restore" : "Soft Delete"}</button>
                  <button type="button" class="btn btn-outline btn-sm" data-post-block="${escapeHtml(p.authorUid)}" data-author-name="${escapeHtml(p.authorName)}">Block User</button>
                  <button type="button" class="btn btn-danger btn-sm" data-post-perm-del="${escapeHtml(p.id)}">Delete</button>
                </div>
              </div>
              <div style="font-size:13px;color:var(--text-muted);">${escapeHtml(p.body)}</div>
              ${photosHtml}
            </div>
          `;
        }).join("")
      : `<div class="list-item"><span style="color:var(--text-muted);">No community posts in this filter.</span></div>`;

    postsEl.querySelectorAll("[data-post-mod]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!currentUser) return;
        const postId = btn.dataset.postId;
        const nextStatus = btn.dataset.postMod;
        const post = cachedCommunityPosts.find((x) => x.id === postId);
        if (!post) return;
        try {
          await multiCloudDbUpdate({
            table: "community_posts",
            categoryKey: "community",
            recordId: postId,
            supabaseFilter: `post_id=eq.${encodeURIComponent(postId)}`,
            patch: {
              approval_status: nextStatus,
              reviewed_by_uid: currentUser.uid
            },
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          if (post.authorUid) {
            await sendAutomatedPushAndInApp({
              audience: "SELECTED",
              targetUids: [post.authorUid],
              eventType: nextStatus === "APPROVED" ? "POST_APPROVED" : "POST_REJECTED",
              title: nextStatus === "APPROVED" ? "Community Post Approved" : "Community Post Update",
              body: nextStatus === "APPROVED"
                ? `Your post "${post.title}" is now live in the Repair Pro Community.`
                : `Your post "${post.title}" was not approved by moderators.`,
              targetRoute: "community"
            });
          }
          await writeAuditLog("MODERATE_COMMUNITY_POST", "community_posts", postId, `${post.title} -> ${nextStatus}`);
          await refreshTable("community_posts");
          showToast(`Post marked ${nextStatus} & author notified.`);
        } catch (err) {
          showToast(`Moderation failed: ${err.message}`, true);
        }
      });
    });

    postsEl.querySelectorAll("[data-post-pin]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const post = cachedCommunityPosts.find((x) => x.id === btn.dataset.postPin);
        if (!post) return;
        try {
          await multiCloudDbUpdate({
            table: "community_posts",
            categoryKey: "community",
            recordId: post.id,
            supabaseFilter: `post_id=eq.${encodeURIComponent(post.id)}`,
            patch: { is_pinned: !post.isPinned },
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await refreshTable("community_posts");
          showToast(post.isPinned ? "Post unpinned." : "Post pinned to top.");
        } catch (err) {
          showToast(`Pin failed: ${err.message}`, true);
        }
      });
    });

    postsEl.querySelectorAll("[data-post-hide]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const post = cachedCommunityPosts.find((x) => x.id === btn.dataset.postHide);
        if (!post || !currentUser) return;
        const nextHidden = !Boolean(post.isHidden);
        try {
          await multiCloudDbUpdate({
            table: "community_posts",
            categoryKey: "community",
            recordId: post.id,
            supabaseFilter: `post_id=eq.${encodeURIComponent(post.id)}`,
            patch: { is_hidden: nextHidden, reviewed_by_uid: currentUser.uid },
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await writeAuditLog(nextHidden ? "HIDE_COMMUNITY_POST" : "UNHIDE_COMMUNITY_POST", "community_posts", post.id, post.title);
          await refreshTable("community_posts");
          showToast(nextHidden ? "Post hidden from feed." : "Post restored to feed.");
        } catch (err) {
          showToast(`Hide toggle failed: ${err.message}`, true);
        }
      });
    });

    postsEl.querySelectorAll("[data-post-edit]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const post = cachedCommunityPosts.find((x) => x.id === btn.dataset.postEdit);
        if (!post || !currentUser) return;
        const nextTitle = (window.prompt("Edit post title (3-140 chars):", post.title || "") || "").trim();
        if (nextTitle.length < 3) {
          showToast("Title must be at least 3 characters.", true);
          return;
        }
        const nextBody = (window.prompt("Edit post description (5-3000 chars):", post.body || "") || "").trim();
        if (nextBody.length < 5 && !(post.photoUrl || (Array.isArray(post.photoUrls) && post.photoUrls.length))) {
          showToast("Description must be at least 5 characters when no photo is attached.", true);
          return;
        }
        const nextBrand = (window.prompt("Edit brand (optional):", post.brandName || "") || "").trim();
        const nextCode = (window.prompt("Edit error code (optional):", post.errorCode || "") || "").trim();
        try {
          await multiCloudDbUpdate({
            table: "community_posts",
            categoryKey: "community",
            recordId: post.id,
            supabaseFilter: `post_id=eq.${encodeURIComponent(post.id)}`,
            patch: {
              title: nextTitle.slice(0, 140),
              body: nextBody.slice(0, 3000),
              brand_name: nextBrand.slice(0, 80),
              error_code: nextCode.slice(0, 32),
              reviewed_by_uid: currentUser.uid
            },
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await writeAuditLog("EDIT_COMMUNITY_POST", "community_posts", post.id, nextTitle);
          await refreshTable("community_posts");
          showToast("Community post updated.");
        } catch (err) {
          showToast(`Edit failed: ${err.message}`, true);
        }
      });
    });

    postsEl.querySelectorAll("[data-post-rm-photo]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const post = cachedCommunityPosts.find((x) => x.id === btn.dataset.postRmPhoto);
        const idx = Number(btn.dataset.photoIdx || 0);
        if (!post || !currentUser) return;
        if (!(await openConfirmModal("Remove Post Photo", `Remove attached photo #${idx + 1} from "${post.title}"?`, "Remove Photo"))) return;
        const currUrls = Array.isArray(post.photoUrls) && post.photoUrls.length ? [...post.photoUrls] : (post.photoUrl ? [post.photoUrl] : []);
        const currPaths = Array.isArray(post.photoStoragePaths) && post.photoStoragePaths.length ? [...post.photoStoragePaths] : (post.photoStoragePath ? [post.photoStoragePath] : []);
        const currProviders = Array.isArray(post.photoProviderIds) ? [...post.photoProviderIds] : [];
        currUrls.splice(idx, 1);
        if (idx < currPaths.length) currPaths.splice(idx, 1);
        if (idx < currProviders.length) currProviders.splice(idx, 1);
        if (!currUrls.length && String(post.body || "").trim().length < 5) {
          showToast("Cannot remove last photo when post body is under 5 characters. Edit text first.", true);
          return;
        }
        try {
          await multiCloudDbUpdate({
            table: "community_posts",
            categoryKey: "community",
            recordId: post.id,
            supabaseFilter: `post_id=eq.${encodeURIComponent(post.id)}`,
            patch: {
              photo_url: currUrls[0] || "",
              photo_storage_path: currPaths[0] || "",
              photo_urls: currUrls,
              photo_storage_paths: currPaths,
              photo_provider_ids: currProviders,
              reviewed_by_uid: currentUser.uid
            },
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await writeAuditLog("REMOVE_POST_PHOTO", "community_posts", post.id, `Removed photo #${idx + 1}`);
          await refreshTable("community_posts");
          showToast("Post photo removed.");
        } catch (err) {
          showToast(`Remove photo failed: ${err.message}`, true);
        }
      });
    });

    postsEl.querySelectorAll("[data-post-soft-del]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const post = cachedCommunityPosts.find((x) => x.id === btn.dataset.postSoftDel);
        if (!post || !currentUser) return;
        const nextDeleted = !Boolean(post.isDeleted);
        try {
          await multiCloudDbUpdate({
            table: "community_posts",
            categoryKey: "community",
            recordId: post.id,
            supabaseFilter: `post_id=eq.${encodeURIComponent(post.id)}`,
            patch: {
              is_deleted: nextDeleted,
              deleted_by_uid: nextDeleted ? currentUser.uid : "",
              deleted_at: nextDeleted ? new Date().toISOString() : null,
              reviewed_by_uid: currentUser.uid
            },
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await writeAuditLog(nextDeleted ? "SOFT_DELETE_COMMUNITY_POST" : "RESTORE_COMMUNITY_POST", "community_posts", post.id, post.title);
          await refreshTable("community_posts");
          showToast(nextDeleted ? "Post soft-deleted." : "Post restored.");
        } catch (err) {
          showToast(`Soft delete failed: ${err.message}`, true);
        }
      });
    });

    postsEl.querySelectorAll("[data-post-perm-del]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const postId = btn.dataset.postPermDel;
        if (!(await openConfirmModal("Delete Community Post", `Permanently delete community post "${postId}"?`))) return;
        try {
          await multiCloudDbDelete({
            table: "community_posts",
            categoryKey: "community",
            recordId: postId,
            supabaseFilter: `post_id=eq.${encodeURIComponent(postId)}`,
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await writeAuditLog("DELETE_COMMUNITY_POST", "community_posts", postId, "Permanent delete");
          await refreshTable("community_posts");
          showToast("Community post deleted permanently.");
        } catch (err) {
          showToast(`Delete failed: ${err.message}`, true);
        }
      });
    });

    postsEl.querySelectorAll("[data-post-block]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!currentUser) return;
        const uid = btn.dataset.postBlock;
        const name = btn.dataset.authorName || "User";
        const reason = (window.prompt(`Reason for blocking ${name} from posting:`, "Community guideline violation") || "").trim();
        if (!reason) return;
        try {
          await multiCloudDbUpsert({
            table: "community_user_restrictions",
            categoryKey: "community",
            record: {
              user_id: uid,
              user_name: name.slice(0, 80),
              is_blocked: true,
              can_post: false,
              can_comment: false,
              can_upload_photo: false,
              reason: reason.slice(0, 400),
              blocked_by_uid: currentUser.uid
            },
            onConflict: "user_id",
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await refreshTable("community_user_restrictions");
          showToast(`${name} blocked from community posting.`);
        } catch (err) {
          showToast(`Block failed: ${err.message}`, true);
        }
      });
    });
  }

  const reportsEl = $("community-reports-list");
  if (reportsEl) {
    reportsEl.innerHTML = cachedCommunityReports.length
      ? cachedCommunityReports.map((r) => `
          <div class="list-item">
            <div class="list-header">
              <strong>${escapeHtml(r.reason)} — Post ${escapeHtml(r.postId)}</strong>
              <span class="badge ${r.status === "OPEN" ? "badge-warn" : "badge-green"}">${escapeHtml(r.status)}</span>
            </div>
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">Reported by ${escapeHtml(r.reporterName)} • ${escapeHtml(r.details || "")}</div>
            <button type="button" class="btn btn-outline btn-sm" data-creport-resolve="${escapeHtml(r.id)}">Mark Resolved</button>
          </div>
        `).join("")
      : `<div class="list-item"><span style="color:var(--text-muted);">No community reports found.</span></div>`;
    reportsEl.querySelectorAll("[data-creport-resolve]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await multiCloudDbUpdate({
            table: "community_reports",
            categoryKey: "community",
            recordId: btn.dataset.creportResolve,
            supabaseFilter: `report_id=eq.${encodeURIComponent(btn.dataset.creportResolve)}`,
            patch: { status: "RESOLVED" },
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await refreshTable("community_reports");
          showToast("Report marked resolved.");
        } catch (err) {
          showToast(`Update failed: ${err.message}`, true);
        }
      });
    });
  }

  const restrEl = $("community-restrictions-list");
  if (restrEl) {
    restrEl.innerHTML = cachedCommunityRestrictions.length
      ? cachedCommunityRestrictions.map((r) => `
          <div class="list-item">
            <div class="list-header">
              <div><strong>${escapeHtml(r.userName || r.userId)}</strong><div style="font-size:12px;color:var(--text-muted);">${escapeHtml(r.reason)}</div></div>
              <button type="button" class="btn btn-outline btn-sm" data-unblock-uid="${escapeHtml(r.id)}">Unblock</button>
            </div>
          </div>
        `).join("")
      : `<div class="list-item"><span style="color:var(--text-muted);">No blocked community users.</span></div>`;
    restrEl.querySelectorAll("[data-unblock-uid]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await multiCloudDbDelete({
            table: "community_user_restrictions",
            categoryKey: "community",
            recordId: btn.dataset.unblockUid,
            supabaseFilter: `user_id=eq.${encodeURIComponent(btn.dataset.unblockUid)}`,
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await refreshTable("community_user_restrictions");
          showToast("User unblocked.");
        } catch (err) {
          showToast(`Unblock failed: ${err.message}`, true);
        }
      });
    });
  }
}

// =========================================================================
// PDF MANUALS & CIRCUIT DIAGRAMS (MULTI-CLOUD UPLOAD + AUTO PUSH)
// =========================================================================

$("tech-doc-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const file = $("doc-file-input")?.files?.[0];
  const title = $("doc-title")?.value.trim();
  if (!file || !title) {
    showToast("Select a PDF/image file and enter a title.", true);
    return;
  }
  if (file.size > 20 * 1024 * 1024) {
    showToast("Technical documents must be 20 MB or smaller.", true);
    return;
  }
  const docType = $("doc-type").value;
  const bucketKey = docType === "PDF_MANUAL" ? "pdfs" : docType === "CIRCUIT_DIAGRAM" ? "diagrams" : "community";
  const docId = slugId("doc");
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-60);
  const uploadBtn = $("doc-upload-btn");
  if (uploadBtn) uploadBtn.disabled = true;
  $("doc-upload-progress-wrap")?.classList.remove("hidden");

  try {
    const uploaded = await multiCloudUpload({
      bucketKey,
      objectPath: `${docId}_${safeName}`,
      fileOrBlob: file,
      contentType: file.type || (docType === "PDF_MANUAL" ? "application/pdf" : "image/png"),
      onProgress: (p) => {
        if ($("doc-upload-progress-fill")) $("doc-upload-progress-fill").style.width = `${Math.round(p * 100)}%`;
      }
    });

    const offlineAvailable = docType === "PDF_MANUAL" && Boolean($("doc-offline-available")?.checked);
    await multiCloudDbUpsert({
      table: "technical_documents",
      categoryKey: bucketKey,
      record: {
        doc_id: docId,
        doc_type: docType,
        category_id: $("doc-category").value,
        brand_name: $("doc-brand").value.trim(),
        model_name: $("doc-model").value.trim(),
        linked_entry_id: $("doc-linked-entry").value.trim(),
        title,
        description: $("doc-description").value.trim(),
        file_url: uploaded.publicUrl,
        storage_path: uploaded.storagePath,
        storage_provider_id: uploaded.providerId || "supabase_primary",
        mime_type: file.type || "application/pdf",
        file_size_bytes: Number(file.size || 0),
        published: $("doc-published").checked,
        offline_available: offlineAvailable,
        is_deleted: false,
        uploaded_by_uid: currentUser.uid
      },
      onConflict: "doc_id",
      currentUser,
      storageState,
      migrationConfig: migrationConfigState
    });

    if ($("doc-notify-users")?.checked && $("doc-published")?.checked) {
      await sendAutomatedPushAndInApp({
        audience: "ALL",
        eventType: "NEW_PDF",
        title: `New ${docType === "PDF_MANUAL" ? "PDF Manual" : "Diagram"}: ${title}`.slice(0, 140),
        body: `${$("doc-brand").value.trim() || "Repair Pro"} technical resource is now available to view in the app.`,
        targetRoute: "documents"
      });
    }

    await writeAuditLog("UPLOAD_TECHNICAL_DOCUMENT", "technical_documents", docId, `${title} -> ${uploaded.providerName} (offline=${offlineAvailable})`);
    await refreshTable("technical_documents");
    $("tech-doc-form")?.reset();
    showToast(`Document uploaded to ${uploaded.providerName}${uploaded.failoverUsed ? " (Failover)" : ""}.`);
  } catch (err) {
    showToast(`Document upload failed: ${err.message}`, true);
  } finally {
    if (uploadBtn) uploadBtn.disabled = false;
  }
});

function renderDocumentsList() {
  const listEl = $("technical-documents-list");
  if (!listEl) return;
  if (!cachedDocuments.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No technical documents uploaded yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedDocuments.map((d) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge badge-cyan">${escapeHtml(d.docType)}</span>
          <span class="badge ${d.published ? "badge-green" : "badge-warn"}">${d.published ? "LIVE" : "HIDDEN"}</span>
          ${d.offlineAvailable ? `<span class="badge badge-green">OFFLINE OK</span>` : ""}
          ${d.isDeleted ? `<span class="badge badge-err">SOFT DELETED</span>` : ""}
          <strong style="margin-left:6px;">${escapeHtml(d.title)}</strong>
          <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(String(d.categoryId || "").toUpperCase())} ${d.brandName ? `• ${escapeHtml(d.brandName)}` : ""} • ${formatBytes(d.fileSizeBytes)}</div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          <a class="btn btn-outline btn-sm" href="${escapeHtml(safeHref(d.fileUrl))}" target="_blank" rel="noopener">Open</a>
          ${d.docType === "PDF_MANUAL" ? `<button type="button" class="btn btn-outline btn-sm" data-doc-offline="${escapeHtml(d.id)}">${d.offlineAvailable ? "Disable Offline" : "Allow Offline"}</button>` : ""}
          <button type="button" class="btn btn-outline btn-sm" data-doc-replace="${escapeHtml(d.id)}">Replace File</button>
          <button type="button" class="btn btn-outline btn-sm" data-doc-soft-del="${escapeHtml(d.id)}">${d.isDeleted ? "Restore" : "Soft Delete"}</button>
          <button type="button" class="btn btn-danger btn-sm" data-doc-del="${escapeHtml(d.id)}">Delete</button>
        </div>
      </div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-doc-offline]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const d = cachedDocuments.find((x) => x.id === btn.dataset.docOffline);
      if (!d || !currentUser) return;
      const nextOffline = !Boolean(d.offlineAvailable);
      try {
        await multiCloudDbUpdate({
          table: "technical_documents",
          categoryKey: "pdfs",
          recordId: d.id,
          supabaseFilter: `doc_id=eq.${encodeURIComponent(d.id)}`,
          patch: { offline_available: nextOffline },
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await writeAuditLog("TOGGLE_DOC_OFFLINE", "technical_documents", d.id, `${d.title} offlineAvailable=${nextOffline}`);
        await refreshTable("technical_documents");
        showToast(nextOffline ? "Offline PDF caching enabled for users." : "Offline PDF caching disabled (device caches auto-clean).");
      } catch (err) {
        showToast(`Offline toggle failed: ${err.message}`, true);
      }
    });
  });

  listEl.querySelectorAll("[data-doc-replace]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const d = cachedDocuments.find((x) => x.id === btn.dataset.docReplace);
      if (!d || !currentUser) return;
      const picker = document.createElement("input");
      picker.type = "file";
      picker.accept = "application/pdf,image/jpeg,image/png,image/webp";
      picker.onchange = async () => {
        const file = picker.files?.[0];
        if (!file) return;
        if (file.size > 20 * 1024 * 1024) {
          showToast("Replacement file must be 20 MB or smaller.", true);
          return;
        }
        const bucketKey = d.docType === "PDF_MANUAL" ? "pdfs" : d.docType === "CIRCUIT_DIAGRAM" ? "diagrams" : "community";
        const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-60);
        try {
          const uploaded = await multiCloudUpload({
            bucketKey,
            objectPath: `${d.id}_${Date.now()}_${safeName}`,
            fileOrBlob: file,
            contentType: file.type || d.mimeType || "application/pdf"
          });
          await multiCloudDbUpdate({
            table: "technical_documents",
            categoryKey: bucketKey,
            recordId: d.id,
            supabaseFilter: `doc_id=eq.${encodeURIComponent(d.id)}`,
            patch: {
              file_url: uploaded.publicUrl,
              storage_path: uploaded.storagePath,
              storage_provider_id: uploaded.providerId || d.storageProviderId || "supabase_primary",
              mime_type: file.type || d.mimeType || "application/pdf",
              file_size_bytes: Number(file.size || 0)
            },
            currentUser,
            storageState,
            migrationConfig: migrationConfigState
          });
          await writeAuditLog("REPLACE_TECHNICAL_DOCUMENT", "technical_documents", d.id, `${d.title} -> ${uploaded.storagePath}`);
          await refreshTable("technical_documents");
          showToast("Document file replaced.");
        } catch (err) {
          showToast(`Replace failed: ${err.message}`, true);
        }
      };
      picker.click();
    });
  });

  listEl.querySelectorAll("[data-doc-soft-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const d = cachedDocuments.find((x) => x.id === btn.dataset.docSoftDel);
      if (!d || !currentUser) return;
      const nextDeleted = !Boolean(d.isDeleted);
      try {
        await multiCloudDbUpdate({
          table: "technical_documents",
          categoryKey: "pdfs",
          recordId: d.id,
          supabaseFilter: `doc_id=eq.${encodeURIComponent(d.id)}`,
          patch: { is_deleted: nextDeleted },
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await writeAuditLog(nextDeleted ? "SOFT_DELETE_DOCUMENT" : "RESTORE_DOCUMENT", "technical_documents", d.id, d.title);
        await refreshTable("technical_documents");
        showToast(nextDeleted ? "Document soft-deleted from user library." : "Document restored.");
      } catch (err) {
        showToast(`Update failed: ${err.message}`, true);
      }
    });
  });

  listEl.querySelectorAll("[data-doc-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.docDel;
      if (!(await openConfirmModal("Delete Technical Document", `Delete document ${id}?`))) return;
      try {
        await multiCloudDbDelete({
          table: "technical_documents",
          categoryKey: "pdfs",
          recordId: id,
          supabaseFilter: `doc_id=eq.${encodeURIComponent(id)}`,
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await writeAuditLog("DELETE_TECHNICAL_DOCUMENT", "technical_documents", id, "Removed document");
        await refreshTable("technical_documents");
        showToast("Document removed.");
      } catch (err) {
        showToast(`Delete failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// MULTI-CLOUD STORAGE MANAGER UI
// =========================================================================

function syncStorageFormsFromState() {
  const supa = getPrimarySupabaseProvider();
  if ($("st-supabase-url")) $("st-supabase-url").value = supa.endpointUrl || getSupabaseUrl() || SUPABASE_URL;
  if ($("st-supabase-anon-key")) $("st-supabase-anon-key").value = supa.publicAnonKey || getSupabaseAnonKey() || "";
  if ($("st-fcm-endpoint")) $("st-fcm-endpoint").value = storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT;
  if ($("st-hosting-proxy-url")) $("st-hosting-proxy-url").value = storageState.hostingProxyUrl || DEFAULT_HOSTING_PROXY_URL;
  if ($("st-comp-max-dim")) $("st-comp-max-dim").value = storageState.compressionMaxDim || 1440;
  if ($("st-comp-quality")) $("st-comp-quality").value = storageState.compressionQuality || 82;
  if ($("st-comp-max-kb")) $("st-comp-max-kb").value = storageState.compressionMaxSizeKb || 4500;
  if ($("st-duplicate-check")) $("st-duplicate-check").checked = storageState.duplicateCheckEnabled !== false;
  if ($("push-endpoint-url") && !$("push-endpoint-url").value) {
    $("push-endpoint-url").value = storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT;
  }
  if ($("st-auto-failover")) $("st-auto-failover").checked = storageState.autoFailoverEnabled !== false;

  const phpProv = (storageState.providers || []).find((p) => p.providerType === "PHP_HOSTING");
  if (phpProv) {
    if ($("php-vendor") && phpProv.hostingVendor) $("php-vendor").value = phpProv.hostingVendor;
    if ($("php-name")) $("php-name").value = phpProv.providerName || "";
    if ($("php-endpoint-url")) $("php-endpoint-url").value = phpProv.endpointUrl || "";
    if ($("php-public-base-url")) $("php-public-base-url").value = phpProv.publicMediaBaseUrl || "";
    if ($("php-role")) $("php-role").value = phpProv.role === "PRIMARY" ? "PRIMARY" : "BACKUP";
    if ($("php-capacity-mb")) $("php-capacity-mb").value = Math.round((phpProv.capacityLimitBytes || 5368709120) / (1024 * 1024));
    if ($("php-supports-storage")) $("php-supports-storage").checked = phpProv.supportsStorage !== false;
    if ($("php-community-only")) $("php-community-only").checked = phpProv.communityOnly !== false;
    if ($("php-supports-db")) $("php-supports-db").checked = Boolean(phpProv.supportsDatabase);
    if ($("php-db-enabled")) $("php-db-enabled").checked = Boolean(phpProv.dbEnabled);
    if ($("php-db-engine") && phpProv.dbEngine) $("php-db-engine").value = phpProv.dbEngine;
  }
  renderCategoryRoutingSelects();
}

function renderCategoryRoutingSelects() {
  const categories = ["community", "technicians", "pdfs", "diagrams", "verification", "user_profiles"];
  const enabledProviders = (storageState.providers || []).filter((p) => p.enabled && p.supportsStorage !== false);
  const currentMap = storageState.categoryMappings || DEFAULT_STORAGE_ROUTING;
  categories.forEach((cat) => {
    const sel = $(`route-${cat}`);
    if (!sel) return;
    const eligible = enabledProviders.filter((p) => {
      if (p.providerType === "PHP_HOSTING" && p.communityOnly && !["community", "technicians"].includes(cat)) {
        return false;
      }
      return true;
    });
    const opts = (eligible.length ? eligible : [defaultSupabasePrimaryProvider()]).map(
      (p) => `<option value="${escapeHtml(p.providerId)}">${escapeHtml(p.providerName)} (${escapeHtml(p.providerType)})</option>`
    );
    sel.innerHTML = `<option value="">Auto Priority Chain (Default)</option>${opts.join("")}`;
    const savedVal = currentMap[cat] || "";
    if (savedVal && eligible.some((p) => p.providerId === savedVal)) {
      sel.value = savedVal;
    } else {
      sel.value = "";
    }
  });
}

function syncMigrationUiFromState() {
  const dbSel = $("mig-primary-db-provider");
  if (dbSel) {
    const extProviders = (storageState.providers || []).filter(
      (p) => p.enabled && p.supportsDatabase && p.dbEnabled && (p.providerType === "PHP_HOSTING" || p.providerType === "EXTERNAL_DB")
    );
    dbSel.innerHTML = `<option value="supabase_primary">Supabase PostgreSQL (Primary Default)</option>` +
      extProviders.map((p) => `<option value="${escapeHtml(p.providerId)}">${escapeHtml(p.providerName)} (${escapeHtml(p.dbEngine || "MYSQL")})</option>`).join("");
    const targetVal = migrationConfigState.primaryDbProviderId || "supabase_primary";
    dbSel.value = Array.from(dbSel.options).some((o) => o.value === targetVal) ? targetVal : "supabase_primary";
  }
  if ($("mig-db-threshold")) $("mig-db-threshold").value = migrationConfigState.dbMigrationThresholdPct ?? 80;
  if ($("mig-storage-threshold")) $("mig-storage-threshold").value = migrationConfigState.storageMigrationThresholdPct ?? 80;
  if ($("mig-fallback-urls")) $("mig-fallback-urls").value = (migrationConfigState.fallbackDiscoveryUrls || []).join(", ");
  if ($("mig-auto-enabled")) $("mig-auto-enabled").checked = Boolean(migrationConfigState.autoMigrationEnabled);
  if ($("mig-auto-cleanup")) $("mig-auto-cleanup").checked = Boolean(migrationConfigState.autoCleanupEnabled);
}

async function persistStorageConfigToSupabase() {
  if (!currentUser) return;
  const cleanProviders = sanitizeProvidersForStorage(storageState.providers);
  const categoryMappings = {
    ...DEFAULT_STORAGE_ROUTING,
    ...(storageState.categoryMappings || {})
  };
  await sbSaveSetting("storage_config", "STORAGE", {
    configType: "STORAGE",
    autoFailoverEnabled: Boolean(storageState.autoFailoverEnabled),
    fcmBackendUrl: String(storageState.fcmBackendUrl || DEFAULT_FCM_ENDPOINT).trim().slice(0, 500),
    hostingProxyUrl: String(storageState.hostingProxyUrl || DEFAULT_HOSTING_PROXY_URL).trim().slice(0, 500),
    compressionMaxDim: Math.min(4096, Math.max(480, Math.round(Number(storageState.compressionMaxDim || 1440)))),
    compressionQuality: Math.min(100, Math.max(40, Math.round(Number(storageState.compressionQuality || 82)))),
    compressionMaxSizeKb: Math.min(5120, Math.max(100, Math.round(Number(storageState.compressionMaxSizeKb || 4500)))),
    duplicateCheckEnabled: Boolean(storageState.duplicateCheckEnabled),
    categoryMappings,
    primaryDbProviderId: migrationConfigState.primaryDbProviderId || "supabase_primary",
    providersJson: JSON.stringify(cleanProviders).slice(0, 20000),
    configVersion: Number(migrationConfigState.configVersion || 1),
    updatedByUid: currentUser.uid
  }, currentUser.uid, currentUser).catch((err) => {
    console.warn("app_settings storage_config sync warning:", err?.message || err);
  });
  await syncStorageProvidersTable(storageState.providers, categoryMappings, currentUser.uid, currentUser).catch((err) => {
    console.warn("storage_providers table sync warning:", err?.message || err);
  });
  await syncDiscoveryManifestToExternalHosts(storageState, migrationConfigState, currentUser).catch(() => {});
  renderCategoryRoutingSelects();
  syncMigrationUiFromState();
}

async function refreshLiveUsageAndThresholdMonitor() {
  if (!currentUser) return;
  latestSupabaseMetrics = await fetchSupabaseUsageMetrics(currentUser, migrationConfigState);
  const evalRes = evaluateMigrationThresholds(latestSupabaseMetrics, migrationConfigState, storageState);

  const dbLimit = Math.max(1, Number(latestSupabaseMetrics.dbLimitBytes || migrationConfigState.dbLimitBytes || 524288000));
  const stLimit = Math.max(1, Number(latestSupabaseMetrics.storageLimitBytes || migrationConfigState.storageLimitBytes || FREE_TIER_STORAGE_LIMIT_BYTES));
  if ($("mig-supa-db-label")) {
    $("mig-supa-db-label").textContent = `${formatBytes(latestSupabaseMetrics.dbUsedBytes)} / ${formatBytes(dbLimit)} (${evalRes.dbPct}%)`;
  }
  if ($("mig-supa-db-bar")) $("mig-supa-db-bar").style.width = `${evalRes.dbPct}%`;
  if ($("mig-supa-st-label")) {
    $("mig-supa-st-label").textContent = `${formatBytes(latestSupabaseMetrics.storageUsedBytes)} / ${formatBytes(stLimit)} (${evalRes.storagePct}%)`;
  }
  if ($("mig-supa-st-bar")) $("mig-supa-st-bar").style.width = `${evalRes.storagePct}%`;

  const phpHost = (storageState.providers || []).find((p) => p.enabled && p.providerType === "PHP_HOSTING");
  if (phpHost) {
    try {
      latestCpanelStats = await fetchCpanelUsageMetrics(phpHost, currentUser);
      const used = Number(latestCpanelStats?.usedBytes || 0) + Number(latestCpanelStats?.dbUsedBytes || 0);
      const cap = Math.max(1, Number(phpHost.capacityLimitBytes || 1));
      const pct = Math.min(100, Math.round((used / cap) * 100));
      if ($("mig-cpanel-usage-label")) {
        $("mig-cpanel-usage-label").textContent = `Files: ${formatBytes(latestCpanelStats?.usedBytes || 0)} • DB: ${formatBytes(latestCpanelStats?.dbUsedBytes || 0)}`;
      }
      if ($("mig-cpanel-bar")) $("mig-cpanel-bar").style.width = `${pct}%`;
    } catch (err) {
      if ($("mig-cpanel-usage-label")) $("mig-cpanel-usage-label").textContent = `Offline / Check Host (${err.message})`;
    }
  } else {
    if ($("mig-cpanel-usage-label")) $("mig-cpanel-usage-label").textContent = "Not Connected (Supabase Only)";
    if ($("mig-cpanel-bar")) $("mig-cpanel-bar").style.width = "0%";
  }

  if (evalRes.shouldAutoMigrate && !autoMigrationRunning && evalRes.targetProvider) {
    autoMigrationRunning = true;
    try {
      setBanner("migration-status-banner", `Auto-migration triggered: ${evalRes.reasons.join("; ")}`, "warning");
      $("migration-progress-wrap")?.classList.remove("hidden");
      const res = await runCloudMigration({
        scope: "BOTH",
        triggerMode: evalRes.dbPct >= migrationConfigState.dbMigrationThresholdPct ? "AUTO_DB" : "AUTO_STORAGE",
        targetProvider: evalRes.targetProvider,
        supaProvider: getPrimarySupabaseProvider(),
        storageState,
        migrationConfig: migrationConfigState,
        currentUser,
        supabaseListObjectsFn: supabaseListObjects,
        supabaseCreateSignedUrlFn: supabaseCreateSignedUrl,
        onProgress: (pct, msg) => {
          if ($("migration-progress-fill")) $("migration-progress-fill").style.width = `${pct}%`;
          if ($("migration-progress-label")) $("migration-progress-label").textContent = msg;
        }
      });
      await Promise.allSettled([refreshTable("cloud_migration_runs"), refreshTable("cloud_backup_manifests")]);
      setBanner("migration-status-banner", `Auto-migration ${res.run.status}: ${res.run.verified_items}/${res.run.total_items} verified.`, res.run.failed_items === 0 ? "success" : "warning");
    } catch (err) {
      setBanner("migration-status-banner", `Auto-migration error: ${err.message}`, "error");
    } finally {
      autoMigrationRunning = false;
    }
  }
}

function renderMigrationRunsList() {
  const el = $("migration-runs-list");
  if (!el) return;
  if (!cachedMigrationRuns.length) {
    el.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No cloud migration runs executed yet. Supabase remains active primary.</span></div>`;
    return;
  }
  el.innerHTML = cachedMigrationRuns.map((r) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge ${r.status === "COMPLETED" ? "badge-green" : r.status === "PARTIAL" ? "badge-warn" : r.status === "FAILED" ? "badge-err" : "badge-cyan"}">${escapeHtml(r.status)}</span>
          <span class="badge badge-cyan">${escapeHtml(r.trigger_mode || "MANUAL")} • ${escapeHtml(r.scope || "BOTH")}</span>
          <strong style="margin-left:6px;">${escapeHtml(r.run_id)}</strong>
          <div style="font-size:12px;color:var(--text-muted);margin-top:4px;">
            Verified: <strong>${Number(r.verified_items || 0)}</strong> / ${Number(r.total_items || 0)} • Failed: <strong>${Number(r.failed_items || 0)}</strong> • Cleaned: ${Number(r.cleaned_items || 0)} • Size: ${formatBytes(r.total_bytes || 0)}
          </div>
          ${r.error_summary ? `<div style="font-size:11px;color:var(--warning);margin-top:2px;">${escapeHtml(r.error_summary)}</div>` : ""}
        </div>
        <span style="font-size:11px;color:var(--text-muted);">${escapeHtml(formatTs(r.started_at))}</span>
      </div>
    </div>
  `).join("");
}

function renderBackupManifestsList() {
  const el = $("migration-backups-list");
  if (!el) return;
  if (!cachedBackupManifests.length) {
    el.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No backup manifests generated yet. A full backup manifest is automatically created before any cleanup.</span></div>`;
    return;
  }
  el.innerHTML = cachedBackupManifests.map((m) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge ${m.status === "RESTORED" ? "badge-cyan" : "badge-green"}">${escapeHtml(m.status || "READY")}</span>
          <strong style="margin-left:6px;">${escapeHtml(m.backup_id)}</strong>
          <div style="font-size:12px;color:var(--text-muted);">
            Run: <code>${escapeHtml(m.run_id)}</code> • Items: ${Number(m.item_count || 0)} • ${formatBytes(m.total_bytes || 0)} • ${escapeHtml(formatTs(m.created_at))}
          </div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="button" class="btn btn-outline btn-sm" data-bkp-download="${escapeHtml(m.backup_id)}">Download JSON</button>
          <button type="button" class="btn btn-outline btn-sm" data-bkp-restore="${escapeHtml(m.backup_id)}">Restore / Rollback</button>
        </div>
      </div>
    </div>
  `).join("");

  el.querySelectorAll("[data-bkp-download]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const m = cachedBackupManifests.find((x) => x.backup_id === btn.dataset.bkpDownload);
      if (!m) return;
      const blob = new Blob([JSON.stringify(m.manifest_json || m, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `${m.backup_id}.json`;
      a.click();
    });
  });

  el.querySelectorAll("[data-bkp-restore]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const m = cachedBackupManifests.find((x) => x.backup_id === btn.dataset.bkpRestore);
      if (!m || !currentUser) return;
      if (!(await openConfirmModal("Restore From Backup Manifest", `Restore rows & files from backup "${m.backup_id}" back into Supabase?`, "Start Restore"))) return;
      const targetProv = (storageState.providers || []).find((p) => p.providerId === m.target_provider_id)
        || (storageState.providers || []).find((p) => p.providerType === "PHP_HOSTING");
      setBanner("migration-status-banner", `Restoring backup ${m.backup_id}...`, "info");
      try {
        const res = await restoreFromBackupManifest({
          manifestRecord: m,
          targetProvider: targetProv,
          supaProvider: getPrimarySupabaseProvider(),
          currentUser,
          supabaseUploadObjectFn: supabaseUploadObject
        });
        await refreshTable("cloud_backup_manifests");
        setBanner("migration-status-banner", `Rollback complete: restored ${res.restoredRows} table row(s) and ${res.restoredFiles} storage file(s).`, "success");
        showToast("Backup restored to Supabase.");
      } catch (err) {
        setBanner("migration-status-banner", `Restore failed: ${err.message}`, "error");
      }
    });
  });
}

$("mig-refresh-usage-btn")?.addEventListener("click", async () => {
  setBanner("migration-status-banner", "Querying live Supabase & cPanel usage...", "info");
  await refreshLiveUsageAndThresholdMonitor();
  setBanner("migration-status-banner", "Live usage metrics updated.", "success");
});

$("migration-config-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const fallbackUrls = ($("mig-fallback-urls")?.value || "")
    .split(",")
    .map((u) => u.trim())
    .filter((u) => /^https:\/\//i.test(u));
  const nextPrimaryDb = $("mig-primary-db-provider")?.value || "supabase_primary";

  migrationConfigState = normalizeMigrationConfig({
    ...migrationConfigState,
    autoFailoverEnabled: storageState.autoFailoverEnabled,
    autoMigrationEnabled: Boolean($("mig-auto-enabled")?.checked),
    autoCleanupEnabled: Boolean($("mig-auto-cleanup")?.checked),
    dbMigrationThresholdPct: Number($("mig-db-threshold")?.value || 80),
    storageMigrationThresholdPct: Number($("mig-storage-threshold")?.value || 80),
    primaryDbProviderId: nextPrimaryDb,
    fallbackDiscoveryUrls: fallbackUrls,
    configVersion: Number(migrationConfigState.configVersion || 1) + 1
  });

  if (nextPrimaryDb !== "supabase_primary") {
    storageState.providers = (storageState.providers || []).map((p) => {
      if (p.providerId === nextPrimaryDb) return { ...p, role: "PRIMARY", enabled: true };
      if (p.role === "PRIMARY") return { ...p, role: "BACKUP" };
      return p;
    });
  } else {
    storageState.providers = (storageState.providers || []).map((p) => {
      if (p.providerId === "supabase_primary") return { ...p, role: "PRIMARY", enabled: true };
      if (p.role === "PRIMARY") return { ...p, role: "BACKUP" };
      return p;
    });
  }

  try {
    await sbSaveSetting("migration_config", "MIGRATION", migrationConfigState, currentUser.uid, currentUser).catch(() => {});
    await persistStorageConfigToSupabase();
    renderStorageManager();
    await writeAuditLog("UPDATE_MIGRATION_POLICY", "app_settings", "migration_config", `primaryDb=${nextPrimaryDb}, autoMig=${migrationConfigState.autoMigrationEnabled}, autoCleanup=${migrationConfigState.autoCleanupEnabled}`);
    setBanner("migration-status-banner", "Migration policy, thresholds & primary DB routing saved and synced to discovery hosts.", "success");
    showToast("Migration policy saved.");
  } catch (err) {
    setBanner("migration-status-banner", `Failed to save migration policy: ${err.message}`, "error");
  }
});

async function handleManualMigration(scope) {
  if (!currentUser) return;
  const targetHost = (storageState.providers || []).find(
    (p) => p.enabled && p.providerType === "PHP_HOSTING" && /^https:\/\//i.test(p.endpointUrl || "")
  );
  if (!targetHost) {
    setBanner("migration-status-banner", "Connect and enable a cPanel PHP Hosting provider below before starting migration.", "warning");
    return;
  }
  $("migration-progress-wrap")?.classList.remove("hidden");
  setBanner("migration-status-banner", `Starting ${scope} migration to ${targetHost.providerName}...`, "info");
  try {
    const res = await runCloudMigration({
      scope,
      triggerMode: "MANUAL",
      targetProvider: targetHost,
      supaProvider: getPrimarySupabaseProvider(),
      storageState,
      migrationConfig: migrationConfigState,
      currentUser,
      supabaseListObjectsFn: supabaseListObjects,
      supabaseCreateSignedUrlFn: supabaseCreateSignedUrl,
      onProgress: (pct, msg) => {
        if ($("migration-progress-fill")) $("migration-progress-fill").style.width = `${pct}%`;
        if ($("migration-progress-label")) $("migration-progress-label").textContent = msg;
      }
    });
    await Promise.allSettled([refreshTable("cloud_migration_runs"), refreshTable("cloud_backup_manifests")]);
    setBanner(
      "migration-status-banner",
      `Migration ${res.run.status}: ${res.run.verified_items}/${res.run.total_items} verified, ${res.run.failed_items} failed. Backup manifest ${res.manifest.backup_id} saved.`,
      res.run.failed_items === 0 ? "success" : "warning"
    );
    showToast(`Migration ${res.run.status}.`);
  } catch (err) {
    setBanner("migration-status-banner", `Migration aborted: ${err.message}`, "error");
    showToast(`Migration error: ${err.message}`, true);
  }
}

$("mig-check-readiness-btn")?.addEventListener("click", async () => {
  const phpProv = (storageState.providers || []).find((p) => p.providerType === "PHP_HOSTING") || getOrBuildPhpProviderDraft();
  setBanner("migration-status-banner", "Running pre-activation hosting & database readiness checks...", "info");
  const tempSecret = ($("php-api-secret")?.value || "").trim();
  const res = await validateCpanelHostingReadiness(phpProv, currentUser, tempSecret, callHostingProxy);
  const el = $("migration-preflight-checklist");
  if (el) {
    el.innerHTML = res.checks.map((c) => `
      <div style="font-size:12px;margin:4px 0;color:${c.passed ? "var(--success)" : "var(--error)"};">
        ${c.passed ? "✓" : "✕"} <strong>${escapeHtml(c.name)}</strong>: ${escapeHtml(c.detail)}
      </div>
    `).join("");
  }
  setBanner(
    "migration-status-banner",
    res.ready ? "Pre-activation check PASSED! cPanel hosting is ready for failover & migration." : "Some pre-activation checks failed. See checklist below.",
    res.ready ? "success" : "warning"
  );
});

$("mig-run-full-btn")?.addEventListener("click", () => handleManualMigration("BOTH"));
$("mig-run-db-btn")?.addEventListener("click", () => handleManualMigration("DATABASE"));
$("mig-run-storage-btn")?.addEventListener("click", () => handleManualMigration("STORAGE"));

$("mig-retry-btn")?.addEventListener("click", async () => {
  const latestRun = cachedMigrationRuns.find((r) => Number(r.failed_items || 0) > 0) || cachedMigrationRuns[0];
  const targetHost = (storageState.providers || []).find((p) => p.providerId === latestRun?.target_provider_id)
    || (storageState.providers || []).find((p) => p.enabled && p.providerType === "PHP_HOSTING");
  if (!latestRun || !targetHost) {
    setBanner("migration-status-banner", "No migration run or target cPanel host found to retry.", "warning");
    return;
  }
  $("migration-progress-wrap")?.classList.remove("hidden");
  try {
    const res = await retryFailedMigrationItems({
      run: latestRun,
      targetProvider: targetHost,
      supaProvider: getPrimarySupabaseProvider(),
      currentUser,
      supabaseCreateSignedUrlFn: supabaseCreateSignedUrl,
      onProgress: (pct, msg) => {
        if ($("migration-progress-fill")) $("migration-progress-fill").style.width = `${pct}%`;
        if ($("migration-progress-label")) $("migration-progress-label").textContent = msg;
      }
    });
    await refreshTable("cloud_migration_runs");
    setBanner("migration-status-banner", `Retried ${res.retried} item(s): ${res.succeeded} verified, ${res.remainingFailed} remaining.`, res.remainingFailed === 0 ? "success" : "warning");
  } catch (err) {
    setBanner("migration-status-banner", `Retry failed: ${err.message}`, "error");
  }
});

$("mig-cleanup-btn")?.addEventListener("click", async () => {
  const latestRun = cachedMigrationRuns.find((r) => r.status === "COMPLETED") || cachedMigrationRuns[0];
  const targetHost = (storageState.providers || []).find((p) => p.providerId === latestRun?.target_provider_id)
    || (storageState.providers || []).find((p) => p.enabled && p.providerType === "PHP_HOSTING");
  if (!latestRun || !targetHost) {
    setBanner("migration-status-banner", "No completed migration run available for cleanup.", "warning");
    return;
  }
  if (!(await openConfirmModal("Cleanup Verified Supabase Files", `Remove only 100% SHA-256 verified storage copies for run ${latestRun.run_id} from Supabase? Original backup manifest remains preserved.`, "Verify & Cleanup"))) {
    return;
  }
  try {
    const res = await executeVerifiedCleanup({
      run: latestRun,
      targetProvider: targetHost,
      supaProvider: getPrimarySupabaseProvider(),
      migrationConfig: migrationConfigState,
      currentUser,
      supabaseDeleteObjectFn: supabaseDeleteObject,
      fetchUsageMetricsFn: fetchSupabaseUsageMetrics
    });
    await Promise.allSettled([refreshTable("cloud_migration_runs"), refreshLiveUsageAndThresholdMonitor()]);
    setBanner("migration-status-banner", `Safe cleanup complete: removed ${res.cleanedCount} verified object(s) and reclaimed ${formatBytes(res.reclaimedBytes || 0)}.`, "success");
    showToast(`Cleaned ${res.cleanedCount} verified copies.`);
  } catch (err) {
    setBanner("migration-status-banner", `Cleanup blocked: ${err.message}`, "error");
  }
});

function renderPartialCloudAvailabilityBanner() {
  const failures = getPartialCloudFailures();
  const el = $("cloud-partial-availability-banner");
  if (!el) return;
  if (!failures.length) {
    el.classList.add("hidden");
    el.textContent = "";
    return;
  }
  const sources = Array.from(new Set(failures.flatMap((f) => f.failedSources || [])));
  setBanner(
    "cloud-partial-availability-banner",
    `Partial Cloud Warning: Records stored only on unreachable host(s) (${sources.join(", ")}) are temporarily unavailable; showing all reachable records.`,
    "warning"
  );
}

async function refreshSchedulerStatusCard() {
  const res = await fetchSchedulerStatus(currentUser, storageState).catch(() => null);
  const st = res?.schedulerStatus || null;
  if (!st) return;
  if ($("mig-scheduler-status")) {
    $("mig-scheduler-status").textContent = `${st.status || "IDLE"} (${st.worker_type || res.source || "CRON"})`;
  }
  if ($("mig-scheduler-last-run")) {
    $("mig-scheduler-last-run").textContent = st.last_run_at || st.ranAt ? formatTs(st.last_run_at || st.ranAt) : "Never";
  }
  if ($("mig-scheduler-reclaimed")) {
    $("mig-scheduler-reclaimed").textContent = formatBytes(Number(st.reclaimed_bytes || 0));
  }
  if ($("mig-scheduler-last-error")) {
    $("mig-scheduler-last-error").textContent = st.last_error
      ? `${st.last_status || "ERROR"}: ${st.last_error}`
      : (st.last_status || st.localHealth || "OK");
  }
}

$("mig-scheduler-refresh-btn")?.addEventListener("click", async () => {
  await refreshSchedulerStatusCard();
  showToast("24x7 scheduler status refreshed.");
});

$("mig-scheduler-tick-btn")?.addEventListener("click", async () => {
  if (!currentUser) return;
  setBanner("migration-status-banner", "Triggering 24x7 server-side migration worker tick...", "info");
  try {
    const res = await triggerServerSideMigrationTick(currentUser, storageState, true);
    await Promise.allSettled([
      refreshSchedulerStatusCard(),
      refreshTable("cloud_migration_runs"),
      refreshTable("cloud_backup_manifests"),
      refreshLiveUsageAndThresholdMonitor()
    ]);
    const detail = res.skipped
      ? `Scheduler tick idle (${res.reason || "below threshold / no host"}).`
      : `Scheduler tick finished (${res.status || "OK"}): ${res.verifiedItems || 0}/${res.totalItems || 0} verified, ${formatBytes(res.reclaimedBytes || 0)} reclaimed.`;
    setBanner("migration-status-banner", detail, res.ok === false ? "warning" : "success");
    showToast("Server-side worker tick complete.");
  } catch (err) {
    setBanner("migration-status-banner", `Scheduler tick note: ${err.message}`, "warning");
  }
});

$("category-routing-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const nextMappings = {
    community: $("route-community")?.value || "",
    technicians: $("route-technicians")?.value || "",
    pdfs: $("route-pdfs")?.value || "",
    diagrams: $("route-diagrams")?.value || "",
    verification: $("route-verification")?.value || "",
    user_profiles: $("route-user_profiles")?.value || ""
  };
  storageState.categoryMappings = nextMappings;
  try {
    await persistStorageConfigToSupabase();
    await writeAuditLog("UPDATE_CATEGORY_ROUTING", "app_settings", "storage_config", JSON.stringify(nextMappings));
    setBanner("storage-routing-banner", "Per-category storage routing saved to Supabase app_settings & storage_providers.", "success");
    showToast("Category storage routing saved.");
  } catch (err) {
    setBanner("storage-routing-banner", `Failed to save category routing: ${err.message}`, "error");
  }
});

$("storage-connection-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const supaUrl = ($("st-supabase-url")?.value || SUPABASE_URL).trim().replace(/\/+$/, "");
  const supaAnon = ($("st-supabase-anon-key")?.value || "").trim();
  const fcmUrl = ($("st-fcm-endpoint")?.value || DEFAULT_FCM_ENDPOINT).trim();
  const proxyUrl = ($("st-hosting-proxy-url")?.value || DEFAULT_HOSTING_PROXY_URL).trim();
  const maxDim = Math.min(4096, Math.max(480, Math.round(Number($("st-comp-max-dim")?.value || 1440))));
  const quality = Math.min(100, Math.max(40, Math.round(Number($("st-comp-quality")?.value || 82))));
  const maxKb = Math.min(5120, Math.max(100, Math.round(Number($("st-comp-max-kb")?.value || 4500))));
  const dupCheck = $("st-duplicate-check") ? Boolean($("st-duplicate-check").checked) : true;
  const autoFailover = Boolean($("st-auto-failover")?.checked);

  if (supaUrl) setSupabaseUrl(supaUrl);
  if (supaAnon) setSupabaseAnonKey(supaAnon);

  let foundSupa = false;
  storageState.providers = (storageState.providers || []).map((p) => {
    if (p.providerId === "supabase_primary" || (!foundSupa && p.providerType === "SUPABASE_STORAGE")) {
      foundSupa = true;
      return {
        ...p,
        endpointUrl: supaUrl,
        publicAnonKey: supaAnon,
        lastStatus: supaAnon ? "CONFIGURED" : "NEEDS_ANON_KEY"
      };
    }
    return p;
  });
  if (!foundSupa) {
    storageState.providers.unshift({
      ...defaultSupabasePrimaryProvider(),
      endpointUrl: supaUrl,
      publicAnonKey: supaAnon
    });
  }
  storageState.autoFailoverEnabled = autoFailover;
  storageState.fcmBackendUrl = fcmUrl;
  storageState.hostingProxyUrl = /^https:\/\//i.test(proxyUrl) ? proxyUrl : DEFAULT_HOSTING_PROXY_URL;
  storageState.compressionMaxDim = maxDim;
  storageState.compressionQuality = quality;
  storageState.compressionMaxSizeKb = maxKb;
  storageState.duplicateCheckEnabled = dupCheck;
  if ($("push-endpoint-url")) $("push-endpoint-url").value = fcmUrl;

  try {
    await persistStorageConfigToSupabase();
    await writeAuditLog("UPDATE_STORAGE_CONFIG", "app_settings", "storage_config", `Primary=${supaUrl}, Failover=${autoFailover}, MaxDim=${maxDim}`);
    setBanner("storage-config-banner", "Storage & compression settings saved and synced to Supabase app_settings/storage_config.", "success");
    showToast("Storage config synced.");
  } catch (err) {
    setBanner("storage-config-banner", `Failed to save storage config: ${err.message}`, "error");
  }
});

async function callHostingProxy(payload) {
  if (!currentUser) throw new Error("Sign in as Super Admin first.");
  const proxyUrl = String(storageState.hostingProxyUrl || DEFAULT_HOSTING_PROXY_URL).trim();
  const idToken = await currentUser.getIdToken();
  const resp = await fetch(proxyUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${idToken}`
    },
    body: JSON.stringify(payload)
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok || data.ok === false) {
    throw new Error(data.message || `Hosting proxy HTTP ${resp.status}`);
  }
  return data;
}

function getOrBuildPhpProviderDraft() {
  const vendor = ($("php-vendor")?.value || "Hostinger").trim();
  const name = ($("php-name")?.value || `${vendor} Shared Hosting`).trim();
  const endpointUrl = ($("php-endpoint-url")?.value || "").trim().replace(/\/+$/, "");
  const publicMediaBaseUrl = ($("php-public-base-url")?.value || "").trim().replace(/\/+$/, "");
  const role = ($("php-role")?.value || "BACKUP") === "PRIMARY" ? "PRIMARY" : "BACKUP";
  const capMb = Math.max(100, Number($("php-capacity-mb")?.value || 5120));
  const supportsStorage = $("php-supports-storage") ? Boolean($("php-supports-storage").checked) : true;
  const communityOnly = $("php-community-only") ? Boolean($("php-community-only").checked) : true;
  const supportsDatabase = $("php-supports-db") ? Boolean($("php-supports-db").checked) : false;
  const dbEnabled = $("php-db-enabled") ? Boolean($("php-db-enabled").checked) : false;
  const dbEngine = ($("php-db-engine")?.value || "MYSQL").trim().toUpperCase();
  const existing = (storageState.providers || []).find((p) => p.providerType === "PHP_HOSTING");
  return {
    providerId: existing?.providerId || `php_${vendor.toLowerCase().replace(/[^a-z0-9]+/g, "_")}`,
    providerName: name,
    providerType: "PHP_HOSTING",
    endpointUrl,
    publicAnonKey: "",
    proxyUploadUrl: storageState.hostingProxyUrl || DEFAULT_HOSTING_PROXY_URL,
    hostingVendor: vendor,
    publicMediaBaseUrl,
    supportsStorage,
    communityOnly,
    supportsDatabase,
    dbEnabled,
    dbEngine,
    role,
    enabled: true,
    capacityLimitBytes: capMb * 1024 * 1024,
    usedBytes: existing?.usedBytes || 0,
    lastStatus: existing?.lastStatus || "CONFIGURED",
    buckets: { ...DEFAULT_SUPABASE_BUCKETS }
  };
}

$("php-vendor")?.addEventListener("change", () => {
  const v = $("php-vendor").value;
  if ($("php-name") && !$("php-name").value.trim()) {
    $("php-name").value = `${v} Community Media`;
  }
});

$("php-hosting-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const draft = getOrBuildPhpProviderDraft();
  if (!/^https:\/\//i.test(draft.endpointUrl) || (draft.supportsStorage && !/^https:\/\//i.test(draft.publicMediaBaseUrl))) {
    setBanner("php-hosting-banner", "PHP API Endpoint URL (and Public Media Base URL when file uploads are enabled) must start with https://", "error");
    return;
  }
  const secret = ($("php-api-secret")?.value || "").trim();
  if (secret && secret.length < 16) {
    setBanner("php-hosting-banner", "PHP API Secret must be at least 16 characters.", "error");
    return;
  }
  try {
    if (secret) {
      await callHostingProxy({ action: "save_secret", providerId: draft.providerId, apiSecret: secret });
      if ($("php-api-secret")) $("php-api-secret").value = "";
    }
    const normalized = normalizeProvider(draft);
    const others = (storageState.providers || []).filter((p) => p.providerId !== normalized.providerId);
    const updatedList = normalized.role === "PRIMARY"
      ? others.map((p) => (p.role === "PRIMARY" ? { ...p, role: "BACKUP" } : p))
      : others;
    storageState.providers = [...updatedList, normalized];
    await persistStorageConfigToSupabase();
    renderStorageManager();
    await writeAuditLog("SAVE_PHP_HOSTING", "app_settings", "storage_config", `${normalized.hostingVendor}: ${normalized.endpointUrl} (storage=${normalized.supportsStorage}, db=${normalized.dbEnabled})`);
    setBanner("php-hosting-banner", `Shared hosting provider "${normalized.providerName}" saved & synced.${secret ? " Secret stored securely on backend." : ""}`, "success");
    showToast("Shared web hosting saved.");
  } catch (err) {
    setBanner("php-hosting-banner", `Could not save shared hosting: ${err.message}`, "error");
  }
});

$("php-save-secret-btn")?.addEventListener("click", async () => {
  const draft = getOrBuildPhpProviderDraft();
  const secret = ($("php-api-secret")?.value || "").trim();
  if (secret.length < 16) {
    setBanner("php-hosting-banner", "Enter a strong PHP API Secret (at least 16 characters) matching config.php.", "error");
    return;
  }
  try {
    await callHostingProxy({ action: "save_secret", providerId: draft.providerId, apiSecret: secret });
    if ($("php-api-secret")) $("php-api-secret").value = "";
    setBanner("php-hosting-banner", `Backend hosting secret saved securely for ${draft.providerId} (never written to Supabase public tables or APK).`, "success");
    showToast("Hosting secret stored.");
  } catch (err) {
    setBanner("php-hosting-banner", `Failed to store hosting secret: ${err.message}`, "error");
  }
});

$("php-test-btn")?.addEventListener("click", async () => {
  const draft = getOrBuildPhpProviderDraft();
  if (!/^https:\/\//i.test(draft.endpointUrl)) {
    setBanner("php-hosting-banner", "Enter your HTTPS PHP API Endpoint URL first (e.g. https://yourdomain.com/repairpro-api/index.php).", "error");
    return;
  }
  setBanner("php-hosting-banner", "Testing shared hosting PHP API health & upload directory permissions...", "info");
  try {
    const tempSecret = ($("php-api-secret")?.value || "").trim();
    const readiness = await validateCpanelHostingReadiness(draft, currentUser, tempSecret, callHostingProxy);
    const res = readiness.health || {};
    const phpVer = res.phpVersion ? `PHP ${res.phpVersion}` : "PHP OK";
    const writable = (res.writable || res.uploadsWritable) ? "uploads writable" : "check folder permissions";
    setBanner("php-hosting-banner", `${readiness.ready ? "Ready!" : "Partial:"} ${draft.hostingVendor} (${phpVer}, ${writable}).`, readiness.ready ? "success" : "warning");
    showToast(readiness.ready ? "Shared hosting verified." : "Check readiness warnings.");
  } catch (err) {
    setBanner("php-hosting-banner", `Connection check failed: ${err.message}`, "error");
  }
});

$("php-db-health-btn")?.addEventListener("click", async () => {
  const draft = getOrBuildPhpProviderDraft();
  if (!/^https:\/\//i.test(draft.endpointUrl)) {
    setBanner("php-hosting-banner", "Enter your HTTPS PHP API Endpoint URL first.", "error");
    return;
  }
  setBanner("php-hosting-banner", "Testing cPanel/PHP external SQL database connectivity...", "info");
  try {
    const res = await callCpanelDirect(draft.endpointUrl, "db_health", {}, currentUser).catch(async () => {
      const tempSecret = ($("php-api-secret")?.value || "").trim();
      return await callHostingProxy({
        action: "db_health",
        providerId: draft.providerId,
        uploadApiUrl: draft.endpointUrl,
        endpointUrl: draft.endpointUrl,
        tempApiSecret: tempSecret || undefined
      });
    });
    setBanner("php-hosting-banner", `External SQL DB connected! Engine: ${res.driver || res.engine || draft.dbEngine}, Status: ${res.status || res.dbStatus || "READY"}.`, "success");
    showToast("External SQL DB healthy.");
  } catch (err) {
    setBanner("php-hosting-banner", `External SQL DB check failed: ${err.message}`, "error");
  }
});

$("php-db-init-btn")?.addEventListener("click", async () => {
  const draft = getOrBuildPhpProviderDraft();
  if (!/^https:\/\//i.test(draft.endpointUrl)) {
    setBanner("php-hosting-banner", "Enter your HTTPS PHP API Endpoint URL first.", "error");
    return;
  }
  setBanner("php-hosting-banner", "Initializing SQL schema on external cPanel/PHP host...", "info");
  try {
    const res = await callCpanelDirect(draft.endpointUrl, "db_init_schema", {}, currentUser).catch(async () => {
      const tempSecret = ($("php-api-secret")?.value || "").trim();
      return await callHostingProxy({
        action: "db_init_schema",
        providerId: draft.providerId,
        uploadApiUrl: draft.endpointUrl,
        endpointUrl: draft.endpointUrl,
        tempApiSecret: tempSecret || undefined
      });
    });
    await writeAuditLog("INIT_PHP_EXTERNAL_DB", "storage_providers", draft.providerId, `Engine=${draft.dbEngine}`);
    setBanner("php-hosting-banner", `External SQL schema initialized (${res.message || "tables ready"}).`, "success");
    showToast("External SQL schema ready.");
  } catch (err) {
    setBanner("php-hosting-banner", `External DB schema init failed: ${err.message}`, "error");
  }
});

$("st-test-failover-btn")?.addEventListener("click", async () => {
  const ordered = getOrderedActiveProviders();
  if (ordered.length < 2) {
    setBanner("storage-config-banner", "Add and enable at least one BACKUP provider below to test multi-cloud failover.", "warning");
    return;
  }
  const primary = ordered[0];
  const backup = ordered[1];
  await logStorageError(primary.providerId, "diagnostic-check", "failover_dry_run", "Simulated primary outage check (Admin Test)", backup.providerId);
  setBanner(
    "storage-config-banner",
    `Failover verified: Primary "${primary.providerName}" -> Backup "${backup.providerName}" (Auto-Failover ${storageState.autoFailoverEnabled ? "ON" : "OFF"}).`,
    "success"
  );
});

$("add-provider-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const pType = $("prov-type").value;
  const pName = $("prov-name").value.trim();
  const pEndpoint = $("prov-endpoint").value.trim().replace(/\/+$/, "");
  const pKeyOrProxy = $("prov-key-or-proxy").value.trim();
  const capMb = Math.max(100, Number($("prov-capacity-mb").value || 1024));
  const role = $("prov-role").value;

  if (!pName || !pEndpoint) {
    showToast("Provider name and endpoint URL are required.", true);
    return;
  }

  const newProv = normalizeProvider({
    providerId: slugId("prov"),
    providerName: pName,
    providerType: pType,
    endpointUrl: pEndpoint,
    publicAnonKey: pType === "SUPABASE_STORAGE" ? pKeyOrProxy : "",
    proxyUploadUrl: pType !== "SUPABASE_STORAGE" && pType !== "FIREBASE_LEGACY" ? pKeyOrProxy : "",
    role,
    enabled: true,
    capacityLimitBytes: capMb * 1024 * 1024,
    usedBytes: 0,
    lastStatus: "ADDED"
  });

  if (role === "PRIMARY") {
    storageState.providers = storageState.providers.map((p) => (p.role === "PRIMARY" ? { ...p, role: "BACKUP" } : p));
  }
  storageState.providers.push(newProv);

  try {
    await persistStorageConfigToSupabase();
    renderStorageManager();
    await writeAuditLog("ADD_STORAGE_PROVIDER", "app_settings", "storage_config", `${pName} (${pType})`);
    $("add-provider-form").reset();
    showToast(`Added storage provider "${pName}".`);
  } catch (err) {
    showToast(`Failed to add provider: ${err.message}`, true);
  }
});

async function testProviderConnection(provider) {
  try {
    if (provider.providerType === "SUPABASE_STORAGE") {
      if (!provider.publicAnonKey && !getSupabaseAnonKey()) {
        throw new Error("Public Anon Key is required to test Supabase Storage.");
      }
      const resp = await supabaseFetchWithAuth(provider, `${provider.endpointUrl}/storage/v1/bucket`);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      provider.lastStatus = "ONLINE";
      showToast(`${provider.providerName} connected (HTTP ${resp.status}).`);
    } else if (provider.providerType === "PHP_HOSTING") {
      await callHostingProxy({
        action: "test_connection",
        providerId: provider.providerId,
        uploadApiUrl: provider.endpointUrl,
        endpointUrl: provider.endpointUrl
      });
      provider.lastStatus = "ONLINE";
      showToast(`${provider.providerName} PHP Hosting API verified.`);
    } else if (provider.providerType === "FIREBASE_LEGACY") {
      provider.lastStatus = "READY";
      showToast("Legacy compatibility adapter ready.");
    } else {
      if (!provider.proxyUploadUrl) throw new Error("Signed Upload Proxy URL not configured.");
      provider.lastStatus = "PROXY_SET";
      showToast(`Signed proxy configured at ${provider.proxyUploadUrl}.`);
    }
    await persistStorageConfigToSupabase();
    renderStorageManager();
  } catch (err) {
    provider.lastStatus = "ERROR";
    showToast(`Connection test failed for ${provider.providerName}: ${err.message}`, true);
    renderStorageManager();
  }
}

function renderStorageStats() {
  const primary = (storageState.providers || []).find((p) => p.enabled && p.role === "PRIMARY") || storageState.providers[0];
  if ($("st-stat-active-primary")) $("st-stat-active-primary").textContent = primary ? primary.providerName : "Supabase";
  if ($("st-stat-providers")) $("st-stat-providers").textContent = String((storageState.providers || []).length);
  const trackedBytes = cachedUploadHistory
    .filter((u) => u.status === "SUCCESS")
    .reduce((acc, u) => acc + Number(u.sizeBytes || 0), 0);
  if ($("st-stat-used")) $("st-stat-used").textContent = formatBytes(trackedBytes);
  if ($("st-stat-errors")) $("st-stat-errors").textContent = String(cachedErrorLogs.filter((e) => !e.resolved).length);
}

function renderStorageManager() {
  renderStorageStats();
  const listEl = $("storage-providers-list");
  if (listEl) {
    listEl.innerHTML = (storageState.providers || []).map((p) => {
      const pct = Math.min(100, Math.round((Number(p.usedBytes || 0) / Math.max(1, Number(p.capacityLimitBytes || 1))) * 100));
      const scopeTag = p.providerType === "PHP_HOSTING"
        ? `<span class="badge badge-cyan">${p.communityOnly ? "COMMUNITY ONLY" : "ALL BUCKETS"}</span>`
        : "";
      return `
        <div class="list-item">
          <div class="list-header">
            <div>
              <span class="badge ${p.role === "PRIMARY" ? "badge-green" : p.enabled ? "badge-cyan" : "badge-err"}">${escapeHtml(p.role)}</span>
              <span class="badge ${p.enabled ? "badge-green" : "badge-warn"}">${p.enabled ? "ENABLED" : "DISABLED"}</span>
              ${scopeTag}
              <strong style="margin-left:6px;">${escapeHtml(p.providerName)}</strong>
              <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(p.providerType)}${p.hostingVendor ? ` (${escapeHtml(p.hostingVendor)})` : ""} • ${escapeHtml(p.endpointUrl)} • Status: ${escapeHtml(p.lastStatus)}</div>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;">
              <button type="button" class="btn btn-outline btn-sm" data-prov-test="${escapeHtml(p.providerId)}">Test</button>
              <button type="button" class="btn btn-outline btn-sm" data-prov-role="PRIMARY" data-prov-id="${escapeHtml(p.providerId)}">Set Primary</button>
              <button type="button" class="btn btn-outline btn-sm" data-prov-role="BACKUP" data-prov-id="${escapeHtml(p.providerId)}">Set Backup</button>
              <button type="button" class="btn btn-outline btn-sm" data-prov-toggle="${escapeHtml(p.providerId)}">${p.enabled ? "Disable" : "Enable"}</button>
            </div>
          </div>
          <div class="progress-track" style="margin-top:8px;"><div class="progress-fill" style="width:${pct}%;"></div></div>
          <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Used ${formatBytes(p.usedBytes)} / ${formatBytes(p.capacityLimitBytes)} (${pct}%)</div>
        </div>
      `;
    }).join("");

    listEl.querySelectorAll("[data-prov-test]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const prov = storageState.providers.find((x) => x.providerId === btn.dataset.provTest);
        if (prov) testProviderConnection(prov);
      });
    });

    listEl.querySelectorAll("[data-prov-role]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const targetId = btn.dataset.provId;
        const nextRole = btn.dataset.provRole;
        storageState.providers = storageState.providers.map((p) => {
          if (p.providerId === targetId) return { ...p, role: nextRole, enabled: true };
          if (nextRole === "PRIMARY" && p.role === "PRIMARY") return { ...p, role: "BACKUP" };
          return p;
        });
        await persistStorageConfigToSupabase();
        renderStorageManager();
        showToast(`Provider updated to ${nextRole}.`);
      });
    });

    listEl.querySelectorAll("[data-prov-toggle]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const targetId = btn.dataset.provToggle;
        storageState.providers = storageState.providers.map((p) =>
          p.providerId === targetId ? { ...p, enabled: !p.enabled } : p
        );
        await persistStorageConfigToSupabase();
        renderStorageManager();
        showToast("Provider availability updated.");
      });
    });
  }

  const fmProv = $("fm-provider-select");
  if (fmProv) {
    const prev = fmProv.value;
    fmProv.innerHTML = (storageState.providers || [])
      .filter((p) => p.providerType === "SUPABASE_STORAGE" || p.providerType === "PHP_HOSTING")
      .map((p) => `<option value="${escapeHtml(p.providerId)}">${escapeHtml(p.providerName)}</option>`)
      .join("");
    if (prev) fmProv.value = prev;
  }
}

$("fm-refresh-btn")?.addEventListener("click", async () => {
  const filesEl = $("storage-files-list");
  if (!filesEl) return;
  const provId = $("fm-provider-select")?.value;
  const prov = (storageState.providers || []).find((p) => p.providerId === provId) || getPrimarySupabaseProvider();
  const bucket = $("fm-bucket-select")?.value || "community-photos";
  filesEl.innerHTML = `<div class="list-item">Loading files from ${escapeHtml(bucket)}...</div>`;
  try {
    if (prov.providerType === "PHP_HOSTING") {
      const res = await callHostingProxy({
        action: "list_files",
        providerId: prov.providerId,
        uploadApiUrl: prov.endpointUrl,
        endpointUrl: prov.endpointUrl,
        bucketName: bucket
      });
      const items = Array.isArray(res.files) ? res.files : [];
      if (!items.length) {
        filesEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No files uploaded to PHP folder "${escapeHtml(bucket)}" yet.</span></div>`;
        return;
      }
      filesEl.innerHTML = items.map((it) => `
        <div class="list-item">
          <div class="list-header">
            <div>
              <strong>${escapeHtml(it.name || it.storagePath || "file")}</strong>
              <div style="font-size:12px;color:var(--text-muted);">${formatBytes(it.sizeBytes || 0)} • ${escapeHtml(it.updatedAt || "")}</div>
            </div>
            <div style="display:flex;gap:8px;">
              ${it.publicUrl ? `<a class="btn btn-outline btn-sm" href="${escapeHtml(safeHref(it.publicUrl))}" target="_blank" rel="noopener">Open</a>` : ""}
              <button type="button" class="btn btn-danger btn-sm" data-php-del="${escapeHtml(it.storagePath || `${bucket}/${it.name}`)}">Delete</button>
            </div>
          </div>
        </div>
      `).join("");

      filesEl.querySelectorAll("[data-php-del]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const storagePath = btn.dataset.phpDel;
          if (!(await openConfirmModal("Delete Shared Hosting File", `Delete "${storagePath}" from ${prov.providerName}?`))) return;
          try {
            await callHostingProxy({
              action: "delete_file",
              providerId: prov.providerId,
              uploadApiUrl: prov.endpointUrl,
              endpointUrl: prov.endpointUrl,
              storagePath
            });
            showToast(`Deleted ${storagePath}.`);
            $("fm-refresh-btn")?.click();
          } catch (err) {
            showToast(`Delete failed: ${err.message}`, true);
          }
        });
      });
      return;
    }

    const items = await supabaseListObjects(prov, bucket);
    if (!items.length) {
      filesEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">Bucket "${escapeHtml(bucket)}" has no files yet.</span></div>`;
      return;
    }
    const endpoint = prov.endpointUrl;
    const isPrivateBucket = bucket === "verification-documents";
    filesEl.innerHTML = items.map((it) => {
      const url = `${endpoint}/storage/v1/object/public/${bucket}/${it.name}`;
      return `
        <div class="list-item">
          <div class="list-header">
            <div>
              <strong>${escapeHtml(it.name)}</strong>
              <div style="font-size:12px;color:var(--text-muted);">${formatBytes(it.metadata?.size || 0)} • ${escapeHtml(it.created_at || "")}</div>
            </div>
            <div style="display:flex;gap:8px;">
              ${isPrivateBucket
                ? `<button type="button" class="btn btn-outline btn-sm" data-fm-open-signed="${escapeHtml(it.name)}">Open Signed</button>`
                : `<a class="btn btn-outline btn-sm" href="${escapeHtml(safeHref(url))}" target="_blank" rel="noopener">Open</a>`
              }
              <button type="button" class="btn btn-danger btn-sm" data-fm-del="${escapeHtml(it.name)}">Delete</button>
            </div>
          </div>
        </div>
      `;
    }).join("");

    filesEl.querySelectorAll("[data-fm-open-signed]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          const signed = await supabaseCreateSignedUrl(prov, bucket, btn.dataset.fmOpenSigned, 300);
          window.open(signed, "_blank", "noopener,noreferrer");
        } catch (err) {
          showToast(`Signed URL failed: ${err.message}`, true);
        }
      });
    });

    filesEl.querySelectorAll("[data-fm-del]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const path = btn.dataset.fmDel;
        if (!(await openConfirmModal("Delete Cloud File", `Delete "${path}" from ${bucket}?`))) return;
        try {
          await supabaseDeleteObject(prov, bucket, path);
          showToast(`Deleted ${path}.`);
          $("fm-refresh-btn")?.click();
        } catch (err) {
          showToast(`Delete failed: ${err.message}`, true);
        }
      });
    });
  } catch (err) {
    filesEl.innerHTML = `<div class="list-item" style="color:var(--warning);">${escapeHtml(err.message)}</div>`;
  }
});

function renderUploadHistory() {
  const listEl = $("storage-upload-history-list");
  if (!listEl) return;
  if (!cachedUploadHistory.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No multi-cloud uploads recorded yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedUploadHistory.slice(0, 30).map((u) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge ${u.status === "SUCCESS" ? "badge-green" : "badge-err"}">${escapeHtml(u.status)}</span>
          ${u.failoverUsed ? `<span class="badge badge-warn">FAILOVER</span>` : ""}
          <strong style="margin-left:6px;">${escapeHtml(u.bucketName)}/${escapeHtml(u.objectPath)}</strong>
        </div>
        <span style="font-size:12px;color:var(--text-muted);">${escapeHtml(u.providerId)} • ${formatBytes(u.sizeBytes)}</span>
      </div>
    </div>
  `).join("");
}

function renderErrorLogs() {
  const listEl = $("storage-error-logs-list");
  if (!listEl) return;
  if (!cachedErrorLogs.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No storage failover or connection errors logged.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedErrorLogs.slice(0, 30).map((e) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge ${e.resolved ? "badge-green" : "badge-err"}">${e.resolved ? "RESOLVED" : "ALERT"}</span>
          <strong style="margin-left:6px;">${escapeHtml(e.providerId)}</strong>
          ${e.failoverTargetId ? ` &rarr; <span class="badge badge-cyan">Failover: ${escapeHtml(e.failoverTargetId)}</span>` : ""}
        </div>
        ${!e.resolved ? `<button type="button" class="btn btn-outline btn-sm" data-err-resolve="${escapeHtml(e.id)}">Resolve</button>` : ""}
      </div>
      <div style="font-size:12px;color:var(--warning);margin-top:4px;">${escapeHtml(e.errorMessage)}</div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-err-resolve]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await sbUpdate("storage_error_logs", `error_id=eq.${encodeURIComponent(btn.dataset.errResolve)}`, { resolved: true }, currentUser);
        await refreshTable("storage_error_logs");
        showToast("Storage alert marked resolved.");
      } catch (err) {
        showToast(`Resolve failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// AI ASSISTANT MANAGEMENT (PHASE 2 — MULTI-PROVIDER FREE-FIRST ROUTING)
// =========================================================================

function isOpenRouterFreeModelName(model) {
  const m = String(model || "").trim().toLowerCase();
  return m === "openrouter/free" || m.endsWith(":free");
}

function isAiProfileEligible(p) {
  if (!p || !p.enabled || p.role === "DISABLED") return false;
  if (aiState.aiFreeOnlyMode) {
    if (!p.isFree) return false;
    if (p.providerType === "OPENROUTER" && !isOpenRouterFreeModelName(p.model)) return false;
    return true;
  }
  if (!p.isFree) {
    return Boolean(aiState.aiAllowPaidFallback && p.adminPaidApproved);
  }
  return true;
}

function aiRoleWeight(role) {
  switch (role) {
    case "PRIMARY": return 0;
    case "SECONDARY": return 1;
    case "BACKUP": return 2;
    default: return 3;
  }
}

function populateAiForm() {
  if ($("ai-enabled")) $("ai-enabled").checked = aiState.aiEnabled !== false;
  if ($("ai-show-nav")) $("ai-show-nav").checked = aiState.showAiNavItem !== false;
  if ($("ai-free-only-mode")) $("ai-free-only-mode").checked = aiState.aiFreeOnlyMode !== false;
  if ($("ai-allow-paid-fallback")) $("ai-allow-paid-fallback").checked = Boolean(aiState.aiAllowPaidFallback);
  if ($("ai-auto-failover")) $("ai-auto-failover").checked = aiState.aiAutoFailoverEnabled !== false;
  if ($("ai-provider")) $("ai-provider").value = aiState.aiProvider || "GEMINI";
  if ($("ai-model")) $("ai-model").value = aiState.aiModel || "gemini-2.5-flash";
  if ($("ai-endpoint-url")) $("ai-endpoint-url").value = aiState.aiEndpointUrl || "";
  if ($("ai-proxy-endpoint")) $("ai-proxy-endpoint").value = aiState.aiProxyEndpoint || DEFAULT_AI_PROXY_URL;
  if ($("ai-daily-limit")) $("ai-daily-limit").value = aiState.aiDailyLimit ?? 500;
  if ($("ai-per-user-limit")) $("ai-per-user-limit").value = aiState.aiPerUserLimit ?? 15;
  if ($("ai-appliances")) $("ai-appliances").value = (aiState.aiSupportedAppliances || []).join(", ");
  if ($("ai-brands-json")) $("ai-brands-json").value = aiState.aiBrandsModelsJson || DEFAULT_AI_BRANDS_JSON;
  if ($("ai-system-instructions")) $("ai-system-instructions").value = aiState.aiSystemInstructions || "";
  const langs = new Set(aiState.aiSupportedLanguages || ["en", "bn", "hi"]);
  if ($("ai-lang-en")) $("ai-lang-en").checked = langs.has("en");
  if ($("ai-lang-bn")) $("ai-lang-bn").checked = langs.has("bn");
  if ($("ai-lang-hi")) $("ai-lang-hi").checked = langs.has("hi");
  if ($("ai-key-provider")) $("ai-key-provider").value = aiState.aiProvider || "GEMINI";
}

function renderAiStats() {
  if ($("ai-stat-status")) {
    const modeLabel = aiState.aiFreeOnlyMode ? "FREE ONLY" : (aiState.aiAllowPaidFallback ? "PAID AUTH" : "FREE DEFAULT");
    $("ai-stat-status").textContent = aiState.aiEnabled ? `ENABLED (${modeLabel})` : "DISABLED";
    $("ai-stat-status").style.color = aiState.aiEnabled ? "var(--success)" : "var(--error)";
  }
  const activeOrdered = [...(aiState.aiProviders || [])]
    .filter((p) => isAiProfileEligible(p))
    .sort((a, b) => aiRoleWeight(a.role) - aiRoleWeight(b.role));
  if ($("ai-stat-provider")) {
    $("ai-stat-provider").textContent = activeOrdered[0]
      ? `${activeOrdered[0].providerType} (${activeOrdered.length})`
      : `${aiState.aiProvider || "GEMINI"} (0 ready)`;
  }
  if ($("ai-stat-limits")) $("ai-stat-limits").textContent = `${aiState.aiDailyLimit} / ${aiState.aiPerUserLimit}`;
  if ($("ai-stat-errors")) $("ai-stat-errors").textContent = String(cachedAiErrorLogs.filter((e) => !e.resolved).length);
}

function fillAiProviderFormFromPreset(presetKey, suggestedRole = "SECONDARY") {
  const preset = AI_PROVIDER_PRESETS[presetKey] || AI_PROVIDER_PRESETS.GEMINI;
  if ($("ai-prof-id")) $("ai-prof-id").value = "";
  if ($("ai-prof-type")) $("ai-prof-type").value = presetKey;
  if ($("ai-prof-label")) $("ai-prof-label").value = preset.label;
  if ($("ai-prof-role")) $("ai-prof-role").value = suggestedRole;
  if ($("ai-prof-model")) $("ai-prof-model").value = preset.model;
  if ($("ai-prof-endpoint")) $("ai-prof-endpoint").value = preset.endpointUrl;
  if ($("ai-prof-daily-limit")) $("ai-prof-daily-limit").value = preset.isFree ? 400 : 100;
  if ($("ai-prof-user-limit")) $("ai-prof-user-limit").value = 15;
  if ($("ai-prof-enabled")) $("ai-prof-enabled").checked = true;
  if ($("ai-prof-is-free")) $("ai-prof-is-free").checked = Boolean(preset.isFree);
  if ($("ai-prof-paid-approved")) $("ai-prof-paid-approved").checked = false;
  if ($("ai-prof-api-key")) $("ai-prof-api-key").value = "";
}

$("ai-preset-gemini-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("GEMINI", "PRIMARY"));
$("ai-preset-groq-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("GROQ", "SECONDARY"));
$("ai-preset-openrouter-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("OPENROUTER", "BACKUP"));
$("ai-preset-openai-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("OPENAI_COMPATIBLE", "BACKUP"));
$("ai-preset-custom-btn")?.addEventListener("click", () => fillAiProviderFormFromPreset("CUSTOM_PROXY", "BACKUP"));

$("ai-prof-type")?.addEventListener("change", () => {
  if ($("ai-prof-id")?.value) return; // keep values when editing an existing profile
  const selectedType = $("ai-prof-type")?.value || "GEMINI";
  const preset = AI_PROVIDER_PRESETS[selectedType] || AI_PROVIDER_PRESETS.GEMINI;
  if ($("ai-prof-label")) $("ai-prof-label").value = preset.label;
  if ($("ai-prof-model")) $("ai-prof-model").value = preset.model;
  if ($("ai-prof-endpoint")) $("ai-prof-endpoint").value = preset.endpointUrl;
  if ($("ai-prof-is-free")) $("ai-prof-is-free").checked = Boolean(preset.isFree);
});

$("ai-provider")?.addEventListener("change", () => {
  const selectedType = $("ai-provider")?.value || "GEMINI";
  const preset = AI_PROVIDER_PRESETS[selectedType];
  if (!preset) return;
  if ($("ai-model")) $("ai-model").value = preset.model;
  if ($("ai-endpoint-url")) $("ai-endpoint-url").value = preset.endpointUrl;
});

$("ai-prof-reset-btn")?.addEventListener("click", () => {
  fillAiProviderFormFromPreset("GROQ", "SECONDARY");
  setBanner("ai-providers-banner", "Profile form reset.", "info");
});

function buildCurrentAiConfigPayload(overrides = {}) {
  const brandsRaw = ($("ai-brands-json")?.value || aiState.aiBrandsModelsJson || DEFAULT_AI_BRANDS_JSON).trim();
  const appliances = ($("ai-appliances")?.value || (aiState.aiSupportedAppliances || []).join(","))
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 20);
  if (!appliances.length) appliances.push("Air Conditioner", "Refrigerator", "Washing Machine");

  const langs = ["en", "bn", "hi"].filter((code) => $(`ai-lang-${code}`)?.checked);
  if (!langs.length) langs.push("en");

  const proxyUrl = ($("ai-proxy-endpoint")?.value || aiState.aiProxyEndpoint || DEFAULT_AI_PROXY_URL).trim();
  const providersList = overrides.aiProviders || aiState.aiProviders || [defaultGeminiFreeProvider()];
  const orderedPrimary = [...providersList]
    .filter((p) => p.enabled && p.role !== "DISABLED")
    .sort((a, b) => aiRoleWeight(a.role) - aiRoleWeight(b.role))[0];

  return {
    configType: "AI",
    aiEnabled: Boolean($("ai-enabled")?.checked ?? aiState.aiEnabled),
    showAiNavItem: Boolean($("ai-show-nav")?.checked ?? aiState.showAiNavItem),
    aiFreeOnlyMode: Boolean($("ai-free-only-mode")?.checked ?? aiState.aiFreeOnlyMode),
    aiAllowPaidFallback: Boolean($("ai-allow-paid-fallback")?.checked ?? aiState.aiAllowPaidFallback),
    aiAutoFailoverEnabled: Boolean($("ai-auto-failover")?.checked ?? aiState.aiAutoFailoverEnabled),
    aiProvider: orderedPrimary?.providerType || $("ai-provider")?.value || aiState.aiProvider || "GEMINI",
    aiModel: (orderedPrimary?.model || $("ai-model")?.value || aiState.aiModel || "gemini-2.5-flash").trim().slice(0, 120),
    aiEndpointUrl: (orderedPrimary?.endpointUrl || $("ai-endpoint-url")?.value || aiState.aiEndpointUrl || "").trim().slice(0, 500),
    aiProxyEndpoint: (/^https:\/\//i.test(proxyUrl) ? proxyUrl : DEFAULT_AI_PROXY_URL).slice(0, 500),
    aiDailyLimit: Math.min(1000000, Math.max(0, Math.round(Number($("ai-daily-limit")?.value ?? aiState.aiDailyLimit ?? 500)))),
    aiPerUserLimit: Math.min(1000, Math.max(0, Math.round(Number($("ai-per-user-limit")?.value ?? aiState.aiPerUserLimit ?? 15)))),
    aiProvidersJson: sanitizeAiProvidersForFirestore(providersList),
    aiSupportedAppliances: appliances,
    aiBrandsModelsJson: brandsRaw.slice(0, 10000),
    aiSupportedLanguages: langs,
    aiSystemInstructions: ($("ai-system-instructions")?.value || aiState.aiSystemInstructions || "").trim().slice(0, 2000),
    updatedByUid: currentUser.uid
  };
}

async function persistAiProvidersToSupabase(nextProviders, auditDetail) {
  aiState.aiProviders = nextProviders;
  aiState.aiProvidersJson = sanitizeAiProvidersForFirestore(nextProviders);
  const payload = buildCurrentAiConfigPayload({ aiProviders: nextProviders });
  await sbSaveSetting("ai_config", "AI", payload, currentUser.uid, currentUser);
  await writeAuditLog("UPDATE_AI_PROVIDERS", "app_settings", "ai_config", auditDetail);
  renderAiProvidersManager();
  renderAiStats();
}

function renderAiProvidersManager() {
  const listEl = $("ai-providers-list");
  const keyProvSel = $("ai-key-provider-id");
  const ordered = [...(aiState.aiProviders || [])].sort((a, b) => aiRoleWeight(a.role) - aiRoleWeight(b.role));

  if (keyProvSel) {
    const prev = keyProvSel.value;
    keyProvSel.innerHTML = `<option value="">Preset Default Key</option>` +
      ordered.map((p) => `<option value="${escapeHtml(p.providerId)}">${escapeHtml(p.label)} (${escapeHtml(p.providerId)})</option>`).join("");
    if (prev && ordered.some((p) => p.providerId === prev)) {
      keyProvSel.value = prev;
    }
  }

  if (!listEl) return;
  if (!ordered.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No AI provider profiles configured yet. Click a Free preset above to add Gemini, Groq, or OpenRouter.</span></div>`;
    return;
  }

  listEl.innerHTML = ordered.map((p) => {
    const eligible = isAiProfileEligible(p);
    const tierBadge = p.isFree
      ? (p.providerType === "OPENROUTER" && !isOpenRouterFreeModelName(p.model)
          ? `<span class="badge badge-warn">OPENROUTER NON-:FREE (BLOCKED IN FREE MODE)</span>`
          : `<span class="badge badge-green">FREE TIER</span>`)
      : (p.adminPaidApproved && aiState.aiAllowPaidFallback && !aiState.aiFreeOnlyMode
          ? `<span class="badge badge-warn">PAID (ADMIN AUTHORIZED)</span>`
          : `<span class="badge badge-err">PAID (BLOCKED)</span>`);
    const roleBadgeClass = p.role === "PRIMARY" ? "badge-green" : p.role === "SECONDARY" ? "badge-cyan" : p.role === "BACKUP" ? "badge-warn" : "badge-err";
    return `
      <div class="list-item">
        <div class="list-header">
          <div>
            <span class="badge ${roleBadgeClass}">${escapeHtml(p.role)}</span>
            <span class="badge ${p.enabled ? "badge-green" : "badge-err"}">${p.enabled ? "ENABLED" : "DISABLED"}</span>
            ${tierBadge}
            <span class="badge ${eligible ? "badge-cyan" : "badge-warn"}">${eligible ? "ACTIVE IN CHAIN" : "SKIPPED"}</span>
            <strong style="margin-left:6px;">${escapeHtml(p.label)}</strong>
            <div style="font-size:12px;color:var(--text-muted);margin-top:4px;">
              ${escapeHtml(p.providerType)} • Model: <code>${escapeHtml(p.model)}</code> • Daily Cap: ${Number(p.dailyLimit || 0)} • User Cap: ${Number(p.perUserLimit || 0)}
            </div>
            <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">
              Endpoint: ${escapeHtml(p.endpointUrl || "Default")} • ID: <code>${escapeHtml(p.providerId)}</code>
            </div>
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-test="${escapeHtml(p.providerId)}">Test</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-key="${escapeHtml(p.providerId)}">Vault Key</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-edit="${escapeHtml(p.providerId)}">Edit</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-role="PRIMARY" data-ai-prof-id="${escapeHtml(p.providerId)}">Primary</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-role="SECONDARY" data-ai-prof-id="${escapeHtml(p.providerId)}">Secondary</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-role="BACKUP" data-ai-prof-id="${escapeHtml(p.providerId)}">Backup</button>
            <button type="button" class="btn btn-outline btn-sm" data-ai-prof-toggle="${escapeHtml(p.providerId)}">${p.enabled ? "Disable" : "Enable"}</button>
            <button type="button" class="btn btn-danger btn-sm" data-ai-prof-del="${escapeHtml(p.providerId)}">Remove</button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  listEl.querySelectorAll("[data-ai-prof-test]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const prov = (aiState.aiProviders || []).find((x) => x.providerId === btn.dataset.aiProfTest);
      if (!prov) return;
      setBanner("ai-providers-banner", `Testing admin connection to ${prov.label} (${prov.model})...`, "info");
      try {
        const res = await callAiAssistantEndpoint({
          action: "test_connection",
          providerIdOverride: prov.providerId,
          providerOverride: prov.providerType,
          modelOverride: prov.model,
          endpointOverride: prov.endpointUrl
        });
        setBanner("ai-providers-banner", `Connected to ${res.provider} (${res.model})! Sample length: ${res.sampleLength} chars.`, "success");
        showToast(`${prov.label} verified.`);
      } catch (err) {
        setBanner("ai-providers-banner", `Test failed for ${prov.label}: ${err.message}`, "error");
      }
    });
  });

  listEl.querySelectorAll("[data-ai-prof-key]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const prov = (aiState.aiProviders || []).find((x) => x.providerId === btn.dataset.aiProfKey);
      if (!prov) return;
      if ($("ai-key-provider")) $("ai-key-provider").value = prov.providerType;
      if ($("ai-key-provider-id")) $("ai-key-provider-id").value = prov.providerId;
      $("ai-api-key")?.focus();
      setBanner("ai-key-banner", `Ready to store server-only API key for "${prov.label}" (${prov.providerId}).`, "info");
    });
  });

  listEl.querySelectorAll("[data-ai-prof-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const prov = (aiState.aiProviders || []).find((x) => x.providerId === btn.dataset.aiProfEdit);
      if (!prov) return;
      if ($("ai-prof-id")) $("ai-prof-id").value = prov.providerId;
      if ($("ai-prof-type")) $("ai-prof-type").value = prov.providerType;
      if ($("ai-prof-label")) $("ai-prof-label").value = prov.label;
      if ($("ai-prof-role")) $("ai-prof-role").value = prov.role;
      if ($("ai-prof-model")) $("ai-prof-model").value = prov.model;
      if ($("ai-prof-endpoint")) $("ai-prof-endpoint").value = prov.endpointUrl;
      if ($("ai-prof-daily-limit")) $("ai-prof-daily-limit").value = prov.dailyLimit;
      if ($("ai-prof-user-limit")) $("ai-prof-user-limit").value = prov.perUserLimit;
      if ($("ai-prof-enabled")) $("ai-prof-enabled").checked = prov.enabled !== false;
      if ($("ai-prof-is-free")) $("ai-prof-is-free").checked = Boolean(prov.isFree);
      if ($("ai-prof-paid-approved")) $("ai-prof-paid-approved").checked = Boolean(prov.adminPaidApproved);
      if ($("ai-prof-api-key")) $("ai-prof-api-key").value = "";
      $("ai-prof-label")?.focus();
      setBanner("ai-providers-banner", `Editing "${prov.label}".`, "info");
    });
  });

  listEl.querySelectorAll("[data-ai-prof-role]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const targetId = btn.dataset.aiProfId;
      const nextRole = btn.dataset.aiProfRole;
      const nextProviders = (aiState.aiProviders || []).map((p) => {
        if (p.providerId === targetId) return { ...p, role: nextRole, enabled: true };
        if (nextRole === "PRIMARY" && p.role === "PRIMARY") return { ...p, role: "SECONDARY" };
        if (nextRole === "SECONDARY" && p.role === "SECONDARY") return { ...p, role: "BACKUP" };
        return p;
      });
      try {
        await persistAiProvidersToSupabase(nextProviders, `Set ${targetId} role=${nextRole}`);
        showToast(`AI provider role updated to ${nextRole}.`);
      } catch (err) {
        setBanner("ai-providers-banner", `Role update failed: ${err.message}`, "error");
      }
    });
  });

  listEl.querySelectorAll("[data-ai-prof-toggle]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const targetId = btn.dataset.aiProfToggle;
      const nextProviders = (aiState.aiProviders || []).map((p) =>
        p.providerId === targetId ? { ...p, enabled: !p.enabled } : p
      );
      try {
        await persistAiProvidersToSupabase(nextProviders, `Toggled ${targetId}`);
        showToast("AI provider status updated.");
      } catch (err) {
        setBanner("ai-providers-banner", `Status update failed: ${err.message}`, "error");
      }
    });
  });

  listEl.querySelectorAll("[data-ai-prof-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const targetId = btn.dataset.aiProfDel;
      if ((aiState.aiProviders || []).length <= 1) {
        setBanner("ai-providers-banner", "Keep at least one AI provider profile configured (you can disable it instead).", "warning");
        return;
      }
      if (!(await openConfirmModal("Remove AI Provider Profile", `Remove provider profile "${targetId}"?`))) return;
      const nextProviders = (aiState.aiProviders || []).filter((p) => p.providerId !== targetId);
      try {
        await persistAiProvidersToSupabase(nextProviders, `Removed ${targetId}`);
        showToast("AI provider profile removed.");
      } catch (err) {
        setBanner("ai-providers-banner", `Remove failed: ${err.message}`, "error");
      }
    });
  });
}

$("ai-provider-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const existingId = ($("ai-prof-id")?.value || "").trim();
  const providerType = $("ai-prof-type")?.value || "GEMINI";
  const label = ($("ai-prof-label")?.value || "").trim();
  const role = $("ai-prof-role")?.value || "SECONDARY";
  const model = ($("ai-prof-model")?.value || "").trim();
  const endpointUrl = ($("ai-prof-endpoint")?.value || "").trim();
  const isFree = Boolean($("ai-prof-is-free")?.checked);
  const adminPaidApproved = Boolean($("ai-prof-paid-approved")?.checked);
  const enabled = Boolean($("ai-prof-enabled")?.checked);
  const dailyLimit = Math.min(1000000, Math.max(0, Math.round(Number($("ai-prof-daily-limit")?.value ?? 400))));
  const perUserLimit = Math.min(1000, Math.max(0, Math.round(Number($("ai-prof-user-limit")?.value ?? 15))));
  const optionalApiKey = ($("ai-prof-api-key")?.value || "").trim();

  if (!label || !model || !/^https:\/\//i.test(endpointUrl)) {
    setBanner("ai-providers-banner", "Display Label, Model ID, and a valid HTTPS Endpoint URL are required.", "error");
    return;
  }
  if (!isFree && adminPaidApproved && $("ai-free-only-mode")?.checked) {
    setBanner("ai-providers-banner", "Paid usage will remain blocked while Free Only Mode is enabled above.", "warning");
  }
  if (providerType === "OPENROUTER" && isFree && !isOpenRouterFreeModelName(model)) {
    setBanner("ai-providers-banner", "OpenRouter models in Free Only Mode must end with ':free' (or use 'openrouter/free').", "error");
    return;
  }

  const profileId = existingId || `${providerType.toLowerCase()}_${Date.now().toString(36)}`;
  const profile = normalizeAiProviderProfile({
    providerId: profileId,
    label,
    providerType,
    role,
    enabled,
    isFree,
    adminPaidApproved,
    endpointUrl,
    model,
    dailyLimit,
    perUserLimit
  });

  let nextProviders = [...(aiState.aiProviders || [])];
  if (role === "PRIMARY") {
    nextProviders = nextProviders.map((p) => (p.providerId !== profileId && p.role === "PRIMARY" ? { ...p, role: "SECONDARY" } : p));
  }
  const idx = nextProviders.findIndex((p) => p.providerId === profileId);
  if (idx >= 0) {
    nextProviders[idx] = profile;
  } else {
    nextProviders.push(profile);
  }

  try {
    if (optionalApiKey) {
      if (optionalApiKey.length < 10) {
        setBanner("ai-providers-banner", "Optional API key must be at least 10 characters.", "error");
        return;
      }
      await callAiAssistantEndpoint({
        action: "save_ai_key",
        providerOverride: providerType,
        providerIdOverride: profileId,
        apiKey: optionalApiKey
      });
      if ($("ai-prof-api-key")) $("ai-prof-api-key").value = "";
    }
    await persistAiProvidersToSupabase(nextProviders, `${idx >= 0 ? "Updated" : "Added"} ${profileId} (${providerType}, ${role}, free=${isFree})`);
    if ($("ai-prof-id")) $("ai-prof-id").value = "";
    setBanner("ai-providers-banner", `Saved AI provider "${label}" (${role}) and published configuration.${optionalApiKey ? " API key stored securely on backend." : ""}`, "success");
    showToast(`Saved ${label}.`);
  } catch (err) {
    setBanner("ai-providers-banner", `Failed to save AI provider profile: ${err.message}`, "error");
  }
});

$("ai-config-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const brandsRaw = ($("ai-brands-json")?.value || DEFAULT_AI_BRANDS_JSON).trim();
  try {
    const parsed = JSON.parse(brandsRaw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("Brands JSON must be an object mapping appliance names to brand arrays.");
    }
  } catch (err) {
    setBanner("ai-config-banner", `Invalid Brands JSON: ${err.message}`, "error");
    return;
  }

  const appliances = ($("ai-appliances")?.value || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 20);
  if (!appliances.length) {
    setBanner("ai-config-banner", "Provide at least one supported appliance.", "error");
    return;
  }

  const freeOnly = Boolean($("ai-free-only-mode")?.checked);
  const allowPaidFallback = Boolean($("ai-allow-paid-fallback")?.checked);
  if (freeOnly && allowPaidFallback) {
    setBanner("ai-config-banner", "Paid fallback remains disabled while Free Only Mode is checked. Uncheck Free Only Mode to authorize paid fallback.", "warning");
  }

  const payload = buildCurrentAiConfigPayload();
  try {
    await sbSaveSetting("ai_config", "AI", payload, currentUser.uid, currentUser);
    await writeAuditLog(
      "UPDATE_AI_CONFIG",
      "app_settings",
      "ai_config",
      `enabled=${payload.aiEnabled}, freeOnly=${payload.aiFreeOnlyMode}, paidAuth=${payload.aiAllowPaidFallback}, failover=${payload.aiAutoFailoverEnabled}, provider=${payload.aiProvider}`
    );
    setBanner("ai-config-banner", "Repair Pro AI configuration published to Supabase app_settings/ai_config. Android reflects changes live.", "success");
    showToast("AI settings published.");
  } catch (err) {
    setBanner("ai-config-banner", `Failed to publish AI settings: ${err.message}`, "error");
  }
});

async function callAiAssistantEndpoint(payload) {
  if (!currentUser) throw new Error("Sign in as Super Admin first.");
  const url = String($("ai-proxy-endpoint")?.value || aiState.aiProxyEndpoint || DEFAULT_AI_PROXY_URL).trim();
  const idToken = await currentUser.getIdToken();
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${idToken}`
    },
    body: JSON.stringify(payload)
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok || data.ok === false) {
    throw new Error(data.message || `AI Endpoint HTTP ${resp.status}`);
  }
  return data;
}

$("ai-secret-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const providerOverride = $("ai-key-provider")?.value || "GEMINI";
  const providerIdOverride = ($("ai-key-provider-id")?.value || "").trim();
  const apiKey = ($("ai-api-key")?.value || "").trim();
  if (apiKey.length < 10) {
    setBanner("ai-key-banner", "Enter a valid AI API key (at least 10 characters).", "error");
    return;
  }
  try {
    await callAiAssistantEndpoint({
      action: "save_ai_key",
      providerOverride,
      providerIdOverride: providerIdOverride || undefined,
      apiKey
    });
    if ($("ai-api-key")) $("ai-api-key").value = "";
    setBanner("ai-key-banner", `API key for ${providerOverride}${providerIdOverride ? ` (${providerIdOverride})` : ""} stored securely on backend (never sent to Supabase public tables or APK).`, "success");
    showToast("AI key stored securely.");
  } catch (err) {
    setBanner("ai-key-banner", `Failed to save AI key: ${err.message}`, "error");
  }
});

$("ai-test-btn")?.addEventListener("click", async () => {
  const providerIdOverride = ($("ai-key-provider-id")?.value || "").trim();
  const matched = providerIdOverride
    ? (aiState.aiProviders || []).find((p) => p.providerId === providerIdOverride)
    : undefined;
  const providerOverride = matched?.providerType || $("ai-key-provider")?.value || $("ai-provider")?.value || "GEMINI";
  const modelOverride = matched?.model || ($("ai-model")?.value || AI_PROVIDER_PRESETS[providerOverride]?.model || "gemini-2.5-flash").trim();
  const endpointOverride = matched?.endpointUrl || ($("ai-endpoint-url")?.value || AI_PROVIDER_PRESETS[providerOverride]?.endpointUrl || "").trim();
  const tempApiKey = ($("ai-api-key")?.value || "").trim();
  setBanner("ai-key-banner", `Testing admin connection to ${providerOverride} (${modelOverride})...`, "info");
  try {
    const res = await callAiAssistantEndpoint({
      action: "test_connection",
      providerIdOverride: providerIdOverride || undefined,
      providerOverride,
      modelOverride,
      endpointOverride,
      tempApiKey: tempApiKey || undefined
    });
    setBanner("ai-key-banner", `Connected cleanly to ${res.provider} (${res.model})! Sample response length: ${res.sampleLength} chars.`, "success");
    showToast("AI connection verified.");
  } catch (err) {
    setBanner("ai-key-banner", `AI connection test failed: ${err.message}`, "error");
  }
});

function renderAiErrorLogs() {
  const listEl = $("ai-error-logs-list");
  if (!listEl) return;
  if (!cachedAiErrorLogs.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No AI diagnostic errors recorded.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedAiErrorLogs.slice(0, 30).map((e) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <span class="badge ${e.resolved ? "badge-green" : "badge-err"}">${e.resolved ? "RESOLVED" : "ERROR"}</span>
          <strong style="margin-left:6px;">${escapeHtml(e.provider || "AI")} ${e.modelName ? `(${escapeHtml(e.modelName)})` : ""}</strong>
          <span style="font-size:11px;color:var(--text-muted);margin-left:6px;">${escapeHtml(formatTs(e.createdAt))}</span>
        </div>
        ${!e.resolved ? `<button type="button" class="btn btn-outline btn-sm" data-ai-err-resolve="${escapeHtml(e.id)}">Resolve</button>` : ""}
      </div>
      <div style="font-size:12px;color:var(--warning);margin-top:4px;">${escapeHtml(e.errorMessage || "Unknown error")}</div>
    </div>
  `).join("");

  listEl.querySelectorAll("[data-ai-err-resolve]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await sbUpdate("ai_error_logs", `error_id=eq.${encodeURIComponent(btn.dataset.aiErrResolve)}`, { resolved: true }, currentUser);
        await refreshTable("ai_error_logs");
        showToast("AI error marked resolved.");
      } catch (err) {
        showToast(`Resolve failed: ${err.message}`, true);
      }
    });
  });
}

// =========================================================================
// BILLING, PDF INVOICE & MANUAL PAYMENT REMINDERS CONFIG (PHASE 2)
// =========================================================================

function populateBillingForm() {
  if ($("bill-invoice-enabled")) $("bill-invoice-enabled").checked = billingState.invoiceEnabled !== false;
  if ($("bill-whatsapp-enabled")) $("bill-whatsapp-enabled").checked = billingState.whatsappReminderEnabled !== false;
  if ($("bill-sms-enabled")) $("bill-sms-enabled").checked = billingState.smsReminderEnabled !== false;
  if ($("bill-business-title")) $("bill-business-title").value = billingState.invoiceBusinessTitle || "Repair Pro Service Invoice";
  if ($("bill-terms-note")) $("bill-terms-note").value = billingState.invoiceTermsNote || "";

  let templates = { ...DEFAULT_BILLING_TEMPLATES };
  try {
    const parsed = JSON.parse(billingState.reminderTemplatesJson || "{}");
    templates = { ...templates, ...parsed };
  } catch {
    // keep defaults
  }
  if ($("bill-tpl-en")) $("bill-tpl-en").value = templates.en || DEFAULT_BILLING_TEMPLATES.en;
  if ($("bill-tpl-bn")) $("bill-tpl-bn").value = templates.bn || DEFAULT_BILLING_TEMPLATES.bn;
  if ($("bill-tpl-hi")) $("bill-tpl-hi").value = templates.hi || DEFAULT_BILLING_TEMPLATES.hi;

  const langs = new Set(billingState.billingSupportedLanguages || ["en", "bn", "hi"]);
  if ($("bill-lang-en")) $("bill-lang-en").checked = langs.has("en");
  if ($("bill-lang-bn")) $("bill-lang-bn").checked = langs.has("bn");
  if ($("bill-lang-hi")) $("bill-lang-hi").checked = langs.has("hi");
}

$("billing-config-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const langs = ["en", "bn", "hi"].filter((code) => $(`bill-lang-${code}`)?.checked);
  if (!langs.length) langs.push("en");

  const templatesJson = JSON.stringify({
    en: ($("bill-tpl-en")?.value || DEFAULT_BILLING_TEMPLATES.en).trim().slice(0, 1200),
    bn: ($("bill-tpl-bn")?.value || DEFAULT_BILLING_TEMPLATES.bn).trim().slice(0, 1200),
    hi: ($("bill-tpl-hi")?.value || DEFAULT_BILLING_TEMPLATES.hi).trim().slice(0, 1200)
  }).slice(0, 8000);

  const payload = {
    configType: "BILLING",
    invoiceEnabled: Boolean($("bill-invoice-enabled")?.checked),
    whatsappReminderEnabled: Boolean($("bill-whatsapp-enabled")?.checked),
    smsReminderEnabled: Boolean($("bill-sms-enabled")?.checked),
    invoiceBusinessTitle: ($("bill-business-title")?.value || "Repair Pro Service Invoice").trim().slice(0, 120),
    invoiceTermsNote: ($("bill-terms-note")?.value || "").trim().slice(0, 600),
    reminderTemplatesJson: templatesJson,
    billingSupportedLanguages: langs,
    updatedByUid: currentUser.uid
  };

  try {
    await sbSaveSetting("billing_config", "BILLING", payload, currentUser.uid, currentUser);
    await writeAuditLog("UPDATE_BILLING_CONFIG", "app_settings", "billing_config", `invoices=${payload.invoiceEnabled}, whatsapp=${payload.whatsappReminderEnabled}, sms=${payload.smsReminderEnabled}`);
    setBanner("billing-config-banner", "Billing, PDF Invoice & Payment Reminder settings published to Supabase app_settings/billing_config.", "success");
    showToast("Billing settings published.");
  } catch (err) {
    setBanner("billing-config-banner", `Failed to save billing config: ${err.message}`, "error");
  }
});

// =========================================================================
// REPORTS, ADMOB, ONLINE SETTINGS, ROLES & AUDIT LOGS
// =========================================================================

function renderReportsList() {
  const listEl = $("reports-list");
  if (!listEl) return;
  if (!cachedReports.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No problem reports submitted yet.</span></div>`;
    return;
  }
  listEl.innerHTML = cachedReports.map((r) => `
    <div class="list-item">
      <div class="list-header">
        <div>
          <strong>${escapeHtml(r.brandName)} ${r.errorCode ? `(${escapeHtml(r.errorCode)})` : ""}</strong>
          <span class="badge ${r.status === "PUBLISHED" ? "badge-green" : r.status === "PENDING" ? "badge-warn" : "badge-cyan"}">${escapeHtml(r.status)}</span>
        </div>
        <div style="display:flex;gap:6px;">
          <button type="button" class="btn btn-outline btn-sm" data-rep-status="REVIEWED" data-rep-id="${escapeHtml(r.id)}">Review</button>
          <button type="button" class="btn btn-success btn-sm" data-rep-status="PUBLISHED" data-rep-id="${escapeHtml(r.id)}">Mark Published</button>
        </div>
      </div>
      <div style="font-size:13px;color:var(--text-muted);">${escapeHtml(r.description)}</div>
    </div>
  `).join("");
  listEl.querySelectorAll("[data-rep-status]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await multiCloudDbUpdate({
          table: "problem_reports",
          categoryKey: "community",
          recordId: btn.dataset.repId,
          supabaseFilter: `report_id=eq.${encodeURIComponent(btn.dataset.repId)}`,
          patch: { status: btn.dataset.repStatus },
          currentUser,
          storageState,
          migrationConfig: migrationConfigState
        });
        await refreshTable("problem_reports");
        showToast(`Report updated to ${btn.dataset.repStatus}.`);
      } catch (err) {
        showToast(`Update failed: ${err.message}`, true);
      }
    });
  });
}

function populateAdMobForm(d) {
  if ($("ad-global")) $("ad-global").checked = d.adsGlobalEnabled !== false;
  if ($("ad-kill")) $("ad-kill").checked = Boolean(d.emergencyKillSwitch);
  if ($("ad-banner")) $("ad-banner").checked = d.bannerEnabled !== false;
  if ($("ad-interstitial")) $("ad-interstitial").checked = d.interstitialEnabled !== false;
  if ($("ad-rewarded")) $("ad-rewarded").checked = Boolean(d.rewardedEnabled);
  if ($("ad-native")) $("ad-native").checked = Boolean(d.nativeEnabled);
  if ($("ad-test")) $("ad-test").checked = d.testMode !== false;
  if ($("ad-ac")) $("ad-ac").checked = d.acAdsEnabled !== false;
  if ($("ad-fridge")) $("ad-fridge").checked = d.fridgeAdsEnabled !== false;
  if ($("ad-washer")) $("ad-washer").checked = d.washerAdsEnabled !== false;
  if ($("ad-cooldown")) $("ad-cooldown").value = d.interstitialCooldownMin || 3;
  if ($("ad-cap")) $("ad-cap").value = d.sessionFrequencyCap || 6;
  if ($("ad-android-app")) $("ad-android-app").value = d.androidAppId || "";
  if ($("ad-android-banner")) $("ad-android-banner").value = d.androidBannerId || "";
  if ($("ad-android-interstitial")) $("ad-android-interstitial").value = d.androidInterstitialId || "";
  if ($("ad-android-rewarded")) $("ad-android-rewarded").value = d.androidRewardedId || "";
  if ($("ad-ios-app")) $("ad-ios-app").value = d.iosAppId || "";
  if ($("ad-ios-banner")) $("ad-ios-banner").value = d.iosBannerId || "";
}

$("admob-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  try {
    await sbSaveSetting("admob_config", "ADMOB", {
      configType: "ADMOB",
      adsGlobalEnabled: $("ad-global").checked,
      emergencyKillSwitch: $("ad-kill").checked,
      bannerEnabled: $("ad-banner").checked,
      interstitialEnabled: $("ad-interstitial").checked,
      rewardedEnabled: $("ad-rewarded").checked,
      nativeEnabled: $("ad-native").checked,
      testMode: $("ad-test").checked,
      acAdsEnabled: $("ad-ac").checked,
      fridgeAdsEnabled: $("ad-fridge").checked,
      washerAdsEnabled: $("ad-washer").checked,
      interstitialCooldownMin: Math.min(60, Math.max(1, Number($("ad-cooldown").value || 3))),
      sessionFrequencyCap: Math.min(50, Math.max(1, Number($("ad-cap").value || 6))),
      androidAppId: $("ad-android-app").value.trim(),
      androidBannerId: $("ad-android-banner").value.trim(),
      androidInterstitialId: $("ad-android-interstitial").value.trim(),
      androidRewardedId: $("ad-android-rewarded").value.trim(),
      iosAppId: $("ad-ios-app").value.trim(),
      iosBannerId: $("ad-ios-banner").value.trim(),
      updatedByUid: currentUser.uid
    }, currentUser.uid, currentUser);
    await writeAuditLog("UPDATE_ADMOB_CONFIG", "app_settings", "admob_config", "Updated AdMob controls");
    showToast("AdMob configuration published.");
  } catch (err) {
    showToast(`AdMob update failed: ${err.message}`, true);
  }
});

function populateGlobalSettingsForm(d) {
  if ($("set-announcement")) $("set-announcement").value = d.announcement || "";
  if ($("set-maintenance-mode")) $("set-maintenance-mode").checked = Boolean(d.maintenanceMode);
  if ($("set-maintenance")) $("set-maintenance").value = d.maintenanceNotice || "";
  if ($("set-min-version")) $("set-min-version").value = d.minSupportedVersion || "1.0.0";
  if ($("set-min-version-code")) $("set-min-version-code").value = d.minSupportedVersionCode ?? 1;
  if ($("set-latest-version-name")) $("set-latest-version-name").value = d.latestVersionName || "1.2.0";
  if ($("set-latest-version-code")) $("set-latest-version-code").value = d.latestVersionCode ?? 3;
  if ($("set-schema-version")) $("set-schema-version").value = d.schemaVersion ?? 3;
  if ($("set-force-update")) $("set-force-update").checked = Boolean(d.forceUpdate);
  if ($("set-update-message")) $("set-update-message").value = d.updateMessage || "";
  if ($("set-update-url")) $("set-update-url").value = d.updateUrl || "";
  if ($("set-feat-community")) $("set-feat-community").checked = d.communityEnabled !== false;
  if ($("set-feat-technicians")) $("set-feat-technicians").checked = d.techniciansEnabled !== false;
  if ($("set-feat-billing")) $("set-feat-billing").checked = d.billingEnabled !== false;
  if ($("set-feat-verification")) $("set-feat-verification").checked = d.verificationEnabled !== false;
  if ($("set-feat-scanner")) $("set-feat-scanner").checked = d.scannerEnabled !== false;
  if ($("set-feat-reports")) $("set-feat-reports").checked = d.reportsEnabled !== false;
  if ($("set-feat-pdfs")) $("set-feat-pdfs").checked = d.pdfsEnabled !== false;
}

$("global-settings-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const updateUrl = ($("set-update-url")?.value || "").trim().slice(0, 600);
  if (updateUrl && !/^https:\/\//i.test(updateUrl)) {
    showToast("Update / Play Store URL must be blank or start with https://", true);
    return;
  }
  const minCode = Math.min(1000000, Math.max(1, Math.round(Number($("set-min-version-code")?.value || 1))));
  const latestCode = Math.min(1000000, Math.max(1, Math.round(Number($("set-latest-version-code")?.value || 3))));
  const schemaVersion = Math.min(1000, Math.max(1, Math.round(Number($("set-schema-version")?.value || 3))));
  const payload = {
    configType: "GLOBAL",
    announcement: ($("set-announcement")?.value || "").trim().slice(0, 400),
    maintenanceMode: Boolean($("set-maintenance-mode")?.checked),
    maintenanceNotice: ($("set-maintenance")?.value || "").trim().slice(0, 400),
    minSupportedVersion: ($("set-min-version")?.value || "").trim().slice(0, 32) || "1.0.0",
    minSupportedVersionCode: minCode,
    latestVersionName: ($("set-latest-version-name")?.value || "").trim().slice(0, 32) || "1.2.0",
    latestVersionCode: latestCode,
    schemaVersion,
    forceUpdate: Boolean($("set-force-update")?.checked),
    updateMessage: ($("set-update-message")?.value || "").trim().slice(0, 500),
    updateUrl,
    communityEnabled: $("set-feat-community") ? Boolean($("set-feat-community").checked) : true,
    techniciansEnabled: $("set-feat-technicians") ? Boolean($("set-feat-technicians").checked) : true,
    billingEnabled: $("set-feat-billing") ? Boolean($("set-feat-billing").checked) : true,
    verificationEnabled: $("set-feat-verification") ? Boolean($("set-feat-verification").checked) : true,
    scannerEnabled: $("set-feat-scanner") ? Boolean($("set-feat-scanner").checked) : true,
    reportsEnabled: $("set-feat-reports") ? Boolean($("set-feat-reports").checked) : true,
    pdfsEnabled: $("set-feat-pdfs") ? Boolean($("set-feat-pdfs").checked) : true,
    updatedByUid: currentUser.uid
  };
  try {
    await sbSaveSetting("global_config", "GLOBAL", payload, currentUser.uid, currentUser);
    await writeAuditLog(
      "UPDATE_GLOBAL_CONFIG",
      "app_settings",
      "global_config",
      `maintenance=${payload.maintenanceMode}, minCode=${minCode}, forceUpdate=${payload.forceUpdate}`
    );
    showToast("Online app settings & feature switches published.");
  } catch (err) {
    showToast(`Save failed: ${err.message}`, true);
  }
});

// =========================================================================
// USERS & ACCOUNT MODERATION (EDGE FUNCTION + CUSTOM CLAIMS)
// =========================================================================

async function callAdminUserManagementFn(payload) {
  if (!currentUser) throw new Error("Sign in as Super Admin first.");
  const makeCall = async (forceRefresh) => {
    const idToken = await currentUser.getIdToken(forceRefresh);
    return fetch(DEFAULT_ADMIN_USER_MANAGEMENT_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${idToken}`
      },
      body: JSON.stringify(payload)
    });
  };
  let resp = await makeCall(false);
  if (resp.status === 401) {
    resp = await makeCall(true);
  }
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok || data.ok === false) {
    throw new Error(data.message || `User management HTTP ${resp.status}`);
  }
  return data;
}

$("sync-my-claims-btn")?.addEventListener("click", async () => {
  if (!currentUser) return;
  try {
    await callAdminUserManagementFn({ action: "sync_my_claims" });
    await currentUser.getIdToken(true);
    showToast("Firebase custom claims & Supabase role='authenticated' synced.");
  } catch (err) {
    showToast(`Claim sync failed: ${err.message}`, true);
  }
});

$("users-search-input")?.addEventListener("input", renderUsersSection);
$("users-filter-status")?.addEventListener("change", renderUsersSection);

function renderUsersSection() {
  const total = cachedUsers.length;
  const moderated = cachedUsers.filter((u) => Boolean(u.blocked || u.suspended || u.accountStatus === "BLOCKED" || u.accountStatus === "SUSPENDED")).length;
  const restricted = cachedUsers.filter((u) => Boolean(u.communityRestricted || u.uploadRestricted)).length;
  const active = Math.max(0, total - moderated);

  if ($("users-stat-total")) $("users-stat-total").textContent = String(total);
  if ($("users-stat-active")) $("users-stat-active").textContent = String(active);
  if ($("users-stat-moderated")) $("users-stat-moderated").textContent = String(moderated);
  if ($("users-stat-restricted")) $("users-stat-restricted").textContent = String(restricted);

  const listEl = $("users-list");
  if (!listEl) return;

  const qText = ($("users-search-input")?.value || "").trim().toLowerCase();
  const sFilter = $("users-filter-status")?.value || "ALL";
  const filtered = cachedUsers.filter((u) => {
    const uid = String(u.userId || u.id || "");
    const isMod = Boolean(u.blocked || u.suspended || u.accountStatus === "BLOCKED" || u.accountStatus === "SUSPENDED");
    const isRestr = Boolean(u.communityRestricted || u.uploadRestricted);
    const matchesSearch = !qText ||
      uid.toLowerCase().includes(qText) ||
      String(u.displayName || "").toLowerCase().includes(qText) ||
      String(u.email || "").toLowerCase().includes(qText);
    const matchesStatus = sFilter === "ALL" ||
      (sFilter === "ACTIVE" && !isMod) ||
      (sFilter === "MODERATED" && isMod) ||
      (sFilter === "RESTRICTED" && isRestr);
    return matchesSearch && matchesStatus;
  });

  if (!filtered.length) {
    listEl.innerHTML = `<div class="list-item"><span style="color:var(--text-muted);">No users match the active filter.</span></div>`;
    return;
  }

  listEl.innerHTML = filtered.slice(0, 120).map((u) => {
    const uid = String(u.userId || u.id || "");
    const isSelf = Boolean(currentUser && uid === currentUser.uid);
    const isBlocked = Boolean(u.blocked || u.accountStatus === "BLOCKED");
    const isSuspended = Boolean(u.suspended || u.accountStatus === "SUSPENDED");
    const statusLabel = isBlocked ? "BLOCKED" : isSuspended ? "SUSPENDED" : "ACTIVE";
    const statusBadge = isBlocked ? "badge-err" : isSuspended ? "badge-warn" : "badge-green";
    return `
      <div class="list-item">
        <div class="list-header">
          <div>
            <strong>${escapeHtml(u.displayName || "Unnamed User")}${isSelf ? " (You)" : ""}</strong>
            <span class="badge ${statusBadge}">${statusLabel}</span>
            ${u.isVerifiedTechnician ? `<span class="badge badge-cyan">VERIFIED TECH</span>` : ""}
            ${u.communityRestricted ? `<span class="badge badge-warn">COMM RESTRICTED</span>` : ""}
            ${u.uploadRestricted ? `<span class="badge badge-err">UPLOAD RESTRICTED</span>` : ""}
            <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(u.email || "No email")} • UID: <code>${escapeHtml(uid)}</code></div>
            ${u.moderationReason ? `<div style="font-size:12px;color:var(--warning);margin-top:2px;">Reason: ${escapeHtml(u.moderationReason)}</div>` : ""}
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <button type="button" class="btn btn-outline btn-sm" ${isSelf ? "disabled" : ""} data-user-mod="${isSuspended ? "unsuspend" : "suspend"}" data-user-id="${escapeHtml(uid)}">${isSuspended ? "Unsuspend" : "Suspend"}</button>
            <button type="button" class="btn btn-outline btn-sm" ${isSelf ? "disabled" : ""} data-user-mod="${isBlocked ? "unblock" : "block"}" data-user-id="${escapeHtml(uid)}">${isBlocked ? "Unblock" : "Block"}</button>
            <button type="button" class="btn btn-outline btn-sm" ${isSelf ? "disabled" : ""} data-user-mod="${u.communityRestricted ? "unrestrict_community" : "restrict_community"}" data-user-id="${escapeHtml(uid)}">${u.communityRestricted ? "Allow Community" : "Restrict Community"}</button>
            <button type="button" class="btn btn-outline btn-sm" ${isSelf ? "disabled" : ""} data-user-mod="${u.uploadRestricted ? "unrestrict_upload" : "restrict_upload"}" data-user-id="${escapeHtml(uid)}">${u.uploadRestricted ? "Allow Uploads" : "Restrict Uploads"}</button>
            ${(isBlocked || isSuspended || u.communityRestricted || u.uploadRestricted) ? `<button type="button" class="btn btn-success btn-sm" ${isSelf ? "disabled" : ""} data-user-mod="restore" data-user-id="${escapeHtml(uid)}">Restore All</button>` : ""}
            <button type="button" class="btn btn-danger btn-sm" ${isSelf ? "disabled" : ""} data-user-del="${escapeHtml(uid)}">Delete Account</button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  listEl.querySelectorAll("[data-user-mod]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const uid = btn.dataset.userId;
      const actionType = btn.dataset.userMod;
      const u = cachedUsers.find((x) => String(x.userId || x.id) === uid);
      if (!u) return;
      const needsReason = ["suspend", "block", "restrict_community", "restrict_upload"].includes(actionType);
      const reason = needsReason
        ? (window.prompt(`Optional moderation reason for ${u.displayName || uid}:`, u.moderationReason || "") ?? null)
        : (u.moderationReason || "");
      if (needsReason && reason === null) return;

      const blocked = actionType === "block" ? true : (actionType === "unblock" || actionType === "restore") ? false : Boolean(u.blocked);
      const suspended = actionType === "suspend" ? true : (actionType === "unsuspend" || actionType === "restore") ? false : Boolean(u.suspended);
      const communityRestricted = actionType === "restrict_community" ? true : (actionType === "unrestrict_community" || actionType === "restore") ? false : Boolean(u.communityRestricted);
      const uploadRestricted = actionType === "restrict_upload" ? true : (actionType === "unrestrict_upload" || actionType === "restore") ? false : Boolean(u.uploadRestricted);

      try {
        await callAdminUserManagementFn({
          action: "moderate_user",
          targetUid: uid,
          blocked,
          suspended,
          communityRestricted,
          uploadRestricted,
          reason: String(reason || "").trim()
        });
        await refreshTable("user_profiles");
        showToast(`User moderation updated (${actionType}).`);
      } catch (err) {
        showToast(`Moderation failed: ${err.message}`, true);
      }
    });
  });

  listEl.querySelectorAll("[data-user-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const uid = btn.dataset.userDel;
      const u = cachedUsers.find((x) => String(x.userId || x.id) === uid);
      const label = u ? `${u.displayName || uid} (${u.email || uid})` : uid;
      if (!(await openConfirmModal("Permanently Delete User Account", `Invoke admin-user-management Edge Function to permanently delete ${label} from Firebase Auth & Supabase?`))) return;
      try {
        await callAdminUserManagementFn({
          action: "delete_user_account",
          targetUid: uid,
          confirmDelete: true
        });
        await refreshTable("user_profiles");
        showToast(`User account ${uid} permanently deleted.`);
      } catch (err) {
        showToast(`Account deletion failed: ${err.message}`, true);
      }
    });
  });
}

function exportJsonBackup() {
  const payload = {
    exportedAt: new Date().toISOString(),
    catalogEntries: cachedCatalog,
    technicians: cachedTechnicians,
    technicalDocuments: cachedDocuments,
    storageConfig: storageState,
    aiConfig: aiState,
    billingConfig: billingState
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `repairpro-backup-${Date.now()}.json`;
  a.click();
}

$("quick-export-btn")?.addEventListener("click", exportJsonBackup);
$("download-backup-btn")?.addEventListener("click", exportJsonBackup);

$("register-self-admin-btn")?.addEventListener("click", async () => {
  if (!currentUser) return;
  try {
    await sbUpsert("admin_roles", {
      user_id: currentUser.uid,
      email: currentUser.email || "",
      role: "SUPER_ADMIN"
    }, "user_id", currentUser);
    await refreshTable("admin_roles");
    showToast("Your UID is now registered in Supabase admin_roles.");
  } catch (err) {
    showToast(`Failed: ${err.message}`, true);
  }
});

$("role-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;
  const uid = $("role-uid").value.trim();
  const email = ($("role-email")?.value || "").trim().slice(0, 160);
  const role = $("role-name").value;
  if (!uid) return;
  try {
    await sbUpsert("admin_roles", {
      user_id: uid,
      email,
      role
    }, "user_id", currentUser);
    await writeAuditLog("GRANT_ADMIN_ROLE", "admin_roles", uid, `Role=${role}`);
    await refreshTable("admin_roles");
    $("role-form").reset();
    showToast(`Granted ${role} to ${uid}.`);
  } catch (err) {
    showToast(`Role update failed: ${err.message}`, true);
  }
});

function renderRolesList(roles) {
  const listEl = $("roles-list");
  if (!listEl) return;
  listEl.innerHTML = roles.length
    ? roles.map((r) => `
        <div class="list-item">
          <div class="list-header">
            <div>
              <strong>${escapeHtml(r.userId)}</strong>
              ${r.email ? `<span style="font-size:12px;color:var(--text-muted);margin-left:6px;">${escapeHtml(r.email)}</span>` : ""}
              <span class="badge badge-cyan">${escapeHtml(r.role)}</span>
            </div>
            <button type="button" class="btn btn-danger btn-sm" data-role-del="${escapeHtml(r.id)}">Revoke</button>
          </div>
        </div>
      `).join("")
    : `<div class="list-item"><span style="color:var(--text-muted);">No extra admin entries yet.</span></div>`;

  listEl.querySelectorAll("[data-role-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await sbDelete("admin_roles", `user_id=eq.${encodeURIComponent(btn.dataset.roleDel)}`, currentUser);
        await refreshTable("admin_roles");
        showToast("Admin role revoked.");
      } catch (err) {
        showToast(`Revoke failed: ${err.message}`, true);
      }
    });
  });
}

function renderAuditLogs() {
  const listEl = $("audit-list");
  if (!listEl) return;
  listEl.innerHTML = cachedAuditLogs.length
    ? cachedAuditLogs.slice(0, 50).map((l) => `
        <div class="list-item">
          <div class="list-header">
            <strong>${escapeHtml(l.action)}</strong>
            <span style="font-size:11px;color:var(--text-muted);">${escapeHtml(formatTs(l.createdAt))}</span>
          </div>
          <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(l.adminEmail)} • ${escapeHtml(l.targetType)}/${escapeHtml(l.targetId)} — ${escapeHtml(l.details)}</div>
        </div>
      `).join("")
    : `<div class="list-item"><span style="color:var(--text-muted);">No audit logs yet.</span></div>`;
}
