// Repair Pro v3.0 — Shared Firebase & Supabase Backend Configuration (Web Super Admin Panel)
// Connects to the exact same Firebase project, named Firestore database, and Supabase project as Android.
// Note: Firebase client config identifies your Firebase project; all access control is enforced
// server-side by Firebase Authentication + deployed firestore.rules + Supabase Edge JWT verification.
// Zero hardcoded admin passwords, zero service-role keys, zero storage provider secrets.

export const firebaseConfig = {
  apiKey: "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M",
  authDomain: "gen-lang-client-0218221723.firebaseapp.com",
  projectId: "gen-lang-client-0218221723",
  storageBucket: "gen-lang-client-0218221723.firebasestorage.app",
  messagingSenderId: "548310962148"
};

export const APP_VERSION = "3.0";
export const APP_VERSION_CODE = 3;
export const FIRESTORE_DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
export const BOOTSTRAP_SUPER_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";

export const SUPABASE_PROJECT_REF = "xuakzzjtcgcvudkgxpbd";
export const SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";

const ANON_KEY_STORAGE = "repair_pro_supabase_anon_key";

export function getSupabaseAnonKey() {
  try {
    return (window.localStorage.getItem(ANON_KEY_STORAGE) || "").trim();
  } catch (_) {
    return "";
  }
}

export function setSupabaseAnonKey(val) {
  try {
    const clean = String(val || "").trim();
    if (clean) window.localStorage.setItem(ANON_KEY_STORAGE, clean);
    else window.localStorage.removeItem(ANON_KEY_STORAGE);
  } catch (_) {}
}
