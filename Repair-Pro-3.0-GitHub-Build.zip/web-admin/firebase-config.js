// Repair Pro — Shared Firebase Auth/FCM & Supabase Primary Backend Configuration (Web Super Admin Panel)
// Firebase is used EXCLUSIVELY for Authentication & Push Notifications (FCM).
// Supabase (xuakzzjtcgcvudkgxpbd) is the primary database, storage, and Edge Functions backend.
// Never place Firebase Service Account private keys, Supabase service_role keys,
// AI provider keys, or PHP hosting secrets in this file.

export const firebaseConfig = {
  apiKey: "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M",
  authDomain: "gen-lang-client-0218221723.firebaseapp.com",
  projectId: "gen-lang-client-0218221723",
  storageBucket: "gen-lang-client-0218221723.firebasestorage.app",
  messagingSenderId: "548310962148"
};

// Preserved legacy identifier reference (Firestore is removed from runtime data dependencies)
export const LEGACY_FIRESTORE_DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
export const BOOTSTRAP_SUPER_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";

export const SUPABASE_PROJECT_NAME = "Repair-Pro";
export const SUPABASE_PROJECT_REF = "xuakzzjtcgcvudkgxpbd";
export const SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";
export const DEFAULT_FCM_ENDPOINT = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-push-notification";
export const DEFAULT_HOSTING_PROXY_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/hosting-proxy-upload";
export const DEFAULT_AI_PROXY_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/ai-repair-assistant";
export const DEFAULT_ADMIN_USER_MANAGEMENT_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/admin-user-management";

export const DEFAULT_SUPABASE_BUCKETS = {
  community: "community-photos",
  technicians: "technician-photos",
  pdfs: "repair-pdfs",
  diagrams: "circuit-diagrams",
  verification: "verification-documents",
  user_profiles: "user-avatars"
};

export const DEFAULT_STORAGE_ROUTING = {
  community: "supabase_primary",
  technicians: "supabase_primary",
  pdfs: "supabase_primary",
  diagrams: "supabase_primary",
  verification: "supabase_primary",
  user_profiles: "supabase_primary"
};

export const FREE_TIER_STORAGE_LIMIT_BYTES = 1073741824; // 1 GB Free Plan limit
