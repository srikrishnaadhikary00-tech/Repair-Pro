// Repair Pro — Shared Firebase & Supabase Configuration (Web Super Admin Panel)
// Preserves exact existing project IDs and named Firestore database.
// Never place Firebase Service Account private keys, Supabase service_role keys,
// or S3/R2 private secrets in this file.

export const firebaseConfig = {
  apiKey: "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M",
  authDomain: "gen-lang-client-0218221723.firebaseapp.com",
  projectId: "gen-lang-client-0218221723",
  storageBucket: "gen-lang-client-0218221723.firebasestorage.app",
  messagingSenderId: "548310962148"
};

export const FIRESTORE_DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
export const BOOTSTRAP_SUPER_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";

export const SUPABASE_PROJECT_NAME = "Repair-Pro";
export const SUPABASE_PROJECT_REF = "xuakzzjtcgcvudkgxpbd";
export const SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co";
export const DEFAULT_FCM_ENDPOINT = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-push-notification";
export const DEFAULT_HOSTING_PROXY_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/hosting-proxy-upload";
export const DEFAULT_AI_PROXY_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/ai-repair-assistant";

export const DEFAULT_SUPABASE_BUCKETS = {
  community: "community-photos",
  technicians: "technician-photos",
  pdfs: "repair-pdfs",
  diagrams: "circuit-diagrams",
  verification: "verification-documents"
};

export const FREE_TIER_STORAGE_LIMIT_BYTES = 1073741824; // 1 GB Free Plan limit
