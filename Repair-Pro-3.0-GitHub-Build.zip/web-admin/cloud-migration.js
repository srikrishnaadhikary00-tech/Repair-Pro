import {
  DEFAULT_FCM_ENDPOINT,
  DEFAULT_HOSTING_PROXY_URL,
  DEFAULT_STORAGE_ROUTING,
  DEFAULT_SUPABASE_BUCKETS,
  FREE_TIER_STORAGE_LIMIT_BYTES,
  SUPABASE_URL
} from "./firebase-config.js";
import {
  fileToBase64,
  getSupabaseAnonKey,
  getSupabaseUrl,
  sbDelete,
  sbFetch,
  sbSaveSetting,
  sbSelect,
  sbUpdate,
  sbUpsert
} from "./supabase-client.js";

export const DISCOVERY_CACHE_KEY = "repairpro_cloud_discovery_v1";
export const DEFAULT_DB_LIMIT_BYTES = 524288000; // 500 MB Supabase Free DB tier

export const PROTECTED_MIGRATION_TABLES = new Set([
  "admin_roles",
  "app_settings",
  "user_profiles",
  "fcm_tokens",
  "ai_providers",
  "ai_configs",
  "storage_providers",
  "hosting_provider_secrets",
  "cloud_manifest",
  "cloud_migration_runs",
  "cloud_migration_items",
  "cloud_backup_manifests",
  "cloud_scheduler_status",
  "audit_logs",
  "storage_error_logs"
]);

export const MIGRATION_TABLES = [
  { table: "repair_catalog_entries", cpanelTable: "catalog_entries", pk: "id", categoryKey: "community", orderBy: "updated_at", protectedFromCleanup: false },
  { table: "technicians", cpanelTable: "technicians", pk: "technician_id", categoryKey: "technicians", orderBy: "updated_at", protectedFromCleanup: false },
  { table: "technician_verification_requests", cpanelTable: "technician_verification_requests", pk: "user_id", categoryKey: "verification", orderBy: "updated_at", protectedFromCleanup: false },
  { table: "community_posts", cpanelTable: "community_posts", pk: "post_id", categoryKey: "community", orderBy: "created_at", protectedFromCleanup: false },
  { table: "community_comments", cpanelTable: "community_comments", pk: "comment_id", categoryKey: "community", orderBy: "created_at", protectedFromCleanup: false },
  { table: "community_likes", cpanelTable: "community_likes", pk: "like_id", categoryKey: "community", orderBy: "created_at", protectedFromCleanup: false },
  { table: "community_bookmarks", cpanelTable: "community_bookmarks", pk: "bookmark_id", categoryKey: "community", orderBy: "created_at", protectedFromCleanup: false },
  { table: "community_reports", cpanelTable: "community_reports", pk: "report_id", categoryKey: "community", orderBy: "created_at", protectedFromCleanup: false },
  { table: "community_user_restrictions", cpanelTable: "community_user_restrictions", pk: "user_id", categoryKey: "community", orderBy: "created_at", protectedFromCleanup: true },
  { table: "technical_documents", cpanelTable: "technical_documents", pk: "doc_id", categoryKey: "pdfs", orderBy: "updated_at", protectedFromCleanup: false },
  { table: "problem_reports", cpanelTable: "problem_reports", pk: "report_id", categoryKey: "community", orderBy: "created_at", protectedFromCleanup: false },
  { table: "user_profiles", cpanelTable: "user_profiles", pk: "user_id", categoryKey: "user_profiles", orderBy: "updated_at", protectedFromCleanup: true },
  { table: "saved_guides", cpanelTable: "saved_guides", pk: "guide_id", categoryKey: "community", orderBy: "created_at", protectedFromCleanup: false },
  { table: "admin_roles", cpanelTable: "admin_roles", pk: "user_id", categoryKey: "community", orderBy: "created_at", protectedFromCleanup: true }
];

export const MIGRATION_BUCKETS = [
  { key: "community", bucket: "community-photos", isPrivate: false },
  { key: "technicians", bucket: "technician-photos", isPrivate: false },
  { key: "pdfs", bucket: "repair-pdfs", isPrivate: false },
  { key: "diagrams", bucket: "circuit-diagrams", isPrivate: false },
  { key: "verification", bucket: "verification-documents", isPrivate: true },
  { key: "user_profiles", bucket: "user-avatars", isPrivate: false }
];

export function defaultMigrationConfig() {
  return {
    configType: "MIGRATION",
    autoFailoverEnabled: true,
    autoMigrationEnabled: false,
    autoCleanupEnabled: false,
    dbMigrationThresholdPct: 80,
    storageMigrationThresholdPct: 80,
    dbLimitBytes: DEFAULT_DB_LIMIT_BYTES,
    storageLimitBytes: FREE_TIER_STORAGE_LIMIT_BYTES,
    primaryDbProviderId: "supabase_primary",
    fallbackDiscoveryUrls: [],
    configVersion: 1
  };
}

export function normalizeMigrationConfig(raw = {}) {
  const base = defaultMigrationConfig();
  const urls = Array.isArray(raw.fallbackDiscoveryUrls)
    ? raw.fallbackDiscoveryUrls.map((u) => String(u || "").trim()).filter((u) => /^https:\/\//i.test(u))
    : [];
  return {
    configType: "MIGRATION",
    autoFailoverEnabled: raw.autoFailoverEnabled !== undefined ? Boolean(raw.autoFailoverEnabled) : base.autoFailoverEnabled,
    autoMigrationEnabled: Boolean(raw.autoMigrationEnabled),
    autoCleanupEnabled: Boolean(raw.autoCleanupEnabled),
    dbMigrationThresholdPct: Math.min(99, Math.max(10, Math.round(Number(raw.dbMigrationThresholdPct || base.dbMigrationThresholdPct)))),
    storageMigrationThresholdPct: Math.min(99, Math.max(10, Math.round(Number(raw.storageMigrationThresholdPct || base.storageMigrationThresholdPct)))),
    dbLimitBytes: Math.max(10 * 1024 * 1024, Math.round(Number(raw.dbLimitBytes || base.dbLimitBytes))),
    storageLimitBytes: Math.max(10 * 1024 * 1024, Math.round(Number(raw.storageLimitBytes || base.storageLimitBytes))),
    primaryDbProviderId: String(raw.primaryDbProviderId || "supabase_primary").trim() || "supabase_primary",
    fallbackDiscoveryUrls: Array.from(new Set(urls)),
    configVersion: Math.max(1, Math.round(Number(raw.configVersion || 1)))
  };
}

// =========================================================================
// DISCOVERY CACHE & DIRECT CPANEL HTTPS CLIENT
// =========================================================================

export function saveDiscoveryCache(payload) {
  try {
    if (typeof localStorage === "undefined") return;
    localStorage.setItem(DISCOVERY_CACHE_KEY, JSON.stringify({
      savedAt: new Date().toISOString(),
      config: payload
    }));
  } catch { /* ignore */ }
}

export function loadDiscoveryCache() {
  try {
    if (typeof localStorage === "undefined") return null;
    const raw = localStorage.getItem(DISCOVERY_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed?.config || null;
  } catch {
    return null;
  }
}

export function buildPhpActionUrl(baseEndpoint, action) {
  const clean = String(baseEndpoint || "").trim();
  const sep = clean.includes("?") ? "&" : "?";
  return `${clean}${sep}action=${encodeURIComponent(action)}`;
}

export async function callCpanelDirect(endpointUrl, action, body = {}, currentUser = null) {
  const clean = String(endpointUrl || "").trim();
  if (!/^https:\/\//i.test(clean)) {
    throw new Error("cPanel hosting endpoint URL must start with https://");
  }
  const url = buildPhpActionUrl(clean, action);
  const run = async (forceRefresh) => {
    const token = currentUser ? await currentUser.getIdToken(forceRefresh) : "";
    return fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      },
      body: JSON.stringify({ ...body, action })
    });
  };
  let resp = await run(false);
  if (resp.status === 401 && currentUser) {
    resp = await run(true);
  }
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok || data.ok === false) {
    throw new Error(data.message || `cPanel API HTTP ${resp.status}`);
  }
  return data;
}

export async function fetchDiscoveryFromExternalHosts(candidateUrls = []) {
  for (const rawUrl of candidateUrls) {
    const clean = String(rawUrl || "").trim();
    if (!/^https:\/\//i.test(clean)) continue;
    try {
      const resp = await fetch(buildPhpActionUrl(clean, "public_config_discovery"), { method: "GET" });
      if (!resp.ok) continue;
      const data = await resp.json().catch(() => ({}));
      if (data?.ok && data?.config && typeof data.config === "object") {
        return data.config;
      }
    } catch {
      // try next discovery host
    }
  }
  return null;
}

export function buildNonSecretDiscoveryPayload(storageState, migrationConfig) {
  const cleanProviders = (storageState?.providers || []).map((p) => ({
    providerId: p.providerId,
    providerName: p.providerName,
    providerType: p.providerType,
    endpointUrl: p.endpointUrl,
    publicAnonKey: p.providerType === "SUPABASE_STORAGE" ? (p.publicAnonKey || "") : "",
    proxyUploadUrl: p.proxyUploadUrl || "",
    hostingVendor: p.hostingVendor || "",
    publicMediaBaseUrl: p.publicMediaBaseUrl || "",
    communityOnly: Boolean(p.communityOnly),
    supportsStorage: p.supportsStorage !== false,
    supportsDatabase: Boolean(p.supportsDatabase),
    dbEnabled: Boolean(p.dbEnabled),
    dbEngine: p.dbEngine || "MYSQL",
    role: p.role || "BACKUP",
    enabled: Boolean(p.enabled),
    capacityLimitBytes: Number(p.capacityLimitBytes || FREE_TIER_STORAGE_LIMIT_BYTES),
    usedBytes: Number(p.usedBytes || 0),
    buckets: p.buckets || { ...DEFAULT_SUPABASE_BUCKETS }
  }));
  const phpEndpoints = cleanProviders
    .filter((p) => p.enabled && p.providerType === "PHP_HOSTING" && /^https:\/\//i.test(p.endpointUrl))
    .map((p) => p.endpointUrl);
  const allDiscoveryUrls = Array.from(new Set([...(migrationConfig?.fallbackDiscoveryUrls || []), ...phpEndpoints]));

  return {
    configType: "CLOUD_MANIFEST",
    autoFailoverEnabled: storageState?.autoFailoverEnabled !== false,
    fcmBackendUrl: storageState?.fcmBackendUrl || DEFAULT_FCM_ENDPOINT,
    hostingProxyUrl: storageState?.hostingProxyUrl || DEFAULT_HOSTING_PROXY_URL,
    compressionMaxDim: Number(storageState?.compressionMaxDim || 1440),
    compressionQuality: Number(storageState?.compressionQuality || 82),
    compressionMaxSizeKb: Number(storageState?.compressionMaxSizeKb || 4500),
    duplicateCheckEnabled: storageState?.duplicateCheckEnabled !== false,
    categoryMappings: { ...DEFAULT_STORAGE_ROUTING, ...(storageState?.categoryMappings || {}) },
    providers: cleanProviders,
    autoMigrationEnabled: Boolean(migrationConfig?.autoMigrationEnabled),
    autoCleanupEnabled: Boolean(migrationConfig?.autoCleanupEnabled),
    dbMigrationThresholdPct: Number(migrationConfig?.dbMigrationThresholdPct || 80),
    storageMigrationThresholdPct: Number(migrationConfig?.storageMigrationThresholdPct || 80),
    primaryDbProviderId: migrationConfig?.primaryDbProviderId || "supabase_primary",
    fallbackDiscoveryUrls: allDiscoveryUrls,
    configVersion: Number(migrationConfig?.configVersion || 1) + 1
  };
}

export async function syncDiscoveryManifestToExternalHosts(storageState, migrationConfig, currentUser) {
  const payload = buildNonSecretDiscoveryPayload(storageState, migrationConfig);
  saveDiscoveryCache(payload);
  const phpHosts = (storageState?.providers || []).filter(
    (p) => p.enabled && p.providerType === "PHP_HOSTING" && /^https:\/\//i.test(p.endpointUrl)
  );
  const results = [];
  for (const host of phpHosts) {
    try {
      const res = await callCpanelDirect(host.endpointUrl, "save_manifest", { config: payload }, currentUser);
      results.push({ providerId: host.providerId, ok: true, res });
    } catch (err) {
      results.push({ providerId: host.providerId, ok: false, error: err?.message || String(err) });
    }
  }
  return { payload, results };
}

// =========================================================================
// FAILOVER DETECTION, MERGED READS & MULTI-CLOUD DB CRUD
// =========================================================================

export function isSupabaseQuotaOrOutageError(err) {
  const msg = String(err?.message || err || "").toLowerCase();
  if (!msg) return false;
  return (
    msg.includes("507") ||
    msg.includes("503") ||
    msg.includes("502") ||
    msg.includes("504") ||
    msg.includes("500") ||
    msg.includes("429") ||
    msg.includes("413") ||
    msg.includes("402") ||
    msg.includes("quota") ||
    msg.includes("insufficient storage") ||
    msg.includes("database size") ||
    msg.includes("paused") ||
    msg.includes("failed to fetch") ||
    msg.includes("networkerror") ||
    msg.includes("timeout") ||
    msg.includes("missing") ||
    msg.includes("unreachable") ||
    msg.includes("econnrefused")
  );
}

export function isExternalDbProvider(p) {
  return Boolean(
    p &&
    p.enabled &&
    p.role !== "DISABLED" &&
    p.supportsDatabase &&
    p.dbEnabled &&
    (p.providerType === "PHP_HOSTING" || p.providerType === "EXTERNAL_DB") &&
    /^https:\/\//i.test(String(p.endpointUrl || ""))
  );
}

export function isPrimaryDatabaseSupabase(storageState, migrationConfig) {
  const providers = storageState?.providers || [];
  const hasPrimaryExternal = providers.some((p) => isExternalDbProvider(p) && p.role === "PRIMARY");
  const primaryId = String(migrationConfig?.primaryDbProviderId || "supabase_primary");
  return primaryId === "supabase_primary" && !hasPrimaryExternal;
}

export function getReadableExternalDbProviders(storageState, categoryKey = "") {
  const providers = (storageState?.providers || []).filter((p) => {
    if (!isExternalDbProvider(p)) return false;
    if (p.communityOnly && categoryKey && !["community", "technicians"].includes(categoryKey)) {
      return false;
    }
    return true;
  });
  const mappedId = categoryKey ? storageState?.categoryMappings?.[categoryKey] : "";
  const mapped = providers.filter((p) => p.providerId === mappedId);
  const primary = providers.filter((p) => p.role === "PRIMARY" && p.providerId !== mappedId);
  const backups = providers.filter((p) => p.role !== "PRIMARY" && p.providerId !== mappedId);
  return [...mapped, ...primary, ...backups];
}

function rowTimestampMs(row) {
  const candidates = [row?.updated_at, row?.updatedAt, row?.saved_at, row?.created_at, row?.createdAt];
  for (const val of candidates) {
    if (!val) continue;
    const ms = Date.parse(val);
    if (!Number.isNaN(ms)) return ms;
  }
  return 0;
}

export function mergeCloudRows(supaRows = [], extRowLists = [], pkFields = ["id"], sortField = "updated_at") {
  const deduped = new Map();
  let anonIdx = 0;

  const ingest = (list, defaultProviderId = "") => {
    if (!Array.isArray(list)) return;
    for (const raw of list) {
      if (!raw || typeof raw !== "object") continue;
      const row = defaultProviderId && !raw.storage_provider_id
        ? { ...raw, storage_provider_id: defaultProviderId }
        : raw;
      let pk = "";
      for (const col of pkFields) {
        const v = String(row[col] ?? "").trim();
        if (v && v !== "null" && v !== "undefined") {
          pk = v;
          break;
        }
      }
      if (!pk) pk = `anon_${anonIdx++}`;
      const prev = deduped.get(pk);
      if (!prev) {
        deduped.set(pk, row);
      } else if (rowTimestampMs(row) > rowTimestampMs(prev)) {
        deduped.set(pk, row);
      }
    }
  };

  ingest(supaRows, "supabase_primary");
  for (const entry of extRowLists) {
    if (Array.isArray(entry)) ingest(entry, "");
    else if (entry && Array.isArray(entry.rows)) ingest(entry.rows, entry.providerId || "");
  }

  return Array.from(deduped.values()).sort((a, b) => {
    const tA = rowTimestampMs(a) || Date.parse(a?.[sortField] || "") || 0;
    const tB = rowTimestampMs(b) || Date.parse(b?.[sortField] || "") || 0;
    return tB - tA;
  });
}

const partialCloudFailureMap = new Map();

export function getPartialCloudFailures() {
  return Array.from(partialCloudFailureMap.values());
}

export async function multiCloudDbQuery({
  table,
  cpanelTable,
  categoryKey = "community",
  supabaseQuery = "select=*&limit=400",
  extFilters = {},
  extLimit = 400,
  orderBy = "updated_at",
  pkFields = ["id"],
  currentUser,
  storageState
}) {
  const extProviders = getReadableExternalDbProviders(storageState, categoryKey);
  const supaPromise = getSupabaseAnonKey()
    ? sbSelect(table, supabaseQuery, currentUser).then((rows) => ({ ok: true, rows })).catch((err) => ({ ok: false, err }))
    : Promise.resolve({ ok: false, err: new Error("Supabase Anon Key missing") });

  const extPromises = extProviders.map((prov) =>
    callCpanelDirect(prov.endpointUrl, "db_query", {
      table: cpanelTable || table,
      filters: extFilters,
      limit: extLimit,
      orderBy,
      orderDir: "DESC"
    }, currentUser)
      .then((res) => ({ ok: true, providerId: prov.providerId, providerName: prov.providerName || prov.providerId, rows: Array.isArray(res.rows) ? res.rows : [] }))
      .catch((err) => ({ ok: false, providerId: prov.providerId, providerName: prov.providerName || prov.providerId, err }))
  );

  const [supaRes, ...extResults] = await Promise.all([supaPromise, ...extPromises]);
  const anyOk = supaRes.ok || extResults.some((r) => r.ok);
  if (!anyOk) {
    const firstErr = supaRes.err || extResults.find((r) => r.err)?.err || new Error(`Failed querying ${table}`);
    throw firstErr;
  }

  const failedSources = [];
  if (!supaRes.ok && extProviders.length > 0) failedSources.push("Supabase Primary");
  for (const r of extResults) {
    if (!r.ok) failedSources.push(r.providerName || r.providerId);
  }
  if (failedSources.length > 0) {
    partialCloudFailureMap.set(table, {
      table,
      failedSources: Array.from(new Set(failedSources)),
      updatedAt: new Date().toISOString()
    });
  } else {
    partialCloudFailureMap.delete(table);
  }

  return mergeCloudRows(
    supaRes.ok ? supaRes.rows : [],
    extResults.filter((r) => r.ok),
    pkFields,
    orderBy
  );
}

export async function multiCloudDbUpsert({
  table,
  cpanelTable,
  categoryKey = "community",
  record,
  onConflict,
  currentUser,
  storageState,
  migrationConfig
}) {
  const supabasePrimary = isPrimaryDatabaseSupabase(storageState, migrationConfig);
  const extProviders = getReadableExternalDbProviders(storageState, categoryKey);
  const targetCpanelTable = cpanelTable || table;

  const tryExternal = async () => {
    let lastErr = null;
    for (const prov of extProviders) {
      try {
        const res = await callCpanelDirect(prov.endpointUrl, "db_upsert", {
          table: targetCpanelTable,
          record: { ...record, storage_provider_id: prov.providerId }
        }, currentUser);
        return { ok: true, providerId: prov.providerId, res };
      } catch (err) {
        lastErr = err;
      }
    }
    return { ok: false, err: lastErr };
  };

  if (supabasePrimary) {
    try {
      await sbUpsert(table, record, onConflict, currentUser);
      const activeExt = extProviders.find((p) => p.role === "PRIMARY");
      if (activeExt) {
        await callCpanelDirect(activeExt.endpointUrl, "db_upsert", {
          table: targetCpanelTable,
          record: { ...record, storage_provider_id: activeExt.providerId }
        }, currentUser).catch(() => {});
      }
      return { providerId: "supabase_primary", failoverUsed: false };
    } catch (err) {
      if (extProviders.length && isSupabaseQuotaOrOutageError(err)) {
        const extRes = await tryExternal();
        if (extRes.ok) {
          return { providerId: extRes.providerId, failoverUsed: true };
        }
      }
      throw err;
    }
  } else {
    const extRes = await tryExternal();
    if (extRes.ok) {
      return { providerId: extRes.providerId, failoverUsed: false };
    }
    await sbUpsert(table, record, onConflict, currentUser);
    return { providerId: "supabase_primary", failoverUsed: true };
  }
}

export async function multiCloudDbUpdate({
  table,
  cpanelTable,
  categoryKey = "community",
  recordId,
  supabaseFilter,
  patch,
  currentUser,
  storageState,
  migrationConfig
}) {
  const supabasePrimary = isPrimaryDatabaseSupabase(storageState, migrationConfig);
  const extProviders = getReadableExternalDbProviders(storageState, categoryKey);
  const targetCpanelTable = cpanelTable || table;

  const tryExternalUpdates = async () => {
    let anyOk = false;
    let lastErr = null;
    for (const prov of extProviders) {
      try {
        await callCpanelDirect(prov.endpointUrl, "db_update", {
          table: targetCpanelTable,
          recordId,
          record: patch
        }, currentUser);
        anyOk = true;
      } catch (err) {
        lastErr = err;
      }
    }
    return { anyOk, lastErr };
  };

  if (supabasePrimary) {
    let supaErr = null;
    try {
      await sbUpdate(table, supabaseFilter, patch, currentUser);
      await tryExternalUpdates();
      return { ok: true, providerId: "supabase_primary" };
    } catch (err) {
      supaErr = err;
      const extRes = await tryExternalUpdates();
      if (extRes.anyOk && isSupabaseQuotaOrOutageError(err)) {
        return { ok: true, providerId: extProviders[0]?.providerId || "php_hosting", failoverUsed: true };
      }
      throw supaErr;
    }
  } else {
    const extRes = await tryExternalUpdates();
    if (extRes.anyOk) {
      await sbUpdate(table, supabaseFilter, patch, currentUser).catch(() => {});
      return { ok: true, providerId: extProviders[0]?.providerId || "php_hosting" };
    }
    await sbUpdate(table, supabaseFilter, patch, currentUser);
    return { ok: true, providerId: "supabase_primary", failoverUsed: true };
  }
}

export async function multiCloudDbDelete({
  table,
  cpanelTable,
  categoryKey = "community",
  recordId,
  supabaseFilter,
  currentUser,
  storageState,
  migrationConfig
}) {
  const supabasePrimary = isPrimaryDatabaseSupabase(storageState, migrationConfig);
  const extProviders = getReadableExternalDbProviders(storageState, categoryKey);
  const targetCpanelTable = cpanelTable || table;

  const tryExternalDeletes = async () => {
    let anyOk = false;
    let lastErr = null;
    for (const prov of extProviders) {
      try {
        await callCpanelDirect(prov.endpointUrl, "db_delete", {
          table: targetCpanelTable,
          recordId
        }, currentUser);
        anyOk = true;
      } catch (err) {
        lastErr = err;
      }
    }
    return { anyOk, lastErr };
  };

  if (supabasePrimary) {
    try {
      await sbDelete(table, supabaseFilter, currentUser);
      await tryExternalDeletes();
      return { ok: true };
    } catch (err) {
      const extRes = await tryExternalDeletes();
      if (extRes.anyOk && isSupabaseQuotaOrOutageError(err)) {
        return { ok: true, failoverUsed: true };
      }
      throw err;
    }
  } else {
    const extRes = await tryExternalDeletes();
    if (extRes.anyOk) {
      await sbDelete(table, supabaseFilter, currentUser).catch(() => {});
      return { ok: true };
    }
    await sbDelete(table, supabaseFilter, currentUser);
    return { ok: true, failoverUsed: true };
  }
}

// =========================================================================
// PRIVATE DOCUMENT ACCESS (SUPABASE SIGNED URL + CPANEL SIGNED TOKEN)
// =========================================================================

export async function openPrivateCredentialDocument(
  verificationReq,
  storageState,
  currentUser,
  supaProvider,
  supabaseCreateSignedUrlFn
) {
  const docUrl = String(verificationReq?.credentialDocUrl || "").trim();
  const docPath = String(verificationReq?.credentialDocStoragePath || "").trim();
  const provId = String(verificationReq?.credentialDocProviderId || "").trim();

  const phpProvider = (storageState?.providers || []).find(
    (p) =>
      p.providerType === "PHP_HOSTING" &&
      p.enabled &&
      (p.providerId === provId ||
        (docUrl && p.endpointUrl && docUrl.startsWith(p.endpointUrl)) ||
        (!docUrl.includes("supabase.co") && docUrl.includes("download_private")))
  );

  if (phpProvider && (docPath || docUrl.includes("download_private"))) {
    const cleanPath = docPath || decodeURIComponent((docUrl.split("storagePath=")[1] || "").split("&")[0]);
    const res = await callCpanelDirect(phpProvider.endpointUrl, "create_private_download_token", {
      storagePath: cleanPath,
      expiresInSeconds: 300
    }, currentUser);
    if (res?.signedUrl) {
      return res.signedUrl;
    }
  }

  if (docPath && !docUrl.includes("download_private")) {
    return await supabaseCreateSignedUrlFn(supaProvider, "verification-documents", docPath, 300);
  }
  if (/^https:\/\//i.test(docUrl)) {
    return docUrl;
  }
  throw new Error("No valid HTTPS credential document URL or private storage path found.");
}

// =========================================================================
// PRE-ACTIVATION CHECKS, USAGE TELEMETRY & THRESHOLD EVALUATION
// =========================================================================

export async function validateCpanelHostingReadiness(provider, currentUser, tempSecret = "", proxyCaller = null) {
  const checks = [];
  const endpointUrl = String(provider?.endpointUrl || "").trim();
  const isHttps = /^https:\/\//i.test(endpointUrl);
  checks.push({
    name: "HTTPS Endpoint",
    passed: isHttps,
    detail: isHttps ? endpointUrl : "Endpoint URL must use https://"
  });
  if (!isHttps) {
    return { ready: false, checks, health: null, dbHealth: null };
  }

  let health = null;
  let healthErr = null;
  try {
    health = await callCpanelDirect(endpointUrl, "health", {}, currentUser);
  } catch (err) {
    healthErr = err;
    if (proxyCaller) {
      try {
        health = await proxyCaller({
          action: "test_connection",
          providerId: provider.providerId,
          uploadApiUrl: endpointUrl,
          endpointUrl,
          tempApiSecret: tempSecret || undefined
        });
      } catch (proxyErr) {
        healthErr = proxyErr;
      }
    }
  }

  checks.push({
    name: "PHP API Reachable & Auth",
    passed: Boolean(health && health.ok !== false),
    detail: health ? `PHP ${health.phpVersion || "OK"} (${health.authMethod || "token"})` : (healthErr?.message || "Unreachable")
  });
  checks.push({
    name: "OpenSSL (Firebase RS256)",
    passed: Boolean(health?.opensslAvailable !== false && health),
    detail: health?.opensslAvailable ? "Available" : "openssl_verify missing or check skipped"
  });
  checks.push({
    name: "Public & Private Folders Writable",
    passed: Boolean(health && (health.writable || health.uploadsWritable)),
    detail: health
      ? `public=${Boolean(health.publicWritable ?? health.uploadsWritable)}, private=${Boolean(health.privateWritable ?? true)}`
      : "Not checked"
  });
  const freeBytes = Number(health?.diskFreeBytes ?? -1);
  checks.push({
    name: "Sufficient Disk Space (>50 MB free)",
    passed: Boolean(health && (freeBytes < 0 || freeBytes >= 50 * 1024 * 1024)),
    detail: freeBytes >= 0 ? `${Math.round(freeBytes / (1024 * 1024))} MB free` : "Reported OK by host"
  });

  let dbHealth = null;
  if (provider.supportsDatabase || provider.dbEnabled) {
    try {
      dbHealth = await callCpanelDirect(endpointUrl, "db_health", {}, currentUser);
    } catch (err) {
      if (proxyCaller) {
        try {
          dbHealth = await proxyCaller({
            action: "db_health",
            providerId: provider.providerId,
            uploadApiUrl: endpointUrl,
            endpointUrl,
            tempApiSecret: tempSecret || undefined
          });
        } catch { /* ignore */ }
      }
    }
    checks.push({
      name: "External SQL Database (MySQL/SQLite)",
      passed: Boolean(dbHealth && dbHealth.ok !== false),
      detail: dbHealth ? `${dbHealth.driver || provider.dbEngine || "MYSQL"} connected` : "DB connection failed or disabled in config.php"
    });
  }

  const ready = checks.every((c) => c.passed);
  return { ready, checks, health, dbHealth };
}

export async function fetchSupabaseUsageMetrics(currentUser, migrationConfig) {
  const cfg = normalizeMigrationConfig(migrationConfig);
  if (!currentUser || !getSupabaseAnonKey()) {
    return {
      ok: false,
      reachable: false,
      dbUsedBytes: 0,
      dbLimitBytes: cfg.dbLimitBytes,
      storageUsedBytes: 0,
      storageLimitBytes: cfg.storageLimitBytes,
      buckets: [],
      tables: {}
    };
  }
  try {
    const resp = await sbFetch("/rest/v1/rpc/get_supabase_usage_metrics", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}"
    }, currentUser);
    if (resp.ok) {
      const data = await resp.json().catch(() => null);
      if (data && typeof data === "object") {
        return {
          ok: true,
          reachable: true,
          dbUsedBytes: Number(data.dbUsedBytes || 0),
          dbLimitBytes: Number(data.dbLimitBytes || cfg.dbLimitBytes),
          storageUsedBytes: Number(data.storageUsedBytes || 0),
          storageLimitBytes: Number(data.storageLimitBytes || cfg.storageLimitBytes),
          buckets: Array.isArray(data.buckets) ? data.buckets : [],
          tables: data.tables || {},
          measuredAt: data.measuredAt || new Date().toISOString()
        };
      }
    }
  } catch { /* fallback below */ }

  // Safe fallback if RPC hasn't been installed yet
  return {
    ok: false,
    reachable: true,
    rpcMissing: true,
    dbUsedBytes: 0,
    dbLimitBytes: cfg.dbLimitBytes,
    storageUsedBytes: 0,
    storageLimitBytes: cfg.storageLimitBytes,
    buckets: [],
    tables: {}
  };
}

export async function fetchCpanelUsageMetrics(provider, currentUser) {
  if (!provider || !/^https:\/\//i.test(String(provider.endpointUrl || ""))) return null;
  return await callCpanelDirect(provider.endpointUrl, "stats", {}, currentUser);
}

export function evaluateMigrationThresholds(supaMetrics, migrationConfig, storageState) {
  const cfg = normalizeMigrationConfig(migrationConfig);
  const dbLimit = Math.max(1, Number(supaMetrics?.dbLimitBytes || cfg.dbLimitBytes || DEFAULT_DB_LIMIT_BYTES));
  const stLimit = Math.max(1, Number(supaMetrics?.storageLimitBytes || cfg.storageLimitBytes || FREE_TIER_STORAGE_LIMIT_BYTES));
  const dbPct = Math.min(100, Math.round((Number(supaMetrics?.dbUsedBytes || 0) / dbLimit) * 100));
  const storagePct = Math.min(100, Math.round((Number(supaMetrics?.storageUsedBytes || 0) / stLimit) * 100));

  const targetHost = (storageState?.providers || []).find(
    (p) =>
      p.enabled &&
      p.providerType === "PHP_HOSTING" &&
      /^https:\/\//i.test(String(p.endpointUrl || "")) &&
      (p.supportsStorage || (p.supportsDatabase && p.dbEnabled))
  );

  const reasons = [];
  if (dbPct >= cfg.dbMigrationThresholdPct) {
    reasons.push(`Supabase DB at ${dbPct}% (>= ${cfg.dbMigrationThresholdPct}% threshold)`);
  }
  if (storagePct >= cfg.storageMigrationThresholdPct) {
    reasons.push(`Supabase Storage at ${storagePct}% (>= ${cfg.storageMigrationThresholdPct}% threshold)`);
  }

  return {
    dbPct,
    storagePct,
    hasTargetHost: Boolean(targetHost),
    targetProvider: targetHost || null,
    shouldAutoMigrate: Boolean(cfg.autoMigrationEnabled && targetHost && reasons.length > 0),
    reasons
  };
}

// =========================================================================
// CHECKSUMS, SAFE CLEANUP GATE & RESUMABLE MIGRATION ENGINE
// =========================================================================

export async function computeSha256Hex(arrayBuffer) {
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const digest = await crypto.subtle.digest("SHA-256", arrayBuffer);
    return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  return "";
}

export function canExecuteCleanup({ autoCleanupEnabled, totalItems, verifiedItems, failedItems, targetHealthy }) {
  if (!autoCleanupEnabled) {
    return { allowed: false, reason: "Safe Cleanup is disabled. Enable it only when ready to remove verified Supabase copies." };
  }
  if (!targetHealthy) {
    return { allowed: false, reason: "Target cPanel hosting did not pass health check. Cleanup blocked." };
  }
  if (Number(failedItems || 0) > 0) {
    return { allowed: false, reason: `${failedItems} item(s) failed verification. Cleanup strictly blocked until 0 failures.` };
  }
  if (Number(totalItems || 0) <= 0 || Number(verifiedItems || 0) < Number(totalItems || 0)) {
    return { allowed: false, reason: "Not all items are verified yet. Cleanup blocked." };
  }
  return { allowed: true, reason: "All migrated items verified cleanly with backup manifest saved." };
}

async function persistMigrationRunRecord(run, targetProvider, currentUser) {
  try {
    await sbUpsert("cloud_migration_runs", run, "run_id", currentUser);
  } catch { /* Supabase may be throttled */ }
  if (targetProvider) {
    await callCpanelDirect(targetProvider.endpointUrl, "migration_upsert_run", {
      table: "cloud_migration_runs",
      record: run,
      preserveTimestamps: true
    }, currentUser).catch(() => {});
  }
}

async function persistMigrationItemRecord(item, targetProvider, currentUser) {
  try {
    await sbUpsert("cloud_migration_items", item, "item_id", currentUser);
  } catch { /* ignore */ }
  if (targetProvider) {
    await callCpanelDirect(targetProvider.endpointUrl, "db_upsert", {
      table: "cloud_migration_items",
      record: item,
      preserveTimestamps: true
    }, currentUser).catch(() => {});
  }
}

async function supabaseDownloadBucketObject(supaProvider, bucket, objectPath, isPrivate, currentUser, supabaseCreateSignedUrlFn) {
  const endpoint = String(supaProvider?.endpointUrl || getSupabaseUrl() || SUPABASE_URL).replace(/\/+$/, "");
  const cleanPath = String(objectPath || "").replace(/^\/+/, "").replace(new RegExp(`^${bucket}/`), "");
  let downloadUrl;
  const headers = {};
  if (isPrivate && supabaseCreateSignedUrlFn) {
    downloadUrl = await supabaseCreateSignedUrlFn(supaProvider, bucket, cleanPath, 300);
  } else {
    downloadUrl = `${endpoint}/storage/v1/object/authenticated/${encodeURIComponent(bucket)}/${cleanPath.split("/").map(encodeURIComponent).join("/")}`;
    const anonKey = String(supaProvider?.publicAnonKey || getSupabaseAnonKey() || "").trim();
    const token = currentUser ? await currentUser.getIdToken(false) : anonKey;
    headers.apikey = anonKey;
    headers.Authorization = `Bearer ${token}`;
  }
  const resp = await fetch(downloadUrl, { method: "GET", headers });
  if (!resp.ok) {
    throw new Error(`Supabase download HTTP ${resp.status} for ${bucket}/${cleanPath}`);
  }
  const blob = await resp.blob();
  return blob;
}

export async function runCloudMigration({
  scope = "BOTH",
  triggerMode = "MANUAL",
  targetProvider,
  supaProvider,
  storageState,
  migrationConfig,
  currentUser,
  supabaseListObjectsFn,
  supabaseCreateSignedUrlFn,
  onProgress
}) {
  if (!currentUser) throw new Error("Sign in as Super Admin first.");
  if (!targetProvider) throw new Error("Connect and enable a cPanel PHP Hosting provider first.");

  const reportProgress = (pct, msg) => {
    if (typeof onProgress === "function") onProgress(pct, msg);
  };

  reportProgress(5, "Running pre-activation health & permission checks...");
  const readiness = await validateCpanelHostingReadiness(targetProvider, currentUser);
  if (!readiness.ready) {
    const failed = readiness.checks.filter((c) => !c.passed).map((c) => `${c.name}: ${c.detail}`).join("; ");
    throw new Error(`Target cPanel host failed readiness check: ${failed}`);
  }

  const doDb = scope === "DATABASE" || scope === "BOTH";
  const doStorage = scope === "STORAGE" || scope === "BOTH";

  if (doDb && !(targetProvider.supportsDatabase && targetProvider.dbEnabled)) {
    throw new Error("Target cPanel host does not have External SQL Database enabled.");
  }
  if (doStorage && targetProvider.supportsStorage === false) {
    throw new Error("Target cPanel host does not have File Storage enabled.");
  }

  if (doDb) {
    reportProgress(10, "Initializing / verifying target MySQL/SQLite tables on cPanel...");
    await callCpanelDirect(targetProvider.endpointUrl, "db_init_schema", {}, currentUser);
  }

  const runId = `mig_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const backupId = `bkp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const nowIso = new Date().toISOString();

  const run = {
    run_id: runId,
    source_provider_id: "supabase_primary",
    target_provider_id: targetProvider.providerId,
    trigger_mode: triggerMode,
    scope,
    status: "RUNNING",
    total_items: 0,
    migrated_items: 0,
    verified_items: 0,
    cleaned_items: 0,
    failed_items: 0,
    total_bytes: 0,
    backup_manifest_id: backupId,
    last_cursor: "",
    error_summary: "",
    started_by_uid: currentUser.uid,
    started_at: nowIso,
    updated_at: nowIso
  };
  await persistMigrationRunRecord(run, targetProvider, currentUser);

  const backupEntries = [];
  let totalItems = 0;
  let migratedItems = 0;
  let verifiedItems = 0;
  let failedItems = 0;
  let totalBytes = 0;
  const errors = [];

  // 1. DATABASE MIGRATION
  if (doDb) {
    for (let tIdx = 0; tIdx < MIGRATION_TABLES.length; tIdx += 1) {
      const tbl = MIGRATION_TABLES[tIdx];
      reportProgress(12 + Math.round((tIdx / MIGRATION_TABLES.length) * 35), `Migrating table ${tbl.table}...`);
      let rows = [];
      try {
        rows = await sbSelect(tbl.table, "select=*&limit=500", currentUser);
      } catch (err) {
        errors.push(`Table ${tbl.table} read failed: ${err.message}`);
        continue;
      }
      if (!Array.isArray(rows) || !rows.length) continue;

      const batchSize = 40;
      for (let offset = 0; offset < rows.length; offset += batchSize) {
        const batch = rows.slice(offset, offset + batchSize);
        totalItems += batch.length;
        try {
          const stamped = batch.map((r) => ({
            ...r,
            migrated_to_provider_id: targetProvider.providerId,
            migration_status: "MIGRATED"
          }));
          await callCpanelDirect(targetProvider.endpointUrl, "db_upsert", {
            table: tbl.cpanelTable,
            records: stamped,
            preserveTimestamps: true
          }, currentUser);

          migratedItems += batch.length;
          verifiedItems += batch.length;

          for (const r of batch) {
            const pkVal = String(r[tbl.pk] || "");
            const rowBytes = JSON.stringify(r).length;
            totalBytes += rowBytes;
            const itemRec = {
              item_id: `it_${runId}_${tbl.table}_${pkVal}`.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 120),
              run_id: runId,
              entity_type: "table_row",
              table_or_bucket: tbl.table,
              record_or_path: pkVal,
              source_provider_id: "supabase_primary",
              target_provider_id: targetProvider.providerId,
              checksum_sha256: "",
              byte_size: rowBytes,
              status: "VERIFIED",
              retry_count: 0,
              target_url: targetProvider.endpointUrl,
              error_message: "",
              snapshot_json: r
            };
            backupEntries.push({
              entityType: "table_row",
              table: tbl.table,
              pkCol: tbl.pk,
              pkVal,
              row: r
            });
            await persistMigrationItemRecord(itemRec, targetProvider, currentUser);
          }
        } catch (err) {
          failedItems += batch.length;
          errors.push(`${tbl.table} batch ${offset}: ${err.message}`);
          for (const r of batch) {
            const pkVal = String(r[tbl.pk] || "");
            await persistMigrationItemRecord({
              item_id: `it_${runId}_${tbl.table}_${pkVal}`.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 120),
              run_id: runId,
              entity_type: "table_row",
              table_or_bucket: tbl.table,
              record_or_path: pkVal,
              source_provider_id: "supabase_primary",
              target_provider_id: targetProvider.providerId,
              byte_size: JSON.stringify(r).length,
              status: "FAILED",
              error_message: String(err.message || "Batch upsert failed").slice(0, 400),
              snapshot_json: r
            }, targetProvider, currentUser);
          }
        }
      }
    }
  }

  // 2. STORAGE MIGRATION (WITH SHA-256 VERIFICATION)
  if (doStorage) {
    const eligibleBuckets = MIGRATION_BUCKETS.filter((b) =>
      b.key === "verification" ? !targetProvider.communityOnly : (!targetProvider.communityOnly || ["community", "technicians"].includes(b.key))
    );
    for (let bIdx = 0; bIdx < eligibleBuckets.length; bIdx += 1) {
      const bInfo = eligibleBuckets[bIdx];
      reportProgress(50 + Math.round((bIdx / Math.max(1, eligibleBuckets.length)) * 40), `Scanning bucket ${bInfo.bucket}...`);
      let objects = [];
      try {
        objects = await supabaseListObjectsFn(supaProvider, bInfo.bucket);
      } catch (err) {
        errors.push(`Bucket ${bInfo.bucket} list failed: ${err.message}`);
        continue;
      }
      for (const obj of objects) {
        const objectPath = String(obj.name || "").trim();
        if (!objectPath) continue;
        totalItems += 1;
        const fullStoragePath = `${bInfo.bucket}/${objectPath}`;
        const itemId = `it_${runId}_${fullStoragePath}`.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 120);
        try {
          const blob = await supabaseDownloadBucketObject(
            supaProvider,
            bInfo.bucket,
            objectPath,
            bInfo.isPrivate,
            currentUser,
            supabaseCreateSignedUrlFn
          );
          const buf = await blob.arrayBuffer();
          const sha256 = await computeSha256Hex(buf);
          const base64 = await fileToBase64(blob);
          const uploadRes = await callCpanelDirect(targetProvider.endpointUrl, "upload", {
            bucketName: bInfo.bucket,
            objectPath,
            base64,
            mimeType: blob.type || obj.metadata?.mimetype || "application/octet-stream",
            preserveExactBytes: true,
            skipDedupe: true
          }, currentUser);

          const uploadedPath = uploadRes.storagePath || fullStoragePath;
          const verifyRes = await callCpanelDirect(targetProvider.endpointUrl, "verify_file", {
            storagePath: uploadedPath,
            sha256
          }, currentUser);
          if (!verifyRes.exists || !verifyRes.shaMatch || Number(verifyRes.sizeBytes || 0) <= 0) {
            throw new Error(`Checksum/existence verification failed for ${uploadedPath}`);
          }

          migratedItems += 1;
          verifiedItems += 1;
          totalBytes += Number(verifyRes.sizeBytes || buf.byteLength || 0);

          const itemRec = {
            item_id: itemId,
            run_id: runId,
            entity_type: "storage_object",
            table_or_bucket: bInfo.bucket,
            record_or_path: objectPath,
            source_provider_id: "supabase_primary",
            target_provider_id: targetProvider.providerId,
            checksum_sha256: sha256,
            byte_size: Number(verifyRes.sizeBytes || buf.byteLength || 0),
            status: "VERIFIED",
            retry_count: 0,
            target_url: verifyRes.publicUrl || uploadRes.publicUrl || "",
            error_message: ""
          };
          backupEntries.push({
            entityType: "storage_object",
            bucket: bInfo.bucket,
            objectPath,
            isPrivate: bInfo.isPrivate,
            targetStoragePath: uploadedPath,
            targetUrl: itemRec.target_url,
            sha256,
            sizeBytes: itemRec.byte_size
          });
          await persistMigrationItemRecord(itemRec, targetProvider, currentUser);
        } catch (err) {
          failedItems += 1;
          errors.push(`${fullStoragePath}: ${err.message}`);
          await persistMigrationItemRecord({
            item_id: itemId,
            run_id: runId,
            entity_type: "storage_object",
            table_or_bucket: bInfo.bucket,
            record_or_path: objectPath,
            source_provider_id: "supabase_primary",
            target_provider_id: targetProvider.providerId,
            byte_size: 0,
            status: "FAILED",
            error_message: String(err.message || "Storage migration failed").slice(0, 400)
          }, targetProvider, currentUser);
        }
      }
    }
  }

  // 3. SAVE BACKUP MANIFEST BEFORE ANY CLEANUP
  reportProgress(92, "Generating verified Backup Manifest...");
  const manifestJson = {
    backupId,
    runId,
    createdAt: new Date().toISOString(),
    sourceProviderId: "supabase_primary",
    targetProviderId: targetProvider.providerId,
    scope,
    totalItems,
    verifiedItems,
    failedItems,
    totalBytes,
    entries: backupEntries
  };
  const manifestChecksum = await computeSha256Hex(new TextEncoder().encode(JSON.stringify(manifestJson)));
  const manifestRecord = {
    backup_id: backupId,
    run_id: runId,
    source_provider_id: "supabase_primary",
    target_provider_id: targetProvider.providerId,
    item_count: backupEntries.length,
    total_bytes: totalBytes,
    checksum_sha256: manifestChecksum,
    manifest_json: manifestJson,
    status: "READY",
    created_by_uid: currentUser.uid
  };
  await sbUpsert("cloud_backup_manifests", manifestRecord, "backup_id", currentUser).catch(() => {});
  await callCpanelDirect(targetProvider.endpointUrl, "db_upsert", {
    table: "cloud_backup_manifests",
    record: manifestRecord,
    preserveTimestamps: true
  }, currentUser).catch(() => {});

  // 4. UPDATE RUN STATUS
  const finalStatus = failedItems === 0 ? "COMPLETED" : (verifiedItems > 0 ? "PARTIAL" : "FAILED");
  const finishedRun = {
    ...run,
    status: finalStatus,
    total_items: totalItems,
    migrated_items: migratedItems,
    verified_items: verifiedItems,
    failed_items: failedItems,
    total_bytes: totalBytes,
    error_summary: errors.slice(0, 12).join(" | ").slice(0, 1000),
    completed_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };
  await persistMigrationRunRecord(finishedRun, targetProvider, currentUser);

  reportProgress(100, `Migration finished (${finalStatus}): ${verifiedItems}/${totalItems} verified, ${failedItems} failed.`);
  return { run: finishedRun, manifest: manifestRecord, errors };
}

export async function executeVerifiedCleanup({
  run,
  targetProvider,
  supaProvider,
  migrationConfig,
  currentUser,
  supabaseDeleteObjectFn,
  fetchUsageMetricsFn
}) {
  if (!run) throw new Error("No migration run selected.");
  if (!targetProvider) throw new Error("Target cPanel host required for verification before cleanup.");

  const health = await callCpanelDirect(targetProvider.endpointUrl, "health", {}, currentUser).catch(() => null);
  const gate = canExecuteCleanup({
    autoCleanupEnabled: Boolean(migrationConfig?.autoCleanupEnabled),
    totalItems: run.total_items,
    verifiedItems: run.verified_items,
    failedItems: run.failed_items,
    targetHealthy: Boolean(health && health.ok !== false)
  });
  if (!gate.allowed) {
    throw new Error(gate.reason);
  }

  const items = await sbSelect(
    "cloud_migration_items",
    `run_id=eq.${encodeURIComponent(run.run_id)}&entity_type=eq.storage_object&status=eq.VERIFIED&select=*`,
    currentUser
  );
  const beforeUsage = typeof fetchUsageMetricsFn === "function"
    ? await fetchUsageMetricsFn(currentUser, migrationConfig).catch(() => null)
    : null;

  let cleaned = 0;
  let cleanedBytes = 0;
  for (const it of items) {
    if (PROTECTED_MIGRATION_TABLES.has(it.table_or_bucket)) continue;
    const verify = await callCpanelDirect(targetProvider.endpointUrl, "verify_file", {
      storagePath: `${it.table_or_bucket}/${it.record_or_path}`,
      sha256: it.checksum_sha256 || ""
    }, currentUser).catch(() => null);
    if (!verify?.exists || !verify?.shaMatch) {
      throw new Error(`Cleanup aborted: target missing or checksum mismatch for ${it.table_or_bucket}/${it.record_or_path}`);
    }
    await supabaseDeleteObjectFn(supaProvider, it.table_or_bucket, it.record_or_path);
    await sbUpdate("cloud_migration_items", `item_id=eq.${encodeURIComponent(it.item_id)}`, { status: "CLEANED_UP" }, currentUser).catch(() => {});
    cleaned += 1;
    cleanedBytes += Number(it.byte_size || 0);
  }

  const afterUsage = typeof fetchUsageMetricsFn === "function"
    ? await fetchUsageMetricsFn(currentUser, migrationConfig).catch(() => null)
    : null;
  const reclaimedBytes = beforeUsage && afterUsage
    ? Math.max(cleanedBytes, Number(beforeUsage.storageUsedBytes || 0) - Number(afterUsage.storageUsedBytes || 0))
    : cleanedBytes;

  await persistMigrationRunRecord({
    ...run,
    cleaned_items: Number(run.cleaned_items || 0) + cleaned,
    updated_at: new Date().toISOString()
  }, targetProvider, currentUser);

  return { cleanedCount: cleaned, reclaimedBytes, verifiedReclamation: Boolean(beforeUsage && afterUsage) };
}

export async function fetchSchedulerStatus(currentUser, storageState) {
  if (!currentUser) return null;
  const baseUrl = String(getSupabaseUrl() || SUPABASE_URL).replace(/\/+$/, "");
  const anonKey = String(getSupabaseAnonKey() || "").trim();
  if (anonKey) {
    try {
      const token = await currentUser.getIdToken(false);
      const resp = await fetch(`${baseUrl}/functions/v1/cloud-migration-worker`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: anonKey,
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ action: "status" })
      });
      const data = await resp.json().catch(() => ({}));
      if (resp.ok && data?.ok) {
        return {
          source: "EDGE_WORKER",
          schedulerStatus: data.schedulerStatus || null,
          metrics: data.metrics || null
        };
      }
    } catch { /* fallback below */ }

    try {
      const rows = await sbSelect("cloud_scheduler_status", "scheduler_id=eq.default&limit=1", currentUser);
      if (Array.isArray(rows) && rows[0]) {
        return { source: "SUPABASE_TABLE", schedulerStatus: rows[0] };
      }
    } catch { /* fallback below */ }
  }

  const phpHost = (storageState?.providers || []).find((p) => p.enabled && p.providerType === "PHP_HOSTING" && /^https:\/\//i.test(p.endpointUrl || ""));
  if (phpHost) {
    try {
      const res = await callCpanelDirect(phpHost.endpointUrl, "scheduler_status", {}, currentUser);
      return { source: "CPANEL_CRON", schedulerStatus: res.schedulerStatus || res.heartbeat || null };
    } catch { /* ignore */ }
  }
  return null;
}

export async function triggerServerSideMigrationTick(currentUser, storageState, forceManual = true) {
  if (!currentUser) throw new Error("Sign in as Super Admin first.");
  const baseUrl = String(getSupabaseUrl() || SUPABASE_URL).replace(/\/+$/, "");
  const anonKey = String(getSupabaseAnonKey() || "").trim();
  if (anonKey) {
    try {
      const token = await currentUser.getIdToken(false);
      const resp = await fetch(`${baseUrl}/functions/v1/cloud-migration-worker`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: anonKey,
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ action: "run_tick", forceManual, triggerMode: "MANUAL_ADMIN_TICK" })
      });
      const data = await resp.json().catch(() => ({}));
      if (resp.ok && data?.ok !== false) {
        return { via: "EDGE_WORKER", ...data };
      }
    } catch { /* fallback to cPanel cron_tick */ }
  }

  const phpHost = (storageState?.providers || []).find((p) => p.enabled && p.providerType === "PHP_HOSTING" && /^https:\/\//i.test(p.endpointUrl || ""));
  if (phpHost) {
    const res = await callCpanelDirect(phpHost.endpointUrl, "cron_tick", {}, currentUser);
    return { via: "CPANEL_CRON", ...res };
  }
  throw new Error("Deploy `cloud-migration-worker` Edge Function or connect an active cPanel host first.");
}

export async function restoreFromBackupManifest({
  manifestRecord,
  targetProvider,
  supaProvider,
  currentUser,
  supabaseUploadObjectFn
}) {
  const manifest = manifestRecord?.manifest_json || manifestRecord;
  const entries = Array.isArray(manifest?.entries) ? manifest.entries : [];
  if (!entries.length) {
    throw new Error("Backup manifest has no entries to restore.");
  }
  let restoredRows = 0;
  let restoredFiles = 0;

  for (const entry of entries) {
    if (entry.entityType === "table_row" && entry.table && entry.row) {
      const targetTable = entry.table === "catalog_entries" ? "repair_catalog_entries" : entry.table;
      await sbUpsert(targetTable, {
        ...entry.row,
        migration_status: "ROLLED_BACK"
      }, entry.pkCol || "id", currentUser);
      restoredRows += 1;
    } else if (entry.entityType === "storage_object" && entry.bucket && entry.objectPath && targetProvider) {
      const tokenRes = await callCpanelDirect(targetProvider.endpointUrl, "create_private_download_token", {
        storagePath: entry.targetStoragePath || `${entry.bucket}/${entry.objectPath}`,
        expiresInSeconds: 300
      }, currentUser).catch(() => null);
      const sourceUrl = tokenRes?.signedUrl || entry.targetUrl;
      if (!sourceUrl) continue;
      const resp = await fetch(sourceUrl);
      if (!resp.ok) continue;
      const blob = await resp.blob();
      await supabaseUploadObjectFn(supaProvider, entry.bucket, entry.objectPath, blob, blob.type || "application/octet-stream");
      restoredFiles += 1;
    }
  }

  if (manifestRecord?.backup_id) {
    await sbUpdate("cloud_backup_manifests", `backup_id=eq.${encodeURIComponent(manifestRecord.backup_id)}`, {
      status: "RESTORED"
    }, currentUser).catch(() => {});
  }
  return { restoredRows, restoredFiles };
}

export async function retryFailedMigrationItems({
  run,
  targetProvider,
  supaProvider,
  currentUser,
  supabaseCreateSignedUrlFn,
  onProgress
}) {
  if (!run || !targetProvider || !currentUser) {
    throw new Error("Migration run, target cPanel host, and Super Admin session required.");
  }
  const report = (pct, msg) => {
    if (typeof onProgress === "function") onProgress(pct, msg);
  };
  let failedItems = [];
  try {
    failedItems = await sbSelect(
      "cloud_migration_items",
      `run_id=eq.${encodeURIComponent(run.run_id)}&status=eq.FAILED&select=*`,
      currentUser
    );
  } catch {
    const ext = await callCpanelDirect(targetProvider.endpointUrl, "db_query", {
      table: "cloud_migration_items",
      filters: { run_id: run.run_id, status: "FAILED" },
      limit: 500
    }, currentUser);
    failedItems = Array.isArray(ext.rows) ? ext.rows : [];
  }

  if (!failedItems.length) {
    return { retried: 0, succeeded: 0, remainingFailed: 0 };
  }

  let succeeded = 0;
  let remainingFailed = 0;
  for (let i = 0; i < failedItems.length; i += 1) {
    const it = failedItems[i];
    report(Math.round(((i + 1) / failedItems.length) * 100), `Retrying ${it.table_or_bucket}/${it.record_or_path}...`);
    try {
      if (it.entity_type === "table_row" && it.snapshot_json) {
        const tblMeta = MIGRATION_TABLES.find((t) => t.table === it.table_or_bucket || t.cpanelTable === it.table_or_bucket);
        await callCpanelDirect(targetProvider.endpointUrl, "db_upsert", {
          table: tblMeta?.cpanelTable || it.table_or_bucket,
          record: it.snapshot_json,
          preserveTimestamps: true
        }, currentUser);
        await persistMigrationItemRecord({
          ...it,
          status: "VERIFIED",
          retry_count: Number(it.retry_count || 0) + 1,
          error_message: ""
        }, targetProvider, currentUser);
        succeeded += 1;
      } else if (it.entity_type === "storage_object") {
        const bMeta = MIGRATION_BUCKETS.find((b) => b.bucket === it.table_or_bucket);
        const blob = await supabaseDownloadBucketObject(
          supaProvider,
          it.table_or_bucket,
          it.record_or_path,
          Boolean(bMeta?.isPrivate),
          currentUser,
          supabaseCreateSignedUrlFn
        );
        const buf = await blob.arrayBuffer();
        const sha256 = await computeSha256Hex(buf);
        const base64 = await fileToBase64(blob);
        const uploadRes = await callCpanelDirect(targetProvider.endpointUrl, "upload", {
          bucketName: it.table_or_bucket,
          objectPath: it.record_or_path,
          base64,
          mimeType: blob.type || "application/octet-stream",
          preserveExactBytes: true,
          skipDedupe: true
        }, currentUser);
        const verifyRes = await callCpanelDirect(targetProvider.endpointUrl, "verify_file", {
          storagePath: uploadRes.storagePath || `${it.table_or_bucket}/${it.record_or_path}`,
          sha256
        }, currentUser);
        if (!verifyRes.exists || !verifyRes.shaMatch) {
          throw new Error("Verification checksum mismatch after retry.");
        }
        await persistMigrationItemRecord({
          ...it,
          checksum_sha256: sha256,
          byte_size: Number(verifyRes.sizeBytes || buf.byteLength || 0),
          status: "VERIFIED",
          retry_count: Number(it.retry_count || 0) + 1,
          target_url: verifyRes.publicUrl || uploadRes.publicUrl || "",
          error_message: ""
        }, targetProvider, currentUser);
        succeeded += 1;
      }
    } catch (err) {
      remainingFailed += 1;
      await persistMigrationItemRecord({
        ...it,
        status: "FAILED",
        retry_count: Number(it.retry_count || 0) + 1,
        error_message: String(err?.message || "Retry failed").slice(0, 400)
      }, targetProvider, currentUser);
    }
  }

  const nextVerified = Number(run.verified_items || 0) + succeeded;
  const nextFailed = Math.max(0, Number(run.failed_items || 0) - succeeded);
  await persistMigrationRunRecord({
    ...run,
    verified_items: nextVerified,
    migrated_items: Number(run.migrated_items || 0) + succeeded,
    failed_items: nextFailed,
    status: nextFailed === 0 ? "COMPLETED" : "PARTIAL",
    updated_at: new Date().toISOString()
  }, targetProvider, currentUser);

  return { retried: failedItems.length, succeeded, remainingFailed };
}

