Repair Pro 3.0 — GitHub build
Extract ZIP into private repository root, including .github.
Settings > Secrets and variables > Actions: add SUPABASE_ANON_KEY (public anon key only). Optional variable ADMOB_APP_ID; defaults to Google test ID.
Actions > Build Repair Pro Android > Run workflow. Download APK artifact. Debug signing is newly generated each run; register SHA fingerprints in Firebase for Google login; for repeatable updates use original signing key.
For signed release, add KEYSTORE_BASE64, STORE_PASSWORD, KEY_PASSWORD secrets (original keystore, alias upload), then select release when running workflow. Do not commit keys.
Web admin deployment is manual only to prevent accidental live changes. Backend deployment and storage migration fixes remain separate. Workflow has not been executed here.
