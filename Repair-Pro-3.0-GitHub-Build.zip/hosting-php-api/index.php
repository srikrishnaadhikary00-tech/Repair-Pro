<?php
/**
 * Repair Pro — Universal Shared Hosting Media API (PHP 7.4+ / 8.x)
 * Compatible with Hostinger, BigRock, MilesWeb, GoDaddy, Namecheap, HostGator & cPanel hosts.
 *
 * Supported Actions (GET ?action=... or POST action=... or JSON body):
 *  - health : Verifies PHP version, disk space, and write permissions
 *  - upload : Authenticated image upload with magic-byte validation, EXIF strip, & SHA-256 deduplication
 *  - list   : Lists files in an allowed bucket directory
 *  - delete : Deletes a validated file path inside an allowed bucket directory
 *  - stats  : Returns tracked file count and used storage bytes
 */

declare(strict_types=1);

$configPath = __DIR__ . '/config.php';
$config = file_exists($configPath) ? require $configPath : require __DIR__ . '/config.example.php';

// CORS Headers
$origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
$allowedOrigins = trim((string)($config['allowed_origins'] ?? '*'));
if ($allowedOrigins === '*') {
    header('Access-Control-Allow-Origin: *');
} else {
    $originList = array_map('trim', explode(',', $allowedOrigins));
    if (in_array($origin, $originList, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
    }
}
header('Access-Control-Allow-Headers: Authorization, X-RepairPro-Timestamp, X-RepairPro-Signature, X-RepairPro-Hash, Content-Type');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(['ok' => true]);
    exit;
}

function sendJson(int $status, array $payload): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES);
    exit;
}

function ensureDir(string $dir): bool {
    if (is_dir($dir)) {
        return is_writable($dir);
    }
    return @mkdir($dir, 0755, true);
}

function resolvePublicBaseUrl(array $config): string {
    $configured = rtrim(trim((string)($config['public_base_url'] ?? '')), '/');
    if ($configured !== '') {
        return $configured;
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    return $scheme . '://' . $host . $scriptDir;
}

function checkRateLimit(array $config): void {
    $uploadDir = rtrim((string)$config['upload_dir'], '/');
    $rateDir = $uploadDir . '/.ratelimit';
    if (!ensureDir($rateDir)) return;

    $ip = preg_replace('/[^a-zA-Z0-9._-]/', '_', (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $rateFile = $rateDir . '/' . hash('sha256', $ip) . '.json';
    $window = max(10, (int)($config['rate_limit_window_seconds'] ?? 60));
    $maxReqs = max(5, (int)($config['rate_limit_max_requests'] ?? 40));
    $now = time();

    $hits = [];
    if (file_exists($rateFile)) {
        $raw = @file_get_contents($rateFile);
        $decoded = $raw ? json_decode($raw, true) : null;
        if (is_array($decoded)) {
            $hits = array_values(array_filter($decoded, fn($ts) => is_int($ts) && ($now - $ts) < $window));
        }
    }
    if (count($hits) >= $maxReqs) {
        sendJson(429, [
            'ok' => false,
            'errorCode' => 'RATE_LIMITED',
            'message' => 'Too many requests. Please slow down.'
        ]);
    }
    $hits[] = $now;
    @file_put_contents($rateFile, json_encode($hits), LOCK_EX);
}

function verifyAuthorization(array $config, string $action): void {
    $secret = trim((string)($config['api_secret'] ?? ''));
    if ($secret === '' || strpos($secret, 'CHANGE_ME_') === 0) {
        sendJson(503, [
            'ok' => false,
            'errorCode' => 'API_SECRET_NOT_CONFIGURED',
            'message' => 'Hosting config.php api_secret is still a placeholder. Configure a strong random secret.'
        ]);
    }

    $authHeader = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    $bearer = '';
    if (stripos($authHeader, 'Bearer ') === 0) {
        $bearer = trim(substr($authHeader, 7));
    }

    // 1. Direct Bearer match (constant-time)
    if ($bearer !== '' && hash_equals($secret, $bearer)) {
        return;
    }

    // 2. Optional HMAC timestamp + signature headers (recommended for proxy forwarding)
    $ts = trim((string)($_SERVER['HTTP_X_REPAIRPRO_TIMESTAMP'] ?? ''));
    $sig = trim((string)($_SERVER['HTTP_X_REPAIRPRO_SIGNATURE'] ?? ''));
    if ($ts !== '' && $sig !== '' && ctype_digit($ts)) {
        $maxSkew = (int)($config['hmac_max_skew_seconds'] ?? 300);
        if (abs(time() - (int)$ts) <= $maxSkew) {
            $expected = hash_hmac('sha256', $ts . '|' . $action, $secret);
            if (hash_equals($expected, $sig)) {
                return;
            }
        }
    }

    sendJson(401, [
        'ok' => false,
        'errorCode' => 'UNAUTHORIZED',
        'message' => 'Invalid or missing Authorization token / HMAC signature.'
    ]);
}

function sanitizeBucket(string $rawBucket, array $config): string {
    $clean = preg_replace('/[^a-zA-Z0-9_-]/', '', trim($rawBucket));
    $allowed = $config['allowed_buckets'] ?? ['community-photos'];
    if ($clean === '' || !in_array($clean, $allowed, true)) {
        sendJson(400, [
            'ok' => false,
            'errorCode' => 'INVALID_BUCKET',
            'message' => 'Requested storage bucket is not permitted.'
        ]);
    }
    return $clean;
}

function sanitizeRelativePath(string $rawPath): string {
    $normalized = str_replace('\\', '/', trim($rawPath));
    $normalized = ltrim($normalized, '/');
    if ($normalized === '' || strpos($normalized, '..') !== false || strpos($normalized, "\0") !== false) {
        sendJson(400, ['ok' => false, 'errorCode' => 'INVALID_PATH', 'message' => 'Invalid object path.']);
    }
    $parts = array_values(array_filter(explode('/', $normalized), fn($seg) => $seg !== '' && $seg !== '.'));
    if (empty($parts)) {
        sendJson(400, ['ok' => false, 'errorCode' => 'INVALID_PATH', 'message' => 'Empty object path.']);
    }
    $safeParts = array_map(fn($p) => preg_replace('/[^a-zA-Z0-9._-]/', '_', $p), $parts);
    return implode('/', $safeParts);
}

function reencodeSafeImage(string $rawBytes, string $mime): string {
    if (!function_exists('imagecreatefromstring')) {
        return $rawBytes;
    }
    $img = @imagecreatefromstring($rawBytes);
    if ($img === false) {
        return $rawBytes;
    }
    ob_start();
    if ($mime === 'image/png') {
        imagealphablending($img, false);
        imagesavealpha($img, true);
        imagepng($img, null, 6);
    } elseif ($mime === 'image/webp' && function_exists('imagewebp')) {
        imagewebp($img, null, 84);
    } else {
        imagejpeg($img, null, 85);
    }
    $reencoded = ob_get_clean();
    imagedestroy($img);
    return (is_string($reencoded) && strlen($reencoded) > 0) ? $reencoded : $rawBytes;
}

function readDedupeIndex(string $indexPath): array {
    if (!file_exists($indexPath)) return [];
    $raw = @file_get_contents($indexPath);
    $parsed = $raw ? json_decode($raw, true) : null;
    return is_array($parsed) ? $parsed : [];
}

function writeDedupeIndex(string $indexPath, array $index): void {
    if (count($index) > 5000) {
        $index = array_slice($index, -4000, null, true);
    }
    @file_put_contents($indexPath, json_encode($index, JSON_UNESCAPED_SLASHES), LOCK_EX);
}

function computeFolderStats(string $dir): array {
    if (!is_dir($dir)) return ['files' => 0, 'bytes' => 0];
    $count = 0;
    $bytes = 0;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($it as $file) {
        /** @var SplFileInfo $file */
        if ($file->isFile()) {
            $name = $file->getFilename();
            if ($name === '.htaccess' || substr($name, 0, 1) === '.') continue;
            $count += 1;
            $bytes += $file->getSize();
        }
    }
    return ['files' => $count, 'bytes' => $bytes];
}

// Determine action
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = strtolower(trim((string)($_GET['action'] ?? $_POST['action'] ?? '')));
if ($action === '') {
    $action = $method === 'GET' ? 'health' : 'upload';
}

checkRateLimit($config);
verifyAuthorization($config, $action);

$uploadRoot = rtrim((string)$config['upload_dir'], '/');
if (!ensureDir($uploadRoot)) {
    sendJson(500, [
        'ok' => false,
        'errorCode' => 'STORAGE_NOT_WRITABLE',
        'message' => 'Upload directory is not writable. Ensure CHMOD 0755 on uploads/.'
    ]);
}

switch ($action) {
    case 'health':
    case 'stats': {
        $stats = computeFolderStats($uploadRoot);
        $freeBytes = function_exists('disk_free_space') ? @disk_free_space($uploadRoot) : false;
        $totalBytes = function_exists('disk_total_space') ? @disk_total_space($uploadRoot) : false;
        sendJson(200, [
            'ok' => true,
            'status' => 'HEALTHY',
            'phpVersion' => PHP_VERSION,
            'gdAvailable' => function_exists('imagecreatefromstring'),
            'finfoAvailable' => class_exists('finfo'),
            'writable' => is_writable($uploadRoot),
            'trackedFiles' => $stats['files'],
            'usedBytes' => $stats['bytes'],
            'diskFreeBytes' => is_numeric($freeBytes) ? (int)$freeBytes : null,
            'diskTotalBytes' => is_numeric($totalBytes) ? (int)$totalBytes : null,
            'publicBaseUrl' => resolvePublicBaseUrl($config),
            'timestamp' => gmdate('c'),
        ]);
    }

    case 'upload': {
        if ($method !== 'POST') {
            sendJson(405, ['ok' => false, 'errorCode' => 'METHOD_NOT_ALLOWED', 'message' => 'Use POST for uploads.']);
        }
        $rawBucket = (string)($_POST['bucket'] ?? $_POST['bucketName'] ?? $_GET['bucket'] ?? 'community-photos');
        $bucket = sanitizeBucket($rawBucket, $config);

        $rawBytes = '';
        $requestedPath = trim((string)($_POST['objectPath'] ?? $_POST['path'] ?? ''));

        if (!empty($_FILES['file']['tmp_name']) && is_uploaded_file($_FILES['file']['tmp_name'])) {
            $rawBytes = (string)@file_get_contents($_FILES['file']['tmp_name']);
            if ($requestedPath === '') {
                $requestedPath = (string)($_FILES['file']['name'] ?? ('photo_' . time() . '.jpg'));
            }
        } else {
            $input = (string)@file_get_contents('php://input');
            if ($input !== '') {
                $json = json_decode($input, true);
                if (is_array($json) && isset($json['base64'])) {
                    $decoded = base64_decode((string)$json['base64'], true);
                    if ($decoded !== false) $rawBytes = $decoded;
                    if ($requestedPath === '' && !empty($json['objectPath'])) {
                        $requestedPath = (string)$json['objectPath'];
                    }
                    if (!empty($json['bucket'])) {
                        $bucket = sanitizeBucket((string)$json['bucket'], $config);
                    }
                } else {
                    $rawBytes = $input;
                }
            }
        }

        $maxSize = (int)($config['max_file_size_bytes'] ?? (5 * 1024 * 1024));
        $byteLen = strlen($rawBytes);
        if ($byteLen <= 0 || $byteLen > $maxSize) {
            sendJson(400, [
                'ok' => false,
                'errorCode' => 'INVALID_FILE_SIZE',
                'message' => "File must be non-empty and <= {$maxSize} bytes."
            ]);
        }

        // Strict magic-byte MIME verification
        $detectedMime = 'application/octet-stream';
        if (class_exists('finfo')) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $detectedMime = (string)$finfo->buffer($rawBytes);
        } elseif (function_exists('getimagesizefromstring')) {
            $info = @getimagesizefromstring($rawBytes);
            if (is_array($info) && !empty($info['mime'])) {
                $detectedMime = (string)$info['mime'];
            }
        }

        $allowedMimes = $config['allowed_mimes'] ?? ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!isset($allowedMimes[$detectedMime])) {
            sendJson(415, [
                'ok' => false,
                'errorCode' => 'UNSUPPORTED_MEDIA_TYPE',
                'message' => "Unsupported or unsafe MIME type: {$detectedMime}. Allowed: JPEG, PNG, WebP."
            ]);
        }
        $safeExt = $allowedMimes[$detectedMime];

        // Deduplicate by SHA-256 of incoming bytes before EXIF stripping so exact client repeats match cleanly
        $contentHash = hash('sha256', $rawBytes);
        $indexFile = $uploadRoot . '/.dedupe_index.json';
        $baseUrl = resolvePublicBaseUrl($config);
        $prefix = '/' . trim((string)($config['public_upload_prefix'] ?? '/uploads'), '/');

        if (!empty($config['enable_deduplication'])) {
            $index = readDedupeIndex($indexFile);
            $dedupeKey = $bucket . ':' . $contentHash;
            if (isset($index[$dedupeKey]) && is_array($index[$dedupeKey])) {
                $existingRel = (string)($index[$dedupeKey]['storagePath'] ?? '');
                $existingDisk = $uploadRoot . '/' . $existingRel;
                if ($existingRel !== '' && file_exists($existingDisk)) {
                    sendJson(200, [
                        'ok' => true,
                        'deduplicated' => true,
                        'bucketName' => $bucket,
                        'storagePath' => $existingRel,
                        'publicUrl' => $baseUrl . $prefix . '/' . $existingRel,
                        'mimeType' => $detectedMime,
                        'sizeBytes' => filesize($existingDisk),
                        'sha256' => $contentHash,
                    ]);
                }
            }
        }

        $safeBytes = reencodeSafeImage($rawBytes, $detectedMime);
        if ($requestedPath === '') {
            $requestedPath = date('Y/m') . '/img_' . bin2hex(random_bytes(8)) . '.' . $safeExt;
        }
        $cleanRelPath = sanitizeRelativePath($requestedPath);
        // Force safe extension matching verified magic bytes
        $cleanRelPath = preg_replace('/\.[^.\/]+$/', '', $cleanRelPath) . '.' . $safeExt;
        $storagePath = $bucket . '/' . $cleanRelPath;
        $targetFile = $uploadRoot . '/' . $storagePath;

        if (!ensureDir(dirname($targetFile))) {
            sendJson(500, ['ok' => false, 'errorCode' => 'MKDIR_FAILED', 'message' => 'Could not create target subfolder.']);
        }
        if (@file_put_contents($targetFile, $safeBytes, LOCK_EX) === false) {
            sendJson(500, ['ok' => false, 'errorCode' => 'WRITE_FAILED', 'message' => 'Failed to save uploaded image.']);
        }
        @chmod($targetFile, 0644);

        if (!empty($config['enable_deduplication'])) {
            $index = readDedupeIndex($indexFile);
            $index[$bucket . ':' . $contentHash] = [
                'storagePath' => $storagePath,
                'createdAt' => gmdate('c'),
                'sizeBytes' => strlen($safeBytes),
            ];
            writeDedupeIndex($indexFile, $index);
        }

        sendJson(200, [
            'ok' => true,
            'deduplicated' => false,
            'bucketName' => $bucket,
            'storagePath' => $storagePath,
            'publicUrl' => $baseUrl . $prefix . '/' . $storagePath,
            'mimeType' => $detectedMime,
            'sizeBytes' => strlen($safeBytes),
            'sha256' => $contentHash,
        ]);
    }

    case 'list': {
        $bucket = sanitizeBucket((string)($_GET['bucket'] ?? $_POST['bucket'] ?? 'community-photos'), $config);
        $bucketDir = $uploadRoot . '/' . $bucket;
        if (!is_dir($bucketDir)) {
            sendJson(200, ['ok' => true, 'bucket' => $bucket, 'files' => []]);
        }
        $baseUrl = resolvePublicBaseUrl($config);
        $prefix = '/' . trim((string)($config['public_upload_prefix'] ?? '/uploads'), '/');
        $files = [];
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($bucketDir, FilesystemIterator::SKIP_DOTS)
        );
        foreach ($it as $file) {
            /** @var SplFileInfo $file */
            if (!$file->isFile()) continue;
            $name = $file->getFilename();
            if ($name === '.htaccess' || substr($name, 0, 1) === '.') continue;
            $rel = ltrim(str_replace(['\\', $uploadRoot], ['/', ''], $file->getPathname()), '/');
            $files[] = [
                'name' => $name,
                'storagePath' => $rel,
                'publicUrl' => $baseUrl . $prefix . '/' . $rel,
                'sizeBytes' => $file->getSize(),
                'updatedAt' => gmdate('c', $file->getMTime()),
            ];
            if (count($files) >= 150) break;
        }
        usort($files, fn($a, $b) => strcmp($b['updatedAt'], $a['updatedAt']));
        sendJson(200, ['ok' => true, 'bucket' => $bucket, 'files' => $files]);
    }

    case 'delete': {
        $input = json_decode((string)@file_get_contents('php://input'), true);
        $rawPath = (string)($_POST['storagePath'] ?? $_GET['storagePath'] ?? ($input['storagePath'] ?? ''));
        $cleanRel = sanitizeRelativePath($rawPath);
        $parts = explode('/', $cleanRel, 2);
        sanitizeBucket($parts[0], $config);
        $targetFile = $uploadRoot . '/' . $cleanRel;
        if (!file_exists($targetFile) || !is_file($targetFile)) {
            sendJson(200, ['ok' => true, 'deleted' => false, 'message' => 'File not found (already removed).']);
        }
        if (!@unlink($targetFile)) {
            sendJson(500, ['ok' => false, 'errorCode' => 'DELETE_FAILED', 'message' => 'Could not remove file on hosting server.']);
        }
        sendJson(200, ['ok' => true, 'deleted' => true, 'storagePath' => $cleanRel]);
    }

    default:
        sendJson(400, ['ok' => false, 'errorCode' => 'UNKNOWN_ACTION', 'message' => 'Supported actions: health, stats, upload, list, delete.']);
}
