<?php
/**
 * Repair Pro — Universal Shared Hosting Media, Private Storage & MySQL Database API (PHP 7.4+ / 8.x)
 * Compatible with cPanel, Hostinger, BigRock, MilesWeb, GoDaddy, Namecheap, HostGator.
 *
 * Authentication Modes:
 *  1. Direct Client HTTPS (Android App & Web Admin): Firebase ID Token (RS256 verified via Google x509 certs)
 *  2. Server-to-Server Proxy: Bearer `api_secret` OR HMAC (`X-RepairPro-Timestamp` + `X-RepairPro-Signature`)
 *  3. Public Read-Only Discovery: `?action=public_config_discovery` (non-secret routing metadata only)
 *  4. Signed Private Download: `?action=download_private&storagePath=...&token=...&exp=...` (or Firebase Bearer)
 */

declare(strict_types=1);

$configPath = __DIR__ . '/config.php';
$config = file_exists($configPath) ? require $configPath : require __DIR__ . '/config.example.php';

// CORS Headers
$origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
$allowedOrigins = trim((string)($config['allowed_origins'] ?? '*'));
if ($allowedOrigins === '*') {
    header('Access-Control-Allow-Origin: *');
} else {
    $originList = array_map('trim', explode(',', $allowedOrigins));
    if (in_array($origin, $originList, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
    }
}
header('Access-Control-Allow-Headers: Authorization, X-RepairPro-Timestamp, X-RepairPro-Signature, X-RepairPro-Hash, Content-Type');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(200);
    echo json_encode(['ok' => true]);
    exit;
}

function sendJson(int $status, array $payload): void {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES);
    exit;
}

function ensureDir(string $dir): bool {
    if (is_dir($dir)) {
        return is_writable($dir);
    }
    return @mkdir($dir, 0755, true);
}

function getUploadRoot(array $config): string {
    return rtrim((string)($config['upload_dir'] ?? (__DIR__ . '/uploads')), '/');
}

function getPrivateRoot(array $config): string {
    return rtrim((string)($config['private_dir'] ?? (__DIR__ . '/private_uploads')), '/');
}

function isPrivateBucket(string $bucket, array $config): bool {
    $priv = $config['private_buckets'] ?? ['verification-documents'];
    return in_array($bucket, $priv, true);
}

function resolveBucketRoot(string $bucket, array $config): string {
    return isPrivateBucket($bucket, $config) ? getPrivateRoot($config) : getUploadRoot($config);
}

function ensurePrivateFolderGuard(string $privateRoot): void {
    if (!ensureDir($privateRoot)) return;
    $htaccess = $privateRoot . '/.htaccess';
    if (!file_exists($htaccess)) {
        $rules = "Options -Indexes\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n";
        @file_put_contents($htaccess, $rules, LOCK_EX);
    }
}

function resolvePublicBaseUrl(array $config): string {
    $configured = rtrim(trim((string)($config['public_base_url'] ?? '')), '/');
    if ($configured !== '') {
        return $configured;
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    return $scheme . '://' . $host . $scriptDir;
}

function resolveScriptEndpointUrl(array $config): string {
    $base = resolvePublicBaseUrl($config);
    $scriptName = basename((string)($_SERVER['SCRIPT_NAME'] ?? 'index.php')) ?: 'index.php';
    return $base . '/' . $scriptName;
}

function getSigningKey(array $config): string {
    $secret = trim((string)($config['api_secret'] ?? ''));
    if ($secret !== '' && strpos($secret, 'CHANGE_ME_') !== 0) {
        return $secret;
    }
    $priv = getPrivateRoot($config);
    ensurePrivateFolderGuard($priv);
    $keyFile = $priv . '/.signing_key';
    if (file_exists($keyFile)) {
        $existing = trim((string)@file_get_contents($keyFile));
        if (strlen($existing) >= 32) return $existing;
    }
    $generated = bin2hex(random_bytes(32));
    @file_put_contents($keyFile, $generated, LOCK_EX);
    @chmod($keyFile, 0600);
    return $generated;
}

function checkRateLimit(array $config): void {
    $uploadRoot = getUploadRoot($config);
    $rateDir = $uploadRoot . '/.ratelimit';
    if (!ensureDir($rateDir)) return;

    $ip = preg_replace('/[^a-zA-Z0-9._-]/', '_', (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $rateFile = $rateDir . '/' . hash('sha256', $ip) . '.json';
    $window = max(10, (int)($config['rate_limit_window_seconds'] ?? 60));
    $maxReqs = max(10, (int)($config['rate_limit_max_requests'] ?? 180));
    $now = time();

    $hits = [];
    if (file_exists($rateFile)) {
        $raw = @file_get_contents($rateFile);
        $decoded = $raw ? json_decode($raw, true) : null;
        if (is_array($decoded)) {
            $hits = array_values(array_filter($decoded, fn($ts) => is_int($ts) && ($now - $ts) < $window));
        }
    }
    if (count($hits) >= $maxReqs) {
        sendJson(429, [
            'ok' => false,
            'errorCode' => 'RATE_LIMITED',
            'message' => 'Too many requests. Please slow down.'
        ]);
    }
    $hits[] = $now;
    @file_put_contents($rateFile, json_encode($hits), LOCK_EX);
}

// =========================================================================
// FIREBASE RS256 ID TOKEN & SERVICE AUTHENTICATION
// =========================================================================
function base64UrlDecode(string $input): string {
    $remainder = strlen($input) % 4;
    if ($remainder > 0) {
        $input .= str_repeat('=', 4 - $remainder);
    }
    $decoded = base64_decode(strtr($input, '-_', '+/'), true);
    return $decoded === false ? '' : $decoded;
}

function fetchGoogleX509Certs(string $projectId, bool $forceRefresh = false): array {
    $cacheFile = rtrim(sys_get_temp_dir(), '/') . '/repairpro_fb_certs_' . md5($projectId) . '.json';
    if (!$forceRefresh && file_exists($cacheFile)) {
        $raw = @file_get_contents($cacheFile);
        $cached = $raw ? json_decode($raw, true) : null;
        if (is_array($cached) && !empty($cached['certs']) && (time() - (int)($cached['fetchedAt'] ?? 0)) < 3600) {
            return $cached['certs'];
        }
    }
    $certUrl = 'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';
    $ctx = stream_context_create([
        'http' => ['timeout' => 10, 'ignore_errors' => true],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $rawCerts = @file_get_contents($certUrl, false, $ctx);
    if (($rawCerts === false || $rawCerts === '') && function_exists('curl_init')) {
        $ch = curl_init($certUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $rawCerts = curl_exec($ch);
        curl_close($ch);
    }
    $certs = is_string($rawCerts) ? json_decode($rawCerts, true) : null;
    if (!is_array($certs) || empty($certs)) {
        return [];
    }
    @file_put_contents($cacheFile, json_encode(['fetchedAt' => time(), 'certs' => $certs]), LOCK_EX);
    return $certs;
}

function verifyFirebaseIdToken(string $jwt, array $config): ?array {
    $parts = explode('.', $jwt);
    if (count($parts) !== 3) return null;
    if (!function_exists('openssl_verify')) return null;

    [$headerB64, $payloadB64, $sigB64] = $parts;
    $header = json_decode(base64UrlDecode($headerB64), true);
    $payload = json_decode(base64UrlDecode($payloadB64), true);
    $sig = base64UrlDecode($sigB64);

    if (!is_array($header) || !is_array($payload) || $sig === '') return null;
    if (($header['alg'] ?? '') !== 'RS256' || empty($header['kid'])) return null;

    $projectId = trim((string)($config['firebase_project_id'] ?? 'gen-lang-client-0218221723'));
    $now = time();
    $exp = (int)($payload['exp'] ?? 0);
    $iat = (int)($payload['iat'] ?? 0);
    $aud = (string)($payload['aud'] ?? '');
    $iss = (string)($payload['iss'] ?? '');
    $sub = trim((string)($payload['sub'] ?? ''));

    if ($aud !== $projectId || $iss !== "https://securetoken.google.com/{$projectId}") return null;
    if ($sub === '' || $exp < ($now - 30) || $iat > ($now + 300)) return null;

    $kid = (string)$header['kid'];
    $certs = fetchGoogleX509Certs($projectId, false);
    if (empty($certs[$kid])) {
        $certs = fetchGoogleX509Certs($projectId, true);
    }
    if (empty($certs[$kid])) return null;

    $pubKey = @openssl_pkey_get_public((string)$certs[$kid]);
    if ($pubKey === false) return null;
    $ok = @openssl_verify($headerB64 . '.' . $payloadB64, $sig, $pubKey, OPENSSL_ALGO_SHA256);
    if ($ok !== 1) return null;

    return [
        'uid' => $sub,
        'email' => (string)($payload['email'] ?? ''),
        'emailVerified' => !empty($payload['email_verified']),
        'claims' => $payload,
    ];
}

function connectOptionalPdo(array $config): ?array {
    $dbCfg = $config['db'] ?? [];
    if (empty($dbCfg['enabled'])) return null;
    try {
        return connectExternalPdo($config, false);
    } catch (Throwable $e) {
        return null;
    }
}

function resolveAuthContext(array $config, string $action, ?array $jsonInput): array {
    $secret = trim((string)($config['api_secret'] ?? ''));
    $secretConfigured = ($secret !== '' && strpos($secret, 'CHANGE_ME_') !== 0);

    $authHeader = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    $bearer = '';
    if (stripos($authHeader, 'Bearer ') === 0) {
        $bearer = trim(substr($authHeader, 7));
    }

    // 1. Server-to-server secret Bearer
    if ($secretConfigured && $bearer !== '' && hash_equals($secret, $bearer)) {
        $actorUid = is_array($jsonInput) ? trim((string)($jsonInput['actorUid'] ?? $jsonInput['uploadedByUid'] ?? 'service')) : 'service';
        $isAdminFlag = is_array($jsonInput) && array_key_exists('isAdmin', $jsonInput) ? !empty($jsonInput['isAdmin']) : true;
        return [
            'authenticated' => true,
            'method' => 'api_secret',
            'isService' => true,
            'isAdmin' => $isAdminFlag,
            'uid' => $actorUid !== '' ? $actorUid : 'service',
            'email' => '',
            'emailVerified' => true,
            'isRestricted' => false,
            'isAccountBlocked' => false,
            'isUploadRestricted' => false,
            'canComment' => true,
        ];
    }

    // 2. Server-to-server HMAC signature
    $ts = trim((string)($_SERVER['HTTP_X_REPAIRPRO_TIMESTAMP'] ?? ''));
    $sig = trim((string)($_SERVER['HTTP_X_REPAIRPRO_SIGNATURE'] ?? ''));
    if ($secretConfigured && $ts !== '' && $sig !== '' && ctype_digit($ts)) {
        $maxSkew = (int)($config['hmac_max_skew_seconds'] ?? 300);
        if (abs(time() - (int)$ts) <= $maxSkew) {
            $expected = hash_hmac('sha256', $ts . '|' . $action, $secret);
            if (hash_equals($expected, $sig)) {
                $actorUid = is_array($jsonInput) ? trim((string)($jsonInput['actorUid'] ?? $jsonInput['uploadedByUid'] ?? 'service')) : 'service';
                $isAdminFlag = is_array($jsonInput) && array_key_exists('isAdmin', $jsonInput) ? !empty($jsonInput['isAdmin']) : true;
                return [
                    'authenticated' => true,
                    'method' => 'hmac',
                    'isService' => true,
                    'isAdmin' => $isAdminFlag,
                    'uid' => $actorUid !== '' ? $actorUid : 'service',
                    'email' => '',
                    'emailVerified' => true,
                    'isRestricted' => false,
                    'isAccountBlocked' => false,
                    'isUploadRestricted' => false,
                    'canComment' => true,
                ];
            }
        }
    }

    // 3. Direct Firebase ID Token (Android App & Web Admin direct HTTPS access)
    if ($bearer !== '' && substr_count($bearer, '.') === 2) {
        $fb = verifyFirebaseIdToken($bearer, $config);
        if (is_array($fb) && $fb['uid'] !== '') {
            $bootstrapEmail = strtolower(trim((string)($config['bootstrap_admin_email'] ?? 'srikrishnaadhikary00@gmail.com')));
            $claims = $fb['claims'] ?? [];
            $isAdmin = ($fb['emailVerified'] && strtolower($fb['email']) === $bootstrapEmail)
                || !empty($claims['admin'])
                || (($claims['repairproRole'] ?? '') === 'SUPER_ADMIN');
            $isAccountBlocked = !empty($claims['blocked']) || !empty($claims['suspended']) || !empty($claims['communityRestricted']);
            $isUploadRestricted = !empty($claims['uploadRestricted']);
            $canComment = !$isAccountBlocked;

            $pdoPair = connectOptionalPdo($config);
            if (is_array($pdoPair)) {
                [$pdo] = $pdoPair;
                if (!$isAdmin) {
                    try {
                        $stmt = $pdo->prepare('SELECT role FROM `admin_roles` WHERE `user_id` = ? LIMIT 1');
                        $stmt->execute([$fb['uid']]);
                        if ($stmt->fetch()) $isAdmin = true;
                    } catch (Throwable $ignored) {}
                }
                if (!$isAdmin) {
                    try {
                        $stmt = $pdo->prepare('SELECT blocked, suspended, community_restricted, upload_restricted FROM `user_profiles` WHERE `user_id` = ? LIMIT 1');
                        $stmt->execute([$fb['uid']]);
                        $prof = $stmt->fetch(PDO::FETCH_ASSOC);
                        if (is_array($prof)) {
                            if (!empty($prof['blocked']) || !empty($prof['suspended']) || !empty($prof['community_restricted'])) {
                                $isAccountBlocked = true;
                                $canComment = false;
                            }
                            if (!empty($prof['upload_restricted'])) {
                                $isUploadRestricted = true;
                            }
                        }
                    } catch (Throwable $ignored) {}
                    try {
                        $stmt = $pdo->prepare('SELECT is_blocked, can_post, can_comment, can_upload_photo FROM `community_user_restrictions` WHERE `user_id` = ? LIMIT 1');
                        $stmt->execute([$fb['uid']]);
                        $restr = $stmt->fetch(PDO::FETCH_ASSOC);
                        if (is_array($restr)) {
                            if (!empty($restr['is_blocked']) || (isset($restr['can_post']) && (int)$restr['can_post'] === 0)) {
                                $isAccountBlocked = true;
                            }
                            if (!empty($restr['is_blocked']) || (isset($restr['can_comment']) && (int)$restr['can_comment'] === 0)) {
                                $canComment = false;
                            }
                            if (isset($restr['can_upload_photo']) && (int)$restr['can_upload_photo'] === 0) {
                                $isUploadRestricted = true;
                            }
                        }
                    } catch (Throwable $ignored) {}
                }
            }
            if ($isAdmin) {
                $isAccountBlocked = false;
                $isUploadRestricted = false;
                $canComment = true;
            }

            return [
                'authenticated' => true,
                'method' => 'firebase_id_token',
                'isService' => false,
                'isAdmin' => $isAdmin,
                'uid' => $fb['uid'],
                'email' => $fb['email'],
                'emailVerified' => $fb['emailVerified'],
                'isRestricted' => ($isAccountBlocked || $isUploadRestricted),
                'isAccountBlocked' => $isAccountBlocked,
                'isUploadRestricted' => $isUploadRestricted,
                'canComment' => $canComment,
            ];
        }
    }

    // 4. Signed short-lived URL token (ONLY allowed for download_private)
    if ($action === 'download_private') {
        $rawPath = (string)($_GET['storagePath'] ?? $_POST['storagePath'] ?? '');
        $exp = trim((string)($_GET['exp'] ?? ''));
        $token = trim((string)($_GET['token'] ?? ''));
        if ($rawPath !== '' && $exp !== '' && ctype_digit($exp) && (int)$exp >= time() && $token !== '') {
            $cleanRel = sanitizeRelativePath($rawPath);
            $expected = hash_hmac('sha256', $exp . '|' . $cleanRel, getSigningKey($config));
            if (hash_equals($expected, $token)) {
                return [
                    'authenticated' => true,
                    'method' => 'signed_download_token',
                    'isService' => false,
                    'isAdmin' => true,
                    'uid' => 'signed_token',
                    'email' => '',
                    'emailVerified' => true,
                    'isRestricted' => false,
                ];
            }
        }
    }

    sendJson(401, [
        'ok' => false,
        'errorCode' => 'UNAUTHORIZED',
        'message' => 'Valid Firebase ID Token or hosting Authorization secret required.'
    ]);
    exit;
}

function sanitizeBucket(string $rawBucket, array $config): string {
    $clean = preg_replace('/[^a-zA-Z0-9_-]/', '', trim($rawBucket));
    $allowed = $config['allowed_buckets'] ?? [
        'community-photos',
        'technician-photos',
        'repair-pdfs',
        'circuit-diagrams',
        'verification-documents',
        'user-avatars',
    ];
    if ($clean === '' || !in_array($clean, $allowed, true)) {
        sendJson(400, [
            'ok' => false,
            'errorCode' => 'INVALID_BUCKET',
            'message' => 'Requested storage bucket is not permitted.'
        ]);
    }
    return $clean;
}

function sanitizeRelativePath(string $rawPath): string {
    $normalized = str_replace('\\', '/', trim($rawPath));
    $normalized = ltrim($normalized, '/');
    if ($normalized === '' || strpos($normalized, '..') !== false || strpos($normalized, "\0") !== false) {
        sendJson(400, ['ok' => false, 'errorCode' => 'INVALID_PATH', 'message' => 'Invalid object path.']);
    }
    $parts = array_values(array_filter(explode('/', $normalized), fn($seg) => $seg !== '' && $seg !== '.'));
    if (empty($parts)) {
        sendJson(400, ['ok' => false, 'errorCode' => 'INVALID_PATH', 'message' => 'Empty object path.']);
    }
    $safeParts = array_map(fn($p) => preg_replace('/[^a-zA-Z0-9._-]/', '_', $p), $parts);
    return implode('/', $safeParts);
}

function reencodeSafeImage(string $rawBytes, string $mime): string {
    if ($mime === 'application/pdf') return $rawBytes;
    if (!function_exists('imagecreatefromstring')) return $rawBytes;
    $img = @imagecreatefromstring($rawBytes);
    if ($img === false) return $rawBytes;
    ob_start();
    if ($mime === 'image/png') {
        imagealphablending($img, false);
        imagesavealpha($img, true);
        imagepng($img, null, 6);
    } elseif ($mime === 'image/webp' && function_exists('imagewebp')) {
        imagewebp($img, null, 84);
    } else {
        imagejpeg($img, null, 85);
    }
    $reencoded = ob_get_clean();
    imagedestroy($img);
    return (is_string($reencoded) && strlen($reencoded) > 0) ? $reencoded : $rawBytes;
}

function readDedupeIndex(string $indexPath): array {
    if (!file_exists($indexPath)) return [];
    $raw = @file_get_contents($indexPath);
    $parsed = $raw ? json_decode($raw, true) : null;
    return is_array($parsed) ? $parsed : [];
}

function writeDedupeIndex(string $indexPath, array $index): void {
    if (count($index) > 8000) {
        $index = array_slice($index, -6000, null, true);
    }
    @file_put_contents($indexPath, json_encode($index, JSON_UNESCAPED_SLASHES), LOCK_EX);
}

function computeFolderStats(string $dir): array {
    if (!is_dir($dir)) return ['files' => 0, 'bytes' => 0];
    $count = 0;
    $bytes = 0;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($it as $file) {
        /** @var SplFileInfo $file */
        if ($file->isFile()) {
            $name = $file->getFilename();
            if ($name === '.htaccess' || substr($name, 0, 1) === '.') continue;
            $count += 1;
            $bytes += $file->getSize();
        }
    }
    return ['files' => $count, 'bytes' => $bytes];
}

// =========================================================================
// EXTERNAL DATABASE (PDO MySQL / SQLite) SCHEMAS & HELPERS
// =========================================================================
function normalizeTableName(string $rawTable): string {
    $clean = trim($rawTable);
    if ($clean === 'repair_catalog_entries') {
        return 'catalog_entries';
    }
    return $clean;
}

function getDbTableSchemas(): array {
    return [
        'community_posts' => [
            'pk' => 'post_id',
            'ownerCol' => 'author_uid',
            'userWritable' => true,
            'searchCols' => ['title', 'body', 'brand_name', 'model_name', 'error_code', 'author_name'],
            'columns' => [
                'post_id', 'author_uid', 'author_name', 'author_photo_url', 'author_verified',
                'category', 'brand_name', 'model_name', 'error_code', 'title', 'body',
                'photo_url', 'photo_storage_path', 'photo_urls_json', 'photo_storage_paths_json',
                'photo_provider_ids_json', 'is_pinned', 'is_hidden', 'is_deleted', 'deleted_by_uid',
                'deleted_at', 'approval_status', 'moderation_note', 'reviewed_by_uid', 'like_count',
                'comment_count', 'report_count', 'storage_provider_id', 'external_record_id',
                'migrated_to_provider_id', 'checksum_sha256', 'migration_status', 'created_at', 'updated_at'
            ]
        ],
        'community_comments' => [
            'pk' => 'comment_id',
            'ownerCol' => 'author_uid',
            'userWritable' => true,
            'searchCols' => ['body', 'author_name'],
            'columns' => [
                'comment_id', 'post_id', 'parent_comment_id', 'reply_to_author_name', 'author_uid', 'author_name',
                'author_photo_url', 'author_verified', 'body', 'is_hidden', 'is_deleted',
                'created_at', 'updated_at'
            ]
        ],
        'community_likes' => [
            'pk' => 'like_id',
            'ownerCol' => 'user_id',
            'userWritable' => true,
            'searchCols' => ['post_id', 'user_id'],
            'columns' => ['like_id', 'post_id', 'user_id', 'created_at', 'updated_at']
        ],
        'community_bookmarks' => [
            'pk' => 'bookmark_id',
            'ownerCol' => 'user_id',
            'userWritable' => true,
            'userScopedRead' => 'user_id',
            'searchCols' => ['post_id', 'user_id', 'title'],
            'columns' => ['bookmark_id', 'post_id', 'user_id', 'title', 'category', 'author_name', 'photo_url', 'created_at', 'updated_at']
        ],
        'community_reports' => [
            'pk' => 'report_id',
            'ownerCol' => 'reporter_uid',
            'userWritable' => true,
            'adminOnlyRead' => true,
            'searchCols' => ['reason', 'details', 'target_id', 'reporter_name'],
            'columns' => [
                'report_id', 'target_type', 'target_id', 'post_id', 'comment_id', 'reporter_uid',
                'reporter_name', 'reason', 'details', 'status', 'admin_note', 'resolved_by_uid',
                'created_at', 'updated_at'
            ]
        ],
        'community_user_restrictions' => [
            'pk' => 'user_id',
            'ownerCol' => 'user_id',
            'userWritable' => false,
            'userScopedRead' => 'user_id',
            'searchCols' => ['user_id', 'user_name', 'reason'],
            'columns' => [
                'user_id', 'user_name', 'is_blocked', 'can_post', 'can_comment', 'can_upload_photo',
                'reason', 'blocked_by_uid', 'updated_by_uid', 'created_at', 'updated_at'
            ]
        ],
        'technicians' => [
            'pk' => 'technician_id',
            'ownerCol' => 'linked_user_uid',
            'userWritable' => false,
            'searchCols' => ['full_name', 'city_area', 'district', 'state', 'pin_code'],
            'columns' => [
                'technician_id', 'full_name', 'photo_url', 'photo_storage_path', 'photo_provider_id',
                'mobile_number', 'full_address', 'state', 'district', 'city_area', 'pin_code',
                'service_categories_json', 'experience', 'bio', 'verification_status',
                'blocked', 'is_suspended', 'is_deleted', 'deleted_at', 'linked_user_uid', 'status',
                'updated_by_uid', 'storage_provider_id', 'external_record_id', 'migrated_to_provider_id',
                'checksum_sha256', 'migration_status', 'created_at', 'updated_at'
            ]
        ],
        'technician_verification_requests' => [
            'pk' => 'user_id',
            'ownerCol' => 'user_id',
            'userWritable' => true,
            'userScopedRead' => 'user_id',
            'searchCols' => ['full_name', 'mobile_number', 'city_area', 'district'],
            'columns' => [
                'user_id', 'full_name', 'mobile_number', 'full_address', 'state', 'district',
                'city_area', 'pin_code', 'service_categories_json', 'experience', 'bio',
                'profile_photo_url', 'profile_photo_storage_path', 'profile_photo_provider_id',
                'credential_doc_url', 'credential_doc_storage_path', 'credential_doc_provider_id',
                'credential_doc_name', 'status', 'rejection_reason', 'reviewed_by_uid',
                'storage_provider_id', 'external_record_id', 'migrated_to_provider_id',
                'checksum_sha256', 'migration_status', 'created_at', 'updated_at'
            ]
        ],
        'technical_documents' => [
            'pk' => 'doc_id',
            'ownerCol' => 'uploaded_by_uid',
            'userWritable' => false,
            'searchCols' => ['title', 'description', 'brand_name', 'model_name'],
            'columns' => [
                'doc_id', 'doc_type', 'category_id', 'brand_name', 'model_name', 'linked_entry_id',
                'title', 'description', 'file_url', 'storage_path', 'storage_provider_id',
                'mime_type', 'file_size_bytes', 'published', 'offline_available', 'is_deleted',
                'uploaded_by_uid', 'external_record_id', 'migrated_to_provider_id',
                'checksum_sha256', 'migration_status', 'created_at', 'updated_at'
            ]
        ],
        'problem_reports' => [
            'pk' => 'report_id',
            'ownerCol' => 'user_id',
            'userWritable' => true,
            'userScopedRead' => 'user_id',
            'searchCols' => ['brand_name', 'model_name', 'error_code', 'description'],
            'columns' => [
                'report_id', 'user_id', 'category_id', 'brand_name', 'model_name', 'error_code',
                'description', 'preferred_language', 'status', 'admin_note',
                'storage_provider_id', 'external_record_id', 'migrated_to_provider_id',
                'checksum_sha256', 'migration_status', 'created_at', 'updated_at'
            ]
        ],
        'catalog_entries' => [
            'pk' => 'id',
            'ownerCol' => 'updated_by_uid',
            'userWritable' => false,
            'searchCols' => ['brand_name', 'model_series', 'code', 'title_en', 'summary_en'],
            'columns' => [
                'id', 'entry_type', 'category_id', 'brand_name', 'model_series', 'code',
                'title_en', 'title_bn', 'title_hi', 'summary_en', 'summary_bn', 'summary_hi',
                'steps_en', 'steps_bn', 'steps_hi', 'safety_warning_en',
                'photo_url', 'photo_storage_path', 'pdf_url', 'pdf_storage_path', 'pdf_title',
                'diagram_url', 'diagram_storage_path', 'diagram_title',
                'verification_status', 'published', 'revision', 'updated_by_uid',
                'storage_provider_id', 'external_record_id', 'migrated_to_provider_id',
                'checksum_sha256', 'migration_status', 'created_at', 'updated_at'
            ]
        ],
        'user_profiles' => [
            'pk' => 'user_id',
            'ownerCol' => 'user_id',
            'userWritable' => true,
            'userScopedRead' => 'user_id',
            'searchCols' => ['display_name', 'email', 'user_id'],
            'columns' => [
                'user_id', 'display_name', 'email', 'photo_url', 'photo_storage_path',
                'photo_provider_id', 'role', 'preferred_language', 'ad_consent_granted',
                'notifications_enabled', 'account_status', 'blocked', 'suspended',
                'community_restricted', 'upload_restricted', 'moderation_reason',
                'moderated_by_uid', 'moderated_at', 'is_verified_technician', 'fcm_token',
                'migrated_to_provider_id', 'migration_status', 'created_at', 'updated_at'
            ]
        ],
        'admin_roles' => [
            'pk' => 'user_id',
            'ownerCol' => 'user_id',
            'userWritable' => false,
            'userScopedRead' => 'user_id',
            'searchCols' => ['user_id', 'email'],
            'columns' => ['user_id', 'email', 'role', 'granted_by_uid', 'created_at', 'updated_at']
        ],
        'saved_guides' => [
            'pk' => 'guide_id',
            'ownerCol' => 'user_id',
            'userWritable' => true,
            'userScopedRead' => 'user_id',
            'searchCols' => ['title', 'summary', 'entry_id', 'code'],
            'columns' => ['guide_id', 'user_id', 'entry_type', 'code', 'category_id', 'title', 'summary', 'entry_id', 'saved_at', 'created_at', 'updated_at']
        ],
        'cloud_manifest' => [
            'pk' => 'manifest_key',
            'ownerCol' => 'updated_by_uid',
            'userWritable' => false,
            'adminOnlyRead' => true,
            'searchCols' => ['manifest_key'],
            'columns' => ['manifest_key', 'payload_json', 'config_version', 'updated_by_uid', 'created_at', 'updated_at']
        ],
        'cloud_migration_runs' => [
            'pk' => 'run_id',
            'ownerCol' => 'started_by_uid',
            'userWritable' => false,
            'adminOnlyRead' => true,
            'searchCols' => ['run_id', 'target_provider_id', 'status'],
            'columns' => [
                'run_id', 'source_provider_id', 'target_provider_id', 'trigger_mode', 'scope',
                'status', 'total_items', 'migrated_items', 'verified_items', 'cleaned_items',
                'failed_items', 'total_bytes', 'backup_manifest_id', 'last_cursor', 'error_summary',
                'started_by_uid', 'started_at', 'completed_at', 'created_at', 'updated_at'
            ]
        ],
        'cloud_migration_items' => [
            'pk' => 'item_id',
            'ownerCol' => 'run_id',
            'userWritable' => false,
            'adminOnlyRead' => true,
            'searchCols' => ['item_id', 'table_or_bucket', 'record_or_path', 'status'],
            'columns' => [
                'item_id', 'run_id', 'entity_type', 'table_or_bucket', 'record_or_path',
                'source_provider_id', 'target_provider_id', 'checksum_sha256', 'byte_size',
                'status', 'retry_count', 'target_url', 'error_message', 'snapshot_json',
                'created_at', 'updated_at'
            ]
        ],
        'cloud_backup_manifests' => [
            'pk' => 'backup_id',
            'ownerCol' => 'created_by_uid',
            'userWritable' => false,
            'adminOnlyRead' => true,
            'searchCols' => ['backup_id', 'run_id', 'target_provider_id'],
            'columns' => [
                'backup_id', 'run_id', 'source_provider_id', 'target_provider_id',
                'item_count', 'total_bytes', 'checksum_sha256', 'manifest_json', 'status',
                'created_by_uid', 'created_at', 'updated_at'
            ]
        ],
        'cloud_scheduler_status' => [
            'pk' => 'scheduler_id',
            'ownerCol' => 'lock_owner',
            'userWritable' => false,
            'adminOnlyRead' => true,
            'searchCols' => ['scheduler_id', 'status', 'last_status'],
            'columns' => [
                'scheduler_id', 'worker_type', 'status', 'lock_owner', 'locked_until',
                'last_run_at', 'last_success_at', 'last_run_id', 'last_status', 'last_error',
                'last_db_pct', 'last_storage_pct', 'reclaimed_bytes', 'updated_at'
            ]
        ],
        'storage_error_logs' => [
            'pk' => 'error_id',
            'ownerCol' => 'provider_id',
            'userWritable' => false,
            'adminOnlyRead' => true,
            'searchCols' => ['error_id', 'provider_id', 'error_message'],
            'columns' => [
                'error_id', 'provider_id', 'error_message', 'failover_target_id',
                'resolved', 'created_at', 'updated_at'
            ]
        ],
    ];
}

function connectExternalPdo(array $config, bool $exitOnError = true): ?array {
    $dbCfg = $config['db'] ?? [];
    if (empty($dbCfg['enabled'])) {
        if ($exitOnError) {
            sendJson(503, [
                'ok' => false,
                'errorCode' => 'EXTERNAL_DB_DISABLED',
                'message' => 'External SQL database is disabled in hosting config.php (set db.enabled = true).'
            ]);
        }
        return null;
    }
    $driver = strtolower((string)($dbCfg['driver'] ?? 'mysql'));
    try {
        if ($driver === 'sqlite') {
            $sqlitePath = (string)($dbCfg['sqlite_path'] ?? (getPrivateRoot($config) . '/.repairpro_external.sqlite'));
            ensureDir(dirname($sqlitePath));
            $pdo = new PDO('sqlite:' . $sqlitePath, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            return [$pdo, 'sqlite'];
        }
        $host = (string)($dbCfg['mysql_host'] ?? '127.0.0.1');
        $port = (int)($dbCfg['mysql_port'] ?? 3306);
        $dbName = trim((string)($dbCfg['mysql_database'] ?? ''));
        $user = (string)($dbCfg['mysql_username'] ?? '');
        $pass = (string)($dbCfg['mysql_password'] ?? '');
        if ($dbName === '' || $user === '') {
            if ($exitOnError) {
                sendJson(400, [
                    'ok' => false,
                    'errorCode' => 'DB_CREDENTIALS_MISSING',
                    'message' => 'MySQL database name and username are required in config.php.'
                ]);
            }
            return null;
        }
        $dsn = "mysql:host={$host};port={$port};dbname={$dbName};charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        return [$pdo, 'mysql'];
    } catch (Throwable $e) {
        if ($exitOnError) {
            sendJson(500, [
                'ok' => false,
                'errorCode' => 'DB_CONNECTION_FAILED',
                'message' => 'Database connection failed: ' . $e->getMessage()
            ]);
        }
        return null;
    }
}

function getInitStatements(string $driver): array {
    $textType = $driver === 'sqlite' ? 'TEXT' : 'LONGTEXT';
    $strPk = $driver === 'sqlite' ? 'TEXT PRIMARY KEY' : 'VARCHAR(128) PRIMARY KEY';
    $widePk = $driver === 'sqlite' ? 'TEXT PRIMARY KEY' : 'VARCHAR(191) PRIMARY KEY';
    $shortStr = $driver === 'sqlite' ? 'TEXT' : 'VARCHAR(191)';
    $boolInt = $driver === 'sqlite' ? 'INTEGER NOT NULL DEFAULT 0' : 'TINYINT(1) NOT NULL DEFAULT 0';
    $intCol = $driver === 'sqlite' ? 'INTEGER NOT NULL DEFAULT 0' : 'INT NOT NULL DEFAULT 0';
    $bigIntCol = $driver === 'sqlite' ? 'INTEGER NOT NULL DEFAULT 0' : 'BIGINT NOT NULL DEFAULT 0';
    $tsCol = $driver === 'sqlite' ? 'TEXT NOT NULL DEFAULT ""' : 'VARCHAR(64) NOT NULL DEFAULT ""';
    $mysqlOpts = $driver === 'sqlite' ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    return [
        "CREATE TABLE IF NOT EXISTS community_posts (
            post_id {$strPk},
            author_uid {$shortStr} NOT NULL DEFAULT '',
            author_name {$shortStr} NOT NULL DEFAULT '',
            author_photo_url {$textType},
            author_verified {$boolInt},
            category {$shortStr} NOT NULL DEFAULT 'General',
            brand_name {$shortStr} NOT NULL DEFAULT '',
            model_name {$shortStr} NOT NULL DEFAULT '',
            error_code {$shortStr} NOT NULL DEFAULT '',
            title {$textType},
            body {$textType},
            photo_url {$textType},
            photo_storage_path {$textType},
            photo_urls_json {$textType},
            photo_storage_paths_json {$textType},
            photo_provider_ids_json {$textType},
            is_pinned {$boolInt},
            is_hidden {$boolInt},
            is_deleted {$boolInt},
            deleted_by_uid {$shortStr} NOT NULL DEFAULT '',
            deleted_at {$tsCol},
            approval_status {$shortStr} NOT NULL DEFAULT 'APPROVED',
            moderation_note {$textType},
            reviewed_by_uid {$shortStr} NOT NULL DEFAULT '',
            like_count {$intCol},
            comment_count {$intCol},
            report_count {$intCol},
            storage_provider_id {$shortStr} NOT NULL DEFAULT 'cpanel_primary',
            external_record_id {$shortStr} NOT NULL DEFAULT '',
            migrated_to_provider_id {$shortStr} NOT NULL DEFAULT '',
            checksum_sha256 {$shortStr} NOT NULL DEFAULT '',
            migration_status {$shortStr} NOT NULL DEFAULT 'ACTIVE',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS community_comments (
            comment_id {$strPk},
            post_id {$shortStr} NOT NULL DEFAULT '',
            parent_comment_id {$shortStr} NOT NULL DEFAULT '',
            reply_to_author_name {$shortStr} NOT NULL DEFAULT '',
            author_uid {$shortStr} NOT NULL DEFAULT '',
            author_name {$shortStr} NOT NULL DEFAULT '',
            author_photo_url {$textType},
            author_verified {$boolInt},
            body {$textType},
            is_hidden {$boolInt},
            is_deleted {$boolInt},
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS community_likes (
            like_id {$widePk},
            post_id {$shortStr} NOT NULL DEFAULT '',
            user_id {$shortStr} NOT NULL DEFAULT '',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS community_bookmarks (
            bookmark_id {$widePk},
            post_id {$shortStr} NOT NULL DEFAULT '',
            user_id {$shortStr} NOT NULL DEFAULT '',
            title {$textType},
            category {$shortStr} NOT NULL DEFAULT 'General',
            author_name {$shortStr} NOT NULL DEFAULT '',
            photo_url {$textType},
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS community_reports (
            report_id {$strPk},
            target_type {$shortStr} NOT NULL DEFAULT 'POST',
            target_id {$shortStr} NOT NULL DEFAULT '',
            post_id {$shortStr} NOT NULL DEFAULT '',
            comment_id {$shortStr} NOT NULL DEFAULT '',
            reporter_uid {$shortStr} NOT NULL DEFAULT '',
            reporter_name {$shortStr} NOT NULL DEFAULT '',
            reason {$shortStr} NOT NULL DEFAULT '',
            details {$textType},
            status {$shortStr} NOT NULL DEFAULT 'OPEN',
            admin_note {$textType},
            resolved_by_uid {$shortStr} NOT NULL DEFAULT '',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS community_user_restrictions (
            user_id {$widePk},
            user_name {$shortStr} NOT NULL DEFAULT '',
            is_blocked {$boolInt},
            can_post {$boolInt},
            can_comment {$boolInt},
            can_upload_photo {$boolInt},
            reason {$textType},
            blocked_by_uid {$shortStr} NOT NULL DEFAULT '',
            updated_by_uid {$shortStr} NOT NULL DEFAULT '',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS technicians (
            technician_id {$strPk},
            full_name {$shortStr} NOT NULL DEFAULT '',
            photo_url {$textType},
            photo_storage_path {$textType},
            photo_provider_id {$shortStr} NOT NULL DEFAULT '',
            mobile_number {$shortStr} NOT NULL DEFAULT '',
            full_address {$textType},
            state {$shortStr} NOT NULL DEFAULT '',
            district {$shortStr} NOT NULL DEFAULT '',
            city_area {$shortStr} NOT NULL DEFAULT '',
            pin_code {$shortStr} NOT NULL DEFAULT '',
            service_categories_json {$textType},
            experience {$shortStr} NOT NULL DEFAULT '',
            bio {$textType},
            verification_status {$shortStr} NOT NULL DEFAULT 'VERIFIED',
            blocked {$boolInt},
            is_suspended {$boolInt},
            is_deleted {$boolInt},
            deleted_at {$tsCol},
            linked_user_uid {$shortStr} NOT NULL DEFAULT '',
            status {$shortStr} NOT NULL DEFAULT 'ACTIVE',
            updated_by_uid {$shortStr} NOT NULL DEFAULT '',
            storage_provider_id {$shortStr} NOT NULL DEFAULT 'cpanel_primary',
            external_record_id {$shortStr} NOT NULL DEFAULT '',
            migrated_to_provider_id {$shortStr} NOT NULL DEFAULT '',
            checksum_sha256 {$shortStr} NOT NULL DEFAULT '',
            migration_status {$shortStr} NOT NULL DEFAULT 'ACTIVE',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS technician_verification_requests (
            user_id {$widePk},
            full_name {$shortStr} NOT NULL DEFAULT '',
            mobile_number {$shortStr} NOT NULL DEFAULT '',
            full_address {$textType},
            state {$shortStr} NOT NULL DEFAULT '',
            district {$shortStr} NOT NULL DEFAULT '',
            city_area {$shortStr} NOT NULL DEFAULT '',
            pin_code {$shortStr} NOT NULL DEFAULT '',
            service_categories_json {$textType},
            experience {$shortStr} NOT NULL DEFAULT '',
            bio {$textType},
            profile_photo_url {$textType},
            profile_photo_storage_path {$textType},
            profile_photo_provider_id {$shortStr} NOT NULL DEFAULT '',
            credential_doc_url {$textType},
            credential_doc_storage_path {$textType},
            credential_doc_provider_id {$shortStr} NOT NULL DEFAULT '',
            credential_doc_name {$shortStr} NOT NULL DEFAULT '',
            status {$shortStr} NOT NULL DEFAULT 'PENDING',
            rejection_reason {$textType},
            reviewed_by_uid {$shortStr} NOT NULL DEFAULT '',
            storage_provider_id {$shortStr} NOT NULL DEFAULT 'cpanel_primary',
            external_record_id {$shortStr} NOT NULL DEFAULT '',
            migrated_to_provider_id {$shortStr} NOT NULL DEFAULT '',
            checksum_sha256 {$shortStr} NOT NULL DEFAULT '',
            migration_status {$shortStr} NOT NULL DEFAULT 'ACTIVE',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS technical_documents (
            doc_id {$strPk},
            doc_type {$shortStr} NOT NULL DEFAULT 'PDF_MANUAL',
            category_id {$shortStr} NOT NULL DEFAULT 'ac',
            brand_name {$shortStr} NOT NULL DEFAULT '',
            model_name {$shortStr} NOT NULL DEFAULT '',
            linked_entry_id {$shortStr} NOT NULL DEFAULT '',
            title {$textType},
            description {$textType},
            file_url {$textType},
            storage_path {$textType},
            storage_provider_id {$shortStr} NOT NULL DEFAULT '',
            mime_type {$shortStr} NOT NULL DEFAULT 'application/pdf',
            file_size_bytes {$bigIntCol},
            published {$boolInt},
            offline_available {$boolInt},
            is_deleted {$boolInt},
            uploaded_by_uid {$shortStr} NOT NULL DEFAULT '',
            external_record_id {$shortStr} NOT NULL DEFAULT '',
            migrated_to_provider_id {$shortStr} NOT NULL DEFAULT '',
            checksum_sha256 {$shortStr} NOT NULL DEFAULT '',
            migration_status {$shortStr} NOT NULL DEFAULT 'ACTIVE',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS problem_reports (
            report_id {$strPk},
            user_id {$shortStr} NOT NULL DEFAULT '',
            category_id {$shortStr} NOT NULL DEFAULT 'ac',
            brand_name {$shortStr} NOT NULL DEFAULT '',
            model_name {$shortStr} NOT NULL DEFAULT '',
            error_code {$shortStr} NOT NULL DEFAULT '',
            description {$textType},
            preferred_language {$shortStr} NOT NULL DEFAULT 'en',
            status {$shortStr} NOT NULL DEFAULT 'PENDING',
            admin_note {$textType},
            storage_provider_id {$shortStr} NOT NULL DEFAULT 'cpanel_primary',
            external_record_id {$shortStr} NOT NULL DEFAULT '',
            migrated_to_provider_id {$shortStr} NOT NULL DEFAULT '',
            checksum_sha256 {$shortStr} NOT NULL DEFAULT '',
            migration_status {$shortStr} NOT NULL DEFAULT 'ACTIVE',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS catalog_entries (
            id {$strPk},
            entry_type {$shortStr} NOT NULL DEFAULT 'ERROR_CODE',
            category_id {$shortStr} NOT NULL DEFAULT 'ac',
            brand_name {$shortStr} NOT NULL DEFAULT '',
            model_series {$shortStr} NOT NULL DEFAULT '',
            code {$shortStr} NOT NULL DEFAULT '',
            title_en {$textType},
            title_bn {$textType},
            title_hi {$textType},
            summary_en {$textType},
            summary_bn {$textType},
            summary_hi {$textType},
            steps_en {$textType},
            steps_bn {$textType},
            steps_hi {$textType},
            safety_warning_en {$textType},
            photo_url {$textType},
            photo_storage_path {$textType},
            pdf_url {$textType},
            pdf_storage_path {$textType},
            pdf_title {$textType},
            diagram_url {$textType},
            diagram_storage_path {$textType},
            diagram_title {$textType},
            verification_status {$shortStr} NOT NULL DEFAULT 'VERIFIED',
            published {$boolInt},
            revision {$intCol},
            updated_by_uid {$shortStr} NOT NULL DEFAULT '',
            storage_provider_id {$shortStr} NOT NULL DEFAULT 'cpanel_primary',
            external_record_id {$shortStr} NOT NULL DEFAULT '',
            migrated_to_provider_id {$shortStr} NOT NULL DEFAULT '',
            checksum_sha256 {$shortStr} NOT NULL DEFAULT '',
            migration_status {$shortStr} NOT NULL DEFAULT 'ACTIVE',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS user_profiles (
            user_id {$widePk},
            display_name {$shortStr} NOT NULL DEFAULT '',
            email {$shortStr} NOT NULL DEFAULT '',
            photo_url {$textType},
            photo_storage_path {$textType},
            photo_provider_id {$shortStr} NOT NULL DEFAULT '',
            role {$shortStr} NOT NULL DEFAULT 'USER',
            preferred_language {$shortStr} NOT NULL DEFAULT 'en',
            ad_consent_granted {$boolInt},
            notifications_enabled {$boolInt},
            account_status {$shortStr} NOT NULL DEFAULT 'ACTIVE',
            blocked {$boolInt},
            suspended {$boolInt},
            community_restricted {$boolInt},
            upload_restricted {$boolInt},
            moderation_reason {$textType},
            moderated_by_uid {$shortStr} NOT NULL DEFAULT '',
            moderated_at {$tsCol},
            is_verified_technician {$boolInt},
            fcm_token {$textType},
            migrated_to_provider_id {$shortStr} NOT NULL DEFAULT '',
            migration_status {$shortStr} NOT NULL DEFAULT 'ACTIVE',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS admin_roles (
            user_id {$widePk},
            email {$shortStr} NOT NULL DEFAULT '',
            role {$shortStr} NOT NULL DEFAULT 'ADMIN',
            granted_by_uid {$shortStr} NOT NULL DEFAULT '',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS saved_guides (
            guide_id {$widePk},
            user_id {$shortStr} NOT NULL DEFAULT '',
            entry_type {$shortStr} NOT NULL DEFAULT 'PROBLEM',
            code {$shortStr} NOT NULL DEFAULT '',
            category_id {$shortStr} NOT NULL DEFAULT 'ac',
            title {$textType},
            summary {$textType},
            entry_id {$shortStr} NOT NULL DEFAULT '',
            saved_at {$tsCol},
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS cloud_manifest (
            manifest_key {$strPk},
            payload_json {$textType},
            config_version {$bigIntCol},
            updated_by_uid {$shortStr} NOT NULL DEFAULT '',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS cloud_migration_runs (
            run_id {$strPk},
            source_provider_id {$shortStr} NOT NULL DEFAULT 'supabase_primary',
            target_provider_id {$shortStr} NOT NULL DEFAULT '',
            trigger_mode {$shortStr} NOT NULL DEFAULT 'MANUAL',
            scope {$shortStr} NOT NULL DEFAULT 'BOTH',
            status {$shortStr} NOT NULL DEFAULT 'RUNNING',
            total_items {$intCol},
            migrated_items {$intCol},
            verified_items {$intCol},
            cleaned_items {$intCol},
            failed_items {$intCol},
            total_bytes {$bigIntCol},
            backup_manifest_id {$shortStr} NOT NULL DEFAULT '',
            last_cursor {$shortStr} NOT NULL DEFAULT '',
            error_summary {$textType},
            started_by_uid {$shortStr} NOT NULL DEFAULT '',
            started_at {$tsCol},
            completed_at {$tsCol},
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS cloud_migration_items (
            item_id {$widePk},
            run_id {$shortStr} NOT NULL DEFAULT '',
            entity_type {$shortStr} NOT NULL DEFAULT 'table_row',
            table_or_bucket {$shortStr} NOT NULL DEFAULT '',
            record_or_path {$shortStr} NOT NULL DEFAULT '',
            source_provider_id {$shortStr} NOT NULL DEFAULT 'supabase_primary',
            target_provider_id {$shortStr} NOT NULL DEFAULT '',
            checksum_sha256 {$shortStr} NOT NULL DEFAULT '',
            byte_size {$bigIntCol},
            status {$shortStr} NOT NULL DEFAULT 'PENDING',
            retry_count {$intCol},
            target_url {$textType},
            error_message {$textType},
            snapshot_json {$textType},
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS cloud_backup_manifests (
            backup_id {$strPk},
            run_id {$shortStr} NOT NULL DEFAULT '',
            source_provider_id {$shortStr} NOT NULL DEFAULT 'supabase_primary',
            target_provider_id {$shortStr} NOT NULL DEFAULT '',
            item_count {$intCol},
            total_bytes {$bigIntCol},
            checksum_sha256 {$shortStr} NOT NULL DEFAULT '',
            manifest_json {$textType},
            status {$shortStr} NOT NULL DEFAULT 'READY',
            created_by_uid {$shortStr} NOT NULL DEFAULT '',
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS cloud_scheduler_status (
            scheduler_id {$strPk},
            worker_type {$shortStr} NOT NULL DEFAULT 'CPANEL_PHP_CRON',
            status {$shortStr} NOT NULL DEFAULT 'IDLE',
            lock_owner {$shortStr} NOT NULL DEFAULT '',
            locked_until {$tsCol},
            last_run_at {$tsCol},
            last_success_at {$tsCol},
            last_run_id {$shortStr} NOT NULL DEFAULT '',
            last_status {$shortStr} NOT NULL DEFAULT 'READY',
            last_error {$textType},
            last_db_pct {$intCol},
            last_storage_pct {$intCol},
            reclaimed_bytes {$bigIntCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
        "CREATE TABLE IF NOT EXISTS storage_error_logs (
            error_id {$strPk},
            provider_id {$shortStr} NOT NULL DEFAULT '',
            error_message {$textType},
            failover_target_id {$shortStr} NOT NULL DEFAULT '',
            resolved {$boolInt},
            created_at {$tsCol},
            updated_at {$tsCol}
        ){$mysqlOpts}",
    ];
}

function upgradeExistingTableColumns(PDO $pdo, string $driver): void {
    $upgrades = [
        'community_posts' => [
            'storage_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT 'cpanel_primary'" : "VARCHAR(128) NOT NULL DEFAULT 'cpanel_primary'",
            'external_record_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migrated_to_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'checksum_sha256' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migration_status' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT 'ACTIVE'" : "VARCHAR(64) NOT NULL DEFAULT 'ACTIVE'",
        ],
        'technicians' => [
            'photo_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'storage_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT 'cpanel_primary'" : "VARCHAR(128) NOT NULL DEFAULT 'cpanel_primary'",
            'external_record_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migrated_to_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'checksum_sha256' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migration_status' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT 'ACTIVE'" : "VARCHAR(64) NOT NULL DEFAULT 'ACTIVE'",
        ],
        'technical_documents' => [
            'external_record_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migrated_to_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'checksum_sha256' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migration_status' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT 'ACTIVE'" : "VARCHAR(64) NOT NULL DEFAULT 'ACTIVE'",
        ],
        'problem_reports' => [
            'storage_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT 'cpanel_primary'" : "VARCHAR(128) NOT NULL DEFAULT 'cpanel_primary'",
            'external_record_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migrated_to_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'checksum_sha256' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migration_status' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT 'ACTIVE'" : "VARCHAR(64) NOT NULL DEFAULT 'ACTIVE'",
        ],
        'catalog_entries' => [
            'storage_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT 'cpanel_primary'" : "VARCHAR(128) NOT NULL DEFAULT 'cpanel_primary'",
            'external_record_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migrated_to_provider_id' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'checksum_sha256' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT ''" : "VARCHAR(128) NOT NULL DEFAULT ''",
            'migration_status' => $driver === 'sqlite' ? "TEXT NOT NULL DEFAULT 'ACTIVE'" : "VARCHAR(64) NOT NULL DEFAULT 'ACTIVE'",
        ],
    ];
    foreach ($upgrades as $table => $cols) {
        foreach ($cols as $col => $def) {
            try {
                $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$col}` {$def}");
            } catch (Throwable $ignored) {
                // Column already exists
            }
        }
    }
}

function normalizeDbValue($val) {
    if (is_bool($val)) return $val ? 1 : 0;
    if (is_array($val)) return json_encode($val, JSON_UNESCAPED_SLASHES);
    if ($val === null) return '';
    return $val;
}

function computeDatabaseUsageMetrics(array $config): array {
    $dbCfg = $config['db'] ?? [];
    if (empty($dbCfg['enabled'])) {
        return [
            'enabled' => false,
            'driver' => 'disabled',
            'dbUsedBytes' => 0,
            'dbLimitBytes' => (int)($dbCfg['db_limit_bytes'] ?? (1024 * 1024 * 1024)),
            'tables' => [],
        ];
    }
    $pdoPair = connectOptionalPdo($config);
    if (!is_array($pdoPair)) {
        return [
            'enabled' => true,
            'driver' => (string)($dbCfg['driver'] ?? 'mysql'),
            'dbUsedBytes' => 0,
            'dbLimitBytes' => (int)($dbCfg['db_limit_bytes'] ?? (1024 * 1024 * 1024)),
            'tables' => [],
            'error' => 'Database connection failed',
        ];
    }
    [$pdo, $driver] = $pdoPair;
    $dbBytes = 0;
    $tableCounts = [];
    if ($driver === 'sqlite') {
        $sqlitePath = (string)($dbCfg['sqlite_path'] ?? (getPrivateRoot($config) . '/.repairpro_external.sqlite'));
        $dbBytes = file_exists($sqlitePath) ? (int)@filesize($sqlitePath) : 0;
    } else {
        try {
            $dbName = trim((string)($dbCfg['mysql_database'] ?? ''));
            $stmt = $pdo->prepare('SELECT COALESCE(SUM(data_length + index_length), 0) AS total_bytes FROM information_schema.TABLES WHERE table_schema = ?');
            $stmt->execute([$dbName]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $dbBytes = (int)($row['total_bytes'] ?? 0);
        } catch (Throwable $ignored) {}
    }

    foreach (array_keys(getDbTableSchemas()) as $tbl) {
        try {
            $cnt = $pdo->query("SELECT COUNT(*) FROM `{$tbl}`")->fetchColumn();
            $tableCounts[$tbl] = (int)$cnt;
        } catch (Throwable $ignored) {
            // Table not initialized yet
        }
    }

    return [
        'enabled' => true,
        'driver' => $driver,
        'dbUsedBytes' => $dbBytes,
        'dbLimitBytes' => (int)($dbCfg['db_limit_bytes'] ?? (1024 * 1024 * 1024)),
        'tables' => $tableCounts,
    ];
}

function sanitizeDiscoveryPayload(array $raw): array {
    // Strip secrets if anything extra was passed
    unset($raw['apiSecret'], $raw['tempApiSecret'], $raw['mysql_password'], $raw['serviceRoleKey'], $raw['cronSecret'], $raw['supabase_service_role_key']);
    if (!empty($raw['providers']) && is_array($raw['providers'])) {
        $cleanProviders = [];
        foreach ($raw['providers'] as $p) {
            if (!is_array($p)) continue;
            unset($p['apiSecret'], $p['tempApiSecret'], $p['mysqlPassword'], $p['serviceKey'], $p['cronSecret']);
            $cleanProviders[] = $p;
        }
        $raw['providers'] = $cleanProviders;
    }
    return $raw;
}

function loadDiscoveryManifest(array $config): array {
    $pdoPair = connectOptionalPdo($config);
    if (is_array($pdoPair)) {
        [$pdo] = $pdoPair;
        try {
            $stmt = $pdo->prepare('SELECT payload_json, config_version, updated_at FROM `cloud_manifest` WHERE `manifest_key` = ? LIMIT 1');
            $stmt->execute(['storage_routing']);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (is_array($row) && !empty($row['payload_json'])) {
                $decoded = json_decode((string)$row['payload_json'], true);
                if (is_array($decoded)) {
                    $decoded['configVersion'] = (int)($row['config_version'] ?? ($decoded['configVersion'] ?? 1));
                    $decoded['updatedAt'] = (string)($row['updated_at'] ?? '');
                    return sanitizeDiscoveryPayload($decoded);
                }
            }
        } catch (Throwable $ignored) {}
    }

    $privFile = getPrivateRoot($config) . '/.discovery_manifest.json';
    if (file_exists($privFile)) {
        $decoded = json_decode((string)@file_get_contents($privFile), true);
        if (is_array($decoded)) {
            return sanitizeDiscoveryPayload($decoded);
        }
    }
    return [];
}

function normalizeRecordAliases(string $table, array $record): array {
    if ($table === 'community_posts') {
        if (array_key_exists('photo_urls', $record) && !array_key_exists('photo_urls_json', $record)) {
            $record['photo_urls_json'] = $record['photo_urls'];
        }
        if (array_key_exists('photo_storage_paths', $record) && !array_key_exists('photo_storage_paths_json', $record)) {
            $record['photo_storage_paths_json'] = $record['photo_storage_paths'];
        }
        if (array_key_exists('photo_provider_ids', $record) && !array_key_exists('photo_provider_ids_json', $record)) {
            $record['photo_provider_ids_json'] = $record['photo_provider_ids'];
        }
    } elseif ($table === 'technicians' || $table === 'technician_verification_requests') {
        if (array_key_exists('service_categories', $record) && !array_key_exists('service_categories_json', $record)) {
            $record['service_categories_json'] = $record['service_categories'];
        }
    } elseif ($table === 'community_bookmarks' && empty($record['bookmark_id']) && !empty($record['user_id']) && !empty($record['post_id'])) {
        $record['bookmark_id'] = (string)$record['user_id'] . '__' . (string)$record['post_id'];
    } elseif ($table === 'community_likes' && empty($record['like_id']) && !empty($record['user_id']) && !empty($record['post_id'])) {
        $record['like_id'] = (string)$record['user_id'] . '__' . (string)$record['post_id'];
    }
    return $record;
}

function upsertSingleRow(PDO $pdo, string $driver, string $table, array $meta, array $record, bool $preserveTimestamps): string {
    $record = normalizeRecordAliases($table, $record);
    $pk = $meta['pk'];
    $now = gmdate('c');
    if (empty($record[$pk])) {
        $record[$pk] = 'ext_' . bin2hex(random_bytes(8));
    }
    if (!$preserveTimestamps || empty($record['created_at'])) {
        $record['created_at'] = !empty($record['created_at']) ? (string)$record['created_at'] : $now;
    }
    if (!$preserveTimestamps || empty($record['updated_at'])) {
        $record['updated_at'] = $now;
    }

    $cols = [];
    $vals = [];
    foreach ($meta['columns'] as $col) {
        if (array_key_exists($col, $record)) {
            $cols[] = "`{$col}`";
            $vals[] = normalizeDbValue($record[$col]);
        }
    }
    if (empty($cols)) {
        throw new InvalidArgumentException('No valid schema columns found in record.');
    }
    $placeholders = implode(', ', array_fill(0, count($cols), '?'));
    $updateAssignments = [];
    foreach ($cols as $colSql) {
        if ($colSql !== "`{$pk}`") {
            $updateAssignments[] = "{$colSql} = VALUES({$colSql})";
        }
    }
    if ($driver === 'sqlite') {
        $sql = "INSERT OR REPLACE INTO `{$table}` (" . implode(', ', $cols) . ") VALUES ({$placeholders})";
    } else {
        $sql = "INSERT INTO `{$table}` (" . implode(', ', $cols) . ") VALUES ({$placeholders}) ON DUPLICATE KEY UPDATE " . implode(', ', $updateAssignments);
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($vals);
    return (string)$record[$pk];
}

// =========================================================================
// REQUEST ROUTING
// =========================================================================
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$rawBody = ($method === 'POST' || $method === 'DELETE') ? (string)@file_get_contents('php://input') : '';
$jsonInput = $rawBody !== '' ? json_decode($rawBody, true) : null;
if (!is_array($jsonInput)) $jsonInput = [];

$action = strtolower(trim((string)(
    $_GET['action']
    ?? $_POST['action']
    ?? ($jsonInput['action'] ?? '')
)));
if ($action === '') {
    $action = $method === 'GET' ? 'health' : 'upload';
}

checkRateLimit($config);

// Public non-secret config discovery (accessible when Supabase is paused/unreachable)
if ($action === 'public_config_discovery') {
    $manifest = loadDiscoveryManifest($config);
    sendJson(200, [
        'ok' => true,
        'endpointUrl' => resolveScriptEndpointUrl($config),
        'config' => $manifest,
        'timestamp' => gmdate('c'),
    ]);
}

$auth = resolveAuthContext($config, $action, $jsonInput);

$uploadRoot = getUploadRoot($config);
$privateRoot = getPrivateRoot($config);
if (!ensureDir($uploadRoot)) {
    sendJson(500, [
        'ok' => false,
        'errorCode' => 'STORAGE_NOT_WRITABLE',
        'message' => 'Upload directory is not writable. Ensure CHMOD 0755 on uploads/.'
    ]);
}
ensurePrivateFolderGuard($privateRoot);

switch ($action) {
    case 'health':
    case 'stats': {
        $pubStats = computeFolderStats($uploadRoot);
        $privStats = computeFolderStats($privateRoot);
        $freeBytes = function_exists('disk_free_space') ? @disk_free_space($uploadRoot) : false;
        $totalBytes = function_exists('disk_total_space') ? @disk_total_space($uploadRoot) : false;
        $dbUsage = computeDatabaseUsageMetrics($config);

        $bucketBreakdown = [];
        foreach (($config['allowed_buckets'] ?? []) as $bkt) {
            $bRoot = resolveBucketRoot((string)$bkt, $config);
            $bStat = computeFolderStats($bRoot . '/' . $bkt);
            $bucketBreakdown[] = [
                'bucket' => $bkt,
                'isPrivate' => isPrivateBucket((string)$bkt, $config),
                'files' => $bStat['files'],
                'bytes' => $bStat['bytes'],
            ];
        }

        sendJson(200, [
            'ok' => true,
            'status' => 'HEALTHY',
            'phpVersion' => PHP_VERSION,
            'opensslAvailable' => function_exists('openssl_verify'),
            'gdAvailable' => function_exists('imagecreatefromstring'),
            'finfoAvailable' => class_exists('finfo'),
            'pdoAvailable' => class_exists('PDO'),
            'writable' => is_writable($uploadRoot) && is_writable($privateRoot),
            'publicWritable' => is_writable($uploadRoot),
            'privateWritable' => is_writable($privateRoot),
            'firebaseProjectId' => (string)($config['firebase_project_id'] ?? ''),
            'externalDbEnabled' => $dbUsage['enabled'],
            'externalDbDriver' => $dbUsage['driver'],
            'dbUsedBytes' => $dbUsage['dbUsedBytes'],
            'dbLimitBytes' => $dbUsage['dbLimitBytes'],
            'tableCounts' => $dbUsage['tables'],
            'trackedFiles' => $pubStats['files'] + $privStats['files'],
            'usedBytes' => $pubStats['bytes'] + $privStats['bytes'],
            'publicUsedBytes' => $pubStats['bytes'],
            'privateUsedBytes' => $privStats['bytes'],
            'diskFreeBytes' => is_numeric($freeBytes) ? (int)$freeBytes : null,
            'diskTotalBytes' => is_numeric($totalBytes) ? (int)$totalBytes : null,
            'buckets' => $bucketBreakdown,
            'publicBaseUrl' => resolvePublicBaseUrl($config),
            'endpointUrl' => resolveScriptEndpointUrl($config),
            'allowedBuckets' => $config['allowed_buckets'] ?? [],
            'privateBuckets' => $config['private_buckets'] ?? ['verification-documents'],
            'authMethod' => $auth['method'],
            'isAdmin' => $auth['isAdmin'],
            'timestamp' => gmdate('c'),
        ]);
    }

    case 'save_manifest': {
        if (!$auth['isAdmin']) {
            sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Super Admin access required.']);
        }
        $manifestPayload = $jsonInput['config'] ?? $jsonInput['manifest'] ?? null;
        if (!is_array($manifestPayload)) {
            sendJson(400, ['ok' => false, 'errorCode' => 'INVALID_MANIFEST', 'message' => 'config object required.']);
        }
        $cleanManifest = sanitizeDiscoveryPayload($manifestPayload);
        $configVersion = (int)($cleanManifest['configVersion'] ?? time());
        $cleanManifest['configVersion'] = $configVersion;
        $encoded = json_encode($cleanManifest, JSON_UNESCAPED_SLASHES);

        @file_put_contents($privateRoot . '/.discovery_manifest.json', $encoded, LOCK_EX);

        $pdoPair = connectOptionalPdo($config);
        $savedToDb = false;
        if (is_array($pdoPair)) {
            [$pdo, $driver] = $pdoPair;
            try {
                foreach (getInitStatements($driver) as $ddl) {
                    $pdo->exec($ddl);
                }
                $schemas = getDbTableSchemas();
                upsertSingleRow($pdo, $driver, 'cloud_manifest', $schemas['cloud_manifest'], [
                    'manifest_key' => 'storage_routing',
                    'payload_json' => $encoded,
                    'config_version' => $configVersion,
                    'updated_by_uid' => $auth['uid'],
                ], false);
                $savedToDb = true;
            } catch (Throwable $ignored) {}
        }

        sendJson(200, [
            'ok' => true,
            'savedToDb' => $savedToDb,
            'configVersion' => $configVersion,
            'message' => 'Discovery manifest saved securely on cPanel host.'
        ]);
    }

    case 'upload': {
        if ($method !== 'POST') {
            sendJson(405, ['ok' => false, 'errorCode' => 'METHOD_NOT_ALLOWED', 'message' => 'Use POST for uploads.']);
        }
        if ((($auth['isAccountBlocked'] ?? false) || ($auth['isUploadRestricted'] ?? false)) && !$auth['isAdmin']) {
            sendJson(403, ['ok' => false, 'errorCode' => 'UPLOAD_RESTRICTED', 'message' => 'Uploads are disabled for your account by an administrator.']);
        }
        $rawBucket = (string)($_POST['bucket'] ?? $_POST['bucketName'] ?? $_GET['bucket'] ?? ($jsonInput['bucket'] ?? $jsonInput['bucketName'] ?? 'community-photos'));
        $bucket = sanitizeBucket($rawBucket, $config);
        $privateBucket = isPrivateBucket($bucket, $config);
        $bucketRoot = resolveBucketRoot($bucket, $config);

        $rawBytes = '';
        $requestedPath = trim((string)($_POST['objectPath'] ?? $_POST['path'] ?? ($jsonInput['objectPath'] ?? '')));

        if (!empty($_FILES['file']['tmp_name']) && is_uploaded_file($_FILES['file']['tmp_name'])) {
            $rawBytes = (string)@file_get_contents($_FILES['file']['tmp_name']);
            if ($requestedPath === '') {
                $requestedPath = (string)($_FILES['file']['name'] ?? ('file_' . time() . '.jpg'));
            }
        } elseif (isset($jsonInput['base64'])) {
            $decoded = base64_decode((string)$jsonInput['base64'], true);
            if ($decoded !== false) $rawBytes = $decoded;
        } elseif ($rawBody !== '' && empty($jsonInput)) {
            $rawBytes = $rawBody;
        }

        $detectedMime = 'application/octet-stream';
        if (class_exists('finfo')) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $detectedMime = (string)$finfo->buffer($rawBytes);
        } elseif (substr($rawBytes, 0, 5) === '%PDF-') {
            $detectedMime = 'application/pdf';
        } elseif (function_exists('getimagesizefromstring')) {
            $info = @getimagesizefromstring($rawBytes);
            if (is_array($info) && !empty($info['mime'])) {
                $detectedMime = (string)$info['mime'];
            }
        }

        $allowedMimes = $config['allowed_mimes'] ?? [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'application/pdf' => 'pdf',
        ];
        if (!isset($allowedMimes[$detectedMime])) {
            sendJson(415, [
                'ok' => false,
                'errorCode' => 'UNSUPPORTED_MEDIA_TYPE',
                'message' => "Unsupported or unsafe MIME type: {$detectedMime}. Allowed: JPEG, PNG, WebP, PDF."
            ]);
        }
        if ($detectedMime === 'application/pdf' && substr($rawBytes, 0, 5) !== '%PDF-') {
            sendJson(415, [
                'ok' => false,
                'errorCode' => 'INVALID_PDF_HEADER',
                'message' => 'Uploaded PDF failed %PDF- signature validation.'
            ]);
        }
        $safeExt = $allowedMimes[$detectedMime];

        $maxSize = $detectedMime === 'application/pdf'
            ? (int)($config['max_pdf_size_bytes'] ?? (25 * 1024 * 1024))
            : (int)($config['max_file_size_bytes'] ?? (6 * 1024 * 1024));
        $byteLen = strlen($rawBytes);
        if ($byteLen <= 0 || $byteLen > $maxSize) {
            sendJson(400, [
                'ok' => false,
                'errorCode' => 'INVALID_FILE_SIZE',
                'message' => "File must be non-empty and <= {$maxSize} bytes."
            ]);
        }

        $rawHash = hash('sha256', $rawBytes);
        $indexFile = $bucketRoot . '/.dedupe_index.json';
        $baseUrl = resolvePublicBaseUrl($config);
        $scriptEndpoint = resolveScriptEndpointUrl($config);
        $prefix = '/' . trim((string)($config['public_upload_prefix'] ?? '/uploads'), '/');

        $buildReturnUrl = function (string $sp) use ($privateBucket, $scriptEndpoint, $baseUrl, $prefix): string {
            if ($privateBucket) {
                return $scriptEndpoint . '?action=download_private&storagePath=' . rawurlencode($sp);
            }
            return $baseUrl . $prefix . '/' . $sp;
        };

        $skipDedupe = !empty($jsonInput['skipDedupe']);
        if (!empty($config['enable_deduplication']) && !$skipDedupe && !$privateBucket) {
            $index = readDedupeIndex($indexFile);
            $dedupeKey = $bucket . ':' . $rawHash;
            if (isset($index[$dedupeKey]) && is_array($index[$dedupeKey])) {
                $existingRel = (string)($index[$dedupeKey]['storagePath'] ?? '');
                $existingDisk = $bucketRoot . '/' . $existingRel;
                if ($existingRel !== '' && file_exists($existingDisk)) {
                    $storedHash = (string)($index[$dedupeKey]['storedSha256'] ?? hash_file('sha256', $existingDisk));
                    sendJson(200, [
                        'ok' => true,
                        'deduplicated' => true,
                        'isPrivate' => $privateBucket,
                        'bucketName' => $bucket,
                        'storagePath' => $existingRel,
                        'publicUrl' => $buildReturnUrl($existingRel),
                        'mimeType' => $detectedMime,
                        'sizeBytes' => filesize($existingDisk),
                        'sha256' => $storedHash,
                        'rawSha256' => $rawHash,
                    ]);
                }
            }
        }

        $preserveExact = $auth['isAdmin'] && !empty($jsonInput['preserveExactBytes']);
        $safeBytes = $preserveExact ? $rawBytes : reencodeSafeImage($rawBytes, $detectedMime);
        $storedHash = hash('sha256', $safeBytes);

        if ($requestedPath === '') {
            $uidPart = $auth['uid'] !== '' ? preg_replace('/[^a-zA-Z0-9_-]/', '_', $auth['uid']) . '/' : '';
            $requestedPath = $uidPart . date('Y/m') . '/file_' . bin2hex(random_bytes(8)) . '.' . $safeExt;
        }
        $cleanRelPath = sanitizeRelativePath($requestedPath);
        $cleanRelPath = preg_replace('/\.[^.\/]+$/', '', $cleanRelPath) . '.' . $safeExt;
        $storagePath = $bucket . '/' . $cleanRelPath;

        // Enforce UID path prefix for non-admin users on direct upload
        if (!$auth['isAdmin'] && !$auth['isService'] && $auth['uid'] !== '') {
            $uidSafe = preg_replace('/[^a-zA-Z0-9_-]/', '_', $auth['uid']);
            if (strpos($cleanRelPath, $uidSafe . '/') !== 0 && strpos($cleanRelPath, '/' . $uidSafe . '/') === false) {
                $cleanRelPath = $uidSafe . '/' . $cleanRelPath;
                $storagePath = $bucket . '/' . $cleanRelPath;
            }
        }

        $targetFile = $bucketRoot . '/' . $storagePath;
        if (!ensureDir(dirname($targetFile))) {
            sendJson(500, ['ok' => false, 'errorCode' => 'MKDIR_FAILED', 'message' => 'Could not create target subfolder.']);
        }
        if (@file_put_contents($targetFile, $safeBytes, LOCK_EX) === false) {
            sendJson(500, ['ok' => false, 'errorCode' => 'WRITE_FAILED', 'message' => 'Failed to save uploaded file.']);
        }
        @chmod($targetFile, $privateBucket ? 0640 : 0644);

        if (!empty($config['enable_deduplication']) && !$privateBucket) {
            $index = readDedupeIndex($indexFile);
            $index[$bucket . ':' . $rawHash] = [
                'storagePath' => $storagePath,
                'createdAt' => gmdate('c'),
                'sizeBytes' => strlen($safeBytes),
                'storedSha256' => $storedHash,
            ];
            writeDedupeIndex($indexFile, $index);
        }

        sendJson(200, [
            'ok' => true,
            'deduplicated' => false,
            'isPrivate' => $privateBucket,
            'bucketName' => $bucket,
            'storagePath' => $storagePath,
            'publicUrl' => $buildReturnUrl($storagePath),
            'mimeType' => $detectedMime,
            'sizeBytes' => strlen($safeBytes),
            'sha256' => $storedHash,
            'rawSha256' => $rawHash,
        ]);
    }

    case 'verify_file': {
        $rawPath = (string)($_GET['storagePath'] ?? $_POST['storagePath'] ?? ($jsonInput['storagePath'] ?? ''));
        $expectedSha = strtolower(trim((string)($_GET['sha256'] ?? $_POST['sha256'] ?? ($jsonInput['sha256'] ?? ''))));
        $cleanRel = sanitizeRelativePath($rawPath);
        $parts = explode('/', $cleanRel, 2);
        $bucket = sanitizeBucket($parts[0], $config);
        $bucketRoot = resolveBucketRoot($bucket, $config);
        $targetFile = $bucketRoot . '/' . $cleanRel;
        if (!file_exists($targetFile) || !is_file($targetFile)) {
            sendJson(404, ['ok' => false, 'exists' => false, 'errorCode' => 'NOT_FOUND', 'storagePath' => $cleanRel]);
        }
        $actualSha = strtolower((string)hash_file('sha256', $targetFile));
        $sizeBytes = (int)filesize($targetFile);
        $shaMatch = ($expectedSha === '' || hash_equals($expectedSha, $actualSha));
        if (!$shaMatch) {
            sendJson(409, [
                'ok' => false,
                'exists' => true,
                'shaMatch' => false,
                'storagePath' => $cleanRel,
                'expectedSha256' => $expectedSha,
                'actualSha256' => $actualSha,
                'sizeBytes' => $sizeBytes,
                'errorCode' => 'CHECKSUM_MISMATCH',
                'message' => 'Uploaded file checksum did not match expected SHA-256.'
            ]);
        }
        $privateBucket = isPrivateBucket($bucket, $config);
        $url = $privateBucket
            ? (resolveScriptEndpointUrl($config) . '?action=download_private&storagePath=' . rawurlencode($cleanRel))
            : (resolvePublicBaseUrl($config) . '/' . trim((string)($config['public_upload_prefix'] ?? '/uploads'), '/') . '/' . $cleanRel);
        sendJson(200, [
            'ok' => true,
            'exists' => true,
            'shaMatch' => true,
            'isPrivate' => $privateBucket,
            'storagePath' => $cleanRel,
            'publicUrl' => $url,
            'sha256' => $actualSha,
            'sizeBytes' => $sizeBytes,
        ]);
    }

    case 'create_private_download_token': {
        $rawPath = (string)($_GET['storagePath'] ?? $_POST['storagePath'] ?? ($jsonInput['storagePath'] ?? ''));
        $cleanRel = sanitizeRelativePath($rawPath);
        $parts = explode('/', $cleanRel, 2);
        $bucket = sanitizeBucket($parts[0], $config);
        $uid = $auth['uid'];
        $isOwner = $uid !== '' && (strpos($cleanRel, '/' . $uid . '/') !== false || strpos($cleanRel, $bucket . '/' . $uid . '/') === 0);
        if (!$auth['isAdmin'] && !$isOwner) {
            sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Owner or Super Admin access required for private files.']);
        }
        $bucketRoot = resolveBucketRoot($bucket, $config);
        $targetFile = $bucketRoot . '/' . $cleanRel;
        if (!file_exists($targetFile) || !is_file($targetFile)) {
            sendJson(404, ['ok' => false, 'errorCode' => 'NOT_FOUND', 'message' => 'Private document not found on hosting server.']);
        }
        $ttl = max(60, min(900, (int)($jsonInput['expiresInSeconds'] ?? ($config['private_token_ttl_seconds'] ?? 300))));
        $exp = time() + $ttl;
        $token = hash_hmac('sha256', $exp . '|' . $cleanRel, getSigningKey($config));
        $signedUrl = resolveScriptEndpointUrl($config)
            . '?action=download_private&storagePath=' . rawurlencode($cleanRel)
            . '&exp=' . $exp
            . '&token=' . urlencode($token);
        sendJson(200, [
            'ok' => true,
            'signedUrl' => $signedUrl,
            'storagePath' => $cleanRel,
            'expiresAt' => gmdate('c', $exp),
        ]);
    }

    case 'download_private': {
        $rawPath = (string)($_GET['storagePath'] ?? $_POST['storagePath'] ?? ($jsonInput['storagePath'] ?? ''));
        $cleanRel = sanitizeRelativePath($rawPath);
        $parts = explode('/', $cleanRel, 2);
        $bucket = sanitizeBucket($parts[0], $config);
        if ($auth['method'] !== 'signed_download_token' && !$auth['isAdmin']) {
            $uid = $auth['uid'];
            $isOwner = $uid !== '' && (strpos($cleanRel, '/' . $uid . '/') !== false || strpos($cleanRel, $bucket . '/' . $uid . '/') === 0);
            if (!$isOwner) {
                sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Unauthorized private document access.']);
            }
        }
        $bucketRoot = resolveBucketRoot($bucket, $config);
        $targetFile = $bucketRoot . '/' . $cleanRel;
        if (!file_exists($targetFile) || !is_file($targetFile)) {
            sendJson(404, ['ok' => false, 'errorCode' => 'NOT_FOUND', 'message' => 'Private document not found.']);
        }
        $mime = 'application/octet-stream';
        if (class_exists('finfo')) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = (string)$finfo->file($targetFile) ?: 'application/octet-stream';
        }
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . (string)filesize($targetFile));
        header('Cache-Control: private, no-store, max-age=0');
        header('Content-Disposition: inline; filename="' . basename($targetFile) . '"');
        http_response_code(200);
        readfile($targetFile);
        exit;
    }

    case 'list':
    case 'list_files': {
        $bucket = sanitizeBucket((string)($_GET['bucket'] ?? $_POST['bucket'] ?? ($jsonInput['bucketName'] ?? $jsonInput['bucket'] ?? 'community-photos')), $config);
        $privateBucket = isPrivateBucket($bucket, $config);
        if ($privateBucket && !$auth['isAdmin']) {
            sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Only Super Admin may list private buckets.']);
        }
        $bucketRoot = resolveBucketRoot($bucket, $config);
        $bucketDir = $bucketRoot . '/' . $bucket;
        if (!is_dir($bucketDir)) {
            sendJson(200, ['ok' => true, 'bucket' => $bucket, 'files' => []]);
        }
        $baseUrl = resolvePublicBaseUrl($config);
        $scriptEndpoint = resolveScriptEndpointUrl($config);
        $prefix = '/' . trim((string)($config['public_upload_prefix'] ?? '/uploads'), '/');
        $files = [];
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($bucketDir, FilesystemIterator::SKIP_DOTS)
        );
        foreach ($it as $file) {
            /** @var SplFileInfo $file */
            if (!$file->isFile()) continue;
            $name = $file->getFilename();
            if ($name === '.htaccess' || substr($name, 0, 1) === '.') continue;
            $rel = ltrim(str_replace(['\\', $bucketRoot], ['/', ''], $file->getPathname()), '/');
            $url = $privateBucket
                ? ($scriptEndpoint . '?action=download_private&storagePath=' . rawurlencode($rel))
                : ($baseUrl . $prefix . '/' . $rel);
            $files[] = [
                'name' => $name,
                'storagePath' => $rel,
                'publicUrl' => $url,
                'isPrivate' => $privateBucket,
                'sizeBytes' => $file->getSize(),
                'updatedAt' => gmdate('c', $file->getMTime()),
            ];
            if (count($files) >= 500) break;
        }
        usort($files, fn($a, $b) => strcmp($b['updatedAt'], $a['updatedAt']));
        sendJson(200, ['ok' => true, 'bucket' => $bucket, 'files' => $files]);
    }

    case 'delete':
    case 'delete_file': {
        $rawPath = (string)($_POST['storagePath'] ?? $_GET['storagePath'] ?? ($jsonInput['storagePath'] ?? ''));
        $cleanRel = sanitizeRelativePath($rawPath);
        $parts = explode('/', $cleanRel, 2);
        $bucket = sanitizeBucket($parts[0], $config);
        $uid = $auth['uid'];
        $isOwner = $uid !== '' && (strpos($cleanRel, '/' . $uid . '/') !== false || strpos($cleanRel, $bucket . '/' . $uid . '/') === 0);
        if (!$auth['isAdmin'] && !$isOwner) {
            sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Owner or Super Admin access required to delete files.']);
        }
        $bucketRoot = resolveBucketRoot($bucket, $config);
        $targetFile = $bucketRoot . '/' . $cleanRel;
        if (!file_exists($targetFile) || !is_file($targetFile)) {
            sendJson(200, ['ok' => true, 'deleted' => false, 'message' => 'File not found (already removed).']);
        }
        if (!@unlink($targetFile)) {
            sendJson(500, ['ok' => false, 'errorCode' => 'DELETE_FAILED', 'message' => 'Could not remove file on hosting server.']);
        }
        sendJson(200, ['ok' => true, 'deleted' => true, 'storagePath' => $cleanRel]);
    }

    case 'db_health': {
        [$pdo, $driver] = connectExternalPdo($config);
        $tables = [];
        if ($driver === 'sqlite') {
            $stmt = $pdo->query("SELECT name FROM sqlite_master WHERE type='table'");
            $tables = $stmt ? $stmt->fetchAll(PDO::FETCH_COLUMN) : [];
        } else {
            $stmt = $pdo->query('SHOW TABLES');
            $tables = $stmt ? $stmt->fetchAll(PDO::FETCH_COLUMN) : [];
        }
        $usage = computeDatabaseUsageMetrics($config);
        sendJson(200, [
            'ok' => true,
            'status' => 'DB_HEALTHY',
            'driver' => $driver,
            'tables' => $tables,
            'dbUsedBytes' => $usage['dbUsedBytes'],
            'dbLimitBytes' => $usage['dbLimitBytes'],
            'tableCounts' => $usage['tables'],
            'timestamp' => gmdate('c')
        ]);
    }

    case 'db_init_schema': {
        if (!$auth['isAdmin']) {
            sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Super Admin access required.']);
        }
        [$pdo, $driver] = connectExternalPdo($config);
        foreach (getInitStatements($driver) as $ddl) {
            $pdo->exec($ddl);
        }
        upgradeExistingTableColumns($pdo, $driver);
        sendJson(200, [
            'ok' => true,
            'driver' => $driver,
            'message' => 'External database tables initialized and upgraded cleanly.',
            'tables' => array_keys(getDbTableSchemas())
        ]);
    }

    case 'db_query':
    case 'migration_query': {
        [$pdo] = connectExternalPdo($config);
        $schemas = getDbTableSchemas();
        $rawTable = (string)($jsonInput['table'] ?? $_GET['table'] ?? '');
        $table = $action === 'migration_query' && $rawTable === '' ? 'cloud_migration_runs' : normalizeTableName($rawTable);
        if (!isset($schemas[$table])) {
            sendJson(400, ['ok' => false, 'errorCode' => 'INVALID_TABLE', 'message' => 'Unknown table requested.']);
        }
        $meta = $schemas[$table];
        if (!empty($meta['adminOnlyRead']) && !$auth['isAdmin']) {
            sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => "Super Admin privileges required to query {$table}."]);
        }

        $allowedCols = $meta['columns'];
        $filters = is_array($jsonInput['filters'] ?? null) ? $jsonInput['filters'] : [];
        $whereParts = [];
        $bindings = [];

        if (!empty($meta['userScopedRead']) && !$auth['isAdmin']) {
            $scopeCol = $meta['userScopedRead'];
            $whereParts[] = "`{$scopeCol}` = ?";
            $bindings[] = $auth['uid'];
        }

        foreach ($filters as $col => $val) {
            if (in_array((string)$col, $allowedCols, true)) {
                $whereParts[] = "`{$col}` = ?";
                $bindings[] = normalizeDbValue($val);
            }
        }

        $search = trim((string)($jsonInput['search'] ?? ''));
        if ($search !== '' && !empty($meta['searchCols'])) {
            $likeParts = [];
            foreach ($meta['searchCols'] as $sc) {
                if (in_array($sc, $allowedCols, true)) {
                    $likeParts[] = "`{$sc}` LIKE ?";
                    $bindings[] = '%' . $search . '%';
                }
            }
            if (!empty($likeParts)) {
                $whereParts[] = '(' . implode(' OR ', $likeParts) . ')';
            }
        }

        $orderCol = (string)($jsonInput['orderBy'] ?? 'created_at');
        if (!in_array($orderCol, $allowedCols, true)) {
            $orderCol = in_array('created_at', $allowedCols, true) ? 'created_at' : $meta['pk'];
        }
        $orderDir = strtoupper((string)($jsonInput['orderDir'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC';
        $limit = min(500, max(1, (int)($jsonInput['limit'] ?? 120)));
        $offset = max(0, (int)($jsonInput['offset'] ?? 0));

        $sql = "SELECT * FROM `{$table}`"
            . (!empty($whereParts) ? ' WHERE ' . implode(' AND ', $whereParts) : '')
            . " ORDER BY `{$orderCol}` {$orderDir} LIMIT {$limit} OFFSET {$offset}";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($bindings);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        sendJson(200, ['ok' => true, 'table' => $rawTable ?: $table, 'rows' => $rows, 'count' => count($rows)]);
    }

    case 'db_upsert':
    case 'migration_upsert_run': {
        [$pdo, $driver] = connectExternalPdo($config);
        $schemas = getDbTableSchemas();
        $rawTable = (string)($jsonInput['table'] ?? ($action === 'migration_upsert_run' ? 'cloud_migration_runs' : ''));
        $table = normalizeTableName($rawTable);
        $batch = is_array($jsonInput['records'] ?? null) ? $jsonInput['records'] : null;
        $single = is_array($jsonInput['record'] ?? null) ? $jsonInput['record'] : null;
        $records = $batch !== null ? $batch : ($single !== null ? [$single] : []);

        if (!isset($schemas[$table]) || empty($records)) {
            sendJson(400, ['ok' => false, 'errorCode' => 'INVALID_PAYLOAD', 'message' => 'Valid table and record(s) required.']);
        }
        if (count($records) > 100) {
            sendJson(400, ['ok' => false, 'errorCode' => 'BATCH_TOO_LARGE', 'message' => 'Max 100 records per upsert batch.']);
        }

        $meta = $schemas[$table];
        $pk = $meta['pk'];
        $ownerCol = $meta['ownerCol'];
        if (!$auth['isAdmin']) {
            if (!empty($auth['isAccountBlocked'])) {
                sendJson(403, ['ok' => false, 'errorCode' => 'ACCOUNT_RESTRICTED', 'message' => 'Account is restricted.']);
            }
            if ($table === 'community_comments' && empty($auth['canComment'])) {
                sendJson(403, ['ok' => false, 'errorCode' => 'COMMENT_RESTRICTED', 'message' => 'Commenting is disabled for your account.']);
            }
            if (empty($meta['userWritable'])) {
                sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => "Only Super Admin may modify {$table}."]);
            }
        }

        $preserveTimestamps = $auth['isAdmin'] && !empty($jsonInput['preserveTimestamps']);
        $savedIds = [];
        $pdo->beginTransaction();
        try {
            foreach ($records as $rec) {
                if (!is_array($rec) || empty($rec)) continue;
                if (!$auth['isAdmin']) {
                    // Prevent non-admins from overwriting an existing row owned by someone else
                    if (!empty($rec[$pk])) {
                        $chkOwn = $pdo->prepare("SELECT `{$ownerCol}` AS owner_uid FROM `{$table}` WHERE `{$pk}` = ? LIMIT 1");
                        $chkOwn->execute([(string)$rec[$pk]]);
                        $existingRow = $chkOwn->fetch(PDO::FETCH_ASSOC);
                        if (is_array($existingRow) && (string)($existingRow['owner_uid'] ?? '') !== '' && (string)$existingRow['owner_uid'] !== $auth['uid']) {
                            throw new RuntimeException('Forbidden: cannot overwrite record owned by another user.');
                        }
                    }
                    $rec[$ownerCol] = $auth['uid'];
                    if ($table === 'technician_verification_requests') {
                        $rec['status'] = 'PENDING';
                        unset($rec['reviewed_by_uid']);
                    }
                    if ($table === 'user_profiles') {
                        unset($rec['role'], $rec['blocked'], $rec['suspended'], $rec['community_restricted'], $rec['upload_restricted'], $rec['is_verified_technician']);
                    }
                    if ($table === 'community_posts') {
                        $hasPhoto = trim((string)($rec['photo_url'] ?? '')) !== ''
                            || (!empty($rec['photo_urls']) && is_array($rec['photo_urls']))
                            || (!empty($rec['photo_urls_json']) && trim((string)$rec['photo_urls_json']) !== '[]');
                        if ($hasPhoto && !empty($auth['isUploadRestricted'])) {
                            throw new RuntimeException('Photo uploads are disabled for your account; text-only posts are allowed.');
                        }
                        $rec['approval_status'] = 'PENDING';
                        unset($rec['is_pinned'], $rec['is_hidden']);
                    }
                }
                $savedIds[] = upsertSingleRow($pdo, $driver, $table, $meta, $rec, $preserveTimestamps);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            sendJson(403, ['ok' => false, 'errorCode' => 'UPSERT_FAILED', 'message' => $e->getMessage()]);
        }

        sendJson(200, [
            'ok' => true,
            'table' => $rawTable ?: $table,
            'recordId' => $savedIds[0] ?? '',
            'recordIds' => $savedIds,
            'count' => count($savedIds),
        ]);
    }

    case 'db_update': {
        [$pdo] = connectExternalPdo($config);
        $schemas = getDbTableSchemas();
        $rawTable = (string)($jsonInput['table'] ?? '');
        $table = normalizeTableName($rawTable);
        $recordId = trim((string)($jsonInput['recordId'] ?? ''));
        $record = is_array($jsonInput['record'] ?? null) ? $jsonInput['record'] : [];
        if (!isset($schemas[$table]) || $recordId === '' || empty($record)) {
            sendJson(400, ['ok' => false, 'errorCode' => 'INVALID_PAYLOAD', 'message' => 'Valid table, recordId, and record required.']);
        }
        $meta = $schemas[$table];
        $pk = $meta['pk'];
        $ownerCol = $meta['ownerCol'];

        if (!$auth['isAdmin']) {
            if (!empty($auth['isAccountBlocked'])) {
                sendJson(403, ['ok' => false, 'errorCode' => 'ACCOUNT_RESTRICTED', 'message' => 'Account is restricted.']);
            }
            if ($table === 'community_comments' && empty($auth['canComment'])) {
                sendJson(403, ['ok' => false, 'errorCode' => 'COMMENT_RESTRICTED', 'message' => 'Commenting is disabled for your account.']);
            }
            if (empty($meta['userWritable'])) {
                sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => "Only Super Admin may update {$table}."]);
            }
            $chk = $pdo->prepare("SELECT `{$ownerCol}` AS owner_uid FROM `{$table}` WHERE `{$pk}` = ? LIMIT 1");
            $chk->execute([$recordId]);
            $row = $chk->fetch(PDO::FETCH_ASSOC);
            if (!$row || (string)$row['owner_uid'] !== $auth['uid']) {
                sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Only record owner or admin can update.']);
            }
            if ($table === 'technician_verification_requests') {
                unset($record['status'], $record['reviewed_by_uid'], $record['rejection_reason']);
            }
            if ($table === 'user_profiles') {
                unset($record['role'], $record['blocked'], $record['suspended'], $record['community_restricted'], $record['upload_restricted'], $record['is_verified_technician']);
            }
            if ($table === 'community_posts') {
                $hasPhoto = trim((string)($record['photo_url'] ?? '')) !== ''
                    || (!empty($record['photo_urls']) && is_array($record['photo_urls']));
                if ($hasPhoto && !empty($auth['isUploadRestricted'])) {
                    sendJson(403, ['ok' => false, 'errorCode' => 'UPLOAD_RESTRICTED', 'message' => 'Photo uploads are disabled for your account; text-only posts are allowed.']);
                }
                unset($record['is_pinned'], $record['is_hidden']);
                $record['approval_status'] = 'PENDING';
            }
        }

        $record = normalizeRecordAliases($table, $record);
        $record['updated_at'] = gmdate('c');
        $sets = [];
        $vals = [];
        foreach ($meta['columns'] as $col) {
            if ($col === $pk) continue;
            if (array_key_exists($col, $record)) {
                $sets[] = "`{$col}` = ?";
                $vals[] = normalizeDbValue($record[$col]);
            }
        }
        if (empty($sets)) sendJson(400, ['ok' => false, 'errorCode' => 'NO_FIELDS', 'message' => 'No valid fields to update.']);
        $vals[] = $recordId;
        $stmt = $pdo->prepare("UPDATE `{$table}` SET " . implode(', ', $sets) . " WHERE `{$pk}` = ?");
        $stmt->execute($vals);
        sendJson(200, ['ok' => true, 'table' => $rawTable ?: $table, 'recordId' => $recordId, 'updated' => true]);
    }

    case 'db_delete': {
        [$pdo] = connectExternalPdo($config);
        $schemas = getDbTableSchemas();
        $rawTable = (string)($jsonInput['table'] ?? '');
        $table = normalizeTableName($rawTable);
        $recordId = trim((string)($jsonInput['recordId'] ?? ''));
        if (!isset($schemas[$table]) || $recordId === '') {
            sendJson(400, ['ok' => false, 'errorCode' => 'INVALID_PAYLOAD', 'message' => 'Valid table and recordId required.']);
        }
        $meta = $schemas[$table];
        $pk = $meta['pk'];
        $ownerCol = $meta['ownerCol'];

        if (!$auth['isAdmin']) {
            if (empty($meta['userWritable'])) {
                sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => "Only Super Admin may delete from {$table}."]);
            }
            $chk = $pdo->prepare("SELECT `{$ownerCol}` AS owner_uid FROM `{$table}` WHERE `{$pk}` = ? LIMIT 1");
            $chk->execute([$recordId]);
            $row = $chk->fetch(PDO::FETCH_ASSOC);
            if (!$row || (string)$row['owner_uid'] !== $auth['uid']) {
                sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Only record owner or admin can delete.']);
            }
        }

        $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE `{$pk}` = ?");
        $stmt->execute([$recordId]);
        sendJson(200, ['ok' => true, 'table' => $rawTable ?: $table, 'recordId' => $recordId, 'deleted' => $stmt->rowCount() > 0]);
    }

    case 'db_export_backup': {
        if (!$auth['isAdmin']) {
            sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Super Admin access required.']);
        }
        [$pdo] = connectExternalPdo($config);
        $schemas = getDbTableSchemas();
        $dump = [];
        $totalRows = 0;
        foreach (array_keys($schemas) as $tbl) {
            if (in_array($tbl, ['cloud_migration_items', 'cloud_backup_manifests'], true)) continue;
            try {
                $rows = $pdo->query("SELECT * FROM `{$tbl}`")->fetchAll(PDO::FETCH_ASSOC);
                $dump[$tbl] = $rows;
                $totalRows += count($rows);
            } catch (Throwable $ignored) {
                $dump[$tbl] = [];
            }
        }
        sendJson(200, [
            'ok' => true,
            'exportedAt' => gmdate('c'),
            'totalRows' => $totalRows,
            'tables' => $dump,
        ]);
    }

    case 'scheduler_status': {
        if (!$auth['isAdmin'] && !$auth['isService']) {
            sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Super Admin access required.']);
        }
        $heartbeatFile = getPrivateRoot($config) . '/.scheduler_heartbeat.json';
        $heartbeat = file_exists($heartbeatFile) ? json_decode((string)@file_get_contents($heartbeatFile), true) : null;
        $dbRow = null;
        $pdoPair = connectOptionalPdo($config);
        if (is_array($pdoPair)) {
            [$pdo] = $pdoPair;
            try {
                $stmt = $pdo->query("SELECT * FROM `cloud_scheduler_status` WHERE `scheduler_id` = 'default' LIMIT 1");
                $dbRow = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : null;
            } catch (Throwable $ignored) {}
        }
        sendJson(200, [
            'ok' => true,
            'schedulerStatus' => $dbRow ?: null,
            'heartbeat' => is_array($heartbeat) ? $heartbeat : null,
        ]);
    }

    case 'cron_tick': {
        if (!$auth['isAdmin'] && !$auth['isService']) {
            sendJson(403, ['ok' => false, 'errorCode' => 'FORBIDDEN', 'message' => 'Super Admin or service auth required.']);
        }
        $heartbeatFile = getPrivateRoot($config) . '/.scheduler_heartbeat.json';
        $tickPayload = [
            'ok' => true,
            'workerType' => 'CPANEL_PHP_CRON',
            'ranAt' => gmdate('c'),
            'localHealth' => 'OK',
            'actorUid' => $auth['uid'],
        ];
        @file_put_contents($heartbeatFile, json_encode($tickPayload, JSON_PRETTY_PRINT), LOCK_EX);
        $pdoPair = connectOptionalPdo($config);
        if (is_array($pdoPair)) {
            [$pdo, $driver] = $pdoPair;
            try {
                $schemas = getDbTableSchemas();
                upsertSingleRow($pdo, $driver, 'cloud_scheduler_status', $schemas['cloud_scheduler_status'], [
                    'scheduler_id' => 'default',
                    'worker_type' => 'CPANEL_PHP_CRON',
                    'status' => 'IDLE',
                    'last_run_at' => gmdate('c'),
                    'last_success_at' => gmdate('c'),
                    'last_status' => 'OK',
                ], false);
            } catch (Throwable $ignored) {}
        }
        sendJson(200, $tickPayload);
    }

    default:
        sendJson(400, ['ok' => false, 'errorCode' => 'UNKNOWN_ACTION', 'message' => 'Unknown action.']);
}
