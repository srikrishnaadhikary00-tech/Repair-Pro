<?php
/**
 * Repair Pro — 24x7 cPanel Cron Job Worker (`php cron_migrate.php`)
 *
 * Designed for cPanel -> Cron Jobs (e.g., every 15 minutes):
 *   php /home/USER/public_html/repairpro-api/cron_migrate.php >/dev/null 2>&1
 *
 * Security & Safety Rules:
 * - Never executes unauthenticated HTTPS requests without `cron_secret` (constant-time verify).
 * - Uses exclusive file lock (`flock`) + `cloud_scheduler_status` DB lock to prevent overlapping runs.
 * - Never touches or deletes Supabase data unless `autoMigrationEnabled === true` and target checks pass.
 * - Never modifies protected auth/config/system tables.
 */

$configFile = __DIR__ . '/config.php';
$config = file_exists($configFile) ? require $configFile : require __DIR__ . '/config.example.php';

$isCli = (PHP_SAPI === 'cli');
if (!$isCli) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $expected = trim((string)($config['cron_secret'] ?? ''));
    if ($expected === '' || strlen($expected) < 16) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'errorCode' => 'CRON_SECRET_MISSING', 'message' => 'Configure cron_secret in config.php before web cron invocation.']);
        exit;
    }
    $provided = trim((string)($_SERVER['HTTP_X_REPAIRPRO_CRON_SECRET'] ?? ''));
    if ($provided === '' || !hash_equals($expected, $provided)) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'errorCode' => 'UNAUTHORIZED', 'message' => 'Invalid cron secret.']);
        exit;
    }
}

$privDir = rtrim((string)($config['private_dir'] ?? (__DIR__ . '/private_uploads')), '/\\');
if (!is_dir($privDir)) @mkdir($privDir, 0750, true);
$lockPath = $privDir . '/.cron_migrate.lock';
$lockFp = @fopen($lockPath, 'c+');
if (!$lockFp || !@flock($lockFp, LOCK_EX | LOCK_NB)) {
    $msg = ['ok' => true, 'skipped' => true, 'reason' => 'LOCK_HELD'];
    if ($isCli) echo json_encode($msg) . PHP_EOL;
    else echo json_encode($msg);
    exit;
}

$summary = [
    'ok' => true,
    'workerType' => 'CPANEL_PHP_CRON',
    'ranAt' => gmdate('c'),
    'localHealth' => 'OK',
    'edgeTrigger' => 'SKIPPED',
    'message' => ''
];

try {
    // 1. Verify local cPanel upload directories are writable
    $uploadDir = rtrim((string)($config['upload_dir'] ?? (__DIR__ . '/uploads')), '/\\');
    if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
    if (!is_writable($uploadDir) || !is_writable($privDir)) {
        throw new RuntimeException('cPanel upload or private directory is not writable.');
    }

    // 2. If Supabase Service Role Key & URL are configured in server-only config.php,
    // trigger the 24x7 Supabase Edge migration worker cleanly (resumable + backup-safe).
    $supaUrl = rtrim((string)($config['supabase_url'] ?? ''), '/');
    $supaKey = trim((string)($config['supabase_service_role_key'] ?? ''));
    if ($supaUrl !== '' && strpos($supaUrl, 'https://') === 0 && $supaKey !== '') {
        $workerUrl = $supaUrl . '/functions/v1/cloud-migration-worker';
        $payload = json_encode(['action' => 'run_tick', 'triggerMode' => 'CPANEL_CRON_24X7']);
        $ch = curl_init($workerUrl);
        if ($ch) {
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $payload,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $supaKey,
                    'apikey: ' . $supaKey,
                ],
            ]);
            $respRaw = curl_exec($ch);
            $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $decoded = json_decode((string)$respRaw, true);
            $summary['edgeTrigger'] = ($httpCode >= 200 && $httpCode < 300) ? 'OK' : ('HTTP_' . $httpCode);
            $summary['edgeResult'] = is_array($decoded) ? $decoded : substr((string)$respRaw, 0, 300);
        }
    } else {
        $summary['message'] = 'cPanel local storage & DB healthy. Configure supabase_service_role_key in config.php to orchestrate pull-migration from cPanel Cron.';
    }

    // 3. Persist local scheduler heartbeat
    $heartbeatFile = $privDir . '/.scheduler_heartbeat.json';
    @file_put_contents($heartbeatFile, json_encode($summary, JSON_PRETTY_PRINT), LOCK_EX);
} catch (Throwable $e) {
    $summary['ok'] = false;
    $summary['localHealth'] = 'ERROR';
    $summary['message'] = $e->getMessage();
    if (!$isCli) http_response_code(500);
} finally {
    @flock($lockFp, LOCK_UN);
    @fclose($lockFp);
}

echo json_encode($summary, JSON_UNESCAPED_SLASHES) . ($isCli ? PHP_EOL : '');
