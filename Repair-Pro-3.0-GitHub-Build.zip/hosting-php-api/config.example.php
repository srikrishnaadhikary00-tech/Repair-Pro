<?php
/**
 * Repair Pro — Shared Hosting PHP Upload API Configuration Template
 *
 * INSTRUCTIONS:
 * 1. Copy this file to `config.php` in the same folder on your hosting server.
 * 2. Replace `CHANGE_ME_GENERATE_64_CHAR_HEX_SECRET` with a strong random secret
 *    (at least 32 characters). Never commit real secrets to Git.
 * 3. Put the exact same secret ONLY in Supabase Edge Function Secrets / Private Hosting
 *    Secret Manager (via `hosting-proxy-upload`), NEVER in Android source or public Firestore.
 */

return [
    // Strong random Bearer / HMAC shared secret used by Repair Pro backend proxy
    'api_secret' => getenv('REPAIRPRO_HOSTING_SECRET') ?: 'CHANGE_ME_GENERATE_64_CHAR_HEX_SECRET',

    // Public HTTPS base URL where `uploads/` files are served (no trailing slash)
    // Example: 'https://media.yourdomain.com/repairpro-api'
    'public_base_url' => '',

    // Relative folder on disk where uploaded media is stored
    'upload_dir' => __DIR__ . '/uploads',

    // Relative URL prefix appended to public_base_url (e.g., '/uploads')
    'public_upload_prefix' => '/uploads',

    // Allowed subdirectories / buckets (prevents arbitrary path creation)
    'allowed_buckets' => [
        'community-photos',
        'technician-photos',
        'repair-pdfs',
        'circuit-diagrams',
    ],

    // Allowed MIME types (strictly checked against file magic bytes via finfo)
    'allowed_mimes' => [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ],

    // Maximum upload file size in bytes (default: 5 MB)
    'max_file_size_bytes' => 5 * 1024 * 1024,

    // Allowed CORS origins ('*' or comma-separated list of Admin Panel origins)
    'allowed_origins' => '*',

    // Simple file-based rate limit: max requests per IP/caller per window
    'rate_limit_max_requests' => 40,
    'rate_limit_window_seconds' => 60,

    // Enable SHA-256 duplicate detection so identical uploads reuse the existing URL
    'enable_deduplication' => true,

    // Optional maximum age (seconds) for HMAC timestamp validation (anti-replay)
    'hmac_max_skew_seconds' => 300,
];
