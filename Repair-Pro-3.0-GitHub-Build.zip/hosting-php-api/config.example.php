<?php
/**
 * Repair Pro — Shared Hosting PHP Media, Private Storage & MySQL Database API Configuration Template
 *
 * INSTRUCTIONS:
 * 1. Copy this file to `config.php` in the same folder on your cPanel/hosting server.
 * 2. Replace `CHANGE_ME_GENERATE_64_CHAR_HEX_SECRET` with a strong random secret (>=32 chars)
 *    for optional server-to-server proxy calls.
 * 3. Direct Android/Web Admin HTTPS calls authenticate via Firebase ID Tokens (`firebase_project_id`),
 *    so direct cPanel failover & reads work even if Supabase is paused or unavailable!
 * 4. NEVER commit real `config.php` secrets or database passwords to Git or APK builds.
 */

return [
    // Firebase Project ID for direct RS256 Bearer ID Token verification (Auth + FCM only)
    'firebase_project_id' => getenv('REPAIRPRO_FIREBASE_PROJECT_ID') ?: 'gen-lang-client-0218221723',

    // Bootstrap Super Admin email (case-insensitive, requires email_verified=true in Firebase token)
    'bootstrap_admin_email' => getenv('REPAIRPRO_ADMIN_EMAIL') ?: 'srikrishnaadhikary00@gmail.com',

    // Optional server-to-server secret for Supabase Edge proxy / automated scripts
    'api_secret' => getenv('REPAIRPRO_HOSTING_SECRET') ?: 'CHANGE_ME_GENERATE_64_CHAR_HEX_SECRET',

    // Public HTTPS base URL where `uploads/` files & `index.php` are served (no trailing slash)
    // Example: 'https://api.yourdomain.com/repairpro'
    'public_base_url' => '',

    // Public storage directory (served under public_upload_prefix)
    'upload_dir' => __DIR__ . '/uploads',

    // Protected private storage directory (blocked via .htaccess, served only via ?action=download_private)
    'private_dir' => __DIR__ . '/private_uploads',

    // Relative URL prefix appended to public_base_url (e.g., '/uploads')
    'public_upload_prefix' => '/uploads',

    // Allowed subdirectories / buckets
    'allowed_buckets' => [
        'community-photos',
        'technician-photos',
        'repair-pdfs',
        'circuit-diagrams',
        'verification-documents',
        'user-avatars',
    ],

    // Private buckets stored outside public web directory and requiring Firebase Auth or signed token
    'private_buckets' => [
        'verification-documents',
    ],

    // Allowed MIME types (strictly checked against file magic bytes via finfo)
    'allowed_mimes' => [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'application/pdf' => 'pdf',
    ],

    // Maximum upload file sizes in bytes
    'max_file_size_bytes' => 6 * 1024 * 1024,      // 6 MB for images
    'max_pdf_size_bytes' => 25 * 1024 * 1024,      // 25 MB for PDF manuals & diagrams

    // External SQL Database (cPanel MySQL / MariaDB or SQLite)
    'db' => [
        'enabled' => false,
        'driver' => 'mysql', // 'mysql' or 'sqlite'
        'mysql_host' => getenv('REPAIRPRO_MYSQL_HOST') ?: '127.0.0.1',
        'mysql_port' => (int)(getenv('REPAIRPRO_MYSQL_PORT') ?: 3306),
        'mysql_database' => getenv('REPAIRPRO_MYSQL_DB') ?: '',
        'mysql_username' => getenv('REPAIRPRO_MYSQL_USER') ?: '',
        'mysql_password' => getenv('REPAIRPRO_MYSQL_PASS') ?: '',
        'sqlite_path' => __DIR__ . '/private_uploads/.repairpro_external.sqlite',
        'db_limit_bytes' => 1024 * 1024 * 1024, // Reported hosting DB soft capacity (1 GB default)
    ],

    // Allowed CORS origins ('*' or comma-separated list of Admin Panel origins)
    'allowed_origins' => '*',

    // File-based rate limit: max requests per IP per window
    'rate_limit_max_requests' => 180,
    'rate_limit_window_seconds' => 60,

    // Enable SHA-256 duplicate detection so identical uploads reuse the existing URL
    'enable_deduplication' => true,

    // Maximum age (seconds) for HMAC / private download token validation
    'hmac_max_skew_seconds' => 300,
    'private_token_ttl_seconds' => 300,

    // Optional 24x7 cPanel Cron Worker Settings (SERVER-ONLY — NEVER expose in discovery/clients)
    'cron_secret' => getenv('REPAIRPRO_CRON_SECRET') ?: '',
    'supabase_url' => getenv('REPAIRPRO_SUPABASE_URL') ?: 'https://xuakzzjtcgcvudkgxpbd.supabase.co',
    'supabase_service_role_key' => getenv('REPAIRPRO_SUPABASE_SERVICE_ROLE_KEY') ?: '',
];
