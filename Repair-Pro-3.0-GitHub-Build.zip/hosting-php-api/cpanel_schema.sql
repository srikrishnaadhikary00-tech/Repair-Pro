-- Repair Pro — Complete cPanel MySQL / MariaDB Failover & Migration Schema
-- Execute in phpMyAdmin or click "Initialize External DB Schema" in Web Admin -> Multi-Cloud Storage.

CREATE TABLE IF NOT EXISTS community_posts (
  post_id VARCHAR(128) PRIMARY KEY,
  author_uid VARCHAR(191) NOT NULL DEFAULT '',
  author_name VARCHAR(191) NOT NULL DEFAULT '',
  author_photo_url LONGTEXT,
  author_verified TINYINT(1) NOT NULL DEFAULT 0,
  category VARCHAR(191) NOT NULL DEFAULT 'General',
  brand_name VARCHAR(191) NOT NULL DEFAULT '',
  model_name VARCHAR(191) NOT NULL DEFAULT '',
  error_code VARCHAR(191) NOT NULL DEFAULT '',
  title LONGTEXT,
  body LONGTEXT,
  photo_url LONGTEXT,
  photo_storage_path LONGTEXT,
  photo_urls_json LONGTEXT,
  photo_storage_paths_json LONGTEXT,
  photo_provider_ids_json LONGTEXT,
  is_pinned TINYINT(1) NOT NULL DEFAULT 0,
  is_hidden TINYINT(1) NOT NULL DEFAULT 0,
  is_deleted TINYINT(1) NOT NULL DEFAULT 0,
  deleted_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  deleted_at VARCHAR(64) NOT NULL DEFAULT '',
  approval_status VARCHAR(64) NOT NULL DEFAULT 'APPROVED',
  moderation_note LONGTEXT,
  reviewed_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  like_count INT NOT NULL DEFAULT 0,
  comment_count INT NOT NULL DEFAULT 0,
  report_count INT NOT NULL DEFAULT 0,
  storage_provider_id VARCHAR(128) NOT NULL DEFAULT 'cpanel_primary',
  external_record_id VARCHAR(128) NOT NULL DEFAULT '',
  migrated_to_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  checksum_sha256 VARCHAR(128) NOT NULL DEFAULT '',
  migration_status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS community_comments (
  comment_id VARCHAR(128) PRIMARY KEY,
  post_id VARCHAR(128) NOT NULL DEFAULT '',
  parent_comment_id VARCHAR(128) NOT NULL DEFAULT '',
  reply_to_author_name VARCHAR(191) NOT NULL DEFAULT '',
  author_uid VARCHAR(191) NOT NULL DEFAULT '',
  author_name VARCHAR(191) NOT NULL DEFAULT '',
  author_photo_url LONGTEXT,
  author_verified TINYINT(1) NOT NULL DEFAULT 0,
  body LONGTEXT,
  is_hidden TINYINT(1) NOT NULL DEFAULT 0,
  is_deleted TINYINT(1) NOT NULL DEFAULT 0,
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS community_likes (
  like_id VARCHAR(191) PRIMARY KEY,
  post_id VARCHAR(128) NOT NULL DEFAULT '',
  user_id VARCHAR(191) NOT NULL DEFAULT '',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS community_bookmarks (
  bookmark_id VARCHAR(191) PRIMARY KEY,
  post_id VARCHAR(128) NOT NULL DEFAULT '',
  user_id VARCHAR(191) NOT NULL DEFAULT '',
  title LONGTEXT,
  category VARCHAR(191) NOT NULL DEFAULT 'General',
  author_name VARCHAR(191) NOT NULL DEFAULT '',
  photo_url LONGTEXT,
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS community_reports (
  report_id VARCHAR(128) PRIMARY KEY,
  target_type VARCHAR(64) NOT NULL DEFAULT 'POST',
  target_id VARCHAR(128) NOT NULL DEFAULT '',
  post_id VARCHAR(128) NOT NULL DEFAULT '',
  comment_id VARCHAR(128) NOT NULL DEFAULT '',
  reporter_uid VARCHAR(191) NOT NULL DEFAULT '',
  reporter_name VARCHAR(191) NOT NULL DEFAULT '',
  reason VARCHAR(191) NOT NULL DEFAULT '',
  details LONGTEXT,
  status VARCHAR(64) NOT NULL DEFAULT 'OPEN',
  admin_note LONGTEXT,
  resolved_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS community_user_restrictions (
  user_id VARCHAR(191) PRIMARY KEY,
  user_name VARCHAR(191) NOT NULL DEFAULT '',
  is_blocked TINYINT(1) NOT NULL DEFAULT 0,
  can_post TINYINT(1) NOT NULL DEFAULT 1,
  can_comment TINYINT(1) NOT NULL DEFAULT 1,
  can_upload_photo TINYINT(1) NOT NULL DEFAULT 1,
  reason LONGTEXT,
  blocked_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  updated_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS technicians (
  technician_id VARCHAR(128) PRIMARY KEY,
  full_name VARCHAR(191) NOT NULL DEFAULT '',
  photo_url LONGTEXT,
  photo_storage_path LONGTEXT,
  photo_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  mobile_number VARCHAR(64) NOT NULL DEFAULT '',
  full_address LONGTEXT,
  state VARCHAR(191) NOT NULL DEFAULT '',
  district VARCHAR(191) NOT NULL DEFAULT '',
  city_area VARCHAR(191) NOT NULL DEFAULT '',
  pin_code VARCHAR(32) NOT NULL DEFAULT '',
  service_categories_json LONGTEXT,
  experience VARCHAR(191) NOT NULL DEFAULT '',
  bio LONGTEXT,
  verification_status VARCHAR(64) NOT NULL DEFAULT 'VERIFIED',
  blocked TINYINT(1) NOT NULL DEFAULT 0,
  is_suspended TINYINT(1) NOT NULL DEFAULT 0,
  is_deleted TINYINT(1) NOT NULL DEFAULT 0,
  deleted_at VARCHAR(64) NOT NULL DEFAULT '',
  linked_user_uid VARCHAR(191) NOT NULL DEFAULT '',
  status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
  updated_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  storage_provider_id VARCHAR(128) NOT NULL DEFAULT 'cpanel_primary',
  external_record_id VARCHAR(128) NOT NULL DEFAULT '',
  migrated_to_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  checksum_sha256 VARCHAR(128) NOT NULL DEFAULT '',
  migration_status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS technician_verification_requests (
  user_id VARCHAR(191) PRIMARY KEY,
  full_name VARCHAR(191) NOT NULL DEFAULT '',
  mobile_number VARCHAR(64) NOT NULL DEFAULT '',
  full_address LONGTEXT,
  state VARCHAR(191) NOT NULL DEFAULT '',
  district VARCHAR(191) NOT NULL DEFAULT '',
  city_area VARCHAR(191) NOT NULL DEFAULT '',
  pin_code VARCHAR(32) NOT NULL DEFAULT '',
  service_categories_json LONGTEXT,
  experience VARCHAR(191) NOT NULL DEFAULT '',
  bio LONGTEXT,
  profile_photo_url LONGTEXT,
  profile_photo_storage_path LONGTEXT,
  profile_photo_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  credential_doc_url LONGTEXT,
  credential_doc_storage_path LONGTEXT,
  credential_doc_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  credential_doc_name VARCHAR(191) NOT NULL DEFAULT '',
  status VARCHAR(64) NOT NULL DEFAULT 'PENDING',
  rejection_reason LONGTEXT,
  reviewed_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  storage_provider_id VARCHAR(128) NOT NULL DEFAULT 'cpanel_primary',
  external_record_id VARCHAR(128) NOT NULL DEFAULT '',
  migrated_to_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  checksum_sha256 VARCHAR(128) NOT NULL DEFAULT '',
  migration_status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS technical_documents (
  doc_id VARCHAR(128) PRIMARY KEY,
  doc_type VARCHAR(64) NOT NULL DEFAULT 'PDF_MANUAL',
  category_id VARCHAR(64) NOT NULL DEFAULT 'ac',
  brand_name VARCHAR(191) NOT NULL DEFAULT '',
  model_name VARCHAR(191) NOT NULL DEFAULT '',
  linked_entry_id VARCHAR(191) NOT NULL DEFAULT '',
  title LONGTEXT,
  description LONGTEXT,
  file_url LONGTEXT,
  storage_path LONGTEXT,
  storage_provider_id VARCHAR(191) NOT NULL DEFAULT '',
  mime_type VARCHAR(128) NOT NULL DEFAULT 'application/pdf',
  file_size_bytes BIGINT NOT NULL DEFAULT 0,
  published TINYINT(1) NOT NULL DEFAULT 1,
  offline_available TINYINT(1) NOT NULL DEFAULT 1,
  is_deleted TINYINT(1) NOT NULL DEFAULT 0,
  uploaded_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  external_record_id VARCHAR(128) NOT NULL DEFAULT '',
  migrated_to_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  checksum_sha256 VARCHAR(128) NOT NULL DEFAULT '',
  migration_status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS problem_reports (
  report_id VARCHAR(128) PRIMARY KEY,
  user_id VARCHAR(191) NOT NULL DEFAULT '',
  category_id VARCHAR(64) NOT NULL DEFAULT 'ac',
  brand_name VARCHAR(191) NOT NULL DEFAULT '',
  model_name VARCHAR(191) NOT NULL DEFAULT '',
  error_code VARCHAR(191) NOT NULL DEFAULT '',
  description LONGTEXT,
  preferred_language VARCHAR(16) NOT NULL DEFAULT 'en',
  status VARCHAR(64) NOT NULL DEFAULT 'PENDING',
  admin_note LONGTEXT,
  storage_provider_id VARCHAR(128) NOT NULL DEFAULT 'cpanel_primary',
  external_record_id VARCHAR(128) NOT NULL DEFAULT '',
  migrated_to_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  checksum_sha256 VARCHAR(128) NOT NULL DEFAULT '',
  migration_status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS catalog_entries (
  id VARCHAR(128) PRIMARY KEY,
  entry_type VARCHAR(64) NOT NULL DEFAULT 'ERROR_CODE',
  category_id VARCHAR(64) NOT NULL DEFAULT 'ac',
  brand_name VARCHAR(191) NOT NULL DEFAULT '',
  model_series VARCHAR(191) NOT NULL DEFAULT '',
  code VARCHAR(191) NOT NULL DEFAULT '',
  title_en LONGTEXT,
  title_bn LONGTEXT,
  title_hi LONGTEXT,
  summary_en LONGTEXT,
  summary_bn LONGTEXT,
  summary_hi LONGTEXT,
  steps_en LONGTEXT,
  steps_bn LONGTEXT,
  steps_hi LONGTEXT,
  safety_warning_en LONGTEXT,
  photo_url LONGTEXT,
  photo_storage_path LONGTEXT,
  pdf_url LONGTEXT,
  pdf_storage_path LONGTEXT,
  pdf_title LONGTEXT,
  diagram_url LONGTEXT,
  diagram_storage_path LONGTEXT,
  diagram_title LONGTEXT,
  verification_status VARCHAR(64) NOT NULL DEFAULT 'VERIFIED',
  published TINYINT(1) NOT NULL DEFAULT 1,
  revision INT NOT NULL DEFAULT 1,
  updated_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  storage_provider_id VARCHAR(128) NOT NULL DEFAULT 'cpanel_primary',
  external_record_id VARCHAR(128) NOT NULL DEFAULT '',
  migrated_to_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  checksum_sha256 VARCHAR(128) NOT NULL DEFAULT '',
  migration_status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_profiles (
  user_id VARCHAR(191) PRIMARY KEY,
  display_name VARCHAR(191) NOT NULL DEFAULT '',
  email VARCHAR(191) NOT NULL DEFAULT '',
  photo_url LONGTEXT,
  photo_storage_path LONGTEXT,
  photo_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  role VARCHAR(64) NOT NULL DEFAULT 'USER',
  preferred_language VARCHAR(16) NOT NULL DEFAULT 'en',
  ad_consent_granted TINYINT(1) NOT NULL DEFAULT 1,
  notifications_enabled TINYINT(1) NOT NULL DEFAULT 1,
  account_status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
  blocked TINYINT(1) NOT NULL DEFAULT 0,
  suspended TINYINT(1) NOT NULL DEFAULT 0,
  community_restricted TINYINT(1) NOT NULL DEFAULT 0,
  upload_restricted TINYINT(1) NOT NULL DEFAULT 0,
  moderation_reason LONGTEXT,
  moderated_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  moderated_at VARCHAR(64) NOT NULL DEFAULT '',
  is_verified_technician TINYINT(1) NOT NULL DEFAULT 0,
  fcm_token LONGTEXT,
  migrated_to_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  migration_status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admin_roles (
  user_id VARCHAR(191) PRIMARY KEY,
  email VARCHAR(191) NOT NULL DEFAULT '',
  role VARCHAR(64) NOT NULL DEFAULT 'ADMIN',
  granted_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS saved_guides (
  guide_id VARCHAR(191) PRIMARY KEY,
  user_id VARCHAR(191) NOT NULL DEFAULT '',
  entry_type VARCHAR(64) NOT NULL DEFAULT 'PROBLEM',
  code VARCHAR(64) NOT NULL DEFAULT '',
  category_id VARCHAR(64) NOT NULL DEFAULT 'ac',
  title LONGTEXT,
  summary LONGTEXT,
  entry_id VARCHAR(191) NOT NULL DEFAULT '',
  saved_at VARCHAR(64) NOT NULL DEFAULT '',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cloud_manifest (
  manifest_key VARCHAR(128) PRIMARY KEY,
  payload_json LONGTEXT,
  config_version BIGINT NOT NULL DEFAULT 1,
  updated_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cloud_migration_runs (
  run_id VARCHAR(128) PRIMARY KEY,
  source_provider_id VARCHAR(128) NOT NULL DEFAULT 'supabase_primary',
  target_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  trigger_mode VARCHAR(64) NOT NULL DEFAULT 'MANUAL',
  scope VARCHAR(64) NOT NULL DEFAULT 'BOTH',
  status VARCHAR(64) NOT NULL DEFAULT 'RUNNING',
  total_items INT NOT NULL DEFAULT 0,
  migrated_items INT NOT NULL DEFAULT 0,
  verified_items INT NOT NULL DEFAULT 0,
  cleaned_items INT NOT NULL DEFAULT 0,
  failed_items INT NOT NULL DEFAULT 0,
  total_bytes BIGINT NOT NULL DEFAULT 0,
  backup_manifest_id VARCHAR(128) NOT NULL DEFAULT '',
  last_cursor VARCHAR(191) NOT NULL DEFAULT '',
  error_summary LONGTEXT,
  started_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  started_at VARCHAR(64) NOT NULL DEFAULT '',
  completed_at VARCHAR(64) NOT NULL DEFAULT '',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cloud_migration_items (
  item_id VARCHAR(191) PRIMARY KEY,
  run_id VARCHAR(128) NOT NULL DEFAULT '',
  entity_type VARCHAR(64) NOT NULL DEFAULT 'table_row',
  table_or_bucket VARCHAR(128) NOT NULL DEFAULT '',
  record_or_path VARCHAR(191) NOT NULL DEFAULT '',
  source_provider_id VARCHAR(128) NOT NULL DEFAULT 'supabase_primary',
  target_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  checksum_sha256 VARCHAR(128) NOT NULL DEFAULT '',
  byte_size BIGINT NOT NULL DEFAULT 0,
  status VARCHAR(64) NOT NULL DEFAULT 'PENDING',
  retry_count INT NOT NULL DEFAULT 0,
  target_url LONGTEXT,
  error_message LONGTEXT,
  snapshot_json LONGTEXT,
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cloud_backup_manifests (
  backup_id VARCHAR(128) PRIMARY KEY,
  run_id VARCHAR(128) NOT NULL DEFAULT '',
  source_provider_id VARCHAR(128) NOT NULL DEFAULT 'supabase_primary',
  target_provider_id VARCHAR(128) NOT NULL DEFAULT '',
  item_count INT NOT NULL DEFAULT 0,
  total_bytes BIGINT NOT NULL DEFAULT 0,
  checksum_sha256 VARCHAR(128) NOT NULL DEFAULT '',
  manifest_json LONGTEXT,
  status VARCHAR(64) NOT NULL DEFAULT 'READY',
  created_by_uid VARCHAR(191) NOT NULL DEFAULT '',
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cloud_scheduler_status (
  scheduler_id VARCHAR(128) PRIMARY KEY,
  worker_type VARCHAR(64) NOT NULL DEFAULT 'CPANEL_PHP_CRON',
  status VARCHAR(64) NOT NULL DEFAULT 'IDLE',
  lock_owner VARCHAR(191) NOT NULL DEFAULT '',
  locked_until VARCHAR(64) NOT NULL DEFAULT '',
  last_run_at VARCHAR(64) NOT NULL DEFAULT '',
  last_success_at VARCHAR(64) NOT NULL DEFAULT '',
  last_run_id VARCHAR(128) NOT NULL DEFAULT '',
  last_status VARCHAR(64) NOT NULL DEFAULT 'READY',
  last_error LONGTEXT,
  last_db_pct INT NOT NULL DEFAULT 0,
  last_storage_pct INT NOT NULL DEFAULT 0,
  reclaimed_bytes BIGINT NOT NULL DEFAULT 0,
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS storage_error_logs (
  error_id VARCHAR(128) PRIMARY KEY,
  provider_id VARCHAR(128) NOT NULL DEFAULT '',
  error_message LONGTEXT,
  failover_target_id VARCHAR(128) NOT NULL DEFAULT '',
  resolved TINYINT(1) NOT NULL DEFAULT 0,
  created_at VARCHAR(64) NOT NULL DEFAULT '',
  updated_at VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
