# Repair Pro — Universal Shared PHP Hosting API Setup Guide

Works on **Hostinger (hPanel)**, **BigRock**, **MilesWeb**, **GoDaddy**, **Namecheap**, **HostGator**, and any **Apache / LiteSpeed / cPanel / DirectAdmin** shared web hosting with PHP 7.4+ or PHP 8.x.

## 1. Upload Package to Your Hosting Account

1. Log into your hosting control panel (**Hostinger hPanel -> File Manager** or **cPanel -> File Manager**).
2. Open `public_html` (or your subdomain folder such as `media.yourdomain.com`).
3. Create a folder named `repairpro-api`.
4. Upload all files from `hosting-php-api/` into `public_html/repairpro-api/`:
   - `index.php`
   - `config.example.php`
   - `.htaccess`
   - `uploads/.htaccess`

## 2. Configure `config.php`

1. Rename/copy `config.example.php` to `config.php` inside `repairpro-api/`.
2. Generate a strong 64-character secret (example via terminal: `openssl rand -hex 32`).
3. Set:
   - `'api_secret' => 'YOUR_64_CHAR_HEX_SECRET'`
   - `'public_base_url' => 'https://yourdomain.com/repairpro-api'` (no trailing slash)
4. Verify folder permissions:
   - `repairpro-api/` -> `0755`
   - `repairpro-api/uploads/` -> `0755` (PHP must be able to create `community-photos/` inside it)
   - `repairpro-api/config.php` -> `0640` (or `0600` on suPHP/LiteSpeed)

## 3. Enable HTTPS (Required by Android)

- Ensure Free Let's Encrypt / AutoSSL is active in Hostinger hPanel or cPanel so your endpoint uses `https://yourdomain.com/repairpro-api/index.php`.
- Android blocks plain `http://` URLs by default for security.

## 4. Store the Secret Safely (Backend Only)

- **NEVER** paste your hosting `api_secret` into Android source code or public Firestore settings.
- Instead, deploy Supabase Edge Function `hosting-proxy-upload` (`supabase/functions/hosting-proxy-upload/index.ts`).
- Save your hosting secret either:
  1. In **Repair Pro Web Admin -> Multi-Cloud Storage & Hosting Manager -> Hosting Secret Manager** (which calls the authenticated Admin-only endpoint on `hosting-proxy-upload` and stores it inside RLS-locked `public.hosting_provider_secrets` readable only by `service_role`), **OR**
  2. As a Supabase Edge Secret (`HOSTING_SECRET_<PROVIDER_ID>` or `PHP_HOSTING_DEFAULT_SECRET`).

## 5. Connect in Repair Pro Web Admin Panel

1. Open **Web Admin Panel -> Multi-Cloud Storage & Hosting Manager**.
2. Under **Add Hosting / Storage Provider**, select **Shared PHP Hosting (Hostinger / BigRock / MilesWeb / GoDaddy / Namecheap / HostGator / cPanel)**.
3. Enter:
   - **Hosting Name:** e.g. `Hostinger Community Media`
   - **Domain / Base URL:** `https://yourdomain.com/repairpro-api`
   - **Upload API Endpoint:** `https://yourdomain.com/repairpro-api/index.php`
   - **Proxy Upload Endpoint:** `https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/hosting-proxy-upload`
   - **Hosting API Secret (Server-Only):** paste the secret from `config.php` (saved securely to `hosting_provider_secrets`, never saved in Firestore)
4. Click **Test Connection** to verify PHP version, writable status, and free space.
5. Set role to **PRIMARY** or **BACKUP** (keeping old Supabase URLs accessible automatically) and click **Save & Apply Storage Config**.
