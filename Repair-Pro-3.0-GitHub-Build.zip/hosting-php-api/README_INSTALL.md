# Repair Pro — cPanel / Shared Hosting PHP & MySQL API Setup Guide

Compatible with **cPanel, Hostinger, BigRock, MilesWeb, GoDaddy, Namecheap, HostGator**, and any PHP 7.4+ / 8.x Apache/Nginx host with **OpenSSL + PDO MySQL + GD**.

## Files to Upload to Your Hosting Folder
Upload the contents of `hosting-php-api/` (for example into `public_html/repairpro-api/`):

- `index.php` — Direct HTTPS Storage & MySQL Database endpoint (supports Firebase RS256 ID Tokens + Server HMAC/Bearer secrets).
- `.htaccess` — Preserves `Authorization` headers across Apache/CGI/FastCGI/LiteSpeed and disables directory browsing.
- `config.php` — Created by copying `config.example.php` and filling in your MySQL database credentials and random `api_secret`.
- `uploads/.htaccess` — Disables PHP execution inside public `uploads/`.
- `uploads/verification-documents/.htaccess` — Extra guard denying direct access.
- `private_uploads/.htaccess` — Blocks **all** direct HTTP access to sensitive verification documents; served solely through `?action=download_private` with Firebase Auth or short-lived HMAC signed URLs.

## Quick Setup Steps
1. Create a MySQL database and user in **cPanel -> MySQL Databases** (e.g. `user_repairpro`).
2. Copy `config.example.php` to `config.php`.
3. In `config.php`:
   - Keep `'firebase_project_id' => 'gen-lang-client-0218221723'` and `'bootstrap_admin_email' => 'srikrishnaadhikary00@gmail.com'`.
   - Set `'api_secret'` to a strong random 64-char hex string.
   - Set `'db' => ['enabled' => true, 'driver' => 'mysql', ...]` with your cPanel MySQL database/username/password.
4. Upload `cpanel_schema.sql` in **phpMyAdmin** OR open **Web Admin -> Multi-Cloud Storage & Hosting** and click **Verify & Test cPanel Connection** -> **Initialize External DB Schema**.
5. Verify in Web Admin:
   - PHP OpenSSL is enabled (`opensslAvailable: true`) for direct Firebase Auth token verification.
   - Both `uploads/` and `private_uploads/` are writable (`0755`).
   - Run **Pre-Activation Verification** before toggling cPanel Active or Primary.
