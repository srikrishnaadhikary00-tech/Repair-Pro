const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails
} = require("@firebase/rules-unit-testing");

const PROJECT_ID = "gen-lang-client-0218221723";
const DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";

let testEnv;

test.before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      host: "127.0.0.1",
      port: 8085,
      rules: fs.readFileSync("firestore.rules", "utf8")
    }
  });
});

test.after(async () => {
  if (testEnv) await testEnv.cleanup();
});

test.beforeEach(async () => {
  await testEnv.clearFirestore();
});

const getDb = (ctx) => ctx.firestore(DATABASE_ID);
const pastTs = () => new Date(Date.now() - 1000);

test("1. Zero-Trust: Unauthenticated users cannot read or write any collection", async () => {
  const unauthDb = getDb(testEnv.unauthenticatedContext());
  await assertFails(unauthDb.collection("users").doc("u1").get());
  await assertFails(unauthDb.collection("catalog_entries").doc("c1").get());
  await assertFails(unauthDb.collection("community_posts").doc("p1").get());
  await assertFails(unauthDb.collection("technicians").doc("t1").get());
  await assertFails(unauthDb.collection("repair_documents").doc("d1").get());
  await assertFails(unauthDb.collection("storage_providers").doc("sp1").get());
});

test("2. User Profiles & Saved Guides: Strict per-user isolation", async () => {
  const aliceDb = getDb(testEnv.authenticatedContext("alice_uid", { email: "alice@example.com", email_verified: true }));
  const bobDb = getDb(testEnv.authenticatedContext("bob_uid", { email: "bob@example.com", email_verified: true }));

  await assertSucceeds(
    aliceDb.collection("users").doc("alice_uid").set({
      userId: "alice_uid",
      displayName: "Alice",
      preferredLanguage: "bn",
      adConsentGranted: true,
      appVersion: "3.0",
      createdAt: pastTs(),
      updatedAt: pastTs()
    })
  );
  await assertFails(bobDb.collection("users").doc("alice_uid").get());
  await assertFails(aliceDb.collection("users").doc("alice_uid").update({ isBlocked: true, updatedAt: pastTs() }));

  await assertSucceeds(
    aliceDb.collection("users").doc("alice_uid").collection("saved_guides").doc("error_ac_lg_ch05").set({
      userId: "alice_uid",
      itemType: "ERROR_CODE",
      itemId: "ac_lg_ch05",
      categoryId: "ac",
      title: "LG CH05",
      subtitle: "Indoor-Outdoor comm",
      createdAt: pastTs()
    })
  );
  await assertFails(bobDb.collection("users").doc("alice_uid").collection("saved_guides").doc("error_ac_lg_ch05").get());
});

test("3. Community System: Users can post/edit/delete own posts; Admin can moderate", async () => {
  const aliceDb = getDb(testEnv.authenticatedContext("alice_uid", { email: "alice@example.com", email_verified: true }));
  const bobDb = getDb(testEnv.authenticatedContext("bob_uid", { email: "bob@example.com", email_verified: true }));
  const adminDb = getDb(testEnv.authenticatedContext("admin_uid", { email: BOOTSTRAP_ADMIN_EMAIL, email_verified: true }));

  await assertSucceeds(
    aliceDb.collection("community_posts").doc("post_1").set({
      authorUid: "alice_uid",
      authorName: "Alice",
      categoryId: "ac",
      title: "LG CH05 Wiring",
      body: "Checked outdoor terminal block and found loose wire.",
      photoUrls: ["https://xuakzzjtcgcvudkgxpbd.supabase.co/storage/v1/object/public/community-photos/demo.jpg"],
      moderationStatus: "APPROVED",
      verifiedTechnician: false,
      likesCount: 0,
      commentsCount: 0,
      createdAt: pastTs(),
      updatedAt: pastTs()
    })
  );

  // Bob can read approved post and comment, but cannot edit or delete Alice's post
  await assertSucceeds(bobDb.collection("community_posts").doc("post_1").get());
  await assertFails(bobDb.collection("community_posts").doc("post_1").update({ body: "Hacked", updatedAt: pastTs() }));
  await assertFails(bobDb.collection("community_posts").doc("post_1").delete());
  await assertSucceeds(
    bobDb.collection("community_posts").doc("post_1").collection("comments").doc("c1").set({
      authorUid: "bob_uid",
      authorName: "Bob",
      body: "Great catch!",
      createdAt: pastTs()
    })
  );

  // Alice can edit own post; Admin can reject post
  await assertSucceeds(aliceDb.collection("community_posts").doc("post_1").update({ body: "Fixed loose wire!", updatedAt: pastTs() }));
  await assertSucceeds(adminDb.collection("community_posts").doc("post_1").update({ moderationStatus: "REJECTED", rejectionReason: "Duplicate", updatedAt: pastTs() }));
});

test("4. Technician Privacy: Private verification docs strictly blocked from ordinary users", async () => {
  const techDb = getDb(testEnv.authenticatedContext("tech_uid", { email: "tech@example.com", email_verified: true }));
  const userDb = getDb(testEnv.authenticatedContext("other_uid", { email: "other@example.com", email_verified: true }));
  const adminDb = getDb(testEnv.authenticatedContext("admin_uid", { email: BOOTSTRAP_ADMIN_EMAIL, email_verified: true }));

  // Technician submits PENDING application (cannot self-approve or self-verify!)
  await assertFails(
    techDb.collection("technicians").doc("tech_uid").set({
      userId: "tech_uid",
      fullName: "Ravi Kumar",
      serviceDetails: "AC & Inverter PCB repair",
      serviceLocation: "Kolkata",
      experienceYears: 6,
      approvalStatus: "APPROVED",
      verified: true,
      active: true,
      blocked: false,
      createdAt: pastTs(),
      updatedAt: pastTs()
    })
  );

  await assertSucceeds(
    techDb.collection("technicians").doc("tech_uid").set({
      userId: "tech_uid",
      fullName: "Ravi Kumar",
      serviceDetails: "AC & Inverter PCB repair",
      serviceLocation: "Kolkata",
      experienceYears: 6,
      approvalStatus: "PENDING",
      verified: false,
      active: true,
      blocked: false,
      createdAt: pastTs(),
      updatedAt: pastTs()
    })
  );

  // Private verification document uploaded by technician
  await assertSucceeds(
    techDb.collection("technicians").doc("tech_uid").collection("private_verification").doc("id_card").set({
      docUrl: "private://verification-documents/id_card.jpg",
      uploadedAt: pastTs()
    })
  );

  // Ordinary user CANNOT view unapproved technician or private verification doc
  await assertFails(userDb.collection("technicians").doc("tech_uid").get());
  await assertFails(userDb.collection("technicians").doc("tech_uid").collection("private_verification").doc("id_card").get());

  // Admin approves & verifies technician
  await assertSucceeds(
    adminDb.collection("technicians").doc("tech_uid").update({
      approvalStatus: "APPROVED",
      verified: true,
      updatedAt: pastTs()
    })
  );

  // Ordinary user CAN now view approved public profile, STILL CANNOT read private verification doc
  await assertSucceeds(userDb.collection("technicians").doc("tech_uid").get());
  await assertFails(userDb.collection("technicians").doc("tech_uid").collection("private_verification").doc("id_card").get());
  await assertSucceeds(adminDb.collection("technicians").doc("tech_uid").collection("private_verification").doc("id_card").get());
});

test("5. PDFs, Notifications, AdMob v3.0 & Multi-Cloud Storage: Admin-only writes enforced", async () => {
  const userDb = getDb(testEnv.authenticatedContext("user_uid", { email: "user@example.com", email_verified: true }));
  const adminDb = getDb(testEnv.authenticatedContext("admin_uid", { email: BOOTSTRAP_ADMIN_EMAIL, email_verified: true }));

  // Repair document (PDF / Circuit diagram)
  await assertFails(
    userDb.collection("repair_documents").doc("doc_1").set({
      docType: "PDF",
      categoryId: "ac",
      brandName: "LG",
      title: "Fake PDF",
      fileUrl: "https://xuakzzjtcgcvudkgxpbd.supabase.co/storage/v1/object/public/repair-pdfs/a.pdf",
      published: true,
      uploadedByUid: "user_uid",
      createdAt: pastTs(),
      updatedAt: pastTs()
    })
  );
  await assertSucceeds(
    adminDb.collection("repair_documents").doc("doc_1").set({
      docType: "PDF",
      categoryId: "ac",
      brandName: "LG",
      title: "LG Dual Inverter Service Manual",
      fileUrl: "https://xuakzzjtcgcvudkgxpbd.supabase.co/storage/v1/object/public/repair-pdfs/lg.pdf",
      published: true,
      uploadedByUid: "admin_uid",
      createdAt: pastTs(),
      updatedAt: pastTs()
    })
  );
  await assertSucceeds(userDb.collection("repair_documents").doc("doc_1").get());

  // Multi-Cloud Storage Providers strictly Admin-only + HTTPS enforced
  await assertFails(userDb.collection("storage_providers").doc("sp_primary").get());
  await assertFails(
    adminDb.collection("storage_providers").doc("sp_bad").set({
      name: "Bad HTTP",
      providerType: "SUPABASE",
      endpointUrl: "http://insecure.local",
      secretEnvKey: "KEY",
      primary: false,
      backup: true,
      enabled: true,
      updatedAt: pastTs()
    })
  );
  await assertSucceeds(
    adminDb.collection("storage_providers").doc("sp_primary").set({
      name: "Supabase Primary (Repair-Pro)",
      providerType: "SUPABASE",
      endpointUrl: "https://xuakzzjtcgcvudkgxpbd.supabase.co",
      secretEnvKey: "SUPABASE_SERVICE_ROLE_KEY",
      primary: true,
      backup: false,
      enabled: true,
      updatedAt: pastTs()
    })
  );

  // Push Notification logging (Admin-only immutable create; users can read history)
  await assertSucceeds(
    adminDb.collection("notifications").doc("notif_1").set({
      title: "Repair Pro v3.0 Live",
      body: "New circuit diagrams and community photos available.",
      targetType: "ALL",
      sentByUid: "admin_uid",
      deliveryStatus: "SENT",
      createdAt: pastTs()
    })
  );
  await assertSucceeds(userDb.collection("notifications").doc("notif_1").get());
  await assertFails(adminDb.collection("notifications").doc("notif_1").delete());

  // AdMob v3.0 remote config with appOpenEnabled & androidNativeId
  await assertSucceeds(
    adminDb.collection("app_settings").doc("admob_config").set({
      configType: "ADMOB",
      adsGlobalEnabled: true,
      bannerEnabled: true,
      interstitialEnabled: true,
      rewardedEnabled: true,
      nativeEnabled: true,
      appOpenEnabled: true,
      testMode: true,
      androidNativeId: "ca-app-pub-3940256099942544/2247696110",
      androidAppOpenId: "ca-app-pub-3940256099942544/9257395921",
      updatedByUid: "admin_uid",
      updatedAt: pastTs()
    })
  );
  await assertSucceeds(userDb.collection("app_settings").doc("admob_config").get());
});
