const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_user_001";
const BOB_UID = "bob_user_002";
const ADMIN_UID = "super_admin_001";
const ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users are blocked from all collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("problem_reports").get());
  await assertFails(unauthDb.collection("catalog_entries").where("published", "==", true).get());
  await assertFails(unauthDb.collection("app_settings").doc("admob_config").get());
  await assertFails(unauthDb.collection("app_settings").doc("storage_config").get());
  await assertFails(unauthDb.collection("push_notifications").get());
  await assertFails(unauthDb.collection("audit_logs").get());
});

test("User profile create, partial update, cross-user denial, and shadow field rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Tech",
      preferredLanguage: "bn",
      adConsentGranted: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      preferredLanguage: "hi",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "SUPER_ADMIN",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      displayName: "Hijacked",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Saved guides subcollection allows owner list/create/delete and blocks other users", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 3000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("saved_guides").doc("err_lg_ch05").set({
      userId: ALICE_UID,
      itemType: "ERROR_CODE",
      itemId: "err_lg_ch05",
      categoryId: "ac",
      title: "LG AC CH05",
      subtitle: "Indoor-Outdoor Communication Error",
      createdAt: now,
    })
  );

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("saved_guides").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("saved_guides").get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("saved_guides").doc("err_lg_ch05").delete());
});

test("Storage config, push_notifications, and storage_error_logs enforce Admin RBAC", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 4000);

  // Regular user cannot overwrite storage_config or push_notifications
  await assertFails(
    aliceDb.collection("app_settings").doc("storage_config").set({
      configType: "STORAGE",
      autoFailoverEnabled: true,
      providersJson: "[]",
      updatedByUid: ALICE_UID,
      updatedAt: now,
    })
  );
  await assertFails(
    aliceDb.collection("push_notifications").doc("push_1").set({
      pushId: "push_1",
      audience: "ALL",
      title: "Hijack",
      body: "Spoof",
      deliveryStatus: "SENT",
      createdByUid: ALICE_UID,
      createdAt: now,
    })
  );

  // Admin writes sanitized storage_config; signed-in user can read routing config
  await assertSucceeds(
    adminDb.collection("app_settings").doc("storage_config").set({
      configType: "STORAGE",
      autoFailoverEnabled: true,
      fcmBackendUrl: "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-fcm-v1",
      providersJson: JSON.stringify([{ id: "supabase_primary", type: "SUPABASE_STORAGE", role: "PRIMARY" }]),
      updatedByUid: ADMIN_UID,
      updatedAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("app_settings").doc("storage_config").get());

  // Admin writes & updates push_notifications
  await assertSucceeds(
    adminDb.collection("push_notifications").doc("push_1").set({
      pushId: "push_1",
      audience: "TECHNICIANS",
      eventType: "NEW_PDF",
      title: "New Inverter Diagram",
      body: "Added LG Dual Inverter wiring manual.",
      deliveryStatus: "SENT",
      sentCount: 12,
      failedCount: 0,
      createdByUid: ADMIN_UID,
      createdAt: now,
    })
  );

  // User can report failover error log; only admin can list/resolve
  await assertSucceeds(
    aliceDb.collection("storage_error_logs").doc("err_1").set({
      errorId: "err_1",
      providerId: "supabase_primary",
      bucketName: "community-photos",
      errorMessage: "HTTP 503",
      failoverTargetId: "backup_1",
      actorUid: ALICE_UID,
      resolved: false,
      createdAt: now,
    })
  );
  await assertFails(aliceDb.collection("storage_error_logs").get());
  await assertSucceeds(adminDb.collection("storage_error_logs").get());
});

test("AI/Billing remote settings block secret fields & Invoices isolate technicians", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 4000);

  // Admin cannot accidentally store raw API key in app_settings/ai_config or inside aiProvidersJson
  await assertFails(
    adminDb.collection("app_settings").doc("ai_config").set({
      configType: "AI",
      aiEnabled: true,
      apiKey: "should-be-blocked",
      updatedByUid: ADMIN_UID,
      updatedAt: now,
    })
  );
  await assertFails(
    adminDb.collection("app_settings").doc("ai_config").set({
      configType: "AI",
      aiEnabled: true,
      aiFreeOnlyMode: true,
      aiProvidersJson: JSON.stringify([{ providerId: "groq_free", providerType: "GROQ", apiKey: "gsk_secret_blocked" }]),
      updatedByUid: ADMIN_UID,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    adminDb.collection("app_settings").doc("ai_config").set({
      configType: "AI",
      aiEnabled: true,
      showAiNavItem: true,
      aiFreeOnlyMode: true,
      aiAllowPaidFallback: false,
      aiAutoFailoverEnabled: true,
      aiProvider: "GROQ",
      aiModel: "llama-3.3-70b-versatile",
      aiDailyLimit: 500,
      aiPerUserLimit: 15,
      aiProvidersJson: JSON.stringify([
        {
          providerId: "gemini_free_primary",
          label: "Google Gemini (Free)",
          providerType: "GEMINI",
          role: "PRIMARY",
          enabled: true,
          isFree: true,
          adminPaidApproved: false,
          endpointUrl: "https://generativelanguage.googleapis.com",
          model: "gemini-2.5-flash",
          dailyLimit: 500,
          perUserLimit: 15
        },
        {
          providerId: "groq_free_secondary",
          label: "Groq (Free)",
          providerType: "GROQ",
          role: "SECONDARY",
          enabled: true,
          isFree: true,
          adminPaidApproved: false,
          endpointUrl: "https://api.groq.com/openai/v1/chat/completions",
          model: "llama-3.3-70b-versatile",
          dailyLimit: 400,
          perUserLimit: 15
        },
        {
          providerId: "openrouter_free_backup",
          label: "OpenRouter (Free)",
          providerType: "OPENROUTER",
          role: "BACKUP",
          enabled: true,
          isFree: true,
          adminPaidApproved: false,
          endpointUrl: "https://openrouter.ai/api/v1/chat/completions",
          model: "meta-llama/llama-3.3-70b-instruct:free",
          dailyLimit: 200,
          perUserLimit: 10
        }
      ]),
      updatedByUid: ADMIN_UID,
      updatedAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("app_settings").doc("ai_config").get());

  // Technician Alice can create/read own invoice; Bob is strictly denied
  await assertSucceeds(
    aliceDb.collection("invoices").doc("inv_001").set({
      invoiceId: "inv_001",
      invoiceNumber: "RP-2026-0001",
      technicianUid: ALICE_UID,
      customerId: "cust_001",
      customerName: "Ramesh Das",
      customerMobile: "+919876543210",
      paymentStatus: "AMOUNT_NOT_ENTERED",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("invoices").doc("inv_001").get());
  await assertFails(bobDb.collection("invoices").doc("inv_001").get());
  await assertFails(
    bobDb.collection("invoices").doc("inv_002").set({
      invoiceId: "inv_002",
      invoiceNumber: "RP-2026-0002",
      technicianUid: ALICE_UID,
      customerId: "cust_001",
      customerName: "Spoof",
      customerMobile: "+919876543210",
      paymentStatus: "UNPAID",
      createdAt: now,
      updatedAt: now,
    })
  );
});

