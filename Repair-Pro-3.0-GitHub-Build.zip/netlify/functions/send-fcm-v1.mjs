// Repair Pro — Secure Netlify Function for Firebase Cloud Messaging (FCM HTTP v1)
// Free-tier alternative if hosting Web Admin on Netlify (set FIREBASE_SERVICE_ACCOUNT_JSON in Netlify Env Vars).
// NEVER put service account private keys in frontend code.

import crypto from "node:crypto";

const PROJECT_ID = "gen-lang-client-0218221723";
const FIRESTORE_DATABASE_ID = "ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8";
const BOOTSTRAP_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com";
const DEFAULT_FIREBASE_WEB_API_KEY = "AIzaSyBuy_nQwFC2W39iASDAdj3rG0vhy9AJW-M";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

function respond(statusCode, body) {
  return {
    statusCode,
    headers: corsHeaders,
    body: JSON.stringify(body)
  };
}

function base64Url(input) {
  return Buffer.from(input)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

async function getGoogleAccessToken(serviceAccount) {
  const now = Math.floor(Date.now() / 1000);
  const header = base64Url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const payload = base64Url(
    JSON.stringify({
      iss: serviceAccount.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging https://www.googleapis.com/auth/datastore",
      aud: serviceAccount.token_uri || "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600
    })
  );
  const signingInput = `${header}.${payload}`;
  const signer = crypto.createSign("RSA-SHA256");
  signer.update(signingInput);
  signer.end();
  const signature = signer.sign(serviceAccount.private_key);
  const jwt = `${signingInput}.${base64Url(signature)}`;

  const resp = await fetch(serviceAccount.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  const data = await resp.json();
  if (!resp.ok || !data.access_token) {
    throw new Error(data.error_description || data.error || `OAuth2 HTTP ${resp.status}`);
  }
  return data.access_token;
}

async function verifyFirebaseIdToken(idToken) {
  const apiKey = process.env.FIREBASE_WEB_API_KEY || DEFAULT_FIREBASE_WEB_API_KEY;
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(apiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken })
  });
  const data = await resp.json();
  if (!resp.ok || !Array.isArray(data.users) || data.users.length === 0) {
    throw new Error(data?.error?.message || "Invalid or expired Firebase session token.");
  }
  const u = data.users[0];
  return {
    uid: String(u.localId || ""),
    email: String(u.email || ""),
    emailVerified: Boolean(u.emailVerified)
  };
}

async function isAuthorizedAdmin(uid, email, emailVerified, googleAccessToken) {
  if (emailVerified && email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) {
    return true;
  }
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/admins/${encodeURIComponent(uid)}`;
  const resp = await fetch(url, {
    headers: { Authorization: `Bearer ${googleAccessToken}` }
  });
  return resp.ok;
}

function getStringField(fields, key) {
  const v = fields?.[key]?.stringValue;
  return typeof v === "string" ? v : "";
}

async function fetchUserTokens(uid, googleAccessToken) {
  const safeUid = uid.replace(/[^a-zA-Z0-9_\-]/g, "");
  if (!safeUid) return [];
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/users/${encodeURIComponent(safeUid)}/fcm_tokens?pageSize=20`;
  const resp = await fetch(url, { headers: { Authorization: `Bearer ${googleAccessToken}` } });
  if (!resp.ok) return [];
  const data = await resp.json();
  return (data.documents || [])
    .map((d) => getStringField(d.fields, "token"))
    .filter((t) => t.length >= 10);
}

async function resolveTargetTokens(audience, targetUids, explicitTokens, googleAccessToken) {
  const tokens = new Set(explicitTokens.filter((t) => typeof t === "string" && t.length >= 10));

  if (audience === "SELECTED") {
    for (const uid of targetUids.slice(0, 200)) {
      const list = await fetchUserTokens(uid, googleAccessToken);
      list.forEach((t) => tokens.add(t));
    }
    return Array.from(tokens);
  }

  if (audience === "TECHNICIANS") {
    const uidSet = new Set();
    const techResp = await fetch(
      `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/technicians?pageSize=200`,
      { headers: { Authorization: `Bearer ${googleAccessToken}` } }
    );
    if (techResp.ok) {
      const d = await techResp.json();
      for (const doc of d.documents || []) {
        const linked = getStringField(doc.fields, "linkedUserUid");
        if (linked) uidSet.add(linked);
      }
    }
    const verResp = await fetch(
      `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/technician_verification_requests?pageSize=200`,
      { headers: { Authorization: `Bearer ${googleAccessToken}` } }
    );
    if (verResp.ok) {
      const d = await verResp.json();
      for (const doc of d.documents || []) {
        if (getStringField(doc.fields, "status") === "VERIFIED") {
          const uid = getStringField(doc.fields, "userId");
          if (uid) uidSet.add(uid);
        }
      }
    }
    for (const uid of uidSet) {
      const list = await fetchUserTokens(uid, googleAccessToken);
      list.forEach((t) => tokens.add(t));
    }
    return Array.from(tokens);
  }

  const runQueryUrl = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents:runQuery`;
  const qResp = await fetch(runQueryUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${googleAccessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId: "fcm_tokens", allDescendants: true }],
        limit: 500
      }
    })
  });
  if (qResp.ok) {
    const rows = await qResp.json();
    if (Array.isArray(rows)) {
      for (const row of rows) {
        const t = getStringField(row?.document?.fields, "token");
        if (t.length >= 10) tokens.add(t);
      }
    }
  }
  return Array.from(tokens);
}

export async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return respond(200, { ok: true });
  }
  if (event.httpMethod !== "POST") {
    return respond(405, { ok: false, errorCode: "METHOD_NOT_ALLOWED", message: "Use POST." });
  }

  try {
    const authHeader = event.headers?.authorization || event.headers?.Authorization || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    if (!idToken) {
      return respond(401, {
        ok: false,
        errorCode: "MISSING_AUTH_TOKEN",
        message: "Missing Firebase ID token. Admin session remains active."
      });
    }

    let caller;
    try {
      caller = await verifyFirebaseIdToken(idToken);
    } catch (err) {
      return respond(401, {
        ok: false,
        errorCode: "INVALID_AUTH_TOKEN",
        message: err?.message || "Invalid Firebase token."
      });
    }

    const saRaw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON || "";
    if (!saRaw.trim()) {
      return respond(503, {
        ok: false,
        errorCode: "FCM_SERVICE_ACCOUNT_NOT_CONFIGURED",
        message: "Set FIREBASE_SERVICE_ACCOUNT_JSON in Netlify Environment Variables to enable live FCM HTTP v1 push."
      });
    }

    const serviceAccount = JSON.parse(saRaw);
    const googleAccessToken = await getGoogleAccessToken(serviceAccount);
    const allowed = await isAuthorizedAdmin(caller.uid, caller.email, caller.emailVerified, googleAccessToken);
    if (!allowed) {
      return respond(403, {
        ok: false,
        errorCode: "FORBIDDEN",
        message: "Account does not have Super Admin permissions in admins/."
      });
    }

    const body = JSON.parse(event.body || "{}");
    const audience = ["ALL", "SELECTED", "TECHNICIANS"].includes(body?.audience) ? body.audience : "ALL";
    const title = String(body?.title || "").trim().slice(0, 140);
    const message = String(body?.message || body?.body || "").trim().slice(0, 1200);
    const imageUrl = typeof body?.imageUrl === "string" && body.imageUrl.startsWith("https://")
      ? body.imageUrl.trim().slice(0, 1000)
      : "";
    const route = String(body?.route || body?.targetRoute || "notifications").trim().slice(0, 160);
    const channel = String(body?.channel || "announcements").trim().slice(0, 40);
    const eventType = String(body?.eventType || "ANNOUNCEMENT").trim().slice(0, 64);
    const targetUids = Array.isArray(body?.targetUids) ? body.targetUids.map(String) : [];
    const explicitTokens = Array.isArray(body?.tokens) ? body.tokens.map(String) : [];

    if (title.length < 2 || message.length < 2) {
      return respond(400, { ok: false, errorCode: "VALIDATION_ERROR", message: "Title and message are required." });
    }

    const tokens = await resolveTargetTokens(audience, targetUids, explicitTokens, googleAccessToken);
    if (tokens.length === 0) {
      return respond(200, {
        ok: true,
        deliveryStatus: "IN_APP_ONLY",
        sentCount: 0,
        failedCount: 0,
        totalTargets: 0,
        message: "No registered FCM tokens matched the target audience yet."
      });
    }

    const androidChannelId = channel === "community"
      ? "repair_pro_community"
      : channel === "verification"
        ? "repair_pro_verification"
        : "repair_pro_announcements";

    let sentCount = 0;
    let failedCount = 0;
    const errors = [];
    const fcmEndpoint = `https://fcm.googleapis.com/v1/projects/${PROJECT_ID}/messages:send`;

    for (const token of tokens) {
      const fcmBody = {
        message: {
          token,
          notification: {
            title,
            body: message,
            ...(imageUrl ? { image: imageUrl } : {})
          },
          data: {
            title,
            body: message,
            channel,
            route,
            imageUrl,
            eventType
          },
          android: {
            priority: "HIGH",
            notification: {
              channel_id: androidChannelId,
              ...(imageUrl ? { image: imageUrl } : {})
            }
          }
        }
      };

      const res = await fetch(fcmEndpoint, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${googleAccessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(fcmBody)
      });
      if (res.ok) {
        sentCount += 1;
      } else {
        failedCount += 1;
        const errPayload = await res.json().catch(() => ({}));
        const detail = errPayload?.error?.message || `HTTP ${res.status}`;
        if (errors.length < 5) errors.push(detail);
      }
    }

    const deliveryStatus = sentCount > 0 && failedCount === 0
      ? "SENT"
      : sentCount > 0
        ? "PARTIAL"
        : "FAILED";

    return respond(200, {
      ok: sentCount > 0,
      deliveryStatus,
      sentCount,
      failedCount,
      totalTargets: tokens.length,
      errors
    });
  } catch (err) {
    return respond(500, {
      ok: false,
      errorCode: "INTERNAL_ERROR",
      message: err?.message || "Unexpected FCM dispatch error"
    });
  }
}
