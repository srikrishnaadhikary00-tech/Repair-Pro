# Repair Pro 3.0 — Phase 2 Cloud Setup & Deployment Guide

This guide covers the **additive** backend and hosting setup steps for Phase 2 without modifying your existing Firebase project (`gen-lang-client-0218221723`), named Firestore database (`ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8`), or Supabase project (`xuakzzjtcgcvudkgxpbd`).

---

## 1. Required Android Local Build File (`google-services.json`)

Ensure your original `google-services.json` (for package `com.aistudio.repairpro.kxmvqz` in Firebase project `gen-lang-client-0218221723`) is placed at:

```
app/google-services.json
```

And ensure `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `FIREBASE_WEB_CLIENT_ID` (ending in `.apps.googleusercontent.com`), and `FCM_BACKEND_ENDPOINT` are configured in your AI Studio Secrets panel or environment.

---

## 2. Additive Supabase PostgreSQL Migration

Run **only** the additive Phase 2 migration in **Supabase Dashboard → SQL Editor** (safe, idempotent `CREATE TABLE IF NOT EXISTS`, does not reset existing tables):

- File: `/supabase/migrations/20261126_phase2_additive_migration.sql`
- Rollback (if ever needed): `/supabase/migrations/20261126_phase2_rollback.sql`

This creates / safely extends (idempotent and compatible with existing tables):
- `hosting_provider_secrets` (strictly server-side `service_role` only; RLS enabled with no client read policy)
- `ai_usage_logs` (with `provider_id`, `is_free`, `failover_used` audit logging)
- `ai_usage_counters` + atomic RPCs `reserve_ai_quota` / `release_ai_quota` (concurrency-safe global, provider, and per-user daily limits)
- `ai_error_logs` (with `provider_id` failure diagnostics)

---

## 3. Deploy Phase 2 Supabase Edge Functions & Secrets

Deploy the two Phase 2 Edge Functions (keeping existing `send-push-notification` untouched):

```bash
supabase functions deploy hosting-proxy-upload --no-verify-jwt
supabase functions deploy ai-repair-assistant --no-verify-jwt
```

Configure the following secrets in **Supabase Dashboard → Edge Functions → Secrets**:

- `SUPABASE_URL` = `https://xuakzzjtcgcvudkgxpbd.supabase.co`
- `SUPABASE_SERVICE_ROLE_KEY` = your Supabase `service_role` key
- `FIREBASE_SERVICE_ACCOUNT_JSON` = JSON credentials for `gen-lang-client-0218221723` (used to read `admins/{uid}` and `app_settings/ai_config`)
- `GEMINI_API_KEY` = Google Gemini Free Tier API key (or set via **Web Super Admin → AI Smart Assistant → Backend AI API Key Vault**)
- `GROQ_API_KEY` = Groq Free Tier API key (optional failover preset, or set via Web Admin Vault)
- `OPENROUTER_API_KEY` = OpenRouter API key for `:free` models (optional failover preset, or set via Web Admin Vault)
- `OPENAI_API_KEY` / `CUSTOM_AI_API_KEY` = optional (blocked automatically whenever **Free Only Mode** is ON)

> Both Edge Functions independently verify the caller's Firebase ID token (`Bearer`) and admin status before allowing admin secret writes or connection override tests. Regular app users never send provider/model/endpoint overrides and obey Free Only Mode strictly.

---

## 4. Deploy Updated Firestore Security Rules

Deploy `/firestore.rules` to your named Firestore database `ai-studio-android-76b0d240-703a-45a1-84ce-916ade67f7c8`:

- Adds strict validation for `app_settings/ai_config` and `app_settings/billing_config`
- Adds new storage & compression controls to `app_settings/storage_config` (`hostingProxyUrl`, `compressionMaxDim`, `compressionQuality`, `compressionMaxSizeKb`, `duplicateCheckEnabled`)
- Adds per-technician owner-isolated collections: `customers/{customerId}`, `invoices/{invoiceId}`, `invoice_payments/{paymentId}` (`technicianUid == request.auth.uid`)
- Adds `ai_error_logs/{errorId}` for Super Admin diagnostics

Verify rules locally (with Firebase emulator if available) using:
```bash
node --test firestore.test.js
```

---

## 5. Shared Web Hosting PHP API Installation (Hostinger / BigRock / MilesWeb / GoDaddy / Namecheap / HostGator / cPanel)

1. Upload all files inside `/hosting-php-api/` to a folder inside your hosting's `public_html/` (for example, `public_html/repairpro-api/`).
2. Rename `config.example.php` to `config.php`.
3. Edit `config.php`:
   - Set `REPAIRPRO_API_SECRET` to a strong 32+ character random secret.
   - Set `REPAIRPRO_PUBLIC_BASE_URL` to your HTTPS uploads folder URL (e.g., `https://media.yourdomain.com/repairpro-api/uploads`).
4. Verify permissions:
   - `uploads/` directory must be writable by PHP (`0755` or `0775`).
   - `.htaccess` and `uploads/.htaccess` block direct PHP execution inside `uploads/`.
5. Open **Web Super Admin Panel → Storage & Web Hosting → Shared Web Hosting Manager**:
   - Select your provider preset (`Hostinger`, `BigRock`, `MilesWeb`, etc.).
   - Enter your HTTPS `PHP Upload API Endpoint` and `Public Media Base URL`.
   - Paste the `REPAIRPRO_API_SECRET` and click **Save Secret to Backend Vault**.
   - Click **Test Hosting Health & Permissions** to verify PHP version & writable uploads folder.
   - Keep **Community & Public Photos Only** enabled so private Verification Documents & PDF manuals remain on Supabase Storage.
