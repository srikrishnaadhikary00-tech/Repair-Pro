package com.example

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.LocalLaundryService
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ads.AdMobManager
import com.example.data.RepairRepository
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.V2DomainHelper
import com.example.data.remote.authStateFlow
import com.example.data.remote.signOutGoogle
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.notifications.RepairProMessagingService
import com.example.ui.RepairViewModel
import com.example.ui.UiState
import com.example.ui.screens.AiRepairAssistantScreen
import com.example.ui.screens.AuthSplashScreen
import com.example.ui.screens.BillingDashboardScreen
import com.example.ui.screens.CameraScannerScreen
import com.example.ui.screens.CategoriesDirectoryScreen
import com.example.ui.screens.CategoryDetailBrandScreen
import com.example.ui.screens.CommunityFeedScreen
import com.example.ui.screens.CommunityPostDetailScreen
import com.example.ui.screens.CreateCommunityPostScreen
import com.example.ui.screens.ErrorCodeDetailScreen
import com.example.ui.screens.FindTechnicianScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.InvoiceDetailScreen
import com.example.ui.screens.InvoiceEditorScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.OnlinePdfViewerScreen
import com.example.ui.screens.ProblemDetailScreen
import com.example.ui.screens.ReportProblemScreen
import com.example.ui.screens.SavedGuidesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SmartSearchScreen
import com.example.ui.screens.SuperAdminScreen
import com.example.ui.screens.TechnicalDocumentsLibraryScreen
import com.example.ui.screens.TechnicianVerificationScreen
import com.example.ui.screens.TroubleshootingWizardScreen
import com.example.ui.screens.ZoomableImageViewerScreen
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkScreenGradient
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.RepairProTheme
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

private const val ROUTE_HOME = "home"
private const val ROUTE_AC = "ac"
private const val ROUTE_FRIDGE = "fridge"
private const val ROUTE_COMMUNITY_BASE = "community"
private const val ROUTE_COMMUNITY_PATTERN = "community?tab={tab}"
private const val ROUTE_COMMUNITY_CREATE_PATTERN = "community_create?postId={postId}"
private const val ROUTE_COMMUNITY_DETAIL = "community/{postId}"
private const val ROUTE_MORE = "more"
private const val ROUTE_CATEGORIES = "categories"
private const val ROUTE_SEARCH_BASE = "search"
private const val ROUTE_SEARCH_PATTERN = "search?q={q}&type={type}"
private const val ROUTE_TECHNICIANS = "technicians"
private const val ROUTE_SAVED = "saved"
private const val ROUTE_CATEGORY_DETAIL = "category/{categoryId}"
private const val ROUTE_ERROR_DETAIL = "error/{errorId}"
private const val ROUTE_PROBLEM_DETAIL = "problem/{problemId}"
private const val ROUTE_WIZARD = "wizard/{categoryId}"
private const val ROUTE_SCANNER = "scanner"
private const val ROUTE_REPORT = "report"
private const val ROUTE_VERIFICATION = "verification"
private const val ROUTE_DOCUMENTS_PATTERN = "documents?category={category}"
private const val ROUTE_NOTIFICATIONS = "notifications"
private const val ROUTE_IMAGE_VIEWER_PATTERN = "image_viewer?url={url}&title={title}"
private const val ROUTE_PDF_VIEWER_PATTERN = "pdf_viewer?url={url}&title={title}"
private const val ROUTE_ADMIN = "admin"
private const val ROUTE_AI_ASSISTANT = "ai_assistant"
private const val ROUTE_BILLING = "billing"
private const val ROUTE_BILLING_CREATE_PATTERN = "billing_create?invoiceId={invoiceId}"
private const val ROUTE_BILLING_DETAIL = "billing_detail/{invoiceId}"

private data class TopLevelDestination(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

private fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

class MainActivity : ComponentActivity() {
    private var latestDeepLinkRoute by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.data.remote.ensureFirebaseInitialized(this)
        AdMobManager.initializeSafely(this)
        RepairProMessagingService.ensureChannels(this)
        latestDeepLinkRoute = intent?.getStringExtra(RepairProMessagingService.EXTRA_TARGET_ROUTE).orEmpty()
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            RepairProTheme {
                RepairProAppRoot(initialDeepLinkRoute = latestDeepLinkRoute)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val route = intent.getStringExtra(RepairProMessagingService.EXTRA_TARGET_ROUTE).orEmpty()
        if (route.isNotBlank()) {
            latestDeepLinkRoute = route
        }
    }
}

@Composable
private fun RepairProAppRoot(initialDeepLinkRoute: String = "") {
    val context = LocalContext.current
    val firebaseReady = remember(context) { com.example.data.remote.ensureFirebaseInitialized(context) }
    var selectedPreAuthLanguageCode by rememberSaveable { mutableStateOf(AppLanguage.EN.code) }
    var openAdminAfterLogin by rememberSaveable { mutableStateOf(false) }
    var pendingDeepLink by rememberSaveable { mutableStateOf(initialDeepLinkRoute) }
    LaunchedEffect(initialDeepLinkRoute) {
        if (initialDeepLinkRoute.isNotBlank()) {
            pendingDeepLink = initialDeepLinkRoute
        }
    }
    val preAuthLang = AppLanguage.fromCode(selectedPreAuthLanguageCode)

    if (!firebaseReady) {
        AuthSplashScreen(
            selectedLanguage = preAuthLang,
            onSelectLanguage = { selectedPreAuthLanguageCode = it.code },
            onAuthSuccess = {},
            onAdminPortalRequested = { openAdminAfterLogin = true },
            firebaseConfigured = false
        )
        return
    }

    val authFlow = remember { Firebase.auth.authStateFlow() }
    val currentUser by authFlow.collectAsStateWithLifecycle(
        initialValue = runCatching { Firebase.auth.currentUser }.getOrNull()
    )

    if (currentUser == null) {
        AuthSplashScreen(
            selectedLanguage = preAuthLang,
            onSelectLanguage = { selectedPreAuthLanguageCode = it.code },
            onAuthSuccess = { /* authStateFlow updates automatically */ },
            onAdminPortalRequested = { openAdminAfterLogin = true },
            firebaseConfigured = true
        )
    } else {
        val user = currentUser!!
        key(user.uid) {
            val appContext = LocalContext.current.applicationContext
            val repository = remember(appContext) { RepairRepository(appContext) }
            val viewModel: RepairViewModel = viewModel(
                key = user.uid,
                factory = viewModelFactory {
                    initializer {
                        RepairViewModel(
                            repository = repository,
                            currentUserId = user.uid,
                            userDisplayName = user.displayName ?: "Repair Pro User",
                            userEmail = user.email ?: "",
                            userPhotoUrl = user.photoUrl?.toString().orEmpty(),
                            initialLanguage = preAuthLang
                        )
                    }
                }
            )
            AuthenticatedRepairProShell(
                viewModel = viewModel,
                startInAdminPortal = openAdminAfterLogin,
                onAdminPortalConsumed = { openAdminAfterLogin = false },
                pendingDeepLink = pendingDeepLink,
                onDeepLinkConsumed = { pendingDeepLink = "" }
            )
        }
    }
}

@Composable
private fun AuthenticatedRepairProShell(
    viewModel: RepairViewModel,
    startInAdminPortal: Boolean = false,
    onAdminPortalConsumed: () -> Unit = {},
    pendingDeepLink: String = "",
    onDeepLinkConsumed: () -> Unit = {}
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val language by viewModel.language.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val isBootstrapAdmin by viewModel.isBootstrapAdmin.collectAsStateWithLifecycle()
    val adminRoleChecked by viewModel.adminRoleChecked.collectAsStateWithLifecycle()
    val adConsentGranted by viewModel.adConsentGranted.collectAsStateWithLifecycle()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsStateWithLifecycle()
    val isVerifiedTechnician by viewModel.isVerifiedTechnician.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val uploadProgress by viewModel.uploadProgress.collectAsStateWithLifecycle()

    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val brands by viewModel.brands.collectAsStateWithLifecycle()
    val totalModels by viewModel.totalModelCount.collectAsStateWithLifecycle()
    val errorCodes by viewModel.errorCodes.collectAsStateWithLifecycle()
    val problems by viewModel.problems.collectAsStateWithLifecycle()
    val searchHistory by viewModel.searchHistory.collectAsStateWithLifecycle()
    val savedGuides by viewModel.savedGuides.collectAsStateWithLifecycle()
    val userReports by viewModel.userReports.collectAsStateWithLifecycle()
    val publishedCatalog by viewModel.publishedCloudCatalog.collectAsStateWithLifecycle()
    val adMobConfig by viewModel.adMobConfig.collectAsStateWithLifecycle()
    val globalConfig by viewModel.globalConfig.collectAsStateWithLifecycle()

    // V2.0 user streams
    val myVerificationRequest by viewModel.myVerificationRequest.collectAsStateWithLifecycle()
    val publishedTechnicalDocuments by viewModel.publishedTechnicalDocuments.collectAsStateWithLifecycle()
    val myNotifications by viewModel.myNotifications.collectAsStateWithLifecycle()
    val announcements by viewModel.announcements.collectAsStateWithLifecycle()
    val readAnnouncementIds by viewModel.readAnnouncementIds.collectAsStateWithLifecycle()
    val unreadNotificationCount by viewModel.unreadNotificationCount.collectAsStateWithLifecycle()
    val myCommunityRestriction by viewModel.myCommunityRestriction.collectAsStateWithLifecycle()

    // Admin streams
    val adminAllReports by viewModel.adminAllReports.collectAsStateWithLifecycle()
    val adminAllCatalog by viewModel.adminAllCatalog.collectAsStateWithLifecycle()
    val adminAuditLogs by viewModel.adminAuditLogs.collectAsStateWithLifecycle()
    val adminRoles by viewModel.adminRoles.collectAsStateWithLifecycle()
    val adminVerificationRequests by viewModel.adminVerificationRequests.collectAsStateWithLifecycle()
    val adminTechnicalDocuments by viewModel.adminTechnicalDocuments.collectAsStateWithLifecycle()
    val adminCommunityRestrictions by viewModel.adminCommunityRestrictions.collectAsStateWithLifecycle()
    val activeTechniciansState by viewModel.activeTechniciansState.collectAsStateWithLifecycle()
    val adminAllTechnicians by viewModel.adminAllTechnicians.collectAsStateWithLifecycle()

    // Community streams
    val approvedCommunityPostsState by viewModel.approvedCommunityPostsState.collectAsStateWithLifecycle()
    val myCommunityPosts by viewModel.myCommunityPosts.collectAsStateWithLifecycle()
    val likedCommunityPostIds by viewModel.likedCommunityPostIds.collectAsStateWithLifecycle()
    val savedCommunityPosts by viewModel.savedCommunityPosts.collectAsStateWithLifecycle()
    val communitySubmitting by viewModel.communitySubmitting.collectAsStateWithLifecycle()
    val adminAllCommunityPosts by viewModel.adminAllCommunityPosts.collectAsStateWithLifecycle()
    val adminAllCommunityReports by viewModel.adminAllCommunityReports.collectAsStateWithLifecycle()

    // Phase 2 & Final Release streams
    val aiConfig by viewModel.aiConfig.collectAsStateWithLifecycle()
    val billingConfig by viewModel.billingConfig.collectAsStateWithLifecycle()
    val storageRoutingConfig by viewModel.storageRoutingConfig.collectAsStateWithLifecycle()
    val aiDiagnosisState by viewModel.aiDiagnosisState.collectAsStateWithLifecycle()
    val billingInvoices by viewModel.billingInvoices.collectAsStateWithLifecycle()
    val billingCustomers by viewModel.billingCustomers.collectAsStateWithLifecycle()
    val billingStats by viewModel.billingStats.collectAsStateWithLifecycle()
    val billingSyncing by viewModel.billingSyncing.collectAsStateWithLifecycle()
    val currentUserProfile by viewModel.currentUserProfile.collectAsStateWithLifecycle()
    val isUserBlockedOrSuspended by viewModel.isUserBlockedOrSuspended.collectAsStateWithLifecycle()
    val isCommunityRestricted by viewModel.isCommunityRestricted.collectAsStateWithLifecycle()
    val isUploadRestricted by viewModel.isUploadRestricted.collectAsStateWithLifecycle()
    val cachedOfflinePdfIds by viewModel.cachedOfflinePdfIds.collectAsStateWithLifecycle()
    val downloadingOfflinePdfIds by viewModel.downloadingOfflinePdfIds.collectAsStateWithLifecycle()
    val adminAllUsers by viewModel.adminAllUsers.collectAsStateWithLifecycle()

    LaunchedEffect(viewModel.currentUserId) {
        viewModel.syncFcmToken(context)
    }

    LaunchedEffect(adMobConfig, adConsentGranted) {
        AdMobManager.preloadInterstitialIfEligible(context, adMobConfig, adConsentGranted)
    }

    LaunchedEffect(startInAdminPortal) {
        if (startInAdminPortal) {
            navController.navigate(ROUTE_ADMIN) { launchSingleTop = true }
            onAdminPortalConsumed()
        }
    }

    fun openSafeRoute(rawRoute: String) {
        val route = rawRoute.trim()
        if (route.isBlank()) return
        when {
            route == "home" -> navController.navigate(ROUTE_HOME) { launchSingleTop = true }
            route == "ac" -> navController.navigate(ROUTE_AC) { launchSingleTop = true }
            route == "fridge" -> navController.navigate(ROUTE_FRIDGE) { launchSingleTop = true }
            route == "community" -> navController.navigate("community?tab=0") { launchSingleTop = true }
            route.startsWith("community/") -> navController.navigate(route) { launchSingleTop = true }
            route == "verification" -> navController.navigate(ROUTE_VERIFICATION) { launchSingleTop = true }
            route == "notifications" -> navController.navigate(ROUTE_NOTIFICATIONS) { launchSingleTop = true }
            route == "documents" -> navController.navigate("documents?category=ALL") { launchSingleTop = true }
            route == "technicians" -> navController.navigate(ROUTE_TECHNICIANS) { launchSingleTop = true }
            route == "ai_assistant" -> navController.navigate(ROUTE_AI_ASSISTANT) { launchSingleTop = true }
            route == "billing" -> navController.navigate(ROUTE_BILLING) { launchSingleTop = true }
            else -> navController.navigate(ROUTE_NOTIFICATIONS) { launchSingleTop = true }
        }
    }

    LaunchedEffect(pendingDeepLink) {
        if (pendingDeepLink.isNotBlank()) {
            openSafeRoute(pendingDeepLink)
            onDeepLinkConsumed()
        }
    }

    val strings = StringsProvider.get(language)

    LaunchedEffect(statusBanner) {
        val message = statusBanner
        if (!message.isNullOrBlank()) {
            snackbarHostState.showSnackbar(message)
            viewModel.clearStatusBanner()
        }
    }

    val showCommunityNav = globalConfig.communityEnabled || isAdmin
    val showTechniciansNav = globalConfig.techniciansEnabled || isAdmin
    val showBillingFeature = (billingConfig.invoiceEnabled && globalConfig.billingEnabled) || isAdmin
    val showAiNav = aiConfig.aiEnabled && aiConfig.showAiNavItem

    // V2.0/Phase 2 Bottom Navigation Bar: Home | AC | Fridge | (Community) | (AI if remote-enabled) | More
    val bottomDestinations = remember(strings, showAiNav, showCommunityNav) {
        buildList {
            add(TopLevelDestination(ROUTE_HOME, strings.navHome, Icons.Filled.Home, "nav_home"))
            add(TopLevelDestination(ROUTE_AC, strings.navAc, Icons.Filled.AcUnit, "nav_ac"))
            add(TopLevelDestination(ROUTE_FRIDGE, strings.navFridge, Icons.Filled.Kitchen, "nav_fridge"))
            if (showCommunityNav) {
                add(TopLevelDestination(ROUTE_COMMUNITY_BASE, strings.navCommunity, Icons.Filled.Forum, "nav_community"))
            }
            if (showAiNav) {
                add(TopLevelDestination(ROUTE_AI_ASSISTANT, strings.navAi, Icons.Filled.AutoAwesome, "nav_ai"))
            }
            add(TopLevelDestination(ROUTE_MORE, strings.navMore, Icons.Filled.Menu, "nav_more"))
        }
    }

    val railDestinations = remember(strings, showAiNav, showCommunityNav, showTechniciansNav) {
        buildList {
            add(TopLevelDestination(ROUTE_HOME, strings.navHome, Icons.Filled.Home, "nav_home"))
            add(TopLevelDestination(ROUTE_AC, strings.navAc, Icons.Filled.AcUnit, "nav_ac"))
            add(TopLevelDestination(ROUTE_FRIDGE, strings.navFridge, Icons.Filled.Kitchen, "nav_fridge"))
            if (showCommunityNav) {
                add(TopLevelDestination(ROUTE_COMMUNITY_BASE, strings.navCommunity, Icons.Filled.Forum, "nav_community"))
            }
            if (showAiNav) {
                add(TopLevelDestination(ROUTE_AI_ASSISTANT, strings.navAi, Icons.Filled.AutoAwesome, "nav_ai"))
            }
            if (showTechniciansNav) {
                add(TopLevelDestination(ROUTE_TECHNICIANS, strings.navTechnicians, Icons.Filled.Engineering, "nav_technicians"))
            }
            add(TopLevelDestination(ROUTE_SEARCH_BASE, strings.navSearch, Icons.Filled.Search, "nav_search"))
            add(TopLevelDestination(ROUTE_MORE, strings.navMore, Icons.Filled.Menu, "nav_more"))
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_HOME
    val showTopLevelNav = currentRoute == ROUTE_HOME ||
        currentRoute == ROUTE_AC ||
        currentRoute == ROUTE_FRIDGE ||
        currentRoute.startsWith("community?tab=") ||
        (showAiNav && currentRoute == ROUTE_AI_ASSISTANT) ||
        currentRoute == ROUTE_MORE

    fun navigateTopLevel(route: String) {
        val target = when (route) {
            ROUTE_COMMUNITY_BASE -> "community?tab=0"
            ROUTE_SEARCH_BASE -> "search?q=&type=ALL"
            else -> route
        }
        navController.navigate(target) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun navigateToSearch(query: String = "", filterType: String = "ALL") {
        val encoded = Uri.encode(query)
        navController.navigate("search?q=$encoded&type=$filterType") {
            launchSingleTop = true
        }
    }

    fun openImageViewer(url: String, title: String) {
        if (url.isBlank()) return
        navController.navigate("image_viewer?url=${Uri.encode(url)}&title=${Uri.encode(title)}") {
            launchSingleTop = true
        }
    }

    fun openPdfViewer(url: String, title: String) {
        if (url.isBlank()) return
        navController.navigate("pdf_viewer?url=${Uri.encode(url)}&title=${Uri.encode(title)}") {
            launchSingleTop = true
        }
    }

    fun openExternalUrl(rawUrl: String) {
        val trimmed = rawUrl.trim()
        val safeUrl = if (trimmed.startsWith("https://")) {
            trimmed
        } else {
            "https://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}"
        }
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(safeUrl)))
        } catch (_: Exception) {
            viewModel.showStatusMessage("Unable to open link on this device.")
        }
    }

    fun openLocalOfflinePdf(docId: String, title: String) {
        val file = viewModel.getOfflinePdfFile(docId)
        if (file == null || !file.exists()) {
            viewModel.showStatusMessage("Offline PDF copy not found for $title.")
            return
        }
        try {
            val uri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, title))
        } catch (_: Exception) {
            viewModel.showStatusMessage("Install a PDF viewer app to open offline manual \"$title\".")
        }
    }

    fun openDrawer() {
        scope.launch { drawerState.open() }
    }

    val verifiedTechCount = remember(activeTechniciansState) {
        (activeTechniciansState as? UiState.Success)?.data?.count { V2DomainHelper.isVerifiedTechnicianRecord(it) } ?: 0
    }
    val approvedPostCount = remember(approvedCommunityPostsState) {
        (approvedCommunityPostsState as? UiState.Success)?.data?.size ?: 0
    }

    if (globalConfig.maintenanceMode && !isAdmin) {
        RemoteStatusBlockingScreen(
            testTag = "maintenance_gate_screen",
            icon = Icons.Filled.CloudOff,
            accent = WarningAmber,
            title = "Scheduled Maintenance",
            message = globalConfig.maintenanceNotice.ifBlank {
                "Repair Pro servers are currently undergoing maintenance. Please check back shortly."
            },
            primaryLabel = null,
            onPrimaryClick = null,
            onSignOut = {
                viewModel.prepareForSignOut(context)
                signOutGoogle(credentialManager, scope)
            }
        )
        return
    }

    if (globalConfig.requiresForceUpdate(BuildConfig.VERSION_CODE) && !isAdmin) {
        RemoteStatusBlockingScreen(
            testTag = "force_update_gate_screen",
            icon = Icons.Filled.SystemUpdate,
            accent = CyanAccent,
            title = "Update Required (v${globalConfig.latestVersionName.ifBlank { globalConfig.minSupportedVersion }})",
            message = globalConfig.updateMessage.ifBlank {
                "Please update Repair Pro to the latest version to continue using online services."
            },
            primaryLabel = "Update App",
            onPrimaryClick = { openExternalUrl(globalConfig.updateUrl) },
            onSignOut = {
                viewModel.prepareForSignOut(context)
                signOutGoogle(credentialManager, scope)
            }
        )
        return
    }

    if (isUserBlockedOrSuspended) {
        val statusWord = if (currentUserProfile?.blocked == true ||
            currentUserProfile?.accountStatus.equals("BLOCKED", ignoreCase = true)
        ) "Account Blocked" else "Account Suspended"
        RemoteStatusBlockingScreen(
            testTag = "account_blocked_gate_screen",
            icon = Icons.Filled.Block,
            accent = ErrorCrimson,
            title = statusWord,
            message = currentUserProfile?.moderationReason?.takeIf { it.isNotBlank() }
                ?: "Your account access has been restricted by Repair Pro Super Admin. Contact support if you believe this is an error.",
            primaryLabel = null,
            onPrimaryClick = null,
            onSignOut = {
                viewModel.prepareForSignOut(context)
                signOutGoogle(credentialManager, scope)
            }
        )
        return
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = showTopLevelNav,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DeepCardSurface,
                drawerContentColor = TextPrimaryWhite,
                modifier = Modifier.width(290.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Repair Pro V2.0",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = viewModel.userDisplayName,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyanAccent
                    )
                    if (isVerifiedTechnician) {
                        Surface(
                            color = SuccessGreen.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.45f))
                        ) {
                            Text(
                                text = "Verified Technician",
                                style = MaterialTheme.typography.labelSmall,
                                color = SuccessGreen,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
                HorizontalDivider(color = CardBorderSubtle)
                Spacer(modifier = Modifier.height(6.dp))

                val drawerColors = NavigationDrawerItemDefaults.colors(
                    selectedContainerColor = ElectricBluePrimary.copy(alpha = 0.22f),
                    unselectedContainerColor = Color.Transparent,
                    selectedIconColor = CyanAccent,
                    unselectedIconColor = TextSecondarySlate,
                    selectedTextColor = TextPrimaryWhite,
                    unselectedTextColor = TextPrimaryWhite
                )

                fun drawerGo(action: () -> Unit) {
                    scope.launch { drawerState.close() }
                    action()
                }

                NavigationDrawerItem(
                    label = { Text("Washing Machine Guides") },
                    selected = false,
                    onClick = { drawerGo { navController.navigate("category/washer") } },
                    icon = { Icon(Icons.Filled.LocalLaundryService, contentDescription = null) },
                    colors = drawerColors,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
                if (globalConfig.pdfsEnabled || isAdmin) {
                    NavigationDrawerItem(
                        label = { Text(strings.pdfAndDiagramsTitle) },
                        selected = false,
                        onClick = { drawerGo { navController.navigate("documents?category=ALL") } },
                        icon = { Icon(Icons.Filled.Description, contentDescription = null) },
                        colors = drawerColors,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
                if (globalConfig.techniciansEnabled || isAdmin) {
                    NavigationDrawerItem(
                        label = { Text(strings.findTechnicianTitle) },
                        selected = false,
                        onClick = { drawerGo { navController.navigate(ROUTE_TECHNICIANS) } },
                        icon = { Icon(Icons.Filled.Engineering, contentDescription = null) },
                        colors = drawerColors,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
                if (globalConfig.verificationEnabled || isAdmin) {
                    NavigationDrawerItem(
                        label = { Text(strings.technicianVerificationTitle) },
                        selected = false,
                        onClick = { drawerGo { navController.navigate(ROUTE_VERIFICATION) } },
                        icon = { Icon(Icons.Filled.VerifiedUser, contentDescription = null) },
                        colors = drawerColors,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
                NavigationDrawerItem(
                    label = { Text("${strings.notificationsTitle}${if (unreadNotificationCount > 0) " ($unreadNotificationCount)" else ""}") },
                    selected = false,
                    onClick = { drawerGo { navController.navigate(ROUTE_NOTIFICATIONS) } },
                    icon = { Icon(Icons.Filled.Notifications, contentDescription = null) },
                    colors = drawerColors,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
                NavigationDrawerItem(
                    label = { Text(strings.savedGuides) },
                    selected = false,
                    onClick = { drawerGo { navController.navigate(ROUTE_SAVED) } },
                    icon = { Icon(Icons.Filled.Bookmark, contentDescription = null) },
                    colors = drawerColors,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
                if (globalConfig.scannerEnabled || isAdmin) {
                    NavigationDrawerItem(
                        label = { Text(strings.scanTitle) },
                        selected = false,
                        onClick = { drawerGo { navController.navigate(ROUTE_SCANNER) } },
                        icon = { Icon(Icons.Filled.CameraAlt, contentDescription = null) },
                        colors = drawerColors,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
                NavigationDrawerItem(
                    label = { Text(strings.wizardShortcut) },
                    selected = false,
                    onClick = { drawerGo { navController.navigate("wizard/ac") } },
                    icon = { Icon(Icons.Filled.AutoFixHigh, contentDescription = null) },
                    colors = drawerColors,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
                if (globalConfig.reportsEnabled || isAdmin) {
                    NavigationDrawerItem(
                        label = { Text(strings.reportProblemTitle) },
                        selected = false,
                        onClick = { drawerGo { navController.navigate(ROUTE_REPORT) } },
                        icon = { Icon(Icons.Filled.ReportProblem, contentDescription = null) },
                        colors = drawerColors,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
                if (aiConfig.aiEnabled) {
                    NavigationDrawerItem(
                        label = { Text(strings.aiTitle) },
                        selected = false,
                        onClick = { drawerGo { navController.navigate(ROUTE_AI_ASSISTANT) } },
                        icon = { Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = CyanAccent) },
                        colors = drawerColors,
                        modifier = Modifier.padding(horizontal = 10.dp).testTag("drawer_ai_item")
                    )
                }
                if (showBillingFeature) {
                    NavigationDrawerItem(
                        label = { Text(strings.billingTitle) },
                        selected = false,
                        onClick = { drawerGo { navController.navigate(ROUTE_BILLING) } },
                        icon = { Icon(Icons.Filled.ReceiptLong, contentDescription = null, tint = SuccessGreen) },
                        colors = drawerColors,
                        modifier = Modifier.padding(horizontal = 10.dp).testTag("drawer_billing_item")
                    )
                }
                if (isAdmin) {
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider(color = CardBorderSubtle)
                    Spacer(modifier = Modifier.height(6.dp))
                    NavigationDrawerItem(
                        label = { Text(strings.superAdminPanel, color = CyanAccent, fontWeight = FontWeight.SemiBold) },
                        selected = false,
                        onClick = { drawerGo { navController.navigate(ROUTE_ADMIN) } },
                        icon = { Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = CyanAccent) },
                        colors = drawerColors,
                        modifier = Modifier.padding(horizontal = 10.dp).testTag("drawer_super_admin_item")
                    )
                }
            }
        }
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkScreenGradient)
        ) {
            val useNavRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = {
                    SnackbarHost(hostState = snackbarHostState) { data ->
                        Snackbar(
                            snackbarData = data,
                            containerColor = SecondaryNavySurface,
                            contentColor = TextPrimaryWhite,
                            actionColor = CyanAccent
                        )
                    }
                },
                bottomBar = {
                    if (showTopLevelNav && !useNavRail) {
                        NavigationBar(
                            containerColor = DeepCardSurface,
                            tonalElevation = 0.dp
                        ) {
                            bottomDestinations.forEach { dest ->
                                val selected = currentRoute == dest.route ||
                                    (dest.route == ROUTE_COMMUNITY_BASE && currentRoute.startsWith("community?tab="))
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(dest.route) },
                                    icon = { Icon(dest.icon, contentDescription = dest.label) },
                                    label = { Text(dest.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    modifier = Modifier.testTag(dest.testTag),
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = CyanAccent,
                                        selectedTextColor = CyanAccent,
                                        unselectedIconColor = TextSecondarySlate,
                                        unselectedTextColor = TextSecondarySlate,
                                        indicatorColor = ElectricBluePrimary.copy(alpha = 0.22f)
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (showTopLevelNav && useNavRail) {
                        NavigationRail(
                            containerColor = DeepCardSurface,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            railDestinations.forEach { dest ->
                                val selected = currentRoute == dest.route ||
                                    (dest.route == ROUTE_COMMUNITY_BASE && currentRoute.startsWith("community?tab=")) ||
                                    (dest.route == ROUTE_SEARCH_BASE && currentRoute.startsWith(ROUTE_SEARCH_BASE))
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(dest.route) },
                                    icon = { Icon(dest.icon, contentDescription = dest.label) },
                                    label = { Text(dest.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    modifier = Modifier.testTag(dest.testTag),
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = CyanAccent,
                                        selectedTextColor = CyanAccent,
                                        unselectedIconColor = TextSecondarySlate,
                                        unselectedTextColor = TextSecondarySlate,
                                        indicatorColor = ElectricBluePrimary.copy(alpha = 0.22f)
                                    )
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        NavHost(
                            navController = navController,
                            startDestination = ROUTE_HOME
                        ) {
                            composable(ROUTE_HOME) {
                                HomeDashboardScreen(
                                    language = language,
                                    userName = viewModel.userDisplayName,
                                    userPhotoUrl = viewModel.userPhotoUrl,
                                    unreadNotificationCount = unreadNotificationCount,
                                    categories = categories,
                                    errorCodes = errorCodes,
                                    problems = problems,
                                    verifiedTechnicianCount = verifiedTechCount,
                                    communityPostCount = approvedPostCount,
                                    technicalDocCount = publishedTechnicalDocuments.size,
                                    isOnline = isOnline,
                                    isAdmin = isAdmin,
                                    adMobConfig = adMobConfig,
                                    globalConfig = globalConfig,
                                    adConsentGranted = adConsentGranted,
                                    aiEnabled = aiConfig.aiEnabled,
                                    billingEnabled = showBillingFeature,
                                    onLanguageChange = viewModel::setLanguage,
                                    onRetryConnection = { viewModel.refreshConnectivity() },
                                    onOpenMenu = { openDrawer() },
                                    onOpenNotifications = { navController.navigate(ROUTE_NOTIFICATIONS) },
                                    onOpenProfile = { navigateTopLevel(ROUTE_MORE) },
                                    onOpenSearch = { navigateToSearch("", "ALL") },
                                    onOpenCategory = { catId ->
                                        when (catId) {
                                            "ac" -> navigateTopLevel(ROUTE_AC)
                                            "fridge" -> navigateTopLevel(ROUTE_FRIDGE)
                                            else -> navController.navigate("category/$catId")
                                        }
                                    },
                                    onOpenScanner = { navController.navigate(ROUTE_SCANNER) },
                                    onOpenWizard = { catId -> navController.navigate("wizard/$catId") },
                                    onOpenSaved = { navController.navigate(ROUTE_SAVED) },
                                    onOpenReport = { navController.navigate(ROUTE_REPORT) },
                                    onOpenTechnicians = { navController.navigate(ROUTE_TECHNICIANS) },
                                    onOpenCommunity = { navigateTopLevel(ROUTE_COMMUNITY_BASE) },
                                    onOpenDocuments = { navController.navigate("documents?category=ALL") },
                                    onOpenVerification = { navController.navigate(ROUTE_VERIFICATION) },
                                    onOpenAiAssistant = { navController.navigate(ROUTE_AI_ASSISTANT) },
                                    onOpenBilling = { navController.navigate(ROUTE_BILLING) },
                                    onOpenAdmin = { navController.navigate(ROUTE_ADMIN) },
                                    onOpenUpdateUrl = ::openExternalUrl,
                                    onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                    onOpenProblemDetail = { id -> navController.navigate("problem/$id") }
                                )
                            }

                            composable(ROUTE_AC) {
                                CategoryDetailBrandScreen(
                                    categoryId = "ac",
                                    language = language,
                                    category = categories.firstOrNull { it.id == "ac" },
                                    brands = brands.filter { it.categoryId == "ac" },
                                    errorCodes = errorCodes.filter { it.categoryId == "ac" },
                                    problems = problems.filter { it.categoryId == "ac" },
                                    categoryDocuments = publishedTechnicalDocuments.filter { it.categoryId.equals("ac", ignoreCase = true) },
                                    adMobConfig = adMobConfig,
                                    isOnline = isOnline,
                                    adConsentGranted = adConsentGranted,
                                    showTopHeader = true,
                                    userName = viewModel.userDisplayName,
                                    userPhotoUrl = viewModel.userPhotoUrl,
                                    unreadNotificationCount = unreadNotificationCount,
                                    onRetryConnection = { viewModel.refreshConnectivity() },
                                    onOpenMenu = { openDrawer() },
                                    onOpenNotifications = { navController.navigate(ROUTE_NOTIFICATIONS) },
                                    onOpenProfile = { navigateTopLevel(ROUTE_MORE) },
                                    onBack = { navigateTopLevel(ROUTE_HOME) },
                                    onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                    onOpenProblemDetail = { id -> navController.navigate("problem/$id") },
                                    onOpenWizard = { id -> navController.navigate("wizard/$id") },
                                    onOpenScanner = { navController.navigate(ROUTE_SCANNER) },
                                    onOpenPdfViewer = ::openPdfViewer,
                                    onOpenImageViewer = ::openImageViewer
                                )
                            }

                            composable(ROUTE_FRIDGE) {
                                CategoryDetailBrandScreen(
                                    categoryId = "fridge",
                                    language = language,
                                    category = categories.firstOrNull { it.id == "fridge" },
                                    brands = brands.filter { it.categoryId == "fridge" },
                                    errorCodes = errorCodes.filter { it.categoryId == "fridge" },
                                    problems = problems.filter { it.categoryId == "fridge" },
                                    categoryDocuments = publishedTechnicalDocuments.filter { it.categoryId.equals("fridge", ignoreCase = true) },
                                    adMobConfig = adMobConfig,
                                    isOnline = isOnline,
                                    adConsentGranted = adConsentGranted,
                                    showTopHeader = true,
                                    userName = viewModel.userDisplayName,
                                    userPhotoUrl = viewModel.userPhotoUrl,
                                    unreadNotificationCount = unreadNotificationCount,
                                    onRetryConnection = { viewModel.refreshConnectivity() },
                                    onOpenMenu = { openDrawer() },
                                    onOpenNotifications = { navController.navigate(ROUTE_NOTIFICATIONS) },
                                    onOpenProfile = { navigateTopLevel(ROUTE_MORE) },
                                    onBack = { navigateTopLevel(ROUTE_HOME) },
                                    onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                    onOpenProblemDetail = { id -> navController.navigate("problem/$id") },
                                    onOpenWizard = { id -> navController.navigate("wizard/$id") },
                                    onOpenScanner = { navController.navigate(ROUTE_SCANNER) },
                                    onOpenPdfViewer = ::openPdfViewer,
                                    onOpenImageViewer = ::openImageViewer
                                )
                            }

                            composable(ROUTE_CATEGORIES) {
                                CategoriesDirectoryScreen(
                                    language = language,
                                    categories = categories,
                                    errorCodes = errorCodes,
                                    problems = problems,
                                    onSelectCategory = { catId -> navController.navigate("category/$catId") },
                                    onOpenWizard = { catId -> navController.navigate("wizard/$catId") }
                                )
                            }

                            composable(
                                route = ROUTE_SEARCH_PATTERN,
                                arguments = listOf(
                                    navArgument("q") { type = NavType.StringType; defaultValue = "" },
                                    navArgument("type") { type = NavType.StringType; defaultValue = "ALL" }
                                )
                            ) { entry ->
                                val q = entry.arguments?.getString("q").orEmpty()
                                val filterType = entry.arguments?.getString("type").orEmpty().ifBlank { "ALL" }
                                SmartSearchScreen(
                                    initialQuery = q,
                                    initialFilterType = filterType,
                                    language = language,
                                    errorCodes = errorCodes,
                                    problems = problems,
                                    searchHistory = searchHistory,
                                    adMobConfig = adMobConfig,
                                    isOnline = isOnline,
                                    adConsentGranted = adConsentGranted,
                                    onRetryConnection = { viewModel.refreshConnectivity() },
                                    onBack = { navController.popBackStack() },
                                    onRecordSearch = { term -> viewModel.recordSearch(term) },
                                    onClearHistory = viewModel::clearSearchHistory,
                                    onOpenScanner = { navController.navigate(ROUTE_SCANNER) },
                                    onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                    onOpenProblemDetail = { id -> navController.navigate("problem/$id") }
                                )
                            }

                            composable(ROUTE_TECHNICIANS) {
                                FindTechnicianScreen(
                                    language = language,
                                    techniciansState = activeTechniciansState,
                                    isOnline = isOnline,
                                    onRetry = viewModel::retryLoadTechnicians,
                                    onShowMessage = viewModel::showStatusMessage,
                                    onBack = { navController.popBackStack() },
                                    onApplyVerification = { navController.navigate(ROUTE_VERIFICATION) }
                                )
                            }

                            composable(
                                route = ROUTE_COMMUNITY_PATTERN,
                                arguments = listOf(
                                    navArgument("tab") { type = NavType.IntType; defaultValue = 0 }
                                )
                            ) { entry ->
                                val initialTab = entry.arguments?.getInt("tab") ?: 0
                                CommunityFeedScreen(
                                    language = language,
                                    currentUserUid = viewModel.currentUserId,
                                    userName = viewModel.userDisplayName,
                                    userPhotoUrl = viewModel.userPhotoUrl,
                                    unreadNotificationCount = unreadNotificationCount,
                                    isAdmin = isAdmin,
                                    restriction = myCommunityRestriction,
                                    approvedPostsState = approvedCommunityPostsState,
                                    myPosts = myCommunityPosts,
                                    likedPostIds = likedCommunityPostIds,
                                    savedPosts = savedCommunityPosts,
                                    initialTab = initialTab,
                                    onOpenMenu = { openDrawer() },
                                    onOpenNotifications = { navController.navigate(ROUTE_NOTIFICATIONS) },
                                    onOpenProfile = { navigateTopLevel(ROUTE_MORE) },
                                    onRetry = viewModel::retryLoadCommunity,
                                    onOpenCreatePost = { navController.navigate("community_create?postId=") },
                                    onEditPost = { postId -> navController.navigate("community_create?postId=$postId") },
                                    onOpenPost = { postId -> navController.navigate("community/$postId") },
                                    onOpenImageViewer = ::openImageViewer,
                                    onToggleLike = viewModel::toggleCommunityPostLike,
                                    onToggleBookmark = viewModel::toggleCommunityPostBookmark,
                                    onRemoveSavedPost = { saved ->
                                        viewModel.toggleCommunityPostBookmark(
                                            CommunityPostCloud(
                                                id = saved.postId.ifBlank { saved.id },
                                                postId = saved.postId.ifBlank { saved.id },
                                                title = saved.title,
                                                category = saved.category,
                                                authorName = saved.authorName,
                                                photoUrl = saved.photoUrl
                                            )
                                        )
                                    },
                                    onReportPost = { postId, reason, details, onDone ->
                                        viewModel.reportCommunityPostOrComment(
                                            postId = postId,
                                            commentId = "",
                                            reason = reason,
                                            details = details,
                                            onSuccess = onDone
                                        )
                                    },
                                    onDeletePost = { post -> viewModel.deleteCommunityPost(post) }
                                )
                            }

                            composable(
                                route = ROUTE_COMMUNITY_CREATE_PATTERN,
                                arguments = listOf(
                                    navArgument("postId") { type = NavType.StringType; defaultValue = "" }
                                )
                            ) { entry ->
                                val editPostId = entry.arguments?.getString("postId").orEmpty()
                                val editingPost = remember(editPostId, myCommunityPosts, approvedCommunityPostsState) {
                                    if (editPostId.isBlank()) null
                                    else myCommunityPosts.firstOrNull { it.postId == editPostId || it.id == editPostId }
                                        ?: (approvedCommunityPostsState as? UiState.Success)?.data
                                            ?.firstOrNull { it.postId == editPostId || it.id == editPostId }
                                }
                                CreateCommunityPostScreen(
                                    userName = viewModel.userDisplayName,
                                    userPhotoUrl = viewModel.userPhotoUrl,
                                    isVerifiedTechnician = isVerifiedTechnician,
                                    isAdmin = isAdmin,
                                    isBlocked = (myCommunityRestriction != null) || isCommunityRestricted,
                                    blockedReason = myCommunityRestriction?.reason?.takeIf { it.isNotBlank() }
                                        ?: currentUserProfile?.moderationReason.orEmpty(),
                                    isUploadRestricted = isUploadRestricted,
                                    uploadBlockedReason = currentUserProfile?.moderationReason.orEmpty(),
                                    editingPost = editingPost,
                                    submitting = communitySubmitting,
                                    uploadProgress = uploadProgress,
                                    compressionMaxDim = storageRoutingConfig.compressionMaxDim,
                                    compressionQuality = storageRoutingConfig.compressionQuality,
                                    compressionMaxSizeKb = storageRoutingConfig.compressionMaxSizeKb,
                                    duplicateCheckEnabled = storageRoutingConfig.duplicateCheckEnabled,
                                    onBack = { navController.popBackStack() },
                                    onSubmitNew = { cat, brand, model, code, title, body, photos ->
                                        viewModel.createCommunityPost(
                                            category = cat,
                                            brandName = brand,
                                            modelName = model,
                                            errorCode = code,
                                            title = title,
                                            body = body,
                                            photos = photos,
                                            onSuccess = { navController.popBackStack() }
                                        )
                                    },
                                    onSubmitEdit = { pid, cat, brand, model, code, title, body, oldUrls, oldPaths, newPhotos ->
                                        viewModel.updateCommunityPost(
                                            postId = pid,
                                            category = cat,
                                            brandName = brand,
                                            modelName = model,
                                            errorCode = code,
                                            title = title,
                                            body = body,
                                            existingPhotoUrls = oldUrls,
                                            existingStoragePaths = oldPaths,
                                            newPhotos = newPhotos,
                                            onSuccess = { navController.popBackStack() }
                                        )
                                    }
                                )
                            }

                            composable(
                                route = ROUTE_COMMUNITY_DETAIL,
                                arguments = listOf(navArgument("postId") { type = NavType.StringType })
                            ) { entry ->
                                val postId = entry.arguments?.getString("postId").orEmpty()
                                val postFlow = remember(postId) { viewModel.observeCommunityPost(postId) }
                                val commentsFlow = remember(postId) { viewModel.observeCommunityComments(postId) }
                                val post by postFlow.collectAsStateWithLifecycle(initialValue = null)
                                val comments by commentsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
                                val isLiked = likedCommunityPostIds.contains(postId)
                                val isBookmarked = savedCommunityPosts.any { it.postId == postId || it.id == postId }
                                CommunityPostDetailScreen(
                                    post = post,
                                    comments = comments,
                                    currentUserUid = viewModel.currentUserId,
                                    isAdmin = isAdmin,
                                    restriction = myCommunityRestriction,
                                    isLiked = isLiked,
                                    isBookmarked = isBookmarked,
                                    onBack = { navController.popBackStack() },
                                    onEditPost = { pid -> navController.navigate("community_create?postId=$pid") },
                                    onOpenImageViewer = ::openImageViewer,
                                    onToggleLike = { viewModel.toggleCommunityPostLike(postId) },
                                    onToggleBookmark = {
                                        post?.let { viewModel.toggleCommunityPostBookmark(it) }
                                    },
                                    onAddComment = { body, parentId, replyTo, postAuthorUid, replyTargetUid, onDone ->
                                        viewModel.addCommunityComment(
                                            postId = postId,
                                            body = body,
                                            parentCommentId = parentId,
                                            replyToAuthorName = replyTo,
                                            postAuthorUid = postAuthorUid,
                                            replyTargetUid = replyTargetUid,
                                            onSuccess = onDone
                                        )
                                    },
                                    onEditComment = { commentId, newBody, onDone ->
                                        viewModel.editCommunityComment(postId, commentId, newBody, onDone)
                                    },
                                    onDeleteComment = { commentId ->
                                        viewModel.deleteCommunityComment(postId, commentId)
                                    },
                                    onReport = { commentId, reason, details, onDone ->
                                        viewModel.reportCommunityPostOrComment(
                                            postId = postId,
                                            commentId = commentId,
                                            reason = reason,
                                            details = details,
                                            onSuccess = onDone
                                        )
                                    },
                                    onDeletePost = { onDeleted ->
                                        post?.let { viewModel.deleteCommunityPost(it, onDeleted) }
                                    }
                                )
                            }

                            composable(ROUTE_SAVED) {
                                SavedGuidesScreen(
                                    language = language,
                                    savedGuides = savedGuides,
                                    onBack = { navController.popBackStack() },
                                    onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                    onOpenProblemDetail = { id -> navController.navigate("problem/$id") },
                                    onRemoveGuide = { guide ->
                                        viewModel.toggleSavedGuide(
                                            itemType = guide.itemType,
                                            itemId = guide.itemId,
                                            categoryId = guide.categoryId,
                                            title = guide.title,
                                            subtitle = guide.subtitle
                                        )
                                    }
                                )
                            }

                            composable(ROUTE_MORE) {
                                SettingsScreen(
                                    language = language,
                                    userDisplayName = viewModel.userDisplayName,
                                    userEmail = viewModel.userEmail,
                                    userPhotoUrl = viewModel.userPhotoUrl,
                                    isVerifiedTechnician = isVerifiedTechnician,
                                    verificationStatus = myVerificationRequest?.status.orEmpty(),
                                    unreadNotificationCount = unreadNotificationCount,
                                    isAdmin = isAdmin,
                                    adConsentGranted = adConsentGranted,
                                    aiEnabled = aiConfig.aiEnabled,
                                    billingEnabled = showBillingFeature,
                                    onOpenMenu = { openDrawer() },
                                    onSelectLanguage = viewModel::setLanguage,
                                    onToggleAdConsent = viewModel::setAdConsent,
                                    onOpenVerification = { navController.navigate(ROUTE_VERIFICATION) },
                                    onOpenNotifications = { navController.navigate(ROUTE_NOTIFICATIONS) },
                                    onOpenWasherGuides = { navController.navigate("category/washer") },
                                    onOpenDocuments = { navController.navigate("documents?category=ALL") },
                                    onOpenTechnicians = { navController.navigate(ROUTE_TECHNICIANS) },
                                    onOpenSavedGuides = { navController.navigate(ROUTE_SAVED) },
                                    onOpenMyPosts = { navController.navigate("community?tab=1") },
                                    onOpenWizard = { navController.navigate("wizard/ac") },
                                    onOpenReportProblem = { navController.navigate(ROUTE_REPORT) },
                                    onOpenAiAssistant = { navController.navigate(ROUTE_AI_ASSISTANT) },
                                    onOpenBilling = { navController.navigate(ROUTE_BILLING) },
                                    onOpenAdminConsole = { navController.navigate(ROUTE_ADMIN) },
                                    onDeleteCloudData = {
                                        viewModel.prepareForSignOut(context)
                                        viewModel.deleteMyCloudData {
                                            signOutGoogle(credentialManager, scope)
                                        }
                                    },
                                    onSignOut = {
                                        viewModel.prepareForSignOut(context)
                                        signOutGoogle(credentialManager, scope)
                                    }
                                )
                            }

                            composable(
                                route = ROUTE_CATEGORY_DETAIL,
                                arguments = listOf(navArgument("categoryId") { type = NavType.StringType })
                            ) { entry ->
                                val categoryId = entry.arguments?.getString("categoryId") ?: "ac"
                                CategoryDetailBrandScreen(
                                    categoryId = categoryId,
                                    language = language,
                                    category = categories.firstOrNull { it.id == categoryId },
                                    brands = brands.filter { it.categoryId == categoryId },
                                    errorCodes = errorCodes.filter { it.categoryId == categoryId },
                                    problems = problems.filter { it.categoryId == categoryId },
                                    categoryDocuments = publishedTechnicalDocuments.filter {
                                        it.categoryId.equals(categoryId, ignoreCase = true)
                                    },
                                    adMobConfig = adMobConfig,
                                    isOnline = isOnline,
                                    adConsentGranted = adConsentGranted,
                                    showTopHeader = false,
                                    onRetryConnection = { viewModel.refreshConnectivity() },
                                    onBack = { navController.popBackStack() },
                                    onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                    onOpenProblemDetail = { id -> navController.navigate("problem/$id") },
                                    onOpenWizard = { id -> navController.navigate("wizard/$id") },
                                    onOpenScanner = { navController.navigate(ROUTE_SCANNER) },
                                    onOpenPdfViewer = ::openPdfViewer,
                                    onOpenImageViewer = ::openImageViewer
                                )
                            }

                            composable(
                                route = ROUTE_ERROR_DETAIL,
                                arguments = listOf(navArgument("errorId") { type = NavType.StringType })
                            ) { entry ->
                                val errorId = entry.arguments?.getString("errorId").orEmpty()
                                val item = errorCodes.firstOrNull { it.id == errorId }
                                val isSaved = savedGuides.any { it.itemType == "ERROR_CODE" && it.itemId == errorId }
                                val cloudEntry = remember(errorId, item, publishedCatalog) {
                                    publishedCatalog.firstOrNull {
                                        it.id == errorId || (item != null && it.entryType == "ERROR_CODE" && it.code.equals(item.code, ignoreCase = true) && it.brandName.equals(item.brandName, ignoreCase = true))
                                    }
                                }
                                val relatedDocs = remember(errorId, item, publishedTechnicalDocuments) {
                                    publishedTechnicalDocuments.filter { doc ->
                                        doc.linkedEntryId == errorId ||
                                            (item != null && doc.categoryId.equals(item.categoryId, ignoreCase = true) &&
                                                (doc.brandName.isBlank() || doc.brandName.equals(item.brandName, ignoreCase = true)))
                                    }.take(6)
                                }
                                LaunchedEffect(errorId) {
                                    AdMobManager.maybeShowInterstitial(activity, adMobConfig, item?.categoryId, adConsentGranted)
                                }
                                ErrorCodeDetailScreen(
                                    errorCode = item,
                                    language = language,
                                    isSaved = isSaved,
                                    isOnline = isOnline,
                                    cloudEntry = cloudEntry,
                                    relatedDocuments = relatedDocs,
                                    onRetryConnection = { viewModel.refreshConnectivity() },
                                    onOpenImageViewer = ::openImageViewer,
                                    onOpenPdfViewer = ::openPdfViewer,
                                    onBack = { navController.popBackStack() },
                                    onToggleSave = {
                                        if (item != null) {
                                            val title = resolveLocalizedText(language, item.titleEn, item.titleBn, item.titleHi).text
                                            viewModel.toggleSavedGuide(
                                                itemType = "ERROR_CODE",
                                                itemId = item.id,
                                                categoryId = item.categoryId,
                                                title = "${item.brandName} ${item.code} — $title",
                                                subtitle = item.modelSeries
                                            )
                                        }
                                    }
                                )
                            }

                            composable(
                                route = ROUTE_PROBLEM_DETAIL,
                                arguments = listOf(navArgument("problemId") { type = NavType.StringType })
                            ) { entry ->
                                val problemId = entry.arguments?.getString("problemId").orEmpty()
                                val item = problems.firstOrNull { it.id == problemId }
                                val isSaved = savedGuides.any { it.itemType == "PROBLEM" && it.itemId == problemId }
                                val cloudEntry = remember(problemId, publishedCatalog) {
                                    publishedCatalog.firstOrNull { it.id == problemId }
                                }
                                val relatedDocs = remember(problemId, item, publishedTechnicalDocuments) {
                                    publishedTechnicalDocuments.filter { doc ->
                                        doc.linkedEntryId == problemId ||
                                            (item != null && doc.categoryId.equals(item.categoryId, ignoreCase = true))
                                    }.take(6)
                                }
                                LaunchedEffect(problemId) {
                                    AdMobManager.maybeShowInterstitial(activity, adMobConfig, item?.categoryId, adConsentGranted)
                                }
                                ProblemDetailScreen(
                                    problem = item,
                                    language = language,
                                    isSaved = isSaved,
                                    isOnline = isOnline,
                                    cloudEntry = cloudEntry,
                                    relatedDocuments = relatedDocs,
                                    onRetryConnection = { viewModel.refreshConnectivity() },
                                    onOpenImageViewer = ::openImageViewer,
                                    onOpenPdfViewer = ::openPdfViewer,
                                    onBack = { navController.popBackStack() },
                                    onToggleSave = {
                                        if (item != null) {
                                            val title = resolveLocalizedText(language, item.titleEn, item.titleBn, item.titleHi).text
                                            val sym = resolveLocalizedText(language, item.symptomsEn, item.symptomsBn, item.symptomsHi).text
                                            viewModel.toggleSavedGuide(
                                                itemType = "PROBLEM",
                                                itemId = item.id,
                                                categoryId = item.categoryId,
                                                title = title,
                                                subtitle = sym.lineSequence().firstOrNull().orEmpty()
                                            )
                                        }
                                    },
                                    onSearchRelatedCode = { code -> navigateToSearch(code, "ERROR") }
                                )
                            }

                            composable(
                                route = ROUTE_WIZARD,
                                arguments = listOf(navArgument("categoryId") { type = NavType.StringType })
                            ) { entry ->
                                val categoryId = entry.arguments?.getString("categoryId") ?: "ac"
                                TroubleshootingWizardScreen(
                                    initialCategoryId = categoryId,
                                    language = language,
                                    onBack = { navController.popBackStack() },
                                    onOpenProblemDetail = { id -> navController.navigate("problem/$id") },
                                    onOpenErrorDetail = { id -> navController.navigate("error/$id") }
                                )
                            }

                            composable(ROUTE_SCANNER) {
                                CameraScannerScreen(
                                    language = language,
                                    allErrorCodes = errorCodes,
                                    onBack = { navController.popBackStack() },
                                    onOpenErrorDetail = { id -> navController.navigate("error/$id") },
                                    onManualSearchFallback = { q -> navigateToSearch(q, "ALL") }
                                )
                            }

                            composable(ROUTE_REPORT) {
                                ReportProblemScreen(
                                    language = language,
                                    myReports = userReports,
                                    onBack = { navController.popBackStack() },
                                    onSubmitReport = viewModel::submitProblemReport
                                )
                            }

                            composable(ROUTE_VERIFICATION) {
                                TechnicianVerificationScreen(
                                    strings = strings,
                                    defaultName = viewModel.userDisplayName,
                                    existingRequest = myVerificationRequest,
                                    submitting = communitySubmitting,
                                    uploadProgress = uploadProgress,
                                    isUploadRestricted = isUploadRestricted,
                                    uploadBlockedReason = currentUserProfile?.moderationReason.orEmpty(),
                                    onBack = { navController.popBackStack() },
                                    onSubmit = { draft, avatarBytes, avatarMime, credBytes, credMime, credName ->
                                        viewModel.submitTechnicianVerification(
                                            draft = draft,
                                            profilePhotoBytes = avatarBytes,
                                            profilePhotoMime = avatarMime,
                                            credentialBytes = credBytes,
                                            credentialMime = credMime,
                                            credentialFileName = credName
                                        )
                                    }
                                )
                            }

                            composable(
                                route = ROUTE_DOCUMENTS_PATTERN,
                                arguments = listOf(
                                    navArgument("category") { type = NavType.StringType; defaultValue = "ALL" }
                                )
                            ) { entry ->
                                val initialCat = entry.arguments?.getString("category").orEmpty().ifBlank { "ALL" }
                                TechnicalDocumentsLibraryScreen(
                                    strings = strings,
                                    documents = publishedTechnicalDocuments,
                                    isOnline = isOnline,
                                    initialCategory = initialCat,
                                    cachedPdfIds = cachedOfflinePdfIds,
                                    downloadingPdfIds = downloadingOfflinePdfIds,
                                    onDownloadOffline = viewModel::downloadOfflinePdf,
                                    onRemoveOffline = viewModel::removeOfflinePdf,
                                    onOpenOfflinePdf = ::openLocalOfflinePdf,
                                    onRetryConnectivity = { viewModel.refreshConnectivity() },
                                    onOpenPdf = ::openPdfViewer,
                                    onOpenImage = ::openImageViewer,
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(ROUTE_NOTIFICATIONS) {
                                NotificationsScreen(
                                    strings = strings,
                                    userNotifications = myNotifications,
                                    announcements = announcements,
                                    readAnnouncementIds = readAnnouncementIds,
                                    notificationsEnabled = notificationsEnabled,
                                    onToggleNotifications = viewModel::setNotificationsEnabled,
                                    onMarkNotificationRead = viewModel::markNotificationRead,
                                    onMarkAnnouncementRead = viewModel::markAnnouncementRead,
                                    onNavigateRoute = ::openSafeRoute,
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(
                                route = ROUTE_IMAGE_VIEWER_PATTERN,
                                arguments = listOf(
                                    navArgument("url") { type = NavType.StringType; defaultValue = "" },
                                    navArgument("title") { type = NavType.StringType; defaultValue = "" }
                                )
                            ) { entry ->
                                ZoomableImageViewerScreen(
                                    imageUrl = Uri.decode(entry.arguments?.getString("url").orEmpty()),
                                    title = Uri.decode(entry.arguments?.getString("title").orEmpty()),
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(
                                route = ROUTE_PDF_VIEWER_PATTERN,
                                arguments = listOf(
                                    navArgument("url") { type = NavType.StringType; defaultValue = "" },
                                    navArgument("title") { type = NavType.StringType; defaultValue = "" }
                                )
                            ) { entry ->
                                OnlinePdfViewerScreen(
                                    pdfUrl = Uri.decode(entry.arguments?.getString("url").orEmpty()),
                                    title = Uri.decode(entry.arguments?.getString("title").orEmpty()),
                                    isOnline = isOnline,
                                    onRetryConnectivity = { viewModel.refreshConnectivity() },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(ROUTE_ADMIN) {
                                SuperAdminScreen(
                                    isAdmin = isAdmin,
                                    isBootstrapAdmin = isBootstrapAdmin,
                                    adminRoleChecked = adminRoleChecked,
                                    currentUserUid = viewModel.currentUserId,
                                    adminEmail = viewModel.userEmail,
                                    categories = categories,
                                    brands = brands,
                                    totalModels = totalModels,
                                    errorCodes = errorCodes,
                                    problems = problems,
                                    allReports = adminAllReports,
                                    allCatalog = adminAllCatalog,
                                    auditLogs = adminAuditLogs,
                                    adminRoles = adminRoles,
                                    adMobConfig = adMobConfig,
                                    globalConfig = globalConfig,
                                    isSubmittingMedia = communitySubmitting,
                                    uploadProgress = uploadProgress,
                                    onBack = { navController.popBackStack() },
                                    onUpdateReportStatus = viewModel::adminUpdateReportStatus,
                                    onPublishCatalogEntry = viewModel::adminPublishCatalogEntry,
                                    onUploadCatalogMedia = viewModel::adminUploadCatalogMedia,
                                    onDeleteCatalogEntry = viewModel::adminDeleteCatalogEntry,
                                    onSaveAdMobConfig = viewModel::adminSaveAdMobConfig,
                                    onSaveGlobalConfig = viewModel::adminSaveGlobalConfig,
                                    onUpsertAdminRole = viewModel::adminUpsertRole,
                                    onRevokeAdminRole = viewModel::adminRevokeRole,
                                    onExportBackupJson = viewModel::exportCatalogBackupJson,
                                    allTechnicians = adminAllTechnicians,
                                    onSaveTechnician = viewModel::adminSaveTechnician,
                                    onToggleTechnicianStatus = viewModel::adminToggleTechnicianStatus,
                                    onDeleteTechnician = viewModel::adminDeleteTechnician,
                                    allCommunityPosts = adminAllCommunityPosts,
                                    allCommunityReports = adminAllCommunityReports,
                                    communityRestrictions = adminCommunityRestrictions,
                                    onModerateCommunityPost = viewModel::adminModerateCommunityPost,
                                    onTogglePinCommunityPost = viewModel::adminTogglePinCommunityPost,
                                    onSetCommunityUserBlocked = viewModel::adminSetCommunityUserBlocked,
                                    onDeleteCommunityPost = { post -> viewModel.deleteCommunityPost(post) },
                                    onUpdateCommunityReportStatus = viewModel::adminUpdateCommunityReportStatus,
                                    verificationRequests = adminVerificationRequests,
                                    onReviewVerification = viewModel::adminReviewVerification,
                                    technicalDocuments = adminTechnicalDocuments,
                                    onUploadTechnicalDocument = viewModel::adminUploadTechnicalDocument,
                                    onDeleteTechnicalDocument = viewModel::adminDeleteTechnicalDocument,
                                    announcements = announcements,
                                    onPublishAnnouncement = viewModel::adminPublishAnnouncement,
                                    onDispatchPushNotification = viewModel::adminDispatchPushNotification,
                                    onDeleteAnnouncement = viewModel::adminDeleteAnnouncement,
                                    onOpenImageViewer = ::openImageViewer,
                                    onOpenPdfViewer = ::openPdfViewer,
                                    allUsers = adminAllUsers,
                                    onSaveGlobalConfigFull = viewModel::adminSaveGlobalConfig,
                                    onModerateUser = viewModel::adminModerateUser,
                                    onDeleteUserAccount = viewModel::adminDeleteUserAccount,
                                    onSyncMyClaims = viewModel::adminSyncMyClaims,
                                    onSuspendTechnician = viewModel::adminSuspendTechnician,
                                    onSoftDeleteTechnician = viewModel::adminSoftDeleteTechnician,
                                    onRemoveTechnicianPhoto = viewModel::adminRemoveTechnicianPhoto,
                                    onToggleHiddenCommunityPost = viewModel::adminSetCommunityPostHidden,
                                    onSoftDeleteCommunityPost = viewModel::adminSoftDeleteCommunityPost,
                                    onRestoreCommunityPost = viewModel::adminRestoreCommunityPost,
                                    onEditCommunityPost = viewModel::adminEditCommunityPost,
                                    onRemoveCommunityPhoto = viewModel::adminRemoveCommunityPhoto,
                                    onResolvePrivateVerificationUrl = viewModel::resolvePrivateVerificationUrl,
                                    onSetDocOfflineAvailable = viewModel::adminSetDocOfflineAvailable,
                                    onReplaceTechnicalDocumentFile = viewModel::adminReplaceTechnicalDocumentFile,
                                    onSoftDeleteTechnicalDocument = viewModel::adminSoftDeleteTechnicalDocument,
                                    onRestoreTechnicalDocument = viewModel::adminRestoreTechnicalDocument
                                )
                            }

                            composable(ROUTE_AI_ASSISTANT) {
                                AiRepairAssistantScreen(
                                    language = language,
                                    aiConfig = aiConfig,
                                    isOnline = isOnline,
                                    diagnosisState = aiDiagnosisState,
                                    onRetryConnection = { viewModel.refreshConnectivity() },
                                    onSubmitDiagnosis = viewModel::submitAiDiagnosis,
                                    onClearResult = viewModel::clearAiDiagnosis,
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(ROUTE_BILLING) {
                                BillingDashboardScreen(
                                    language = language,
                                    billingConfig = billingConfig,
                                    invoices = billingInvoices,
                                    customers = billingCustomers,
                                    stats = billingStats,
                                    isOnline = isOnline,
                                    syncing = billingSyncing,
                                    onBack = { navController.popBackStack() },
                                    onCreateInvoice = { navController.navigate("billing_create?invoiceId=") },
                                    onOpenInvoiceDetail = { id -> navController.navigate("billing_detail/$id") },
                                    onTriggerSync = viewModel::triggerBillingSync
                                )
                            }

                            composable(
                                route = ROUTE_BILLING_CREATE_PATTERN,
                                arguments = listOf(navArgument("invoiceId") { type = NavType.StringType; defaultValue = "" })
                            ) { entry ->
                                val editId = entry.arguments?.getString("invoiceId").orEmpty()
                                val existing = remember(editId, billingInvoices) {
                                    if (editId.isBlank()) null else billingInvoices.firstOrNull { it.invoiceId == editId }
                                }
                                InvoiceEditorScreen(
                                    existingInvoice = existing,
                                    onBack = { navController.popBackStack() },
                                    onSave = { exId, custId, name, mobile, addr, cat, brand, model, serial, prob, work, parts, qty, pChg, sChg, vChg, oChg, disc, rec, method, due, warr, notes, remDate ->
                                        viewModel.saveBillingInvoice(
                                            existingInvoiceId = exId,
                                            customerId = custId,
                                            customerName = name,
                                            customerMobile = mobile,
                                            customerAddress = addr,
                                            applianceCategory = cat,
                                            applianceBrand = brand,
                                            modelNumber = model,
                                            serialNumber = serial,
                                            reportedProblem = prob,
                                            workDone = work,
                                            partsUsed = parts,
                                            partsQuantity = qty,
                                            partsCharges = pChg,
                                            serviceCharges = sChg,
                                            visitingCharges = vChg,
                                            otherCharges = oChg,
                                            discountAmount = disc,
                                            amountReceived = rec,
                                            paymentMethod = method,
                                            paymentDueDate = due,
                                            warrantyInfo = warr,
                                            notes = notes,
                                            reminderDate = remDate,
                                            onSaved = { savedId ->
                                                navController.popBackStack()
                                                navController.navigate("billing_detail/$savedId") { launchSingleTop = true }
                                            }
                                        )
                                    }
                                )
                            }

                            composable(
                                route = ROUTE_BILLING_DETAIL,
                                arguments = listOf(navArgument("invoiceId") { type = NavType.StringType })
                            ) { entry ->
                                val invoiceId = entry.arguments?.getString("invoiceId").orEmpty()
                                val invoice = remember(invoiceId, billingInvoices) {
                                    billingInvoices.firstOrNull { it.invoiceId == invoiceId }
                                }
                                val payFlow = remember(invoiceId) { viewModel.observeInvoicePayments(invoiceId) }
                                val payments by payFlow.collectAsStateWithLifecycle(initialValue = emptyList())
                                InvoiceDetailScreen(
                                    language = language,
                                    invoice = invoice,
                                    payments = payments,
                                    billingConfig = billingConfig,
                                    onBack = { navController.popBackStack() },
                                    onEdit = { id -> navController.navigate("billing_create?invoiceId=$id") },
                                    onRecordPayment = { amt, method, note, key ->
                                        viewModel.recordInvoicePayment(invoiceId, amt, method, note, key)
                                    },
                                    onDeleteInvoice = { id ->
                                        viewModel.deleteBillingInvoice(id) { navController.popBackStack() }
                                    },
                                    onShowMessage = viewModel::showStatusMessage
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RemoteStatusBlockingScreen(
    testTag: String,
    icon: ImageVector,
    accent: Color,
    title: String,
    message: String,
    primaryLabel: String?,
    onPrimaryClick: (() -> Unit)?,
    onSignOut: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkScreenGradient)
            .padding(24.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ElevatedCardSurface,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, accent.copy(alpha = 0.55f))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(52.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondarySlate
                )
                if (!primaryLabel.isNullOrBlank() && onPrimaryClick != null) {
                    Button(
                        onClick = onPrimaryClick,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("${testTag}_primary")
                    ) {
                        Text(primaryLabel, fontWeight = FontWeight.Bold)
                    }
                }
                OutlinedButton(
                    onClick = onSignOut,
                    border = BorderStroke(1.dp, CardBorderSubtle),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("${testTag}_signout")
                ) {
                    Text("Sign Out", color = TextPrimaryWhite)
                }
            }
        }
    }
}
