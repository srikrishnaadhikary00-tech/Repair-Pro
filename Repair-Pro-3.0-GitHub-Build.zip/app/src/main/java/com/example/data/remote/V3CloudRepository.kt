package com.example.data.remote

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Repair Pro v3.0 — Cloud data operations for Community, Technicians, Repair PDFs/Diagrams,
 * Push Notifications, Multi-Cloud Storage Manager, and User Management.
 * Uses named Firestore database (R.string.firestore_database_id) AND coordinates with SupabaseApiClient
 * for Multi-Cloud file uploads and FCM HTTP v1 delivery.
 */
class V3CloudRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUid(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Google Sign-In required.")

    // ---------------- COMMUNITY SYSTEM ----------------
    fun observeApprovedCommunityPosts(uid: String): Flow<List<CommunityPostItem>> = flow {
        emitAll(
            db.collection("community_posts")
                .whereEqualTo("moderationStatus", "APPROVED")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CommunityPostItem::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "community_posts", uid); throw e }
        )
    }

    fun observeAllCommunityPostsForAdmin(uid: String): Flow<List<CommunityPostItem>> = flow {
        emitAll(
            db.collection("community_posts")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CommunityPostItem::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "community_posts", uid); throw e }
        )
    }

    fun observeComments(postId: String, uid: String): Flow<List<CommunityCommentItem>> = flow {
        emitAll(
            db.collection("community_posts").document(postId).collection("comments")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CommunityCommentItem::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt?.seconds ?: 0L }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "community_posts/$postId/comments", uid); throw e }
        )
    }

    suspend fun createCommunityPost(
        authorName: String,
        categoryId: String,
        title: String,
        body: String,
        photoUrls: List<String>,
        verifiedTechnician: Boolean
    ): Result<Unit> = runFirestoreWrite("community_posts") { uid ->
        val postId = CloudRepository.sanitizeId("post_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val payload = mapOf(
            "authorUid" to uid,
            "authorName" to authorName.trim().ifBlank { "Repair Pro Member" }.take(80),
            "categoryId" to categoryId.take(64),
            "title" to title.trim().take(160),
            "body" to body.trim().take(2000),
            "photoUrls" to photoUrls.take(5),
            "moderationStatus" to "APPROVED",
            "rejectionReason" to "",
            "verifiedTechnician" to verifiedTechnician,
            "likesCount" to 0L,
            "commentsCount" to 0L,
            "likedByUids" to emptyList<String>(),
            "savedByUids" to emptyList<String>(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        db.collection("community_posts").document(postId).set(payload).await()
    }

    suspend fun editCommunityPost(postId: String, title: String, body: String): Result<Unit> =
        runFirestoreWrite("community_posts/$postId") {
            db.collection("community_posts").document(postId).update(
                mapOf(
                    "title" to title.trim().take(160),
                    "body" to body.trim().take(2000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun deleteCommunityPost(postId: String): Result<Unit> =
        runFirestoreWrite("community_posts/$postId") {
            db.collection("community_posts").document(postId).delete().await()
        }

    suspend fun toggleLikePost(post: CommunityPostItem): Result<Unit> =
        runFirestoreWrite("community_posts/${post.id}") { uid ->
            val alreadyLiked = post.likedByUids.contains(uid)
            val updatedList = if (alreadyLiked) post.likedByUids - uid else post.likedByUids + uid
            db.collection("community_posts").document(post.id).update(
                mapOf(
                    "likedByUids" to updatedList,
                    "likesCount" to updatedList.size.toLong(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun toggleSavePost(post: CommunityPostItem): Result<Unit> =
        runFirestoreWrite("community_posts/${post.id}") { uid ->
            val alreadySaved = post.savedByUids.contains(uid)
            val updatedList = if (alreadySaved) post.savedByUids - uid else post.savedByUids + uid
            db.collection("community_posts").document(post.id).update(
                mapOf(
                    "savedByUids" to updatedList,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun addComment(
        postId: String,
        parentCommentId: String,
        authorName: String,
        verifiedTechnician: Boolean,
        body: String
    ): Result<Unit> = runFirestoreWrite("community_posts/$postId/comments") { uid ->
        val commentId = CloudRepository.sanitizeId("cmt_${UUID.randomUUID().toString().replace("-", "").take(14)}")
        db.collection("community_posts").document(postId).collection("comments").document(commentId).set(
            mapOf(
                "postId" to postId,
                "parentCommentId" to parentCommentId,
                "authorUid" to uid,
                "authorName" to authorName.trim().ifBlank { "Repair Pro Member" }.take(80),
                "verifiedTechnician" to verifiedTechnician,
                "body" to body.trim().take(1000),
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        db.collection("community_posts").document(postId).update(
            mapOf(
                "commentsCount" to FieldValue.increment(1L),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun reportCommunityPost(postId: String, reason: String): Result<Unit> =
        runFirestoreWrite("community_reports") { uid ->
            val repId = CloudRepository.sanitizeId("crep_${UUID.randomUUID().toString().replace("-", "").take(14)}")
            db.collection("community_reports").document(repId).set(
                mapOf(
                    "postId" to postId,
                    "reporterUid" to uid,
                    "reason" to reason.trim().take(400),
                    "status" to "OPEN",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun adminModeratePost(postId: String, status: String, reason: String = ""): Result<Unit> =
        runFirestoreWrite("community_posts/$postId") { uid ->
            db.collection("community_posts").document(postId).update(
                mapOf(
                    "moderationStatus" to status,
                    "rejectionReason" to reason.trim().take(300),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            logAudit(uid, "MODERATE_POST", "community_posts", postId, "Status=$status")
        }

    // ---------------- TECHNICIAN DIRECTORY & VERIFICATION ----------------
    fun observePublicTechnicians(uid: String): Flow<List<TechnicianProfileItem>> = flow {
        emitAll(
            db.collection("technicians")
                .whereEqualTo("approvalStatus", "APPROVED")
                .whereEqualTo("active", true)
                .whereEqualTo("blocked", false)
                .snapshots()
                .map { snap ->
                    snap.toObjects(TechnicianProfileItem::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.verified }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "technicians", uid); throw e }
        )
    }

    fun observeAllTechniciansForAdmin(uid: String): Flow<List<TechnicianProfileItem>> = flow {
        emitAll(
            db.collection("technicians")
                .snapshots()
                .map { snap ->
                    snap.toObjects(TechnicianProfileItem::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "technicians", uid); throw e }
        )
    }

    suspend fun registerTechnician(
        fullName: String,
        profilePhotoUrl: String,
        publicPhone: String,
        serviceDetails: String,
        experienceYears: Long,
        serviceLocation: String,
        city: String,
        categories: List<String>,
        privateVerificationDocUrl: String
    ): Result<Unit> = runFirestoreWrite("technicians") { uid ->
        val safeDocId = CloudRepository.sanitizeId(uid)
        val payload = mapOf(
            "userId" to uid,
            "fullName" to fullName.trim().take(100),
            "profilePhotoUrl" to profilePhotoUrl.trim().take(500),
            "publicPhone" to publicPhone.trim().take(32),
            "serviceDetails" to serviceDetails.trim().take(800),
            "experienceYears" to experienceYears.coerceIn(0L, 70L),
            "serviceLocation" to serviceLocation.trim().take(140),
            "city" to city.trim().take(80),
            "applianceCategories" to categories.ifEmpty { listOf("ac") },
            "approvalStatus" to "PENDING",
            "verified" to false,
            "active" to true,
            "blocked" to false,
            "adminNote" to "",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        db.collection("technicians").document(safeDocId).set(payload).await()
        // Store private verification document STRICTLY in locked subcollection (never in public doc)
        if (privateVerificationDocUrl.isNotBlank()) {
            db.collection("technicians").document(safeDocId)
                .collection("private_verification").document("primary_id")
                .set(
                    mapOf(
                        "docUrl" to privateVerificationDocUrl.take(500),
                        "uploadedByUid" to uid,
                        "uploadedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
        }
    }

    suspend fun adminManageTechnician(
        techId: String,
        approvalStatus: String? = null,
        verified: Boolean? = null,
        active: Boolean? = null,
        blocked: Boolean? = null,
        adminNote: String? = null
    ): Result<Unit> = runFirestoreWrite("technicians/$techId") { uid ->
        val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
        if (approvalStatus != null) updates["approvalStatus"] = approvalStatus
        if (verified != null) updates["verified"] = verified
        if (active != null) updates["active"] = active
        if (blocked != null) updates["blocked"] = blocked
        if (adminNote != null) updates["adminNote"] = adminNote.take(400)
        db.collection("technicians").document(techId).update(updates).await()
        logAudit(uid, "MANAGE_TECHNICIAN", "technicians", techId, updates.keys.joinToString(","))
    }

    suspend fun adminGetPrivateVerificationDocRef(techId: String): Result<String> = try {
        val uid = requireUid()
        val snap = db.collection("technicians").document(techId)
            .collection("private_verification").document("primary_id")
            .get().await()
        val rawUrl = snap.getString("docUrl").orEmpty().trim()
        if (rawUrl.isBlank()) {
            Result.failure(IllegalStateException("No private verification document uploaded by this technician."))
        } else {
            logAudit(uid, "REQUEST_VERIFICATION_DOC", "technicians", techId, "Admin inspected private verification reference")
            Result.success(rawUrl)
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.GET, "technicians/$techId/private_verification/primary_id")
        Result.failure(e)
    }

    // ---------------- REPAIR PDFS & CIRCUIT DIAGRAMS ----------------
    fun observePublishedDocuments(uid: String): Flow<List<RepairDocumentItem>> = flow {
        emitAll(
            db.collection("repair_documents")
                .whereEqualTo("published", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(RepairDocumentItem::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "repair_documents", uid); throw e }
        )
    }

    fun observeAllDocumentsForAdmin(uid: String): Flow<List<RepairDocumentItem>> = flow {
        emitAll(
            db.collection("repair_documents")
                .snapshots()
                .map { snap ->
                    snap.toObjects(RepairDocumentItem::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "repair_documents", uid); throw e }
        )
    }

    suspend fun adminSaveDocument(docItem: RepairDocumentItem): Result<Unit> =
        runFirestoreWrite("repair_documents") { uid ->
            val docId = if (docItem.id.isNotBlank()) CloudRepository.sanitizeId(docItem.id)
            else CloudRepository.sanitizeId("doc_${UUID.randomUUID().toString().replace("-", "").take(14)}")
            val ref = db.collection("repair_documents").document(docId)
            val exists = ref.get().await().exists()
            val payload = mutableMapOf<String, Any>(
                "docType" to docItem.docType.ifBlank { "PDF" },
                "categoryId" to docItem.categoryId.ifBlank { "ac" },
                "brandName" to docItem.brandName.trim().ifBlank { "Universal" }.take(80),
                "modelName" to docItem.modelName.trim().take(100),
                "errorCode" to docItem.errorCode.trim().uppercase().take(32),
                "title" to docItem.title.trim().ifBlank { "Repair Manual" }.take(180),
                "description" to docItem.description.trim().take(1000),
                "fileUrl" to docItem.fileUrl.trim().take(1000),
                "mimeType" to docItem.mimeType.ifBlank { "application/pdf" },
                "fileSizeBytes" to docItem.fileSizeBytes,
                "storageProviderId" to docItem.storageProviderId,
                "published" to docItem.published,
                "uploadedByUid" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!exists) {
                payload["createdAt"] = FieldValue.serverTimestamp()
                ref.set(payload).await()
                logAudit(uid, "UPLOAD_DOCUMENT", "repair_documents", docId, "${docItem.docType}: ${docItem.title}")
            } else {
                ref.update(payload).await()
                logAudit(uid, "UPDATE_DOCUMENT", "repair_documents", docId, docItem.title)
            }
        }

    suspend fun adminDeleteDocument(docId: String): Result<Unit> =
        runFirestoreWrite("repair_documents/$docId") { uid ->
            db.collection("repair_documents").document(docId).delete().await()
            logAudit(uid, "DELETE_DOCUMENT", "repair_documents", docId, "Deleted repair document")
        }

    // ---------------- PUSH NOTIFICATIONS & HISTORY ----------------
    fun observeNotifications(uid: String): Flow<List<PushNotificationItem>> = flow {
        emitAll(
            db.collection("notifications")
                .snapshots()
                .map { snap ->
                    snap.toObjects(PushNotificationItem::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "notifications", uid); throw e }
        )
    }

    /**
     * Sends push notification via secure Supabase FCM HTTP v1 Edge Function and logs to Firestore history.
     * NEVER signs out or redirects admin on backend errors.
     */
    suspend fun adminSendPushNotification(
        title: String,
        body: String,
        targetType: String,
        targetUids: List<String>
    ): Result<String> = try {
        val uid = requireUid()
        val email = auth.currentUser?.email.orEmpty()
        var deliveryStatus = "LOGGED"
        var totalTargeted = targetUids.size.toLong()
        var successCount = 0L
        var failureCount = 0L
        var errorMsg = ""

        if (SupabaseApiClient.isConfigured()) {
            val edgeRes = SupabaseApiClient.sendPushNotification(title, body, targetType, targetUids)
            if (edgeRes.isSuccess) {
                val j = edgeRes.getOrThrow()
                deliveryStatus = j.optString("deliveryStatus", "SENT")
                totalTargeted = j.optLong("totalTargeted", totalTargeted)
                successCount = j.optLong("successCount", 0L)
                failureCount = j.optLong("failureCount", 0L)
                errorMsg = j.optString("warning", "")
            } else {
                deliveryStatus = "EDGE_PENDING"
                errorMsg = edgeRes.exceptionOrNull()?.localizedMessage ?: "Edge Function not deployed yet"
            }
        } else {
            deliveryStatus = "SAVED_IN_APP_INBOX"
            errorMsg = "Saved to in-app notification inbox. Set SUPABASE_ANON_KEY & deploy send-push-notification for live FCM HTTP v1 tray delivery."
        }

        val notifId = CloudRepository.sanitizeId("notif_${UUID.randomUUID().toString().replace("-", "").take(14)}")
        db.collection("notifications").document(notifId).set(
            mapOf(
                "title" to title.trim().take(120),
                "body" to body.trim().take(500),
                "targetType" to targetType,
                "targetUids" to targetUids,
                "sentByUid" to uid,
                "sentByEmail" to email.take(160),
                "totalTargeted" to totalTargeted,
                "successCount" to successCount,
                "failureCount" to failureCount,
                "deliveryStatus" to deliveryStatus,
                "errorMessage" to errorMsg.take(400),
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        logAudit(uid, "SEND_PUSH_NOTIFICATION", "notifications", notifId, "Target=$targetType, Status=$deliveryStatus")
        Result.success(if (errorMsg.isNotBlank()) "$deliveryStatus: $errorMsg" else "Notification sent ($deliveryStatus)")
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "notifications")
        Result.failure(e)
    }

    // ---------------- MULTI-CLOUD STORAGE MIRROR (SUPABASE AUTHORITATIVE) ----------------
    suspend fun adminMirrorStorageProviders(providers: List<StorageProviderItem>): Result<Unit> =
        runFirestoreWrite("storage_providers") { _ ->
            val existingSnap = db.collection("storage_providers").get().await()
            val activeIds = providers.map { CloudRepository.sanitizeId(it.id) }.toSet()
            for (provider in providers) {
                val id = CloudRepository.sanitizeId(provider.id)
                if (!provider.endpointUrl.startsWith("https://")) continue
                val normalizedType = SupabaseApiClient.normalizeProviderType(provider.providerType)
                db.collection("storage_providers").document(id).set(
                    mapOf(
                        "name" to provider.name.trim().take(100),
                        "providerType" to normalizedType,
                        "endpointUrl" to provider.endpointUrl.trim().take(300),
                        "projectRef" to provider.projectRef.trim().take(80),
                        "secretEnvKey" to provider.secretEnvKey.trim().ifBlank { "SUPABASE_SERVICE_ROLE_KEY" }.take(80),
                        "primary" to provider.primary,
                        "backup" to provider.backup,
                        "enabled" to provider.enabled,
                        "autoFailoverEnabled" to provider.autoFailoverEnabled,
                        "capacityBytes" to provider.capacityBytes,
                        "usedBytes" to provider.usedBytes,
                        "lastTestStatus" to provider.lastTestStatus,
                        "lastTestMessage" to provider.lastTestMessage.take(300),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            for (docSnap in existingSnap.documents) {
                if (docSnap.id !in activeIds) {
                    docSnap.reference.delete().await()
                }
            }
        }

    fun observeUsersForAdmin(uid: String): Flow<List<UserProfileCloud>> = flow {
        emitAll(
            db.collection("users")
                .snapshots()
                .map { snap ->
                    snap.toObjects(UserProfileCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "users", uid); throw e }
        )
    }

    suspend fun adminSetUserBlocked(targetUid: String, blocked: Boolean): Result<Unit> =
        runFirestoreWrite("users/$targetUid") { uid ->
            db.collection("users").document(targetUid).update(
                mapOf(
                    "isBlocked" to blocked,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            logAudit(uid, if (blocked) "BLOCK_USER" else "UNBLOCK_USER", "users", targetUid, "isBlocked=$blocked")
        }

    fun observeErrorLogsForAdmin(uid: String): Flow<List<SystemErrorLogItem>> = flow {
        emitAll(
            db.collection("error_logs")
                .snapshots()
                .map { snap ->
                    snap.toObjects(SystemErrorLogItem::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { e -> handleStreamError(e, OperationType.LIST, "error_logs", uid); throw e }
        )
    }

    private suspend fun logAudit(adminUid: String, action: String, targetType: String, targetId: String, details: String) {
        val logId = CloudRepository.sanitizeId("log_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val email = auth.currentUser?.email ?: "admin@repairpro.local"
        runCatching {
            db.collection("audit_logs").document(logId).set(
                mapOf(
                    "adminUid" to adminUid,
                    "adminEmail" to email.take(160),
                    "action" to action.take(100),
                    "targetType" to targetType.take(64),
                    "targetId" to targetId.take(128),
                    "details" to details.take(500),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    private suspend fun runFirestoreWrite(path: String, block: suspend (uid: String) -> Unit): Result<Unit> {
        return try {
            val uid = requireUid()
            block(uid)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private fun handleStreamError(error: Throwable, op: OperationType, path: String, expectedUid: String) {
        val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
        if (fe == null && error is CancellationException) return
        val ex = fe ?: (error as? Exception)
        if (ex != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(ex, op, path)
        }
    }
}
