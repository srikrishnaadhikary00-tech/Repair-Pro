package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "customers",
    indices = [
        Index(value = ["technicianUid"]),
        Index(value = ["technicianUid", "mobileNumber"])
    ]
)
data class CustomerEntity(
    @PrimaryKey val customerId: String,
    val technicianUid: String,
    val name: String,
    val mobileNumber: String,
    val address: String = "",
    val notes: String = "",
    val syncStatus: String = "PENDING_SYNC",
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

@Entity(
    tableName = "invoices",
    indices = [
        Index(value = ["technicianUid"]),
        Index(value = ["technicianUid", "customerId"]),
        Index(value = ["technicianUid", "paymentStatus"])
    ]
)
data class InvoiceEntity(
    @PrimaryKey val invoiceId: String,
    val invoiceNumber: String,
    val technicianUid: String,
    val customerId: String,
    val customerName: String,
    val customerMobile: String,
    val customerAddress: String = "",
    val applianceCategory: String = "",
    val applianceBrand: String = "",
    val modelNumber: String = "",
    val serialNumber: String = "",
    val reportedProblem: String = "",
    val workDone: String = "",
    val partsUsed: String = "",
    val partsQuantity: Int = 0,
    val partsCharges: Double? = null,
    val serviceCharges: Double? = null,
    val visitingCharges: Double? = null,
    val otherCharges: Double? = null,
    val discountAmount: Double? = null,
    val totalBill: Double? = null,
    val amountReceived: Double? = null,
    val remainingBalance: Double? = null,
    val paymentStatus: String = "AMOUNT_NOT_ENTERED",
    val paymentMethod: String = "",
    val paymentDueDate: String = "",
    val warrantyInfo: String = "",
    val notes: String = "",
    val reminderDate: String = "",
    val syncStatus: String = "PENDING_SYNC",
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

@Entity(
    tableName = "invoice_payments",
    indices = [
        Index(value = ["technicianUid"]),
        Index(value = ["invoiceId"])
    ]
)
data class InvoicePaymentEntity(
    @PrimaryKey val paymentId: String,
    val invoiceId: String,
    val technicianUid: String,
    val amount: Double,
    val paymentMethod: String,
    val note: String = "",
    val idempotencyKey: String = "",
    val syncStatus: String = "PENDING_SYNC",
    val paidAtMillis: Long
)
