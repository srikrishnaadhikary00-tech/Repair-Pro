package com.example.data.remote

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.BuildConfig
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

const val BOOTSTRAP_SUPER_ADMIN_EMAIL = "srikrishnaadhikary00@gmail.com"

fun isValidOAuthWebClientId(value: String?): Boolean {
    val v = value?.trim().orEmpty()
    return v.isNotBlank() &&
        !v.startsWith("YOUR_", ignoreCase = true) &&
        !v.startsWith("AIza", ignoreCase = false) &&
        v.endsWith(".apps.googleusercontent.com", ignoreCase = true)
}

fun ensureFirebaseInitialized(context: Context): Boolean {
    val appCtx = context.applicationContext
    return runCatching {
        if (FirebaseApp.getApps(appCtx).isNotEmpty()) return@runCatching true
        FirebaseApp.initializeApp(appCtx) != null || FirebaseApp.getApps(appCtx).isNotEmpty()
    }.getOrDefault(false)
}

fun isFirebaseInitialized(context: Context): Boolean = ensureFirebaseInitialized(context)

fun resolveDefaultWebClientId(context: Context): String? {
    val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
    if (resId != 0) {
        val fromRes = runCatching { context.getString(resId) }.getOrNull()?.trim()
        if (isValidOAuthWebClientId(fromRes)) return fromRes
    }
    val fromEnv = BuildConfig.FIREBASE_WEB_CLIENT_ID.trim()
    return if (isValidOAuthWebClientId(fromEnv)) fromEnv else null
}

fun hasInvalidApiKeyAsClientId(): Boolean {
    val fromEnv = BuildConfig.FIREBASE_WEB_CLIENT_ID.trim()
    return fromEnv.startsWith("AIza")
}

fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    if (!ensureFirebaseInitialized(context)) {
        onUnauthenticated()
        return
    }
    val currentUser = try {
        Firebase.auth.currentUser
    } catch (_: Exception) {
        null
    }
    if (currentUser != null) {
        onAuthSuccess()
        return
    }
    val clientId = resolveDefaultWebClientId(context) ?: run {
        onUnauthenticated()
        return
    }
    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val cred = credentialManager.getCredential(context, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    if (!ensureFirebaseInitialized(context)) {
        onAuthError("Firebase is not initialized yet. Add your original app/google-services.json for gen-lang-client-0218221723 (package com.aistudio.repairpro.kxmvqz).")
        return
    }
    val clientId = resolveDefaultWebClientId(context) ?: run {
        val reason = if (hasInvalidApiKeyAsClientId()) {
            "FIREBASE_WEB_CLIENT_ID is currently set to an AIza Firebase API key instead of an OAuth 2.0 Web Client ID (*.apps.googleusercontent.com). Update AI Studio Secrets or provide app/google-services.json."
        } else {
            "Google Sign-In OAuth Web Client ID missing: add app/google-services.json or set a valid *.apps.googleusercontent.com FIREBASE_WEB_CLIENT_ID in AI Studio Secrets."
        }
        onAuthError(reason)
        return
    }
    val activity = context as? Activity
    if (activity == null) {
        onAuthError("Unable to start Google Sign-In from non-Activity context")
        return
    }
    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val cred = credentialManager.getCredential(activity, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onAuthError("Unexpected credential type returned")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e("Auth", "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "Google Sign-In failed")
        }
    }
}

fun signOutGoogle(
    credentialManager: CredentialManager,
    scope: CoroutineScope,
    onSignOutComplete: () -> Unit = {}
) {
    scope.launch {
        withContext(NonCancellable) {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w("Auth", "Failed to clear credential state: ${e.message}")
            } finally {
                runCatching { Firebase.auth.signOut() }
                onSignOutComplete()
            }
        }
    }
}
