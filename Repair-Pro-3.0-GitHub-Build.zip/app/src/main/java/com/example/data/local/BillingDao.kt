package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.remote.BillingDomainHelper
import kotlinx.coroutines.flow.Flow

@Dao
interface BillingDao {
    @Query("SELECT * FROM customers WHERE technicianUid = :uid ORDER BY updatedAtMillis DESC")
    fun observeCustomers(uid: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE customerId = :customerId AND technicianUid = :uid LIMIT 1")
    suspend fun getCustomer(customerId: String, uid: String): CustomerEntity?

    @Query("SELECT * FROM customers WHERE technicianUid = :uid AND mobileNumber = :mobile LIMIT 1")
    suspend fun findCustomerByMobile(uid: String, mobile: String): CustomerEntity?

    @Query("SELECT * FROM customers WHERE technicianUid = :uid AND syncStatus != 'SYNCED'")
    suspend fun getPendingCustomers(uid: String): List<CustomerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomer(customer: CustomerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomers(customers: List<CustomerEntity>)

    @Query("SELECT * FROM invoices WHERE technicianUid = :uid ORDER BY updatedAtMillis DESC")
    fun observeInvoices(uid: String): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE invoiceId = :invoiceId AND technicianUid = :uid LIMIT 1")
    suspend fun getInvoice(invoiceId: String, uid: String): InvoiceEntity?

    @Query("SELECT * FROM invoices WHERE invoiceId = :invoiceId AND technicianUid = :uid LIMIT 1")
    fun observeInvoice(invoiceId: String, uid: String): Flow<InvoiceEntity?>

    @Query("SELECT * FROM invoices WHERE technicianUid = :uid AND syncStatus != 'SYNCED'")
    suspend fun getPendingInvoices(uid: String): List<InvoiceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInvoice(invoice: InvoiceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInvoices(invoices: List<InvoiceEntity>)

    @Query("DELETE FROM invoices WHERE invoiceId = :invoiceId AND technicianUid = :uid")
    suspend fun deleteInvoice(invoiceId: String, uid: String)

    @Query("SELECT * FROM invoice_payments WHERE invoiceId = :invoiceId AND technicianUid = :uid ORDER BY paidAtMillis DESC")
    fun observePaymentsForInvoice(invoiceId: String, uid: String): Flow<List<InvoicePaymentEntity>>

    @Query("SELECT * FROM invoice_payments WHERE technicianUid = :uid ORDER BY paidAtMillis DESC")
    fun observeAllPayments(uid: String): Flow<List<InvoicePaymentEntity>>

    @Query("SELECT * FROM invoice_payments WHERE invoiceId = :invoiceId AND technicianUid = :uid ORDER BY paidAtMillis DESC")
    suspend fun getPaymentsForInvoice(invoiceId: String, uid: String): List<InvoicePaymentEntity>

    @Query("SELECT * FROM invoice_payments WHERE technicianUid = :uid AND syncStatus != 'SYNCED'")
    suspend fun getPendingPayments(uid: String): List<InvoicePaymentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayment(payment: InvoicePaymentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayments(payments: List<InvoicePaymentEntity>)

    @Query("DELETE FROM invoice_payments WHERE invoiceId = :invoiceId AND technicianUid = :uid")
    suspend fun deletePaymentsForInvoice(invoiceId: String, uid: String)

    @Transaction
    suspend fun recordPaymentAndRecalculate(
        payment: InvoicePaymentEntity
    ): InvoiceEntity? {
        val invoice = getInvoice(payment.invoiceId, payment.technicianUid) ?: return null
        val existing = getPaymentsForInvoice(payment.invoiceId, payment.technicianUid)
        if (payment.idempotencyKey.isNotBlank() && existing.any { it.idempotencyKey == payment.idempotencyKey }) {
            return invoice
        }
        upsertPayment(payment)
        val totalReceived = BillingDomainHelper.round2((invoice.amountReceived ?: 0.0) + payment.amount)
        val newRemaining = BillingDomainHelper.calculateRemainingBalance(invoice.totalBill, totalReceived)
        val newStatus = BillingDomainHelper.resolvePaymentStatus(invoice.totalBill, totalReceived)
        val updatedInvoice = invoice.copy(
            amountReceived = totalReceived,
            remainingBalance = newRemaining,
            paymentStatus = newStatus,
            paymentMethod = payment.paymentMethod,
            syncStatus = "PENDING_SYNC",
            updatedAtMillis = payment.paidAtMillis
        )
        upsertInvoice(updatedInvoice)
        return updatedInvoice
    }
}
