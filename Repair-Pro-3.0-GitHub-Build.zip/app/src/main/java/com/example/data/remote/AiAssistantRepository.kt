package com.example.data.remote

import android.content.Context
import com.example.data.local.Phase2ConfigCache
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class AiAssistantRepository(
    private val supabaseClient: SupabaseClient,
    private val auth: FirebaseAuth = Firebase.auth,
    private val cache: Phase2ConfigCache,
    private val httpClient: OkHttpClient = SupabaseClient.defaultHttpClient(),
    private val storageRouter: MultiCloudStorageRouter? = null
) {
    constructor(context: Context) : this(
        supabaseClient = SupabaseClient(
            firebaseTokenProvider = { forceRefresh ->
                runCatching { Firebase.auth.currentUser?.getIdToken(forceRefresh)?.await()?.token }.getOrNull()
            }
        ),
        cache = Phase2ConfigCache(context.applicationContext)
    )

    private val refreshTick = MutableStateFlow(0L)

    val cachedAiConfig: Flow<AiConfigCloud> = cache.cachedAiConfig
    val cachedBillingConfig: Flow<BillingConfigCloud> = cache.cachedBillingConfig
    val cachedStorageConfig: Flow<StorageRoutingConfig> = cache.cachedStorageConfig

    fun triggerConfigRefresh() {
        refreshTick.value = System.currentTimeMillis()
    }

    suspend fun fetchAiConfig(): AiConfigCloud {
        val rows = supabaseClient.selectRows(
            tableName = "app_settings",
            queryParams = "setting_id=eq.ai_config&select=payload&limit=1",
            requireAuth = false
        ).getOrNull()
        val payload = rows?.optJSONObject(0)?.optJSONObject("payload")
        val parsed = if (payload != null) {
            Phase2ConfigParser.parseAiConfigFromMap(jsonObjectToMap(payload))
        } else {
            runCatching { cache.cachedAiConfig.first() }.getOrDefault(AiConfigCloud())
        }
        runCatching { cache.saveAiConfig(parsed) }
        return parsed
    }

    suspend fun fetchBillingConfig(): BillingConfigCloud {
        val rows = supabaseClient.selectRows(
            tableName = "app_settings",
            queryParams = "setting_id=eq.billing_config&select=payload&limit=1",
            requireAuth = false
        ).getOrNull()
        val payload = rows?.optJSONObject(0)?.optJSONObject("payload")
        val parsed = if (payload != null) {
            Phase2ConfigParser.parseBillingConfigFromMap(jsonObjectToMap(payload))
        } else {
            runCatching { cache.cachedBillingConfig.first() }.getOrDefault(BillingConfigCloud())
        }
        runCatching { cache.saveBillingConfig(parsed) }
        return parsed
    }

    suspend fun fetchStorageRoutingConfig(): StorageRoutingConfig {
        storageRouter?.let { router ->
            return router.loadRoutingConfig()
        }
        val rows = supabaseClient.selectRows(
            tableName = "app_settings",
            queryParams = "setting_id=eq.storage_config&select=payload&limit=1",
            requireAuth = false
        ).getOrNull()
        val payload = rows?.optJSONObject(0)?.optJSONObject("payload")
        if (payload == null) {
            return cache.getCachedStorageConfigSnapshot()
                ?: runCatching { cache.cachedStorageConfig.first() }.getOrDefault(StorageRoutingConfig())
        }
        val providersJson = payload.opt("providers")?.takeIf { it is JSONArray }?.toString()
            ?: payload.optString("providersJson").orEmpty()
        val parsed = MultiCloudStorageRouter.parseRoutingConfig(
            autoFailoverEnabled = payload.optBoolean("autoFailoverEnabled", true),
            fcmBackendUrl = payload.optString("fcmBackendUrl", ""),
            providersJson = providersJson,
            hostingProxyUrl = payload.optString("hostingProxyUrl", ""),
            compressionMaxDim = payload.optInt("compressionMaxDim", 1440),
            compressionQuality = payload.optInt("compressionQuality", 82),
            compressionMaxSizeKb = payload.optInt("compressionMaxSizeKb", 4500),
            duplicateCheckEnabled = payload.optBoolean("duplicateCheckEnabled", true),
            categoryMappingsJson = payload.optJSONObject("categoryMappings")?.toString().orEmpty()
        )
        runCatching { cache.saveStorageConfig(parsed, providersJson) }
        return parsed
    }

    fun observeAiConfig(): Flow<AiConfigCloud> = flow {
        runCatching { emit(cache.cachedAiConfig.first()) }
        while (true) {
            emit(fetchAiConfig())
            delay(45_000L)
        }
    }

    fun observeBillingConfig(): Flow<BillingConfigCloud> = flow {
        runCatching { emit(cache.cachedBillingConfig.first()) }
        while (true) {
            emit(fetchBillingConfig())
            delay(45_000L)
        }
    }

    fun observeStorageRoutingConfig(): Flow<StorageRoutingConfig> = flow {
        runCatching { emit(cache.cachedStorageConfig.first()) }
        while (true) {
            emit(fetchStorageRoutingConfig())
            delay(45_000L)
        }
    }

    suspend fun requestDiagnosis(
        config: AiConfigCloud,
        appliance: String,
        brand: String,
        model: String,
        problem: String,
        errorCode: String,
        languageCode: String
    ): Result<AiDiagnosisResult> = withContext(Dispatchers.IO) {
        if (!config.aiEnabled) {
            return@withContext Result.failure(
                IllegalStateException("Repair Pro AI is currently disabled by administrator.")
            )
        }
        if (config.approvedOrderedProviders().isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException(
                    if (config.aiFreeOnlyMode) {
                        "No enabled free-tier AI providers are currently configured. Requests are paused in Free Only Mode."
                    } else {
                        "No enabled administrator-approved AI providers are available."
                    }
                )
            )
        }
        val cleanAppliance = appliance.trim()
        val cleanBrand = brand.trim()
        val cleanModel = model.trim()
        val cleanErrorCode = errorCode.trim()
        val cleanProblem = problem.trim()

        val hasAnyMeaningfulInput = cleanProblem.length >= 2 ||
            cleanModel.length >= 2 ||
            cleanBrand.length >= 2 ||
            cleanAppliance.length >= 2 ||
            cleanErrorCode.isNotEmpty()

        if (!hasAnyMeaningfulInput) {
            return@withContext Result.failure(
                IllegalArgumentException("Enter at least one diagnostic field (Appliance, Brand, Model, Error Code, or Problem).")
            )
        }
        val endpoint = config.effectiveProxyUrl()
        if (!endpoint.startsWith("https://", ignoreCase = true)) {
            return@withContext Result.failure(
                IllegalStateException("AI Proxy Endpoint must use HTTPS.")
            )
        }

        val currentUser = auth.currentUser
            ?: return@withContext Result.failure(IllegalStateException("Please sign in with Google first."))
        val idToken = runCatching { currentUser.getIdToken(false).await().token }.getOrNull().orEmpty()
        if (idToken.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Google authentication token unavailable. Please sign in again."))
        }

        val safeLang = if (languageCode in listOf("en", "bn", "hi")) languageCode else "en"
        val payload = JSONObject()
            .put("action", "diagnose")
            .put("appliance", cleanAppliance.take(60))
            .put("brand", cleanBrand.take(60))
            .put("model", cleanModel.take(80))
            .put("problem", cleanProblem.take(1200))
            .put("errorCode", cleanErrorCode.uppercase().take(32))
            .put("language", safeLang)

        val request = Request.Builder()
            .url(endpoint)
            .post(payload.toString().toRequestBody("application/json".toMediaTypeOrNull()))
            .addHeader("Authorization", "Bearer $idToken")
            .addHeader("Content-Type", "application/json")
            .build()

        runCatching {
            httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                val json = runCatching { JSONObject(rawBody) }.getOrNull()
                if (!response.isSuccessful || json == null || !json.optBoolean("ok", false)) {
                    val code = json?.optString("errorCode").orEmpty().ifBlank { "HTTP_${response.code}" }
                    val msg = json?.optString("message")?.takeIf { it.isNotBlank() }
                        ?: "AI service returned HTTP ${response.code}"
                    recordClientAiError(currentUser.uid, config.aiProvider, config.aiModel, code, msg)
                    throw IllegalStateException(msg)
                }
                val diag = json.optJSONObject("diagnosis") ?: JSONObject()
                val usage = json.optJSONObject("usage")
                AiDiagnosisResult(
                    safetyWarning = diag.optString("safetyWarning").ifBlank {
                        "Disconnect mains power before inspecting any electrical or PCB component."
                    },
                    errorCodeStatus = diag.optString("errorCodeStatus", if (cleanErrorCode.isBlank()) "NOT_PROVIDED" else "UNVERIFIED"),
                    errorCodeExplanation = diag.optString("errorCodeExplanation"),
                    possibleCauses = diag.optJSONArray("possibleCauses").toStringList(),
                    componentsToInspect = diag.optJSONArray("componentsToInspect").toStringList(),
                    diagnosticChecks = diag.optJSONArray("diagnosticChecks").toStringList(),
                    safeTroubleshootingSteps = diag.optJSONArray("safeTroubleshootingSteps").toStringList(),
                    repairOptions = diag.optJSONArray("repairOptions").toStringList(),
                    followUpQuestions = diag.optJSONArray("followUpQuestions").toStringList(),
                    summaryNote = diag.optString("summaryNote"),
                    providerUsed = json.optString("provider", config.aiProvider),
                    modelUsed = json.optString("model", config.aiModel),
                    language = json.optString("language", safeLang),
                    userUsedToday = usage?.optInt("userUsedToday", 0) ?: 0,
                    perUserLimit = usage?.optInt("perUserLimit", config.aiPerUserLimit) ?: config.aiPerUserLimit
                )
            }
        }
    }

    private suspend fun recordClientAiError(
        uid: String,
        provider: String,
        model: String,
        errorCode: String,
        message: String
    ) {
        val errorId = "aie_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        val payload = JSONObject()
            .put("error_id", errorId)
            .put("user_id", uid)
            .put("provider", provider.take(40))
            .put("model_name", model.take(80))
            .put("error_code", errorCode.take(64))
            .put("error_message", message.take(600))
            .put("resolved", false)
        runCatching {
            supabaseClient.insertRow("ai_error_logs", payload, requireAuth = true)
        }
    }

    private fun jsonObjectToMap(obj: JSONObject): Map<String, Any?> {
        val map = linkedMapOf<String, Any?>()
        obj.keys().forEach { key ->
            val v = obj.opt(key)
            map[key] = when (v) {
                JSONObject.NULL -> null
                is JSONArray -> (0 until v.length()).map { idx -> v.opt(idx) }
                is JSONObject -> v.toString()
                else -> v
            }
        }
        return map
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return (0 until length())
            .mapNotNull { optString(it)?.trim()?.takeIf { s -> s.isNotEmpty() } }
    }
}
