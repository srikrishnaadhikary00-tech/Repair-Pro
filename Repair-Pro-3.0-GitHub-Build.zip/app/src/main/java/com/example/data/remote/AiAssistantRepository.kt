package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.local.Phase2ConfigCache
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class AiAssistantRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
    private val cache: Phase2ConfigCache,
    private val httpClient: OkHttpClient = SupabaseClient.defaultHttpClient()
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        cache = Phase2ConfigCache(context.applicationContext)
    )

    val cachedAiConfig: Flow<AiConfigCloud> = cache.cachedAiConfig
    val cachedBillingConfig: Flow<BillingConfigCloud> = cache.cachedBillingConfig
    val cachedStorageConfig: Flow<StorageRoutingConfig> = cache.cachedStorageConfig

    fun observeAiConfig(): Flow<AiConfigCloud> = flow {
        emitAll(
            db.collection("app_settings").document("ai_config")
                .snapshots()
                .map { snap ->
                    val parsed = if (snap.exists()) {
                        Phase2ConfigParser.parseAiConfigFromMap(snap.data)
                    } else {
                        AiConfigCloud()
                    }
                    runCatching { cache.saveAiConfig(parsed) }
                    parsed
                }
                .catch {
                    emitAll(cache.cachedAiConfig)
                }
        )
    }

    fun observeBillingConfig(): Flow<BillingConfigCloud> = flow {
        emitAll(
            db.collection("app_settings").document("billing_config")
                .snapshots()
                .map { snap ->
                    val parsed = if (snap.exists()) {
                        Phase2ConfigParser.parseBillingConfigFromMap(snap.data)
                    } else {
                        BillingConfigCloud()
                    }
                    runCatching { cache.saveBillingConfig(parsed) }
                    parsed
                }
                .catch {
                    emitAll(cache.cachedBillingConfig)
                }
        )
    }

    fun observeStorageRoutingConfig(): Flow<StorageRoutingConfig> = flow {
        emitAll(
            db.collection("app_settings").document("storage_config")
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) {
                        StorageRoutingConfig()
                    } else {
                        val providersJson = snap.getString("providersJson").orEmpty()
                        val parsed = MultiCloudStorageRouter.parseRoutingConfig(
                            autoFailoverEnabled = snap.getBoolean("autoFailoverEnabled") ?: true,
                            fcmBackendUrl = snap.getString("fcmBackendUrl").orEmpty(),
                            providersJson = providersJson,
                            hostingProxyUrl = snap.getString("hostingProxyUrl").orEmpty(),
                            compressionMaxDim = (snap.getLong("compressionMaxDim") ?: 1440L).toInt(),
                            compressionQuality = (snap.getLong("compressionQuality") ?: 82L).toInt(),
                            compressionMaxSizeKb = (snap.getLong("compressionMaxSizeKb") ?: 4500L).toInt(),
                            duplicateCheckEnabled = snap.getBoolean("duplicateCheckEnabled") ?: true
                        )
                        runCatching { cache.saveStorageConfig(parsed, providersJson) }
                        parsed
                    }
                }
                .catch {
                    emitAll(cache.cachedStorageConfig)
                }
        )
    }

    suspend fun requestDiagnosis(
        config: AiConfigCloud,
        appliance: String,
        brand: String,
        model: String,
        problem: String,
        errorCode: String,
        languageCode: String
    ): Result<AiDiagnosisResult> = withContext(Dispatchers.IO) {
        if (!config.aiEnabled) {
            return@withContext Result.failure(
                IllegalStateException("AI Smart Repair Assistant is currently disabled by administrator.")
            )
        }
        if (config.approvedOrderedProviders().isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException(
                    if (config.aiFreeOnlyMode) {
                        "No enabled free-tier AI providers are currently configured. Requests are paused in Free Only Mode."
                    } else {
                        "No enabled administrator-approved AI providers are available."
                    }
                )
            )
        }
        val cleanAppliance = appliance.trim()
        val cleanBrand = brand.trim()
        val cleanProblem = problem.trim()
        if (cleanAppliance.isBlank() || cleanBrand.isBlank() || cleanProblem.length < 4) {
            return@withContext Result.failure(
                IllegalArgumentException("Please select Appliance, Brand, and describe the problem.")
            )
        }
        val endpoint = config.effectiveProxyUrl()
        if (!endpoint.startsWith("https://", ignoreCase = true)) {
            return@withContext Result.failure(
                IllegalStateException("AI Proxy Endpoint must use HTTPS.")
            )
        }

        val currentUser = auth.currentUser
            ?: return@withContext Result.failure(IllegalStateException("Please sign in with Google first."))
        val idToken = runCatching { currentUser.getIdToken(false).await().token }.getOrNull().orEmpty()
        if (idToken.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Google authentication token unavailable. Please sign in again."))
        }

        val safeLang = if (languageCode in listOf("en", "bn", "hi")) languageCode else "en"
        val payload = JSONObject()
            .put("action", "diagnose")
            .put("appliance", cleanAppliance.take(60))
            .put("brand", cleanBrand.take(60))
            .put("model", model.trim().take(80))
            .put("problem", cleanProblem.take(1200))
            .put("errorCode", errorCode.trim().uppercase().take(32))
            .put("language", safeLang)

        val request = Request.Builder()
            .url(endpoint)
            .post(payload.toString().toRequestBody("application/json".toMediaTypeOrNull()))
            .addHeader("Authorization", "Bearer $idToken")
            .addHeader("Content-Type", "application/json")
            .build()

        runCatching {
            httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                val json = runCatching { JSONObject(rawBody) }.getOrNull()
                if (!response.isSuccessful || json == null || !json.optBoolean("ok", false)) {
                    val code = json?.optString("errorCode").orEmpty().ifBlank { "HTTP_${response.code}" }
                    val msg = json?.optString("message")?.takeIf { it.isNotBlank() }
                        ?: "AI service returned HTTP ${response.code}"
                    recordClientAiError(currentUser.uid, config.aiProvider, config.aiModel, code, msg)
                    throw IllegalStateException(msg)
                }
                val diag = json.optJSONObject("diagnosis") ?: JSONObject()
                val usage = json.optJSONObject("usage")
                AiDiagnosisResult(
                    safetyWarning = diag.optString("safetyWarning").ifBlank {
                        "Disconnect mains power before inspecting any electrical or PCB component."
                    },
                    errorCodeStatus = diag.optString("errorCodeStatus", if (errorCode.isBlank()) "NOT_PROVIDED" else "UNVERIFIED"),
                    errorCodeExplanation = diag.optString("errorCodeExplanation"),
                    possibleCauses = diag.optJSONArray("possibleCauses").toStringList(),
                    componentsToInspect = diag.optJSONArray("componentsToInspect").toStringList(),
                    diagnosticChecks = diag.optJSONArray("diagnosticChecks").toStringList(),
                    safeTroubleshootingSteps = diag.optJSONArray("safeTroubleshootingSteps").toStringList(),
                    repairOptions = diag.optJSONArray("repairOptions").toStringList(),
                    followUpQuestions = diag.optJSONArray("followUpQuestions").toStringList(),
                    summaryNote = diag.optString("summaryNote"),
                    providerUsed = json.optString("provider", config.aiProvider),
                    modelUsed = json.optString("model", config.aiModel),
                    language = json.optString("language", safeLang),
                    userUsedToday = usage?.optInt("userUsedToday", 0) ?: 0,
                    perUserLimit = usage?.optInt("perUserLimit", config.aiPerUserLimit) ?: config.aiPerUserLimit
                )
            }
        }
    }

    private suspend fun recordClientAiError(
        uid: String,
        provider: String,
        model: String,
        errorCode: String,
        message: String
    ) {
        val errorId = "aie_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        val payload = mapOf(
            "errorId" to errorId,
            "userId" to uid,
            "provider" to provider.take(40),
            "modelName" to model.take(80),
            "errorCode" to errorCode.take(64),
            "errorMessage" to message.take(600),
            "resolved" to false,
            "createdAt" to FieldValue.serverTimestamp()
        )
        runCatching {
            db.collection("ai_error_logs").document(errorId).set(payload).await()
        }
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return (0 until length())
            .mapNotNull { optString(it)?.trim()?.takeIf { s -> s.isNotEmpty() } }
    }
}
