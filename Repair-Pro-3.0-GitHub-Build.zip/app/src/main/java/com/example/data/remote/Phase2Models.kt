package com.example.data.remote

import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToLong

data class AiProviderProfile(
    val providerId: String,
    val label: String,
    val providerType: String,
    val role: String,
    val enabled: Boolean = true,
    val isFree: Boolean = true,
    val adminPaidApproved: Boolean = false,
    val endpointUrl: String = "",
    val model: String = "",
    val dailyLimit: Int = 500,
    val perUserLimit: Int = 15
) {
    fun isOpenRouterFreeModel(): Boolean {
        val m = model.trim().lowercase()
        return m == "openrouter/free" || m.endsWith(":free")
    }

    fun roleWeight(): Int = when (role.uppercase()) {
        "PRIMARY" -> 0
        "SECONDARY" -> 1
        "BACKUP" -> 2
        else -> 3
    }

    companion object {
        val SUPPORTED_PROVIDER_TYPES = setOf("GEMINI", "GROQ", "OPENROUTER", "OPENAI_COMPATIBLE", "CUSTOM_PROXY")
    }
}

data class AiConfigCloud(
    val aiEnabled: Boolean = true,
    val showAiNavItem: Boolean = true,
    val aiProvider: String = "GEMINI",
    val aiModel: String = "gemini-2.5-flash",
    val aiEndpointUrl: String = "",
    val aiProxyEndpoint: String = DEFAULT_AI_PROXY_URL,
    val aiDailyLimit: Int = 500,
    val aiPerUserLimit: Int = 15,
    val aiSupportedAppliances: List<String> = DEFAULT_APPLIANCES,
    val aiBrandsModelsJson: String = DEFAULT_BRANDS_JSON,
    val aiSupportedLanguages: List<String> = listOf("en", "bn", "hi"),
    val aiSystemInstructions: String = "",
    val aiUsageCount: Long = 0L,
    val aiErrorCount: Long = 0L,
    val aiLastStatus: String = "READY",
    val aiFreeOnlyMode: Boolean = true,
    val aiAllowPaidFallback: Boolean = false,
    val aiAutoFailoverEnabled: Boolean = true,
    val aiProvidersJson: String = DEFAULT_AI_PROVIDERS_JSON
) {
    fun brandsMap(): Map<String, List<String>> = Phase2ConfigParser.parseBrandsMap(aiBrandsModelsJson)

    fun configuredProviders(): List<AiProviderProfile> = Phase2ConfigParser.parseAiProvidersList(
        json = aiProvidersJson,
        fallbackProvider = aiProvider,
        fallbackModel = aiModel,
        fallbackEndpoint = aiEndpointUrl,
        fallbackDailyLimit = aiDailyLimit,
        fallbackPerUserLimit = aiPerUserLimit
    )

    fun isProviderEligible(profile: AiProviderProfile): Boolean {
        if (!profile.enabled || profile.role.equals("DISABLED", ignoreCase = true)) return false
        if (aiFreeOnlyMode) {
            if (!profile.isFree) return false
            if (profile.providerType.equals("OPENROUTER", ignoreCase = true) && !profile.isOpenRouterFreeModel()) {
                return false
            }
            return true
        }
        if (!profile.isFree) {
            return aiAllowPaidFallback && profile.adminPaidApproved
        }
        return true
    }

    fun approvedOrderedProviders(): List<AiProviderProfile> {
        val ordered = configuredProviders()
            .filter { isProviderEligible(it) }
            .sortedBy { it.roleWeight() }
        return if (aiAutoFailoverEnabled) ordered else ordered.take(1)
    }

    fun effectiveProxyUrl(): String {
        val trimmed = aiProxyEndpoint.trim()
        return if (trimmed.startsWith("https://", ignoreCase = true)) trimmed else DEFAULT_AI_PROXY_URL
    }

    companion object {
        const val DEFAULT_AI_PROXY_URL =
            "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/ai-repair-assistant"

        val DEFAULT_APPLIANCES = listOf("Air Conditioner", "Refrigerator", "Washing Machine")

        const val DEFAULT_BRANDS_JSON = """{"Air Conditioner":["LG","Voltas","Daikin","Blue Star","Samsung","Lloyd","Hitachi","Carrier","Godrej","Haier","Whirlpool"],"Refrigerator":["LG","Samsung","Whirlpool","Godrej","Haier","Bosch","Electrolux","Voltas Beko"],"Washing Machine":["LG","Samsung","Whirlpool","IFB","Bosch","Haier","Godrej","Voltas Beko"]}"""

        const val DEFAULT_AI_PROVIDERS_JSON = """[{"providerId":"gemini_free_primary","label":"Google Gemini (Free Tier)","providerType":"GEMINI","role":"PRIMARY","enabled":true,"isFree":true,"adminPaidApproved":false,"endpointUrl":"https://generativelanguage.googleapis.com","model":"gemini-2.5-flash","dailyLimit":500,"perUserLimit":15}]"""
    }
}

data class AiDiagnosisResult(
    val safetyWarning: String = "",
    val errorCodeStatus: String = "NOT_PROVIDED",
    val errorCodeExplanation: String = "",
    val possibleCauses: List<String> = emptyList(),
    val componentsToInspect: List<String> = emptyList(),
    val diagnosticChecks: List<String> = emptyList(),
    val safeTroubleshootingSteps: List<String> = emptyList(),
    val repairOptions: List<String> = emptyList(),
    val followUpQuestions: List<String> = emptyList(),
    val summaryNote: String = "",
    val providerUsed: String = "",
    val modelUsed: String = "",
    val language: String = "en",
    val userUsedToday: Int = 0,
    val perUserLimit: Int = 15
)

data class BillingConfigCloud(
    val invoiceEnabled: Boolean = true,
    val whatsappReminderEnabled: Boolean = true,
    val smsReminderEnabled: Boolean = true,
    val invoiceBusinessTitle: String = "Repair Pro Service Invoice",
    val invoiceTermsNote: String = "Thank you for choosing our appliance service. Retain this invoice for service reference.",
    val reminderTemplatesJson: String = DEFAULT_TEMPLATES_JSON,
    val billingSupportedLanguages: List<String> = listOf("en", "bn", "hi")
) {
    fun templateFor(languageCode: String): String {
        val map = Phase2ConfigParser.parseTemplatesMap(reminderTemplatesJson)
        return map[languageCode]?.takeIf { it.isNotBlank() }
            ?: defaultTemplateFor(languageCode)
    }

    companion object {
        const val DEFAULT_TEMPLATE_EN =
            "Hello {customerName}, your Repair Pro service invoice #{invoiceNumber} for {appliance} has a pending balance of {remainingBalance}. Total: {totalBill}, Paid: {amountReceived}. Due date: {dueDate}. Thank you!"
        const val DEFAULT_TEMPLATE_BN =
            "নমস্কার {customerName}, আপনার {appliance} সার্ভিস ইনভয়েস #{invoiceNumber}-এর বকেয়া পরিমাণ {remainingBalance}। মোট বিল: {totalBill}, জমা: {amountReceived}। শেষ তারিখ: {dueDate}। ধন্যবাদ!"
        const val DEFAULT_TEMPLATE_HI =
            "नमस्ते {customerName}, आपके {appliance} सर्विस इनवॉइस #{invoiceNumber} की बकाया राशि {remainingBalance} है। कुल बिल: {totalBill}, प्राप्त: {amountReceived}। अंतिम तिथि: {dueDate}। धन्यवाद!"

        val DEFAULT_TEMPLATES_JSON =
            """{"en":"$DEFAULT_TEMPLATE_EN","bn":"$DEFAULT_TEMPLATE_BN","hi":"$DEFAULT_TEMPLATE_HI"}"""

        fun defaultTemplateFor(languageCode: String): String = when (languageCode.lowercase()) {
            "bn" -> DEFAULT_TEMPLATE_BN
            "hi" -> DEFAULT_TEMPLATE_HI
            else -> DEFAULT_TEMPLATE_EN
        }
    }
}

object Phase2ConfigParser {
    fun parseAiConfigFromMap(raw: Map<String, Any?>?): AiConfigCloud {
        if (raw == null) return AiConfigCloud()
        val appliances = (raw["aiSupportedAppliances"] as? List<*>)
            ?.mapNotNull { it?.toString()?.trim()?.takeIf { s -> s.isNotEmpty() } }
            ?.takeIf { it.isNotEmpty() }
            ?: AiConfigCloud.DEFAULT_APPLIANCES
        val langs = (raw["aiSupportedLanguages"] as? List<*>)
            ?.mapNotNull { it?.toString()?.trim()?.lowercase()?.takeIf { s -> s in listOf("en", "bn", "hi") } }
            ?.distinct()
            ?.takeIf { it.isNotEmpty() }
            ?: listOf("en", "bn", "hi")
        val provider = raw["aiProvider"]?.toString()?.trim()?.uppercase()
            ?.takeIf { it in AiProviderProfile.SUPPORTED_PROVIDER_TYPES }
            ?: "GEMINI"
        val proxyUrl = raw["aiProxyEndpoint"]?.toString()?.trim()
            ?.takeIf { it.startsWith("https://", ignoreCase = true) }
            ?: AiConfigCloud.DEFAULT_AI_PROXY_URL

        return AiConfigCloud(
            aiEnabled = raw["aiEnabled"] as? Boolean ?: true,
            showAiNavItem = raw["showAiNavItem"] as? Boolean ?: true,
            aiProvider = provider,
            aiModel = raw["aiModel"]?.toString()?.trim()?.ifBlank { "gemini-2.5-flash" } ?: "gemini-2.5-flash",
            aiEndpointUrl = raw["aiEndpointUrl"]?.toString()?.trim().orEmpty(),
            aiProxyEndpoint = proxyUrl,
            aiDailyLimit = ((raw["aiDailyLimit"] as? Number)?.toInt() ?: 500).coerceIn(0, 1_000_000),
            aiPerUserLimit = ((raw["aiPerUserLimit"] as? Number)?.toInt() ?: 15).coerceIn(0, 1000),
            aiSupportedAppliances = appliances,
            aiBrandsModelsJson = raw["aiBrandsModelsJson"]?.toString()?.takeIf { it.isNotBlank() }
                ?: AiConfigCloud.DEFAULT_BRANDS_JSON,
            aiSupportedLanguages = langs,
            aiSystemInstructions = raw["aiSystemInstructions"]?.toString().orEmpty(),
            aiUsageCount = (raw["aiUsageCount"] as? Number)?.toLong() ?: 0L,
            aiErrorCount = (raw["aiErrorCount"] as? Number)?.toLong() ?: 0L,
            aiLastStatus = raw["aiLastStatus"]?.toString()?.ifBlank { "READY" } ?: "READY",
            aiFreeOnlyMode = raw["aiFreeOnlyMode"] as? Boolean ?: true,
            aiAllowPaidFallback = raw["aiAllowPaidFallback"] as? Boolean ?: false,
            aiAutoFailoverEnabled = raw["aiAutoFailoverEnabled"] as? Boolean ?: true,
            aiProvidersJson = raw["aiProvidersJson"]?.toString()?.takeIf { it.isNotBlank() }
                ?: AiConfigCloud.DEFAULT_AI_PROVIDERS_JSON
        )
    }

    fun parseBillingConfigFromMap(raw: Map<String, Any?>?): BillingConfigCloud {
        if (raw == null) return BillingConfigCloud()
        val langs = (raw["billingSupportedLanguages"] as? List<*>)
            ?.mapNotNull { it?.toString()?.trim()?.lowercase()?.takeIf { s -> s in listOf("en", "bn", "hi") } }
            ?.distinct()
            ?.takeIf { it.isNotEmpty() }
            ?: listOf("en", "bn", "hi")

        return BillingConfigCloud(
            invoiceEnabled = raw["invoiceEnabled"] as? Boolean ?: true,
            whatsappReminderEnabled = raw["whatsappReminderEnabled"] as? Boolean ?: true,
            smsReminderEnabled = raw["smsReminderEnabled"] as? Boolean ?: true,
            invoiceBusinessTitle = raw["invoiceBusinessTitle"]?.toString()?.trim()
                ?.ifBlank { "Repair Pro Service Invoice" }
                ?: "Repair Pro Service Invoice",
            invoiceTermsNote = raw["invoiceTermsNote"]?.toString()?.trim()
                ?.ifBlank { BillingConfigCloud().invoiceTermsNote }
                ?: BillingConfigCloud().invoiceTermsNote,
            reminderTemplatesJson = raw["reminderTemplatesJson"]?.toString()
                ?.takeIf { it.isNotBlank() }
                ?: BillingConfigCloud.DEFAULT_TEMPLATES_JSON,
            billingSupportedLanguages = langs
        )
    }

    /**
     * Pure-Kotlin JSON object-of-string-arrays parser so JVM unit tests run without org.json stubs.
     */
    fun parseBrandsMap(json: String): Map<String, List<String>> {
        val result = linkedMapOf<String, List<String>>()
        val trimmed = json.trim()
        if (!trimmed.startsWith("{") || !trimmed.endsWith("}")) return defaultBrandsFallback()
        val entryRegex = Regex(""""([^"]+)"\s*:\s*\[([^\]]*)]""")
        val itemRegex = Regex(""""((?:[^"\\]|\\.)*)"""")
        for (match in entryRegex.findAll(trimmed)) {
            val key = unescapeJson(match.groupValues[1]).trim()
            val arrayBody = match.groupValues[2]
            val items = itemRegex.findAll(arrayBody)
                .map { unescapeJson(it.groupValues[1]).trim() }
                .filter { it.isNotEmpty() }
                .toList()
            if (key.isNotEmpty() && items.isNotEmpty()) {
                result[key] = items
            }
        }
        return result.ifEmpty { defaultBrandsFallback() }
    }

    /**
     * Pure-Kotlin JSON string-map parser for {"en":"...","bn":"...","hi":"..."}.
     */
    fun parseTemplatesMap(json: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val trimmed = json.trim()
        if (!trimmed.startsWith("{") || !trimmed.endsWith("}")) return result
        val pairRegex = Regex(""""([a-zA-Z0-9_-]+)"\s*:\s*"((?:[^"\\]|\\.)*)"""")
        for (match in pairRegex.findAll(trimmed)) {
            val k = match.groupValues[1].trim()
            val v = unescapeJson(match.groupValues[2])
            if (k.isNotEmpty()) result[k] = v
        }
        return result
    }

    /**
     * Pure-Kotlin parser for multi-provider aiProvidersJson array so JVM unit tests run without org.json stubs.
     */
    fun parseAiProvidersList(
        json: String,
        fallbackProvider: String = "GEMINI",
        fallbackModel: String = "gemini-2.5-flash",
        fallbackEndpoint: String = "",
        fallbackDailyLimit: Int = 500,
        fallbackPerUserLimit: Int = 15
    ): List<AiProviderProfile> {
        val trimmed = json.trim()
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            val objects = splitTopLevelJsonObjects(trimmed)
            val parsed = objects.mapIndexedNotNull { idx, obj ->
                val pTypeRaw = extractJsonString(obj, "providerType").uppercase()
                val pType = if (pTypeRaw in AiProviderProfile.SUPPORTED_PROVIDER_TYPES) pTypeRaw else "GEMINI"
                val id = extractJsonString(obj, "providerId").ifBlank { "ai_${pType.lowercase()}_$idx" }
                val label = extractJsonString(obj, "label").ifBlank { pType }
                val roleRaw = extractJsonString(obj, "role").uppercase()
                val role = if (roleRaw in setOf("PRIMARY", "SECONDARY", "BACKUP", "DISABLED")) roleRaw else "BACKUP"
                val enabled = extractJsonBoolean(obj, "enabled") ?: true
                val defaultFree = pType in setOf("GEMINI", "GROQ", "OPENROUTER")
                val isFree = extractJsonBoolean(obj, "isFree") ?: defaultFree
                val adminPaidApproved = extractJsonBoolean(obj, "adminPaidApproved") ?: false
                val endpoint = extractJsonString(obj, "endpointUrl").ifBlank { defaultEndpointFor(pType) }
                val model = extractJsonString(obj, "model").ifBlank { defaultModelFor(pType) }
                val dailyLimit = (extractJsonInt(obj, "dailyLimit") ?: fallbackDailyLimit).coerceIn(0, 1_000_000)
                val perUserLimit = (extractJsonInt(obj, "perUserLimit") ?: fallbackPerUserLimit).coerceIn(0, 1000)
                AiProviderProfile(
                    providerId = id,
                    label = label,
                    providerType = pType,
                    role = role,
                    enabled = enabled,
                    isFree = isFree,
                    adminPaidApproved = adminPaidApproved,
                    endpointUrl = endpoint,
                    model = model,
                    dailyLimit = dailyLimit,
                    perUserLimit = perUserLimit
                )
            }
            if (parsed.isNotEmpty()) return parsed
        }
        val cleanType = fallbackProvider.uppercase().takeIf { it in AiProviderProfile.SUPPORTED_PROVIDER_TYPES } ?: "GEMINI"
        return listOf(
            AiProviderProfile(
                providerId = "legacy_${cleanType.lowercase()}",
                label = cleanType,
                providerType = cleanType,
                role = "PRIMARY",
                enabled = true,
                isFree = cleanType in setOf("GEMINI", "GROQ", "OPENROUTER"),
                adminPaidApproved = false,
                endpointUrl = fallbackEndpoint.ifBlank { defaultEndpointFor(cleanType) },
                model = fallbackModel.ifBlank { defaultModelFor(cleanType) },
                dailyLimit = fallbackDailyLimit,
                perUserLimit = fallbackPerUserLimit
            )
        )
    }

    private fun defaultEndpointFor(providerType: String): String = when (providerType) {
        "GEMINI" -> "https://generativelanguage.googleapis.com"
        "GROQ" -> "https://api.groq.com/openai/v1/chat/completions"
        "OPENROUTER" -> "https://openrouter.ai/api/v1/chat/completions"
        "OPENAI_COMPATIBLE" -> "https://api.openai.com/v1/chat/completions"
        else -> ""
    }

    private fun defaultModelFor(providerType: String): String = when (providerType) {
        "GEMINI" -> "gemini-2.5-flash"
        "GROQ" -> "llama-3.3-70b-versatile"
        "OPENROUTER" -> "meta-llama/llama-3.3-70b-instruct:free"
        "OPENAI_COMPATIBLE" -> "gpt-4o-mini"
        else -> "custom-model"
    }

    private fun splitTopLevelJsonObjects(arrayJson: String): List<String> {
        val result = mutableListOf<String>()
        var depth = 0
        var inQuotes = false
        var escape = false
        var start = -1
        for (i in arrayJson.indices) {
            val ch = arrayJson[i]
            if (escape) {
                escape = false
                continue
            }
            if (ch == '\\' && inQuotes) {
                escape = true
                continue
            }
            if (ch == '"') {
                inQuotes = !inQuotes
                continue
            }
            if (!inQuotes) {
                if (ch == '{') {
                    if (depth == 0) start = i
                    depth++
                } else if (ch == '}') {
                    depth--
                    if (depth == 0 && start >= 0) {
                        result += arrayJson.substring(start, i + 1)
                        start = -1
                    }
                }
            }
        }
        return result
    }

    private fun extractJsonString(obj: String, key: String): String {
        val regex = Regex(""""${Regex.escape(key)}"\s*:\s*"((?:[^"\\]|\\.)*)"""")
        val match = regex.find(obj) ?: return ""
        return unescapeJson(match.groupValues[1]).trim()
    }

    private fun extractJsonBoolean(obj: String, key: String): Boolean? {
        val regex = Regex(""""${Regex.escape(key)}"\s*:\s*(true|false)\b""", RegexOption.IGNORE_CASE)
        val match = regex.find(obj) ?: return null
        return match.groupValues[1].equals("true", ignoreCase = true)
    }

    private fun extractJsonInt(obj: String, key: String): Int? {
        val regex = Regex(""""${Regex.escape(key)}"\s*:\s*(-?\d+)""")
        val match = regex.find(obj) ?: return null
        return match.groupValues[1].toIntOrNull()
    }

    private fun unescapeJson(raw: String): String {
        val sb = StringBuilder(raw.length)
        var i = 0
        while (i < raw.length) {
            val c = raw[i]
            if (c == '\\' && i + 1 < raw.length) {
                when (val next = raw[i + 1]) {
                    'n' -> sb.append('\n')
                    'r' -> sb.append('\r')
                    't' -> sb.append('\t')
                    '"' -> sb.append('"')
                    '\\' -> sb.append('\\')
                    '/' -> sb.append('/')
                    else -> sb.append(next)
                }
                i += 2
            } else {
                sb.append(c)
                i += 1
            }
        }
        return sb.toString()
    }

    private fun defaultBrandsFallback(): Map<String, List<String>> = mapOf(
        "Air Conditioner" to listOf("LG", "Voltas", "Daikin", "Blue Star", "Samsung", "Lloyd", "Hitachi"),
        "Refrigerator" to listOf("LG", "Samsung", "Whirlpool", "Godrej", "Haier"),
        "Washing Machine" to listOf("LG", "Samsung", "Whirlpool", "IFB", "Bosch", "Haier")
    )
}

object BillingDomainHelper {
    const val STATUS_FULLY_PAID = "FULLY_PAID"
    const val STATUS_PARTIALLY_PAID = "PARTIALLY_PAID"
    const val STATUS_UNPAID = "UNPAID"
    const val STATUS_AMOUNT_NOT_ENTERED = "AMOUNT_NOT_ENTERED"

    val ALLOWED_PAYMENT_METHODS = listOf("Cash", "UPI", "Card", "Bank Transfer")

    fun parseOptionalAmount(raw: String): Double? {
        val clean = raw.trim().replace(",", "").replace("₹", "")
        if (clean.isEmpty()) return null
        return clean.toDoubleOrNull()?.takeIf { it.isFinite() }
    }

    fun calculateTotalBill(
        partsCharges: Double?,
        serviceCharges: Double?,
        visitingCharges: Double?,
        otherCharges: Double?,
        discountAmount: Double?
    ): Double? {
        val anyChargeEntered = listOf(
            partsCharges,
            serviceCharges,
            visitingCharges,
            otherCharges,
            discountAmount
        ).any { it != null }
        if (!anyChargeEntered) return null

        val gross = (partsCharges ?: 0.0).coerceAtLeast(0.0) +
            (serviceCharges ?: 0.0).coerceAtLeast(0.0) +
            (visitingCharges ?: 0.0).coerceAtLeast(0.0) +
            (otherCharges ?: 0.0).coerceAtLeast(0.0)
        val discount = (discountAmount ?: 0.0).coerceAtLeast(0.0)
        return round2((gross - discount).coerceAtLeast(0.0))
    }

    fun calculateRemainingBalance(totalBill: Double?, amountReceived: Double?): Double? {
        if (totalBill == null) return null
        val received = (amountReceived ?: 0.0).coerceAtLeast(0.0)
        return round2((totalBill - received).coerceAtLeast(0.0))
    }

    fun resolvePaymentStatus(totalBill: Double?, amountReceived: Double?): String {
        if (totalBill == null) return STATUS_AMOUNT_NOT_ENTERED
        val received = (amountReceived ?: 0.0).coerceAtLeast(0.0)
        val remaining = (totalBill - received).coerceAtLeast(0.0)
        return when {
            remaining <= 0.009 -> STATUS_FULLY_PAID
            received > 0.0 -> STATUS_PARTIALLY_PAID
            else -> STATUS_UNPAID
        }
    }

    fun validateCustomerAndInvoiceInput(
        customerName: String,
        customerMobile: String,
        partsCharges: Double?,
        serviceCharges: Double?,
        visitingCharges: Double?,
        otherCharges: Double?,
        discountAmount: Double?,
        amountReceived: Double?
    ): String? {
        if (customerName.trim().isEmpty()) {
            return "Customer name is required."
        }
        val cleanMobile = customerMobile.trim()
        val digits = cleanMobile.count { it.isDigit() }
        if (digits < 6 || cleanMobile.length > 20 || !cleanMobile.matches(Regex("^[+0-9\\s\\-()]{6,20}$"))) {
            return "Enter a valid customer mobile number (at least 6 digits)."
        }
        val values = listOf(partsCharges, serviceCharges, visitingCharges, otherCharges, discountAmount, amountReceived)
        if (values.any { it != null && it < 0.0 }) {
            return "Financial charges or payments cannot be negative."
        }
        return null
    }

    fun validateNewPayment(
        amount: Double?,
        currentRemaining: Double?,
        existingIdempotencyKeys: Set<String>,
        idempotencyKey: String
    ): String? {
        if (amount == null || !amount.isFinite() || amount <= 0.0) {
            return "Enter a payment amount greater than zero."
        }
        if (idempotencyKey.isNotBlank() && idempotencyKey in existingIdempotencyKeys) {
            return "This payment was already recorded."
        }
        if (currentRemaining != null && currentRemaining > 0.0 && amount > currentRemaining + 0.01) {
            return "Payment exceeds remaining balance (${formatInr(currentRemaining)})."
        }
        return null
    }

    fun generateInvoiceNumber(nowMillis: Long, randomSuffix: String): String {
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(nowMillis))
        val cleanSuffix = randomSuffix.filter { it.isLetterOrDigit() }.uppercase().take(4).ifBlank { "1001" }
        return "RP-$dateStr-$cleanSuffix"
    }

    fun formatInr(amount: Double?): String {
        if (amount == null) return "Not Entered"
        val rounded = round2(amount)
        return if (rounded % 1.0 == 0.0) {
            "₹${rounded.toLong()}"
        } else {
            "₹" + String.format(Locale.US, "%.2f", rounded)
        }
    }

    fun canSendReminder(
        paymentStatus: String,
        remainingBalance: Double?,
        featureEnabled: Boolean
    ): Boolean {
        if (!featureEnabled) return false
        if (paymentStatus == STATUS_FULLY_PAID || paymentStatus == STATUS_AMOUNT_NOT_ENTERED) return false
        return (remainingBalance ?: 0.0) > 0.009
    }

    fun buildReminderMessage(
        languageCode: String,
        billingConfig: BillingConfigCloud,
        customerName: String,
        invoiceNumber: String,
        applianceSummary: String,
        totalBill: Double?,
        amountReceived: Double?,
        remainingBalance: Double?,
        dueDate: String
    ): String {
        val template = billingConfig.templateFor(languageCode)
        val safeAppliance = applianceSummary.trim().ifBlank { "Appliance" }
        val safeDue = dueDate.trim().ifBlank { "As scheduled" }
        return template
            .replace("{customerName}", customerName.trim())
            .replace("{invoiceNumber}", invoiceNumber.trim())
            .replace("{appliance}", safeAppliance)
            .replace("{totalBill}", formatInr(totalBill))
            .replace("{amountReceived}", formatInr(amountReceived ?: 0.0))
            .replace("{remainingBalance}", formatInr(remainingBalance ?: 0.0))
            .replace("{dueDate}", safeDue)
    }

    fun normalizePhoneForWhatsApp(mobile: String): String {
        val trimmed = mobile.trim()
        val digitsOnly = trimmed.filter { it.isDigit() }
        if (digitsOnly.isEmpty()) return ""
        return if (trimmed.startsWith("+")) {
            digitsOnly
        } else if (digitsOnly.length == 10) {
            "91$digitsOnly"
        } else {
            digitsOnly
        }
    }

    fun buildWhatsAppUriString(mobile: String, message: String): String {
        val phone = normalizePhoneForWhatsApp(mobile)
        val encodedText = URLEncoder.encode(message, "UTF-8").replace("+", "%20")
        return "https://wa.me/$phone?text=$encodedText"
    }

    fun buildSmsUriString(mobile: String): String {
        val clean = mobile.trim().filter { it.isDigit() || it == '+' }
        return "smsto:${URLEncoder.encode(clean, "UTF-8")}"
    }

    fun round2(value: Double): Double = (value * 100.0).roundToLong() / 100.0
}
