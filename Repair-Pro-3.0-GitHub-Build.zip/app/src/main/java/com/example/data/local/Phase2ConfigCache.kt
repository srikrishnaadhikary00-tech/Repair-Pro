package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.remote.AiConfigCloud
import com.example.data.remote.BillingConfigCloud
import com.example.data.remote.MultiCloudStorageRouter
import com.example.data.remote.StorageRoutingConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.phase2ConfigDataStore: DataStore<Preferences> by preferencesDataStore(name = "repair_pro_phase2_config")

class Phase2ConfigCache(private val context: Context) {
    private object Keys {
        val AI_ENABLED = booleanPreferencesKey("ai_enabled")
        val AI_SHOW_NAV = booleanPreferencesKey("ai_show_nav")
        val AI_PROVIDER = stringPreferencesKey("ai_provider")
        val AI_MODEL = stringPreferencesKey("ai_model")
        val AI_ENDPOINT = stringPreferencesKey("ai_endpoint")
        val AI_PROXY = stringPreferencesKey("ai_proxy")
        val AI_DAILY_LIMIT = intPreferencesKey("ai_daily_limit")
        val AI_USER_LIMIT = intPreferencesKey("ai_user_limit")
        val AI_APPLIANCES_CSV = stringPreferencesKey("ai_appliances_csv")
        val AI_BRANDS_JSON = stringPreferencesKey("ai_brands_json")
        val AI_LANGS_CSV = stringPreferencesKey("ai_langs_csv")
        val AI_INSTRUCTIONS = stringPreferencesKey("ai_instructions")
        val AI_USAGE_COUNT = longPreferencesKey("ai_usage_count")
        val AI_ERROR_COUNT = longPreferencesKey("ai_error_count")
        val AI_LAST_STATUS = stringPreferencesKey("ai_last_status")
        val AI_FREE_ONLY_MODE = booleanPreferencesKey("ai_free_only_mode")
        val AI_ALLOW_PAID_FALLBACK = booleanPreferencesKey("ai_allow_paid_fallback")
        val AI_AUTO_FAILOVER = booleanPreferencesKey("ai_auto_failover")
        val AI_PROVIDERS_JSON = stringPreferencesKey("ai_providers_json")

        val BILLING_INVOICE_ENABLED = booleanPreferencesKey("billing_invoice_enabled")
        val BILLING_WHATSAPP_ENABLED = booleanPreferencesKey("billing_whatsapp_enabled")
        val BILLING_SMS_ENABLED = booleanPreferencesKey("billing_sms_enabled")
        val BILLING_TITLE = stringPreferencesKey("billing_title")
        val BILLING_TERMS = stringPreferencesKey("billing_terms")
        val BILLING_TEMPLATES_JSON = stringPreferencesKey("billing_templates_json")
        val BILLING_LANGS_CSV = stringPreferencesKey("billing_langs_csv")

        val STORAGE_AUTO_FAILOVER = booleanPreferencesKey("storage_auto_failover")
        val STORAGE_FCM_URL = stringPreferencesKey("storage_fcm_url")
        val STORAGE_HOSTING_PROXY = stringPreferencesKey("storage_hosting_proxy")
        val STORAGE_COMP_MAX_DIM = intPreferencesKey("storage_comp_max_dim")
        val STORAGE_COMP_QUALITY = intPreferencesKey("storage_comp_quality")
        val STORAGE_COMP_MAX_KB = intPreferencesKey("storage_comp_max_kb")
        val STORAGE_DEDUPE_ENABLED = booleanPreferencesKey("storage_dedupe_enabled")
        val STORAGE_PROVIDERS_JSON = stringPreferencesKey("storage_providers_json")
    }

    val cachedAiConfig: Flow<AiConfigCloud> = context.phase2ConfigDataStore.data.map { prefs ->
        AiConfigCloud(
            aiEnabled = prefs[Keys.AI_ENABLED] ?: true,
            showAiNavItem = prefs[Keys.AI_SHOW_NAV] ?: true,
            aiProvider = prefs[Keys.AI_PROVIDER] ?: "GEMINI",
            aiModel = prefs[Keys.AI_MODEL] ?: "gemini-2.5-flash",
            aiEndpointUrl = prefs[Keys.AI_ENDPOINT] ?: "",
            aiProxyEndpoint = prefs[Keys.AI_PROXY] ?: AiConfigCloud.DEFAULT_AI_PROXY_URL,
            aiDailyLimit = prefs[Keys.AI_DAILY_LIMIT] ?: 500,
            aiPerUserLimit = prefs[Keys.AI_USER_LIMIT] ?: 15,
            aiSupportedAppliances = prefs[Keys.AI_APPLIANCES_CSV]
                ?.split("|")?.map { it.trim() }?.filter { it.isNotEmpty() }
                ?.takeIf { it.isNotEmpty() } ?: AiConfigCloud.DEFAULT_APPLIANCES,
            aiBrandsModelsJson = prefs[Keys.AI_BRANDS_JSON] ?: AiConfigCloud.DEFAULT_BRANDS_JSON,
            aiSupportedLanguages = prefs[Keys.AI_LANGS_CSV]
                ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }
                ?.takeIf { it.isNotEmpty() } ?: listOf("en", "bn", "hi"),
            aiSystemInstructions = prefs[Keys.AI_INSTRUCTIONS] ?: "",
            aiUsageCount = prefs[Keys.AI_USAGE_COUNT] ?: 0L,
            aiErrorCount = prefs[Keys.AI_ERROR_COUNT] ?: 0L,
            aiLastStatus = prefs[Keys.AI_LAST_STATUS] ?: "READY",
            aiFreeOnlyMode = prefs[Keys.AI_FREE_ONLY_MODE] ?: true,
            aiAllowPaidFallback = prefs[Keys.AI_ALLOW_PAID_FALLBACK] ?: false,
            aiAutoFailoverEnabled = prefs[Keys.AI_AUTO_FAILOVER] ?: true,
            aiProvidersJson = prefs[Keys.AI_PROVIDERS_JSON] ?: AiConfigCloud.DEFAULT_AI_PROVIDERS_JSON
        )
    }

    val cachedBillingConfig: Flow<BillingConfigCloud> = context.phase2ConfigDataStore.data.map { prefs ->
        BillingConfigCloud(
            invoiceEnabled = prefs[Keys.BILLING_INVOICE_ENABLED] ?: true,
            whatsappReminderEnabled = prefs[Keys.BILLING_WHATSAPP_ENABLED] ?: true,
            smsReminderEnabled = prefs[Keys.BILLING_SMS_ENABLED] ?: true,
            invoiceBusinessTitle = prefs[Keys.BILLING_TITLE] ?: "Repair Pro Service Invoice",
            invoiceTermsNote = prefs[Keys.BILLING_TERMS] ?: BillingConfigCloud().invoiceTermsNote,
            reminderTemplatesJson = prefs[Keys.BILLING_TEMPLATES_JSON] ?: BillingConfigCloud.DEFAULT_TEMPLATES_JSON,
            billingSupportedLanguages = prefs[Keys.BILLING_LANGS_CSV]
                ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }
                ?.takeIf { it.isNotEmpty() } ?: listOf("en", "bn", "hi")
        )
    }

    val cachedStorageConfig: Flow<StorageRoutingConfig> = context.phase2ConfigDataStore.data.map { prefs ->
        MultiCloudStorageRouter.parseRoutingConfig(
            autoFailoverEnabled = prefs[Keys.STORAGE_AUTO_FAILOVER] ?: true,
            fcmBackendUrl = prefs[Keys.STORAGE_FCM_URL] ?: "",
            providersJson = prefs[Keys.STORAGE_PROVIDERS_JSON] ?: "",
            hostingProxyUrl = prefs[Keys.STORAGE_HOSTING_PROXY] ?: MultiCloudStorageRouter.DEFAULT_HOSTING_PROXY_URL,
            compressionMaxDim = prefs[Keys.STORAGE_COMP_MAX_DIM] ?: 1440,
            compressionQuality = prefs[Keys.STORAGE_COMP_QUALITY] ?: 82,
            compressionMaxSizeKb = prefs[Keys.STORAGE_COMP_MAX_KB] ?: 4500,
            duplicateCheckEnabled = prefs[Keys.STORAGE_DEDUPE_ENABLED] ?: true
        )
    }

    suspend fun saveAiConfig(config: AiConfigCloud) {
        context.phase2ConfigDataStore.edit { prefs ->
            prefs[Keys.AI_ENABLED] = config.aiEnabled
            prefs[Keys.AI_SHOW_NAV] = config.showAiNavItem
            prefs[Keys.AI_PROVIDER] = config.aiProvider
            prefs[Keys.AI_MODEL] = config.aiModel
            prefs[Keys.AI_ENDPOINT] = config.aiEndpointUrl
            prefs[Keys.AI_PROXY] = config.effectiveProxyUrl()
            prefs[Keys.AI_DAILY_LIMIT] = config.aiDailyLimit
            prefs[Keys.AI_USER_LIMIT] = config.aiPerUserLimit
            prefs[Keys.AI_APPLIANCES_CSV] = config.aiSupportedAppliances.joinToString("|")
            prefs[Keys.AI_BRANDS_JSON] = config.aiBrandsModelsJson
            prefs[Keys.AI_LANGS_CSV] = config.aiSupportedLanguages.joinToString(",")
            prefs[Keys.AI_INSTRUCTIONS] = config.aiSystemInstructions
            prefs[Keys.AI_USAGE_COUNT] = config.aiUsageCount
            prefs[Keys.AI_ERROR_COUNT] = config.aiErrorCount
            prefs[Keys.AI_LAST_STATUS] = config.aiLastStatus
            prefs[Keys.AI_FREE_ONLY_MODE] = config.aiFreeOnlyMode
            prefs[Keys.AI_ALLOW_PAID_FALLBACK] = config.aiAllowPaidFallback
            prefs[Keys.AI_AUTO_FAILOVER] = config.aiAutoFailoverEnabled
            prefs[Keys.AI_PROVIDERS_JSON] = config.aiProvidersJson
        }
    }

    suspend fun saveBillingConfig(config: BillingConfigCloud) {
        context.phase2ConfigDataStore.edit { prefs ->
            prefs[Keys.BILLING_INVOICE_ENABLED] = config.invoiceEnabled
            prefs[Keys.BILLING_WHATSAPP_ENABLED] = config.whatsappReminderEnabled
            prefs[Keys.BILLING_SMS_ENABLED] = config.smsReminderEnabled
            prefs[Keys.BILLING_TITLE] = config.invoiceBusinessTitle
            prefs[Keys.BILLING_TERMS] = config.invoiceTermsNote
            prefs[Keys.BILLING_TEMPLATES_JSON] = config.reminderTemplatesJson
            prefs[Keys.BILLING_LANGS_CSV] = config.billingSupportedLanguages.joinToString(",")
        }
    }

    suspend fun saveStorageConfig(config: StorageRoutingConfig, rawProvidersJson: String) {
        context.phase2ConfigDataStore.edit { prefs ->
            prefs[Keys.STORAGE_AUTO_FAILOVER] = config.autoFailoverEnabled
            prefs[Keys.STORAGE_FCM_URL] = config.fcmBackendUrl
            prefs[Keys.STORAGE_HOSTING_PROXY] = config.hostingProxyUrl
            prefs[Keys.STORAGE_COMP_MAX_DIM] = config.compressionMaxDim
            prefs[Keys.STORAGE_COMP_QUALITY] = config.compressionQuality
            prefs[Keys.STORAGE_COMP_MAX_KB] = config.compressionMaxSizeKb
            prefs[Keys.STORAGE_DEDUPE_ENABLED] = config.duplicateCheckEnabled
            if (rawProvidersJson.isNotBlank()) {
                prefs[Keys.STORAGE_PROVIDERS_JSON] = rawProvidersJson
            }
        }
    }
}
