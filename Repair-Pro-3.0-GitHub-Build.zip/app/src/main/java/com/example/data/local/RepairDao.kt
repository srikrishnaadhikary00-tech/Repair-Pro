package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RepairDao {

    @Query("SELECT * FROM appliance_categories ORDER BY id ASC")
    fun observeCategories(): Flow<List<ApplianceCategoryEntity>>

    @Query("SELECT COUNT(*) FROM appliance_categories")
    suspend fun countCategories(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCategories(categories: List<ApplianceCategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCategory(category: ApplianceCategoryEntity)

    @Query("SELECT * FROM brands ORDER BY popular DESC, name ASC")
    fun observeAllBrands(): Flow<List<BrandEntity>>

    @Query("SELECT * FROM brands WHERE categoryId = :categoryId ORDER BY popular DESC, name ASC")
    fun observeBrandsByCategory(categoryId: String): Flow<List<BrandEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBrands(brands: List<BrandEntity>)

    @Query("SELECT * FROM error_codes ORDER BY code ASC")
    fun observeAllErrorCodes(): Flow<List<ErrorCodeEntity>>

    @Query("SELECT * FROM error_codes WHERE categoryId = :categoryId ORDER BY code ASC")
    fun observeErrorCodesByCategory(categoryId: String): Flow<List<ErrorCodeEntity>>

    @Query("SELECT * FROM error_codes WHERE id = :id LIMIT 1")
    suspend fun getErrorCodeById(id: String): ErrorCodeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertErrorCodes(codes: List<ErrorCodeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertErrorCode(code: ErrorCodeEntity)

    @Query("DELETE FROM error_codes WHERE id = :id")
    suspend fun deleteErrorCode(id: String)

    @Query("SELECT * FROM problem_guides ORDER BY updatedAt DESC")
    fun observeAllProblems(): Flow<List<ProblemGuideEntity>>

    @Query("SELECT * FROM problem_guides WHERE categoryId = :categoryId ORDER BY updatedAt DESC")
    fun observeProblemsByCategory(categoryId: String): Flow<List<ProblemGuideEntity>>

    @Query("SELECT * FROM problem_guides WHERE id = :id LIMIT 1")
    suspend fun getProblemById(id: String): ProblemGuideEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProblems(problems: List<ProblemGuideEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProblem(problem: ProblemGuideEntity)

    @Query("DELETE FROM problem_guides WHERE id = :id")
    suspend fun deleteProblem(id: String)

    @Query("SELECT * FROM search_history ORDER BY timestamp DESC LIMIT 12")
    fun observeSearchHistory(): Flow<List<SearchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSearchHistory(entry: SearchHistoryEntity)

    @Query("DELETE FROM search_history")
    suspend fun clearSearchHistory()

    @Query("SELECT * FROM offline_packages ORDER BY categoryId ASC")
    fun observeOfflinePackages(): Flow<List<OfflinePackageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOfflinePackages(packages: List<OfflinePackageEntity>)

    @Query("UPDATE offline_packages SET downloaded = :downloaded, lastUpdatedAt = :updatedAt, version = version + 1 WHERE categoryId = :categoryId")
    suspend fun updatePackageStatus(categoryId: String, downloaded: Boolean, updatedAt: Long)

    @Query("SELECT COUNT(*) FROM error_codes WHERE categoryId = :categoryId")
    suspend fun countErrorCodesForCategory(categoryId: String): Int

    @Query("SELECT COUNT(*) FROM problem_guides WHERE categoryId = :categoryId")
    suspend fun countProblemsForCategory(categoryId: String): Int

    @Query("SELECT * FROM downloaded_documents ORDER BY downloadedAt DESC")
    fun observeDownloadedDocuments(): Flow<List<DownloadedDocumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDownloadedDocument(doc: DownloadedDocumentEntity)

    @Query("DELETE FROM downloaded_documents WHERE docId = :docId")
    suspend fun deleteDownloadedDocument(docId: String)
}
