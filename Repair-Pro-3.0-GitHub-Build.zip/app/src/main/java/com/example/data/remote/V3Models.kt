package com.example.data.remote

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class CommunityPostItem(
    @DocumentId val id: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val categoryId: String = "ac",
    val title: String = "",
    val body: String = "",
    val photoUrls: List<String> = emptyList(),
    val moderationStatus: String = "APPROVED",
    val rejectionReason: String = "",
    val verifiedTechnician: Boolean = false,
    val likesCount: Long = 0L,
    val commentsCount: Long = 0L,
    val likedByUids: List<String> = emptyList(),
    val savedByUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CommunityCommentItem(
    @DocumentId val id: String = "",
    val postId: String = "",
    val parentCommentId: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val verifiedTechnician: Boolean = false,
    val body: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class TechnicianProfileItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val profilePhotoUrl: String = "",
    val publicPhone: String = "",
    val serviceDetails: String = "",
    val experienceYears: Long = 1L,
    val serviceLocation: String = "",
    val city: String = "",
    val applianceCategories: List<String> = listOf("ac"),
    val approvalStatus: String = "PENDING",
    val verified: Boolean = false,
    val active: Boolean = true,
    val blocked: Boolean = false,
    val adminNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class RepairDocumentItem(
    @DocumentId val id: String = "",
    val docType: String = "PDF", // PDF | CIRCUIT_DIAGRAM | SERVICE_MANUAL
    val categoryId: String = "ac",
    val brandName: String = "Universal",
    val modelName: String = "",
    val errorCode: String = "",
    val title: String = "",
    val description: String = "",
    val fileUrl: String = "",
    val mimeType: String = "application/pdf",
    val fileSizeBytes: Long = 0L,
    val storageProviderId: String = "",
    val published: Boolean = true,
    val uploadedByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PushNotificationItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val body: String = "",
    val targetType: String = "ALL", // ALL | SELECTED | TECHNICIANS
    val targetUids: List<String> = emptyList(),
    val sentByUid: String = "",
    val sentByEmail: String = "",
    val totalTargeted: Long = 0L,
    val successCount: Long = 0L,
    val failureCount: Long = 0L,
    val deliveryStatus: String = "SENT",
    val errorMessage: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class StorageProviderItem(
    @DocumentId val id: String = "",
    val name: String = "",
    val providerType: String = "SUPABASE", // SUPABASE | CLOUDFLARE_R2 | BACKBLAZE_B2 | CUSTOM_S3
    val endpointUrl: String = "",
    val projectRef: String = "",
    val region: String = "auto",
    val publicBaseUrl: String = "",
    val secretEnvKey: String = "SUPABASE_SERVICE_ROLE_KEY",
    val secretConfigured: Boolean? = null,
    val activeFilesCount: Int = 0,
    val primary: Boolean = false,
    val backup: Boolean = false,
    val enabled: Boolean = true,
    val autoFailoverEnabled: Boolean = true,
    val capacityBytes: Long = 1073741824L,
    val usedBytes: Long = 0L,
    val lastTestStatus: String = "UNTESTED",
    val lastTestMessage: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SystemErrorLogItem(
    @DocumentId val id: String = "",
    val source: String = "",
    val severity: String = "ERROR",
    val message: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class BackendConnectionStatus(
    val firebaseConnected: Boolean = true,
    val supabaseConfigured: Boolean = false,
    val supabaseReachable: Boolean = false,
    val supabaseMessage: String = "Checking Supabase Repair-Pro (xuakzzjtcgcvudkgxpbd)..."
)
