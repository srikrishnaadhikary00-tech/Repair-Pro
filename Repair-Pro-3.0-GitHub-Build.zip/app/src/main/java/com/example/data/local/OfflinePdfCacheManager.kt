package com.example.data.local

import android.content.Context
import com.example.data.remote.MultiCloudStorageRouter
import com.example.data.remote.TechnicalDocumentCloud
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Stores ONLY admin-approved PDF manuals marked `published && offlineAvailable && !isDeleted`.
 * Never stores verification documents or private credentials offline.
 */
class OfflinePdfCacheManager(private val cacheRootDir: File) {

    constructor(context: Context) : this(File(context.filesDir, "offline_pdfs"))

    private fun safeId(docId: String): String =
        docId.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(128)

    fun isDocumentEligibleForOffline(doc: TechnicalDocumentCloud): Boolean {
        val id = doc.docId.ifBlank { doc.id }
        return id.isNotBlank() &&
            doc.docType == "PDF_MANUAL" &&
            doc.published &&
            doc.offlineAvailable &&
            !doc.isDeleted &&
            doc.fileUrl.startsWith("https://") &&
            !doc.storagePath.contains("verification-documents", ignoreCase = true)
    }

    fun getCachedPdfFile(docId: String): File? {
        val clean = safeId(docId)
        if (clean.isBlank()) return null
        val target = File(cacheRootDir, "$clean.pdf")
        return target.takeIf { it.exists() && it.length() > 0L }
    }

    fun getCachedDocIds(): Set<String> {
        val files = cacheRootDir.listFiles() ?: return emptySet()
        return files.filter { it.isFile && it.name.endsWith(".pdf") && it.length() > 0L }
            .map { it.name.removeSuffix(".pdf") }
            .toSet()
    }

    /**
     * Removes any locally cached PDF whose admin metadata was unpublished, soft-deleted,
     * permanently deleted, or marked `offlineAvailable = false`.
     */
    suspend fun syncWithApprovedDocuments(docs: List<TechnicalDocumentCloud>): Set<String> = withContext(Dispatchers.IO) {
        if (!cacheRootDir.exists()) return@withContext emptySet()
        val allowedIds = docs
            .filter { isDocumentEligibleForOffline(it) }
            .map { safeId(it.docId.ifBlank { it.id }) }
            .toSet()

        cacheRootDir.listFiles()?.forEach { file ->
            if (file.isFile) {
                if (file.name.endsWith(".tmp")) {
                    file.delete()
                } else if (file.name.endsWith(".pdf")) {
                    val id = file.name.removeSuffix(".pdf")
                    if (id !in allowedIds) {
                        file.delete()
                    }
                }
            }
        }
        getCachedDocIds()
    }

    suspend fun downloadAndSaveAtomic(
        doc: TechnicalDocumentCloud,
        storageRouter: MultiCloudStorageRouter
    ): Result<File> = withContext(Dispatchers.IO) {
        if (!isDocumentEligibleForOffline(doc)) {
            return@withContext Result.failure(IllegalStateException("This manual is not enabled for offline storage by administrator."))
        }
        val docId = safeId(doc.docId.ifBlank { doc.id })
        if (!cacheRootDir.exists()) cacheRootDir.mkdirs()

        val tmpFile = File(cacheRootDir, "$docId.pdf.tmp")
        val finalFile = File(cacheRootDir, "$docId.pdf")
        return@withContext try {
            val bytes = storageRouter.downloadAuthorizedBytes(doc.fileUrl).getOrThrow()
            val isPdf = bytes.size >= 5 &&
                bytes[0] == '%'.code.toByte() && bytes[1] == 'P'.code.toByte() &&
                bytes[2] == 'D'.code.toByte() && bytes[3] == 'F'.code.toByte()
            if (!isPdf) {
                throw IllegalStateException("Downloaded file is not a valid PDF.")
            }
            tmpFile.writeBytes(bytes)
            if (finalFile.exists()) finalFile.delete()
            if (!tmpFile.renameTo(finalFile)) {
                tmpFile.copyTo(finalFile, overwrite = true)
                tmpFile.delete()
            }
            Result.success(finalFile)
        } catch (e: Exception) {
            runCatching { tmpFile.delete() }
            Result.failure(e)
        }
    }

    suspend fun removeCachedDocument(docId: String) = withContext(Dispatchers.IO) {
        val clean = safeId(docId)
        if (clean.isBlank()) return@withContext
        runCatching { File(cacheRootDir, "$clean.pdf").delete() }
        runCatching { File(cacheRootDir, "$clean.pdf.tmp").delete() }
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        cacheRootDir.listFiles()?.forEach { runCatching { it.delete() } }
    }
}
