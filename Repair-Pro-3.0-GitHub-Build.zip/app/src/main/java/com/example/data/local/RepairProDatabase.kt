package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ApplianceCategoryEntity::class,
        BrandEntity::class,
        ErrorCodeEntity::class,
        ProblemGuideEntity::class,
        SearchHistoryEntity::class,
        OfflinePackageEntity::class,
        DownloadedDocumentEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class RepairProDatabase : RoomDatabase() {
    abstract fun repairDao(): RepairDao

    companion object {
        @Volatile
        private var INSTANCE: RepairProDatabase? = null

        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `downloaded_documents` (
                        `docId` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `docType` TEXT NOT NULL,
                        `categoryId` TEXT NOT NULL,
                        `brandName` TEXT NOT NULL,
                        `modelName` TEXT NOT NULL,
                        `localFilePath` TEXT NOT NULL,
                        `mimeType` TEXT NOT NULL,
                        `fileSizeBytes` INTEGER NOT NULL,
                        `downloadedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`docId`)
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): RepairProDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RepairProDatabase::class.java,
                    "repair_pro_offline.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
