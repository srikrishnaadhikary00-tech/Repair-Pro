package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ApplianceCategoryEntity::class,
        BrandEntity::class,
        ErrorCodeEntity::class,
        ProblemGuideEntity::class,
        SearchHistoryEntity::class,
        OfflinePackageEntity::class,
        CustomerEntity::class,
        InvoiceEntity::class,
        InvoicePaymentEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class RepairProDatabase : RoomDatabase() {
    abstract fun repairDao(): RepairDao
    abstract fun billingDao(): BillingDao

    companion object {
        @Volatile
        private var INSTANCE: RepairProDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `customers` (
                        `customerId` TEXT NOT NULL,
                        `technicianUid` TEXT NOT NULL,
                        `name` TEXT NOT NULL,
                        `mobileNumber` TEXT NOT NULL,
                        `address` TEXT NOT NULL,
                        `notes` TEXT NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        `createdAtMillis` INTEGER NOT NULL,
                        `updatedAtMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`customerId`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_customers_technicianUid` ON `customers` (`technicianUid`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_customers_technicianUid_mobileNumber` ON `customers` (`technicianUid`, `mobileNumber`)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `invoices` (
                        `invoiceId` TEXT NOT NULL,
                        `invoiceNumber` TEXT NOT NULL,
                        `technicianUid` TEXT NOT NULL,
                        `customerId` TEXT NOT NULL,
                        `customerName` TEXT NOT NULL,
                        `customerMobile` TEXT NOT NULL,
                        `customerAddress` TEXT NOT NULL,
                        `applianceCategory` TEXT NOT NULL,
                        `applianceBrand` TEXT NOT NULL,
                        `modelNumber` TEXT NOT NULL,
                        `serialNumber` TEXT NOT NULL,
                        `reportedProblem` TEXT NOT NULL,
                        `workDone` TEXT NOT NULL,
                        `partsUsed` TEXT NOT NULL,
                        `partsQuantity` INTEGER NOT NULL,
                        `partsCharges` REAL,
                        `serviceCharges` REAL,
                        `visitingCharges` REAL,
                        `otherCharges` REAL,
                        `discountAmount` REAL,
                        `totalBill` REAL,
                        `amountReceived` REAL,
                        `remainingBalance` REAL,
                        `paymentStatus` TEXT NOT NULL,
                        `paymentMethod` TEXT NOT NULL,
                        `paymentDueDate` TEXT NOT NULL,
                        `warrantyInfo` TEXT NOT NULL,
                        `notes` TEXT NOT NULL,
                        `reminderDate` TEXT NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        `createdAtMillis` INTEGER NOT NULL,
                        `updatedAtMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`invoiceId`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoices_technicianUid` ON `invoices` (`technicianUid`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoices_technicianUid_customerId` ON `invoices` (`technicianUid`, `customerId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoices_technicianUid_paymentStatus` ON `invoices` (`technicianUid`, `paymentStatus`)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `invoice_payments` (
                        `paymentId` TEXT NOT NULL,
                        `invoiceId` TEXT NOT NULL,
                        `technicianUid` TEXT NOT NULL,
                        `amount` REAL NOT NULL,
                        `paymentMethod` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `idempotencyKey` TEXT NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        `paidAtMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`paymentId`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoice_payments_technicianUid` ON `invoice_payments` (`technicianUid`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoice_payments_invoiceId` ON `invoice_payments` (`invoiceId`)")
            }
        }

        fun getInstance(context: Context): RepairProDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RepairProDatabase::class.java,
                    "repair_pro_offline.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
