package com.example.data.remote

import android.content.Context
import com.example.BuildConfig
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID

class V2CloudRepository(
    private val auth: FirebaseAuth = Firebase.auth,
    private val supabaseClient: SupabaseClient = SupabaseClient(
        firebaseTokenProvider = { forceRefresh ->
            runCatching { auth.currentUser?.getIdToken(forceRefresh)?.await()?.token }.getOrNull()
        }
    ),
    internal val storageRouter: MultiCloudStorageRouter = MultiCloudStorageRouter(
        authProvider = { auth },
        supabaseClientOverride = supabaseClient
    ),
    private val httpClient: OkHttpClient = SupabaseClient.defaultHttpClient()
) {
    constructor(context: Context) : this()

    private val verificationTick = MutableStateFlow(0L)
    private val docsTick = MutableStateFlow(0L)
    private val notificationsTick = MutableStateFlow(0L)
    private val announcementsTick = MutableStateFlow(0L)
    private val restrictionsTick = MutableStateFlow(0L)

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Please sign in with Google first.")
    }

    private fun <T> pollFlow(
        trigger: StateFlow<Long>,
        intervalMs: Long = 25_000L,
        op: OperationType,
        path: String,
        expectedUid: String,
        loader: suspend () -> T
    ): Flow<T> = flow {
        val ticker = flow {
            var count = 0L
            while (true) {
                emit(count++)
                delay(intervalMs)
            }
        }
        combine(trigger, ticker) { t, c -> t to c }.collect {
            try {
                emit(loader())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (auth.currentUser?.uid == expectedUid) {
                    handleCloudError(e, op, path)
                }
            }
        }
    }

    // =========================================================================
    // 1. TECHNICIAN VERIFICATION SYSTEM
    // =========================================================================

    fun observeMyVerificationRequest(userId: String): Flow<TechnicianVerificationRequestCloud?> {
        val encUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = verificationTick,
            intervalMs = 25_000L,
            op = OperationType.GET,
            path = "technician_verification_requests/$userId",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "technician_verification_requests",
                categoryKey = "verification",
                supabaseQueryParams = "user_id=eq.$encUid&select=*&limit=1",
                supabaseRequireAuth = true,
                extFilters = mapOf("user_id" to userId),
                extLimit = 1,
                pkColumns = listOf("user_id", "id")
            ).getOrThrow()
            arr.optJSONObject(0)?.let { SupabaseMappers.toVerificationRequest(it) }
        }
    }

    fun observeAllVerificationRequestsForAdmin(adminUid: String): Flow<List<TechnicianVerificationRequestCloud>> {
        return pollFlow(
            trigger = verificationTick,
            intervalMs = 20_000L,
            op = OperationType.LIST,
            path = "technician_verification_requests",
            expectedUid = adminUid
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "technician_verification_requests",
                categoryKey = "verification",
                supabaseQueryParams = "select=*&order=updated_at.desc",
                supabaseRequireAuth = true,
                extLimit = 200,
                extOrderBy = "updated_at",
                pkColumns = listOf("user_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toVerificationRequest(it) }
                .sortedByDescending { it.updatedAt?.seconds ?: 0L }
        }
    }

    suspend fun uploadVerificationFile(
        userId: String,
        prefix: String,
        bytes: ByteArray,
        mimeType: String,
        onProgress: (Float) -> Unit = {}
    ): Result<Pair<String, String>> =
        uploadVerificationFileWithResult(userId, prefix, bytes, mimeType, onProgress)
            .map { it.publicUrl to it.storagePath }

    suspend fun uploadVerificationFileWithResult(
        userId: String,
        prefix: String,
        bytes: ByteArray,
        mimeType: String,
        onProgress: (Float) -> Unit = {}
    ): Result<MultiCloudUploadResult> {
        val cleanMime = when (mimeType.lowercase()) {
            "application/pdf" -> "application/pdf"
            "image/png" -> "image/png"
            "image/webp" -> "image/webp"
            else -> "image/jpeg"
        }
        val ext = when (cleanMime) {
            "application/pdf" -> "pdf"
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        // Public technician avatars route to "technicians" (technician-photos public bucket)
        // Private credential documents route to "verification" (verification-documents private bucket)
        val isPublicAvatar = prefix.startsWith("avatar", ignoreCase = true) ||
            prefix.startsWith("profile", ignoreCase = true)
        val bucketKey = if (isPublicAvatar) "technicians" else "verification"
        val maxSizeBytes = if (isPublicAvatar) 5 * 1024 * 1024 else 10 * 1024 * 1024
        val objectPath = "$userId/${prefix}_${System.currentTimeMillis()}.$ext"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            require(bytes.isNotEmpty() && bytes.size < maxSizeBytes) {
                if (isPublicAvatar) "Profile photo must be smaller than 5 MB." else "Credential file must be smaller than 10 MB."
            }
            storageRouter.uploadBytes(
                bucketKey = bucketKey,
                objectPath = objectPath,
                bytes = bytes,
                mimeType = cleanMime,
                onProgress = onProgress
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitVerificationRequest(
        userId: String,
        request: TechnicianVerificationRequestCloud
    ): Result<Unit> {
        val path = "technician_verification_requests/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val err = V2DomainHelper.validateVerificationApplication(
                fullName = request.fullName,
                mobileNumber = request.mobileNumber,
                fullAddress = request.fullAddress,
                state = request.state,
                district = request.district,
                cityArea = request.cityArea,
                pinCode = request.pinCode,
                serviceCategories = request.serviceCategories
            )
            require(err == null) { err ?: "Invalid verification details." }

            val cleanCats = request.serviceCategories.filter { it in V2DomainHelper.ALLOWED_SERVICE_CATEGORIES }.distinct()
            val payload = JSONObject()
                .put("user_id", userId)
                .put("full_name", request.fullName.trim().take(100))
                .put("mobile_number", request.mobileNumber.trim().take(20))
                .put("full_address", request.fullAddress.trim().take(300))
                .put("state", request.state.trim().take(80))
                .put("district", request.district.trim().take(80))
                .put("city_area", request.cityArea.trim().take(80))
                .put("pin_code", request.pinCode.trim().take(12))
                .put("service_categories", JSONArray(cleanCats))
                .put("experience", request.experience.trim().take(80))
                .put("bio", request.bio.trim().take(600))
                .put("profile_photo_url", request.profilePhotoUrl.trim().takeIf { it.startsWith("https://") } ?: "")
                .put("profile_photo_storage_path", request.profilePhotoStoragePath.trim().take(320))
                .put("profile_photo_provider_id", request.profilePhotoProviderId.trim().take(80))
                .put("credential_doc_url", request.credentialDocUrl.trim().takeIf { it.startsWith("https://") } ?: "")
                .put("credential_doc_storage_path", request.credentialDocStoragePath.trim().take(320))
                .put("credential_doc_provider_id", request.credentialDocProviderId.trim().take(80))
                .put("credential_doc_name", request.credentialDocName.trim().take(140))
                .put("status", "PENDING")
                .put("updated_at", CloudTimestamp.toIsoString())

            storageRouter.writeRowWithFailover(
                tableName = "technician_verification_requests",
                categoryKey = "verification",
                payload = payload,
                onConflict = "user_id",
                mirrorIfActiveExternal = true
            ).getOrThrow()
            verificationTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun adminReviewVerificationRequest(
        request: TechnicianVerificationRequestCloud,
        newStatus: String,
        rejectionReason: String
    ): Result<Unit> {
        val targetUid = CloudRepository.sanitizeId(request.userId.ifBlank { request.id })
        val cleanStatus = when (newStatus) {
            "VERIFIED", "REJECTED", "SUSPENDED", "PENDING" -> newStatus
            else -> "PENDING"
        }
        val path = "technician_verification_requests/$targetUid"
        return try {
            val adminUid = requireUserId()
            val encTargetUid = URLEncoder.encode(targetUid, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "technician_verification_requests",
                categoryKey = "verification",
                recordId = targetUid,
                supabaseFilterQuery = "user_id=eq.$encTargetUid",
                patchJson = JSONObject()
                    .put("status", cleanStatus)
                    .put("rejection_reason", rejectionReason.trim().take(500))
                    .put("reviewed_by_uid", adminUid)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()

            val techId = CloudRepository.sanitizeId("vtech_$targetUid")
            val encTechId = URLEncoder.encode(techId, "UTF-8")
            val isVerified = cleanStatus == "VERIFIED"
            val isSuspended = cleanStatus == "SUSPENDED"
            val existingTechArr = storageRouter.readMergedRows(
                tableName = "technicians",
                categoryKey = "technicians",
                supabaseQueryParams = "technician_id=eq.$encTechId&select=technician_id&limit=1",
                supabaseRequireAuth = true,
                extFilters = mapOf("technician_id" to techId),
                extLimit = 1,
                pkColumns = listOf("technician_id", "id")
            ).getOrNull()
            val techExists = existingTechArr != null && existingTechArr.length() > 0

            if (isVerified) {
                val cleanCats = request.serviceCategories.filter { it in V2DomainHelper.ALLOWED_SERVICE_CATEGORIES }
                    .ifEmpty { listOf("AC") }
                val cleanPhotoUrl = request.profilePhotoUrl.trim().takeIf { it.startsWith("https://") } ?: ""
                val techPayload = JSONObject()
                    .put("technician_id", techId)
                    .put("full_name", request.fullName.trim().take(100))
                    .put("mobile_number", request.mobileNumber.trim().take(20))
                    .put("full_address", request.fullAddress.trim().take(300))
                    .put("state", request.state.trim().take(80))
                    .put("district", request.district.trim().take(80))
                    .put("city_area", request.cityArea.trim().take(80))
                    .put("pin_code", request.pinCode.trim().take(12))
                    .put("service_categories", JSONArray(cleanCats))
                    .put("experience", request.experience.trim().take(80))
                    .put("bio", request.bio.trim().take(600))
                    .put("photo_url", cleanPhotoUrl)
                    .put("photo_storage_path", request.profilePhotoStoragePath.trim().take(320))
                    .put("photo_provider_id", request.profilePhotoProviderId.trim().ifBlank { "supabase_primary" })
                    .put("verification_status", "VERIFIED")
                    .put("blocked", false)
                    .put("is_suspended", false)
                    .put("is_deleted", false)
                    .put("linked_user_uid", targetUid)
                    .put("status", "ACTIVE")
                    .put("updated_by_uid", adminUid)
                    .put("updated_at", CloudTimestamp.toIsoString())
                storageRouter.writeRowWithFailover(
                    tableName = "technicians",
                    categoryKey = "technicians",
                    payload = techPayload,
                    onConflict = "technician_id",
                    mirrorIfActiveExternal = true
                ).getOrThrow()
            } else if (techExists) {
                storageRouter.patchRowWithFailover(
                    tableName = "technicians",
                    categoryKey = "technicians",
                    recordId = techId,
                    supabaseFilterQuery = "technician_id=eq.$encTechId",
                    patchJson = JSONObject()
                        .put("verification_status", cleanStatus)
                        .put("blocked", isSuspended)
                        .put("is_suspended", isSuspended)
                        .put("status", "INACTIVE")
                        .put("updated_by_uid", adminUid)
                        .put("updated_at", CloudTimestamp.toIsoString())
                ).getOrThrow()
            }

            runCatching {
                storageRouter.patchRowWithFailover(
                    tableName = "user_profiles",
                    categoryKey = "user_profiles",
                    recordId = targetUid,
                    supabaseFilterQuery = "user_id=eq.$encTargetUid",
                    patchJson = JSONObject()
                        .put("is_verified_technician", isVerified)
                        .put("updated_at", CloudTimestamp.toIsoString())
                )
            }

            val notifType = when (cleanStatus) {
                "VERIFIED" -> "VERIFICATION_APPROVED"
                "SUSPENDED" -> "VERIFICATION_SUSPENDED"
                else -> "VERIFICATION_REJECTED"
            }
            val notifTitle = when (cleanStatus) {
                "VERIFIED" -> "Technician Verification Approved"
                "SUSPENDED" -> "Technician Account Suspended"
                else -> "Verification Application Update"
            }
            val notifBody = when (cleanStatus) {
                "VERIFIED" -> "Your Verified Technician badge is now active in Repair Pro directory and community."
                "SUSPENDED" -> "Your verified technician status has been suspended.${if (rejectionReason.isNotBlank()) " Reason: ${rejectionReason.trim()}" else ""}"
                else -> "Your verification request was not approved.${if (rejectionReason.isNotBlank()) " Reason: ${rejectionReason.trim()}" else " Please review your details and resubmit."}"
            }
            sendUserNotification(
                recipientUid = targetUid,
                actorUid = adminUid,
                type = notifType,
                title = notifTitle,
                body = notifBody,
                targetRoute = "verification"
            )

            logAdminAction(
                adminUid,
                "REVIEW_TECHNICIAN_VERIFICATION",
                "technician_verification_requests",
                targetUid,
                "${request.fullName} -> $cleanStatus"
            )
            verificationTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // =========================================================================
    // 2. ONLINE TECHNICAL DOCUMENTS (PDF MANUALS, CIRCUIT DIAGRAMS, PHOTOS)
    // =========================================================================

    fun observePublishedTechnicalDocuments(userId: String): Flow<List<TechnicalDocumentCloud>> {
        return pollFlow(
            trigger = docsTick,
            intervalMs = 35_000L,
            op = OperationType.LIST,
            path = "technical_documents",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "technical_documents",
                categoryKey = "pdfs",
                supabaseQueryParams = "published=eq.true&is_deleted=eq.false&select=*&order=updated_at.desc",
                supabaseRequireAuth = false,
                extLimit = 250,
                extOrderBy = "updated_at",
                pkColumns = listOf("doc_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toTechnicalDocument(it) }
                .filter { it.published && !it.isDeleted }
                .sortedByDescending { it.updatedAt?.seconds ?: 0L }
        }
    }

    fun observeAllTechnicalDocumentsForAdmin(adminUid: String): Flow<List<TechnicalDocumentCloud>> {
        return pollFlow(
            trigger = docsTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "technical_documents",
            expectedUid = adminUid
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "technical_documents",
                categoryKey = "pdfs",
                supabaseQueryParams = "select=*&order=updated_at.desc",
                supabaseRequireAuth = true,
                extLimit = 300,
                extOrderBy = "updated_at",
                pkColumns = listOf("doc_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toTechnicalDocument(it) }
                .sortedByDescending { it.updatedAt?.seconds ?: 0L }
        }
    }

    suspend fun uploadRepairMedia(
        categoryId: String,
        prefix: String,
        bytes: ByteArray,
        mimeType: String,
        onProgress: (Float) -> Unit = {}
    ): Result<Pair<String, String>> =
        uploadRepairMediaWithResult(categoryId, prefix, bytes, mimeType, onProgress)
            .map { it.publicUrl to it.storagePath }

    suspend fun uploadRepairMediaWithResult(
        categoryId: String,
        prefix: String,
        bytes: ByteArray,
        mimeType: String,
        onProgress: (Float) -> Unit = {}
    ): Result<MultiCloudUploadResult> {
        val cleanCat = if (categoryId in V2DomainHelper.ALLOWED_DOC_CATEGORIES) categoryId else "general"
        val cleanMime = when (mimeType.lowercase()) {
            "application/pdf" -> "application/pdf"
            "image/png" -> "image/png"
            "image/webp" -> "image/webp"
            else -> "image/jpeg"
        }
        val ext = when (cleanMime) {
            "application/pdf" -> "pdf"
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        val bucketKey = when {
            cleanMime == "application/pdf" -> "pdfs"
            prefix.contains("diagram", ignoreCase = true) -> "diagrams"
            else -> "diagrams"
        }
        val objectPath = "$cleanCat/${prefix}_${System.currentTimeMillis()}.$ext"
        return try {
            requireUserId()
            require(bytes.isNotEmpty() && bytes.size < 20 * 1024 * 1024) {
                "File must be smaller than 20 MB."
            }
            storageRouter.uploadBytes(
                bucketKey = bucketKey,
                objectPath = objectPath,
                bytes = bytes,
                mimeType = cleanMime,
                onProgress = onProgress
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveTechnicalDocument(doc: TechnicalDocumentCloud): Result<Unit> {
        val docId = if (doc.docId.isNotBlank()) CloudRepository.sanitizeId(doc.docId)
        else CloudRepository.sanitizeId("tdoc_${UUID.randomUUID().toString().replace("-", "").take(14)}")
        val path = "technical_documents/$docId"
        return try {
            val uid = requireUserId()
            val cleanType = if (doc.docType in V2DomainHelper.ALLOWED_DOC_TYPES) doc.docType else "PDF_MANUAL"
            val cleanCat = if (doc.categoryId in V2DomainHelper.ALLOWED_DOC_CATEGORIES) doc.categoryId else "general"
            require(doc.title.trim().length >= 2) { "Document title is required." }
            require(doc.fileUrl.startsWith("https://")) { "A valid uploaded file URL is required." }

            val payload = JSONObject()
                .put("doc_id", docId)
                .put("doc_type", cleanType)
                .put("category_id", cleanCat)
                .put("brand_name", doc.brandName.trim().take(80))
                .put("model_name", doc.modelName.trim().take(100))
                .put("linked_entry_id", doc.linkedEntryId.trim().take(128))
                .put("title", doc.title.trim().take(160))
                .put("description", doc.description.trim().take(800))
                .put("file_url", doc.fileUrl.trim().take(1000))
                .put("storage_path", doc.storagePath.trim().take(320))
                .put("storage_provider_id", doc.storageProviderId.trim().ifBlank { "supabase_primary" })
                .put("mime_type", doc.mimeType.trim().ifBlank { "application/pdf" }.take(80))
                .put("file_size_bytes", doc.fileSizeBytes.coerceIn(0L, 25_000_000L))
                .put("published", doc.published)
                .put("offline_available", doc.offlineAvailable)
                .put("is_deleted", doc.isDeleted)
                .put("uploaded_by_uid", uid)
                .put("updated_at", CloudTimestamp.toIsoString())

            val bucketKey = if (cleanType == "PDF_MANUAL") "pdfs" else "diagrams"
            storageRouter.writeRowWithFailover(
                tableName = "technical_documents",
                categoryKey = bucketKey,
                payload = payload,
                onConflict = "doc_id",
                mirrorIfActiveExternal = true
            ).getOrThrow()

            logAdminAction(uid, "SAVE_TECHNICAL_DOCUMENT", "technical_documents", docId, "$cleanType: ${doc.title}")
            docsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun replaceTechnicalDocumentFile(
        doc: TechnicalDocumentCloud,
        bytes: ByteArray,
        mimeType: String,
        onProgress: (Float) -> Unit = {}
    ): Result<Unit> {
        val docId = CloudRepository.sanitizeId(doc.docId.ifBlank { doc.id })
        val path = "technical_documents/$docId"
        return try {
            val uid = requireUserId()
            val cleanCat = if (doc.categoryId in V2DomainHelper.ALLOWED_DOC_CATEGORIES) doc.categoryId else "general"
            val bucketKey = if (mimeType.equals("application/pdf", ignoreCase = true) || doc.docType == "PDF_MANUAL") "pdfs" else "diagrams"
            val uploadRes = uploadRepairMediaWithResult(
                categoryId = cleanCat,
                prefix = doc.docType.lowercase(),
                bytes = bytes,
                mimeType = mimeType,
                onProgress = onProgress
            )
            if (uploadRes.isFailure) {
                return Result.failure(uploadRes.exceptionOrNull() ?: IllegalStateException("Replacement upload failed."))
            }
            val uploaded = uploadRes.getOrThrow()
            val patchRes = storageRouter.patchRowWithFailover(
                tableName = "technical_documents",
                categoryKey = bucketKey,
                recordId = doc.externalRecordId.ifBlank { docId },
                supabaseFilterQuery = "doc_id=eq.${URLEncoder.encode(docId, "UTF-8")}",
                patchJson = JSONObject()
                    .put("file_url", uploaded.publicUrl)
                    .put("storage_path", uploaded.storagePath)
                    .put("storage_provider_id", uploaded.providerId)
                    .put("mime_type", mimeType.take(80))
                    .put("file_size_bytes", bytes.size.toLong().coerceIn(0L, 25_000_000L))
                    .put("updated_at", CloudTimestamp.toIsoString())
            )
            if (patchRes.isFailure) {
                withContext(NonCancellable) {
                    runCatching {
                        storageRouter.deleteObject(
                            providerId = uploaded.providerId,
                            bucketKey = bucketKey,
                            storagePath = uploaded.storagePath,
                            publicUrl = uploaded.publicUrl
                        )
                    }
                }
                throw (patchRes.exceptionOrNull() ?: IllegalStateException("Document replacement update failed."))
            }
            withContext(NonCancellable) {
                runCatching {
                    storageRouter.deleteObject(
                        providerId = doc.storageProviderId,
                        bucketKey = if (doc.docType == "PDF_MANUAL") "pdfs" else "diagrams",
                        storagePath = doc.storagePath,
                        publicUrl = doc.fileUrl
                    )
                }
            }
            logAdminAction(uid, "REPLACE_TECHNICAL_DOCUMENT_FILE", "technical_documents", docId, "Replaced file for ${doc.title}")
            docsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun setDocumentOfflineAvailable(docId: String, offlineAvailable: Boolean): Result<Unit> {
        val safeId = CloudRepository.sanitizeId(docId)
        val path = "technical_documents/$safeId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safeId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "technical_documents",
                categoryKey = "pdfs",
                recordId = safeId,
                supabaseFilterQuery = "doc_id=eq.$encId",
                patchJson = JSONObject()
                    .put("offline_available", offlineAvailable)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(uid, "SET_DOC_OFFLINE_POLICY", "technical_documents", safeId, "offlineAvailable=$offlineAvailable")
            docsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun softDeleteTechnicalDocument(docId: String): Result<Unit> {
        val safeId = CloudRepository.sanitizeId(docId)
        val path = "technical_documents/$safeId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safeId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "technical_documents",
                categoryKey = "pdfs",
                recordId = safeId,
                supabaseFilterQuery = "doc_id=eq.$encId",
                patchJson = JSONObject()
                    .put("is_deleted", true)
                    .put("published", false)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(uid, "SOFT_DELETE_TECHNICAL_DOCUMENT", "technical_documents", safeId, "Soft deleted technical document")
            docsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun restoreTechnicalDocument(docId: String): Result<Unit> {
        val safeId = CloudRepository.sanitizeId(docId)
        val path = "technical_documents/$safeId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safeId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "technical_documents",
                categoryKey = "pdfs",
                recordId = safeId,
                supabaseFilterQuery = "doc_id=eq.$encId",
                patchJson = JSONObject()
                    .put("is_deleted", false)
                    .put("published", true)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(uid, "RESTORE_TECHNICAL_DOCUMENT", "technical_documents", safeId, "Restored technical document")
            docsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun resolveSignedPrivateUrl(
        storagePath: String,
        preferredProviderId: String = "",
        fallbackUrl: String = ""
    ): Result<String> {
        val clean = storagePath.trim().trimStart('/')
        if (clean.isBlank()) return Result.failure(IllegalArgumentException("Storage path missing."))
        return storageRouter.getSignedPrivateUrl(
            bucketName = "verification-documents",
            storagePath = clean,
            expiresInSeconds = 180,
            preferredProviderId = preferredProviderId,
            fallbackUrl = fallbackUrl
        )
    }

    suspend fun deleteTechnicalDocument(doc: TechnicalDocumentCloud): Result<Unit> {
        val docId = CloudRepository.sanitizeId(doc.docId.ifBlank { doc.id })
        val path = "technical_documents/$docId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(docId, "UTF-8")
            val bucketKey = if (doc.docType == "PDF_MANUAL") "pdfs" else "diagrams"
            storageRouter.deleteRowWithFailover(
                tableName = "technical_documents",
                categoryKey = bucketKey,
                recordId = doc.externalRecordId.ifBlank { docId },
                supabaseFilterQuery = "doc_id=eq.$encId"
            ).getOrThrow()
            runCatching {
                storageRouter.deleteObject(
                    providerId = doc.storageProviderId,
                    bucketKey = bucketKey,
                    storagePath = doc.storagePath,
                    publicUrl = doc.fileUrl
                )
            }
            logAdminAction(uid, "DELETE_TECHNICAL_DOCUMENT", "technical_documents", docId, "Deleted ${doc.title}")
            docsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // =========================================================================
    // 3. NOTIFICATIONS, ANNOUNCEMENTS & FCM TOKEN REGISTRATION
    // =========================================================================

    fun observeMyNotifications(userId: String): Flow<List<UserNotificationCloud>> {
        val encUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = notificationsTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "user_notifications",
            expectedUid = userId
        ) {
            val arr = supabaseClient.selectRows(
                tableName = "user_notifications",
                queryParams = "recipient_uid=eq.$encUid&select=*&order=created_at.desc",
                requireAuth = true
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr).map { SupabaseMappers.toUserNotification(it) }
        }
    }

    fun observeAnnouncements(userId: String): Flow<List<AnnouncementCloud>> {
        return pollFlow(
            trigger = announcementsTick,
            intervalMs = 30_000L,
            op = OperationType.LIST,
            path = "announcements",
            expectedUid = userId
        ) {
            val arr = supabaseClient.selectRows(
                tableName = "announcements",
                queryParams = "select=*&order=created_at.desc",
                requireAuth = false
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr).map { SupabaseMappers.toAnnouncement(it) }
        }
    }

    fun observeReadAnnouncementIds(userId: String): Flow<Set<String>> {
        val encUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = announcementsTick,
            intervalMs = 30_000L,
            op = OperationType.LIST,
            path = "read_announcements/$userId",
            expectedUid = userId
        ) {
            val arr = supabaseClient.selectRows(
                tableName = "read_announcements",
                queryParams = "user_id=eq.$encUid&select=announcement_id",
                requireAuth = true
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .mapNotNull { obj -> obj.optString("announcement_id").takeIf { it.isNotBlank() } }
                .toSet()
        }
    }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> {
        val safeId = CloudRepository.sanitizeId(notificationId)
        val path = "user_notifications/$safeId"
        return try {
            requireUserId()
            val encId = URLEncoder.encode(safeId, "UTF-8")
            supabaseClient.patchRows(
                "user_notifications",
                "notification_id=eq.$encId",
                JSONObject()
                    .put("is_read", true)
                    .put("updated_at", CloudTimestamp.toIsoString()),
                requireAuth = true
            ).getOrThrow()
            notificationsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun markAnnouncementRead(userId: String, announcementId: String): Result<Unit> {
        val safeAnnId = CloudRepository.sanitizeId(announcementId)
        val path = "read_announcements/$userId/$safeAnnId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            supabaseClient.upsertTableRow(
                "read_announcements",
                JSONObject()
                    .put("user_id", userId)
                    .put("announcement_id", safeAnnId)
                    .put("read_at", CloudTimestamp.toIsoString()),
                onConflict = "user_id,announcement_id"
            ).getOrThrow()
            announcementsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun sendUserNotification(
        recipientUid: String,
        actorUid: String,
        type: String,
        title: String,
        body: String,
        targetRoute: String = "",
        imageUrl: String = ""
    ) {
        if (recipientUid.isBlank()) return
        try {
            val notifId = CloudRepository.sanitizeId("ntf_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            supabaseClient.insertRow(
                "user_notifications",
                JSONObject()
                    .put("notification_id", notifId)
                    .put("recipient_uid", CloudRepository.sanitizeId(recipientUid))
                    .put("actor_uid", actorUid.take(128))
                    .put("type", type)
                    .put("title", title.trim().ifBlank { "Repair Pro Update" }.take(140))
                    .put("body", body.trim().ifBlank { "You have a new update." }.take(600))
                    .put("target_route", targetRoute.trim().take(160))
                    .put("image_url", imageUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 }.orEmpty())
                    .put("is_read", false),
                requireAuth = true
            )
            notificationsTick.value += 1
        } catch (_: Exception) {
            // Best-effort
        }
    }

    suspend fun adminPublishAnnouncement(
        title: String,
        body: String,
        category: String = "GENERAL",
        targetRoute: String = "",
        imageUrl: String = ""
    ): Result<Unit> {
        val annId = CloudRepository.sanitizeId("ann_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "announcements/$annId"
        return try {
            val uid = requireUserId()
            require(title.trim().length >= 2) { "Title is required." }
            require(body.trim().length >= 2) { "Message body is required." }
            val cleanCat = if (category in V2DomainHelper.ALLOWED_ANNOUNCEMENT_CATEGORIES) category else "GENERAL"
            supabaseClient.insertRow(
                "announcements",
                JSONObject()
                    .put("announcement_id", annId)
                    .put("title", title.trim().take(140))
                    .put("body", body.trim().take(1200))
                    .put("category", cleanCat)
                    .put("target_route", targetRoute.trim().take(160))
                    .put("image_url", imageUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 }.orEmpty())
                    .put("created_by_uid", uid),
                requireAuth = true
            ).getOrThrow()
            logAdminAction(uid, "PUBLISH_ANNOUNCEMENT", "announcements", annId, title.trim().take(100))
            announcementsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun dispatchAdminPushNotification(
        audience: String,
        title: String,
        body: String,
        category: String = "GENERAL",
        targetRoute: String = "notifications",
        imageUrl: String = "",
        targetUids: List<String> = emptyList(),
        sendPush: Boolean = true
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanAudience = if (audience in listOf("ALL", "TECHNICIANS", "SELECTED")) audience else "ALL"
        val cleanTitle = title.trim().take(140)
        val cleanBody = body.trim().take(1200)
        val cleanImage = imageUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 }.orEmpty()
        val cleanRoute = targetRoute.trim().ifBlank { "notifications" }.take(160)

        return try {
            if (cleanAudience == "ALL") {
                val annRes = adminPublishAnnouncement(cleanTitle, cleanBody, category, cleanRoute, cleanImage)
                if (annRes.isFailure) return Result.failure(annRes.exceptionOrNull()!!)
            } else if (cleanAudience == "SELECTED") {
                targetUids.filter { it.isNotBlank() }.distinct().take(100).forEach { targetUid ->
                    sendUserNotification(
                        recipientUid = targetUid,
                        actorUid = uid,
                        type = if (category == "NEW_PDF") "NEW_PDF" else "ANNOUNCEMENT",
                        title = cleanTitle,
                        body = cleanBody,
                        targetRoute = cleanRoute,
                        imageUrl = cleanImage
                    )
                }
            }

            var status = "IN_APP_ONLY"
            var sentCount = 0
            var failedCount = 0
            var errorMsg = ""

            if (sendPush) {
                val cfg = storageRouter.loadRoutingConfig()
                val endpoint = MultiCloudStorageRouter.resolveEffectiveFcmEndpoint(
                    configuredRemoteUrl = cfg.fcmBackendUrl,
                    buildConfigUrl = BuildConfig.FCM_BACKEND_ENDPOINT
                )

                if (endpoint.startsWith("https://")) {
                    val idToken = runCatching { auth.currentUser?.getIdToken(false)?.await()?.token.orEmpty() }
                        .getOrNull().orEmpty()
                    if (idToken.isNotBlank()) {
                        val anonKey = supabaseClient.resolveAnonKey()
                        withContext(Dispatchers.IO) {
                            runCatching {
                                val json = JSONObject()
                                    .put("audience", cleanAudience)
                                    .put("eventType", category)
                                    .put("title", cleanTitle)
                                    .put("body", cleanBody)
                                    .put("imageUrl", cleanImage)
                                    .put("targetRoute", cleanRoute)
                                    .put("targetUids", JSONArray(targetUids))
                                val reqBuilder = Request.Builder()
                                    .url(endpoint)
                                    .post(json.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                                    .addHeader("Authorization", "Bearer $idToken")
                                    .addHeader("Content-Type", "application/json")
                                if (anonKey.isNotBlank()) reqBuilder.addHeader("apikey", anonKey)
                                httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                                    val respStr = resp.body?.string().orEmpty()
                                    val parsed = runCatching { JSONObject(respStr) }.getOrNull()
                                    if (resp.isSuccessful && parsed?.optBoolean("ok", true) != false) {
                                        sentCount = parsed?.optInt("sentCount", 0) ?: 0
                                        failedCount = parsed?.optInt("failedCount", 0) ?: 0
                                        status = parsed?.optString("deliveryStatus").orEmpty().ifBlank { "SENT" }
                                    } else {
                                        status = "FAILED"
                                        val errDetail = parsed?.optString("error").orEmpty()
                                            .ifBlank { parsed?.optString("message").orEmpty() }
                                        errorMsg = "FCM HTTP ${resp.code}: $errDetail".take(450)
                                    }
                                }
                            }.onFailure { err ->
                                status = "FAILED"
                                errorMsg = (err.message ?: "FCM backend unreachable").take(450)
                            }
                        }
                    }
                }
            }

            val pushId = CloudRepository.sanitizeId("push_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            val pushDoc = JSONObject()
                .put("push_id", pushId)
                .put("audience", cleanAudience)
                .put("event_type", category.take(64))
                .put("title", cleanTitle)
                .put("body", cleanBody)
                .put("image_url", cleanImage)
                .put("target_route", cleanRoute)
                .put("target_uids", JSONArray(targetUids.take(500)))
                .put("delivery_status", status)
                .put("sent_count", sentCount)
                .put("failed_count", failedCount)
                .put("error_message", errorMsg)
                .put("created_by_uid", uid)
                .put("created_by_email", auth.currentUser?.email.orEmpty())
            runCatching { supabaseClient.insertRow("push_notification_history", pushDoc, requireAuth = true) }

            Result.success(
                when {
                    status == "SENT" || status == "PARTIAL" -> "Notification delivered ($sentCount device(s))."
                    status == "IN_APP_ONLY" -> "In-app alert published."
                    else -> "In-app alert published; FCM push note: $errorMsg"
                }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun adminDeleteAnnouncement(announcementId: String): Result<Unit> {
        val safeId = CloudRepository.sanitizeId(announcementId)
        val path = "announcements/$safeId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safeId, "UTF-8")
            supabaseClient.deleteRows("announcements", "announcement_id=eq.$encId", requireAuth = true).getOrThrow()
            logAdminAction(uid, "DELETE_ANNOUNCEMENT", "announcements", safeId, "Deleted announcement")
            announcementsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun saveFcmToken(userId: String, token: String) {
        if (userId.isBlank() || token.length < 10) return
        try {
            val uid = auth.currentUser?.uid ?: return
            if (uid != userId) return
            val tokenId = CloudRepository.sanitizeId("android_${token.hashCode().toUInt()}")
            supabaseClient.upsertTableRow(
                tableName = "fcm_tokens",
                rowJson = JSONObject()
                    .put("token_id", tokenId)
                    .put("user_id", userId)
                    .put("token", token.take(512))
                    .put("platform", "android")
                    .put("updated_at", CloudTimestamp.toIsoString()),
                onConflict = "token_id"
            )
        } catch (_: Exception) {
            // Non-fatal
        }
    }

    suspend fun deleteFcmToken(userId: String, token: String) {
        if (userId.isBlank() || token.length < 10) return
        try {
            val uid = auth.currentUser?.uid ?: return
            if (uid != userId) return
            val tokenId = CloudRepository.sanitizeId("android_${token.hashCode().toUInt()}")
            val encTid = URLEncoder.encode(tokenId, "UTF-8")
            val encUid = URLEncoder.encode(userId, "UTF-8")
            supabaseClient.deleteRows("fcm_tokens", "token_id=eq.$encTid&user_id=eq.$encUid", requireAuth = true)
        } catch (_: Exception) {
            // Non-fatal
        }
    }

    // =========================================================================
    // 4. COMMUNITY USER RESTRICTIONS (ADMIN BLOCK / UNBLOCK)
    // =========================================================================

    fun observeMyCommunityRestriction(userId: String): Flow<CommunityUserRestrictionCloud?> {
        val encUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = restrictionsTick,
            intervalMs = 30_000L,
            op = OperationType.GET,
            path = "community_user_restrictions/$userId",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_user_restrictions",
                categoryKey = "community",
                supabaseQueryParams = "user_id=eq.$encUid&select=*&limit=1",
                supabaseRequireAuth = true,
                extFilters = mapOf("user_id" to userId),
                extLimit = 1,
                pkColumns = listOf("user_id", "id")
            ).getOrThrow()
            arr.optJSONObject(0)?.let { SupabaseMappers.toCommunityRestriction(it) }
        }
    }

    fun observeAllCommunityRestrictionsForAdmin(adminUid: String): Flow<List<CommunityUserRestrictionCloud>> {
        return pollFlow(
            trigger = restrictionsTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "community_user_restrictions",
            expectedUid = adminUid
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_user_restrictions",
                categoryKey = "community",
                supabaseQueryParams = "select=*&order=created_at.desc",
                supabaseRequireAuth = true,
                extLimit = 200,
                pkColumns = listOf("user_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toCommunityRestriction(it) }
                .sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    suspend fun adminSetCommunityUserBlocked(
        targetUid: String,
        userName: String,
        blocked: Boolean,
        reason: String
    ): Result<Unit> {
        val safeUid = CloudRepository.sanitizeId(targetUid)
        val path = "community_user_restrictions/$safeUid"
        return try {
            val adminUid = requireUserId()
            if (blocked) {
                val payload = JSONObject()
                    .put("user_id", safeUid)
                    .put("user_name", userName.trim().ifBlank { "Community Member" }.take(80))
                    .put("is_blocked", true)
                    .put("can_post", false)
                    .put("can_comment", false)
                    .put("can_upload_photo", false)
                    .put("reason", reason.trim().ifBlank { "Community policy violation" }.take(400))
                    .put("blocked_by_uid", adminUid)
                storageRouter.writeRowWithFailover(
                    tableName = "community_user_restrictions",
                    categoryKey = "community",
                    payload = payload,
                    onConflict = "user_id"
                ).getOrThrow()
                logAdminAction(adminUid, "BLOCK_COMMUNITY_USER", "community_user_restrictions", safeUid, "Blocked $userName")
            } else {
                val encUid = URLEncoder.encode(safeUid, "UTF-8")
                storageRouter.deleteRowWithFailover(
                    tableName = "community_user_restrictions",
                    categoryKey = "community",
                    recordId = safeUid,
                    supabaseFilterQuery = "user_id=eq.$encUid"
                ).getOrThrow()
                logAdminAction(adminUid, "UNBLOCK_COMMUNITY_USER", "community_user_restrictions", safeUid, "Unblocked $userName")
            }
            restrictionsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private suspend fun logAdminAction(
        adminUid: String,
        action: String,
        targetType: String,
        targetId: String,
        details: String
    ) {
        try {
            val logId = CloudRepository.sanitizeId("log_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            val email = auth.currentUser?.email ?: "admin@repairpro.local"
            supabaseClient.insertRow(
                "audit_logs",
                JSONObject()
                    .put("log_id", logId)
                    .put("admin_uid", adminUid)
                    .put("admin_email", email.take(160))
                    .put("action", action.take(100))
                    .put("target_type", targetType.take(64))
                    .put("target_id", targetId.take(128))
                    .put("details", details.take(500))
                    .put("result", "SUCCESS"),
                requireAuth = true
            )
        } catch (_: Exception) {
            // Non-fatal
        }
    }
}
