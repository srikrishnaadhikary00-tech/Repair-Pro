package com.example.data.remote

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import com.google.firebase.storage.storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class V2CloudRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
    private val storageProvider: () -> FirebaseStorage = { Firebase.storage },
    private val storageRouter: MultiCloudStorageRouter = MultiCloudStorageRouter({ db }, { auth }, storageProvider),
    private val supabaseClient: SupabaseClient = SupabaseClient(),
    private val httpClient: OkHttpClient = SupabaseClient.defaultHttpClient()
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Please sign in with Google first.")
    }

    // =========================================================================
    // 1. TECHNICIAN VERIFICATION SYSTEM
    // =========================================================================

    fun observeMyVerificationRequest(userId: String): Flow<TechnicianVerificationRequestCloud?> = flow {
        val path = "technician_verification_requests/$userId"
        emitAll(
            db.collection("technician_verification_requests").document(userId)
                .snapshots()
                .map { snap ->
                    if (snap.exists()) {
                        snap.toObject(TechnicianVerificationRequestCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                    } else null
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeAllVerificationRequestsForAdmin(adminUid: String): Flow<List<TechnicianVerificationRequestCloud>> = flow {
        val path = "technician_verification_requests"
        emitAll(
            db.collection("technician_verification_requests")
                .snapshots()
                .map { snap ->
                    snap.toObjects(TechnicianVerificationRequestCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun uploadVerificationFile(
        userId: String,
        prefix: String,
        bytes: ByteArray,
        mimeType: String,
        onProgress: (Float) -> Unit = {}
    ): Result<Pair<String, String>> {
        val cleanMime = when (mimeType.lowercase()) {
            "application/pdf" -> "application/pdf"
            "image/png" -> "image/png"
            "image/webp" -> "image/webp"
            else -> "image/jpeg"
        }
        val ext = when (cleanMime) {
            "application/pdf" -> "pdf"
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        val objectPath = "$userId/${prefix}_${System.currentTimeMillis()}.$ext"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            require(bytes.isNotEmpty() && bytes.size < 10 * 1024 * 1024) {
                "File must be smaller than 10 MB."
            }
            storageRouter.uploadBytes(
                bucketKey = "verification",
                objectPath = objectPath,
                bytes = bytes,
                mimeType = cleanMime,
                onProgress = onProgress
            ).map { it.publicUrl to it.storagePath }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitVerificationRequest(
        userId: String,
        request: TechnicianVerificationRequestCloud
    ): Result<Unit> {
        val path = "technician_verification_requests/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val err = V2DomainHelper.validateVerificationApplication(
                fullName = request.fullName,
                mobileNumber = request.mobileNumber,
                fullAddress = request.fullAddress,
                state = request.state,
                district = request.district,
                cityArea = request.cityArea,
                pinCode = request.pinCode,
                serviceCategories = request.serviceCategories
            )
            require(err == null) { err ?: "Invalid verification details." }

            val cleanCats = request.serviceCategories.filter { it in V2DomainHelper.ALLOWED_SERVICE_CATEGORIES }.distinct()
            val docRef = db.collection("technician_verification_requests").document(userId)
            val existing = docRef.get().await()

            if (!existing.exists()) {
                val payload = mutableMapOf<String, Any>(
                    "userId" to userId,
                    "fullName" to request.fullName.trim().take(100),
                    "mobileNumber" to request.mobileNumber.trim().take(20),
                    "fullAddress" to request.fullAddress.trim().take(300),
                    "state" to request.state.trim().take(80),
                    "district" to request.district.trim().take(80),
                    "cityArea" to request.cityArea.trim().take(80),
                    "pinCode" to request.pinCode.trim().take(12),
                    "serviceCategories" to cleanCats,
                    "status" to "PENDING",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                request.experience.trim().take(80).takeIf { it.isNotEmpty() }?.let { payload["experience"] = it }
                request.bio.trim().take(600).takeIf { it.isNotEmpty() }?.let { payload["bio"] = it }
                request.profilePhotoUrl.trim().takeIf { it.startsWith("https://") }?.let { payload["profilePhotoUrl"] = it }
                request.profilePhotoStoragePath.trim().take(320).takeIf { it.isNotEmpty() }?.let { payload["profilePhotoStoragePath"] = it }
                request.credentialDocUrl.trim().takeIf { it.startsWith("https://") }?.let { payload["credentialDocUrl"] = it }
                request.credentialDocStoragePath.trim().take(320).takeIf { it.isNotEmpty() }?.let { payload["credentialDocStoragePath"] = it }
                request.credentialDocName.trim().take(140).takeIf { it.isNotEmpty() }?.let { payload["credentialDocName"] = it }
                docRef.set(payload).await()
            } else {
                val updates = mutableMapOf<String, Any>(
                    "fullName" to request.fullName.trim().take(100),
                    "mobileNumber" to request.mobileNumber.trim().take(20),
                    "fullAddress" to request.fullAddress.trim().take(300),
                    "state" to request.state.trim().take(80),
                    "district" to request.district.trim().take(80),
                    "cityArea" to request.cityArea.trim().take(80),
                    "pinCode" to request.pinCode.trim().take(12),
                    "serviceCategories" to cleanCats,
                    "experience" to request.experience.trim().take(80),
                    "bio" to request.bio.trim().take(600),
                    "profilePhotoUrl" to (request.profilePhotoUrl.trim().takeIf { it.startsWith("https://") } ?: ""),
                    "profilePhotoStoragePath" to request.profilePhotoStoragePath.trim().take(320),
                    "credentialDocUrl" to (request.credentialDocUrl.trim().takeIf { it.startsWith("https://") } ?: ""),
                    "credentialDocStoragePath" to request.credentialDocStoragePath.trim().take(320),
                    "credentialDocName" to request.credentialDocName.trim().take(140),
                    "status" to "PENDING",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun adminReviewVerificationRequest(
        request: TechnicianVerificationRequestCloud,
        newStatus: String,
        rejectionReason: String
    ): Result<Unit> {
        val targetUid = CloudRepository.sanitizeId(request.userId.ifBlank { request.id })
        val cleanStatus = when (newStatus) {
            "VERIFIED", "REJECTED", "SUSPENDED", "PENDING" -> newStatus
            else -> "PENDING"
        }
        val path = "technician_verification_requests/$targetUid"
        return try {
            val adminUid = requireUserId()
            db.collection("technician_verification_requests").document(targetUid).update(
                mapOf(
                    "status" to cleanStatus,
                    "rejectionReason" to rejectionReason.trim().take(500),
                    "reviewedByUid" to adminUid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val techId = CloudRepository.sanitizeId("vtech_$targetUid")
            val techRef = db.collection("technicians").document(techId)
            val techSnap = techRef.get().await()
            val isVerified = cleanStatus == "VERIFIED"
            val isSuspended = cleanStatus == "SUSPENDED"
            if (isVerified) {
                val cleanCats = request.serviceCategories.filter { it in V2DomainHelper.ALLOWED_SERVICE_CATEGORIES }
                    .ifEmpty { listOf("AC") }
                if (!techSnap.exists()) {
                    val payload = mutableMapOf<String, Any>(
                        "technicianId" to techId,
                        "fullName" to request.fullName.trim().take(100),
                        "mobileNumber" to request.mobileNumber.trim().take(20),
                        "fullAddress" to request.fullAddress.trim().take(300),
                        "state" to request.state.trim().take(80),
                        "district" to request.district.trim().take(80),
                        "cityArea" to request.cityArea.trim().take(80),
                        "pinCode" to request.pinCode.trim().take(12),
                        "serviceCategories" to cleanCats,
                        "verificationStatus" to "VERIFIED",
                        "blocked" to false,
                        "linkedUserUid" to targetUid,
                        "status" to "ACTIVE",
                        "updatedByUid" to adminUid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    request.experience.trim().take(80).takeIf { it.isNotEmpty() }?.let { payload["experience"] = it }
                    request.bio.trim().take(600).takeIf { it.isNotEmpty() }?.let { payload["bio"] = it }
                    request.profilePhotoUrl.trim().takeIf { it.startsWith("https://") }?.let { payload["photoUrl"] = it }
                    techRef.set(payload).await()
                } else {
                    techRef.update(
                        mapOf(
                            "fullName" to request.fullName.trim().take(100),
                            "mobileNumber" to request.mobileNumber.trim().take(20),
                            "fullAddress" to request.fullAddress.trim().take(300),
                            "state" to request.state.trim().take(80),
                            "district" to request.district.trim().take(80),
                            "cityArea" to request.cityArea.trim().take(80),
                            "pinCode" to request.pinCode.trim().take(12),
                            "serviceCategories" to cleanCats,
                            "experience" to request.experience.trim().take(80),
                            "bio" to request.bio.trim().take(600),
                            "photoUrl" to (request.profilePhotoUrl.trim().takeIf { it.startsWith("https://") } ?: ""),
                            "verificationStatus" to "VERIFIED",
                            "blocked" to false,
                            "status" to "ACTIVE",
                            "updatedByUid" to adminUid,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            } else if (techSnap.exists()) {
                techRef.update(
                    mapOf(
                        "verificationStatus" to cleanStatus,
                        "blocked" to isSuspended,
                        "status" to if (isVerified) "ACTIVE" else "INACTIVE",
                        "updatedByUid" to adminUid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            try {
                val userRef = db.collection("users").document(targetUid)
                if (userRef.get().await().exists()) {
                    userRef.update(
                        mapOf(
                            "isVerifiedTechnician" to isVerified,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            } catch (_: Exception) {
                // Non-fatal
            }

            val notifType = when (cleanStatus) {
                "VERIFIED" -> "VERIFICATION_APPROVED"
                "SUSPENDED" -> "VERIFICATION_SUSPENDED"
                else -> "VERIFICATION_REJECTED"
            }
            val notifTitle = when (cleanStatus) {
                "VERIFIED" -> "Technician Verification Approved"
                "SUSPENDED" -> "Technician Account Suspended"
                else -> "Verification Application Update"
            }
            val notifBody = when (cleanStatus) {
                "VERIFIED" -> "Your Verified Technician badge is now active in Repair Pro directory and community."
                "SUSPENDED" -> "Your verified technician status has been suspended.${if (rejectionReason.isNotBlank()) " Reason: ${rejectionReason.trim()}" else ""}"
                else -> "Your verification request was not approved.${if (rejectionReason.isNotBlank()) " Reason: ${rejectionReason.trim()}" else " Please review your details and resubmit."}"
            }
            sendUserNotification(
                recipientUid = targetUid,
                actorUid = adminUid,
                type = notifType,
                title = notifTitle,
                body = notifBody,
                targetRoute = "verification"
            )

            logAdminAction(
                adminUid,
                "REVIEW_TECHNICIAN_VERIFICATION",
                "technician_verification_requests",
                targetUid,
                "${request.fullName} -> $cleanStatus"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // =========================================================================
    // 2. ONLINE TECHNICAL DOCUMENTS (PDF MANUALS, CIRCUIT DIAGRAMS, PHOTOS)
    // =========================================================================

    fun observePublishedTechnicalDocuments(userId: String): Flow<List<TechnicalDocumentCloud>> = flow {
        val path = "technical_documents"
        emitAll(
            db.collection("technical_documents")
                .whereEqualTo("published", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(TechnicalDocumentCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .filter { it.published }
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeAllTechnicalDocumentsForAdmin(adminUid: String): Flow<List<TechnicalDocumentCloud>> = flow {
        val path = "technical_documents"
        emitAll(
            db.collection("technical_documents")
                .snapshots()
                .map { snap ->
                    snap.toObjects(TechnicalDocumentCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun uploadRepairMedia(
        categoryId: String,
        prefix: String,
        bytes: ByteArray,
        mimeType: String,
        onProgress: (Float) -> Unit = {}
    ): Result<Pair<String, String>> {
        val cleanCat = if (categoryId in V2DomainHelper.ALLOWED_DOC_CATEGORIES) categoryId else "general"
        val cleanMime = when (mimeType.lowercase()) {
            "application/pdf" -> "application/pdf"
            "image/png" -> "image/png"
            "image/webp" -> "image/webp"
            else -> "image/jpeg"
        }
        val ext = when (cleanMime) {
            "application/pdf" -> "pdf"
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        val bucketKey = when {
            cleanMime == "application/pdf" -> "pdfs"
            prefix.contains("diagram", ignoreCase = true) -> "diagrams"
            else -> "diagrams"
        }
        val objectPath = "$cleanCat/${prefix}_${System.currentTimeMillis()}.$ext"
        return try {
            requireUserId()
            require(bytes.isNotEmpty() && bytes.size < 20 * 1024 * 1024) {
                "File must be smaller than 20 MB."
            }
            storageRouter.uploadBytes(
                bucketKey = bucketKey,
                objectPath = objectPath,
                bytes = bytes,
                mimeType = cleanMime,
                onProgress = onProgress
            ).map { it.publicUrl to it.storagePath }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveTechnicalDocument(doc: TechnicalDocumentCloud): Result<Unit> {
        val docId = if (doc.docId.isNotBlank()) CloudRepository.sanitizeId(doc.docId)
        else CloudRepository.sanitizeId("tdoc_${UUID.randomUUID().toString().replace("-", "").take(14)}")
        val path = "technical_documents/$docId"
        return try {
            val uid = requireUserId()
            val cleanType = if (doc.docType in V2DomainHelper.ALLOWED_DOC_TYPES) doc.docType else "PDF_MANUAL"
            val cleanCat = if (doc.categoryId in V2DomainHelper.ALLOWED_DOC_CATEGORIES) doc.categoryId else "general"
            require(doc.title.trim().length >= 2) { "Document title is required." }
            require(doc.fileUrl.startsWith("https://")) { "A valid uploaded file URL is required." }

            val docRef = db.collection("technical_documents").document(docId)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = mutableMapOf<String, Any>(
                    "docId" to docId,
                    "docType" to cleanType,
                    "categoryId" to cleanCat,
                    "title" to doc.title.trim().take(160),
                    "fileUrl" to doc.fileUrl.trim().take(1000),
                    "storagePath" to doc.storagePath.trim().take(320),
                    "mimeType" to doc.mimeType.trim().ifBlank { "application/pdf" }.take(80),
                    "fileSizeBytes" to doc.fileSizeBytes.coerceIn(0L, 25_000_000L),
                    "published" to doc.published,
                    "uploadedByUid" to uid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                doc.brandName.trim().take(80).takeIf { it.isNotEmpty() }?.let { payload["brandName"] = it }
                doc.modelName.trim().take(100).takeIf { it.isNotEmpty() }?.let { payload["modelName"] = it }
                doc.linkedEntryId.trim().take(128).takeIf { it.isNotEmpty() }?.let { payload["linkedEntryId"] = it }
                doc.description.trim().take(800).takeIf { it.isNotEmpty() }?.let { payload["description"] = it }
                docRef.set(payload).await()
                logAdminAction(uid, "UPLOAD_TECHNICAL_DOCUMENT", "technical_documents", docId, "$cleanType: ${doc.title}")
            } else {
                docRef.update(
                    mapOf(
                        "docType" to cleanType,
                        "categoryId" to cleanCat,
                        "brandName" to doc.brandName.trim().take(80),
                        "modelName" to doc.modelName.trim().take(100),
                        "linkedEntryId" to doc.linkedEntryId.trim().take(128),
                        "title" to doc.title.trim().take(160),
                        "description" to doc.description.trim().take(800),
                        "fileUrl" to doc.fileUrl.trim().take(1000),
                        "storagePath" to doc.storagePath.trim().take(320),
                        "mimeType" to doc.mimeType.trim().ifBlank { "application/pdf" }.take(80),
                        "fileSizeBytes" to doc.fileSizeBytes.coerceIn(0L, 25_000_000L),
                        "published" to doc.published,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                logAdminAction(uid, "UPDATE_TECHNICAL_DOCUMENT", "technical_documents", docId, "Updated ${doc.title}")
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteTechnicalDocument(doc: TechnicalDocumentCloud): Result<Unit> {
        val docId = CloudRepository.sanitizeId(doc.docId.ifBlank { doc.id })
        val path = "technical_documents/$docId"
        return try {
            val uid = requireUserId()
            db.collection("technical_documents").document(docId).delete().await()
            if (doc.storagePath.startsWith("repair_media/")) {
                try {
                    storageProvider().reference.child(doc.storagePath).delete().await()
                } catch (_: Exception) {
                    // Best-effort storage cleanup
                }
            }
            logAdminAction(uid, "DELETE_TECHNICAL_DOCUMENT", "technical_documents", docId, "Deleted ${doc.title}")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // =========================================================================
    // 3. NOTIFICATIONS, ANNOUNCEMENTS & FCM TOKEN REGISTRATION
    // =========================================================================

    fun observeMyNotifications(userId: String): Flow<List<UserNotificationCloud>> = flow {
        val path = "user_notifications"
        emitAll(
            db.collection("user_notifications")
                .whereEqualTo("recipientUid", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(UserNotificationCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeAnnouncements(userId: String): Flow<List<AnnouncementCloud>> = flow {
        val path = "announcements"
        emitAll(
            db.collection("announcements")
                .snapshots()
                .map { snap ->
                    snap.toObjects(AnnouncementCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeReadAnnouncementIds(userId: String): Flow<Set<String>> = flow {
        val path = "users/$userId/read_announcements"
        emitAll(
            db.collection("users").document(userId).collection("read_announcements")
                .snapshots()
                .map { snap -> snap.documents.map { it.id }.toSet() }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> {
        val safeId = CloudRepository.sanitizeId(notificationId)
        val path = "user_notifications/$safeId"
        return try {
            requireUserId()
            db.collection("user_notifications").document(safeId).update(
                mapOf(
                    "isRead" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun markAnnouncementRead(userId: String, announcementId: String): Result<Unit> {
        val safeAnnId = CloudRepository.sanitizeId(announcementId)
        val path = "users/$userId/read_announcements/$safeAnnId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            db.collection("users").document(userId)
                .collection("read_announcements").document(safeAnnId)
                .set(
                    mapOf(
                        "announcementId" to safeAnnId,
                        "readAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun sendUserNotification(
        recipientUid: String,
        actorUid: String,
        type: String,
        title: String,
        body: String,
        targetRoute: String = "",
        imageUrl: String = ""
    ) {
        if (recipientUid.isBlank()) return
        try {
            val notifId = CloudRepository.sanitizeId("ntf_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            val payload = mutableMapOf<String, Any>(
                "notificationId" to notifId,
                "recipientUid" to CloudRepository.sanitizeId(recipientUid),
                "actorUid" to actorUid.take(128),
                "type" to type,
                "title" to title.trim().ifBlank { "Repair Pro Update" }.take(140),
                "body" to body.trim().ifBlank { "You have a new update." }.take(600),
                "isRead" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            targetRoute.trim().take(160).takeIf { it.isNotEmpty() }?.let { payload["targetRoute"] = it }
            imageUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 }?.let { payload["imageUrl"] = it }
            db.collection("user_notifications").document(notifId).set(payload).await()
        } catch (_: Exception) {
            // Notification delivery is best-effort and should not fail primary workflow
        }
    }

    suspend fun adminPublishAnnouncement(
        title: String,
        body: String,
        category: String = "GENERAL",
        targetRoute: String = "",
        imageUrl: String = ""
    ): Result<Unit> {
        val annId = CloudRepository.sanitizeId("ann_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "announcements/$annId"
        return try {
            val uid = requireUserId()
            require(title.trim().length >= 2) { "Title is required." }
            require(body.trim().length >= 2) { "Message body is required." }
            val cleanCat = if (category in V2DomainHelper.ALLOWED_ANNOUNCEMENT_CATEGORIES) category else "GENERAL"
            val payload = mutableMapOf<String, Any>(
                "announcementId" to annId,
                "title" to title.trim().take(140),
                "body" to body.trim().take(1200),
                "category" to cleanCat,
                "createdByUid" to uid,
                "createdAt" to FieldValue.serverTimestamp()
            )
            targetRoute.trim().take(160).takeIf { it.isNotEmpty() }?.let { payload["targetRoute"] = it }
            imageUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 }?.let { payload["imageUrl"] = it }
            db.collection("announcements").document(annId).set(payload).await()
            logAdminAction(uid, "PUBLISH_ANNOUNCEMENT", "announcements", annId, title.trim().take(100))
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun dispatchAdminPushNotification(
        audience: String,
        title: String,
        body: String,
        category: String = "GENERAL",
        targetRoute: String = "notifications",
        imageUrl: String = "",
        targetUids: List<String> = emptyList(),
        sendPush: Boolean = true
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanAudience = if (audience in listOf("ALL", "TECHNICIANS", "SELECTED")) audience else "ALL"
        val cleanTitle = title.trim().take(140)
        val cleanBody = body.trim().take(1200)
        val cleanImage = imageUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 }.orEmpty()
        val cleanRoute = targetRoute.trim().ifBlank { "notifications" }.take(160)

        return try {
            if (cleanAudience == "ALL") {
                val annRes = adminPublishAnnouncement(cleanTitle, cleanBody, category, cleanRoute, cleanImage)
                if (annRes.isFailure) return Result.failure(annRes.exceptionOrNull()!!)
            } else if (cleanAudience == "SELECTED") {
                targetUids.filter { it.isNotBlank() }.distinct().take(100).forEach { targetUid ->
                    sendUserNotification(
                        recipientUid = targetUid,
                        actorUid = uid,
                        type = if (category == "NEW_PDF") "NEW_PDF" else "ANNOUNCEMENT",
                        title = cleanTitle,
                        body = cleanBody,
                        targetRoute = cleanRoute,
                        imageUrl = cleanImage
                    )
                }
            }

            var status = "IN_APP_ONLY"
            var sentCount = 0
            var failedCount = 0
            var errorMsg = ""

            if (sendPush) {
                val cfg = storageRouter.loadRoutingConfig()
                val endpoint = MultiCloudStorageRouter.resolveEffectiveFcmEndpoint(
                    configuredRemoteUrl = cfg.fcmBackendUrl,
                    buildConfigUrl = BuildConfig.FCM_BACKEND_ENDPOINT
                )

                if (endpoint.startsWith("https://")) {
                    val tokenResult = runCatching { auth.currentUser?.getIdToken(false)?.await()?.token.orEmpty() }
                    val idToken = tokenResult.getOrNull().orEmpty()
                    if (idToken.isNotBlank()) {
                        val anonKey = supabaseClient.resolveAnonKey()
                        withContext(Dispatchers.IO) {
                            runCatching {
                                val json = JSONObject()
                                    .put("audience", cleanAudience)
                                    .put("eventType", category)
                                    .put("title", cleanTitle)
                                    .put("body", cleanBody)
                                    .put("imageUrl", cleanImage)
                                    .put("targetRoute", cleanRoute)
                                    .put("targetUids", JSONArray(targetUids))
                                val reqBuilder = Request.Builder()
                                    .url(endpoint)
                                    .post(json.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                                    .addHeader("Authorization", "Bearer $idToken")
                                    .addHeader("Content-Type", "application/json")
                                if (anonKey.isNotBlank()) {
                                    reqBuilder.addHeader("apikey", anonKey)
                                }
                                httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                                    val respStr = resp.body?.string().orEmpty()
                                    val parsed = runCatching { JSONObject(respStr) }.getOrNull()
                                    if (resp.isSuccessful && parsed?.optBoolean("ok", true) != false) {
                                        sentCount = parsed?.optInt("sentCount", 0) ?: 0
                                        failedCount = parsed?.optInt("failedCount", 0) ?: 0
                                        status = parsed?.optString("deliveryStatus").orEmpty().ifBlank { "SENT" }
                                    } else {
                                        status = "FAILED"
                                        val errDetail = parsed?.optString("error").orEmpty()
                                            .ifBlank { parsed?.optString("message").orEmpty() }
                                        errorMsg = "FCM HTTP ${resp.code}: $errDetail".take(450)
                                    }
                                }
                            }.onFailure { err ->
                                status = "FAILED"
                                errorMsg = (err.message ?: "FCM backend unreachable").take(450)
                            }
                        }
                    }
                }
            }

            val pushId = CloudRepository.sanitizeId("push_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            val pushDoc = mutableMapOf<String, Any>(
                "pushId" to pushId,
                "audience" to cleanAudience,
                "eventType" to category.take(64),
                "title" to cleanTitle,
                "body" to cleanBody,
                "targetRoute" to cleanRoute,
                "targetUids" to targetUids.take(500),
                "deliveryStatus" to status,
                "sentCount" to sentCount,
                "failedCount" to failedCount,
                "createdByUid" to uid,
                "createdAt" to FieldValue.serverTimestamp()
            )
            if (cleanImage.isNotEmpty()) pushDoc["imageUrl"] = cleanImage
            if (errorMsg.isNotEmpty()) pushDoc["errorMessage"] = errorMsg
            runCatching { db.collection("push_notifications").document(pushId).set(pushDoc).await() }

            Result.success(
                if (status == "SENT" || status == "PARTIAL") {
                    "Notification delivered ($sentCount device(s))."
                } else if (status == "IN_APP_ONLY") {
                    "In-app alert published."
                } else {
                    "In-app alert published; FCM push note: $errorMsg"
                }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun adminDeleteAnnouncement(announcementId: String): Result<Unit> {
        val safeId = CloudRepository.sanitizeId(announcementId)
        val path = "announcements/$safeId"
        return try {
            val uid = requireUserId()
            db.collection("announcements").document(safeId).delete().await()
            logAdminAction(uid, "DELETE_ANNOUNCEMENT", "announcements", safeId, "Deleted announcement")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun saveFcmToken(userId: String, token: String) {
        if (userId.isBlank() || token.length < 10) return
        try {
            val uid = auth.currentUser?.uid ?: return
            if (uid != userId) return
            val tokenId = CloudRepository.sanitizeId("android_${token.hashCode().toUInt()}")
            db.collection("users").document(userId)
                .collection("fcm_tokens").document(tokenId)
                .set(
                    mapOf(
                        "token" to token.take(512),
                        "platform" to "android",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
        } catch (_: Exception) {
            // Non-fatal
        }
    }

    // =========================================================================
    // 4. COMMUNITY USER RESTRICTIONS (ADMIN BLOCK / UNBLOCK)
    // =========================================================================

    fun observeMyCommunityRestriction(userId: String): Flow<CommunityUserRestrictionCloud?> = flow {
        val path = "community_user_restrictions/$userId"
        emitAll(
            db.collection("community_user_restrictions").document(userId)
                .snapshots()
                .map { snap ->
                    if (snap.exists()) {
                        snap.toObject(CommunityUserRestrictionCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                    } else null
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeAllCommunityRestrictionsForAdmin(adminUid: String): Flow<List<CommunityUserRestrictionCloud>> = flow {
        val path = "community_user_restrictions"
        emitAll(
            db.collection("community_user_restrictions")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CommunityUserRestrictionCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun adminSetCommunityUserBlocked(
        targetUid: String,
        userName: String,
        blocked: Boolean,
        reason: String
    ): Result<Unit> {
        val safeUid = CloudRepository.sanitizeId(targetUid)
        val path = "community_user_restrictions/$safeUid"
        return try {
            val adminUid = requireUserId()
            if (blocked) {
                val payload = mapOf(
                    "userId" to safeUid,
                    "userName" to userName.trim().ifBlank { "Community Member" }.take(80),
                    "reason" to reason.trim().ifBlank { "Community policy violation" }.take(400),
                    "blockedByUid" to adminUid,
                    "createdAt" to FieldValue.serverTimestamp()
                )
                db.collection("community_user_restrictions").document(safeUid).set(payload).await()
                logAdminAction(adminUid, "BLOCK_COMMUNITY_USER", "community_user_restrictions", safeUid, "Blocked $userName")
            } else {
                db.collection("community_user_restrictions").document(safeUid).delete().await()
                logAdminAction(adminUid, "UNBLOCK_COMMUNITY_USER", "community_user_restrictions", safeUid, "Unblocked $userName")
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private suspend fun logAdminAction(
        adminUid: String,
        action: String,
        targetType: String,
        targetId: String,
        details: String
    ) {
        try {
            val logId = CloudRepository.sanitizeId("log_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            val email = auth.currentUser?.email ?: "admin@repairpro.local"
            db.collection("audit_logs").document(logId).set(
                mapOf(
                    "adminUid" to adminUid,
                    "adminEmail" to email.take(160),
                    "action" to action.take(100),
                    "targetType" to targetType.take(64),
                    "targetId" to targetId.take(128),
                    "details" to details.take(500),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (_: Exception) {
            // Non-fatal
        }
    }

    private fun logStreamErrorIfActive(
        error: Throwable,
        op: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
    }
}
