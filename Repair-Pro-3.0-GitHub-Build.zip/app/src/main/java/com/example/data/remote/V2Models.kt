package com.example.data.remote

import androidx.annotation.Keep

@Keep
data class TechnicianVerificationRequestCloud(
    val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val mobileNumber: String = "",
    val fullAddress: String = "",
    val state: String = "",
    val district: String = "",
    val cityArea: String = "",
    val pinCode: String = "",
    val serviceCategories: List<String> = emptyList(),
    val experience: String = "",
    val bio: String = "",
    val profilePhotoUrl: String = "",
    val profilePhotoStoragePath: String = "",
    val profilePhotoProviderId: String = "",
    val credentialDocUrl: String = "",
    val credentialDocStoragePath: String = "",
    val credentialDocProviderId: String = "",
    val credentialDocName: String = "",
    val status: String = "PENDING", // PENDING, VERIFIED, REJECTED, SUSPENDED
    val rejectionReason: String = "",
    val reviewedByUid: String = "",
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
)

@Keep
data class TechnicalDocumentCloud(
    val id: String = "",
    val docId: String = "",
    val docType: String = "PDF_MANUAL", // PDF_MANUAL, CIRCUIT_DIAGRAM, REPAIR_PHOTO
    val categoryId: String = "ac", // ac, fridge, washer, general
    val brandName: String = "",
    val modelName: String = "",
    val linkedEntryId: String = "",
    val title: String = "",
    val description: String = "",
    val fileUrl: String = "",
    val storagePath: String = "",
    val storageProviderId: String = "supabase_primary",
    val externalRecordId: String = "",
    val mimeType: String = "application/pdf",
    val fileSizeBytes: Long = 0L,
    val published: Boolean = true,
    val offlineAvailable: Boolean = true,
    val isDeleted: Boolean = false,
    val uploadedByUid: String = "",
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
)

@Keep
data class UserNotificationCloud(
    val id: String = "",
    val notificationId: String = "",
    val recipientUid: String = "",
    val actorUid: String = "",
    val type: String = "SYSTEM",
    val title: String = "",
    val body: String = "",
    val imageUrl: String = "",
    val targetRoute: String = "",
    val isRead: Boolean = false,
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
)

@Keep
data class AnnouncementCloud(
    val id: String = "",
    val announcementId: String = "",
    val title: String = "",
    val body: String = "",
    val category: String = "GENERAL", // GENERAL, UPDATE, GUIDE, NEW_GUIDE, NEW_PDF, SAFETY, COMMUNITY
    val imageUrl: String = "",
    val targetRoute: String = "",
    val createdByUid: String = "",
    val createdAt: CloudTimestamp? = null
)

@Keep
data class CommunityUserRestrictionCloud(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val reason: String = "",
    val blockedByUid: String = "",
    val createdAt: CloudTimestamp? = null
)

object V2DomainHelper {
    val ALLOWED_SERVICE_CATEGORIES = listOf("AC", "Refrigerator", "Washing Machine")
    val ALLOWED_DOC_TYPES = listOf("PDF_MANUAL", "CIRCUIT_DIAGRAM", "REPAIR_PHOTO")
    val ALLOWED_DOC_CATEGORIES = listOf("ac", "fridge", "washer", "general")
    val ALLOWED_ANNOUNCEMENT_CATEGORIES = listOf("GENERAL", "UPDATE", "GUIDE", "NEW_GUIDE", "NEW_PDF", "SAFETY", "COMMUNITY")

    fun validateVerificationApplication(
        fullName: String,
        mobileNumber: String,
        fullAddress: String,
        state: String,
        district: String,
        cityArea: String,
        pinCode: String,
        serviceCategories: List<String>
    ): String? {
        val cleanName = fullName.trim()
        val cleanPhone = mobileNumber.trim()
        val cleanPin = pinCode.trim()
        return when {
            cleanName.length < 2 -> "Full name must be at least 2 characters."
            !Regex("^[+0-9\\s\\-()]{6,20}$").matches(cleanPhone) -> "Enter a valid mobile number (6-20 digits)."
            fullAddress.trim().length < 3 -> "Please enter your workshop or service address."
            state.trim().isEmpty() || district.trim().isEmpty() || cityArea.trim().isEmpty() ->
                "State, district, and city/area are required."
            !Regex("^[a-zA-Z0-9\\s\\-]{4,12}$").matches(cleanPin) -> "Enter a valid PIN / postal code."
            serviceCategories.none { it in ALLOWED_SERVICE_CATEGORIES } ->
                "Select at least one service specialization."
            else -> null
        }
    }

    fun countUnreadNotifications(
        userNotifications: List<UserNotificationCloud>,
        announcements: List<AnnouncementCloud>,
        readAnnouncementIds: Set<String>
    ): Int {
        val unreadPersonal = userNotifications.count { !it.isRead }
        val unreadAnnouncements = announcements.count { ann ->
            val key = ann.announcementId.ifBlank { ann.id }
            key.isNotBlank() && key !in readAnnouncementIds
        }
        return unreadPersonal + unreadAnnouncements
    }

    fun isVerifiedTechnicianRecord(tech: TechnicianCloud): Boolean {
        return tech.verificationStatus.equals("VERIFIED", ignoreCase = true) &&
            tech.status.equals("ACTIVE", ignoreCase = true) &&
            !tech.blocked &&
            !tech.isSuspended &&
            !tech.isDeleted
    }
}
