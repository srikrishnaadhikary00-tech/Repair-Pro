package com.example.data.remote

import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Repair Pro v3.0 — Real Supabase Edge Function Client
 * Project: Repair-Pro (xuakzzjtcgcvudkgxpbd)
 * URL: https://xuakzzjtcgcvudkgxpbd.supabase.co
 *
 * Security Invariants:
 * - Authenticates requests with the user's Firebase ID Token (verified cryptographically server-side).
 * - Uses public SUPABASE_ANON_KEY from BuildConfig (Secrets panel) — NEVER embeds service_role or storage secrets.
 * - HTTP 401/403/500 errors NEVER trigger Firebase logout or clear the user/admin session.
 */
object SupabaseApiClient {
    private const val TAG = "SupabaseApiClient"
    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val baseUrl: String
        get() = BuildConfig.SUPABASE_URL.trimEnd('/')

    private val anonKey: String
        get() = runCatching { BuildConfig.SUPABASE_ANON_KEY }.getOrDefault("").trim()

    fun isConfigured(): Boolean {
        return anonKey.isNotBlank() &&
            !anonKey.startsWith("REPLACE_WITH_") &&
            baseUrl.startsWith("https://")
    }

    private suspend fun getFirebaseIdToken(forceRefresh: Boolean = false): String? {
        return try {
            Firebase.auth.currentUser?.getIdToken(forceRefresh)?.await()?.token
        } catch (e: Exception) {
            Log.w(TAG, "Unable to get Firebase ID token: ${e.message}")
            null
        }
    }

    suspend fun checkHealth(): BackendConnectionStatus = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext BackendConnectionStatus(
                firebaseConnected = Firebase.auth.currentUser != null,
                supabaseConfigured = false,
                supabaseReachable = false,
                supabaseMessage = "Set SUPABASE_ANON_KEY in AI Studio Secrets to activate live Supabase Edge Functions (xuakzzjtcgcvudkgxpbd)."
            )
        }
        try {
            val req = Request.Builder()
                .url("$baseUrl/functions/v1/repair-pro-api/health")
                .addHeader("apikey", anonKey)
                .get()
                .build()
            client.newCall(req).execute().use { res ->
                val text = res.body?.string().orEmpty()
                if (res.isSuccessful) {
                    BackendConnectionStatus(
                        firebaseConnected = Firebase.auth.currentUser != null,
                        supabaseConfigured = true,
                        supabaseReachable = true,
                        supabaseMessage = "Connected to Supabase Repair-Pro (xuakzzjtcgcvudkgxpbd) • v3.0"
                    )
                } else {
                    BackendConnectionStatus(
                        firebaseConnected = Firebase.auth.currentUser != null,
                        supabaseConfigured = true,
                        supabaseReachable = false,
                        supabaseMessage = "Supabase Edge Function responded HTTP ${res.code}: ${text.take(120)}"
                    )
                }
            }
        } catch (e: Exception) {
            BackendConnectionStatus(
                firebaseConnected = Firebase.auth.currentUser != null,
                supabaseConfigured = true,
                supabaseReachable = false,
                supabaseMessage = "Supabase unreachable: ${e.localizedMessage ?: "Network error"}"
            )
        }
    }

    private suspend fun callEdgeFunction(
        functionName: String,
        subPath: String,
        method: String = "POST",
        payload: JSONObject? = null,
        forceRefreshToken: Boolean = false
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext Result.failure(
                IllegalStateException("SUPABASE_ANON_KEY is not configured in Secrets panel.")
            )
        }
        val idToken = getFirebaseIdToken(forceRefreshToken)
            ?: return@withContext Result.failure(IllegalStateException("Not signed in with Firebase."))

        val cleanSub = if (subPath.startsWith("/")) subPath else "/$subPath"
        val url = "$baseUrl/functions/v1/$functionName${if (cleanSub == "/") "" else cleanSub}"
        val reqBuilder = Request.Builder()
            .url(url)
            .addHeader("apikey", anonKey)
            .addHeader("Authorization", "Bearer $idToken")
            .addHeader("x-firebase-token", idToken)

        if (method == "GET") {
            reqBuilder.get()
        } else {
            reqBuilder.method(method, (payload ?: JSONObject()).toString().toRequestBody(JSON_MEDIA))
        }

        try {
            client.newCall(reqBuilder.build()).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val json = runCatching { JSONObject(raw) }.getOrElse {
                    JSONObject().put("ok", res.isSuccessful).put("raw", raw)
                }
                if (res.isSuccessful && json.optBoolean("ok", true)) {
                    Result.success(json)
                } else {
                    val errMsg = json.optString("error").ifBlank { "HTTP ${res.code}" }
                    Result.failure(IllegalStateException(errMsg))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    data class UploadedFileResult(
        val publicUrl: String,
        val providerId: String = "",
        val providerName: String = "",
        val mimeType: String = "",
        val sizeBytes: Long = 0L,
        val failoverUsed: Boolean = false
    )

    data class StorageOverviewResult(
        val providers: List<StorageProviderItem>,
        val errorLogs: List<SystemErrorLogItem>
    )

    fun normalizeProviderType(raw: String): String {
        val upper = raw.trim().uppercase()
        return when (upper) {
            "S3_COMPATIBLE", "CUSTOM_ENDPOINT", "AWS_S3", "S3" -> "CUSTOM_S3"
            "R2" -> "CLOUDFLARE_R2"
            "B2" -> "BACKBLAZE_B2"
            "SUPABASE", "CLOUDFLARE_R2", "BACKBLAZE_B2", "CUSTOM_S3" -> upper
            else -> "CUSTOM_S3"
        }
    }

    private fun parseProviderRow(obj: JSONObject): StorageProviderItem {
        return StorageProviderItem(
            id = obj.optString("id"),
            name = obj.optString("name", "Storage Provider"),
            providerType = normalizeProviderType(obj.optString("provider_type", obj.optString("providerType", "SUPABASE"))),
            endpointUrl = obj.optString("endpoint_url", obj.optString("endpointUrl")),
            projectRef = obj.optString("project_ref", obj.optString("projectRef")),
            region = obj.optString("region", "auto").ifBlank { "auto" },
            publicBaseUrl = obj.optString("public_base_url", obj.optString("publicBaseUrl", "")),
            secretEnvKey = obj.optString("secret_env_key", obj.optString("secretEnvKey", "SUPABASE_SERVICE_ROLE_KEY")),
            secretConfigured = when {
                obj.has("secret_configured") && !obj.isNull("secret_configured") -> obj.optBoolean("secret_configured")
                obj.has("secretConfigured") && !obj.isNull("secretConfigured") -> obj.optBoolean("secretConfigured")
                else -> null
            },
            activeFilesCount = obj.optInt("active_files_count", obj.optInt("activeFilesCount", 0)),
            primary = obj.optBoolean("is_primary", obj.optBoolean("primary", false)),
            backup = obj.optBoolean("is_backup", obj.optBoolean("backup", false)),
            enabled = if (obj.has("is_enabled")) obj.optBoolean("is_enabled", true) else obj.optBoolean("enabled", true),
            autoFailoverEnabled = if (obj.has("auto_failover_enabled")) obj.optBoolean("auto_failover_enabled", true) else obj.optBoolean("autoFailoverEnabled", true),
            capacityBytes = obj.optLong("capacity_bytes", obj.optLong("capacityBytes", 1073741824L)),
            usedBytes = obj.optLong("used_bytes", obj.optLong("usedBytes", 0L)),
            lastTestStatus = obj.optString("last_test_status", obj.optString("lastTestStatus", "UNTESTED")),
            lastTestMessage = obj.optString("last_test_message", obj.optString("lastTestMessage", ""))
        )
    }

    private fun parseProviderArray(arr: JSONArray?): List<StorageProviderItem> {
        if (arr == null) return emptyList()
        val list = ArrayList<StorageProviderItem>(arr.length())
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { list.add(parseProviderRow(it)) }
        }
        return list.sortedByDescending { it.primary }
    }

    suspend fun registerFcmToken(fcmToken: String): Result<Unit> {
        if (!isConfigured()) return Result.success(Unit)
        val body = JSONObject()
            .put("fcmToken", fcmToken)
            .put("platform", "android")
            .put("appVersion", BuildConfig.VERSION_NAME)
        return callEdgeFunction("repair-pro-api", "/fcm/register", "POST", body).map { }
    }

    /**
     * Uploads media bytes through the Multi-Cloud Storage Manager (Supabase Primary + Failover Backup).
     * Never exposes storage credentials in Android; returns metadata + public/private registry URL.
     */
    suspend fun uploadFileWithMetadata(
        bucket: String,
        filename: String,
        mimeType: String,
        bytes: ByteArray,
        entityType: String? = null,
        entityId: String? = null
    ): Result<UploadedFileResult> {
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val payload = JSONObject()
            .put("bucket", bucket)
            .put("filename", filename)
            .put("mimeType", mimeType)
            .put("base64", base64)
        if (!entityType.isNullOrBlank()) payload.put("entityType", entityType)
        if (!entityId.isNullOrBlank()) payload.put("entityId", entityId)

        return callEdgeFunction("repair-pro-api", "/storage/upload", "POST", payload).map { json ->
            UploadedFileResult(
                publicUrl = json.optString("publicUrl"),
                providerId = json.optString("providerId"),
                providerName = json.optString("providerName"),
                mimeType = json.optString("mimeType", mimeType),
                sizeBytes = json.optLong("sizeBytes", bytes.size.toLong()),
                failoverUsed = json.optBoolean("failoverUsed", false)
            )
        }
    }

    suspend fun uploadFile(
        bucket: String,
        filename: String,
        mimeType: String,
        bytes: ByteArray,
        entityType: String? = null,
        entityId: String? = null
    ): Result<String> = uploadFileWithMetadata(
        bucket = bucket,
        filename = filename,
        mimeType = mimeType,
        bytes = bytes,
        entityType = entityType,
        entityId = entityId
    ).map { it.publicUrl }

    /**
     * Sends a real FCM HTTP v1 push notification via secure Supabase Edge Function.
     * Session-safe: failures return Result.failure without ever signing out the admin!
     */
    suspend fun sendPushNotification(
        title: String,
        message: String,
        targetType: String,
        targetUids: List<String> = emptyList()
    ): Result<JSONObject> {
        val payload = JSONObject()
            .put("title", title)
            .put("body", message)
            .put("targetType", targetType)
            .put("targetUids", JSONArray(targetUids))
        return callEdgeFunction("send-push-notification", "/", "POST", payload, forceRefreshToken = true)
    }

    suspend fun fetchStorageOverview(): Result<StorageOverviewResult> {
        return callEdgeFunction("repair-pro-api", "/admin/storage/overview", "GET", null).map { json ->
            val providers = parseProviderArray(json.optJSONArray("providers"))
            val errArr = json.optJSONArray("errorLogs")
            val logs = mutableListOf<SystemErrorLogItem>()
            if (errArr != null) {
                for (i in 0 until errArr.length()) {
                    val e = errArr.optJSONObject(i) ?: continue
                    logs.add(
                        SystemErrorLogItem(
                            id = e.optString("id", "sb_err_$i"),
                            source = "${e.optString("provider_name", "storage")} (${e.optString("operation", "UPLOAD")})",
                            severity = "HTTP ${e.optInt("http_status", 500)}",
                            message = e.optString("error_message")
                        )
                    )
                }
            }
            StorageOverviewResult(providers = providers, errorLogs = logs)
        }
    }

    suspend fun upsertStorageProvider(provider: StorageProviderItem): Result<List<StorageProviderItem>> {
        val payload = JSONObject()
            .put("name", provider.name.trim())
            .put("providerType", normalizeProviderType(provider.providerType))
            .put("endpointUrl", provider.endpointUrl.trim())
            .put("projectRef", provider.projectRef.trim())
            .put("region", provider.region.trim().ifBlank { "auto" })
            .put("secretEnvKey", provider.secretEnvKey.trim().ifBlank { "SUPABASE_SERVICE_ROLE_KEY" })
            .put("isPrimary", provider.primary)
            .put("isBackup", !provider.primary && provider.backup)
            .put("isEnabled", provider.enabled)
            .put("autoFailoverEnabled", provider.autoFailoverEnabled)
            .put("capacityBytes", provider.capacityBytes)
        if (provider.publicBaseUrl.isNotBlank()) {
            payload.put("publicBaseUrl", provider.publicBaseUrl.trim())
        }
        if (provider.id.isNotBlank()) {
            payload.put("id", provider.id)
        }
        return callEdgeFunction("repair-pro-api", "/admin/storage/providers", "POST", payload).map { json ->
            parseProviderArray(json.optJSONArray("providers"))
        }
    }

    suspend fun performStorageProviderAction(
        providerId: String,
        action: String,
        targetProviderId: String? = null
    ): Result<Pair<JSONObject, List<StorageProviderItem>>> {
        val payload = JSONObject()
            .put("providerId", providerId)
            .put("action", action.uppercase())
        if (!targetProviderId.isNullOrBlank()) {
            payload.put("targetProviderId", targetProviderId.trim())
        }
        return callEdgeFunction("repair-pro-api", "/admin/storage/providers/action", "POST", payload).map { json ->
            json to parseProviderArray(json.optJSONArray("providers"))
        }
    }

    suspend fun testStorageProvider(providerId: String): Result<JSONObject> {
        val payload = JSONObject().put("providerId", providerId).put("action", "TEST")
        return callEdgeFunction("repair-pro-api", "/admin/storage/providers/action", "POST", payload)
    }

    suspend fun syncRemoteSettings(
        admobConfig: AppSettingCloud? = null,
        announcement: String? = null,
        maintenanceNotice: String? = null,
        minSupportedVersion: String? = null,
        storageAutoFailover: Boolean? = null
    ): Result<Unit> {
        if (!isConfigured()) return Result.success(Unit)
        val payload = JSONObject()
        if (admobConfig != null) {
            payload.put(
                "admob",
                JSONObject()
                    .put("ads_global_enabled", admobConfig.adsGlobalEnabled)
                    .put("emergency_kill_switch", admobConfig.emergencyKillSwitch)
                    .put("banner_enabled", admobConfig.bannerEnabled)
                    .put("interstitial_enabled", admobConfig.interstitialEnabled)
                    .put("rewarded_enabled", admobConfig.rewardedEnabled)
                    .put("native_enabled", admobConfig.nativeEnabled)
                    .put("app_open_enabled", admobConfig.appOpenEnabled)
                    .put("test_mode", admobConfig.testMode)
                    .put("ac_ads_enabled", admobConfig.acAdsEnabled)
                    .put("fridge_ads_enabled", admobConfig.fridgeAdsEnabled)
                    .put("washer_ads_enabled", admobConfig.washerAdsEnabled)
                    .put("interstitial_cooldown_min", admobConfig.interstitialCooldownMin)
                    .put("session_frequency_cap", admobConfig.sessionFrequencyCap)
                    .put("android_app_id", admobConfig.androidAppId)
                    .put("android_banner_id", admobConfig.androidBannerId)
                    .put("android_interstitial_id", admobConfig.androidInterstitialId)
                    .put("android_rewarded_id", admobConfig.androidRewardedId)
                    .put("android_native_id", admobConfig.androidNativeId)
                    .put("android_app_open_id", admobConfig.androidAppOpenId)
                    .put("ios_app_id", admobConfig.iosAppId)
                    .put("ios_banner_id", admobConfig.iosBannerId)
            )
        }
        if (announcement != null || maintenanceNotice != null || minSupportedVersion != null || storageAutoFailover != null) {
            val remoteObj = JSONObject()
            if (announcement != null) remoteObj.put("announcement", announcement.take(400))
            if (maintenanceNotice != null) remoteObj.put("maintenance_notice", maintenanceNotice.take(400))
            if (minSupportedVersion != null) remoteObj.put("min_supported_version", minSupportedVersion.take(32))
            if (storageAutoFailover != null) remoteObj.put("storage_auto_failover", storageAutoFailover)
            payload.put("remote", remoteObj)
        }
        return callEdgeFunction("repair-pro-api", "/admin/settings/remote", "POST", payload).map { }
    }

    suspend fun getAdminVerificationSignedUrl(privateUrl: String): Result<String> {
        val payload = JSONObject().put("privateUrl", privateUrl)
        return callEdgeFunction("repair-pro-api", "/admin/verification/signed-url", "POST", payload).map { json ->
            json.optString("signedUrl")
        }
    }

    suspend fun downloadBytes(fileUrl: String): Result<ByteArray> = withContext(Dispatchers.IO) {
        try {
            if (!fileUrl.startsWith("https://")) {
                return@withContext Result.failure(IllegalArgumentException("Only HTTPS document URLs are allowed."))
            }
            val req = Request.Builder().url(fileUrl).get().build()
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Download failed: HTTP ${res.code}"))
                }
                val bytes = res.body?.bytes() ?: ByteArray(0)
                if (bytes.isEmpty()) {
                    return@withContext Result.failure(IllegalStateException("Downloaded file was empty."))
                }
                Result.success(bytes)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

