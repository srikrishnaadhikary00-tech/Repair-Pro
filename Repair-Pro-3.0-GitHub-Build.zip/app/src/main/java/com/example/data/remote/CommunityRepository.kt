package com.example.data.remote

import android.content.Context
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID

data class PendingCommunityPhoto(
    val bytes: ByteArray,
    val mimeType: String = "image/jpeg"
)

class CommunityRepository(
    private val auth: FirebaseAuth = Firebase.auth,
    private val supabaseClient: SupabaseClient = SupabaseClient(
        firebaseTokenProvider = { forceRefresh ->
            runCatching { auth.currentUser?.getIdToken(forceRefresh)?.await()?.token }.getOrNull()
        }
    ),
    val storageRouter: MultiCloudStorageRouter = MultiCloudStorageRouter(
        authProvider = { auth },
        supabaseClientOverride = supabaseClient
    )
) {
    constructor(context: Context) : this()

    private val postsTick = MutableStateFlow(0L)
    private val likesTick = MutableStateFlow(0L)
    private val bookmarksTick = MutableStateFlow(0L)
    private val commentsTick = MutableStateFlow(0L)
    private val reportsTick = MutableStateFlow(0L)

    fun refreshPosts() {
        val now = System.currentTimeMillis()
        postsTick.value = now
        likesTick.value = now
        bookmarksTick.value = now
    }

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Please sign in with Google to use Technician Community.")
    }

    private fun <T> pollFlow(
        trigger: StateFlow<Long>,
        intervalMs: Long = 20_000L,
        op: OperationType,
        path: String,
        expectedUid: String,
        throwOnInitialFailure: Boolean = false,
        loader: suspend () -> T
    ): Flow<T> = flow {
        var hasEmitted = false
        val ticker = flow {
            var count = 0L
            while (true) {
                emit(count++)
                delay(intervalMs)
            }
        }
        combine(trigger, ticker) { t, c -> t to c }.collect {
            try {
                val value = loader()
                hasEmitted = true
                emit(value)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (auth.currentUser?.uid == expectedUid) {
                    handleCloudError(e, op, path)
                }
                if (throwOnInitialFailure && !hasEmitted) {
                    throw e
                }
            }
        }
    }

    fun observeApprovedPosts(userId: String): Flow<List<CommunityPostCloud>> {
        return pollFlow(
            trigger = postsTick,
            intervalMs = 20_000L,
            op = OperationType.LIST,
            path = "community_posts",
            expectedUid = userId,
            throwOnInitialFailure = true
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_posts",
                categoryKey = "community",
                supabaseQueryParams = "approval_status=eq.APPROVED&is_hidden=eq.false&is_deleted=eq.false&select=*&order=is_pinned.desc,created_at.desc",
                supabaseRequireAuth = false,
                extLimit = 150,
                pkColumns = listOf("post_id", "id")
            ).getOrThrow()

            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toCommunityPost(it) }
                .filter { it.approvalStatus == "APPROVED" && !it.isHidden && !it.isDeleted }
                .sortedWith(
                    compareByDescending<CommunityPostCloud> { it.isPinned }
                        .thenByDescending { it.createdAt?.seconds ?: 0L }
                )
        }
    }

    fun observeMyPosts(userId: String): Flow<List<CommunityPostCloud>> {
        val encUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = postsTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "community_posts/my",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_posts",
                categoryKey = "community",
                supabaseQueryParams = "author_uid=eq.$encUid&select=*&order=created_at.desc",
                supabaseRequireAuth = true,
                extFilters = mapOf("author_uid" to userId),
                extLimit = 120,
                pkColumns = listOf("post_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toCommunityPost(it) }
                .filter { it.authorUid == userId }
                .sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    fun observeAllPostsForAdmin(adminUid: String): Flow<List<CommunityPostCloud>> {
        return pollFlow(
            trigger = postsTick,
            intervalMs = 20_000L,
            op = OperationType.LIST,
            path = "community_posts",
            expectedUid = adminUid
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_posts",
                categoryKey = "community",
                supabaseQueryParams = "select=*&order=is_pinned.desc,created_at.desc",
                supabaseRequireAuth = true,
                extLimit = 200,
                pkColumns = listOf("post_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toCommunityPost(it) }
                .sortedWith(
                    compareByDescending<CommunityPostCloud> { it.isPinned }
                        .thenByDescending { it.createdAt?.seconds ?: 0L }
                )
        }
    }

    fun observePost(postId: String, userId: String): Flow<CommunityPostCloud?> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val encId = URLEncoder.encode(safePostId, "UTF-8")
        return pollFlow(
            trigger = postsTick,
            intervalMs = 15_000L,
            op = OperationType.GET,
            path = "community_posts/$safePostId",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_posts",
                categoryKey = "community",
                supabaseQueryParams = "post_id=eq.$encId&select=*&limit=1",
                supabaseRequireAuth = false,
                extFilters = mapOf("post_id" to safePostId),
                extLimit = 1,
                pkColumns = listOf("post_id", "id")
            ).getOrThrow()
            arr.optJSONObject(0)?.let { SupabaseMappers.toCommunityPost(it) }
        }
    }

    fun observeLikedPostIds(userId: String): Flow<Set<String>> {
        val encUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = likesTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "community_likes/$userId",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_likes",
                categoryKey = "community",
                supabaseQueryParams = "user_id=eq.$encUid&select=post_id,like_id",
                supabaseRequireAuth = true,
                extFilters = mapOf("user_id" to userId),
                extLimit = 300,
                pkColumns = listOf("post_id", "like_id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .mapNotNull { obj -> obj.optString("post_id").takeIf { it.isNotBlank() } }
                .toSet()
        }
    }

    fun observeSavedPosts(userId: String): Flow<List<SavedPostCloud>> {
        val encUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = bookmarksTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "community_bookmarks/$userId",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_bookmarks",
                categoryKey = "community",
                supabaseQueryParams = "user_id=eq.$encUid&select=*&order=created_at.desc",
                supabaseRequireAuth = true,
                extFilters = mapOf("user_id" to userId),
                extLimit = 200,
                pkColumns = listOf("post_id", "bookmark_id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toSavedPost(it) }
                .sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    fun observeComments(postId: String, userId: String): Flow<List<CommunityCommentCloud>> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val encPostId = URLEncoder.encode(safePostId, "UTF-8")
        return pollFlow(
            trigger = commentsTick,
            intervalMs = 15_000L,
            op = OperationType.LIST,
            path = "community_comments/$safePostId",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_comments",
                categoryKey = "community",
                supabaseQueryParams = "post_id=eq.$encPostId&select=*&order=created_at.asc",
                supabaseRequireAuth = false,
                extFilters = mapOf("post_id" to safePostId),
                extLimit = 250,
                extOrderDir = "ASC",
                pkColumns = listOf("comment_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toCommunityComment(it) }
                .filter { it.postId == safePostId }
                .sortedBy { it.createdAt?.seconds ?: 0L }
        }
    }

    fun observeAllCommunityReportsForAdmin(adminUid: String): Flow<List<CommunityReportCloud>> {
        return pollFlow(
            trigger = reportsTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "community_reports",
            expectedUid = adminUid
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "community_reports",
                categoryKey = "community",
                supabaseQueryParams = "select=*&order=created_at.desc",
                supabaseRequireAuth = true,
                extLimit = 200,
                pkColumns = listOf("report_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toCommunityReport(it) }
                .sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    suspend fun loadStorageRoutingConfig(): StorageRoutingConfig {
        return storageRouter.loadRoutingConfig()
    }

    suspend fun uploadCommunityPostPhoto(
        userId: String,
        postId: String,
        imageBytes: ByteArray,
        contentType: String = "image/jpeg",
        index: Int = 0,
        onProgress: (Float) -> Unit = {}
    ): Result<Triple<String, String, String>> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val safeContentType = when (contentType.lowercase()) {
            "image/png" -> "image/png"
            "image/webp" -> "image/webp"
            else -> "image/jpeg"
        }
        val ext = when (safeContentType) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        val objectPath = "$userId/$safePostId/photo_${index}_${System.currentTimeMillis()}.$ext"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            require(imageBytes.isNotEmpty() && imageBytes.size < 5 * 1024 * 1024) {
                "Each photo must be smaller than 5 MB."
            }
            storageRouter.uploadBytes(
                bucketKey = "community",
                objectPath = objectPath,
                bytes = imageBytes,
                mimeType = safeContentType,
                onProgress = onProgress
            ).map { Triple(it.publicUrl, it.storagePath, it.providerId) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createPost(
        userId: String,
        authorName: String,
        authorPhotoUrl: String = "",
        authorVerified: Boolean = false,
        category: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        title: String,
        body: String,
        photos: List<PendingCommunityPhoto> = emptyList(),
        isAdminAuthor: Boolean,
        onUploadProgress: (Float) -> Unit = {}
    ): Result<String> {
        val postId = CloudRepository.sanitizeId("post_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "community_posts/$postId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val routingConfig = storageRouter.loadRoutingConfig()
            val boundedPhotos = if (routingConfig.duplicateCheckEnabled) {
                CommunityDomainHelper.deduplicatePhotos(
                    existingHashes = emptySet(),
                    candidates = photos,
                    maxAllowed = 4
                ).first
            } else {
                photos.take(4)
            }
            val validationError = CommunityDomainHelper.validatePostDraft(
                title = title,
                body = body,
                category = category,
                hasPhotos = boundedPhotos.isNotEmpty()
            )
            require(validationError == null) { validationError ?: "Invalid post." }

            val uploadedItems = mutableListOf<Triple<String, String, String>>()
            val uploadedUrls = mutableListOf<String>()
            val uploadedPaths = mutableListOf<String>()
            val uploadedProviders = mutableListOf<String>()
            boundedPhotos.forEachIndexed { idx, photo ->
                val uploadRes = uploadCommunityPostPhoto(
                    userId = userId,
                    postId = postId,
                    imageBytes = photo.bytes,
                    contentType = photo.mimeType,
                    index = idx,
                    onProgress = { single ->
                        val overall = (idx + single) / boundedPhotos.size.toFloat()
                        onUploadProgress(overall)
                    }
                )
                if (uploadRes.isFailure) {
                    rollbackUploadedPhotos(uploadedItems)
                    return Result.failure(uploadRes.exceptionOrNull() ?: IllegalStateException("Photo upload failed."))
                }
                val item = uploadRes.getOrThrow()
                uploadedItems.add(item)
                uploadedUrls.add(item.first)
                uploadedPaths.add(item.second)
                uploadedProviders.add(item.third)
            }

            val resolvedTitle = CommunityDomainHelper.resolvePostTitle(title, body, category)
            val approvalStatus = if (isAdminAuthor) "APPROVED" else "PENDING"
            val primaryProvider = uploadedProviders.firstOrNull().orEmpty().ifBlank { "supabase_primary" }
            val payload = JSONObject()
                .put("post_id", postId)
                .put("author_uid", userId)
                .put("author_name", authorName.trim().ifBlank { "Repair Pro Member" }.take(80))
                .put("author_photo_url", authorPhotoUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 }.orEmpty())
                .put("author_verified", authorVerified)
                .put("category", category)
                .put("brand_name", brandName.trim().take(80))
                .put("model_name", modelName.trim().take(100))
                .put("error_code", errorCode.trim().uppercase().take(32))
                .put("title", resolvedTitle)
                .put("body", body.trim().take(3000))
                .put("photo_url", uploadedUrls.firstOrNull().orEmpty())
                .put("photo_storage_path", uploadedPaths.firstOrNull().orEmpty())
                .put("photo_urls", JSONArray(uploadedUrls))
                .put("photo_storage_paths", JSONArray(uploadedPaths))
                .put("photo_provider_ids", JSONArray(uploadedProviders))
                .put("storage_provider_id", primaryProvider)
                .put("is_pinned", false)
                .put("is_hidden", false)
                .put("is_deleted", false)
                .put("approval_status", approvalStatus)
                .put("like_count", 0)
                .put("comment_count", 0)
                .put("report_count", 0)

            val writeRes = storageRouter.writeRowWithFailover(
                tableName = "community_posts",
                categoryKey = "community",
                payload = payload,
                onConflict = "post_id",
                mirrorIfActiveExternal = true
            )
            if (writeRes.isFailure) {
                rollbackUploadedPhotos(uploadedItems)
                throw (writeRes.exceptionOrNull() ?: IllegalStateException("Failed to publish community post."))
            }

            postsTick.value += 1
            Result.success(approvalStatus)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    private suspend fun rollbackUploadedPhotos(items: List<Triple<String, String, String>>) {
        if (items.isEmpty()) return
        withContext(NonCancellable) {
            items.forEach { (url, storagePath, providerId) ->
                runCatching {
                    storageRouter.deleteObject(
                        providerId = providerId,
                        bucketKey = "community",
                        storagePath = storagePath,
                        publicUrl = url
                    )
                }
            }
        }
    }

    suspend fun updateOwnPost(
        userId: String,
        postId: String,
        category: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        title: String,
        body: String,
        existingPhotoUrls: List<String>,
        existingStoragePaths: List<String>,
        newPhotos: List<PendingCommunityPhoto> = emptyList(),
        isAdminAuthor: Boolean
    ): Result<String> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val totalPhotoCount = (existingPhotoUrls.size + newPhotos.size).coerceAtMost(4)
            val validationError = CommunityDomainHelper.validatePostDraft(
                title = title,
                body = body,
                category = category,
                hasPhotos = totalPhotoCount > 0
            )
            require(validationError == null) { validationError ?: "Invalid post." }

            val encId = URLEncoder.encode(safePostId, "UTF-8")
            val existingRow = storageRouter.readMergedRows(
                tableName = "community_posts",
                categoryKey = "community",
                supabaseQueryParams = "post_id=eq.$encId&select=*&limit=1",
                supabaseRequireAuth = true,
                extFilters = mapOf("post_id" to safePostId),
                extLimit = 1,
                pkColumns = listOf("post_id", "id")
            ).getOrNull()?.optJSONObject(0)
            val previousPost = existingRow?.let { SupabaseMappers.toCommunityPost(it) }
            val previousUrls = previousPost?.resolvedPhotoUrls().orEmpty()
            val previousPaths = previousPost?.resolvedStoragePaths().orEmpty()
            val previousProviders = previousPost?.photoProviderIds.orEmpty()

            val finalUrls = existingPhotoUrls.distinct().take(4).toMutableList()
            val finalPaths = existingStoragePaths.distinct().take(4).toMutableList()
            val finalProviders = mutableListOf<String>()
            finalUrls.forEach { keptUrl ->
                val prevIdx = previousUrls.indexOf(keptUrl)
                finalProviders.add(previousProviders.getOrNull(prevIdx).orEmpty().ifBlank { "existing" })
            }
            val slotsLeft = (4 - finalUrls.size).coerceAtLeast(0)
            val (dedupedNewPhotos, _) = CommunityDomainHelper.deduplicatePhotos(
                existingHashes = emptySet(),
                candidates = newPhotos,
                maxAllowed = slotsLeft
            )
            val newlyUploaded = mutableListOf<Triple<String, String, String>>()
            dedupedNewPhotos.forEachIndexed { idx, photo ->
                val res = uploadCommunityPostPhoto(userId, safePostId, photo.bytes, photo.mimeType, finalUrls.size + idx)
                if (res.isFailure) {
                    rollbackUploadedPhotos(newlyUploaded)
                    return Result.failure(res.exceptionOrNull() ?: IllegalStateException("Photo upload failed."))
                }
                val item = res.getOrThrow()
                newlyUploaded.add(item)
                finalUrls.add(item.first)
                finalPaths.add(item.second)
                finalProviders.add(item.third)
            }

            val nextStatus = if (isAdminAuthor) "APPROVED" else "PENDING"
            val updates = JSONObject()
                .put("category", category)
                .put("brand_name", brandName.trim().take(80))
                .put("model_name", modelName.trim().take(100))
                .put("error_code", errorCode.trim().uppercase().take(32))
                .put("title", CommunityDomainHelper.resolvePostTitle(title, body, category))
                .put("body", body.trim().take(3000))
                .put("photo_url", finalUrls.firstOrNull() ?: "")
                .put("photo_storage_path", finalPaths.firstOrNull() ?: "")
                .put("photo_urls", JSONArray(finalUrls))
                .put("photo_storage_paths", JSONArray(finalPaths))
                .put("photo_provider_ids", JSONArray(finalProviders))
                .put("approval_status", nextStatus)
                .put("updated_at", CloudTimestamp.toIsoString())

            val patchRes = storageRouter.patchRowWithFailover(
                tableName = "community_posts",
                categoryKey = "community",
                recordId = previousPost?.externalRecordId?.ifBlank { safePostId } ?: safePostId,
                supabaseFilterQuery = "post_id=eq.$encId",
                patchJson = updates
            )
            if (patchRes.isFailure) {
                rollbackUploadedPhotos(newlyUploaded)
                throw (patchRes.exceptionOrNull() ?: IllegalStateException("Post update failed."))
            }

            withContext(NonCancellable) {
                previousUrls.forEachIndexed { idx, oldUrl ->
                    if (oldUrl !in finalUrls) {
                        val oldPath = previousPaths.getOrNull(idx).orEmpty()
                        val oldProv = previousProviders.getOrNull(idx).orEmpty()
                        runCatching {
                            storageRouter.deleteObject(
                                providerId = oldProv,
                                bucketKey = "community",
                                storagePath = oldPath,
                                publicUrl = oldUrl
                            )
                        }
                    }
                }
            }
            postsTick.value += 1
            Result.success(nextStatus)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleLike(
        userId: String,
        postId: String,
        currentlyLiked: Boolean
    ): Result<Boolean> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_likes/$safePostId/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val cfg = storageRouter.loadRoutingConfig()
            val likeId = "${userId}__$safePostId"

            suspend fun toggleOnExternal(): Boolean {
                val extProviders = storageRouter.resolveFailoverExternalDbProviders("community")
                var anyOk = false
                for (prov in extProviders) {
                    val res = if (currentlyLiked) {
                        storageRouter.externalDbDelete(prov, "community_likes", likeId)
                    } else {
                        storageRouter.externalDbUpsert(
                            prov,
                            "community_likes",
                            JSONObject()
                                .put("like_id", likeId)
                                .put("post_id", safePostId)
                                .put("user_id", userId)
                        ).map { Unit }
                    }
                    if (res.isSuccess) anyOk = true
                }
                return anyOk
            }

            val liked = if (storageRouter.isPrimaryDatabaseSupabase(cfg)) {
                val rpcRes = supabaseClient.callRpc(
                    rpcName = "toggle_community_like",
                    paramsJson = JSONObject().put("p_post_id", safePostId),
                    requireAuth = true
                )
                if (rpcRes.isSuccess) {
                    val raw = rpcRes.getOrThrow()
                    runCatching { JSONObject(raw).optBoolean("liked", !currentlyLiked) }.getOrDefault(!currentlyLiked)
                } else {
                    val err = rpcRes.exceptionOrNull()
                    if (MultiCloudStorageRouter.isSupabaseQuotaOrOutageFailure(err) && toggleOnExternal()) {
                        !currentlyLiked
                    } else {
                        throw (err ?: IllegalStateException("Like update failed."))
                    }
                }
            } else {
                if (toggleOnExternal()) {
                    !currentlyLiked
                } else {
                    val raw = supabaseClient.callRpc(
                        rpcName = "toggle_community_like",
                        paramsJson = JSONObject().put("p_post_id", safePostId),
                        requireAuth = true
                    ).getOrThrow()
                    runCatching { JSONObject(raw).optBoolean("liked", !currentlyLiked) }.getOrDefault(!currentlyLiked)
                }
            }
            likesTick.value += 1
            postsTick.value += 1
            Result.success(liked)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun addCommentOrReply(
        userId: String,
        authorName: String,
        authorVerified: Boolean = false,
        postId: String,
        body: String,
        parentCommentId: String = "",
        replyToAuthorName: String = "",
        postAuthorUid: String = "",
        replyTargetUid: String = ""
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val commentId = CloudRepository.sanitizeId("cmt_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "community_comments/$commentId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val err = CommunityDomainHelper.validateCommentBody(body)
            require(err == null) { err ?: "Invalid comment." }

            val cleanAuthor = authorName.trim().ifBlank { "Repair Pro Member" }.take(80)
            val cleanBody = body.trim().take(1000)
            val cleanParent = parentCommentId.trim().take(128)
            val cleanReplyTo = replyToAuthorName.trim().take(80)
            val rpcParams = JSONObject()
                .put("p_comment_id", commentId)
                .put("p_post_id", safePostId)
                .put("p_parent_comment_id", cleanParent)
                .put("p_reply_to_author_name", cleanReplyTo)
                .put("p_author_name", cleanAuthor)
                .put("p_author_verified", authorVerified)
                .put("p_body", cleanBody)
            val extCommentPayload = JSONObject()
                .put("comment_id", commentId)
                .put("post_id", safePostId)
                .put("parent_comment_id", cleanParent)
                .put("reply_to_author_name", cleanReplyTo)
                .put("author_uid", userId)
                .put("author_name", cleanAuthor)
                .put("author_verified", authorVerified)
                .put("body", cleanBody)
                .put("is_hidden", false)
                .put("is_deleted", false)

            val cfg = storageRouter.loadRoutingConfig()
            suspend fun insertExternalComment(): Boolean {
                for (prov in storageRouter.resolveFailoverExternalDbProviders("community")) {
                    if (storageRouter.externalDbUpsert(prov, "community_comments", extCommentPayload).isSuccess) {
                        return true
                    }
                }
                return false
            }

            if (storageRouter.isPrimaryDatabaseSupabase(cfg)) {
                val rpcRes = supabaseClient.callRpc("add_community_comment", rpcParams, requireAuth = true)
                if (rpcRes.isFailure) {
                    val rpcErr = rpcRes.exceptionOrNull()
                    if (!(MultiCloudStorageRouter.isSupabaseQuotaOrOutageFailure(rpcErr) && insertExternalComment())) {
                        throw (rpcErr ?: IllegalStateException("Failed to post comment."))
                    }
                }
            } else {
                if (!insertExternalComment()) {
                    supabaseClient.callRpc("add_community_comment", rpcParams, requireAuth = true).getOrThrow()
                }
            }

            val targetRecipient = when {
                replyTargetUid.isNotBlank() && replyTargetUid != userId -> replyTargetUid
                postAuthorUid.isNotBlank() && postAuthorUid != userId -> postAuthorUid
                else -> ""
            }
            if (targetRecipient.isNotBlank()) {
                val isReply = parentCommentId.isNotBlank()
                sendBestEffortNotification(
                    recipientUid = targetRecipient,
                    actorUid = userId,
                    type = if (isReply) "REPLY" else "COMMENT",
                    title = if (isReply) "$cleanAuthor replied to your comment" else "$cleanAuthor commented on your post",
                    body = cleanBody.take(180),
                    targetRoute = "community/post/$safePostId"
                )
            }
            commentsTick.value += 1
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun editCommentOrReply(
        postId: String,
        commentId: String,
        newBody: String
    ): Result<Unit> {
        val safeCommentId = CloudRepository.sanitizeId(commentId)
        val path = "community_comments/$safeCommentId"
        return try {
            requireUserId()
            val err = CommunityDomainHelper.validateCommentBody(newBody)
            require(err == null) { err ?: "Invalid comment." }
            val encId = URLEncoder.encode(safeCommentId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "community_comments",
                categoryKey = "community",
                recordId = safeCommentId,
                supabaseFilterQuery = "comment_id=eq.$encId",
                patchJson = JSONObject()
                    .put("body", newBody.trim().take(1000))
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            commentsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteCommentOrReply(postId: String, commentId: String): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val safeCommentId = CloudRepository.sanitizeId(commentId)
        val path = "community_comments/$safeCommentId"
        return try {
            requireUserId()
            val cfg = storageRouter.loadRoutingConfig()
            val encCommentId = URLEncoder.encode(safeCommentId, "UTF-8")
            if (storageRouter.isPrimaryDatabaseSupabase(cfg)) {
                val rpcRes = supabaseClient.callRpc(
                    rpcName = "delete_community_comment",
                    paramsJson = JSONObject()
                        .put("p_comment_id", safeCommentId)
                        .put("p_post_id", safePostId),
                    requireAuth = true
                )
                if (rpcRes.isFailure) {
                    val rpcErr = rpcRes.exceptionOrNull()
                    if (MultiCloudStorageRouter.isSupabaseQuotaOrOutageFailure(rpcErr)) {
                        storageRouter.deleteRowWithFailover(
                            tableName = "community_comments",
                            categoryKey = "community",
                            recordId = safeCommentId,
                            supabaseFilterQuery = "comment_id=eq.$encCommentId"
                        ).getOrThrow()
                    } else {
                        throw (rpcErr ?: IllegalStateException("Failed to delete comment."))
                    }
                }
            } else {
                storageRouter.deleteRowWithFailover(
                    tableName = "community_comments",
                    categoryKey = "community",
                    recordId = safeCommentId,
                    supabaseFilterQuery = "comment_id=eq.$encCommentId"
                ).getOrThrow()
            }
            commentsTick.value += 1
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleBookmarkPost(
        userId: String,
        post: CommunityPostCloud,
        currentlySaved: Boolean
    ): Result<Boolean> {
        val safePostId = CloudRepository.sanitizeId(post.postId.ifBlank { post.id })
        val path = "community_bookmarks/$userId/$safePostId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val bookmarkId = "${userId}__$safePostId"
            if (currentlySaved) {
                val encUid = URLEncoder.encode(userId, "UTF-8")
                val encPid = URLEncoder.encode(safePostId, "UTF-8")
                storageRouter.deleteRowWithFailover(
                    tableName = "community_bookmarks",
                    categoryKey = "community",
                    recordId = bookmarkId,
                    supabaseFilterQuery = "user_id=eq.$encUid&post_id=eq.$encPid"
                ).getOrThrow()
            } else {
                val payload = JSONObject()
                    .put("bookmark_id", bookmarkId)
                    .put("user_id", userId)
                    .put("post_id", safePostId)
                    .put("title", post.title.trim().ifBlank { "Community Post" }.take(140))
                    .put("category", if (post.category in COMMUNITY_CATEGORIES) post.category else "General")
                    .put("author_name", post.authorName.trim().ifBlank { "Technician" }.take(80))
                    .put("photo_url", post.resolvedPhotoUrls().firstOrNull()?.takeIf { it.length <= 1000 }.orEmpty())
                storageRouter.writeRowWithFailover(
                    tableName = "community_bookmarks",
                    categoryKey = "community",
                    payload = payload,
                    onConflict = "user_id,post_id"
                ).getOrThrow()
            }
            bookmarksTick.value += 1
            Result.success(!currentlySaved)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun reportCommunityContent(
        userId: String,
        reporterName: String,
        postId: String,
        commentId: String = "",
        reason: String,
        details: String
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val reportId = CloudRepository.sanitizeId("crep_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "community_reports/$reportId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            require(CommunityDomainHelper.validateReportReason(reason)) { "Select a valid report reason." }

            val cleanReporter = reporterName.trim().ifBlank { "Repair Pro User" }.take(80)
            val cleanDetails = details.trim().take(600)
            val cleanCommentId = commentId.trim().take(128)
            val rpcParams = JSONObject()
                .put("p_report_id", reportId)
                .put("p_post_id", safePostId)
                .put("p_comment_id", cleanCommentId)
                .put("p_reporter_name", cleanReporter)
                .put("p_reason", reason)
                .put("p_details", cleanDetails)
            val extReportPayload = JSONObject()
                .put("report_id", reportId)
                .put("target_type", if (cleanCommentId.isNotBlank()) "COMMENT" else "POST")
                .put("target_id", cleanCommentId.ifBlank { safePostId })
                .put("post_id", safePostId)
                .put("comment_id", cleanCommentId)
                .put("reporter_uid", userId)
                .put("reporter_name", cleanReporter)
                .put("reason", reason)
                .put("details", cleanDetails)
                .put("status", "OPEN")

            val cfg = storageRouter.loadRoutingConfig()
            suspend fun insertExternalReport(): Boolean {
                for (prov in storageRouter.resolveFailoverExternalDbProviders("community")) {
                    if (storageRouter.externalDbUpsert(prov, "community_reports", extReportPayload).isSuccess) {
                        return true
                    }
                }
                return false
            }

            if (storageRouter.isPrimaryDatabaseSupabase(cfg)) {
                val rpcRes = supabaseClient.callRpc("submit_community_report", rpcParams, requireAuth = true)
                if (rpcRes.isFailure) {
                    val rpcErr = rpcRes.exceptionOrNull()
                    if (!(MultiCloudStorageRouter.isSupabaseQuotaOrOutageFailure(rpcErr) && insertExternalReport())) {
                        throw (rpcErr ?: IllegalStateException("Report submission failed."))
                    }
                }
            } else {
                if (!insertExternalReport()) {
                    supabaseClient.callRpc("submit_community_report", rpcParams, requireAuth = true).getOrThrow()
                }
            }
            reportsTick.value += 1
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deletePost(
        post: CommunityPostCloud,
        asAdmin: Boolean
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(post.postId.ifBlank { post.id })
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safePostId, "UTF-8")
            storageRouter.deleteRowWithFailover(
                tableName = "community_posts",
                categoryKey = "community",
                recordId = post.externalRecordId.ifBlank { safePostId },
                supabaseFilterQuery = "post_id=eq.$encId"
            ).getOrThrow()
            val urls = post.resolvedPhotoUrls()
            val paths = post.resolvedStoragePaths()
            val maxItems = maxOf(urls.size, paths.size)
            for (idx in 0 until maxItems) {
                runCatching {
                    storageRouter.deleteObject(
                        providerId = post.photoProviderIds.getOrNull(idx).orEmpty(),
                        bucketKey = "community",
                        storagePath = paths.getOrNull(idx).orEmpty(),
                        publicUrl = urls.getOrNull(idx).orEmpty()
                    )
                }
            }
            if (asAdmin) {
                logAdminAction(uid, "DELETE_COMMUNITY_POST", "community_posts", safePostId, "Deleted '${post.title.take(80)}'")
            }
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun softDeletePost(postId: String, reason: String = ""): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            val patch = JSONObject()
                .put("is_deleted", true)
                .put("deleted_by_uid", uid)
                .put("deleted_at", CloudTimestamp.toIsoString())
                .put("updated_at", CloudTimestamp.toIsoString())
            if (reason.isNotBlank()) patch.put("moderation_note", reason.trim().take(500))
            val encId = URLEncoder.encode(safePostId, "UTF-8")
            storageRouter.patchRowWithFailover("community_posts", "community", safePostId, "post_id=eq.$encId", patch).getOrThrow()
            logAdminAction(uid, "SOFT_DELETE_COMMUNITY_POST", "community_posts", safePostId, reason.ifBlank { "Soft deleted post" })
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun restorePost(postId: String): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safePostId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "community_posts",
                categoryKey = "community",
                recordId = safePostId,
                supabaseFilterQuery = "post_id=eq.$encId",
                patchJson = JSONObject()
                    .put("is_deleted", false)
                    .put("is_hidden", false)
                    .put("deleted_by_uid", "")
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(uid, "RESTORE_COMMUNITY_POST", "community_posts", safePostId, "Restored community post")
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminSetPostHidden(postId: String, hidden: Boolean): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safePostId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "community_posts",
                categoryKey = "community",
                recordId = safePostId,
                supabaseFilterQuery = "post_id=eq.$encId",
                patchJson = JSONObject()
                    .put("is_hidden", hidden)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(uid, if (hidden) "HIDE_COMMUNITY_POST" else "UNHIDE_COMMUNITY_POST", "community_posts", safePostId, "isHidden=$hidden")
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminEditPost(
        postId: String,
        title: String,
        body: String,
        brandName: String,
        modelName: String,
        errorCode: String
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            val cleanTitle = title.trim().take(140)
            val cleanBody = body.trim().take(3000)
            require(cleanTitle.length >= 2) { "Title must be at least 2 characters." }
            val encId = URLEncoder.encode(safePostId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "community_posts",
                categoryKey = "community",
                recordId = safePostId,
                supabaseFilterQuery = "post_id=eq.$encId",
                patchJson = JSONObject()
                    .put("title", cleanTitle)
                    .put("body", cleanBody)
                    .put("brand_name", brandName.trim().take(80))
                    .put("model_name", modelName.trim().take(100))
                    .put("error_code", errorCode.trim().uppercase().take(32))
                    .put("reviewed_by_uid", uid)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(uid, "EDIT_COMMUNITY_POST", "community_posts", safePostId, "Edited '$cleanTitle'")
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun removePhotoFromPost(post: CommunityPostCloud, photoIndex: Int): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(post.postId.ifBlank { post.id })
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            val urls = post.resolvedPhotoUrls().toMutableList()
            val paths = post.resolvedStoragePaths().toMutableList()
            val providers = post.photoProviderIds.toMutableList()
            if (photoIndex !in urls.indices && photoIndex !in paths.indices) {
                return Result.failure(IllegalArgumentException("Invalid photo index."))
            }
            val removedUrl = urls.getOrNull(photoIndex).orEmpty()
            val removedPath = paths.getOrNull(photoIndex).orEmpty()
            val removedProvider = providers.getOrNull(photoIndex).orEmpty()
            if (photoIndex in urls.indices) urls.removeAt(photoIndex)
            if (photoIndex in paths.indices) paths.removeAt(photoIndex)
            if (photoIndex in providers.indices) providers.removeAt(photoIndex)

            val encId = URLEncoder.encode(safePostId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "community_posts",
                categoryKey = "community",
                recordId = post.externalRecordId.ifBlank { safePostId },
                supabaseFilterQuery = "post_id=eq.$encId",
                patchJson = JSONObject()
                    .put("photo_url", urls.firstOrNull() ?: "")
                    .put("photo_storage_path", paths.firstOrNull() ?: "")
                    .put("photo_urls", JSONArray(urls))
                    .put("photo_storage_paths", JSONArray(paths))
                    .put("photo_provider_ids", JSONArray(providers))
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()

            runCatching {
                storageRouter.deleteObject(
                    providerId = removedProvider,
                    bucketKey = "community",
                    storagePath = removedPath,
                    publicUrl = removedUrl
                )
            }
            logAdminAction(uid, "REMOVE_COMMUNITY_PHOTO", "community_posts", safePostId, "Removed photo #$photoIndex")
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun moderatePost(
        postId: String,
        newStatus: String,
        moderationNote: String,
        authorUid: String = "",
        postTitle: String = ""
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        val cleanStatus = when (newStatus) {
            "APPROVED" -> "APPROVED"
            "REJECTED" -> "REJECTED"
            else -> "PENDING"
        }
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safePostId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "community_posts",
                categoryKey = "community",
                recordId = safePostId,
                supabaseFilterQuery = "post_id=eq.$encId",
                patchJson = JSONObject()
                    .put("approval_status", cleanStatus)
                    .put("moderation_note", moderationNote.trim().take(500))
                    .put("reviewed_by_uid", uid)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()

            if (authorUid.isNotBlank() && authorUid != uid && cleanStatus in listOf("APPROVED", "REJECTED")) {
                sendBestEffortNotification(
                    recipientUid = authorUid,
                    actorUid = uid,
                    type = if (cleanStatus == "APPROVED") "POST_APPROVED" else "POST_REJECTED",
                    title = if (cleanStatus == "APPROVED") "Community Post Approved" else "Community Post Needs Attention",
                    body = if (cleanStatus == "APPROVED") {
                        "Your post '${postTitle.take(60)}' is now live in Technician Community."
                    } else {
                        "Your post '${postTitle.take(60)}' was rejected.${if (moderationNote.isNotBlank()) " Note: ${moderationNote.trim()}" else ""}"
                    },
                    targetRoute = "community/post/$safePostId"
                )
            }

            logAdminAction(
                uid,
                "MODERATE_COMMUNITY_POST",
                "community_posts",
                safePostId,
                "Status -> $cleanStatus${if (moderationNote.isNotBlank()) " (${moderationNote.trim().take(120)})" else ""}"
            )
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun togglePinPost(postId: String, pinned: Boolean): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safePostId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "community_posts",
                categoryKey = "community",
                recordId = safePostId,
                supabaseFilterQuery = "post_id=eq.$encId",
                patchJson = JSONObject()
                    .put("is_pinned", pinned)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(uid, if (pinned) "PIN_COMMUNITY_POST" else "UNPIN_COMMUNITY_POST", "community_posts", safePostId, "isPinned=$pinned")
            postsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateCommunityReportStatus(
        reportId: String,
        newStatus: String,
        adminNote: String
    ): Result<Unit> {
        val safeReportId = CloudRepository.sanitizeId(reportId)
        val path = "community_reports/$safeReportId"
        val cleanStatus = when (newStatus) {
            "REVIEWED", "RESOLVED", "DISMISSED" -> newStatus
            else -> "OPEN"
        }
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safeReportId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "community_reports",
                categoryKey = "community",
                recordId = safeReportId,
                supabaseFilterQuery = "report_id=eq.$encId",
                patchJson = JSONObject()
                    .put("status", cleanStatus)
                    .put("admin_note", adminNote.trim().take(500))
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(uid, "MODERATE_COMMUNITY_REPORT", "community_reports", safeReportId, "Report -> $cleanStatus")
            reportsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    private suspend fun sendBestEffortNotification(
        recipientUid: String,
        actorUid: String,
        type: String,
        title: String,
        body: String,
        targetRoute: String
    ) {
        try {
            val notifId = CloudRepository.sanitizeId("ntf_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            supabaseClient.insertRow(
                "user_notifications",
                JSONObject()
                    .put("notification_id", notifId)
                    .put("recipient_uid", CloudRepository.sanitizeId(recipientUid))
                    .put("actor_uid", actorUid.take(128))
                    .put("type", type)
                    .put("title", title.take(140))
                    .put("body", body.take(600))
                    .put("target_route", targetRoute.take(160))
                    .put("is_read", false),
                requireAuth = true
            )
        } catch (_: Exception) {
            // Best-effort
        }
    }

    private suspend fun logAdminAction(
        adminUid: String,
        action: String,
        targetType: String,
        targetId: String,
        details: String
    ) {
        try {
            val logId = CloudRepository.sanitizeId("log_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            val email = auth.currentUser?.email ?: "admin@repairpro.local"
            supabaseClient.insertRow(
                "audit_logs",
                JSONObject()
                    .put("log_id", logId)
                    .put("admin_uid", adminUid)
                    .put("admin_email", email.take(160))
                    .put("action", action.take(100))
                    .put("target_type", targetType.take(64))
                    .put("target_id", targetId.take(128))
                    .put("details", details.take(500))
                    .put("result", "SUCCESS"),
                requireAuth = true
            )
        } catch (_: Exception) {
            // Non-fatal
        }
    }
}
