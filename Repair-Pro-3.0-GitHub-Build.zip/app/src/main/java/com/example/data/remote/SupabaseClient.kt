package com.example.data.remote

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class SupabaseUploadResponse(
    val publicUrl: String,
    val storagePath: String,
    val bucketName: String
)

class SupabaseClient(
    private val httpClient: OkHttpClient = defaultHttpClient()
) {
    fun resolveUrl(overrideUrl: String? = null): String {
        val candidate = (overrideUrl?.trim().orEmpty())
            .ifBlank { BuildConfig.SUPABASE_URL.trim() }
            .ifBlank { DEFAULT_SUPABASE_URL }
        return if (isPlaceholderOrBlank(candidate)) DEFAULT_SUPABASE_URL else candidate.trimEnd('/')
    }

    fun resolveAnonKey(overrideAnonKey: String? = null): String {
        val candidate = overrideAnonKey?.trim().orEmpty().ifBlank { BuildConfig.SUPABASE_ANON_KEY.trim() }
        return if (isPlaceholderOrBlank(candidate)) "" else candidate
    }

    fun isConfigured(overrideUrl: String? = null, overrideAnonKey: String? = null): Boolean {
        val url = resolveUrl(overrideUrl)
        val key = resolveAnonKey(overrideAnonKey)
        return url.startsWith("https://") && key.isNotBlank()
    }

    suspend fun uploadObject(
        bucketName: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String,
        isPublicBucket: Boolean = true,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<SupabaseUploadResponse> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Supabase Public Anon Key is not configured yet.")
            )
        }
        val cleanPath = objectPath.trimStart('/')
        val encodedSegments = cleanPath.split("/")
            .filter { it.isNotBlank() }
            .joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
        val encodedBucket = URLEncoder.encode(bucketName, "UTF-8").replace("+", "%20")
        val targetUrl = "$urlBase/storage/v1/object/$encodedBucket/$encodedSegments"

        val mediaType = mimeType.toMediaTypeOrNull() ?: "application/octet-stream".toMediaTypeOrNull()
        val body = bytes.toRequestBody(mediaType)

        val req = Request.Builder()
            .url(targetUrl)
            .post(body)
            .addHeader("apikey", anonKey)
            .addHeader("Authorization", "Bearer $anonKey")
            .addHeader("Content-Type", mimeType)
            .addHeader("x-upsert", "true")
            .build()

        runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val msg = resp.body?.string().orEmpty().take(240)
                    val detail = when (resp.code) {
                        401, 403 -> "Supabase Storage permission denied (HTTP ${resp.code}): check SUPABASE_ANON_KEY or Storage bucket RLS policy for '$bucketName'. $msg"
                        else -> "Supabase Storage HTTP ${resp.code}: $msg"
                    }
                    throw IllegalStateException(detail.trim())
                }
            }
            val visibility = if (isPublicBucket) "public" else "authenticated"
            val publicUrl = "$urlBase/storage/v1/object/$visibility/$bucketName/$cleanPath"
            SupabaseUploadResponse(
                publicUrl = publicUrl,
                storagePath = "$bucketName/$cleanPath",
                bucketName = bucketName
            )
        }
    }

    suspend fun deleteObject(
        bucketName: String,
        objectPath: String,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) return@withContext Result.success(Unit)
        val cleanPath = objectPath.trimStart('/')
        val jsonBody = JSONObject().put("prefixes", org.json.JSONArray().put(cleanPath)).toString()
        val req = Request.Builder()
            .url("$urlBase/storage/v1/object/$bucketName")
            .delete(jsonBody.toRequestBody("application/json".toMediaTypeOrNull()))
            .addHeader("apikey", anonKey)
            .addHeader("Authorization", "Bearer $anonKey")
            .build()
        runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful && resp.code != 404) {
                    throw IllegalStateException("Supabase delete HTTP ${resp.code}")
                }
            }
        }
    }

    suspend fun upsertTableRow(
        tableName: String,
        rowJson: JSONObject,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null,
        onConflict: String? = null
    ): Result<Unit> = upsertTableRowRawJson(
        tableName = tableName,
        rawJson = rowJson.toString(),
        overrideUrl = overrideUrl,
        overrideAnonKey = overrideAnonKey,
        onConflict = onConflict
    )

    suspend fun upsertTableRowRawJson(
        tableName: String,
        rawJson: String,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null,
        onConflict: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) {
            return@withContext Result.success(Unit)
        }
        val querySuffix = onConflict?.trim()?.takeIf { it.isNotEmpty() }
            ?.let { "?on_conflict=${URLEncoder.encode(it, "UTF-8")}" }
            .orEmpty()
        val req = Request.Builder()
            .url("$urlBase/rest/v1/$tableName$querySuffix")
            .post(rawJson.toRequestBody("application/json".toMediaTypeOrNull()))
            .addHeader("apikey", anonKey)
            .addHeader("Authorization", "Bearer $anonKey")
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "resolution=merge-duplicates,return=minimal")
            .build()
        runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string().orEmpty().take(180)
                    throw IllegalStateException("Supabase PostgREST HTTP ${resp.code}: $err")
                }
            }
        }
    }

    companion object {
        const val DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co"
        const val DEFAULT_FCM_ENDPOINT = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-push-notification"

        fun isPlaceholderOrBlank(value: String?): Boolean {
            val v = value?.trim().orEmpty()
            return v.isBlank() || v.startsWith("YOUR_", ignoreCase = true)
        }

        internal fun jsonEscape(value: String): String {
            val sb = StringBuilder(value.length + 8)
            for (ch in value) {
                when (ch) {
                    '\\' -> sb.append("\\\\")
                    '"' -> sb.append("\\\"")
                    '\n' -> sb.append("\\n")
                    '\r' -> sb.append("\\r")
                    '\t' -> sb.append("\\t")
                    else -> if (ch < ' ') {
                        sb.append("\\u%04x".format(ch.code))
                    } else {
                        sb.append(ch)
                    }
                }
            }
            return sb.toString()
        }

        fun buildLiveTechnicianJson(
            id: String,
            name: String,
            phone: String,
            photoUrl: String,
            bio: String,
            specialty: String,
            location: String
        ): String {
            return buildString {
                append('{')
                append("\"id\":\"").append(jsonEscape(id)).append("\",")
                append("\"name\":\"").append(jsonEscape(name)).append("\",")
                append("\"phone\":\"").append(jsonEscape(phone)).append("\",")
                append("\"photo_url\":\"").append(jsonEscape(photoUrl)).append("\",")
                append("\"bio\":\"").append(jsonEscape(bio)).append("\",")
                append("\"specialty\":\"").append(jsonEscape(specialty)).append("\",")
                append("\"location\":\"").append(jsonEscape(location)).append("\"")
                append('}')
            }
        }

        fun defaultHttpClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(45, TimeUnit.SECONDS)
            .build()
    }
}
