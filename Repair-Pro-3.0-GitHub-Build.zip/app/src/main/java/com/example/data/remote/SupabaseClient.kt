package com.example.data.remote

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class SupabaseUploadResponse(
    val publicUrl: String,
    val storagePath: String,
    val bucketName: String
)

class SupabaseClient(
    private val httpClient: OkHttpClient = defaultHttpClient(),
    private val firebaseTokenProvider: (suspend (forceRefresh: Boolean) -> String?)? = null
) {
    fun resolveUrl(overrideUrl: String? = null): String {
        val candidate = (overrideUrl?.trim().orEmpty())
            .ifBlank { BuildConfig.SUPABASE_URL.trim() }
            .ifBlank { DEFAULT_SUPABASE_URL }
        return if (isPlaceholderOrBlank(candidate)) DEFAULT_SUPABASE_URL else candidate.trimEnd('/')
    }

    fun resolveAnonKey(overrideAnonKey: String? = null): String {
        val candidate = overrideAnonKey?.trim().orEmpty().ifBlank { BuildConfig.SUPABASE_ANON_KEY.trim() }
        return if (isPlaceholderOrBlank(candidate)) "" else candidate
    }

    fun isConfigured(overrideUrl: String? = null, overrideAnonKey: String? = null): Boolean {
        val url = resolveUrl(overrideUrl)
        val key = resolveAnonKey(overrideAnonKey)
        return url.startsWith("https://") && key.isNotBlank()
    }

    suspend fun getFirebaseIdToken(forceRefresh: Boolean = false): String? {
        return firebaseTokenProvider?.invoke(forceRefresh)?.trim()?.takeIf { it.isNotEmpty() }
    }

    private suspend fun executeWithAuthRetry(
        anonKey: String,
        requireFirebaseToken: Boolean = true,
        buildRequest: (bearerToken: String) -> Request
    ): okhttp3.Response {
        val initialFirebaseToken = firebaseTokenProvider?.invoke(false)?.trim().orEmpty()
        if (requireFirebaseToken && initialFirebaseToken.isBlank()) {
            throw IllegalStateException("Please sign in with Google to continue.")
        }
        val firstBearer = initialFirebaseToken.ifBlank { anonKey }
        val firstResponse = httpClient.newCall(buildRequest(firstBearer)).execute()
        if (firstResponse.code == 401 && firebaseTokenProvider != null) {
            firstResponse.close()
            val refreshedToken = firebaseTokenProvider.invoke(true)?.trim().orEmpty()
            if (refreshedToken.isNotBlank()) {
                return httpClient.newCall(buildRequest(refreshedToken)).execute()
            }
            if (requireFirebaseToken) {
                throw IllegalStateException("Session expired (HTTP 401). Please sign in again.")
            }
        }
        return firstResponse
    }

    suspend fun selectRows(
        tableName: String,
        queryParams: String = "select=*",
        requireAuth: Boolean = false,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<JSONArray> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Supabase configuration missing."))
        }
        val suffix = queryParams.trim().let { if (it.isEmpty()) "" else "?$it" }
        runCatching {
            executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = requireAuth) { bearer ->
                Request.Builder()
                    .url("$urlBase/rest/v1/$tableName$suffix")
                    .get()
                    .addHeader("apikey", anonKey)
                    .addHeader("Authorization", "Bearer $bearer")
                    .addHeader("Accept", "application/json")
                    .build()
            }.use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Supabase GET $tableName HTTP ${resp.code}: ${raw.take(200)}")
                }
                if (raw.isBlank()) JSONArray() else JSONArray(raw)
            }
        }
    }

    suspend fun insertRow(
        tableName: String,
        rowJson: JSONObject,
        requireAuth: Boolean = true,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Supabase configuration missing."))
        }
        runCatching {
            executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = requireAuth) { bearer ->
                Request.Builder()
                    .url("$urlBase/rest/v1/$tableName")
                    .post(rowJson.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                    .addHeader("apikey", anonKey)
                    .addHeader("Authorization", "Bearer $bearer")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .build()
            }.use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string().orEmpty().take(220)
                    throw IllegalStateException("Supabase INSERT $tableName HTTP ${resp.code}: $err")
                }
            }
        }
    }

    suspend fun patchRows(
        tableName: String,
        filterQuery: String,
        patchJson: JSONObject,
        requireAuth: Boolean = true,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Supabase configuration missing."))
        }
        runCatching {
            executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = requireAuth) { bearer ->
                Request.Builder()
                    .url("$urlBase/rest/v1/$tableName?$filterQuery")
                    .patch(patchJson.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                    .addHeader("apikey", anonKey)
                    .addHeader("Authorization", "Bearer $bearer")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .build()
            }.use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string().orEmpty().take(220)
                    throw IllegalStateException("Supabase PATCH $tableName HTTP ${resp.code}: $err")
                }
            }
        }
    }

    suspend fun deleteRows(
        tableName: String,
        filterQuery: String,
        requireAuth: Boolean = true,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Supabase configuration missing."))
        }
        runCatching {
            executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = requireAuth) { bearer ->
                Request.Builder()
                    .url("$urlBase/rest/v1/$tableName?$filterQuery")
                    .delete()
                    .addHeader("apikey", anonKey)
                    .addHeader("Authorization", "Bearer $bearer")
                    .build()
            }.use { resp ->
                if (!resp.isSuccessful && resp.code != 404) {
                    val err = resp.body?.string().orEmpty().take(220)
                    throw IllegalStateException("Supabase DELETE $tableName HTTP ${resp.code}: $err")
                }
            }
        }
    }

    suspend fun callRpc(
        rpcName: String,
        paramsJson: JSONObject = JSONObject(),
        requireAuth: Boolean = true,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Supabase configuration missing."))
        }
        runCatching {
            executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = requireAuth) { bearer ->
                Request.Builder()
                    .url("$urlBase/rest/v1/rpc/$rpcName")
                    .post(paramsJson.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                    .addHeader("apikey", anonKey)
                    .addHeader("Authorization", "Bearer $bearer")
                    .addHeader("Content-Type", "application/json")
                    .build()
            }.use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Supabase RPC $rpcName HTTP ${resp.code}: ${raw.take(220)}")
                }
                raw
            }
        }
    }

    suspend fun invokeEdgeFunction(
        functionNameOrUrl: String,
        payload: JSONObject,
        requireAuth: Boolean = true,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        val targetUrl = if (functionNameOrUrl.startsWith("https://", ignoreCase = true)) {
            functionNameOrUrl
        } else {
            "$urlBase/functions/v1/$functionNameOrUrl"
        }
        runCatching {
            executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = requireAuth) { bearer ->
                Request.Builder()
                    .url(targetUrl)
                    .post(payload.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                    .apply { if (anonKey.isNotBlank()) addHeader("apikey", anonKey) }
                    .addHeader("Authorization", "Bearer $bearer")
                    .addHeader("Content-Type", "application/json")
                    .build()
            }.use { resp ->
                val raw = resp.body?.string().orEmpty()
                val parsed = runCatching { JSONObject(raw) }.getOrNull()
                if (!resp.isSuccessful || parsed == null) {
                    throw IllegalStateException(parsed?.optString("message")?.takeIf { it.isNotBlank() }
                        ?: "Edge Function HTTP ${resp.code}: ${raw.take(200)}")
                }
                if (parsed.has("ok") && !parsed.optBoolean("ok", true)) {
                    throw IllegalStateException(parsed.optString("message").ifBlank { "Edge Function returned failure." })
                }
                parsed
            }
        }
    }

    suspend fun uploadObject(
        bucketName: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String,
        isPublicBucket: Boolean = true,
        allowUpsert: Boolean = false,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<SupabaseUploadResponse> = withContext(Dispatchers.IO) {
        val validationError = validateBinaryUpload(
            bytes = bytes,
            mimeType = mimeType,
            allowPdf = bucketName in setOf("repair-pdfs", "circuit-diagrams", "verification-documents"),
            maxSizeBytes = when (bucketName) {
                "repair-pdfs", "circuit-diagrams" -> MAX_PDF_BYTES
                "verification-documents" -> MAX_VERIFICATION_DOC_BYTES
                else -> MAX_IMAGE_BYTES
            }
        )
        if (validationError != null) {
            return@withContext Result.failure(IllegalArgumentException(validationError))
        }

        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Supabase Public Anon Key is not configured yet.")
            )
        }
        val cleanPath = objectPath.trimStart('/')
        val encodedSegments = cleanPath.split("/")
            .filter { it.isNotBlank() }
            .joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
        val encodedBucket = URLEncoder.encode(bucketName, "UTF-8").replace("+", "%20")
        val targetUrl = "$urlBase/storage/v1/object/$encodedBucket/$encodedSegments"

        val mediaType = mimeType.toMediaTypeOrNull() ?: "application/octet-stream".toMediaTypeOrNull()
        val body = bytes.toRequestBody(mediaType)

        runCatching {
            executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = true) { bearer ->
                Request.Builder()
                    .url(targetUrl)
                    .post(body)
                    .addHeader("apikey", anonKey)
                    .addHeader("Authorization", "Bearer $bearer")
                    .addHeader("Content-Type", mimeType)
                    .addHeader("x-upsert", if (allowUpsert) "true" else "false")
                    .build()
            }.use { resp ->
                if (!resp.isSuccessful) {
                    val msg = resp.body?.string().orEmpty().take(240)
                    val detail = when (resp.code) {
                        401, 403 -> "Supabase Storage permission denied (HTTP ${resp.code}): verify Firebase Third-Party Auth & RLS policy for '$bucketName'. $msg"
                        409 -> "A file already exists at '$cleanPath' (x-upsert=false)."
                        else -> "Supabase Storage HTTP ${resp.code}: $msg"
                    }
                    throw IllegalStateException(detail.trim())
                }
            }
            val visibility = if (isPublicBucket) "public" else "authenticated"
            val publicUrl = "$urlBase/storage/v1/object/$visibility/$bucketName/$cleanPath"
            SupabaseUploadResponse(
                publicUrl = publicUrl,
                storagePath = "$bucketName/$cleanPath",
                bucketName = bucketName
            )
        }
    }

    suspend fun deleteObject(
        bucketName: String,
        objectPath: String,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) return@withContext Result.success(Unit)
        val cleanPath = objectPath.trimStart('/')
            .removePrefix("$bucketName/")
            .trimStart('/')
        if (cleanPath.isBlank()) return@withContext Result.success(Unit)
        val jsonBody = JSONObject().put("prefixes", JSONArray().put(cleanPath)).toString()
        runCatching {
            executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = true) { bearer ->
                Request.Builder()
                    .url("$urlBase/storage/v1/object/$bucketName")
                    .delete(jsonBody.toRequestBody("application/json".toMediaTypeOrNull()))
                    .addHeader("apikey", anonKey)
                    .addHeader("Authorization", "Bearer $bearer")
                    .build()
            }.use { resp ->
                if (!resp.isSuccessful && resp.code != 404) {
                    val msg = resp.body?.string().orEmpty().take(180)
                    throw IllegalStateException("Supabase delete HTTP ${resp.code}: $msg")
                }
            }
        }
    }

    suspend fun createSignedUrl(
        bucketName: String,
        storagePath: String,
        expiresInSeconds: Int = 120,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        runCatching {
            val payload = JSONObject()
                .put("action", "create_signed_url")
                .put("bucket", bucketName)
                .put("storagePath", storagePath)
                .put("expiresIn", expiresInSeconds.coerceIn(30, 300))
            executeWithAuthRetry(anonKey = anonKey.ifBlank { BuildConfig.SUPABASE_ANON_KEY }, requireFirebaseToken = true) { bearer ->
                Request.Builder()
                    .url("$urlBase/functions/v1/admin-user-management")
                    .post(payload.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                    .addHeader("Authorization", "Bearer $bearer")
                    .apply { if (anonKey.isNotBlank()) addHeader("apikey", anonKey) }
                    .addHeader("Content-Type", "application/json")
                    .build()
            }.use { resp ->
                val raw = resp.body?.string().orEmpty()
                val parsed = runCatching { JSONObject(raw) }.getOrNull()
                if (!resp.isSuccessful || parsed == null || !parsed.optBoolean("ok", false)) {
                    throw IllegalStateException(parsed?.optString("message") ?: "Signed URL HTTP ${resp.code}")
                }
                parsed.optString("signedUrl").takeIf { it.startsWith("https://") }
                    ?: throw IllegalStateException("Signed URL response missing HTTPS URL.")
            }
        }
    }

    suspend fun downloadBytes(
        fileUrl: String,
        overrideAnonKey: String? = null
    ): Result<ByteArray> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl()
        val isOwnSupabase = fileUrl.startsWith(urlBase, ignoreCase = true)
        val anonKey = resolveAnonKey(overrideAnonKey)
        runCatching {
            if (isOwnSupabase && anonKey.isNotBlank() && firebaseTokenProvider != null) {
                executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = false) { bearer ->
                    Request.Builder()
                        .url(fileUrl)
                        .get()
                        .addHeader("apikey", anonKey)
                        .addHeader("Authorization", "Bearer $bearer")
                        .build()
                }.use { resp ->
                    if (!resp.isSuccessful) throw IllegalStateException("Download HTTP ${resp.code}")
                    resp.body?.bytes() ?: throw IllegalStateException("Empty file response")
                }
            } else {
                val req = Request.Builder().url(fileUrl).get().build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IllegalStateException("Download HTTP ${resp.code}")
                    resp.body?.bytes() ?: throw IllegalStateException("Empty file response")
                }
            }
        }
    }

    suspend fun upsertTableRow(
        tableName: String,
        rowJson: JSONObject,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null,
        onConflict: String? = null
    ): Result<Unit> = upsertTableRowRawJson(
        tableName = tableName,
        rawJson = rowJson.toString(),
        overrideUrl = overrideUrl,
        overrideAnonKey = overrideAnonKey,
        onConflict = onConflict
    )

    suspend fun upsertTableRowRawJson(
        tableName: String,
        rawJson: String,
        overrideUrl: String? = null,
        overrideAnonKey: String? = null,
        onConflict: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val urlBase = resolveUrl(overrideUrl)
        val anonKey = resolveAnonKey(overrideAnonKey)
        if (urlBase.isBlank() || anonKey.isBlank()) {
            return@withContext Result.success(Unit)
        }
        val querySuffix = onConflict?.trim()?.takeIf { it.isNotEmpty() }
            ?.let { "?on_conflict=${URLEncoder.encode(it, "UTF-8")}" }
            .orEmpty()
        runCatching {
            executeWithAuthRetry(anonKey = anonKey, requireFirebaseToken = true) { bearer ->
                Request.Builder()
                    .url("$urlBase/rest/v1/$tableName$querySuffix")
                    .post(rawJson.toRequestBody("application/json".toMediaTypeOrNull()))
                    .addHeader("apikey", anonKey)
                    .addHeader("Authorization", "Bearer $bearer")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "resolution=merge-duplicates,return=minimal")
                    .build()
            }.use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string().orEmpty().take(180)
                    throw IllegalStateException("Supabase PostgREST HTTP ${resp.code}: $err")
                }
            }
        }
    }

    companion object {
        const val DEFAULT_SUPABASE_URL = "https://xuakzzjtcgcvudkgxpbd.supabase.co"
        const val DEFAULT_FCM_ENDPOINT = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-push-notification"
        const val MAX_IMAGE_BYTES = 5 * 1024 * 1024
        const val MAX_VERIFICATION_DOC_BYTES = 10 * 1024 * 1024
        const val MAX_PDF_BYTES = 20 * 1024 * 1024

        fun validateBinaryUpload(
            bytes: ByteArray,
            mimeType: String,
            allowPdf: Boolean,
            maxSizeBytes: Int
        ): String? {
            if (bytes.isEmpty()) return "Selected file is empty."
            if (bytes.size > maxSizeBytes) {
                val mb = maxSizeBytes / (1024 * 1024)
                return "File exceeds maximum allowed size (${mb} MB)."
            }
            val cleanMime = mimeType.trim().lowercase()
            return when (cleanMime) {
                "image/jpeg", "image/jpg" -> {
                    val isJpeg = bytes.size >= 3 &&
                        (bytes[0].toInt() and 0xFF) == 0xFF &&
                        (bytes[1].toInt() and 0xFF) == 0xD8 &&
                        (bytes[2].toInt() and 0xFF) == 0xFF
                    if (!isJpeg) "File signature does not match a valid JPEG image." else null
                }
                "image/png" -> {
                    val isPng = bytes.size >= 8 &&
                        (bytes[0].toInt() and 0xFF) == 0x89 &&
                        bytes[1].toInt() == 0x50 &&
                        bytes[2].toInt() == 0x4E &&
                        bytes[3].toInt() == 0x47
                    if (!isPng) "File signature does not match a valid PNG image." else null
                }
                "image/webp" -> {
                    val isWebp = bytes.size >= 12 &&
                        bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte() &&
                        bytes[2] == 'F'.code.toByte() && bytes[3] == 'F'.code.toByte() &&
                        bytes[8] == 'W'.code.toByte() && bytes[9] == 'E'.code.toByte() &&
                        bytes[10] == 'B'.code.toByte() && bytes[11] == 'P'.code.toByte()
                    if (!isWebp) "File signature does not match a valid WebP image." else null
                }
                "application/pdf" -> {
                    if (!allowPdf) return "PDF upload is not permitted in this section."
                    val isPdf = bytes.size >= 5 &&
                        bytes[0] == '%'.code.toByte() && bytes[1] == 'P'.code.toByte() &&
                        bytes[2] == 'D'.code.toByte() && bytes[3] == 'F'.code.toByte() &&
                        bytes[4] == '-'.code.toByte()
                    if (!isPdf) "File signature does not match a valid PDF document." else null
                }
                else -> "Unsupported file format ($cleanMime)."
            }
        }

        fun isPlaceholderOrBlank(value: String?): Boolean {
            val v = value?.trim().orEmpty()
            return v.isBlank() || v.startsWith("YOUR_", ignoreCase = true)
        }

        internal fun jsonEscape(value: String): String {
            val sb = StringBuilder(value.length + 8)
            for (ch in value) {
                when (ch) {
                    '\\' -> sb.append("\\\\")
                    '"' -> sb.append("\\\"")
                    '\n' -> sb.append("\\n")
                    '\r' -> sb.append("\\r")
                    '\t' -> sb.append("\\t")
                    else -> if (ch < ' ') {
                        sb.append("\\u%04x".format(ch.code))
                    } else {
                        sb.append(ch)
                    }
                }
            }
            return sb.toString()
        }

        fun buildLiveTechnicianJson(
            id: String,
            name: String,
            phone: String,
            photoUrl: String,
            bio: String,
            specialty: String,
            location: String
        ): String {
            return buildString {
                append('{')
                append("\"id\":\"").append(jsonEscape(id)).append("\",")
                append("\"name\":\"").append(jsonEscape(name)).append("\",")
                append("\"phone\":\"").append(jsonEscape(phone)).append("\",")
                append("\"photo_url\":\"").append(jsonEscape(photoUrl)).append("\",")
                append("\"bio\":\"").append(jsonEscape(bio)).append("\",")
                append("\"specialty\":\"").append(jsonEscape(specialty)).append("\",")
                append("\"location\":\"").append(jsonEscape(location)).append("\"")
                append('}')
            }
        }

        fun defaultHttpClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(45, TimeUnit.SECONDS)
            .build()
    }
}
