package com.example.data.remote

import androidx.annotation.Keep

val COMMUNITY_CATEGORIES = listOf("AC", "Refrigerator", "Washing Machine", "General")

val COMMUNITY_REPORT_REASONS = listOf(
    "SPAM" to "Spam or advertising",
    "MISINFORMATION" to "Incorrect technical info",
    "UNSAFE_ADVICE" to "Unsafe electrical/gas advice",
    "ABUSE" to "Harassment or abusive language",
    "OFF_TOPIC" to "Off-topic content",
    "OTHER" to "Other issue"
)

@Keep
data class CommunityPostCloud(
    val id: String = "",
    val postId: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val authorPhotoUrl: String = "",
    val authorVerified: Boolean = false,
    val category: String = "AC",
    val brandName: String = "",
    val modelName: String = "",
    val errorCode: String = "",
    val title: String = "",
    val body: String = "",
    val photoUrl: String = "",
    val photoStoragePath: String = "",
    val photoUrls: List<String> = emptyList(),
    val photoStoragePaths: List<String> = emptyList(),
    val photoProviderIds: List<String> = emptyList(),
    val storageProviderId: String = "supabase_primary",
    val externalRecordId: String = "",
    val isPinned: Boolean = false,
    val isHidden: Boolean = false,
    val isDeleted: Boolean = false,
    val deletedByUid: String = "",
    val deletedAt: CloudTimestamp? = null,
    val approvalStatus: String = "PENDING",
    val moderationNote: String = "",
    val reviewedByUid: String = "",
    val likeCount: Long = 0L,
    val commentCount: Long = 0L,
    val reportCount: Long = 0L,
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
) {
    fun resolvedPhotoUrls(): List<String> {
        val list = photoUrls.filter { it.startsWith("https://") }
        if (list.isNotEmpty()) return list
        return if (photoUrl.startsWith("https://")) listOf(photoUrl) else emptyList()
    }

    fun resolvedStoragePaths(): List<String> {
        val list = photoStoragePaths.filter { it.isNotBlank() }
        if (list.isNotEmpty()) return list
        return if (photoStoragePath.isNotBlank()) listOf(photoStoragePath) else emptyList()
    }
}

@Keep
data class CommunityLikeCloud(
    val id: String = "",
    val postId: String = "",
    val userId: String = "",
    val createdAt: CloudTimestamp? = null
)

@Keep
data class CommunityCommentCloud(
    val id: String = "",
    val commentId: String = "",
    val postId: String = "",
    val parentCommentId: String = "",
    val replyToAuthorName: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val authorVerified: Boolean = false,
    val body: String = "",
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
)

@Keep
data class SavedPostCloud(
    val id: String = "",
    val userId: String = "",
    val postId: String = "",
    val title: String = "",
    val category: String = "AC",
    val authorName: String = "",
    val photoUrl: String = "",
    val createdAt: CloudTimestamp? = null
)

@Keep
data class CommunityReportCloud(
    val id: String = "",
    val reportId: String = "",
    val postId: String = "",
    val commentId: String = "",
    val reporterUid: String = "",
    val reporterName: String = "",
    val reason: String = "OTHER",
    val details: String = "",
    val status: String = "OPEN",
    val adminNote: String = "",
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
)

data class CommentThread(
    val parent: CommunityCommentCloud,
    val replies: List<CommunityCommentCloud>
)

object CommunityDomainHelper {

    fun validatePostDraft(
        title: String,
        body: String,
        category: String,
        hasPhotos: Boolean = false
    ): String? {
        val cleanTitle = title.trim()
        val cleanBody = body.trim()
        return when {
            category !in COMMUNITY_CATEGORIES -> "Please select a valid category."
            !hasPhotos && cleanTitle.length < 3 -> "Title must be at least 3 characters."
            cleanTitle.length > 140 -> "Title cannot exceed 140 characters."
            !hasPhotos && cleanBody.length < 5 -> "Description must be at least 5 characters."
            cleanBody.length > 3000 -> "Description cannot exceed 3000 characters."
            else -> null
        }
    }

    fun resolvePostTitle(rawTitle: String, body: String, category: String): String {
        val cleanTitle = rawTitle.trim()
        if (cleanTitle.length >= 3) return cleanTitle.take(140)
        val fromBody = body.trim().lineSequence().firstOrNull()?.take(80).orEmpty()
        if (fromBody.length >= 3) return fromBody
        return "$category Repair Photo"
    }

    fun validateCommentBody(body: String): String? {
        val clean = body.trim()
        return when {
            clean.isEmpty() -> "Comment cannot be empty."
            clean.length > 1000 -> "Comment cannot exceed 1000 characters."
            else -> null
        }
    }

    fun validateReportReason(reason: String): Boolean {
        return COMMUNITY_REPORT_REASONS.any { it.first == reason }
    }

    fun buildCommentThreads(comments: List<CommunityCommentCloud>): List<CommentThread> {
        val sorted = comments.sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
        val byId = sorted.associateBy { it.commentId.ifBlank { it.id } }
        val topLevel = mutableListOf<CommunityCommentCloud>()
        val repliesByParent = mutableMapOf<String, MutableList<CommunityCommentCloud>>()

        for (item in sorted) {
            val parentId = item.parentCommentId.trim()
            if (parentId.isEmpty() || !byId.containsKey(parentId)) {
                topLevel.add(item)
            } else {
                val rootParentId = resolveRootParentId(parentId, byId)
                repliesByParent.getOrPut(rootParentId) { mutableListOf() }.add(item)
            }
        }

        return topLevel.map { parent ->
            val key = parent.commentId.ifBlank { parent.id }
            CommentThread(
                parent = parent,
                replies = repliesByParent[key].orEmpty()
            )
        }
    }

    private fun resolveRootParentId(
        initialParentId: String,
        byId: Map<String, CommunityCommentCloud>
    ): String {
        var current = initialParentId
        val visited = mutableSetOf<String>()
        while (visited.add(current)) {
            val node = byId[current] ?: break
            val next = node.parentCommentId.trim()
            if (next.isEmpty() || !byId.containsKey(next)) return current
            current = next
        }
        return initialParentId
    }

    fun filterPosts(
        posts: List<CommunityPostCloud>,
        category: String,
        query: String
    ): List<CommunityPostCloud> {
        val q = query.trim().lowercase()
        return posts
            .filter { post ->
                val visible = !post.isHidden && !post.isDeleted
                val matchesCat = category == "ALL" || post.category.equals(category, ignoreCase = true)
                val matchesQ = q.isEmpty() ||
                    post.title.lowercase().contains(q) ||
                    post.body.lowercase().contains(q) ||
                    post.brandName.lowercase().contains(q) ||
                    post.modelName.lowercase().contains(q) ||
                    post.errorCode.lowercase().contains(q) ||
                    post.authorName.lowercase().contains(q)
                visible && matchesCat && matchesQ
            }
            .sortedWith(
                compareByDescending<CommunityPostCloud> { it.isPinned }
                    .thenByDescending { it.createdAt?.seconds ?: 0L }
            )
    }

    fun sha256Hex(bytes: ByteArray): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun deduplicatePhotos(
        existingHashes: Set<String>,
        candidates: List<PendingCommunityPhoto>,
        maxAllowed: Int = 4
    ): Pair<List<PendingCommunityPhoto>, Int> {
        val seen = existingHashes.toMutableSet()
        val unique = mutableListOf<PendingCommunityPhoto>()
        var skipped = 0
        for (photo in candidates) {
            if (unique.size >= maxAllowed) break
            val hash = sha256Hex(photo.bytes)
            if (seen.add(hash)) {
                unique.add(photo)
            } else {
                skipped += 1
            }
        }
        return unique to skipped
    }
}
