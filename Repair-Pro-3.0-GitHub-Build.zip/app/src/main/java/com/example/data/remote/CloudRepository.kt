package com.example.data.remote

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID

class CloudRepository(
    private val auth: FirebaseAuth = Firebase.auth,
    private val supabaseClient: SupabaseClient = SupabaseClient(
        firebaseTokenProvider = { forceRefresh ->
            runCatching { auth.currentUser?.getIdToken(forceRefresh)?.await()?.token }.getOrNull()
        }
    ),
    private val storageRouter: MultiCloudStorageRouter = MultiCloudStorageRouter(
        authProvider = { auth },
        supabaseClientOverride = supabaseClient
    ),
    private val httpClient: OkHttpClient = SupabaseClient.defaultHttpClient()
) {
    constructor(context: Context) : this()

    private val profileTick = MutableStateFlow(0L)
    private val savedGuidesTick = MutableStateFlow(0L)
    private val reportsTick = MutableStateFlow(0L)
    private val catalogTick = MutableStateFlow(0L)
    private val settingsTick = MutableStateFlow(0L)
    private val usersTick = MutableStateFlow(0L)
    private val techniciansTick = MutableStateFlow(0L)
    private val auditTick = MutableStateFlow(0L)
    private val adminRolesTick = MutableStateFlow(0L)

    fun refreshAll() {
        val now = System.currentTimeMillis()
        profileTick.value = now
        savedGuidesTick.value = now
        reportsTick.value = now
        catalogTick.value = now
        settingsTick.value = now
        usersTick.value = now
        techniciansTick.value = now
        auditTick.value = now
        adminRolesTick.value = now
    }

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Repair Pro backend.")
    }

    private fun <T> pollFlow(
        trigger: StateFlow<Long>,
        intervalMs: Long = 25_000L,
        op: OperationType,
        path: String,
        expectedUid: String,
        throwOnInitialFailure: Boolean = false,
        loader: suspend () -> T
    ): Flow<T> = flow {
        var hasEmitted = false
        val ticker = flow {
            var count = 0L
            while (true) {
                emit(count++)
                delay(intervalMs)
            }
        }
        combine(trigger, ticker) { t, c -> t to c }.collect {
            try {
                val value = loader()
                hasEmitted = true
                emit(value)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (auth.currentUser?.uid == expectedUid) {
                    handleCloudError(e, op, path)
                }
                if (throwOnInitialFailure && !hasEmitted) {
                    throw e
                }
            }
        }
    }

    fun isCurrentUserBootstrapAdmin(): Boolean {
        val user = auth.currentUser ?: return false
        return user.isEmailVerified &&
            user.email.equals(BOOTSTRAP_SUPER_ADMIN_EMAIL, ignoreCase = true)
    }

    suspend fun checkIsAdmin(userId: String): Boolean {
        if (isCurrentUserBootstrapAdmin()) return true
        return try {
            val tokenClaims = runCatching { auth.currentUser?.getIdToken(false)?.await()?.claims }.getOrNull()
            val claimAdmin = tokenClaims?.get("admin") == true ||
                tokenClaims?.get("repairproRole")?.toString() == "SUPER_ADMIN"
            if (claimAdmin) return true

            val encodedUid = URLEncoder.encode(sanitizeId(userId), "UTF-8")
            val res = supabaseClient.selectRows(
                tableName = "admin_roles",
                queryParams = "user_id=eq.$encodedUid&select=user_id,role&limit=1",
                requireAuth = true
            )
            val rows = res.getOrNull()
            if (rows != null && rows.length() > 0) return true

            val extProviders = runCatching { storageRouter.resolveAllReadableExternalDbProviders("catalog") }
                .getOrDefault(emptyList())
            extProviders.any { prov ->
                val extRows = storageRouter.externalDbQuery(
                    provider = prov,
                    table = "admin_roles",
                    filters = mapOf("user_id" to sanitizeId(userId)),
                    limit = 1
                ).getOrNull()
                extRows != null && extRows.length() > 0
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.GET, "admin_roles/$userId")
            false
        }
    }

    suspend fun ensureUserProfile(
        userId: String,
        displayName: String,
        preferredLanguage: String
    ): Result<Unit> {
        val path = "user_profiles/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val encodedUid = URLEncoder.encode(userId, "UTF-8")
            val existingRes = storageRouter.readMergedRows(
                tableName = "user_profiles",
                categoryKey = "user_profiles",
                supabaseQueryParams = "user_id=eq.$encodedUid&select=user_id,display_name,email,photo_url,updated_at&limit=1",
                supabaseRequireAuth = true,
                extFilters = mapOf("user_id" to userId),
                extLimit = 1,
                pkColumns = listOf("user_id", "id")
            )
            if (existingRes.isFailure) {
                return Result.failure(existingRes.exceptionOrNull() ?: IllegalStateException("Profile fetch failed."))
            }
            val arr = existingRes.getOrThrow()
            val safeEmail = auth.currentUser?.email.orEmpty().trim().take(160)
            val authPhoto = auth.currentUser?.photoUrl?.toString().orEmpty().trim()
                .takeIf { it.startsWith("https://") && it.length <= 1000 }.orEmpty()
            val safeName = displayName.trim().ifBlank { "Repair Pro User" }.take(80)
            val safeLang = if (preferredLanguage in listOf("en", "bn", "hi")) preferredLanguage else "en"

            if (arr.length() == 0) {
                val payload = JSONObject()
                    .put("user_id", userId)
                    .put("display_name", safeName)
                    .put("email", safeEmail)
                    .put("photo_url", authPhoto)
                    .put("preferred_language", safeLang)
                    .put("ad_consent_granted", true)
                    .put("notifications_enabled", true)
                    .put("account_status", "ACTIVE")
                    .put("blocked", false)
                    .put("suspended", false)
                    .put("community_restricted", false)
                    .put("upload_restricted", false)
                storageRouter.writeRowWithFailover(
                    tableName = "user_profiles",
                    categoryKey = "user_profiles",
                    payload = payload,
                    onConflict = "user_id"
                ).getOrThrow()
            } else {
                val row = arr.optJSONObject(0) ?: JSONObject()
                val patch = JSONObject()
                var changed = false
                if (safeEmail.isNotEmpty() && SupabaseMappers.optNonBlank(row, "email").isEmpty()) {
                    patch.put("email", safeEmail)
                    changed = true
                }
                val cleanName = displayName.trim().take(80)
                if (cleanName.isNotEmpty() && SupabaseMappers.optNonBlank(row, "display_name").isEmpty()) {
                    patch.put("display_name", cleanName)
                    changed = true
                }
                if (authPhoto.isNotEmpty() && SupabaseMappers.optNonBlank(row, "photo_url").isEmpty()) {
                    patch.put("photo_url", authPhoto)
                    changed = true
                }
                if (changed) {
                    patch.put("updated_at", CloudTimestamp.toIsoString())
                    storageRouter.patchRowWithFailover(
                        tableName = "user_profiles",
                        categoryKey = "user_profiles",
                        recordId = userId,
                        supabaseFilterQuery = "user_id=eq.$encodedUid",
                        patchJson = patch
                    ).getOrThrow()
                }
            }
            profileTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateUserPreferences(
        userId: String,
        preferredLanguage: String? = null,
        adConsentGranted: Boolean? = null,
        notificationsEnabled: Boolean? = null
    ): Result<Unit> {
        val path = "user_profiles/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val encodedUid = URLEncoder.encode(userId, "UTF-8")
            val updates = JSONObject().put("updated_at", CloudTimestamp.toIsoString())
            if (preferredLanguage != null && preferredLanguage in listOf("en", "bn", "hi")) {
                updates.put("preferred_language", preferredLanguage)
            }
            if (adConsentGranted != null) {
                updates.put("ad_consent_granted", adConsentGranted)
            }
            if (notificationsEnabled != null) {
                updates.put("notifications_enabled", notificationsEnabled)
            }
            storageRouter.patchRowWithFailover(
                tableName = "user_profiles",
                categoryKey = "user_profiles",
                recordId = userId,
                supabaseFilterQuery = "user_id=eq.$encodedUid",
                patchJson = updates
            ).getOrThrow()
            profileTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateUserProfileAndPhoto(
        userId: String,
        displayName: String,
        photoBytes: ByteArray? = null,
        photoMimeType: String = "image/jpeg",
        onProgress: (Float) -> Unit = {}
    ): Result<UserProfileCloud> {
        val path = "user_profiles/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val cleanName = displayName.trim().take(80)
            require(cleanName.length >= 2) { "Display name must be at least 2 characters." }
            val encodedUid = URLEncoder.encode(userId, "UTF-8")

            val existingRow = storageRouter.readMergedRows(
                tableName = "user_profiles",
                categoryKey = "user_profiles",
                supabaseQueryParams = "user_id=eq.$encodedUid&select=*&limit=1",
                supabaseRequireAuth = true,
                extFilters = mapOf("user_id" to userId),
                extLimit = 1,
                pkColumns = listOf("user_id", "id")
            ).getOrNull()?.optJSONObject(0)
            val existingProfile = existingRow?.let { SupabaseMappers.toUserProfile(it) }

            var uploadedResult: MultiCloudUploadResult? = null
            if (photoBytes != null && photoBytes.isNotEmpty()) {
                val safeMime = when (photoMimeType.lowercase()) {
                    "image/png" -> "image/png"
                    "image/webp" -> "image/webp"
                    else -> "image/jpeg"
                }
                val ext = when (safeMime) {
                    "image/png" -> "png"
                    "image/webp" -> "webp"
                    else -> "jpg"
                }
                val objectPath = "$userId/avatar_${System.currentTimeMillis()}.$ext"
                val uploadRes = storageRouter.uploadBytes(
                    bucketKey = "user_profiles",
                    objectPath = objectPath,
                    bytes = photoBytes,
                    mimeType = safeMime,
                    allowUpsert = false,
                    onProgress = onProgress
                )
                if (uploadRes.isFailure) {
                    return Result.failure(uploadRes.exceptionOrNull() ?: IllegalStateException("Profile photo upload failed."))
                }
                uploadedResult = uploadRes.getOrThrow()
            }

            val patch = JSONObject()
                .put("display_name", cleanName)
                .put("updated_at", CloudTimestamp.toIsoString())
            if (uploadedResult != null) {
                patch.put("photo_url", uploadedResult.publicUrl)
                patch.put("photo_storage_path", uploadedResult.storagePath)
                patch.put("photo_provider_id", uploadedResult.providerId)
            }

            val patchRes = storageRouter.patchRowWithFailover(
                tableName = "user_profiles",
                categoryKey = "user_profiles",
                recordId = userId,
                supabaseFilterQuery = "user_id=eq.$encodedUid",
                patchJson = patch
            )
            if (patchRes.isFailure) {
                if (uploadedResult != null) {
                    runCatching {
                        storageRouter.deleteObject(
                            providerId = uploadedResult.providerId,
                            bucketKey = "user_profiles",
                            storagePath = uploadedResult.storagePath,
                            publicUrl = uploadedResult.publicUrl
                        )
                    }
                }
                return Result.failure(patchRes.exceptionOrNull() ?: IllegalStateException("Failed to save profile."))
            }

            // Update Firebase Auth profile for session consistency
            runCatching {
                val builder = UserProfileChangeRequest.Builder().setDisplayName(cleanName)
                if (uploadedResult != null && uploadedResult.publicUrl.startsWith("https://")) {
                    builder.setPhotoUri(Uri.parse(uploadedResult.publicUrl))
                }
                auth.currentUser?.updateProfile(builder.build())?.await()
            }

            // Best-effort cleanup of previous avatar
            if (uploadedResult != null && existingProfile != null &&
                (existingProfile.photoStoragePath.isNotBlank() || existingProfile.photoUrl.isNotBlank()) &&
                existingProfile.photoUrl != uploadedResult.publicUrl
            ) {
                runCatching {
                    storageRouter.deleteObject(
                        providerId = existingProfile.photoProviderId,
                        bucketKey = "user_profiles",
                        storagePath = existingProfile.photoStoragePath,
                        publicUrl = existingProfile.photoUrl
                    )
                }
            }

            profileTick.value += 1
            val updated = (existingProfile ?: UserProfileCloud(id = userId, userId = userId)).copy(
                displayName = cleanName,
                photoUrl = uploadedResult?.publicUrl ?: existingProfile?.photoUrl.orEmpty(),
                photoStoragePath = uploadedResult?.storagePath ?: existingProfile?.photoStoragePath.orEmpty(),
                photoProviderId = uploadedResult?.providerId ?: existingProfile?.photoProviderId.orEmpty(),
                updatedAt = CloudTimestamp.now()
            )
            Result.success(updated)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfileCloud?> {
        val encodedUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = profileTick,
            intervalMs = 25_000L,
            op = OperationType.GET,
            path = "user_profiles/$userId",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "user_profiles",
                categoryKey = "user_profiles",
                supabaseQueryParams = "user_id=eq.$encodedUid&select=*&limit=1",
                supabaseRequireAuth = true,
                extFilters = mapOf("user_id" to userId),
                extLimit = 1,
                pkColumns = listOf("user_id", "id")
            ).getOrThrow()
            arr.optJSONObject(0)?.let { SupabaseMappers.toUserProfile(it) }
        }
    }

    fun observeSavedGuides(userId: String): Flow<List<SavedGuideCloud>> {
        val encodedUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = savedGuidesTick,
            intervalMs = 30_000L,
            op = OperationType.LIST,
            path = "saved_guides/$userId",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "saved_guides",
                categoryKey = "catalog",
                supabaseQueryParams = "user_id=eq.$encodedUid&select=*&order=saved_at.desc",
                supabaseRequireAuth = true,
                extFilters = mapOf("user_id" to userId),
                extLimit = 200,
                pkColumns = listOf("guide_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toSavedGuide(it) }
                .sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    suspend fun saveGuide(
        userId: String,
        itemType: String,
        itemId: String,
        categoryId: String,
        title: String,
        subtitle: String
    ): Result<Unit> {
        val safeDocId = sanitizeId("${itemType.lowercase()}_$itemId")
        val path = "saved_guides/$safeDocId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val nowIso = CloudTimestamp.toIsoString()
            val payload = JSONObject()
                .put("user_id", userId)
                .put("guide_id", safeDocId)
                .put("entry_type", if (itemType == "ERROR_CODE") "ERROR_CODE" else "PROBLEM")
                .put("code", if (itemType == "ERROR_CODE") itemId.take(32) else "")
                .put("entry_id", itemId.take(128))
                .put("category_id", categoryId.take(64))
                .put("title", title.trim().ifBlank { "Saved Guide" }.take(180))
                .put("summary", subtitle.trim().take(240))
                .put("saved_at", nowIso)
            storageRouter.writeRowWithFailover(
                tableName = "saved_guides",
                categoryKey = "catalog",
                payload = payload,
                onConflict = "user_id,guide_id"
            ).getOrThrow()
            savedGuidesTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun removeSavedGuide(userId: String, guideDocId: String): Result<Unit> {
        val path = "saved_guides/$guideDocId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val encUid = URLEncoder.encode(userId, "UTF-8")
            val encGuide = URLEncoder.encode(guideDocId, "UTF-8")
            storageRouter.deleteRowWithFailover(
                tableName = "saved_guides",
                categoryKey = "catalog",
                recordId = guideDocId,
                supabaseFilterQuery = "user_id=eq.$encUid&guide_id=eq.$encGuide"
            ).getOrThrow()
            savedGuidesTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    fun observeUserProblemReports(userId: String): Flow<List<ProblemReportCloud>> {
        val encodedUid = URLEncoder.encode(userId, "UTF-8")
        return pollFlow(
            trigger = reportsTick,
            intervalMs = 30_000L,
            op = OperationType.LIST,
            path = "problem_reports",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "problem_reports",
                categoryKey = "catalog",
                supabaseQueryParams = "user_id=eq.$encodedUid&select=*&order=created_at.desc",
                supabaseRequireAuth = true,
                extFilters = mapOf("user_id" to userId),
                extLimit = 120,
                pkColumns = listOf("report_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toProblemReport(it) }
                .sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    fun observeAllProblemReportsForAdmin(adminUid: String): Flow<List<ProblemReportCloud>> {
        return pollFlow(
            trigger = reportsTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "problem_reports",
            expectedUid = adminUid
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "problem_reports",
                categoryKey = "catalog",
                supabaseQueryParams = "select=*&order=created_at.desc",
                supabaseRequireAuth = true,
                extLimit = 200,
                pkColumns = listOf("report_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toProblemReport(it) }
                .sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    suspend fun submitProblemReport(
        userId: String,
        categoryId: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        description: String,
        preferredLanguage: String
    ): Result<Unit> {
        val docId = sanitizeId("rep_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "problem_reports/$docId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            require(brandName.trim().isNotEmpty()) { "Brand name is required." }
            require(description.trim().length >= 5) { "Please enter at least 5 characters describing the issue." }
            val safeLang = if (preferredLanguage in listOf("en", "bn", "hi")) preferredLanguage else "en"
            val payload = JSONObject()
                .put("report_id", docId)
                .put("user_id", userId)
                .put("category_id", categoryId.take(64))
                .put("brand_name", brandName.trim().take(80))
                .put("model_name", modelName.trim().take(100))
                .put("error_code", errorCode.trim().uppercase().take(32))
                .put("description", description.trim().take(1500))
                .put("preferred_language", safeLang)
                .put("status", "PENDING")
            storageRouter.writeRowWithFailover(
                tableName = "problem_reports",
                categoryKey = "catalog",
                payload = payload,
                onConflict = "report_id"
            ).getOrThrow()
            reportsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProblemReportStatus(
        reportId: String,
        newStatus: String,
        adminNote: String
    ): Result<Unit> {
        val safeId = sanitizeId(reportId)
        val path = "problem_reports/$safeId"
        return try {
            val uid = requireUserId()
            require(newStatus in listOf("PENDING", "REVIEWED", "PUBLISHED")) { "Invalid status." }
            val patch = JSONObject()
                .put("status", newStatus)
                .put("admin_note", adminNote.trim().take(1000))
                .put("updated_at", CloudTimestamp.toIsoString())
            val encId = URLEncoder.encode(safeId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "problem_reports",
                categoryKey = "catalog",
                recordId = safeId,
                supabaseFilterQuery = "report_id=eq.$encId",
                patchJson = patch
            ).getOrThrow()
            logAdminAction(uid, "UPDATE_REPORT_STATUS", "problem_reports", safeId, "Status -> $newStatus")
            reportsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observePublishedCatalog(userId: String): Flow<List<CatalogEntryCloud>> {
        return pollFlow(
            trigger = catalogTick,
            intervalMs = 45_000L,
            op = OperationType.LIST,
            path = "repair_catalog_entries",
            expectedUid = userId
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "repair_catalog_entries",
                categoryKey = "catalog",
                supabaseQueryParams = "published=eq.true&select=*&order=updated_at.desc",
                supabaseRequireAuth = false,
                extLimit = 300,
                extOrderBy = "updated_at",
                pkColumns = listOf("id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toCatalogEntry(it) }
                .filter { it.published }
                .sortedByDescending { it.updatedAt?.seconds ?: 0L }
        }
    }

    fun observeAllCatalogForAdmin(adminUid: String): Flow<List<CatalogEntryCloud>> {
        return pollFlow(
            trigger = catalogTick,
            intervalMs = 30_000L,
            op = OperationType.LIST,
            path = "repair_catalog_entries",
            expectedUid = adminUid
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "repair_catalog_entries",
                categoryKey = "catalog",
                supabaseQueryParams = "select=*&order=updated_at.desc",
                supabaseRequireAuth = true,
                extLimit = 300,
                extOrderBy = "updated_at",
                pkColumns = listOf("id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toCatalogEntry(it) }
                .sortedByDescending { it.updatedAt?.seconds ?: 0L }
        }
    }

    suspend fun publishCatalogEntry(entry: CatalogEntryCloud): Result<Unit> {
        val docId = if (entry.id.isNotBlank()) sanitizeId(entry.id)
        else sanitizeId("cat_${UUID.randomUUID().toString().replace("-", "").take(14)}")
        val path = "repair_catalog_entries/$docId"
        return try {
            val uid = requireUserId()
            val cleanType = if (entry.entryType in listOf("CATEGORY", "ERROR_CODE", "PROBLEM")) entry.entryType else "ERROR_CODE"
            val cleanVer = if (entry.verificationStatus in listOf("VERIFIED", "UNVERIFIED")) entry.verificationStatus else "VERIFIED"
            val cleanPhotoUrl = entry.photoUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 } ?: ""
            val cleanPdfUrl = entry.pdfUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 } ?: ""
            val cleanDiagramUrl = entry.diagramUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 } ?: ""

            val encId = URLEncoder.encode(docId, "UTF-8")
            val existingArr = storageRouter.readMergedRows(
                tableName = "repair_catalog_entries",
                categoryKey = "catalog",
                supabaseQueryParams = "id=eq.$encId&select=id,revision&limit=1",
                supabaseRequireAuth = true,
                extFilters = mapOf("id" to docId),
                extLimit = 1,
                pkColumns = listOf("id")
            ).getOrNull()
            val exists = existingArr != null && existingArr.length() > 0
            val nextRev = if (exists) (existingArr?.optJSONObject(0)?.optLong("revision", 1L) ?: 1L) + 1L else 1L

            val payload = JSONObject()
                .put("id", docId)
                .put("entry_type", cleanType)
                .put("category_id", entry.categoryId.take(64))
                .put("brand_name", entry.brandName.trim().take(80))
                .put("model_series", entry.modelSeries.trim().take(100))
                .put("code", entry.code.trim().uppercase().take(32))
                .put("title_en", entry.titleEn.trim().ifBlank { "Untitled Entry" }.take(180))
                .put("title_bn", entry.titleBn.trim().take(220))
                .put("title_hi", entry.titleHi.trim().take(220))
                .put("summary_en", entry.summaryEn.trim().ifBlank { "Details pending" }.take(1200))
                .put("summary_bn", entry.summaryBn.trim().take(1400))
                .put("summary_hi", entry.summaryHi.trim().take(1400))
                .put("steps_en", entry.stepsEn.trim().take(2000))
                .put("steps_bn", entry.stepsBn.trim().take(2400))
                .put("steps_hi", entry.stepsHi.trim().take(2400))
                .put("safety_warning_en", entry.safetyWarningEn.trim().ifBlank { "Disconnect mains power before inspection." }.take(600))
                .put("photo_url", cleanPhotoUrl)
                .put("photo_storage_path", entry.photoStoragePath.trim().take(320))
                .put("pdf_url", cleanPdfUrl)
                .put("pdf_storage_path", entry.pdfStoragePath.trim().take(320))
                .put("pdf_title", entry.pdfTitle.trim().take(160))
                .put("diagram_url", cleanDiagramUrl)
                .put("diagram_storage_path", entry.diagramStoragePath.trim().take(320))
                .put("diagram_title", entry.diagramTitle.trim().take(160))
                .put("verification_status", cleanVer)
                .put("published", entry.published)
                .put("revision", nextRev)
                .put("updated_by_uid", uid)
                .put("updated_at", CloudTimestamp.toIsoString())

            storageRouter.writeRowWithFailover(
                tableName = "repair_catalog_entries",
                categoryKey = "catalog",
                payload = payload,
                onConflict = "id",
                mirrorIfActiveExternal = true
            ).getOrThrow()
            logAdminAction(
                uid,
                if (exists) "UPDATE_CATALOG_ENTRY" else "CREATE_CATALOG_ENTRY",
                "repair_catalog_entries",
                docId,
                "Rev $nextRev: ${entry.titleEn}"
            )
            catalogTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteCatalogEntry(entryId: String): Result<Unit> {
        val safeId = sanitizeId(entryId)
        val path = "repair_catalog_entries/$safeId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(safeId, "UTF-8")
            val existing = storageRouter.readMergedRows(
                tableName = "repair_catalog_entries",
                categoryKey = "catalog",
                supabaseQueryParams = "id=eq.$encId&select=*&limit=1",
                supabaseRequireAuth = true,
                extFilters = mapOf("id" to safeId),
                extLimit = 1,
                pkColumns = listOf("id")
            ).getOrNull()?.optJSONObject(0)?.let { SupabaseMappers.toCatalogEntry(it) }

            storageRouter.deleteRowWithFailover(
                tableName = "repair_catalog_entries",
                categoryKey = "catalog",
                recordId = safeId,
                supabaseFilterQuery = "id=eq.$encId"
            ).getOrThrow()

            if (existing != null) {
                if (existing.photoStoragePath.isNotBlank() || existing.photoUrl.isNotBlank()) {
                    runCatching { storageRouter.deleteObject(bucketKey = "diagrams", storagePath = existing.photoStoragePath, publicUrl = existing.photoUrl) }
                }
                if (existing.diagramStoragePath.isNotBlank() || existing.diagramUrl.isNotBlank()) {
                    runCatching { storageRouter.deleteObject(bucketKey = "diagrams", storagePath = existing.diagramStoragePath, publicUrl = existing.diagramUrl) }
                }
                if (existing.pdfStoragePath.isNotBlank() || existing.pdfUrl.isNotBlank()) {
                    runCatching { storageRouter.deleteObject(bucketKey = "pdfs", storagePath = existing.pdfStoragePath, publicUrl = existing.pdfUrl) }
                }
            }
            logAdminAction(uid, "DELETE_CATALOG_ENTRY", "repair_catalog_entries", safeId, "Deleted catalog entry")
            catalogTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    fun observeAdMobConfig(userId: String): Flow<AppSettingCloud> {
        return pollFlow(
            trigger = settingsTick,
            intervalMs = 45_000L,
            op = OperationType.GET,
            path = "app_settings/admob_config",
            expectedUid = userId
        ) {
            val arr = supabaseClient.selectRows(
                tableName = "app_settings",
                queryParams = "setting_id=eq.admob_config&select=*&limit=1",
                requireAuth = false
            ).getOrThrow()
            SupabaseMappers.toAppSetting("admob_config", arr.optJSONObject(0))
        }
    }

    fun observeGlobalConfig(userId: String): Flow<AppSettingCloud> {
        return pollFlow(
            trigger = settingsTick,
            intervalMs = 45_000L,
            op = OperationType.GET,
            path = "app_settings/global_config",
            expectedUid = userId
        ) {
            val arr = supabaseClient.selectRows(
                tableName = "app_settings",
                queryParams = "setting_id=eq.global_config&select=*&limit=1",
                requireAuth = false
            ).getOrThrow()
            SupabaseMappers.toAppSetting("global_config", arr.optJSONObject(0))
        }
    }

    suspend fun saveAdMobConfig(config: AppSettingCloud): Result<Unit> {
        val path = "app_settings/admob_config"
        return try {
            val uid = requireUserId()
            val payload = JSONObject()
                .put("configType", "ADMOB")
                .put("adsGlobalEnabled", config.adsGlobalEnabled)
                .put("bannerEnabled", config.bannerEnabled)
                .put("interstitialEnabled", config.interstitialEnabled)
                .put("rewardedEnabled", config.rewardedEnabled)
                .put("nativeEnabled", config.nativeEnabled)
                .put("emergencyKillSwitch", config.emergencyKillSwitch)
                .put("testMode", config.testMode)
                .put("acAdsEnabled", config.acAdsEnabled)
                .put("fridgeAdsEnabled", config.fridgeAdsEnabled)
                .put("washerAdsEnabled", config.washerAdsEnabled)
                .put("interstitialCooldownMin", config.interstitialCooldownMin.coerceIn(1L, 60L))
                .put("sessionFrequencyCap", config.sessionFrequencyCap.coerceIn(1L, 50L))
                .put("androidAppId", config.androidAppId.take(120))
                .put("androidBannerId", config.androidBannerId.take(120))
                .put("androidInterstitialId", config.androidInterstitialId.take(120))
                .put("androidRewardedId", config.androidRewardedId.take(120))
                .put("iosAppId", config.iosAppId.take(120))
                .put("iosBannerId", config.iosBannerId.take(120))

            val row = JSONObject()
                .put("setting_id", "admob_config")
                .put("config_type", "ADMOB")
                .put("payload", payload)
                .put("updated_by_uid", uid)
                .put("updated_at", CloudTimestamp.toIsoString())
            supabaseClient.upsertTableRow("app_settings", row, onConflict = "setting_id").getOrThrow()
            logAdminAction(
                uid,
                "UPDATE_ADMOB_CONFIG",
                "app_settings",
                "admob_config",
                "Global=${config.adsGlobalEnabled}, Kill=${config.emergencyKillSwitch}, Test=${config.testMode}"
            )
            settingsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveGlobalConfig(
        announcement: String,
        maintenanceNotice: String,
        minSupportedVersion: String
    ): Result<Unit> {
        val existing = supabaseClient.selectRows(
            tableName = "app_settings",
            queryParams = "setting_id=eq.global_config&select=*&limit=1",
            requireAuth = false
        ).getOrNull()?.optJSONObject(0)
        val current = SupabaseMappers.toAppSetting("global_config", existing)
        return saveGlobalConfig(
            current.copy(
                announcement = announcement,
                maintenanceNotice = maintenanceNotice,
                minSupportedVersion = minSupportedVersion
            )
        )
    }

    suspend fun saveGlobalConfig(config: AppSettingCloud): Result<Unit> {
        val path = "app_settings/global_config"
        return try {
            val uid = requireUserId()
            val payload = JSONObject()
                .put("configType", "GLOBAL")
                .put("announcement", config.announcement.trim().take(400))
                .put("maintenanceNotice", config.maintenanceNotice.trim().take(400))
                .put("maintenanceMode", config.maintenanceMode)
                .put("schemaVersion", config.schemaVersion.coerceAtLeast(1L))
                .put("minSupportedVersion", config.minSupportedVersion.trim().ifBlank { "1.0.0" }.take(32))
                .put("minSupportedVersionCode", config.minSupportedVersionCode.coerceAtLeast(1L))
                .put("latestVersionCode", config.latestVersionCode.coerceAtLeast(1L))
                .put("latestVersionName", config.latestVersionName.trim().ifBlank { "1.2.0" }.take(32))
                .put("forceUpdate", config.forceUpdate)
                .put("updateMessage", config.updateMessage.trim().take(400))
                .put("updateUrl", config.updateUrl.trim().take(600))
                .put("communityEnabled", config.communityEnabled)
                .put("techniciansEnabled", config.techniciansEnabled)
                .put("billingEnabled", config.billingEnabled)
                .put("verificationEnabled", config.verificationEnabled)
                .put("scannerEnabled", config.scannerEnabled)
                .put("reportsEnabled", config.reportsEnabled)
                .put("pdfsEnabled", config.pdfsEnabled)

            val row = JSONObject()
                .put("setting_id", "global_config")
                .put("config_type", "GLOBAL")
                .put("payload", payload)
                .put("updated_by_uid", uid)
                .put("updated_at", CloudTimestamp.toIsoString())
            supabaseClient.upsertTableRow("app_settings", row, onConflict = "setting_id").getOrThrow()
            logAdminAction(
                uid,
                "UPDATE_GLOBAL_SETTINGS",
                "app_settings",
                "global_config",
                "Maint=${config.maintenanceMode}, ForceUpd=${config.forceUpdate}, Latest=${config.latestVersionCode}"
            )
            settingsTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    fun observeAllUsersForAdmin(adminUid: String): Flow<List<UserProfileCloud>> {
        return pollFlow(
            trigger = usersTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "user_profiles",
            expectedUid = adminUid
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "user_profiles",
                categoryKey = "user_profiles",
                supabaseQueryParams = "select=*&order=updated_at.desc",
                supabaseRequireAuth = true,
                extLimit = 300,
                extOrderBy = "updated_at",
                pkColumns = listOf("user_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toUserProfile(it) }
                .sortedByDescending { it.updatedAt?.seconds ?: 0L }
        }
    }

    suspend fun syncMyFirebaseClaims(): Boolean = storageRouter.syncMyFirebaseClaims()

    suspend fun moderateUserViaEdgeFunction(
        targetUid: String,
        action: String,
        reason: String = ""
    ): Result<String> = withContext(Dispatchers.IO) {
        val safeTarget = sanitizeId(targetUid)
        if (safeTarget.isBlank()) return@withContext Result.failure(IllegalArgumentException("Target UID is required."))
        val user = auth.currentUser
            ?: return@withContext Result.failure(IllegalStateException("Admin sign-in required."))
        val anonKey = supabaseClient.resolveAnonKey().ifBlank { BuildConfig.SUPABASE_ANON_KEY }
        val endpoint = "${supabaseClient.resolveUrl()}/functions/v1/admin-user-management"
        val bodyJson = JSONObject()
            .put("action", action)
            .put("targetUid", safeTarget)
            .put("reason", reason.trim().take(400))
            .toString()

        fun buildReq(token: String) = Request.Builder()
            .url(endpoint)
            .post(bodyJson.toRequestBody("application/json".toMediaTypeOrNull()))
            .addHeader("Authorization", "Bearer $token")
            .apply { if (anonKey.isNotBlank()) addHeader("apikey", anonKey) }
            .addHeader("Content-Type", "application/json")
            .build()

        runCatching {
            var idToken = user.getIdToken(false).await().token.orEmpty()
            if (idToken.isBlank()) throw IllegalStateException("Firebase ID token missing.")
            var resp = httpClient.newCall(buildReq(idToken)).execute()
            if (resp.code == 401) {
                resp.close()
                idToken = user.getIdToken(true).await().token.orEmpty()
                resp = httpClient.newCall(buildReq(idToken)).execute()
            }
            resp.use { r ->
                val raw = r.body?.string().orEmpty()
                val parsed = runCatching { JSONObject(raw) }.getOrNull()
                if (!r.isSuccessful || parsed == null || !parsed.optBoolean("ok", false)) {
                    throw IllegalStateException(parsed?.optString("message")?.takeIf { it.isNotBlank() } ?: "User moderation HTTP ${r.code}")
                }
                usersTick.value += 1
                parsed.optString("message", "User action completed ($action).")
            }
        }
    }

    suspend fun deleteUserAccountViaEdgeFunction(targetUid: String, reason: String = ""): Result<String> =
        moderateUserViaEdgeFunction(targetUid, "delete_user", reason)

    fun observeAuditLogsForAdmin(adminUid: String): Flow<List<AuditLogCloud>> {
        return pollFlow(
            trigger = auditTick,
            intervalMs = 30_000L,
            op = OperationType.LIST,
            path = "audit_logs",
            expectedUid = adminUid
        ) {
            val arr = supabaseClient.selectRows(
                tableName = "audit_logs",
                queryParams = "select=*&order=created_at.desc&limit=120",
                requireAuth = true
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr).map { SupabaseMappers.toAuditLog(it) }
        }
    }

    fun observeAdminRolesForBootstrapAdmin(adminUid: String): Flow<List<AdminRoleCloud>> {
        return pollFlow(
            trigger = adminRolesTick,
            intervalMs = 30_000L,
            op = OperationType.LIST,
            path = "admin_roles",
            expectedUid = adminUid
        ) {
            val arr = supabaseClient.selectRows(
                tableName = "admin_roles",
                queryParams = "select=*&order=created_at.desc",
                requireAuth = true
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr).map { SupabaseMappers.toAdminRole(it) }
        }
    }

    suspend fun upsertAdminRole(targetUid: String, role: String): Result<Unit> {
        val cleanUid = sanitizeId(targetUid.trim())
        val cleanRole = if (role in listOf("SUPER_ADMIN", "CONTENT_EDITOR", "TRANSLATOR", "ANALYST")) role else "CONTENT_EDITOR"
        val path = "admin_roles/$cleanUid"
        return try {
            val actorUid = requireUserId()
            val payload = JSONObject()
                .put("user_id", cleanUid)
                .put("role", cleanRole)
                .put("updated_at", CloudTimestamp.toIsoString())
            supabaseClient.upsertTableRow("admin_roles", payload, onConflict = "user_id").getOrThrow()
            logAdminAction(actorUid, "UPSERT_ADMIN_ROLE", "admin_roles", cleanUid, "Role -> $cleanRole")
            adminRolesTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun removeAdminRole(targetUid: String): Result<Unit> {
        val cleanUid = sanitizeId(targetUid.trim())
        val path = "admin_roles/$cleanUid"
        return try {
            val actorUid = requireUserId()
            val encUid = URLEncoder.encode(cleanUid, "UTF-8")
            supabaseClient.deleteRows("admin_roles", "user_id=eq.$encUid", requireAuth = true).getOrThrow()
            logAdminAction(actorUid, "REVOKE_ADMIN_ROLE", "admin_roles", cleanUid, "Revoked admin role")
            adminRolesTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private suspend fun logAdminAction(
        adminUid: String,
        action: String,
        targetType: String,
        targetId: String,
        details: String
    ) {
        val logId = sanitizeId("log_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val email = auth.currentUser?.email ?: "admin@repairpro.local"
        val payload = JSONObject()
            .put("log_id", logId)
            .put("admin_uid", adminUid)
            .put("admin_email", email.take(160))
            .put("action", action.take(100))
            .put("target_type", targetType.take(64))
            .put("target_id", targetId.take(128))
            .put("details", details.take(500))
            .put("result", "SUCCESS")
        try {
            supabaseClient.insertRow("audit_logs", payload, requireAuth = true)
            auditTick.value += 1
        } catch (_: Exception) {
            // Best-effort
        }
    }

    suspend fun deleteUserCloudData(userId: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val edgeRes = supabaseClient.invokeEdgeFunction(
                functionNameOrUrl = "admin-user-management",
                payload = JSONObject().put("action", "delete_my_account"),
                requireAuth = true
            )
            if (edgeRes.isFailure) {
                val encUid = URLEncoder.encode(userId, "UTF-8")
                supabaseClient.deleteRows("saved_guides", "user_id=eq.$encUid", requireAuth = true)
                supabaseClient.deleteRows("problem_reports", "user_id=eq.$encUid", requireAuth = true)
                supabaseClient.deleteRows("user_profiles", "user_id=eq.$encUid", requireAuth = true).getOrThrow()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.DELETE, "user_profiles/$userId")
            Result.failure(e)
        }
    }

    // --- TECHNICIAN DIRECTORY (ACTIVE-ONLY FOR USERS, FULL CRUD FOR ADMINS) ---

    fun observeActiveTechnicians(userId: String): Flow<List<TechnicianCloud>> {
        return pollFlow(
            trigger = techniciansTick,
            intervalMs = 30_000L,
            op = OperationType.LIST,
            path = "technicians",
            expectedUid = userId,
            throwOnInitialFailure = true
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "technicians",
                categoryKey = "technicians",
                supabaseQueryParams = "status=eq.ACTIVE&blocked=eq.false&is_suspended=eq.false&is_deleted=eq.false&select=*&order=full_name.asc",
                supabaseRequireAuth = false,
                extLimit = 200,
                extOrderBy = "full_name",
                extOrderDir = "ASC",
                pkColumns = listOf("technician_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toTechnician(it) }
                .filter { it.isPubliclyVisible }
                .sortedBy { it.fullName.lowercase() }
        }
    }

    fun observeAllTechniciansForAdmin(adminUid: String): Flow<List<TechnicianCloud>> {
        return pollFlow(
            trigger = techniciansTick,
            intervalMs = 25_000L,
            op = OperationType.LIST,
            path = "technicians",
            expectedUid = adminUid
        ) {
            val arr = storageRouter.readMergedRows(
                tableName = "technicians",
                categoryKey = "technicians",
                supabaseQueryParams = "select=*&order=updated_at.desc",
                supabaseRequireAuth = true,
                extLimit = 300,
                extOrderBy = "updated_at",
                pkColumns = listOf("technician_id", "id")
            ).getOrThrow()
            SupabaseMappers.jsonArrayToObjects(arr)
                .map { SupabaseMappers.toTechnician(it) }
                .sortedByDescending { it.updatedAt?.seconds ?: 0L }
        }
    }

    suspend fun uploadTechnicianPhoto(
        technicianId: String,
        imageBytes: ByteArray,
        contentType: String = "image/jpeg"
    ): Result<Pair<String, String>> =
        uploadTechnicianPhotoWithResult(technicianId, imageBytes, contentType).map { it.publicUrl to it.storagePath }

    suspend fun uploadTechnicianPhotoWithResult(
        technicianId: String,
        imageBytes: ByteArray,
        contentType: String = "image/jpeg"
    ): Result<MultiCloudUploadResult> {
        val safeTechId = sanitizeId(technicianId)
        val safeContentType = when (contentType.lowercase()) {
            "image/png" -> "image/png"
            "image/webp" -> "image/webp"
            else -> "image/jpeg"
        }
        val ext = when (safeContentType) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        val objectPath = "$safeTechId/profile_${System.currentTimeMillis()}.$ext"
        return try {
            requireUserId()
            require(imageBytes.isNotEmpty() && imageBytes.size < 5 * 1024 * 1024) {
                "Photo must be smaller than 5 MB."
            }
            storageRouter.uploadBytes(
                bucketKey = "technicians",
                objectPath = objectPath,
                bytes = imageBytes,
                mimeType = safeContentType
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveTechnician(technician: TechnicianCloud): Result<Unit> {
        val docId = if (technician.id.isNotBlank()) sanitizeId(technician.id)
        else sanitizeId("tech_${UUID.randomUUID().toString().replace("-", "").take(14)}")
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            val cleanName = technician.fullName.trim().take(100)
            val cleanPhone = technician.mobileNumber.trim().take(20)
            val cleanAddress = technician.fullAddress.trim().take(300)
            val cleanState = technician.state.trim().take(80)
            val cleanDistrict = technician.district.trim().take(80)
            val cleanArea = technician.cityArea.trim().take(80)
            val cleanPin = technician.pinCode.trim().take(12)
            val cleanExp = technician.experience.trim().take(80)
            val cleanStatus = if (technician.status == "INACTIVE") "INACTIVE" else "ACTIVE"
            val allowedCats = setOf("AC", "Refrigerator", "Washing Machine")
            val cleanCategories = technician.serviceCategories.filter { it in allowedCats }.distinct()
            val cleanPhotoUrl = technician.photoUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 } ?: ""
            val cleanStoragePath = technician.photoStoragePath.trim().take(300)
            val cleanBio = technician.bio.trim().take(600)
            val cleanVerification = if (technician.verificationStatus in listOf("PENDING", "VERIFIED", "REJECTED", "SUSPENDED")) {
                technician.verificationStatus
            } else "VERIFIED"

            require(cleanName.length >= 2) { "Full name must be at least 2 characters." }
            require(Regex("^[+0-9\\s\\-()]{6,20}$").matches(cleanPhone)) { "Enter a valid mobile number." }
            require(cleanAddress.length >= 3 && cleanState.isNotEmpty() && cleanDistrict.isNotEmpty() && cleanArea.isNotEmpty()) {
                "Full address, state, district, and city/area are required."
            }
            require(Regex("^[a-zA-Z0-9\\s\\-]{4,12}$").matches(cleanPin)) { "Enter a valid PIN code." }
            require(cleanCategories.isNotEmpty()) { "Select at least one service category." }

            val payload = JSONObject()
                .put("technician_id", docId)
                .put("full_name", cleanName)
                .put("photo_url", cleanPhotoUrl)
                .put("photo_storage_path", cleanStoragePath)
                .put("photo_provider_id", technician.photoProviderId.ifBlank { technician.storageProviderId })
                .put("storage_provider_id", technician.storageProviderId.ifBlank { "supabase_primary" })
                .put("mobile_number", cleanPhone)
                .put("full_address", cleanAddress)
                .put("state", cleanState)
                .put("district", cleanDistrict)
                .put("city_area", cleanArea)
                .put("pin_code", cleanPin)
                .put("service_categories", JSONArray(cleanCategories))
                .put("experience", cleanExp)
                .put("bio", cleanBio)
                .put("verification_status", cleanVerification)
                .put("blocked", technician.blocked)
                .put("is_suspended", technician.isSuspended)
                .put("is_deleted", technician.isDeleted)
                .put("linked_user_uid", technician.linkedUserUid.trim().take(128))
                .put("status", cleanStatus)
                .put("updated_by_uid", uid)
                .put("updated_at", CloudTimestamp.toIsoString())

            storageRouter.writeRowWithFailover(
                tableName = "technicians",
                categoryKey = "technicians",
                payload = payload,
                onConflict = "technician_id",
                mirrorIfActiveExternal = true
            ).getOrThrow()

            logAdminAction(uid, "SAVE_TECHNICIAN", "technicians", docId, "$cleanName ($cleanDistrict, $cleanStatus)")
            techniciansTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun setTechnicianStatus(technicianId: String, active: Boolean, fullName: String): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        val nextStatus = if (active) "ACTIVE" else "INACTIVE"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(docId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "technicians",
                categoryKey = "technicians",
                recordId = docId,
                supabaseFilterQuery = "technician_id=eq.$encId",
                patchJson = JSONObject()
                    .put("status", nextStatus)
                    .put("updated_by_uid", uid)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(uid, "TOGGLE_TECHNICIAN_STATUS", "technicians", docId, "$fullName -> $nextStatus")
            techniciansTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun suspendTechnician(technicianId: String, suspended: Boolean, fullName: String): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(docId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "technicians",
                categoryKey = "technicians",
                recordId = docId,
                supabaseFilterQuery = "technician_id=eq.$encId",
                patchJson = JSONObject()
                    .put("is_suspended", suspended)
                    .put("blocked", suspended)
                    .put("verification_status", if (suspended) "SUSPENDED" else "VERIFIED")
                    .put("updated_by_uid", uid)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            logAdminAction(
                uid,
                if (suspended) "SUSPEND_TECHNICIAN" else "UNSUSPEND_TECHNICIAN",
                "technicians",
                docId,
                "$fullName -> suspended=$suspended"
            )
            techniciansTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun softDeleteTechnician(technicianId: String, deleted: Boolean, fullName: String): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(docId, "UTF-8")
            val patch = JSONObject()
                .put("is_deleted", deleted)
                .put("status", if (deleted) "INACTIVE" else "ACTIVE")
                .put("updated_by_uid", uid)
                .put("updated_at", CloudTimestamp.toIsoString())
            if (deleted) patch.put("deleted_at", CloudTimestamp.toIsoString())
            storageRouter.patchRowWithFailover(
                tableName = "technicians",
                categoryKey = "technicians",
                recordId = docId,
                supabaseFilterQuery = "technician_id=eq.$encId",
                patchJson = patch
            ).getOrThrow()
            logAdminAction(
                uid,
                if (deleted) "SOFT_DELETE_TECHNICIAN" else "RESTORE_TECHNICIAN",
                "technicians",
                docId,
                "$fullName -> deleted=$deleted"
            )
            techniciansTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun removeTechnicianPhoto(technicianId: String, photoStoragePath: String, photoUrl: String): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(docId, "UTF-8")
            storageRouter.patchRowWithFailover(
                tableName = "technicians",
                categoryKey = "technicians",
                recordId = docId,
                supabaseFilterQuery = "technician_id=eq.$encId",
                patchJson = JSONObject()
                    .put("photo_url", "")
                    .put("photo_storage_path", "")
                    .put("updated_by_uid", uid)
                    .put("updated_at", CloudTimestamp.toIsoString())
            ).getOrThrow()
            runCatching {
                storageRouter.deleteObject(bucketKey = "technicians", storagePath = photoStoragePath, publicUrl = photoUrl)
            }
            logAdminAction(uid, "REMOVE_TECHNICIAN_PHOTO", "technicians", docId, "Removed profile photo")
            techniciansTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteTechnician(
        technicianId: String,
        fullName: String,
        photoStoragePath: String,
        photoUrl: String = ""
    ): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            val encId = URLEncoder.encode(docId, "UTF-8")
            storageRouter.deleteRowWithFailover(
                tableName = "technicians",
                categoryKey = "technicians",
                recordId = docId,
                supabaseFilterQuery = "technician_id=eq.$encId"
            ).getOrThrow()
            runCatching {
                storageRouter.deleteObject(bucketKey = "technicians", storagePath = photoStoragePath, publicUrl = photoUrl)
            }
            logAdminAction(uid, "DELETE_TECHNICIAN", "technicians", docId, "Deleted $fullName")
            techniciansTick.value += 1
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleCloudError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    companion object {
        fun sanitizeId(raw: String): String {
            val cleaned = raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            return cleaned.take(120).ifBlank { "doc_${System.currentTimeMillis()}" }
        }
    }
}
