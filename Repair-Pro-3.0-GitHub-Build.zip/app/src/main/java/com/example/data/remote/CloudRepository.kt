package com.example.data.remote

import android.content.Context
import com.example.BuildConfig
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import com.google.firebase.storage.storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID

class CloudRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
    private val storageProvider: () -> FirebaseStorage = { Firebase.storage },
    private val supabaseClient: SupabaseClient = SupabaseClient(
        firebaseTokenProvider = { forceRefresh ->
            runCatching { auth.currentUser?.getIdToken(forceRefresh)?.await()?.token }.getOrNull()
        }
    ),
    private val storageRouter: MultiCloudStorageRouter = MultiCloudStorageRouter(
        dbProvider = { db },
        authProvider = { auth },
        storageProvider = storageProvider,
        supabaseClientOverride = supabaseClient
    ),
    private val httpClient: OkHttpClient = SupabaseClient.defaultHttpClient()
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun isCurrentUserBootstrapAdmin(): Boolean {
        val user = auth.currentUser ?: return false
        return user.isEmailVerified &&
            user.email.equals(BOOTSTRAP_SUPER_ADMIN_EMAIL, ignoreCase = true)
    }

    suspend fun checkIsAdmin(userId: String): Boolean {
        if (isCurrentUserBootstrapAdmin()) return true
        return try {
            val doc = db.collection("admins").document(userId).get().await()
            doc.exists()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "admins/$userId")
            false
        }
    }

    suspend fun ensureUserProfile(
        userId: String,
        displayName: String,
        preferredLanguage: String
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val docRef = db.collection("users").document(userId)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val safeName = displayName.trim().ifBlank { "Repair Pro User" }.take(80)
                val safeLang = if (preferredLanguage in listOf("en", "bn", "hi")) preferredLanguage else "en"
                val safeEmail = auth.currentUser?.email.orEmpty().trim().take(160)
                val payload = mapOf(
                    "userId" to userId,
                    "displayName" to safeName,
                    "email" to safeEmail,
                    "preferredLanguage" to safeLang,
                    "adConsentGranted" to true,
                    "accountStatus" to "ACTIVE",
                    "blocked" to false,
                    "suspended" to false,
                    "communityRestricted" to false,
                    "uploadRestricted" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                val backfills = mutableMapOf<String, Any>()
                val currentEmail = auth.currentUser?.email.orEmpty().trim().take(160)
                if (currentEmail.isNotEmpty() && snap.getString("email").isNullOrBlank()) {
                    backfills["email"] = currentEmail
                }
                val cleanName = displayName.trim().take(80)
                if (cleanName.isNotEmpty() && snap.getString("displayName").isNullOrBlank()) {
                    backfills["displayName"] = cleanName
                }
                if (backfills.isNotEmpty()) {
                    backfills["updatedAt"] = FieldValue.serverTimestamp()
                    docRef.update(backfills).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateUserPreferences(
        userId: String,
        preferredLanguage: String? = null,
        adConsentGranted: Boolean? = null,
        notificationsEnabled: Boolean? = null
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
            if (preferredLanguage != null && preferredLanguage in listOf("en", "bn", "hi")) {
                updates["preferredLanguage"] = preferredLanguage
            }
            if (adConsentGranted != null) {
                updates["adConsentGranted"] = adConsentGranted
            }
            if (notificationsEnabled != null) {
                updates["notificationsEnabled"] = notificationsEnabled
            }
            db.collection("users").document(userId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfileCloud?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snap -> snap.toObject(UserProfileCloud::class.java, ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeSavedGuides(userId: String): Flow<List<SavedGuideCloud>> = flow {
        val path = "users/$userId/saved_guides"
        emitAll(
            db.collection("users").document(userId).collection("saved_guides")
                .snapshots()
                .map { snap ->
                    snap.toObjects(SavedGuideCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    suspend fun saveGuide(
        userId: String,
        itemType: String,
        itemId: String,
        categoryId: String,
        title: String,
        subtitle: String
    ): Result<Unit> {
        val safeDocId = sanitizeId("${itemType.lowercase()}_$itemId")
        val path = "users/$userId/saved_guides/$safeDocId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val payload = mapOf(
                "userId" to userId,
                "itemType" to if (itemType == "ERROR_CODE") "ERROR_CODE" else "PROBLEM",
                "itemId" to itemId.take(128),
                "categoryId" to categoryId.take(64),
                "title" to title.trim().ifBlank { "Saved Guide" }.take(180),
                "subtitle" to subtitle.trim().take(240),
                "createdAt" to FieldValue.serverTimestamp()
            )
            db.collection("users").document(userId)
                .collection("saved_guides").document(safeDocId)
                .set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun removeSavedGuide(userId: String, guideDocId: String): Result<Unit> {
        val path = "users/$userId/saved_guides/$guideDocId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            db.collection("users").document(userId)
                .collection("saved_guides").document(guideDocId)
                .delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    fun observeUserProblemReports(userId: String): Flow<List<ProblemReportCloud>> = flow {
        val path = "problem_reports"
        emitAll(
            db.collection("problem_reports")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ProblemReportCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeAllProblemReportsForAdmin(adminUid: String): Flow<List<ProblemReportCloud>> = flow {
        val path = "problem_reports"
        emitAll(
            db.collection("problem_reports")
                .snapshots()
                .map { snap ->
                    snap.toObjects(ProblemReportCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun submitProblemReport(
        userId: String,
        categoryId: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        description: String,
        preferredLanguage: String
    ): Result<Unit> {
        val docId = sanitizeId("rep_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "problem_reports/$docId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            require(brandName.trim().isNotEmpty()) { "Brand name is required." }
            require(description.trim().length >= 5) { "Please enter at least 5 characters describing the issue." }
            val safeLang = if (preferredLanguage in listOf("en", "bn", "hi")) preferredLanguage else "en"
            val payload = mutableMapOf<String, Any?>(
                "userId" to userId,
                "categoryId" to categoryId.take(64),
                "brandName" to brandName.trim().take(80),
                "modelName" to modelName.trim().take(100).ifBlank { null },
                "errorCode" to errorCode.trim().uppercase().take(32).ifBlank { null },
                "description" to description.trim().take(1500),
                "preferredLanguage" to safeLang,
                "status" to "PENDING",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>

            db.collection("problem_reports").document(docId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProblemReportStatus(
        reportId: String,
        newStatus: String,
        adminNote: String
    ): Result<Unit> {
        val path = "problem_reports/$reportId"
        return try {
            val uid = requireUserId()
            require(newStatus in listOf("PENDING", "REVIEWED", "PUBLISHED")) { "Invalid status." }
            val updates = mutableMapOf<String, Any>(
                "status" to newStatus,
                "adminNote" to adminNote.trim().take(1000),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("problem_reports").document(reportId).update(updates).await()
            logAdminAction(uid, "UPDATE_REPORT_STATUS", "problem_reports", reportId, "Status -> $newStatus")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observePublishedCatalog(userId: String): Flow<List<CatalogEntryCloud>> = flow {
        val path = "catalog_entries"
        emitAll(
            db.collection("catalog_entries")
                .whereEqualTo("published", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(CatalogEntryCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeAllCatalogForAdmin(adminUid: String): Flow<List<CatalogEntryCloud>> = flow {
        val path = "catalog_entries"
        emitAll(
            db.collection("catalog_entries")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CatalogEntryCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun publishCatalogEntry(entry: CatalogEntryCloud): Result<Unit> {
        val docId = if (entry.id.isNotBlank()) sanitizeId(entry.id)
        else sanitizeId("cat_${UUID.randomUUID().toString().replace("-", "").take(14)}")
        val path = "catalog_entries/$docId"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("catalog_entries").document(docId)
            val existingSnap = docRef.get().await()
            val cleanType = if (entry.entryType in listOf("CATEGORY", "ERROR_CODE", "PROBLEM")) entry.entryType else "ERROR_CODE"
            val cleanVer = if (entry.verificationStatus in listOf("VERIFIED", "UNVERIFIED")) entry.verificationStatus else "VERIFIED"

            val cleanPhotoUrl = entry.photoUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 } ?: ""
            val cleanPdfUrl = entry.pdfUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 } ?: ""
            val cleanDiagramUrl = entry.diagramUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 } ?: ""

            if (!existingSnap.exists()) {
                val payload = mapOf(
                    "entryType" to cleanType,
                    "categoryId" to entry.categoryId.take(64),
                    "brandName" to entry.brandName.trim().take(80).ifBlank { null },
                    "modelSeries" to entry.modelSeries.trim().take(100).ifBlank { null },
                    "code" to entry.code.trim().uppercase().take(32).ifBlank { null },
                    "titleEn" to entry.titleEn.trim().ifBlank { "Untitled Entry" }.take(180),
                    "titleBn" to entry.titleBn.trim().take(220).ifBlank { null },
                    "titleHi" to entry.titleHi.trim().take(220).ifBlank { null },
                    "summaryEn" to entry.summaryEn.trim().ifBlank { "Details pending" }.take(1200),
                    "summaryBn" to entry.summaryBn.trim().take(1400).ifBlank { null },
                    "summaryHi" to entry.summaryHi.trim().take(1400).ifBlank { null },
                    "stepsEn" to entry.stepsEn.trim().take(2000).ifBlank { null },
                    "stepsBn" to entry.stepsBn.trim().take(2400).ifBlank { null },
                    "stepsHi" to entry.stepsHi.trim().take(2400).ifBlank { null },
                    "safetyWarningEn" to entry.safetyWarningEn.trim().take(600).ifBlank { null },
                    "photoUrl" to cleanPhotoUrl.ifBlank { null },
                    "photoStoragePath" to entry.photoStoragePath.trim().take(320).ifBlank { null },
                    "pdfUrl" to cleanPdfUrl.ifBlank { null },
                    "pdfStoragePath" to entry.pdfStoragePath.trim().take(320).ifBlank { null },
                    "pdfTitle" to entry.pdfTitle.trim().take(160).ifBlank { null },
                    "diagramUrl" to cleanDiagramUrl.ifBlank { null },
                    "diagramStoragePath" to entry.diagramStoragePath.trim().take(320).ifBlank { null },
                    "diagramTitle" to entry.diagramTitle.trim().take(160).ifBlank { null },
                    "verificationStatus" to cleanVer,
                    "published" to entry.published,
                    "revision" to 1L,
                    "updatedByUid" to uid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null } as Map<String, Any>
                docRef.set(payload).await()
                logAdminAction(uid, "CREATE_CATALOG_ENTRY", "catalog_entries", docId, "${entry.entryType}: ${entry.titleEn}")
            } else {
                val currentRev = existingSnap.getLong("revision") ?: 1L
                val updates = mapOf(
                    "brandName" to entry.brandName.trim().take(80),
                    "modelSeries" to entry.modelSeries.trim().take(100),
                    "code" to entry.code.trim().uppercase().take(32),
                    "titleEn" to entry.titleEn.trim().ifBlank { "Untitled Entry" }.take(180),
                    "titleBn" to entry.titleBn.trim().take(220),
                    "titleHi" to entry.titleHi.trim().take(220),
                    "summaryEn" to entry.summaryEn.trim().ifBlank { "Details pending" }.take(1200),
                    "summaryBn" to entry.summaryBn.trim().take(1400),
                    "summaryHi" to entry.summaryHi.trim().take(1400),
                    "stepsEn" to entry.stepsEn.trim().take(2000),
                    "stepsBn" to entry.stepsBn.trim().take(2400),
                    "stepsHi" to entry.stepsHi.trim().take(2400),
                    "safetyWarningEn" to entry.safetyWarningEn.trim().take(600),
                    "photoUrl" to cleanPhotoUrl,
                    "photoStoragePath" to entry.photoStoragePath.trim().take(320),
                    "pdfUrl" to cleanPdfUrl,
                    "pdfStoragePath" to entry.pdfStoragePath.trim().take(320),
                    "pdfTitle" to entry.pdfTitle.trim().take(160),
                    "diagramUrl" to cleanDiagramUrl,
                    "diagramStoragePath" to entry.diagramStoragePath.trim().take(320),
                    "diagramTitle" to entry.diagramTitle.trim().take(160),
                    "verificationStatus" to cleanVer,
                    "published" to entry.published,
                    "revision" to (currentRev + 1L),
                    "updatedByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
                logAdminAction(uid, "UPDATE_CATALOG_ENTRY", "catalog_entries", docId, "Rev ${currentRev + 1}: ${entry.titleEn}")
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteCatalogEntry(entryId: String): Result<Unit> {
        val safeId = sanitizeId(entryId)
        val path = "catalog_entries/$safeId"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("catalog_entries").document(safeId)
            val existing = runCatching { docRef.get().await().toObject(CatalogEntryCloud::class.java) }.getOrNull()
            docRef.delete().await()
            if (existing != null) {
                if (existing.photoStoragePath.isNotBlank() || existing.photoUrl.isNotBlank()) {
                    runCatching {
                        storageRouter.deleteObject(
                            bucketKey = "diagrams",
                            storagePath = existing.photoStoragePath,
                            publicUrl = existing.photoUrl
                        )
                    }
                }
                if (existing.diagramStoragePath.isNotBlank() || existing.diagramUrl.isNotBlank()) {
                    runCatching {
                        storageRouter.deleteObject(
                            bucketKey = "diagrams",
                            storagePath = existing.diagramStoragePath,
                            publicUrl = existing.diagramUrl
                        )
                    }
                }
                if (existing.pdfStoragePath.isNotBlank() || existing.pdfUrl.isNotBlank()) {
                    runCatching {
                        storageRouter.deleteObject(
                            bucketKey = "pdfs",
                            storagePath = existing.pdfStoragePath,
                            publicUrl = existing.pdfUrl
                        )
                    }
                }
            }
            logAdminAction(uid, "DELETE_CATALOG_ENTRY", "catalog_entries", safeId, "Deleted catalog entry")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    fun observeAdMobConfig(userId: String): Flow<AppSettingCloud> = flow {
        val path = "app_settings/admob_config"
        emitAll(
            db.collection("app_settings").document("admob_config")
                .snapshots()
                .map { snap ->
                    snap.toObject(AppSettingCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        ?: AppSettingCloud(id = "admob_config", configType = "ADMOB")
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeGlobalConfig(userId: String): Flow<AppSettingCloud> = flow {
        val path = "app_settings/global_config"
        emitAll(
            db.collection("app_settings").document("global_config")
                .snapshots()
                .map { snap ->
                    snap.toObject(AppSettingCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        ?: AppSettingCloud(id = "global_config", configType = "GLOBAL")
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    suspend fun saveAdMobConfig(config: AppSettingCloud): Result<Unit> {
        val path = "app_settings/admob_config"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "configType" to "ADMOB",
                "adsGlobalEnabled" to config.adsGlobalEnabled,
                "bannerEnabled" to config.bannerEnabled,
                "interstitialEnabled" to config.interstitialEnabled,
                "rewardedEnabled" to config.rewardedEnabled,
                "nativeEnabled" to config.nativeEnabled,
                "emergencyKillSwitch" to config.emergencyKillSwitch,
                "testMode" to config.testMode,
                "acAdsEnabled" to config.acAdsEnabled,
                "fridgeAdsEnabled" to config.fridgeAdsEnabled,
                "washerAdsEnabled" to config.washerAdsEnabled,
                "interstitialCooldownMin" to config.interstitialCooldownMin.coerceIn(1L, 60L),
                "sessionFrequencyCap" to config.sessionFrequencyCap.coerceIn(1L, 50L),
                "androidAppId" to config.androidAppId.take(120),
                "androidBannerId" to config.androidBannerId.take(120),
                "androidInterstitialId" to config.androidInterstitialId.take(120),
                "androidRewardedId" to config.androidRewardedId.take(120),
                "iosAppId" to config.iosAppId.take(120),
                "iosBannerId" to config.iosBannerId.take(120),
                "updatedByUid" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("app_settings").document("admob_config").set(payload).await()
            logAdminAction(
                uid,
                "UPDATE_ADMOB_CONFIG",
                "app_settings",
                "admob_config",
                "Global=${config.adsGlobalEnabled}, Kill=${config.emergencyKillSwitch}, Test=${config.testMode}"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveGlobalConfig(
        announcement: String,
        maintenanceNotice: String,
        minSupportedVersion: String
    ): Result<Unit> {
        val path = "app_settings/global_config"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "configType" to "GLOBAL",
                "announcement" to announcement.trim().take(400),
                "maintenanceNotice" to maintenanceNotice.trim().take(400),
                "minSupportedVersion" to minSupportedVersion.trim().ifBlank { "1.0.0" }.take(32),
                "updatedByUid" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("app_settings").document("global_config").set(payload, SetOptions.merge()).await()
            logAdminAction(uid, "UPDATE_GLOBAL_SETTINGS", "app_settings", "global_config", "MinVer=$minSupportedVersion")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveGlobalConfig(config: AppSettingCloud): Result<Unit> {
        val path = "app_settings/global_config"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "configType" to "GLOBAL",
                "announcement" to config.announcement.trim().take(400),
                "maintenanceNotice" to config.maintenanceNotice.trim().take(400),
                "maintenanceMode" to config.maintenanceMode,
                "schemaVersion" to config.schemaVersion.coerceAtLeast(1L),
                "minSupportedVersion" to config.minSupportedVersion.trim().ifBlank { "1.0.0" }.take(32),
                "minSupportedVersionCode" to config.minSupportedVersionCode.coerceAtLeast(1L),
                "latestVersionCode" to config.latestVersionCode.coerceAtLeast(1L),
                "latestVersionName" to config.latestVersionName.trim().ifBlank { "1.2.0" }.take(32),
                "forceUpdate" to config.forceUpdate,
                "updateMessage" to config.updateMessage.trim().take(400),
                "updateUrl" to config.updateUrl.trim().take(600),
                "communityEnabled" to config.communityEnabled,
                "techniciansEnabled" to config.techniciansEnabled,
                "billingEnabled" to config.billingEnabled,
                "verificationEnabled" to config.verificationEnabled,
                "scannerEnabled" to config.scannerEnabled,
                "reportsEnabled" to config.reportsEnabled,
                "pdfsEnabled" to config.pdfsEnabled,
                "updatedByUid" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("app_settings").document("global_config").set(payload, SetOptions.merge()).await()
            logAdminAction(
                uid,
                "UPDATE_GLOBAL_SETTINGS",
                "app_settings",
                "global_config",
                "Maint=${config.maintenanceMode}, ForceUpd=${config.forceUpdate}, Latest=${config.latestVersionCode}"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    fun observeAllUsersForAdmin(adminUid: String): Flow<List<UserProfileCloud>> = flow {
        val path = "users"
        emitAll(
            db.collection("users")
                .snapshots()
                .map { snap ->
                    snap.toObjects(UserProfileCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun syncMyFirebaseClaims(): Boolean = storageRouter.syncMyFirebaseClaims()

    suspend fun moderateUserViaEdgeFunction(
        targetUid: String,
        action: String,
        reason: String = ""
    ): Result<String> = withContext(Dispatchers.IO) {
        val safeTarget = sanitizeId(targetUid)
        if (safeTarget.isBlank()) return@withContext Result.failure(IllegalArgumentException("Target UID is required."))
        val user = auth.currentUser
            ?: return@withContext Result.failure(IllegalStateException("Admin sign-in required."))
        val anonKey = supabaseClient.resolveAnonKey().ifBlank { BuildConfig.SUPABASE_ANON_KEY }
        val endpoint = "${supabaseClient.resolveUrl()}/functions/v1/admin-user-management"
        val bodyJson = JSONObject()
            .put("action", action)
            .put("targetUid", safeTarget)
            .put("reason", reason.trim().take(400))
            .toString()

        fun buildReq(token: String) = Request.Builder()
            .url(endpoint)
            .post(bodyJson.toRequestBody("application/json".toMediaTypeOrNull()))
            .addHeader("Authorization", "Bearer $token")
            .apply { if (anonKey.isNotBlank()) addHeader("apikey", anonKey) }
            .addHeader("Content-Type", "application/json")
            .build()

        runCatching {
            var idToken = user.getIdToken(false).await().token.orEmpty()
            if (idToken.isBlank()) throw IllegalStateException("Firebase ID token missing.")
            var resp = httpClient.newCall(buildReq(idToken)).execute()
            if (resp.code == 401) {
                resp.close()
                idToken = user.getIdToken(true).await().token.orEmpty()
                resp = httpClient.newCall(buildReq(idToken)).execute()
            }
            resp.use { r ->
                val raw = r.body?.string().orEmpty()
                val parsed = runCatching { JSONObject(raw) }.getOrNull()
                if (!r.isSuccessful || parsed == null || !parsed.optBoolean("ok", false)) {
                    throw IllegalStateException(parsed?.optString("message")?.takeIf { it.isNotBlank() } ?: "User moderation HTTP ${r.code}")
                }
                parsed.optString("message", "User action completed ($action).")
            }
        }
    }

    suspend fun deleteUserAccountViaEdgeFunction(targetUid: String, reason: String = ""): Result<String> =
        moderateUserViaEdgeFunction(targetUid, "delete_user", reason)

    fun observeAuditLogsForAdmin(adminUid: String): Flow<List<AuditLogCloud>> = flow {
        val path = "audit_logs"
        emitAll(
            db.collection("audit_logs")
                .snapshots()
                .map { snap ->
                    snap.toObjects(AuditLogCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    fun observeAdminRolesForBootstrapAdmin(adminUid: String): Flow<List<AdminRoleCloud>> = flow {
        val path = "admins"
        emitAll(
            db.collection("admins")
                .snapshots()
                .map { snap ->
                    snap.toObjects(AdminRoleCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun upsertAdminRole(targetUid: String, role: String): Result<Unit> {
        val cleanUid = sanitizeId(targetUid.trim())
        val cleanRole = if (role in listOf("SUPER_ADMIN", "CONTENT_EDITOR", "TRANSLATOR", "ANALYST")) role else "CONTENT_EDITOR"
        val path = "admins/$cleanUid"
        return try {
            val actorUid = requireUserId()
            val docRef = db.collection("admins").document(cleanUid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = mapOf(
                    "userId" to cleanUid,
                    "role" to cleanRole,
                    "createdAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
                logAdminAction(actorUid, "GRANT_ADMIN_ROLE", "admins", cleanUid, "Granted $cleanRole")
            } else {
                docRef.update(mapOf("role" to cleanRole)).await()
                logAdminAction(actorUid, "UPDATE_ADMIN_ROLE", "admins", cleanUid, "Updated role -> $cleanRole")
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun removeAdminRole(targetUid: String): Result<Unit> {
        val cleanUid = sanitizeId(targetUid.trim())
        val path = "admins/$cleanUid"
        return try {
            val actorUid = requireUserId()
            db.collection("admins").document(cleanUid).delete().await()
            logAdminAction(actorUid, "REVOKE_ADMIN_ROLE", "admins", cleanUid, "Revoked admin role")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private suspend fun logAdminAction(
        adminUid: String,
        action: String,
        targetType: String,
        targetId: String,
        details: String
    ) {
        val logId = sanitizeId("log_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val email = auth.currentUser?.email ?: "admin@repairpro.local"
        val payload = mapOf(
            "adminUid" to adminUid,
            "adminEmail" to email.take(160),
            "action" to action.take(100),
            "targetType" to targetType.take(64),
            "targetId" to targetId.take(128),
            "details" to details.take(500),
            "result" to "SUCCESS",
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            db.collection("audit_logs").document(logId).set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "audit_logs/$logId")
        }
    }

    suspend fun deleteUserCloudData(userId: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val savedSnap = db.collection("users").document(userId).collection("saved_guides").get().await()
            for (doc in savedSnap.documents) {
                doc.reference.delete().await()
            }
            val reportsSnap = db.collection("problem_reports").whereEqualTo("userId", userId).get().await()
            for (doc in reportsSnap.documents) {
                doc.reference.delete().await()
            }
            db.collection("users").document(userId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "users/$userId")
            Result.failure(e)
        }
    }

    // --- TECHNICIAN DIRECTORY (ACTIVE-ONLY FOR USERS, FULL CRUD FOR ADMINS) ---

    fun observeActiveTechnicians(userId: String): Flow<List<TechnicianCloud>> = flow {
        val path = "technicians"
        emitAll(
            db.collection("technicians")
                .whereEqualTo("status", "ACTIVE")
                .snapshots()
                .map { snap ->
                    snap.toObjects(TechnicianCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .filter { it.isPubliclyVisible }
                        .sortedBy { it.fullName.lowercase() }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeAllTechniciansForAdmin(adminUid: String): Flow<List<TechnicianCloud>> = flow {
        val path = "technicians"
        emitAll(
            db.collection("technicians")
                .snapshots()
                .map { snap ->
                    snap.toObjects(TechnicianCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun uploadTechnicianPhoto(
        technicianId: String,
        imageBytes: ByteArray,
        contentType: String = "image/jpeg"
    ): Result<Pair<String, String>> {
        val safeTechId = sanitizeId(technicianId)
        val safeContentType = when (contentType.lowercase()) {
            "image/png" -> "image/png"
            "image/webp" -> "image/webp"
            else -> "image/jpeg"
        }
        val ext = when (safeContentType) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        val objectPath = "$safeTechId/profile_${System.currentTimeMillis()}.$ext"
        return try {
            requireUserId()
            require(imageBytes.isNotEmpty() && imageBytes.size < 5 * 1024 * 1024) {
                "Photo must be smaller than 5 MB."
            }
            storageRouter.uploadBytes(
                bucketKey = "technicians",
                objectPath = objectPath,
                bytes = imageBytes,
                mimeType = safeContentType
            ).map { it.publicUrl to it.storagePath }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveTechnician(technician: TechnicianCloud): Result<Unit> {
        val docId = if (technician.id.isNotBlank()) sanitizeId(technician.id)
        else sanitizeId("tech_${UUID.randomUUID().toString().replace("-", "").take(14)}")
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            val cleanName = technician.fullName.trim().take(100)
            val cleanPhone = technician.mobileNumber.trim().take(20)
            val cleanAddress = technician.fullAddress.trim().take(300)
            val cleanState = technician.state.trim().take(80)
            val cleanDistrict = technician.district.trim().take(80)
            val cleanArea = technician.cityArea.trim().take(80)
            val cleanPin = technician.pinCode.trim().take(12)
            val cleanExp = technician.experience.trim().take(80)
            val cleanStatus = if (technician.status == "INACTIVE") "INACTIVE" else "ACTIVE"
            val allowedCats = setOf("AC", "Refrigerator", "Washing Machine")
            val cleanCategories = technician.serviceCategories.filter { it in allowedCats }.distinct()
            val cleanPhotoUrl = technician.photoUrl.trim()
                .takeIf { it.startsWith("https://") && it.length <= 1000 } ?: ""
            val cleanStoragePath = technician.photoStoragePath.trim().take(300)

            require(cleanName.length >= 2) { "Full name must be at least 2 characters." }
            require(Regex("^[+0-9\\s\\-()]{6,20}$").matches(cleanPhone)) { "Enter a valid mobile number." }
            require(cleanAddress.length >= 3 && cleanState.isNotEmpty() && cleanDistrict.isNotEmpty() && cleanArea.isNotEmpty()) {
                "Full address, state, district, and city/area are required."
            }
            require(Regex("^[a-zA-Z0-9\\s\\-]{4,12}$").matches(cleanPin)) { "Enter a valid PIN code." }
            require(cleanCategories.isNotEmpty()) { "Select at least one service category." }

            val docRef = db.collection("technicians").document(docId)
            val existingSnap = docRef.get().await()

            val cleanBio = technician.bio.trim().take(600)
            val cleanVerification = if (technician.verificationStatus in listOf("PENDING", "VERIFIED", "REJECTED", "SUSPENDED")) {
                technician.verificationStatus
            } else "VERIFIED"

            if (!existingSnap.exists()) {
                val payload = mapOf(
                    "technicianId" to docId,
                    "fullName" to cleanName,
                    "photoUrl" to cleanPhotoUrl.ifBlank { null },
                    "photoStoragePath" to cleanStoragePath.ifBlank { null },
                    "mobileNumber" to cleanPhone,
                    "fullAddress" to cleanAddress,
                    "state" to cleanState,
                    "district" to cleanDistrict,
                    "cityArea" to cleanArea,
                    "pinCode" to cleanPin,
                    "serviceCategories" to cleanCategories,
                    "experience" to cleanExp.ifBlank { null },
                    "bio" to cleanBio.ifBlank { null },
                    "verificationStatus" to cleanVerification,
                    "blocked" to technician.blocked,
                    "linkedUserUid" to technician.linkedUserUid.trim().take(128).ifBlank { null },
                    "status" to cleanStatus,
                    "updatedByUid" to uid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null } as Map<String, Any>
                docRef.set(payload).await()
                logAdminAction(uid, "CREATE_TECHNICIAN", "technicians", docId, "$cleanName ($cleanDistrict)")
            } else {
                val updates = mapOf(
                    "fullName" to cleanName,
                    "photoUrl" to cleanPhotoUrl,
                    "photoStoragePath" to cleanStoragePath,
                    "mobileNumber" to cleanPhone,
                    "fullAddress" to cleanAddress,
                    "state" to cleanState,
                    "district" to cleanDistrict,
                    "cityArea" to cleanArea,
                    "pinCode" to cleanPin,
                    "serviceCategories" to cleanCategories,
                    "experience" to cleanExp,
                    "bio" to cleanBio,
                    "verificationStatus" to cleanVerification,
                    "blocked" to technician.blocked,
                    "status" to cleanStatus,
                    "updatedByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
                logAdminAction(uid, "UPDATE_TECHNICIAN", "technicians", docId, "Updated $cleanName ($cleanStatus)")
            }
            runCatching {
                if (supabaseClient.isConfigured()) {
                    val liveLocation = listOf(cleanArea, cleanDistrict, cleanState, cleanPin)
                        .filter { it.isNotBlank() }
                        .joinToString(", ")
                    val rowJson = SupabaseClient.buildLiveTechnicianJson(
                        id = docId,
                        name = cleanName,
                        phone = cleanPhone,
                        photoUrl = cleanPhotoUrl,
                        bio = cleanBio,
                        specialty = cleanCategories.joinToString(", "),
                        location = liveLocation
                    )
                    supabaseClient.upsertTableRowRawJson(
                        tableName = "technicians",
                        rawJson = rowJson,
                        onConflict = "id"
                    )
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun setTechnicianStatus(technicianId: String, active: Boolean, fullName: String): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        val nextStatus = if (active) "ACTIVE" else "INACTIVE"
        return try {
            val uid = requireUserId()
            db.collection("technicians").document(docId).update(
                mapOf(
                    "status" to nextStatus,
                    "updatedByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            logAdminAction(uid, "TOGGLE_TECHNICIAN_STATUS", "technicians", docId, "$fullName -> $nextStatus")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun suspendTechnician(technicianId: String, suspended: Boolean, fullName: String): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            db.collection("technicians").document(docId).update(
                mapOf(
                    "isSuspended" to suspended,
                    "blocked" to suspended,
                    "verificationStatus" to if (suspended) "SUSPENDED" else "VERIFIED",
                    "updatedByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            logAdminAction(uid, if (suspended) "SUSPEND_TECHNICIAN" else "UNSUSPEND_TECHNICIAN", "technicians", docId, "$fullName -> suspended=$suspended")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun softDeleteTechnician(technicianId: String, deleted: Boolean, fullName: String): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            val updates = mutableMapOf<String, Any>(
                "isDeleted" to deleted,
                "status" to if (deleted) "INACTIVE" else "ACTIVE",
                "updatedByUid" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (deleted) {
                updates["deletedAt"] = FieldValue.serverTimestamp()
            }
            db.collection("technicians").document(docId).update(updates).await()
            logAdminAction(uid, if (deleted) "SOFT_DELETE_TECHNICIAN" else "RESTORE_TECHNICIAN", "technicians", docId, "$fullName -> deleted=$deleted")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun removeTechnicianPhoto(technicianId: String, photoStoragePath: String, photoUrl: String): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            db.collection("technicians").document(docId).update(
                mapOf(
                    "photoUrl" to "",
                    "photoStoragePath" to "",
                    "updatedByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            runCatching {
                storageRouter.deleteObject(
                    bucketKey = "technicians",
                    storagePath = photoStoragePath,
                    publicUrl = photoUrl
                )
            }
            logAdminAction(uid, "REMOVE_TECHNICIAN_PHOTO", "technicians", docId, "Removed profile photo")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteTechnician(
        technicianId: String,
        fullName: String,
        photoStoragePath: String,
        photoUrl: String = ""
    ): Result<Unit> {
        val docId = sanitizeId(technicianId)
        val path = "technicians/$docId"
        return try {
            val uid = requireUserId()
            db.collection("technicians").document(docId).delete().await()
            runCatching {
                storageRouter.deleteObject(
                    bucketKey = "technicians",
                    storagePath = photoStoragePath,
                    publicUrl = photoUrl
                )
            }
            logAdminAction(uid, "DELETE_TECHNICIAN", "technicians", docId, "Deleted $fullName")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private fun logStreamErrorIfActive(
        error: Throwable,
        op: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
    }

    companion object {
        fun sanitizeId(raw: String): String {
            val cleaned = raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            return cleaned.take(120).ifBlank { "doc_${System.currentTimeMillis()}" }
        }
    }
}
