package com.example.data.remote

import org.json.JSONArray
import org.json.JSONObject

internal object SupabaseMappers {

    fun optNonBlank(obj: JSONObject, vararg keys: String): String {
        for (key in keys) {
            if (!obj.has(key) || obj.isNull(key)) continue
            val value = obj.optString(key, "").trim()
            if (value.isNotEmpty() && !value.equals("null", ignoreCase = true)) {
                return value
            }
        }
        return ""
    }

    fun optStringList(obj: JSONObject, vararg keys: String): List<String> {
        for (key in keys) {
            if (!obj.has(key) || obj.isNull(key)) continue
            val raw = obj.opt(key)
            if (raw is JSONArray) {
                val out = mutableListOf<String>()
                for (i in 0 until raw.length()) {
                    val item = raw.optString(i, "").trim()
                    if (item.isNotEmpty() && !item.equals("null", ignoreCase = true)) {
                        out.add(item)
                    }
                }
                return out
            }
            if (raw is String && raw.trim().startsWith("[")) {
                val parsed = runCatching { JSONArray(raw) }.getOrNull()
                if (parsed != null) {
                    val out = mutableListOf<String>()
                    for (i in 0 until parsed.length()) {
                        val item = parsed.optString(i, "").trim()
                        if (item.isNotEmpty()) out.add(item)
                    }
                    return out
                }
            }
        }
        return emptyList()
    }

    fun optTimestamp(obj: JSONObject, vararg keys: String): CloudTimestamp? {
        for (key in keys) {
            if (!obj.has(key) || obj.isNull(key)) continue
            val parsed = CloudTimestamp.parseIso(obj.optString(key, ""))
            if (parsed != null) return parsed
        }
        return null
    }

    fun jsonArrayToObjects(arr: JSONArray?): List<JSONObject> {
        if (arr == null || arr.length() == 0) return emptyList()
        val list = ArrayList<JSONObject>(arr.length())
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { list.add(it) }
        }
        return list
    }

    fun toUserProfile(obj: JSONObject): UserProfileCloud {
        val uid = optNonBlank(obj, "user_id", "userId", "id")
        return UserProfileCloud(
            id = uid,
            userId = uid,
            displayName = optNonBlank(obj, "display_name", "displayName").ifBlank { "Repair Pro User" },
            email = optNonBlank(obj, "email"),
            photoUrl = optNonBlank(obj, "photo_url", "photoUrl"),
            photoStoragePath = optNonBlank(obj, "photo_storage_path", "photoStoragePath"),
            photoProviderId = optNonBlank(obj, "photo_provider_id", "photoProviderId"),
            preferredLanguage = optNonBlank(obj, "preferred_language", "preferredLanguage").ifBlank { "en" },
            adConsentGranted = obj.optBoolean("ad_consent_granted", obj.optBoolean("adConsentGranted", true)),
            notificationsEnabled = obj.optBoolean("notifications_enabled", obj.optBoolean("notificationsEnabled", true)),
            isVerifiedTechnician = obj.optBoolean("is_verified_technician", obj.optBoolean("isVerifiedTechnician", false)),
            accountStatus = optNonBlank(obj, "account_status", "accountStatus").ifBlank { "ACTIVE" },
            blocked = obj.optBoolean("blocked", false),
            suspended = obj.optBoolean("suspended", false),
            communityRestricted = obj.optBoolean("community_restricted", obj.optBoolean("communityRestricted", false)),
            uploadRestricted = obj.optBoolean("upload_restricted", obj.optBoolean("uploadRestricted", false)),
            moderationReason = optNonBlank(obj, "moderation_reason", "moderationReason"),
            moderatedByUid = optNonBlank(obj, "moderated_by_uid", "moderatedByUid"),
            moderatedAt = optTimestamp(obj, "moderated_at", "moderatedAt"),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toSavedGuide(obj: JSONObject): SavedGuideCloud {
        val guideId = optNonBlank(obj, "guide_id", "guideId", "id")
        val entryType = optNonBlank(obj, "entry_type", "item_type", "itemType").ifBlank { "PROBLEM" }
        val itemId = when {
            guideId.startsWith("error_code_") -> guideId.removePrefix("error_code_")
            guideId.startsWith("problem_") -> guideId.removePrefix("problem_")
            else -> optNonBlank(obj, "item_id", "itemId", "code", "entry_id").ifBlank { guideId }
        }
        return SavedGuideCloud(
            id = guideId,
            userId = optNonBlank(obj, "user_id", "userId"),
            itemType = if (entryType.equals("ERROR_CODE", ignoreCase = true)) "ERROR_CODE" else "PROBLEM",
            itemId = itemId,
            categoryId = optNonBlank(obj, "category_id", "categoryId").ifBlank { "ac" },
            title = optNonBlank(obj, "title"),
            subtitle = optNonBlank(obj, "summary", "subtitle"),
            createdAt = optTimestamp(obj, "saved_at", "created_at", "createdAt")
        )
    }

    fun toProblemReport(obj: JSONObject): ProblemReportCloud {
        val reportId = optNonBlank(obj, "report_id", "reportId", "id")
        return ProblemReportCloud(
            id = reportId,
            userId = optNonBlank(obj, "user_id", "userId"),
            categoryId = optNonBlank(obj, "category_id", "categoryId").ifBlank { "ac" },
            brandName = optNonBlank(obj, "brand_name", "brandName"),
            modelName = optNonBlank(obj, "model_name", "modelName"),
            errorCode = optNonBlank(obj, "error_code", "errorCode"),
            description = optNonBlank(obj, "description"),
            preferredLanguage = optNonBlank(obj, "preferred_language", "preferredLanguage").ifBlank { "en" },
            status = optNonBlank(obj, "status").ifBlank { "PENDING" },
            adminNote = optNonBlank(obj, "admin_note", "adminNote"),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toCatalogEntry(obj: JSONObject): CatalogEntryCloud {
        return CatalogEntryCloud(
            id = optNonBlank(obj, "id"),
            entryType = optNonBlank(obj, "entry_type", "entryType").ifBlank { "ERROR_CODE" },
            categoryId = optNonBlank(obj, "category_id", "categoryId").ifBlank { "ac" },
            brandName = optNonBlank(obj, "brand_name", "brandName"),
            modelSeries = optNonBlank(obj, "model_series", "modelSeries"),
            code = optNonBlank(obj, "code"),
            titleEn = optNonBlank(obj, "title_en", "titleEn"),
            titleBn = optNonBlank(obj, "title_bn", "titleBn"),
            titleHi = optNonBlank(obj, "title_hi", "titleHi"),
            summaryEn = optNonBlank(obj, "summary_en", "summaryEn"),
            summaryBn = optNonBlank(obj, "summary_bn", "summaryBn"),
            summaryHi = optNonBlank(obj, "summary_hi", "summaryHi"),
            stepsEn = optNonBlank(obj, "steps_en", "stepsEn"),
            stepsBn = optNonBlank(obj, "steps_bn", "stepsBn"),
            stepsHi = optNonBlank(obj, "steps_hi", "stepsHi"),
            safetyWarningEn = optNonBlank(obj, "safety_warning_en", "safetyWarningEn"),
            photoUrl = optNonBlank(obj, "photo_url", "photoUrl"),
            photoStoragePath = optNonBlank(obj, "photo_storage_path", "photoStoragePath"),
            pdfUrl = optNonBlank(obj, "pdf_url", "pdfUrl"),
            pdfStoragePath = optNonBlank(obj, "pdf_storage_path", "pdfStoragePath"),
            pdfTitle = optNonBlank(obj, "pdf_title", "pdfTitle"),
            diagramUrl = optNonBlank(obj, "diagram_url", "diagramUrl"),
            diagramStoragePath = optNonBlank(obj, "diagram_storage_path", "diagramStoragePath"),
            diagramTitle = optNonBlank(obj, "diagram_title", "diagramTitle"),
            verificationStatus = optNonBlank(obj, "verification_status", "verificationStatus").ifBlank { "VERIFIED" },
            published = obj.optBoolean("published", true),
            revision = obj.optLong("revision", 1L),
            updatedByUid = optNonBlank(obj, "updated_by_uid", "updatedByUid"),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toAppSetting(settingId: String, row: JSONObject?): AppSettingCloud {
        val payload = row?.optJSONObject("payload") ?: row ?: JSONObject()
        val updatedAt = row?.let { optTimestamp(it, "updated_at", "updatedAt") }
        val updatedByUid = row?.let { optNonBlank(it, "updated_by_uid", "updatedByUid") }.orEmpty()
        return AppSettingCloud(
            id = settingId,
            configType = row?.let { optNonBlank(it, "config_type", "configType") }
                ?.ifBlank { if (settingId == "admob_config") "ADMOB" else "GLOBAL" }
                ?: if (settingId == "admob_config") "ADMOB" else "GLOBAL",
            adsGlobalEnabled = payload.optBoolean("adsGlobalEnabled", payload.optBoolean("ads_global_enabled", true)),
            bannerEnabled = payload.optBoolean("bannerEnabled", payload.optBoolean("banner_enabled", true)),
            interstitialEnabled = payload.optBoolean("interstitialEnabled", payload.optBoolean("interstitial_enabled", false)),
            rewardedEnabled = payload.optBoolean("rewardedEnabled", payload.optBoolean("rewarded_enabled", true)),
            nativeEnabled = payload.optBoolean("nativeEnabled", payload.optBoolean("native_enabled", false)),
            emergencyKillSwitch = payload.optBoolean("emergencyKillSwitch", payload.optBoolean("emergency_kill_switch", false)),
            testMode = payload.optBoolean("testMode", payload.optBoolean("test_mode", true)),
            acAdsEnabled = payload.optBoolean("acAdsEnabled", payload.optBoolean("ac_ads_enabled", true)),
            fridgeAdsEnabled = payload.optBoolean("fridgeAdsEnabled", payload.optBoolean("fridge_ads_enabled", true)),
            washerAdsEnabled = payload.optBoolean("washerAdsEnabled", payload.optBoolean("washer_ads_enabled", true)),
            interstitialCooldownMin = payload.optLong("interstitialCooldownMin", payload.optLong("interstitial_cooldown_min", 3L)),
            sessionFrequencyCap = payload.optLong("sessionFrequencyCap", payload.optLong("session_frequency_cap", 6L)),
            androidAppId = optNonBlank(payload, "androidAppId", "android_app_id").ifBlank { "ca-app-pub-3940256099942544~3347511713" },
            androidBannerId = optNonBlank(payload, "androidBannerId", "android_banner_id").ifBlank { "ca-app-pub-3940256099942544/6300978111" },
            androidInterstitialId = optNonBlank(payload, "androidInterstitialId", "android_interstitial_id").ifBlank { "ca-app-pub-3940256099942544/1033173712" },
            androidRewardedId = optNonBlank(payload, "androidRewardedId", "android_rewarded_id").ifBlank { "ca-app-pub-3940256099942544/5224354917" },
            iosAppId = optNonBlank(payload, "iosAppId", "ios_app_id").ifBlank { "ca-app-pub-3940256099942544~1458002511" },
            iosBannerId = optNonBlank(payload, "iosBannerId", "ios_banner_id").ifBlank { "ca-app-pub-3940256099942544/2934735716" },
            announcement = optNonBlank(payload, "announcement"),
            maintenanceNotice = optNonBlank(payload, "maintenanceNotice", "maintenance_notice"),
            maintenanceMode = payload.optBoolean("maintenanceMode", payload.optBoolean("maintenance_mode", false)),
            schemaVersion = payload.optLong("schemaVersion", payload.optLong("schema_version", 2L)),
            minSupportedVersion = optNonBlank(payload, "minSupportedVersion", "min_supported_version").ifBlank { "1.0.0" },
            minSupportedVersionCode = payload.optLong("minSupportedVersionCode", payload.optLong("min_supported_version_code", 1L)),
            latestVersionCode = payload.optLong("latestVersionCode", payload.optLong("latest_version_code", 3L)),
            latestVersionName = optNonBlank(payload, "latestVersionName", "latest_version_name").ifBlank { "1.2.0" },
            forceUpdate = payload.optBoolean("forceUpdate", payload.optBoolean("force_update", false)),
            updateMessage = optNonBlank(payload, "updateMessage", "update_message"),
            updateUrl = optNonBlank(payload, "updateUrl", "update_url"),
            communityEnabled = payload.optBoolean("communityEnabled", payload.optBoolean("community_enabled", true)),
            techniciansEnabled = payload.optBoolean("techniciansEnabled", payload.optBoolean("technicians_enabled", true)),
            billingEnabled = payload.optBoolean("billingEnabled", payload.optBoolean("billing_enabled", true)),
            verificationEnabled = payload.optBoolean("verificationEnabled", payload.optBoolean("verification_enabled", true)),
            scannerEnabled = payload.optBoolean("scannerEnabled", payload.optBoolean("scanner_enabled", true)),
            reportsEnabled = payload.optBoolean("reportsEnabled", payload.optBoolean("reports_enabled", true)),
            pdfsEnabled = payload.optBoolean("pdfsEnabled", payload.optBoolean("pdfs_enabled", true)),
            updatedByUid = updatedByUid,
            updatedAt = updatedAt
        )
    }

    fun toAuditLog(obj: JSONObject): AuditLogCloud {
        return AuditLogCloud(
            id = optNonBlank(obj, "log_id", "logId", "id"),
            adminUid = optNonBlank(obj, "admin_uid", "adminUid"),
            adminEmail = optNonBlank(obj, "admin_email", "adminEmail"),
            action = optNonBlank(obj, "action"),
            targetType = optNonBlank(obj, "target_type", "targetType"),
            targetId = optNonBlank(obj, "target_id", "targetId"),
            details = optNonBlank(obj, "details"),
            result = optNonBlank(obj, "result").ifBlank { "SUCCESS" },
            createdAt = optTimestamp(obj, "created_at", "createdAt")
        )
    }

    fun toAdminRole(obj: JSONObject): AdminRoleCloud {
        val uid = optNonBlank(obj, "user_id", "userId", "id")
        return AdminRoleCloud(
            id = uid,
            userId = uid,
            role = optNonBlank(obj, "role").ifBlank { "SUPER_ADMIN" },
            createdAt = optTimestamp(obj, "created_at", "createdAt")
        )
    }

    fun toTechnician(obj: JSONObject): TechnicianCloud {
        val techId = optNonBlank(obj, "technician_id", "technicianId", "id")
        val cats = optStringList(obj, "service_categories", "service_categories_json", "serviceCategories")
            .ifEmpty {
                optNonBlank(obj, "specialty")
                    .split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
            }
        return TechnicianCloud(
            id = techId,
            technicianId = techId,
            fullName = optNonBlank(obj, "full_name", "fullName", "name"),
            photoUrl = optNonBlank(obj, "photo_url", "photoUrl"),
            photoStoragePath = optNonBlank(obj, "photo_storage_path", "photoStoragePath"),
            photoProviderId = optNonBlank(obj, "photo_provider_id", "photoProviderId"),
            storageProviderId = optNonBlank(obj, "storage_provider_id", "storageProviderId").ifBlank { "supabase_primary" },
            externalRecordId = optNonBlank(obj, "external_record_id", "externalRecordId"),
            mobileNumber = optNonBlank(obj, "mobile_number", "mobileNumber", "phone"),
            fullAddress = optNonBlank(obj, "full_address", "fullAddress", "location"),
            state = optNonBlank(obj, "state"),
            district = optNonBlank(obj, "district"),
            cityArea = optNonBlank(obj, "city_area", "cityArea"),
            pinCode = optNonBlank(obj, "pin_code", "pinCode"),
            serviceCategories = cats,
            experience = optNonBlank(obj, "experience"),
            bio = optNonBlank(obj, "bio"),
            verificationStatus = optNonBlank(obj, "verification_status", "verificationStatus").ifBlank { "VERIFIED" },
            blocked = obj.optBoolean("blocked", false),
            isSuspended = obj.optBoolean("is_suspended", obj.optBoolean("isSuspended", false)),
            isDeleted = obj.optBoolean("is_deleted", obj.optBoolean("isDeleted", false)),
            deletedAt = optTimestamp(obj, "deleted_at", "deletedAt"),
            linkedUserUid = optNonBlank(obj, "linked_user_uid", "linkedUserUid"),
            status = optNonBlank(obj, "status").ifBlank { "ACTIVE" },
            updatedByUid = optNonBlank(obj, "updated_by_uid", "updatedByUid"),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toCommunityPost(obj: JSONObject): CommunityPostCloud {
        val pid = optNonBlank(obj, "post_id", "postId", "id")
        val primaryUrl = optNonBlank(obj, "photo_url", "photoUrl")
        val urls = optStringList(obj, "photo_urls", "photo_urls_json", "photoUrls").ifEmpty {
            if (primaryUrl.startsWith("https://")) listOf(primaryUrl) else emptyList()
        }
        val primaryPath = optNonBlank(obj, "photo_storage_path", "photoStoragePath")
        val paths = optStringList(obj, "photo_storage_paths", "photo_storage_paths_json", "photoStoragePaths").ifEmpty {
            if (primaryPath.isNotEmpty()) listOf(primaryPath) else emptyList()
        }
        return CommunityPostCloud(
            id = pid,
            postId = pid,
            authorUid = optNonBlank(obj, "author_uid", "authorUid"),
            authorName = optNonBlank(obj, "author_name", "authorName").ifBlank { "Repair Pro Technician" },
            authorPhotoUrl = optNonBlank(obj, "author_photo_url", "authorPhotoUrl"),
            authorVerified = obj.optBoolean("author_verified", obj.optBoolean("authorVerified", false)),
            category = optNonBlank(obj, "category").ifBlank { "General" },
            brandName = optNonBlank(obj, "brand_name", "brandName"),
            modelName = optNonBlank(obj, "model_name", "modelName"),
            errorCode = optNonBlank(obj, "error_code", "errorCode"),
            title = optNonBlank(obj, "title"),
            body = optNonBlank(obj, "body"),
            photoUrl = primaryUrl.ifBlank { urls.firstOrNull().orEmpty() },
            photoStoragePath = primaryPath.ifBlank { paths.firstOrNull().orEmpty() },
            photoUrls = urls,
            photoStoragePaths = paths,
            photoProviderIds = optStringList(obj, "photo_provider_ids", "photo_provider_ids_json", "photoProviderIds"),
            storageProviderId = optNonBlank(obj, "storage_provider_id", "storageProviderId").ifBlank { "supabase_primary" },
            externalRecordId = optNonBlank(obj, "external_record_id", "externalRecordId"),
            isPinned = obj.optBoolean("is_pinned", obj.optBoolean("isPinned", false)),
            isHidden = obj.optBoolean("is_hidden", obj.optBoolean("isHidden", false)),
            isDeleted = obj.optBoolean("is_deleted", obj.optBoolean("isDeleted", false)),
            deletedByUid = optNonBlank(obj, "deleted_by_uid", "deletedByUid"),
            deletedAt = optTimestamp(obj, "deleted_at", "deletedAt"),
            approvalStatus = optNonBlank(obj, "approval_status", "approvalStatus").ifBlank { "PENDING" },
            moderationNote = optNonBlank(obj, "moderation_note", "moderationNote"),
            reviewedByUid = optNonBlank(obj, "reviewed_by_uid", "reviewedByUid"),
            likeCount = obj.optLong("like_count", obj.optLong("likeCount", 0L)),
            commentCount = obj.optLong("comment_count", obj.optLong("commentCount", 0L)),
            reportCount = obj.optLong("report_count", obj.optLong("reportCount", 0L)),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toCommunityComment(obj: JSONObject): CommunityCommentCloud {
        val cid = optNonBlank(obj, "comment_id", "commentId", "id")
        return CommunityCommentCloud(
            id = cid,
            commentId = cid,
            postId = optNonBlank(obj, "post_id", "postId"),
            parentCommentId = optNonBlank(obj, "parent_comment_id", "parentCommentId"),
            replyToAuthorName = optNonBlank(obj, "reply_to_author_name", "replyToAuthorName"),
            authorUid = optNonBlank(obj, "author_uid", "authorUid"),
            authorName = optNonBlank(obj, "author_name", "authorName"),
            authorVerified = obj.optBoolean("author_verified", obj.optBoolean("authorVerified", false)),
            body = optNonBlank(obj, "body"),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toSavedPost(obj: JSONObject): SavedPostCloud {
        val pid = optNonBlank(obj, "post_id", "postId")
        return SavedPostCloud(
            id = pid,
            userId = optNonBlank(obj, "user_id", "userId"),
            postId = pid,
            title = optNonBlank(obj, "title"),
            category = optNonBlank(obj, "category").ifBlank { "AC" },
            authorName = optNonBlank(obj, "author_name", "authorName"),
            photoUrl = optNonBlank(obj, "photo_url", "photoUrl"),
            createdAt = optTimestamp(obj, "created_at", "createdAt")
        )
    }

    fun toCommunityReport(obj: JSONObject): CommunityReportCloud {
        val rid = optNonBlank(obj, "report_id", "reportId", "id")
        return CommunityReportCloud(
            id = rid,
            reportId = rid,
            postId = optNonBlank(obj, "post_id", "postId"),
            commentId = optNonBlank(obj, "comment_id", "commentId"),
            reporterUid = optNonBlank(obj, "reporter_uid", "reporterUid"),
            reporterName = optNonBlank(obj, "reporter_name", "reporterName"),
            reason = optNonBlank(obj, "reason").ifBlank { "OTHER" },
            details = optNonBlank(obj, "details"),
            status = optNonBlank(obj, "status").ifBlank { "OPEN" },
            adminNote = optNonBlank(obj, "admin_note", "adminNote"),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toVerificationRequest(obj: JSONObject): TechnicianVerificationRequestCloud {
        val uid = optNonBlank(obj, "user_id", "userId", "id")
        return TechnicianVerificationRequestCloud(
            id = uid,
            userId = uid,
            fullName = optNonBlank(obj, "full_name", "fullName"),
            mobileNumber = optNonBlank(obj, "mobile_number", "mobileNumber"),
            fullAddress = optNonBlank(obj, "full_address", "fullAddress"),
            state = optNonBlank(obj, "state"),
            district = optNonBlank(obj, "district"),
            cityArea = optNonBlank(obj, "city_area", "cityArea"),
            pinCode = optNonBlank(obj, "pin_code", "pinCode"),
            serviceCategories = optStringList(obj, "service_categories", "service_categories_json", "serviceCategories"),
            experience = optNonBlank(obj, "experience"),
            bio = optNonBlank(obj, "bio"),
            profilePhotoUrl = optNonBlank(obj, "profile_photo_url", "profilePhotoUrl"),
            profilePhotoStoragePath = optNonBlank(obj, "profile_photo_storage_path", "profilePhotoStoragePath"),
            profilePhotoProviderId = optNonBlank(obj, "profile_photo_provider_id", "profilePhotoProviderId"),
            credentialDocUrl = optNonBlank(obj, "credential_doc_url", "credentialDocUrl"),
            credentialDocStoragePath = optNonBlank(obj, "credential_doc_storage_path", "credentialDocStoragePath"),
            credentialDocProviderId = optNonBlank(obj, "credential_doc_provider_id", "credentialDocProviderId"),
            credentialDocName = optNonBlank(obj, "credential_doc_name", "credentialDocName"),
            status = optNonBlank(obj, "status").ifBlank { "PENDING" },
            rejectionReason = optNonBlank(obj, "rejection_reason", "rejectionReason"),
            reviewedByUid = optNonBlank(obj, "reviewed_by_uid", "reviewedByUid"),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toTechnicalDocument(obj: JSONObject): TechnicalDocumentCloud {
        val did = optNonBlank(obj, "doc_id", "docId", "id")
        return TechnicalDocumentCloud(
            id = did,
            docId = did,
            docType = optNonBlank(obj, "doc_type", "docType").ifBlank { "PDF_MANUAL" },
            categoryId = optNonBlank(obj, "category_id", "categoryId").ifBlank { "ac" },
            brandName = optNonBlank(obj, "brand_name", "brandName"),
            modelName = optNonBlank(obj, "model_name", "modelName"),
            linkedEntryId = optNonBlank(obj, "linked_entry_id", "linkedEntryId"),
            title = optNonBlank(obj, "title"),
            description = optNonBlank(obj, "description"),
            fileUrl = optNonBlank(obj, "file_url", "fileUrl"),
            storagePath = optNonBlank(obj, "storage_path", "storagePath"),
            storageProviderId = optNonBlank(obj, "storage_provider_id", "storageProviderId").ifBlank { "supabase_primary" },
            externalRecordId = optNonBlank(obj, "external_record_id", "externalRecordId"),
            mimeType = optNonBlank(obj, "mime_type", "mimeType").ifBlank { "application/pdf" },
            fileSizeBytes = obj.optLong("file_size_bytes", obj.optLong("fileSizeBytes", 0L)),
            published = obj.optBoolean("published", true),
            offlineAvailable = obj.optBoolean("offline_available", obj.optBoolean("offlineAvailable", true)),
            isDeleted = obj.optBoolean("is_deleted", obj.optBoolean("isDeleted", false)),
            uploadedByUid = optNonBlank(obj, "uploaded_by_uid", "uploadedByUid"),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toUserNotification(obj: JSONObject): UserNotificationCloud {
        val nid = optNonBlank(obj, "notification_id", "notificationId", "id")
        return UserNotificationCloud(
            id = nid,
            notificationId = nid,
            recipientUid = optNonBlank(obj, "recipient_uid", "recipientUid"),
            actorUid = optNonBlank(obj, "actor_uid", "actorUid"),
            type = optNonBlank(obj, "type").ifBlank { "SYSTEM" },
            title = optNonBlank(obj, "title"),
            body = optNonBlank(obj, "body"),
            imageUrl = optNonBlank(obj, "image_url", "imageUrl"),
            targetRoute = optNonBlank(obj, "target_route", "targetRoute"),
            isRead = obj.optBoolean("is_read", obj.optBoolean("isRead", false)),
            createdAt = optTimestamp(obj, "created_at", "createdAt"),
            updatedAt = optTimestamp(obj, "updated_at", "updatedAt")
        )
    }

    fun toAnnouncement(obj: JSONObject): AnnouncementCloud {
        val aid = optNonBlank(obj, "announcement_id", "announcementId", "id")
        return AnnouncementCloud(
            id = aid,
            announcementId = aid,
            title = optNonBlank(obj, "title"),
            body = optNonBlank(obj, "body"),
            category = optNonBlank(obj, "category").ifBlank { "GENERAL" },
            imageUrl = optNonBlank(obj, "image_url", "imageUrl"),
            targetRoute = optNonBlank(obj, "target_route", "targetRoute"),
            createdByUid = optNonBlank(obj, "created_by_uid", "createdByUid"),
            createdAt = optTimestamp(obj, "created_at", "createdAt")
        )
    }

    fun toCommunityRestriction(obj: JSONObject): CommunityUserRestrictionCloud {
        val uid = optNonBlank(obj, "user_id", "userId", "id")
        return CommunityUserRestrictionCloud(
            id = uid,
            userId = uid,
            userName = optNonBlank(obj, "user_name", "userName"),
            reason = optNonBlank(obj, "reason"),
            blockedByUid = optNonBlank(obj, "blocked_by_uid", "blockedByUid"),
            createdAt = optTimestamp(obj, "created_at", "createdAt")
        )
    }
}
