package com.example.data.remote

import com.example.BuildConfig
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class StorageProviderConfig(
    val providerId: String = "supabase_primary",
    val providerName: String = "Supabase Free Plan",
    val providerType: String = TYPE_SUPABASE_STORAGE,
    val endpointUrl: String = SupabaseClient.DEFAULT_SUPABASE_URL,
    val publicAnonKey: String = "",
    val proxyUploadUrl: String = "",
    val hostingVendor: String = "",
    val publicMediaBaseUrl: String = "",
    val communityOnly: Boolean = false,
    val role: String = ROLE_PRIMARY,
    val enabled: Boolean = true,
    val capacityLimitBytes: Long = 1_073_741_824L,
    val usedBytes: Long = 0L,
    val buckets: Map<String, String> = DEFAULT_BUCKETS
) {
    companion object {
        const val TYPE_SUPABASE_STORAGE = "SUPABASE_STORAGE"
        const val TYPE_PHP_HOSTING = "PHP_HOSTING"
        const val TYPE_FIREBASE_LEGACY = "FIREBASE_LEGACY"
        const val TYPE_S3_COMPATIBLE = "S3_COMPATIBLE"
        const val TYPE_CLOUDFLARE_R2 = "CLOUDFLARE_R2"
        const val TYPE_GOOGLE_CLOUD_STORAGE = "GOOGLE_CLOUD_STORAGE"

        const val ROLE_PRIMARY = "PRIMARY"
        const val ROLE_BACKUP = "BACKUP"
        const val ROLE_DISABLED = "DISABLED"

        val DEFAULT_BUCKETS = mapOf(
            "community" to "community-photos",
            "technicians" to "technician-photos",
            "pdfs" to "repair-pdfs",
            "diagrams" to "circuit-diagrams",
            "verification" to "verification-documents"
        )
    }
}

data class StorageRoutingConfig(
    val autoFailoverEnabled: Boolean = true,
    val fcmBackendUrl: String = MultiCloudStorageRouter.resolveEffectiveFcmEndpoint(),
    val hostingProxyUrl: String = MultiCloudStorageRouter.DEFAULT_HOSTING_PROXY_URL,
    val compressionMaxDim: Int = 1440,
    val compressionQuality: Int = 82,
    val compressionMaxSizeKb: Int = 4500,
    val duplicateCheckEnabled: Boolean = true,
    val providers: List<StorageProviderConfig> = listOf(StorageProviderConfig())
)

data class MultiCloudUploadResult(
    val publicUrl: String,
    val storagePath: String,
    val providerId: String,
    val bucketName: String,
    val failoverUsed: Boolean,
    val deduplicated: Boolean = false
)

class MultiCloudStorageRouter(
    private val dbProvider: () -> FirebaseFirestore?,
    private val authProvider: () -> FirebaseAuth?,
    private val storageProvider: () -> FirebaseStorage?,
    private val httpClient: OkHttpClient = SupabaseClient.defaultHttpClient(),
    supabaseClientOverride: SupabaseClient? = null
) {
    private val supabaseClient: SupabaseClient = supabaseClientOverride ?: SupabaseClient(
        httpClient = httpClient,
        firebaseTokenProvider = { forceRefresh ->
            runCatching { authProvider()?.currentUser?.getIdToken(forceRefresh)?.await()?.token }.getOrNull()
        }
    )

    @Volatile
    private var cachedRoutingConfig: StorageRoutingConfig? = null

    suspend fun loadRoutingConfig(): StorageRoutingConfig {
        val db = dbProvider() ?: return cachedRoutingConfig ?: StorageRoutingConfig()
        return try {
            val snap = db.collection("app_settings").document("storage_config").get().await()
            if (!snap.exists()) {
                StorageRoutingConfig()
            } else {
                val parsed = parseRoutingConfig(
                    autoFailoverEnabled = snap.getBoolean("autoFailoverEnabled") ?: true,
                    fcmBackendUrl = snap.getString("fcmBackendUrl").orEmpty(),
                    providersJson = snap.getString("providersJson").orEmpty(),
                    hostingProxyUrl = snap.getString("hostingProxyUrl").orEmpty(),
                    compressionMaxDim = (snap.getLong("compressionMaxDim") ?: 1440L).toInt(),
                    compressionQuality = (snap.getLong("compressionQuality") ?: 82L).toInt(),
                    compressionMaxSizeKb = (snap.getLong("compressionMaxSizeKb") ?: 4500L).toInt(),
                    duplicateCheckEnabled = snap.getBoolean("duplicateCheckEnabled") ?: true
                )
                cachedRoutingConfig = parsed
                parsed
            }
        } catch (_: Exception) {
            cachedRoutingConfig ?: StorageRoutingConfig()
        }
    }

    suspend fun uploadBytes(
        bucketKey: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String,
        onProgress: (Float) -> Unit = {}
    ): Result<MultiCloudUploadResult> {
        val validationError = SupabaseClient.validateBinaryUpload(
            bytes = bytes,
            mimeType = mimeType,
            allowPdf = bucketKey in setOf("pdfs", "diagrams", "verification"),
            maxSizeBytes = when (bucketKey) {
                "pdfs", "diagrams" -> SupabaseClient.MAX_PDF_BYTES
                "verification" -> SupabaseClient.MAX_VERIFICATION_DOC_BYTES
                else -> SupabaseClient.MAX_IMAGE_BYTES
            }
        )
        if (validationError != null) {
            return Result.failure(IllegalArgumentException(validationError))
        }

        val config = loadRoutingConfig()
        val ordered = selectOrderedProvidersForBucket(config, bucketKey)
        if (ordered.isEmpty()) {
            return Result.failure(IllegalStateException("No enabled storage providers configured."))
        }

        var lastError: Throwable? = null
        var failoverUsed = false

        for (index in ordered.indices) {
            val provider = ordered[index]
            val bucketName = resolveBucketName(provider, bucketKey)
            onProgress(0.2f)
            val attempt = uploadToSingleProvider(
                config = config,
                provider = provider,
                bucketKey = bucketKey,
                bucketName = bucketName,
                objectPath = objectPath,
                bytes = bytes,
                mimeType = mimeType,
                onProgress = onProgress
            )
            if (attempt.isSuccess) {
                val uploaded = attempt.getOrThrow()
                onProgress(1f)
                recordUploadHistory(
                    providerId = provider.providerId,
                    bucketName = bucketName,
                    objectPath = objectPath,
                    publicUrl = uploaded.publicUrl,
                    mimeType = mimeType,
                    sizeBytes = bytes.size.toLong(),
                    failoverUsed = failoverUsed,
                    status = "SUCCESS"
                )
                return Result.success(uploaded.copy(failoverUsed = failoverUsed))
            } else {
                lastError = attempt.exceptionOrNull()
                val nextProvider = ordered.getOrNull(index + 1)
                recordStorageError(
                    providerId = provider.providerId,
                    bucketName = bucketName,
                    objectPath = objectPath,
                    errorMessage = lastError?.message ?: "Upload failed",
                    failoverTargetId = nextProvider?.providerId.orEmpty()
                )
                if (nextProvider != null) {
                    failoverUsed = true
                }
            }
        }

        recordUploadHistory(
            providerId = ordered.first().providerId,
            bucketName = resolveBucketName(ordered.first(), bucketKey),
            objectPath = objectPath,
            publicUrl = "",
            mimeType = mimeType,
            sizeBytes = bytes.size.toLong(),
            failoverUsed = failoverUsed,
            status = "FAILED"
        )
        return Result.failure(lastError ?: IllegalStateException("All storage providers failed."))
    }

    suspend fun deleteObject(
        providerId: String = "",
        bucketKey: String = "community",
        storagePath: String = "",
        publicUrl: String = ""
    ): Result<Unit> {
        val cleanPath = storagePath.trim().trimStart('/')
        if (cleanPath.isBlank() && publicUrl.isBlank()) return Result.success(Unit)
        val config = loadRoutingConfig()
        val resolvedProvider = resolveProviderForDelete(config, providerId, publicUrl)
        val bucketName = resolveBucketName(resolvedProvider, bucketKey)

        return when (resolvedProvider.providerType) {
            StorageProviderConfig.TYPE_PHP_HOSTING -> deleteViaPhpHostingProxy(
                config = config,
                provider = resolvedProvider,
                storagePath = cleanPath.ifBlank { extractRelativePathFromUrl(publicUrl, bucketName) }
            )
            StorageProviderConfig.TYPE_FIREBASE_LEGACY -> {
                val storage = runCatching { storageProvider() }.getOrNull() ?: return Result.success(Unit)
                val path = cleanPath.ifBlank { extractRelativePathFromUrl(publicUrl, bucketName) }
                if (path.isBlank()) return Result.success(Unit)
                runCatching {
                    storage.reference.child(path).delete().await()
                    Unit
                }
            }
            else -> {
                val pathInBucket = cleanPath.removePrefix("$bucketName/").trimStart('/')
                    .ifBlank { extractRelativePathFromUrl(publicUrl, bucketName) }
                supabaseClient.deleteObject(
                    bucketName = bucketName,
                    objectPath = pathInBucket,
                    overrideUrl = resolvedProvider.endpointUrl,
                    overrideAnonKey = resolvedProvider.publicAnonKey
                )
            }
        }
    }

    suspend fun getSignedPrivateUrl(
        bucketName: String = "verification-documents",
        storagePath: String,
        expiresInSeconds: Int = 120
    ): Result<String> {
        return supabaseClient.createSignedUrl(
            bucketName = bucketName,
            storagePath = storagePath,
            expiresInSeconds = expiresInSeconds
        )
    }

    suspend fun downloadAuthorizedBytes(url: String): Result<ByteArray> =
        supabaseClient.downloadBytes(url)

    suspend fun syncMyFirebaseClaims(): Boolean = withContext(Dispatchers.IO) {
        val user = authProvider()?.currentUser ?: return@withContext false
        val idToken = runCatching { user.getIdToken(false).await().token }.getOrNull().orEmpty()
        if (idToken.isBlank()) return@withContext false
        val endpoint = "${supabaseClient.resolveUrl()}/functions/v1/admin-user-management"
        val anonKey = supabaseClient.resolveAnonKey()
        val req = Request.Builder()
            .url(endpoint)
            .post(JSONObject().put("action", "sync_my_claims").toString().toRequestBody("application/json".toMediaTypeOrNull()))
            .addHeader("Authorization", "Bearer $idToken")
            .apply { if (anonKey.isNotBlank()) addHeader("apikey", anonKey) }
            .addHeader("Content-Type", "application/json")
            .build()
        val ok = runCatching {
            httpClient.newCall(req).execute().use { resp ->
                resp.isSuccessful
            }
        }.getOrDefault(false)
        if (ok) {
            runCatching { user.getIdToken(true).await() }
        }
        ok
    }

    private suspend fun deleteViaPhpHostingProxy(
        config: StorageRoutingConfig,
        provider: StorageProviderConfig,
        storagePath: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val proxyUrl = provider.proxyUploadUrl.trim()
            .ifBlank { config.hostingProxyUrl.trim() }
            .ifBlank { DEFAULT_HOSTING_PROXY_URL }
        if (!proxyUrl.startsWith("https://", ignoreCase = true) || storagePath.isBlank()) {
            return@withContext Result.success(Unit)
        }
        runCatching {
            val user = authProvider()?.currentUser ?: throw IllegalStateException("Sign in required.")
            var idToken = user.getIdToken(false).await().token.orEmpty()
            val bodyJson = JSONObject()
                .put("action", "delete_file")
                .put("providerId", provider.providerId)
                .put("uploadApiUrl", provider.endpointUrl)
                .put("storagePath", storagePath)
                .toString()

            fun buildReq(token: String) = Request.Builder()
                .url(proxyUrl)
                .post(bodyJson.toRequestBody("application/json".toMediaTypeOrNull()))
                .addHeader("Authorization", "Bearer $token")
                .addHeader("Content-Type", "application/json")
                .build()

            httpClient.newCall(buildReq(idToken)).execute().use { resp ->
                if (resp.code == 401) {
                    resp.close()
                    idToken = user.getIdToken(true).await().token.orEmpty()
                    if (idToken.isNotBlank()) {
                        httpClient.newCall(buildReq(idToken)).execute().use { retryResp ->
                            if (!retryResp.isSuccessful && retryResp.code != 404) {
                                throw IllegalStateException("PHP delete failed HTTP ${retryResp.code}")
                            }
                        }
                    }
                } else if (!resp.isSuccessful && resp.code != 404) {
                    throw IllegalStateException("PHP delete failed HTTP ${resp.code}")
                }
            }
            Unit
        }
    }

    private suspend fun uploadToSingleProvider(
        config: StorageRoutingConfig,
        provider: StorageProviderConfig,
        bucketKey: String,
        bucketName: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String,
        onProgress: (Float) -> Unit
    ): Result<MultiCloudUploadResult> {
        return when (provider.providerType) {
            StorageProviderConfig.TYPE_SUPABASE_STORAGE -> {
                val res = supabaseClient.uploadObject(
                    bucketName = bucketName,
                    objectPath = objectPath,
                    bytes = bytes,
                    mimeType = mimeType,
                    isPublicBucket = bucketKey != "verification",
                    allowUpsert = false,
                    overrideUrl = provider.endpointUrl,
                    overrideAnonKey = provider.publicAnonKey
                )
                res.map {
                    MultiCloudUploadResult(
                        publicUrl = it.publicUrl,
                        storagePath = it.storagePath,
                        providerId = provider.providerId,
                        bucketName = bucketName,
                        failoverUsed = false
                    )
                }
            }

            StorageProviderConfig.TYPE_PHP_HOSTING -> {
                uploadViaPhpHostingProxy(
                    config = config,
                    provider = provider,
                    bucketName = bucketName,
                    objectPath = objectPath,
                    bytes = bytes
                )
            }

            StorageProviderConfig.TYPE_FIREBASE_LEGACY -> {
                val storage = runCatching { storageProvider() }.getOrNull()
                    ?: return Result.failure(IllegalStateException("Firebase Storage is not initialized."))
                val fullPath = "$bucketName/${objectPath.trimStart('/')}"
                runCatching {
                    val ref = storage.reference.child(fullPath)
                    val metadata = StorageMetadata.Builder().setContentType(mimeType).build()
                    val task = ref.putBytes(bytes, metadata)
                    task.addOnProgressListener { snap ->
                        if (snap.totalByteCount > 0) {
                            onProgress((snap.bytesTransferred.toFloat() / snap.totalByteCount.toFloat()).coerceIn(0f, 1f))
                        }
                    }
                    task.await()
                    val url = ref.downloadUrl.await().toString()
                    MultiCloudUploadResult(
                        publicUrl = url,
                        storagePath = fullPath,
                        providerId = provider.providerId,
                        bucketName = bucketName,
                        failoverUsed = false
                    )
                }
            }

            else -> uploadViaSignedProxy(provider, bucketName, objectPath, bytes, mimeType)
        }
    }

    private suspend fun uploadViaPhpHostingProxy(
        config: StorageRoutingConfig,
        provider: StorageProviderConfig,
        bucketName: String,
        objectPath: String,
        bytes: ByteArray
    ): Result<MultiCloudUploadResult> = withContext(Dispatchers.IO) {
        val proxyUrl = provider.proxyUploadUrl.trim()
            .ifBlank { config.hostingProxyUrl.trim() }
            .ifBlank { DEFAULT_HOSTING_PROXY_URL }
        if (!proxyUrl.startsWith("https://", ignoreCase = true)) {
            return@withContext Result.failure(IllegalStateException("PHP Hosting Proxy requires HTTPS."))
        }
        val uploadApiUrl = provider.endpointUrl.trim()
        if (!uploadApiUrl.startsWith("https://", ignoreCase = true)) {
            return@withContext Result.failure(IllegalStateException("${provider.providerName} endpoint URL must use HTTPS."))
        }
        runCatching {
            val user = authProvider()?.currentUser
                ?: throw IllegalStateException("Google sign-in session required for hosting upload.")
            var idToken = user.getIdToken(false).await().token.orEmpty()
            if (idToken.isBlank()) {
                throw IllegalStateException("Google sign-in session required for hosting upload.")
            }
            val encodedBase64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
            val bodyJson = JSONObject()
                .put("action", "upload")
                .put("providerId", provider.providerId)
                .put("uploadApiUrl", uploadApiUrl)
                .put("bucketName", bucketName)
                .put("objectPath", objectPath)
                .put("base64", encodedBase64)
                .toString()

            fun buildReq(token: String) = Request.Builder()
                .url(proxyUrl)
                .post(bodyJson.toRequestBody("application/json".toMediaTypeOrNull()))
                .addHeader("Authorization", "Bearer $token")
                .addHeader("Content-Type", "application/json")
                .build()

            var resp = httpClient.newCall(buildReq(idToken)).execute()
            if (resp.code == 401) {
                resp.close()
                idToken = user.getIdToken(true).await().token.orEmpty()
                resp = httpClient.newCall(buildReq(idToken)).execute()
            }

            resp.use { r ->
                val raw = r.body?.string().orEmpty()
                val parsed = runCatching { JSONObject(raw) }.getOrNull()
                if (!r.isSuccessful || parsed == null || !parsed.optBoolean("ok", false)) {
                    val errMsg = parsed?.optString("message")?.takeIf { it.isNotBlank() }
                        ?: "Hosting proxy HTTP ${r.code}"
                    throw IllegalStateException(errMsg)
                }
                val publicUrl = parsed.optString("publicUrl")
                if (!publicUrl.startsWith("https://")) {
                    throw IllegalStateException("Shared hosting upload returned invalid HTTPS URL.")
                }
                MultiCloudUploadResult(
                    publicUrl = publicUrl,
                    storagePath = parsed.optString("storagePath", "$bucketName/$objectPath"),
                    providerId = provider.providerId,
                    bucketName = bucketName,
                    failoverUsed = false,
                    deduplicated = parsed.optBoolean("deduplicated", false)
                )
            }
        }
    }

    private suspend fun uploadViaSignedProxy(
        provider: StorageProviderConfig,
        bucketName: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String
    ): Result<MultiCloudUploadResult> = withContext(Dispatchers.IO) {
        val proxyUrl = provider.proxyUploadUrl.trim()
        if (!proxyUrl.startsWith("https://", ignoreCase = true)) {
            return@withContext Result.failure(
                IllegalStateException("${provider.providerName} requires a configured HTTPS Signed Upload Proxy URL.")
            )
        }
        runCatching {
            val idToken = runCatching { authProvider()?.currentUser?.getIdToken(false)?.await()?.token }.getOrNull().orEmpty()
            val bodyJson = JSONObject()
                .put("providerId", provider.providerId)
                .put("providerType", provider.providerType)
                .put("bucketName", bucketName)
                .put("objectPath", objectPath)
                .put("contentType", mimeType)
                .put("sizeBytes", bytes.size)

            val signReq = Request.Builder()
                .url(proxyUrl)
                .post(bodyJson.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                .apply {
                    if (idToken.isNotBlank()) addHeader("Authorization", "Bearer $idToken")
                }
                .build()

            val (uploadUrl, publicUrl) = httpClient.newCall(signReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Signed proxy HTTP ${resp.code}")
                }
                val parsed = JSONObject(resp.body?.string().orEmpty())
                val uUrl = parsed.optString("uploadUrl")
                val pUrl = parsed.optString("publicUrl")
                if (uUrl.isBlank() || pUrl.isBlank()) {
                    throw IllegalStateException("Signed upload proxy returned incomplete URLs.")
                }
                uUrl to pUrl
            }

            val putReq = Request.Builder()
                .url(uploadUrl)
                .put(bytes.toRequestBody(mimeType.toMediaTypeOrNull()))
                .build()
            httpClient.newCall(putReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Direct cloud PUT failed HTTP ${resp.code}")
                }
            }
            MultiCloudUploadResult(
                publicUrl = publicUrl,
                storagePath = "$bucketName/${objectPath.trimStart('/')}",
                providerId = provider.providerId,
                bucketName = bucketName,
                failoverUsed = false
            )
        }
    }

    private suspend fun recordUploadHistory(
        providerId: String,
        bucketName: String,
        objectPath: String,
        publicUrl: String,
        mimeType: String,
        sizeBytes: Long,
        failoverUsed: Boolean,
        status: String
    ) {
        val db = dbProvider() ?: return
        val uid = authProvider()?.currentUser?.uid ?: return
        val uploadId = "upl_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val payload = mutableMapOf<String, Any>(
            "uploadId" to uploadId,
            "providerId" to providerId.take(128),
            "bucketName" to bucketName.take(128),
            "objectPath" to objectPath.take(320),
            "mimeType" to mimeType.take(100),
            "sizeBytes" to sizeBytes.coerceAtLeast(0L),
            "failoverUsed" to failoverUsed,
            "status" to if (status == "FAILED") "FAILED" else "SUCCESS",
            "uploadedByUid" to uid,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (publicUrl.startsWith("https://")) {
            payload["publicUrl"] = publicUrl.take(1000)
        }
        runCatching {
            db.collection("storage_upload_history").document(uploadId).set(payload).await()
        }
    }

    private suspend fun recordStorageError(
        providerId: String,
        bucketName: String,
        objectPath: String,
        errorMessage: String,
        failoverTargetId: String
    ) {
        val db = dbProvider() ?: return
        val uid = authProvider()?.currentUser?.uid ?: return
        val errorId = "err_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val payload = mutableMapOf<String, Any>(
            "errorId" to errorId,
            "providerId" to providerId.take(128),
            "bucketName" to bucketName.take(128),
            "objectPath" to objectPath.take(320),
            "errorMessage" to errorMessage.take(600),
            "failoverTargetId" to failoverTargetId.take(128),
            "actorUid" to uid,
            "resolved" to false,
            "createdAt" to FieldValue.serverTimestamp()
        )
        runCatching {
            db.collection("storage_error_logs").document(errorId).set(payload).await()
        }
    }

    companion object {
        const val DEFAULT_HOSTING_PROXY_URL =
            "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/hosting-proxy-upload"

        fun resolveProviderForDelete(
            config: StorageRoutingConfig,
            providerId: String,
            publicUrl: String
        ): StorageProviderConfig {
            if (providerId.isNotBlank()) {
                config.providers.firstOrNull { it.providerId == providerId }?.let { return it }
            }
            val lower = publicUrl.lowercase()
            if (lower.contains("firebasestorage")) {
                return config.providers.firstOrNull { it.providerType == StorageProviderConfig.TYPE_FIREBASE_LEGACY }
                    ?: StorageProviderConfig(providerId = "firebase_legacy", providerType = StorageProviderConfig.TYPE_FIREBASE_LEGACY)
            }
            if (lower.contains(".supabase.co/storage")) {
                return config.providers.firstOrNull { it.providerType == StorageProviderConfig.TYPE_SUPABASE_STORAGE }
                    ?: StorageProviderConfig()
            }
            config.providers.firstOrNull {
                it.providerType == StorageProviderConfig.TYPE_PHP_HOSTING &&
                    (it.publicMediaBaseUrl.isNotBlank() && lower.startsWith(it.publicMediaBaseUrl.lowercase().trimEnd('/')))
            }?.let { return it }
            return config.providers.firstOrNull() ?: StorageProviderConfig()
        }

        fun extractRelativePathFromUrl(publicUrl: String, bucketName: String): String {
            val clean = publicUrl.substringBefore("?").trim()
            val marker = "/$bucketName/"
            val idx = clean.indexOf(marker)
            return if (idx >= 0) clean.substring(idx + marker.length).trimStart('/') else ""
        }

        fun resolveBucketName(provider: StorageProviderConfig, bucketKey: String): String {
            return provider.buckets[bucketKey]
                ?: StorageProviderConfig.DEFAULT_BUCKETS[bucketKey]
                ?: "community-photos"
        }

        fun selectOrderedProviders(config: StorageRoutingConfig): List<StorageProviderConfig> {
            return selectOrderedProvidersForBucket(config, bucketKey = "community")
        }

        fun selectOrderedProvidersForBucket(
            config: StorageRoutingConfig,
            bucketKey: String
        ): List<StorageProviderConfig> {
            val active = config.providers.filter { provider ->
                val enabledAndActive = provider.enabled && provider.role != StorageProviderConfig.ROLE_DISABLED
                val bucketAllowed = when {
                    bucketKey == "verification" && provider.providerType == StorageProviderConfig.TYPE_PHP_HOSTING -> false
                    provider.communityOnly && bucketKey != "community" -> false
                    else -> true
                }
                enabledAndActive && bucketAllowed
            }
            val primary = active.filter { it.role == StorageProviderConfig.ROLE_PRIMARY }
            val backups = active.filter { it.role != StorageProviderConfig.ROLE_PRIMARY }
            val ordered = if (!config.autoFailoverEnabled) {
                (primary.ifEmpty { backups }).take(1)
            } else {
                primary + backups
            }
            return ordered.ifEmpty { listOf(StorageProviderConfig()) }
        }

        fun resolveEffectiveFcmEndpoint(
            configuredRemoteUrl: String = "",
            buildConfigUrl: String = BuildConfig.FCM_BACKEND_ENDPOINT
        ): String {
            val remote = configuredRemoteUrl.trim()
            val buildCfg = buildConfigUrl.trim().takeIf {
                it.startsWith("https://", ignoreCase = true) && !SupabaseClient.isPlaceholderOrBlank(it)
            }.orEmpty()
            if (remote.startsWith("https://", ignoreCase = true) &&
                !SupabaseClient.isPlaceholderOrBlank(remote) &&
                !remote.endsWith("/send-fcm-v1", ignoreCase = true)
            ) {
                return remote
            }
            if (buildCfg.isNotBlank()) return buildCfg
            if (remote.startsWith("https://", ignoreCase = true) && !SupabaseClient.isPlaceholderOrBlank(remote)) {
                return remote
            }
            return SupabaseClient.DEFAULT_FCM_ENDPOINT
        }

        fun parseRoutingConfig(
            autoFailoverEnabled: Boolean,
            fcmBackendUrl: String,
            providersJson: String,
            buildConfigFcmUrl: String = BuildConfig.FCM_BACKEND_ENDPOINT,
            hostingProxyUrl: String = DEFAULT_HOSTING_PROXY_URL,
            compressionMaxDim: Int = 1440,
            compressionQuality: Int = 82,
            compressionMaxSizeKb: Int = 4500,
            duplicateCheckEnabled: Boolean = true
        ): StorageRoutingConfig {
            val providers = runCatching {
                if (providersJson.isBlank()) emptyList()
                else {
                    val arr = JSONArray(providersJson)
                    (0 until arr.length()).mapNotNull { i ->
                        val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                        val bObj = obj.optJSONObject("buckets")
                        val buckets = if (bObj != null) {
                            StorageProviderConfig.DEFAULT_BUCKETS.mapValues { (k, def) ->
                                bObj.optString(k, def).ifBlank { def }
                            }
                        } else {
                            StorageProviderConfig.DEFAULT_BUCKETS
                        }
                        val type = obj.optString("providerType", StorageProviderConfig.TYPE_SUPABASE_STORAGE)
                        StorageProviderConfig(
                            providerId = obj.optString("providerId", "prov_$i").ifBlank { "prov_$i" },
                            providerName = obj.optString("providerName", "Storage Provider"),
                            providerType = type,
                            endpointUrl = obj.optString("endpointUrl", SupabaseClient.DEFAULT_SUPABASE_URL),
                            publicAnonKey = obj.optString("publicAnonKey", ""),
                            proxyUploadUrl = obj.optString("proxyUploadUrl", ""),
                            hostingVendor = obj.optString("hostingVendor", ""),
                            publicMediaBaseUrl = obj.optString("publicMediaBaseUrl", ""),
                            communityOnly = obj.optBoolean("communityOnly", type == StorageProviderConfig.TYPE_PHP_HOSTING),
                            role = obj.optString("role", StorageProviderConfig.ROLE_BACKUP),
                            enabled = obj.optBoolean("enabled", true),
                            capacityLimitBytes = obj.optLong("capacityLimitBytes", 1_073_741_824L),
                            usedBytes = obj.optLong("usedBytes", 0L),
                            buckets = buckets
                        )
                    }
                }
            }.getOrDefault(emptyList())

            val effectiveProxy = hostingProxyUrl.trim()
                .takeIf { it.startsWith("https://", ignoreCase = true) }
                ?: DEFAULT_HOSTING_PROXY_URL

            return StorageRoutingConfig(
                autoFailoverEnabled = autoFailoverEnabled,
                fcmBackendUrl = resolveEffectiveFcmEndpoint(fcmBackendUrl, buildConfigFcmUrl),
                hostingProxyUrl = effectiveProxy,
                compressionMaxDim = compressionMaxDim.coerceIn(480, 4096),
                compressionQuality = compressionQuality.coerceIn(40, 100),
                compressionMaxSizeKb = compressionMaxSizeKb.coerceIn(100, 5120),
                duplicateCheckEnabled = duplicateCheckEnabled,
                providers = providers.ifEmpty { listOf(StorageProviderConfig()) }
            )
        }
    }
}
