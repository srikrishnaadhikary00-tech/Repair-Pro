package com.example.data.remote

import android.util.Base64
import com.example.BuildConfig
import com.example.data.local.StorageConfigCache
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.URLEncoder
import java.util.UUID

data class StorageProviderConfig(
    val providerId: String = "supabase_primary",
    val providerName: String = "Supabase Free Plan",
    val providerType: String = TYPE_SUPABASE_STORAGE,
    val endpointUrl: String = SupabaseClient.DEFAULT_SUPABASE_URL,
    val publicAnonKey: String = "",
    val proxyUploadUrl: String = "",
    val hostingVendor: String = "",
    val publicMediaBaseUrl: String = "",
    val communityOnly: Boolean = false,
    val supportsStorage: Boolean = true,
    val supportsDatabase: Boolean = false,
    val dbEnabled: Boolean = false,
    val dbEngine: String = "MYSQL",
    val role: String = ROLE_PRIMARY,
    val enabled: Boolean = true,
    val capacityLimitBytes: Long = 1_073_741_824L,
    val usedBytes: Long = 0L,
    val buckets: Map<String, String> = DEFAULT_BUCKETS
) {
    companion object {
        const val TYPE_SUPABASE_STORAGE = "SUPABASE_STORAGE"
        const val TYPE_PHP_HOSTING = "PHP_HOSTING"
        const val TYPE_EXTERNAL_DB = "EXTERNAL_DB"
        const val TYPE_FIREBASE_LEGACY = "FIREBASE_LEGACY"
        const val TYPE_S3_COMPATIBLE = "S3_COMPATIBLE"
        const val TYPE_CLOUDFLARE_R2 = "CLOUDFLARE_R2"
        const val TYPE_GOOGLE_CLOUD_STORAGE = "GOOGLE_CLOUD_STORAGE"

        const val ROLE_PRIMARY = "PRIMARY"
        const val ROLE_BACKUP = "BACKUP"
        const val ROLE_DISABLED = "DISABLED"

        val DEFAULT_BUCKETS = mapOf(
            "community" to "community-photos",
            "technicians" to "technician-photos",
            "pdfs" to "repair-pdfs",
            "diagrams" to "circuit-diagrams",
            "verification" to "verification-documents",
            "user_profiles" to "user-avatars"
        )
    }
}

data class StorageRoutingConfig(
    val autoFailoverEnabled: Boolean = true,
    val fcmBackendUrl: String = MultiCloudStorageRouter.resolveEffectiveFcmEndpoint(),
    val hostingProxyUrl: String = MultiCloudStorageRouter.DEFAULT_HOSTING_PROXY_URL,
    val compressionMaxDim: Int = 1440,
    val compressionQuality: Int = 82,
    val compressionMaxSizeKb: Int = 4500,
    val duplicateCheckEnabled: Boolean = true,
    val categoryMappings: Map<String, String> = emptyMap(),
    val providers: List<StorageProviderConfig> = listOf(StorageProviderConfig()),
    val autoMigrationEnabled: Boolean = false,
    val autoCleanupEnabled: Boolean = false,
    val dbMigrationThresholdPct: Int = 80,
    val storageMigrationThresholdPct: Int = 80,
    val primaryDbProviderId: String = "supabase_primary",
    val fallbackDiscoveryUrls: List<String> = emptyList(),
    val configVersion: Long = 1L
)

data class MultiCloudUploadResult(
    val publicUrl: String,
    val storagePath: String,
    val providerId: String,
    val bucketName: String,
    val failoverUsed: Boolean,
    val deduplicated: Boolean = false
)

class MultiCloudStorageRouter(
    private val authProvider: () -> FirebaseAuth?,
    private val httpClient: OkHttpClient = SupabaseClient.defaultHttpClient(),
    supabaseClientOverride: SupabaseClient? = null,
    private val configCache: StorageConfigCache? = null,
    private val allowInsecureLocalhostForTesting: Boolean = false
) {
    val supabaseClient: SupabaseClient = supabaseClientOverride ?: SupabaseClient(
        httpClient = httpClient,
        firebaseTokenProvider = { forceRefresh ->
            runCatching { authProvider()?.currentUser?.getIdToken(forceRefresh)?.await()?.token }.getOrNull()
        }
    )

    @Volatile
    private var cachedRoutingConfig: StorageRoutingConfig? = null

    private val _cloudAvailabilityNotice = MutableStateFlow<String?>(null)
    val cloudAvailabilityNotice: StateFlow<String?> = _cloudAvailabilityNotice.asStateFlow()

    private fun isAllowedEndpointUrl(url: String): Boolean {
        val trimmed = url.trim()
        if (trimmed.startsWith("https://", ignoreCase = true)) return true
        if (allowInsecureLocalhostForTesting &&
            (trimmed.startsWith("http://127.0.0.1", ignoreCase = true) ||
                trimmed.startsWith("http://localhost", ignoreCase = true))
        ) {
            return true
        }
        return false
    }

    private suspend fun getFirebaseBearerToken(forceRefresh: Boolean = false): String? {
        supabaseClient.getFirebaseIdToken(forceRefresh)?.let { return it }
        return runCatching {
            authProvider()?.currentUser?.getIdToken(forceRefresh)?.await()?.token?.trim()?.takeIf { it.isNotEmpty() }
        }.getOrNull()
    }

    suspend fun loadRoutingConfig(forceRefresh: Boolean = false): StorageRoutingConfig {
        val bootstrapSnapshot = if (cachedRoutingConfig == null) {
            configCache?.getCachedStorageConfigSnapshot()?.also { cachedRoutingConfig = it }
        } else null

        if (!forceRefresh && cachedRoutingConfig != null) {
            // Still try live refresh when called normally, falling back to cache on error.
        }

        // 1. Primary config source: Supabase app_settings + storage_providers
        val supabaseAttempt = runCatching {
            val settingsRes = supabaseClient.selectRows(
                tableName = "app_settings",
                queryParams = "setting_id=in.(storage_config,migration_config)&select=setting_id,payload",
                requireAuth = false
            )
            val providersRes = supabaseClient.selectRows(
                tableName = "storage_providers",
                queryParams = "select=*&order=created_at.asc",
                requireAuth = false
            )
            val settingsRows = settingsRes.getOrThrow()
            var storagePayload = JSONObject()
            var migrationPayload = JSONObject()
            for (i in 0 until settingsRows.length()) {
                val r = settingsRows.optJSONObject(i) ?: continue
                when (r.optString("setting_id")) {
                    "storage_config" -> storagePayload = r.optJSONObject("payload") ?: JSONObject()
                    "migration_config" -> migrationPayload = r.optJSONObject("payload") ?: JSONObject()
                }
            }

            val dbProvidersArr = providersRes.getOrNull()
            var providersJson = storagePayload.opt("providers")?.takeIf { it is JSONArray }?.toString()
                ?: storagePayload.optString("providersJson").orEmpty()
            if (dbProvidersArr != null && dbProvidersArr.length() > 0) {
                // Prefer storage_providers table when it contains rows (keeps capacity/db flags synced)
                val dbJson = convertDbProviderRowsToJson(dbProvidersArr)
                if (dbJson.isNotBlank() && dbJson != "[]") {
                    providersJson = dbJson
                }
            }

            val catMapJson = storagePayload.optJSONObject("categoryMappings")?.toString()
                ?: extractCategoryMappingsFromProviders(dbProvidersArr)
            val discoveryUrls = parseDiscoveryUrlList(
                migrationPayload.optJSONArray("fallbackDiscoveryUrls")
                    ?: storagePayload.optJSONArray("fallbackDiscoveryUrls")
            )

            parseRoutingConfig(
                autoFailoverEnabled = storagePayload.optBoolean(
                    "autoFailoverEnabled",
                    migrationPayload.optBoolean("autoFailoverEnabled", true)
                ),
                fcmBackendUrl = storagePayload.optString("fcmBackendUrl", ""),
                providersJson = providersJson,
                hostingProxyUrl = storagePayload.optString("hostingProxyUrl", ""),
                compressionMaxDim = storagePayload.optInt("compressionMaxDim", 1440),
                compressionQuality = storagePayload.optInt("compressionQuality", 82),
                compressionMaxSizeKb = storagePayload.optInt("compressionMaxSizeKb", 4500),
                duplicateCheckEnabled = storagePayload.optBoolean("duplicateCheckEnabled", true),
                categoryMappingsJson = catMapJson,
                autoMigrationEnabled = migrationPayload.optBoolean(
                    "autoMigrationEnabled",
                    storagePayload.optBoolean("autoMigrationEnabled", false)
                ),
                autoCleanupEnabled = migrationPayload.optBoolean(
                    "autoCleanupEnabled",
                    storagePayload.optBoolean("autoCleanupEnabled", false)
                ),
                dbMigrationThresholdPct = migrationPayload.optInt(
                    "dbMigrationThresholdPct",
                    storagePayload.optInt("dbMigrationThresholdPct", 80)
                ),
                storageMigrationThresholdPct = migrationPayload.optInt(
                    "storageMigrationThresholdPct",
                    storagePayload.optInt("storageMigrationThresholdPct", 80)
                ),
                primaryDbProviderId = storagePayload.optString("primaryDbProviderId", "")
                    .ifBlank { migrationPayload.optString("primaryDbProviderId", "supabase_primary") },
                fallbackDiscoveryUrls = discoveryUrls,
                configVersion = maxOf(
                    migrationPayload.optLong("configVersion", 1L),
                    storagePayload.optLong("configVersion", 1L)
                )
            )
        }

        supabaseAttempt.getOrNull()?.let { parsed ->
            cachedRoutingConfig = parsed
            runCatching { configCache?.saveStorageConfig(parsed) }
            return parsed
        }

        // 2. Fallback config discovery from configured/cached cPanel endpoints when Supabase is unreachable/paused
        val seedForDiscovery = cachedRoutingConfig ?: bootstrapSnapshot ?: StorageRoutingConfig()
        val candidateUrls = buildList {
            seedForDiscovery.fallbackDiscoveryUrls.forEach { add(it) }
            seedForDiscovery.providers
                .filter { it.enabled && it.providerType == StorageProviderConfig.TYPE_PHP_HOSTING && isAllowedEndpointUrl(it.endpointUrl) }
                .forEach { add(it.endpointUrl) }
        }.distinct()

        for (discoveryBase in candidateUrls) {
            val discovered = fetchDiscoveryConfigFromPhpHost(discoveryBase).getOrNull()
            if (discovered != null) {
                cachedRoutingConfig = discovered
                runCatching { configCache?.saveStorageConfig(discovered) }
                return discovered
            }
        }

        return cachedRoutingConfig ?: bootstrapSnapshot ?: StorageRoutingConfig()
    }

    private suspend fun fetchDiscoveryConfigFromPhpHost(baseEndpoint: String): Result<StorageRoutingConfig> =
        withContext(Dispatchers.IO) {
            if (!isAllowedEndpointUrl(baseEndpoint)) {
                return@withContext Result.failure(IllegalArgumentException("Unsupported discovery endpoint URL."))
            }
            runCatching {
                val url = buildPhpActionUrl(baseEndpoint, "public_config_discovery")
                val req = Request.Builder().url(url).get().build()
                httpClient.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    val parsed = JSONObject(raw)
                    if (!resp.isSuccessful || !parsed.optBoolean("ok", false)) {
                        throw IllegalStateException("Discovery HTTP ${resp.code}")
                    }
                    val cfg = parsed.optJSONObject("config") ?: throw IllegalStateException("Empty discovery manifest.")
                    val providersJson = cfg.opt("providers")?.takeIf { it is JSONArray }?.toString()
                        ?: cfg.optString("providersJson").orEmpty()
                    val catMapJson = cfg.optJSONObject("categoryMappings")?.toString().orEmpty()
                    val urls = parseDiscoveryUrlList(cfg.optJSONArray("fallbackDiscoveryUrls")).toMutableList()
                    if (baseEndpoint !in urls) urls.add(baseEndpoint)
                    parseRoutingConfig(
                        autoFailoverEnabled = cfg.optBoolean("autoFailoverEnabled", true),
                        fcmBackendUrl = cfg.optString("fcmBackendUrl", ""),
                        providersJson = providersJson,
                        hostingProxyUrl = cfg.optString("hostingProxyUrl", ""),
                        compressionMaxDim = cfg.optInt("compressionMaxDim", 1440),
                        compressionQuality = cfg.optInt("compressionQuality", 82),
                        compressionMaxSizeKb = cfg.optInt("compressionMaxSizeKb", 4500),
                        duplicateCheckEnabled = cfg.optBoolean("duplicateCheckEnabled", true),
                        categoryMappingsJson = catMapJson,
                        autoMigrationEnabled = cfg.optBoolean("autoMigrationEnabled", false),
                        autoCleanupEnabled = cfg.optBoolean("autoCleanupEnabled", false),
                        dbMigrationThresholdPct = cfg.optInt("dbMigrationThresholdPct", 80),
                        storageMigrationThresholdPct = cfg.optInt("storageMigrationThresholdPct", 80),
                        primaryDbProviderId = cfg.optString("primaryDbProviderId", "supabase_primary"),
                        fallbackDiscoveryUrls = urls,
                        configVersion = cfg.optLong("configVersion", 1L)
                    )
                }
            }
        }

    private fun parseDiscoveryUrlList(arr: JSONArray?): List<String> {
        if (arr == null || arr.length() == 0) return emptyList()
        val out = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val u = arr.optString(i, "").trim()
            if (isAllowedEndpointUrl(u)) out.add(u)
        }
        return out.distinct()
    }

    private fun extractCategoryMappingsFromProviders(rows: JSONArray?): String {
        if (rows == null || rows.length() == 0) return ""
        val firstObj = rows.optJSONObject(0) ?: return ""
        return firstObj.optJSONObject("category_mappings")?.toString().orEmpty()
    }

    private fun convertDbProviderRowsToJson(rows: JSONArray): String {
        val out = JSONArray()
        for (i in 0 until rows.length()) {
            val r = rows.optJSONObject(i) ?: continue
            val meta = r.optJSONObject("provider_metadata") ?: JSONObject()
            val buckets = JSONObject()
                .put("community", r.optString("bucket_community", "community-photos"))
                .put("technicians", r.optString("bucket_technicians", "technician-photos"))
                .put("pdfs", r.optString("bucket_pdfs", "repair-pdfs"))
                .put("diagrams", r.optString("bucket_diagrams", "circuit-diagrams"))
                .put("verification", r.optString("bucket_verification", "verification-documents"))
                .put("user_profiles", r.optString("bucket_user_profiles", "user-avatars"))
            out.put(
                JSONObject()
                    .put("providerId", r.optString("provider_id", "prov_$i"))
                    .put("providerName", r.optString("provider_name", "Storage Provider"))
                    .put("providerType", r.optString("provider_type", StorageProviderConfig.TYPE_SUPABASE_STORAGE))
                    .put("endpointUrl", meta.optString("uploadApiUrl").ifBlank { r.optString("endpoint_url", SupabaseClient.DEFAULT_SUPABASE_URL) })
                    .put("publicAnonKey", r.optString("public_anon_key", ""))
                    .put("proxyUploadUrl", r.optString("proxy_upload_url", ""))
                    .put("hostingVendor", r.optString("hosting_vendor", ""))
                    .put("publicMediaBaseUrl", r.optString("public_media_base_url", ""))
                    .put("communityOnly", r.optBoolean("community_only", false))
                    .put("supportsStorage", r.optBoolean("supports_storage", true))
                    .put("supportsDatabase", r.optBoolean("supports_database", false))
                    .put("dbEnabled", r.optBoolean("db_enabled", false))
                    .put("dbEngine", r.optString("db_engine", "MYSQL"))
                    .put("role", r.optString("role", StorageProviderConfig.ROLE_BACKUP))
                    .put("enabled", r.optBoolean("enabled", true))
                    .put("capacityLimitBytes", r.optLong("capacity_limit_bytes", 1_073_741_824L))
                    .put("usedBytes", r.optLong("used_bytes", 0L))
                    .put("buckets", buckets)
            )
        }
        return out.toString()
    }

    fun isPrimaryDatabaseSupabase(config: StorageRoutingConfig): Boolean {
        val extPrimary = config.providers.any {
            it.enabled && it.role == StorageProviderConfig.ROLE_PRIMARY &&
                it.supportsDatabase && it.dbEnabled &&
                (it.providerType == StorageProviderConfig.TYPE_PHP_HOSTING || it.providerType == StorageProviderConfig.TYPE_EXTERNAL_DB)
        }
        return config.primaryDbProviderId == "supabase_primary" && !extPrimary
    }

    suspend fun resolveActiveExternalDbProvider(categoryKey: String = "community"): StorageProviderConfig? {
        val config = loadRoutingConfig()
        val mappedId = config.categoryMappings[categoryKey]?.trim().orEmpty()
        if (mappedId.isNotEmpty()) {
            val mapped = config.providers.firstOrNull {
                it.providerId == mappedId && it.enabled && it.role != StorageProviderConfig.ROLE_DISABLED &&
                    it.supportsDatabase && it.dbEnabled &&
                    (it.providerType == StorageProviderConfig.TYPE_PHP_HOSTING || it.providerType == StorageProviderConfig.TYPE_EXTERNAL_DB)
            }
            if (mapped != null) return mapped
        }
        return config.providers.firstOrNull {
            it.enabled && it.role == StorageProviderConfig.ROLE_PRIMARY &&
                it.supportsDatabase && it.dbEnabled &&
                (it.providerType == StorageProviderConfig.TYPE_PHP_HOSTING || it.providerType == StorageProviderConfig.TYPE_EXTERNAL_DB)
        }
    }

    /**
     * Resolves enabled external DB providers for automatic failover writes even when Supabase is currently PRIMARY
     * and cPanel is configured as BACKUP.
     */
    suspend fun resolveFailoverExternalDbProviders(categoryKey: String = "community"): List<StorageProviderConfig> {
        val config = loadRoutingConfig()
        val eligible = config.providers.filter {
            it.enabled &&
                it.role != StorageProviderConfig.ROLE_DISABLED &&
                it.supportsDatabase &&
                it.dbEnabled &&
                (it.providerType == StorageProviderConfig.TYPE_PHP_HOSTING || it.providerType == StorageProviderConfig.TYPE_EXTERNAL_DB) &&
                (!it.communityOnly || categoryKey == "community")
        }
        val mappedId = config.categoryMappings[categoryKey]?.trim().orEmpty()
        val mapped = eligible.filter { it.providerId == mappedId }
        val primary = eligible.filter { it.role == StorageProviderConfig.ROLE_PRIMARY && it.providerId != mappedId }
        val backups = eligible.filter { it.role != StorageProviderConfig.ROLE_PRIMARY && it.providerId != mappedId }
        return (mapped + primary + backups).distinctBy { it.providerId }
    }

    /**
     * Resolves all readable external DB providers so old Supabase data + migrated/failover cPanel data merge seamlessly.
     */
    suspend fun resolveAllReadableExternalDbProviders(categoryKey: String = "community"): List<StorageProviderConfig> {
        return resolveFailoverExternalDbProviders(categoryKey)
    }

    suspend fun externalDbQuery(
        provider: StorageProviderConfig,
        table: String,
        filters: Map<String, Any> = emptyMap(),
        limit: Int = 80,
        search: String = "",
        orderBy: String = "created_at",
        orderDir: String = "DESC"
    ): Result<JSONArray> {
        val body = JSONObject()
            .put("table", table)
            .put("limit", limit)
            .put("filters", JSONObject(filters))
            .put("orderBy", orderBy)
            .put("orderDir", orderDir)
        if (search.isNotBlank()) body.put("search", search)

        val direct = callDirectPhpJson(
            endpointUrl = provider.endpointUrl,
            action = "db_query",
            payload = body,
            requireAuth = true
        )
        if (direct.isSuccess) {
            return direct.map { it.optJSONArray("rows") ?: JSONArray() }
        }
        val err = direct.exceptionOrNull()
        val proxyUrl = provider.proxyUploadUrl.trim()
        if (isAuthSecretFallbackCandidate(err) && isAllowedEndpointUrl(proxyUrl)) {
            val proxyPayload = JSONObject(body.toString())
                .put("action", "db_query")
                .put("providerId", provider.providerId)
                .put("uploadApiUrl", provider.endpointUrl)
            return supabaseClient.invokeEdgeFunction(proxyUrl, proxyPayload, requireAuth = false)
                .map { it.optJSONArray("rows") ?: JSONArray() }
        }
        return Result.failure(err ?: IllegalStateException("External DB query failed."))
    }

    suspend fun externalDbUpsert(
        provider: StorageProviderConfig,
        table: String,
        record: JSONObject
    ): Result<String> {
        val body = JSONObject()
            .put("table", table)
            .put("record", record)

        val direct = callDirectPhpJson(
            endpointUrl = provider.endpointUrl,
            action = "db_upsert",
            payload = body,
            requireAuth = true
        )
        if (direct.isSuccess) {
            return direct.map { it.optString("recordId") }
        }
        val err = direct.exceptionOrNull()
        val proxyUrl = provider.proxyUploadUrl.trim()
        if (isAuthSecretFallbackCandidate(err) && isAllowedEndpointUrl(proxyUrl)) {
            val proxyPayload = JSONObject()
                .put("action", "db_upsert")
                .put("providerId", provider.providerId)
                .put("uploadApiUrl", provider.endpointUrl)
                .put("table", table)
                .put("record", record)
            return supabaseClient.invokeEdgeFunction(proxyUrl, proxyPayload, requireAuth = true)
                .map { it.optString("recordId") }
        }
        return Result.failure(err ?: IllegalStateException("External DB upsert failed."))
    }

    suspend fun externalDbUpdate(
        provider: StorageProviderConfig,
        table: String,
        recordId: String,
        record: JSONObject
    ): Result<Unit> {
        val body = JSONObject()
            .put("table", table)
            .put("recordId", recordId)
            .put("record", record)

        val direct = callDirectPhpJson(
            endpointUrl = provider.endpointUrl,
            action = "db_update",
            payload = body,
            requireAuth = true
        )
        if (direct.isSuccess) return Result.success(Unit)
        val err = direct.exceptionOrNull()
        val proxyUrl = provider.proxyUploadUrl.trim()
        if (isAuthSecretFallbackCandidate(err) && isAllowedEndpointUrl(proxyUrl)) {
            val proxyPayload = JSONObject()
                .put("action", "db_update")
                .put("providerId", provider.providerId)
                .put("uploadApiUrl", provider.endpointUrl)
                .put("table", table)
                .put("recordId", recordId)
                .put("record", record)
            return supabaseClient.invokeEdgeFunction(proxyUrl, proxyPayload, requireAuth = true).map { Unit }
        }
        return Result.failure(err ?: IllegalStateException("External DB update failed."))
    }

    suspend fun externalDbDelete(
        provider: StorageProviderConfig,
        table: String,
        recordId: String
    ): Result<Unit> {
        val body = JSONObject()
            .put("table", table)
            .put("recordId", recordId)

        val direct = callDirectPhpJson(
            endpointUrl = provider.endpointUrl,
            action = "db_delete",
            payload = body,
            requireAuth = true
        )
        if (direct.isSuccess) return Result.success(Unit)
        val err = direct.exceptionOrNull()
        val proxyUrl = provider.proxyUploadUrl.trim()
        if (isAuthSecretFallbackCandidate(err) && isAllowedEndpointUrl(proxyUrl)) {
            val proxyPayload = JSONObject()
                .put("action", "db_delete")
                .put("providerId", provider.providerId)
                .put("uploadApiUrl", provider.endpointUrl)
                .put("table", table)
                .put("recordId", recordId)
            return supabaseClient.invokeEdgeFunction(proxyUrl, proxyPayload, requireAuth = true).map { Unit }
        }
        return Result.failure(err ?: IllegalStateException("External DB delete failed."))
    }

    suspend fun readMergedRows(
        tableName: String,
        categoryKey: String = "community",
        supabaseQueryParams: String,
        supabaseRequireAuth: Boolean,
        extFilters: Map<String, Any> = emptyMap(),
        extLimit: Int = 200,
        extOrderBy: String = "created_at",
        extOrderDir: String = "DESC",
        pkColumns: List<String> = listOf("id")
    ): Result<JSONArray> {
        val supaRes = supabaseClient.selectRows(
            tableName = tableName,
            queryParams = supabaseQueryParams,
            requireAuth = supabaseRequireAuth
        )
        val extProviders = runCatching { resolveAllReadableExternalDbProviders(categoryKey) }.getOrDefault(emptyList())
        var anySuccess = supaRes.isSuccess
        var firstExtError: Throwable? = null
        val collected = mutableListOf<JSONObject>()

        supaRes.getOrNull()?.let { arr ->
            for (i in 0 until arr.length()) {
                arr.optJSONObject(i)?.let { collected.add(it) }
            }
        }

        val failedSources = mutableListOf<String>()
        if (supaRes.isFailure && extProviders.isNotEmpty()) {
            failedSources.add("Supabase Primary")
        }

        for (prov in extProviders) {
            val extRes = externalDbQuery(
                provider = prov,
                table = tableName,
                filters = extFilters,
                limit = extLimit,
                orderBy = extOrderBy,
                orderDir = extOrderDir
            )
            if (extRes.isSuccess) {
                anySuccess = true
                val extArr = extRes.getOrNull() ?: JSONArray()
                for (i in 0 until extArr.length()) {
                    extArr.optJSONObject(i)?.let { row ->
                        if (row.optString("storage_provider_id").isBlank()) {
                            row.put("storage_provider_id", prov.providerId)
                        }
                        collected.add(row)
                    }
                }
            } else {
                failedSources.add(prov.providerName.ifBlank { prov.providerId })
                if (firstExtError == null) {
                    firstExtError = extRes.exceptionOrNull()
                }
            }
        }

        if (!anySuccess) {
            return Result.failure(supaRes.exceptionOrNull() ?: firstExtError ?: IllegalStateException("Cloud database unreachable."))
        }

        _cloudAvailabilityNotice.value = if (failedSources.isNotEmpty()) {
            "Showing available records. Data only stored on ${failedSources.distinct().joinToString(", ")} is temporarily unavailable."
        } else {
            null
        }

        val deduped = LinkedHashMap<String, JSONObject>()
        var anonymousCounter = 0
        for (row in collected) {
            val pk = pkColumns.firstNotNullOfOrNull { col ->
                row.optString(col, "").trim().takeIf { it.isNotEmpty() && !it.equals("null", ignoreCase = true) }
            } ?: "anon_${anonymousCounter++}"
            val existing = deduped[pk]
            if (existing == null) {
                deduped[pk] = row
            } else {
                val existingTs = rowTimestampMillis(existing)
                val nextTs = rowTimestampMillis(row)
                if (nextTs > existingTs) {
                    deduped[pk] = row
                }
            }
        }
        val out = JSONArray()
        deduped.values.forEach { out.put(it) }
        return Result.success(out)
    }

    private fun rowTimestampMillis(obj: JSONObject): Long {
        val updated = obj.optString("updated_at", "").ifBlank { obj.optString("updatedAt", "") }
        val created = obj.optString("created_at", "").ifBlank { obj.optString("createdAt", "") }
        val saved = obj.optString("saved_at", "")
        return CloudTimestamp.parseIso(updated)?.toDate()?.time
            ?: CloudTimestamp.parseIso(saved)?.toDate()?.time
            ?: CloudTimestamp.parseIso(created)?.toDate()?.time
            ?: 0L
    }

    suspend fun writeRowWithFailover(
        tableName: String,
        categoryKey: String = "community",
        payload: JSONObject,
        onConflict: String? = null,
        mirrorIfActiveExternal: Boolean = false
    ): Result<String> {
        val config = loadRoutingConfig()
        val supabasePrimary = isPrimaryDatabaseSupabase(config)

        suspend fun tryExternalProviders(): Pair<String?, Throwable?> {
            val providers = resolveFailoverExternalDbProviders(categoryKey)
            var lastErr: Throwable? = null
            for (prov in providers) {
                val extPayload = JSONObject(payload.toString())
                    .put("storage_provider_id", prov.providerId)
                val res = externalDbUpsert(prov, tableName, extPayload)
                if (res.isSuccess) {
                    return prov.providerId to null
                }
                lastErr = res.exceptionOrNull()
            }
            return null to lastErr
        }

        suspend fun trySupabase(): Result<Unit> {
            return if (onConflict != null) {
                supabaseClient.upsertTableRow(tableName, payload, onConflict = onConflict)
            } else {
                supabaseClient.insertRow(tableName, payload, requireAuth = true)
            }
        }

        return if (supabasePrimary) {
            val supaRes = trySupabase()
            if (supaRes.isSuccess) {
                if (mirrorIfActiveExternal) {
                    val activeExt = runCatching { resolveActiveExternalDbProvider(categoryKey) }.getOrNull()
                    if (activeExt != null) {
                        val extPayload = JSONObject(payload.toString()).put("storage_provider_id", activeExt.providerId)
                        runCatching { externalDbUpsert(activeExt, tableName, extPayload) }
                    }
                }
                Result.success("supabase_primary")
            } else {
                val err = supaRes.exceptionOrNull()
                if (isSupabaseQuotaOrOutageFailure(err)) {
                    val (extProvId, _) = tryExternalProviders()
                    if (extProvId != null) {
                        return Result.success(extProvId)
                    }
                }
                Result.failure(err ?: IllegalStateException("Failed to save record in $tableName."))
            }
        } else {
            val (extProvId, extErr) = tryExternalProviders()
            if (extProvId != null) {
                Result.success(extProvId)
            } else {
                val supaFallback = trySupabase()
                if (supaFallback.isSuccess) Result.success("supabase_primary")
                else Result.failure(extErr ?: supaFallback.exceptionOrNull() ?: IllegalStateException("External and primary DB write failed."))
            }
        }
    }

    suspend fun patchRowWithFailover(
        tableName: String,
        categoryKey: String = "community",
        recordId: String,
        supabaseFilterQuery: String,
        patchJson: JSONObject
    ): Result<Unit> {
        val config = loadRoutingConfig()
        val supabasePrimary = isPrimaryDatabaseSupabase(config)
        val extProviders = runCatching { resolveFailoverExternalDbProviders(categoryKey) }.getOrDefault(emptyList())

        suspend fun tryExternalUpdates(): Pair<Boolean, Throwable?> {
            var anyOk = false
            var lastErr: Throwable? = null
            for (prov in extProviders) {
                val res = externalDbUpdate(prov, tableName, recordId, patchJson)
                if (res.isSuccess) anyOk = true else lastErr = res.exceptionOrNull()
            }
            return anyOk to lastErr
        }

        return if (supabasePrimary) {
            val supaRes = supabaseClient.patchRows(tableName, supabaseFilterQuery, patchJson, requireAuth = true)
            val (extOk, _) = tryExternalUpdates()
            if (supaRes.isSuccess) {
                Result.success(Unit)
            } else {
                val err = supaRes.exceptionOrNull()
                if (extOk && isSupabaseQuotaOrOutageFailure(err)) {
                    Result.success(Unit)
                } else {
                    Result.failure(err ?: IllegalStateException("Update failed for $tableName/$recordId."))
                }
            }
        } else {
            val (extOk, extErr) = tryExternalUpdates()
            if (extOk) {
                runCatching { supabaseClient.patchRows(tableName, supabaseFilterQuery, patchJson, requireAuth = true) }
                Result.success(Unit)
            } else {
                val supaRes = supabaseClient.patchRows(tableName, supabaseFilterQuery, patchJson, requireAuth = true)
                if (supaRes.isSuccess) Result.success(Unit)
                else Result.failure(extErr ?: supaRes.exceptionOrNull() ?: IllegalStateException("Update failed."))
            }
        }
    }

    suspend fun deleteRowWithFailover(
        tableName: String,
        categoryKey: String = "community",
        recordId: String,
        supabaseFilterQuery: String
    ): Result<Unit> {
        val config = loadRoutingConfig()
        val supabasePrimary = isPrimaryDatabaseSupabase(config)
        val extProviders = runCatching { resolveFailoverExternalDbProviders(categoryKey) }.getOrDefault(emptyList())

        suspend fun tryExternalDeletes(): Pair<Boolean, Throwable?> {
            var anyOk = false
            var lastErr: Throwable? = null
            for (prov in extProviders) {
                val res = externalDbDelete(prov, tableName, recordId)
                if (res.isSuccess) anyOk = true else lastErr = res.exceptionOrNull()
            }
            return anyOk to lastErr
        }

        return if (supabasePrimary) {
            val supaRes = supabaseClient.deleteRows(tableName, supabaseFilterQuery, requireAuth = true)
            val (extOk, _) = tryExternalDeletes()
            if (supaRes.isSuccess) {
                Result.success(Unit)
            } else {
                val err = supaRes.exceptionOrNull()
                if (extOk && isSupabaseQuotaOrOutageFailure(err)) {
                    Result.success(Unit)
                } else {
                    Result.failure(err ?: IllegalStateException("Delete failed for $tableName/$recordId."))
                }
            }
        } else {
            val (extOk, extErr) = tryExternalDeletes()
            if (extOk) {
                runCatching { supabaseClient.deleteRows(tableName, supabaseFilterQuery, requireAuth = true) }
                Result.success(Unit)
            } else {
                val supaRes = supabaseClient.deleteRows(tableName, supabaseFilterQuery, requireAuth = true)
                if (supaRes.isSuccess) Result.success(Unit)
                else Result.failure(extErr ?: supaRes.exceptionOrNull() ?: IllegalStateException("Delete failed."))
            }
        }
    }

    private fun isAuthSecretFallbackCandidate(error: Throwable?): Boolean {
        val msg = error?.message.orEmpty().lowercase()
        return msg.contains("api_secret") || msg.contains("unauthorized") || msg.contains("http 401")
    }

    private suspend fun callDirectPhpJson(
        endpointUrl: String,
        action: String,
        payload: JSONObject,
        requireAuth: Boolean = true
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        if (!isAllowedEndpointUrl(endpointUrl)) {
            return@withContext Result.failure(IllegalStateException("Hosting endpoint URL must use HTTPS."))
        }
        runCatching {
            val targetUrl = buildPhpActionUrl(endpointUrl, action)
            var bearer = getFirebaseBearerToken(false).orEmpty()
            if (requireAuth && bearer.isBlank()) {
                throw IllegalStateException("Sign in with Google required for cPanel access.")
            }
            val jsonStr = JSONObject(payload.toString()).put("action", action).toString()

            fun buildReq(token: String) = Request.Builder()
                .url(targetUrl)
                .post(jsonStr.toRequestBody("application/json".toMediaTypeOrNull()))
                .apply {
                    if (token.isNotBlank()) addHeader("Authorization", "Bearer $token")
                }
                .addHeader("Content-Type", "application/json")
                .build()

            var resp = httpClient.newCall(buildReq(bearer)).execute()
            if (resp.code == 401 && requireAuth) {
                resp.close()
                val refreshed = getFirebaseBearerToken(true).orEmpty()
                if (refreshed.isNotBlank()) {
                    bearer = refreshed
                    resp = httpClient.newCall(buildReq(bearer)).execute()
                }
            }
            resp.use { r ->
                val raw = r.body?.string().orEmpty()
                val parsed = runCatching { JSONObject(raw) }.getOrNull()
                if (!r.isSuccessful || parsed == null || !parsed.optBoolean("ok", false)) {
                    val code = parsed?.optString("errorCode").orEmpty()
                    val msg = parsed?.optString("message")?.takeIf { it.isNotBlank() }
                        ?: "cPanel HTTP ${r.code}: ${raw.take(180)}"
                    throw IllegalStateException(if (code.isNotBlank()) "$code: $msg" else msg)
                }
                parsed
            }
        }
    }

    suspend fun uploadBytes(
        bucketKey: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String,
        allowUpsert: Boolean = false,
        onProgress: (Float) -> Unit = {}
    ): Result<MultiCloudUploadResult> {
        val validationError = SupabaseClient.validateBinaryUpload(
            bytes = bytes,
            mimeType = mimeType,
            allowPdf = bucketKey in setOf("pdfs", "diagrams", "verification"),
            maxSizeBytes = when (bucketKey) {
                "pdfs", "diagrams" -> SupabaseClient.MAX_PDF_BYTES
                "verification" -> SupabaseClient.MAX_VERIFICATION_DOC_BYTES
                else -> SupabaseClient.MAX_IMAGE_BYTES
            }
        )
        if (validationError != null) {
            return Result.failure(IllegalArgumentException(validationError))
        }

        val config = loadRoutingConfig()
        val ordered = selectOrderedProvidersForBucket(config, bucketKey)
        if (ordered.isEmpty()) {
            return Result.failure(IllegalStateException("No enabled storage providers configured."))
        }

        var lastError: Throwable? = null
        var failoverUsed = false

        for (index in ordered.indices) {
            val provider = ordered[index]
            val bucketName = resolveBucketName(provider, bucketKey)
            onProgress(0.2f)
            val attempt = uploadToSingleProvider(
                config = config,
                provider = provider,
                bucketKey = bucketKey,
                bucketName = bucketName,
                objectPath = objectPath,
                bytes = bytes,
                mimeType = mimeType,
                allowUpsert = allowUpsert,
                onProgress = onProgress
            )
            if (attempt.isSuccess) {
                val uploaded = attempt.getOrThrow()
                onProgress(1f)
                recordUploadHistory(
                    providerId = provider.providerId,
                    bucketName = bucketName,
                    objectPath = objectPath,
                    publicUrl = uploaded.publicUrl,
                    mimeType = mimeType,
                    sizeBytes = bytes.size.toLong(),
                    failoverUsed = failoverUsed,
                    status = "SUCCESS"
                )
                return Result.success(uploaded.copy(failoverUsed = failoverUsed))
            } else {
                lastError = attempt.exceptionOrNull()
                val nextProvider = ordered.getOrNull(index + 1)
                recordStorageError(
                    providerId = provider.providerId,
                    bucketName = bucketName,
                    objectPath = objectPath,
                    errorMessage = lastError?.message ?: "Upload failed",
                    failoverTargetId = nextProvider?.providerId.orEmpty()
                )
                if (nextProvider != null) {
                    failoverUsed = true
                }
            }
        }

        recordUploadHistory(
            providerId = ordered.first().providerId,
            bucketName = resolveBucketName(ordered.first(), bucketKey),
            objectPath = objectPath,
            publicUrl = "",
            mimeType = mimeType,
            sizeBytes = bytes.size.toLong(),
            failoverUsed = failoverUsed,
            status = "FAILED"
        )
        return Result.failure(lastError ?: IllegalStateException("All storage providers failed."))
    }

    suspend fun deleteObject(
        providerId: String = "",
        bucketKey: String = "community",
        storagePath: String = "",
        publicUrl: String = ""
    ): Result<Unit> {
        val cleanPath = storagePath.trim().trimStart('/')
        if (cleanPath.isBlank() && publicUrl.isBlank()) return Result.success(Unit)
        val config = loadRoutingConfig()
        val resolvedProvider = resolveProviderForDelete(config, providerId, publicUrl)
        val bucketName = resolveBucketName(resolvedProvider, bucketKey)

        return when (resolvedProvider.providerType) {
            StorageProviderConfig.TYPE_PHP_HOSTING -> {
                val targetPath = cleanPath.ifBlank { extractRelativePathFromUrl(publicUrl, bucketName) }
                val direct = callDirectPhpJson(
                    endpointUrl = resolvedProvider.endpointUrl,
                    action = "delete_file",
                    payload = JSONObject().put("storagePath", targetPath),
                    requireAuth = true
                ).map { Unit }
                if (direct.isSuccess) direct
                else if (isAuthSecretFallbackCandidate(direct.exceptionOrNull())) {
                    deleteViaPhpHostingProxy(config, resolvedProvider, targetPath)
                } else {
                    direct
                }
            }
            StorageProviderConfig.TYPE_FIREBASE_LEGACY -> Result.success(Unit)
            else -> {
                val pathInBucket = cleanPath.removePrefix("$bucketName/").trimStart('/')
                    .ifBlank { extractRelativePathFromUrl(publicUrl, bucketName) }
                supabaseClient.deleteObject(
                    bucketName = bucketName,
                    objectPath = pathInBucket,
                    overrideUrl = resolvedProvider.endpointUrl,
                    overrideAnonKey = resolvedProvider.publicAnonKey
                )
            }
        }
    }

    suspend fun getSignedPrivateUrl(
        bucketName: String = "verification-documents",
        storagePath: String,
        expiresInSeconds: Int = 120,
        preferredProviderId: String = "",
        fallbackUrl: String = ""
    ): Result<String> {
        val cleanPath = storagePath.trim().trimStart('/')
        val config = loadRoutingConfig()

        val tryPhpHosts: suspend () -> Result<String> = {
            val normalizedBucketPath = if (cleanPath.contains("/")) {
                if (cleanPath.startsWith("$bucketName/")) cleanPath else "$bucketName/$cleanPath"
            } else {
                "$bucketName/$cleanPath"
            }
            val phpProviders = config.providers
                .filter {
                    it.enabled &&
                        it.providerType == StorageProviderConfig.TYPE_PHP_HOSTING &&
                        isAllowedEndpointUrl(it.endpointUrl)
                }
                .sortedByDescending { it.providerId == preferredProviderId }

            var lastErr: Throwable? = null
            var signedResult: String? = null
            for (prov in phpProviders) {
                val res = callDirectPhpJson(
                    endpointUrl = prov.endpointUrl,
                    action = "create_private_download_token",
                    payload = JSONObject()
                        .put("storagePath", normalizedBucketPath)
                        .put("expiresInSeconds", expiresInSeconds.coerceIn(60, 900)),
                    requireAuth = true
                )
                if (res.isSuccess) {
                    val u = res.getOrThrow().optString("signedUrl")
                    if (isAllowedEndpointUrl(u)) {
                        signedResult = u
                        break
                    }
                } else {
                    lastErr = res.exceptionOrNull()
                }
            }
            if (signedResult != null) {
                Result.success(signedResult)
            } else {
                Result.failure(lastErr ?: IllegalStateException("Unable to sign private cPanel file URL."))
            }
        }

        if (preferredProviderId.isNotBlank() && preferredProviderId != "supabase_primary") {
            val phpRes = tryPhpHosts()
            if (phpRes.isSuccess) return phpRes
        }
        if (fallbackUrl.contains("action=download_private", ignoreCase = true)) {
            val phpRes = tryPhpHosts()
            if (phpRes.isSuccess) return phpRes
        }

        val supaRes = supabaseClient.createSignedUrl(
            bucketName = bucketName,
            storagePath = cleanPath.removePrefix("$bucketName/"),
            expiresInSeconds = expiresInSeconds
        )
        if (supaRes.isSuccess) return supaRes

        val phpFallback = tryPhpHosts()
        return if (phpFallback.isSuccess) phpFallback else supaRes
    }

    suspend fun downloadAuthorizedBytes(url: String): Result<ByteArray> = withContext(Dispatchers.IO) {
        val config = cachedRoutingConfig ?: loadRoutingConfig()
        val isPhpUrl = url.contains("action=download_private", ignoreCase = true) ||
            config.providers.any { prov ->
                prov.providerType == StorageProviderConfig.TYPE_PHP_HOSTING &&
                    ((prov.publicMediaBaseUrl.isNotBlank() && url.startsWith(prov.publicMediaBaseUrl, ignoreCase = true)) ||
                        (prov.endpointUrl.isNotBlank() && url.startsWith(prov.endpointUrl.substringBefore("?").substringBeforeLast("/"), ignoreCase = true)))
            }
        if (isPhpUrl) {
            return@withContext runCatching {
                var token = getFirebaseBearerToken(false).orEmpty()
                fun buildReq(t: String) = Request.Builder()
                    .url(url)
                    .get()
                    .apply { if (t.isNotBlank()) addHeader("Authorization", "Bearer $t") }
                    .build()
                var resp = httpClient.newCall(buildReq(token)).execute()
                if (resp.code == 401) {
                    resp.close()
                    token = getFirebaseBearerToken(true).orEmpty()
                    if (token.isNotBlank()) {
                        resp = httpClient.newCall(buildReq(token)).execute()
                    }
                }
                resp.use { r ->
                    if (!r.isSuccessful) throw IllegalStateException("Download HTTP ${r.code}")
                    r.body?.bytes() ?: throw IllegalStateException("Empty file response")
                }
            }
        }
        supabaseClient.downloadBytes(url)
    }

    suspend fun syncMyFirebaseClaims(): Boolean = withContext(Dispatchers.IO) {
        val idToken = getFirebaseBearerToken(false).orEmpty()
        if (idToken.isBlank()) return@withContext false
        val endpoint = "${supabaseClient.resolveUrl()}/functions/v1/admin-user-management"
        val anonKey = supabaseClient.resolveAnonKey()
        val req = Request.Builder()
            .url(endpoint)
            .post(JSONObject().put("action", "sync_my_claims").toString().toRequestBody("application/json".toMediaTypeOrNull()))
            .addHeader("Authorization", "Bearer $idToken")
            .apply { if (anonKey.isNotBlank()) addHeader("apikey", anonKey) }
            .addHeader("Content-Type", "application/json")
            .build()
        val ok = runCatching {
            httpClient.newCall(req).execute().use { resp -> resp.isSuccessful }
        }.getOrDefault(false)
        if (ok) {
            runCatching { getFirebaseBearerToken(true) }
        }
        ok
    }

    private suspend fun deleteViaPhpHostingProxy(
        config: StorageRoutingConfig,
        provider: StorageProviderConfig,
        storagePath: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val proxyUrl = provider.proxyUploadUrl.trim()
            .ifBlank { config.hostingProxyUrl.trim() }
            .ifBlank { DEFAULT_HOSTING_PROXY_URL }
        if (!isAllowedEndpointUrl(proxyUrl) || storagePath.isBlank()) {
            return@withContext Result.success(Unit)
        }
        runCatching {
            var idToken = getFirebaseBearerToken(false).orEmpty()
            if (idToken.isBlank()) throw IllegalStateException("Sign in required.")
            val bodyJson = JSONObject()
                .put("action", "delete_file")
                .put("providerId", provider.providerId)
                .put("uploadApiUrl", provider.endpointUrl)
                .put("storagePath", storagePath)
                .toString()

            fun buildReq(token: String) = Request.Builder()
                .url(proxyUrl)
                .post(bodyJson.toRequestBody("application/json".toMediaTypeOrNull()))
                .addHeader("Authorization", "Bearer $token")
                .addHeader("Content-Type", "application/json")
                .build()

            httpClient.newCall(buildReq(idToken)).execute().use { resp ->
                if (resp.code == 401) {
                    resp.close()
                    idToken = getFirebaseBearerToken(true).orEmpty()
                    if (idToken.isNotBlank()) {
                        httpClient.newCall(buildReq(idToken)).execute().use { retryResp ->
                            if (!retryResp.isSuccessful && retryResp.code != 404) {
                                throw IllegalStateException("PHP delete failed HTTP ${retryResp.code}")
                            }
                        }
                    }
                } else if (!resp.isSuccessful && resp.code != 404) {
                    throw IllegalStateException("PHP delete failed HTTP ${resp.code}")
                }
            }
            Unit
        }
    }

    private suspend fun uploadToSingleProvider(
        config: StorageRoutingConfig,
        provider: StorageProviderConfig,
        bucketKey: String,
        bucketName: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String,
        allowUpsert: Boolean,
        onProgress: (Float) -> Unit
    ): Result<MultiCloudUploadResult> {
        return when (provider.providerType) {
            StorageProviderConfig.TYPE_SUPABASE_STORAGE -> {
                val res = supabaseClient.uploadObject(
                    bucketName = bucketName,
                    objectPath = objectPath,
                    bytes = bytes,
                    mimeType = mimeType,
                    isPublicBucket = bucketKey != "verification",
                    allowUpsert = allowUpsert,
                    overrideUrl = provider.endpointUrl,
                    overrideAnonKey = provider.publicAnonKey
                )
                res.map {
                    MultiCloudUploadResult(
                        publicUrl = it.publicUrl,
                        storagePath = it.storagePath,
                        providerId = provider.providerId,
                        bucketName = bucketName,
                        failoverUsed = false
                    )
                }
            }

            StorageProviderConfig.TYPE_PHP_HOSTING -> {
                onProgress(0.45f)
                val direct = uploadDirectToPhpHosting(
                    provider = provider,
                    bucketName = bucketName,
                    objectPath = objectPath,
                    bytes = bytes,
                    mimeType = mimeType
                )
                if (direct.isSuccess) return direct
                val err = direct.exceptionOrNull()
                if (isAuthSecretFallbackCandidate(err) && isAllowedEndpointUrl(provider.proxyUploadUrl.ifBlank { config.hostingProxyUrl })) {
                    uploadViaPhpHostingProxy(
                        config = config,
                        provider = provider,
                        bucketName = bucketName,
                        objectPath = objectPath,
                        bytes = bytes,
                        mimeType = mimeType
                    )
                } else {
                    direct
                }
            }

            StorageProviderConfig.TYPE_FIREBASE_LEGACY ->
                Result.failure(IllegalStateException("Firebase Storage is deprecated. Switch provider to Supabase or External Hosting."))

            else -> uploadViaSignedProxy(provider, bucketName, objectPath, bytes, mimeType)
        }
    }

    private suspend fun uploadDirectToPhpHosting(
        provider: StorageProviderConfig,
        bucketName: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String
    ): Result<MultiCloudUploadResult> {
        val encodedBase64 = encodeBase64NoWrap(bytes)
        val payload = JSONObject()
            .put("bucket", bucketName)
            .put("objectPath", objectPath)
            .put("mimeType", mimeType)
            .put("base64", encodedBase64)

        return callDirectPhpJson(
            endpointUrl = provider.endpointUrl,
            action = "upload",
            payload = payload,
            requireAuth = true
        ).mapCatching { parsed ->
            val publicUrl = parsed.optString("publicUrl")
            if (!isAllowedEndpointUrl(publicUrl)) {
                throw IllegalStateException("cPanel upload returned invalid URL.")
            }
            MultiCloudUploadResult(
                publicUrl = publicUrl,
                storagePath = parsed.optString("storagePath", "$bucketName/$objectPath"),
                providerId = provider.providerId,
                bucketName = bucketName,
                failoverUsed = false,
                deduplicated = parsed.optBoolean("deduplicated", false)
            )
        }
    }

    private suspend fun uploadViaPhpHostingProxy(
        config: StorageRoutingConfig,
        provider: StorageProviderConfig,
        bucketName: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String
    ): Result<MultiCloudUploadResult> = withContext(Dispatchers.IO) {
        val proxyUrl = provider.proxyUploadUrl.trim()
            .ifBlank { config.hostingProxyUrl.trim() }
            .ifBlank { DEFAULT_HOSTING_PROXY_URL }
        if (!isAllowedEndpointUrl(proxyUrl)) {
            return@withContext Result.failure(IllegalStateException("PHP Hosting Proxy requires HTTPS."))
        }
        val uploadApiUrl = provider.endpointUrl.trim()
        if (!isAllowedEndpointUrl(uploadApiUrl)) {
            return@withContext Result.failure(IllegalStateException("${provider.providerName} endpoint URL must use HTTPS."))
        }
        runCatching {
            var idToken = getFirebaseBearerToken(false).orEmpty()
            if (idToken.isBlank()) {
                throw IllegalStateException("Google sign-in session required for hosting upload.")
            }
            val encodedBase64 = encodeBase64NoWrap(bytes)
            val bodyJson = JSONObject()
                .put("action", "upload")
                .put("providerId", provider.providerId)
                .put("uploadApiUrl", uploadApiUrl)
                .put("bucketName", bucketName)
                .put("objectPath", objectPath)
                .put("mimeType", mimeType)
                .put("base64", encodedBase64)
                .toString()

            fun buildReq(token: String) = Request.Builder()
                .url(proxyUrl)
                .post(bodyJson.toRequestBody("application/json".toMediaTypeOrNull()))
                .addHeader("Authorization", "Bearer $token")
                .addHeader("Content-Type", "application/json")
                .build()

            var resp = httpClient.newCall(buildReq(idToken)).execute()
            if (resp.code == 401) {
                resp.close()
                idToken = getFirebaseBearerToken(true).orEmpty()
                resp = httpClient.newCall(buildReq(idToken)).execute()
            }

            resp.use { r ->
                val raw = r.body?.string().orEmpty()
                val parsed = runCatching { JSONObject(raw) }.getOrNull()
                if (!r.isSuccessful || parsed == null || !parsed.optBoolean("ok", false)) {
                    val errMsg = parsed?.optString("message")?.takeIf { it.isNotBlank() }
                        ?: "Hosting proxy HTTP ${r.code}"
                    throw IllegalStateException(errMsg)
                }
                val publicUrl = parsed.optString("publicUrl")
                if (!isAllowedEndpointUrl(publicUrl)) {
                    throw IllegalStateException("Shared hosting upload returned invalid HTTPS URL.")
                }
                MultiCloudUploadResult(
                    publicUrl = publicUrl,
                    storagePath = parsed.optString("storagePath", "$bucketName/$objectPath"),
                    providerId = provider.providerId,
                    bucketName = bucketName,
                    failoverUsed = false,
                    deduplicated = parsed.optBoolean("deduplicated", false)
                )
            }
        }
    }

    private suspend fun uploadViaSignedProxy(
        provider: StorageProviderConfig,
        bucketName: String,
        objectPath: String,
        bytes: ByteArray,
        mimeType: String
    ): Result<MultiCloudUploadResult> = withContext(Dispatchers.IO) {
        val proxyUrl = provider.proxyUploadUrl.trim()
        if (!isAllowedEndpointUrl(proxyUrl)) {
            return@withContext Result.failure(
                IllegalStateException("${provider.providerName} requires a configured HTTPS Signed Upload Proxy URL.")
            )
        }
        runCatching {
            val idToken = getFirebaseBearerToken(false).orEmpty()
            val bodyJson = JSONObject()
                .put("providerId", provider.providerId)
                .put("providerType", provider.providerType)
                .put("bucketName", bucketName)
                .put("objectPath", objectPath)
                .put("contentType", mimeType)
                .put("sizeBytes", bytes.size)

            val signReq = Request.Builder()
                .url(proxyUrl)
                .post(bodyJson.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                .apply {
                    if (idToken.isNotBlank()) addHeader("Authorization", "Bearer $idToken")
                }
                .build()

            val (uploadUrl, publicUrl) = httpClient.newCall(signReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Signed proxy HTTP ${resp.code}")
                }
                val parsed = JSONObject(resp.body?.string().orEmpty())
                val uUrl = parsed.optString("uploadUrl")
                val pUrl = parsed.optString("publicUrl")
                if (uUrl.isBlank() || pUrl.isBlank()) {
                    throw IllegalStateException("Signed upload proxy returned incomplete URLs.")
                }
                uUrl to pUrl
            }

            val putReq = Request.Builder()
                .url(uploadUrl)
                .put(bytes.toRequestBody(mimeType.toMediaTypeOrNull()))
                .build()
            httpClient.newCall(putReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Direct cloud PUT failed HTTP ${resp.code}")
                }
            }
            MultiCloudUploadResult(
                publicUrl = publicUrl,
                storagePath = "$bucketName/${objectPath.trimStart('/')}",
                providerId = provider.providerId,
                bucketName = bucketName,
                failoverUsed = false
            )
        }
    }

    private suspend fun recordUploadHistory(
        providerId: String,
        bucketName: String,
        objectPath: String,
        publicUrl: String,
        mimeType: String,
        sizeBytes: Long,
        failoverUsed: Boolean,
        status: String
    ) {
        val uid = authProvider()?.currentUser?.uid ?: return
        val uploadId = "upl_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val payload = JSONObject()
            .put("upload_id", uploadId)
            .put("provider_id", providerId.take(128))
            .put("bucket_name", bucketName.take(128))
            .put("object_path", objectPath.take(320))
            .put("public_url", if (publicUrl.startsWith("https://")) publicUrl.take(1000) else "")
            .put("mime_type", mimeType.take(100))
            .put("size_bytes", sizeBytes.coerceAtLeast(0L))
            .put("failover_used", failoverUsed)
            .put("status", if (status == "FAILED") "FAILED" else "SUCCESS")
            .put("uploaded_by_uid", uid)
        runCatching {
            supabaseClient.insertRow("storage_upload_history", payload, requireAuth = true)
        }
    }

    private suspend fun recordStorageError(
        providerId: String,
        bucketName: String,
        objectPath: String,
        errorMessage: String,
        failoverTargetId: String
    ) {
        val uid = authProvider()?.currentUser?.uid ?: return
        val errorId = "err_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val payload = JSONObject()
            .put("error_id", errorId)
            .put("provider_id", providerId.take(128))
            .put("bucket_name", bucketName.take(128))
            .put("object_path", objectPath.take(320))
            .put("error_message", errorMessage.take(600))
            .put("failover_target_id", failoverTargetId.take(128))
            .put("actor_uid", uid)
            .put("resolved", false)
        runCatching {
            supabaseClient.insertRow("storage_error_logs", payload, requireAuth = true)
        }
    }

    companion object {
        const val DEFAULT_HOSTING_PROXY_URL =
            "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/hosting-proxy-upload"

        fun isSupabaseQuotaOrOutageFailure(error: Throwable?): Boolean {
            if (error == null) return false
            if (error is IOException || error is SocketTimeoutException) return true
            val msg = error.message.orEmpty().lowercase()
            val quotaOrOutageHttpCodes = listOf("http 402", "http 408", "http 413", "http 429", "http 500", "http 502", "http 503", "http 504", "http 507", "http 520", "http 521", "http 522", "http 523", "http 524")
            if (quotaOrOutageHttpCodes.any { it in msg }) return true
            if ("http 404" in msg && ("paused" in msg || "not found" in msg || "project" in msg)) return true
            return listOf(
                "quota",
                "insufficient storage",
                "storage limit",
                "database size",
                "exceeded",
                "read-only",
                "paused",
                "timeout",
                "timed out",
                "failed to connect",
                "unable to resolve host",
                "connection refused",
                "connection reset",
                "eof"
            ).any { it in msg }
        }

        fun buildPhpActionUrl(rawEndpoint: String, action: String, extraQuery: String = ""): String {
            val clean = rawEndpoint.trim().trimEnd('/')
            val hasPhpFile = clean.substringBefore("?").endsWith(".php", ignoreCase = true)
            val scriptUrl = if (hasPhpFile) clean else "$clean/index.php"
            val sep = if ("?" in scriptUrl) "&" else "?"
            val suffix = if (extraQuery.isNotBlank()) "&$extraQuery" else ""
            return "$scriptUrl${sep}action=${URLEncoder.encode(action, "UTF-8")}$suffix"
        }

        fun resolveProviderForDelete(
            config: StorageRoutingConfig,
            providerId: String,
            publicUrl: String
        ): StorageProviderConfig {
            if (providerId.isNotBlank()) {
                config.providers.firstOrNull { it.providerId == providerId }?.let { return it }
            }
            val lower = publicUrl.lowercase()
            if (lower.contains(".supabase.co/storage")) {
                return config.providers.firstOrNull { it.providerType == StorageProviderConfig.TYPE_SUPABASE_STORAGE }
                    ?: StorageProviderConfig()
            }
            config.providers.firstOrNull {
                it.providerType == StorageProviderConfig.TYPE_PHP_HOSTING &&
                    ((it.publicMediaBaseUrl.isNotBlank() && lower.startsWith(it.publicMediaBaseUrl.lowercase().trimEnd('/'))) ||
                        (it.endpointUrl.isNotBlank() && lower.startsWith(it.endpointUrl.substringBefore("?").substringBeforeLast("/").lowercase())))
            }?.let { return it }
            return config.providers.firstOrNull() ?: StorageProviderConfig()
        }

        fun extractRelativePathFromUrl(publicUrl: String, bucketName: String): String {
            val clean = publicUrl.substringBefore("?").trim()
            val marker = "/$bucketName/"
            val idx = clean.indexOf(marker)
            return if (idx >= 0) clean.substring(idx + marker.length).trimStart('/') else ""
        }

        fun resolveBucketName(provider: StorageProviderConfig, bucketKey: String): String {
            return provider.buckets[bucketKey]
                ?: StorageProviderConfig.DEFAULT_BUCKETS[bucketKey]
                ?: "community-photos"
        }

        fun selectOrderedProviders(config: StorageRoutingConfig): List<StorageProviderConfig> {
            return selectOrderedProvidersForBucket(config, bucketKey = "community")
        }

        fun selectOrderedProvidersForBucket(
            config: StorageRoutingConfig,
            bucketKey: String
        ): List<StorageProviderConfig> {
            val active = config.providers.filter { provider ->
                val enabledAndActive = provider.enabled &&
                    provider.supportsStorage &&
                    provider.role != StorageProviderConfig.ROLE_DISABLED &&
                    provider.providerType != StorageProviderConfig.TYPE_FIREBASE_LEGACY &&
                    provider.providerType != StorageProviderConfig.TYPE_EXTERNAL_DB
                val bucketAllowed = !(provider.communityOnly && bucketKey != "community")
                enabledAndActive && bucketAllowed
            }
            val mappedProviderId = config.categoryMappings[bucketKey]?.trim().orEmpty()
            val mappedProvider = active.firstOrNull { it.providerId == mappedProviderId }
            val primary = active.filter { it.role == StorageProviderConfig.ROLE_PRIMARY && it.providerId != mappedProviderId }
            val backups = active.filter { it.role != StorageProviderConfig.ROLE_PRIMARY && it.providerId != mappedProviderId }
            val prioritized = listOfNotNull(mappedProvider) + primary + backups

            val ordered = if (!config.autoFailoverEnabled) {
                prioritized.take(1)
            } else {
                prioritized
            }
            return ordered.ifEmpty { listOf(StorageProviderConfig()) }
        }

        fun resolveEffectiveFcmEndpoint(
            configuredRemoteUrl: String = "",
            buildConfigUrl: String = BuildConfig.FCM_BACKEND_ENDPOINT
        ): String {
            val remote = configuredRemoteUrl.trim()
            val buildCfg = buildConfigUrl.trim().takeIf {
                it.startsWith("https://", ignoreCase = true) && !SupabaseClient.isPlaceholderOrBlank(it)
            }.orEmpty()
            if (remote.startsWith("https://", ignoreCase = true) &&
                !SupabaseClient.isPlaceholderOrBlank(remote) &&
                !remote.endsWith("/send-fcm-v1", ignoreCase = true)
            ) {
                return remote
            }
            if (buildCfg.isNotBlank()) return buildCfg
            if (remote.startsWith("https://", ignoreCase = true) && !SupabaseClient.isPlaceholderOrBlank(remote)) {
                return remote
            }
            return SupabaseClient.DEFAULT_FCM_ENDPOINT
        }

        fun serializeProvidersJson(providers: List<StorageProviderConfig>): String {
            val arr = JSONArray()
            providers.forEach { p ->
                val b = JSONObject()
                p.buckets.forEach { (k, v) -> b.put(k, v) }
                arr.put(
                    JSONObject()
                        .put("providerId", p.providerId)
                        .put("providerName", p.providerName)
                        .put("providerType", p.providerType)
                        .put("endpointUrl", p.endpointUrl)
                        .put("publicAnonKey", p.publicAnonKey)
                        .put("proxyUploadUrl", p.proxyUploadUrl)
                        .put("hostingVendor", p.hostingVendor)
                        .put("publicMediaBaseUrl", p.publicMediaBaseUrl)
                        .put("communityOnly", p.communityOnly)
                        .put("supportsStorage", p.supportsStorage)
                        .put("supportsDatabase", p.supportsDatabase)
                        .put("dbEnabled", p.dbEnabled)
                        .put("dbEngine", p.dbEngine)
                        .put("role", p.role)
                        .put("enabled", p.enabled)
                        .put("capacityLimitBytes", p.capacityLimitBytes)
                        .put("usedBytes", p.usedBytes)
                        .put("buckets", b)
                )
            }
            return arr.toString()
        }

        fun serializeCategoryMappingsJson(mappings: Map<String, String>): String {
            val obj = JSONObject()
            mappings.forEach { (k, v) -> obj.put(k, v) }
            return obj.toString()
        }

        fun parseRoutingConfig(
            autoFailoverEnabled: Boolean,
            fcmBackendUrl: String,
            providersJson: String,
            buildConfigFcmUrl: String = BuildConfig.FCM_BACKEND_ENDPOINT,
            hostingProxyUrl: String = DEFAULT_HOSTING_PROXY_URL,
            compressionMaxDim: Int = 1440,
            compressionQuality: Int = 82,
            compressionMaxSizeKb: Int = 4500,
            duplicateCheckEnabled: Boolean = true,
            categoryMappingsJson: String = "",
            autoMigrationEnabled: Boolean = false,
            autoCleanupEnabled: Boolean = false,
            dbMigrationThresholdPct: Int = 80,
            storageMigrationThresholdPct: Int = 80,
            primaryDbProviderId: String = "supabase_primary",
            fallbackDiscoveryUrls: List<String> = emptyList(),
            configVersion: Long = 1L
        ): StorageRoutingConfig {
            val providers = runCatching {
                if (providersJson.isBlank()) emptyList()
                else {
                    val arr = JSONArray(providersJson)
                    (0 until arr.length()).mapNotNull { i ->
                        val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                        val bObj = obj.optJSONObject("buckets")
                        val buckets = if (bObj != null) {
                            StorageProviderConfig.DEFAULT_BUCKETS.mapValues { (k, def) ->
                                bObj.optString(k, def).ifBlank { def }
                            }
                        } else {
                            StorageProviderConfig.DEFAULT_BUCKETS
                        }
                        val type = obj.optString("providerType", StorageProviderConfig.TYPE_SUPABASE_STORAGE)
                        StorageProviderConfig(
                            providerId = obj.optString("providerId", "prov_$i").ifBlank { "prov_$i" },
                            providerName = obj.optString("providerName", "Storage Provider"),
                            providerType = type,
                            endpointUrl = obj.optString("endpointUrl", SupabaseClient.DEFAULT_SUPABASE_URL),
                            publicAnonKey = obj.optString("publicAnonKey", ""),
                            proxyUploadUrl = obj.optString("proxyUploadUrl", ""),
                            hostingVendor = obj.optString("hostingVendor", ""),
                            publicMediaBaseUrl = obj.optString("publicMediaBaseUrl", ""),
                            communityOnly = obj.optBoolean("communityOnly", false),
                            supportsStorage = obj.optBoolean("supportsStorage", type != StorageProviderConfig.TYPE_EXTERNAL_DB),
                            supportsDatabase = obj.optBoolean("supportsDatabase", false),
                            dbEnabled = obj.optBoolean("dbEnabled", false),
                            dbEngine = obj.optString("dbEngine", "MYSQL"),
                            role = obj.optString("role", StorageProviderConfig.ROLE_BACKUP),
                            enabled = obj.optBoolean("enabled", true),
                            capacityLimitBytes = obj.optLong("capacityLimitBytes", 1_073_741_824L),
                            usedBytes = obj.optLong("usedBytes", 0L),
                            buckets = buckets
                        )
                    }
                }
            }.getOrDefault(emptyList())

            val categoryMappings = runCatching {
                if (categoryMappingsJson.isBlank()) emptyMap()
                else {
                    val obj = JSONObject(categoryMappingsJson)
                    buildMap {
                        obj.keys().forEach { k ->
                            val v = obj.optString(k).trim()
                            if (v.isNotEmpty()) put(k, v)
                        }
                    }
                }
            }.getOrDefault(emptyMap())

            val effectiveProxy = hostingProxyUrl.trim()
                .takeIf { it.startsWith("https://", ignoreCase = true) }
                ?: DEFAULT_HOSTING_PROXY_URL

            return StorageRoutingConfig(
                autoFailoverEnabled = autoFailoverEnabled,
                fcmBackendUrl = resolveEffectiveFcmEndpoint(fcmBackendUrl, buildConfigFcmUrl),
                hostingProxyUrl = effectiveProxy,
                compressionMaxDim = compressionMaxDim.coerceIn(480, 4096),
                compressionQuality = compressionQuality.coerceIn(40, 100),
                compressionMaxSizeKb = compressionMaxSizeKb.coerceIn(100, 5120),
                duplicateCheckEnabled = duplicateCheckEnabled,
                categoryMappings = categoryMappings,
                providers = providers.ifEmpty { listOf(StorageProviderConfig()) },
                autoMigrationEnabled = autoMigrationEnabled,
                autoCleanupEnabled = autoCleanupEnabled,
                dbMigrationThresholdPct = dbMigrationThresholdPct.coerceIn(20, 99),
                storageMigrationThresholdPct = storageMigrationThresholdPct.coerceIn(20, 99),
                primaryDbProviderId = primaryDbProviderId.ifBlank { "supabase_primary" },
                fallbackDiscoveryUrls = fallbackDiscoveryUrls.distinct(),
                configVersion = configVersion.coerceAtLeast(1L)
            )
        }

        private fun encodeBase64NoWrap(bytes: ByteArray): String {
            val androidEncoded = runCatching { Base64.encodeToString(bytes, Base64.NO_WRAP) }.getOrNull()
            if (!androidEncoded.isNullOrEmpty() || bytes.isEmpty()) {
                return androidEncoded ?: ""
            }
            return java.util.Base64.getEncoder().encodeToString(bytes)
        }
    }
}
