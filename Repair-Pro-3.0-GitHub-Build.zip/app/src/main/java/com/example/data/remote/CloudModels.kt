package com.example.data.remote

import androidx.annotation.Keep
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Keep
data class CloudTimestamp(
    val seconds: Long = 0L,
    val nanoseconds: Int = 0
) : Comparable<CloudTimestamp> {
    fun toDate(): Date = Date(toEpochMillis())

    fun toEpochMillis(): Long = seconds * 1000L + (nanoseconds / 1_000_000L)

    override fun compareTo(other: CloudTimestamp): Int {
        val secCmp = seconds.compareTo(other.seconds)
        return if (secCmp != 0) secCmp else nanoseconds.compareTo(other.nanoseconds)
    }

    companion object {
        fun now(): CloudTimestamp = fromMillis(System.currentTimeMillis())

        fun fromMillis(millis: Long): CloudTimestamp {
            val secs = millis / 1000L
            val nanos = ((millis % 1000L) * 1_000_000L).toInt()
            return CloudTimestamp(seconds = secs, nanoseconds = nanos)
        }

        fun parseIso(raw: String?): CloudTimestamp? {
            val clean = raw?.trim().orEmpty()
            if (clean.isEmpty() || clean.equals("null", ignoreCase = true)) return null
            val patterns = listOf(
                "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX",
                "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd HH:mm:ss"
            )
            for (pattern in patterns) {
                try {
                    val fmt = SimpleDateFormat(pattern, Locale.US).apply {
                        timeZone = TimeZone.getTimeZone("UTC")
                    }
                    val parsed = fmt.parse(clean)
                    if (parsed != null) return fromMillis(parsed.time)
                } catch (_: Exception) {
                }
            }
            val numeric = clean.toLongOrNull()
            return if (numeric != null) {
                if (numeric > 10_000_000_000L) fromMillis(numeric) else CloudTimestamp(seconds = numeric)
            } else null
        }

        fun toIsoString(ts: CloudTimestamp? = now()): String {
            val millis = ts?.toEpochMillis() ?: System.currentTimeMillis()
            val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            return fmt.format(Date(millis))
        }
    }
}

@Keep
data class UserProfileCloud(
    val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val photoStoragePath: String = "",
    val photoProviderId: String = "",
    val preferredLanguage: String = "en",
    val adConsentGranted: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val isVerifiedTechnician: Boolean = false,
    val accountStatus: String = "ACTIVE",
    val blocked: Boolean = false,
    val suspended: Boolean = false,
    val communityRestricted: Boolean = false,
    val uploadRestricted: Boolean = false,
    val moderationReason: String = "",
    val moderatedByUid: String = "",
    val moderatedAt: CloudTimestamp? = null,
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
) {
    val isAccountBlockedOrSuspended: Boolean
        get() = blocked || suspended || accountStatus.equals("BLOCKED", ignoreCase = true) || accountStatus.equals("SUSPENDED", ignoreCase = true)
}

@Keep
data class SavedGuideCloud(
    val id: String = "",
    val userId: String = "",
    val itemType: String = "PROBLEM",
    val itemId: String = "",
    val categoryId: String = "ac",
    val title: String = "",
    val subtitle: String = "",
    val createdAt: CloudTimestamp? = null
)

@Keep
data class ProblemReportCloud(
    val id: String = "",
    val userId: String = "",
    val categoryId: String = "ac",
    val brandName: String = "",
    val modelName: String = "",
    val errorCode: String = "",
    val description: String = "",
    val preferredLanguage: String = "en",
    val status: String = "PENDING",
    val adminNote: String = "",
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
)

@Keep
data class CatalogEntryCloud(
    val id: String = "",
    val entryType: String = "ERROR_CODE",
    val categoryId: String = "ac",
    val brandName: String = "",
    val modelSeries: String = "",
    val code: String = "",
    val titleEn: String = "",
    val titleBn: String = "",
    val titleHi: String = "",
    val summaryEn: String = "",
    val summaryBn: String = "",
    val summaryHi: String = "",
    val stepsEn: String = "",
    val stepsBn: String = "",
    val stepsHi: String = "",
    val safetyWarningEn: String = "",
    val photoUrl: String = "",
    val photoStoragePath: String = "",
    val pdfUrl: String = "",
    val pdfStoragePath: String = "",
    val pdfTitle: String = "",
    val diagramUrl: String = "",
    val diagramStoragePath: String = "",
    val diagramTitle: String = "",
    val verificationStatus: String = "VERIFIED",
    val published: Boolean = true,
    val revision: Long = 1L,
    val updatedByUid: String = "",
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
)

@Keep
data class AppSettingCloud(
    val id: String = "",
    val configType: String = "ADMOB",
    val adsGlobalEnabled: Boolean = true,
    val bannerEnabled: Boolean = true,
    val interstitialEnabled: Boolean = false,
    val rewardedEnabled: Boolean = true,
    val nativeEnabled: Boolean = false,
    val emergencyKillSwitch: Boolean = false,
    val testMode: Boolean = true,
    val acAdsEnabled: Boolean = true,
    val fridgeAdsEnabled: Boolean = true,
    val washerAdsEnabled: Boolean = true,
    val interstitialCooldownMin: Long = 3L,
    val sessionFrequencyCap: Long = 6L,
    val androidAppId: String = "ca-app-pub-3940256099942544~3347511713",
    val androidBannerId: String = "ca-app-pub-3940256099942544/6300978111",
    val androidInterstitialId: String = "ca-app-pub-3940256099942544/1033173712",
    val androidRewardedId: String = "ca-app-pub-3940256099942544/5224354917",
    val iosAppId: String = "ca-app-pub-3940256099942544~1458002511",
    val iosBannerId: String = "ca-app-pub-3940256099942544/2934735716",
    val announcement: String = "",
    val maintenanceNotice: String = "",
    val maintenanceMode: Boolean = false,
    val schemaVersion: Long = 2L,
    val minSupportedVersion: String = "1.0.0",
    val minSupportedVersionCode: Long = 1L,
    val latestVersionCode: Long = 3L,
    val latestVersionName: String = "1.2.0",
    val forceUpdate: Boolean = false,
    val updateMessage: String = "",
    val updateUrl: String = "",
    val communityEnabled: Boolean = true,
    val techniciansEnabled: Boolean = true,
    val billingEnabled: Boolean = true,
    val verificationEnabled: Boolean = true,
    val scannerEnabled: Boolean = true,
    val reportsEnabled: Boolean = true,
    val pdfsEnabled: Boolean = true,
    val updatedByUid: String = "",
    val updatedAt: CloudTimestamp? = null
) {
    fun requiresForceUpdate(currentVersionCode: Int): Boolean =
        forceUpdate && minSupportedVersionCode > 0L && currentVersionCode.toLong() < minSupportedVersionCode

    fun hasSoftUpdateAvailable(currentVersionCode: Int): Boolean =
        !requiresForceUpdate(currentVersionCode) && latestVersionCode > currentVersionCode.toLong()
}

@Keep
data class AuditLogCloud(
    val id: String = "",
    val adminUid: String = "",
    val adminEmail: String = "",
    val action: String = "",
    val targetType: String = "",
    val targetId: String = "",
    val details: String = "",
    val result: String = "SUCCESS",
    val createdAt: CloudTimestamp? = null
)

@Keep
data class AdminRoleCloud(
    val id: String = "",
    val userId: String = "",
    val role: String = "SUPER_ADMIN",
    val createdAt: CloudTimestamp? = null
)

@Keep
data class TechnicianCloud(
    val id: String = "",
    val technicianId: String = "",
    val fullName: String = "",
    val photoUrl: String = "",
    val photoStoragePath: String = "",
    val photoProviderId: String = "",
    val storageProviderId: String = "supabase_primary",
    val externalRecordId: String = "",
    val mobileNumber: String = "",
    val fullAddress: String = "",
    val state: String = "",
    val district: String = "",
    val cityArea: String = "",
    val pinCode: String = "",
    val serviceCategories: List<String> = emptyList(),
    val experience: String = "",
    val bio: String = "",
    val verificationStatus: String = "VERIFIED",
    val blocked: Boolean = false,
    val isSuspended: Boolean = false,
    val isDeleted: Boolean = false,
    val deletedAt: CloudTimestamp? = null,
    val linkedUserUid: String = "",
    val status: String = "ACTIVE",
    val updatedByUid: String = "",
    val createdAt: CloudTimestamp? = null,
    val updatedAt: CloudTimestamp? = null
) {
    val isPubliclyVisible: Boolean
        get() = status.equals("ACTIVE", ignoreCase = true) && !blocked && !isSuspended && !isDeleted
}
