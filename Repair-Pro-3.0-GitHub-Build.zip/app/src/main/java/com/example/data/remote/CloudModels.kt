package com.example.data.remote

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class UserProfileCloud(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val preferredLanguage: String = "en",
    val adConsentGranted: Boolean = true,
    val fcmToken: String = "",
    val appVersion: String = "3.0",
    val isBlocked: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SavedGuideCloud(
    @DocumentId val id: String = "",
    val userId: String = "",
    val itemType: String = "PROBLEM",
    val itemId: String = "",
    val categoryId: String = "ac",
    val title: String = "",
    val subtitle: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ProblemReportCloud(
    @DocumentId val id: String = "",
    val userId: String = "",
    val categoryId: String = "ac",
    val brandName: String = "",
    val modelName: String = "",
    val errorCode: String = "",
    val description: String = "",
    val preferredLanguage: String = "en",
    val status: String = "PENDING",
    val adminNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CatalogEntryCloud(
    @DocumentId val id: String = "",
    val entryType: String = "ERROR_CODE",
    val categoryId: String = "ac",
    val brandName: String = "",
    val modelSeries: String = "",
    val code: String = "",
    val titleEn: String = "",
    val titleBn: String = "",
    val titleHi: String = "",
    val summaryEn: String = "",
    val summaryBn: String = "",
    val summaryHi: String = "",
    val stepsEn: String = "",
    val stepsBn: String = "",
    val stepsHi: String = "",
    val safetyWarningEn: String = "",
    val verificationStatus: String = "VERIFIED",
    val published: Boolean = true,
    val revision: Long = 1L,
    val updatedByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AppSettingCloud(
    @DocumentId val id: String = "",
    val configType: String = "ADMOB",
    val adsGlobalEnabled: Boolean = true,
    val bannerEnabled: Boolean = true,
    val interstitialEnabled: Boolean = false,
    val rewardedEnabled: Boolean = true,
    val nativeEnabled: Boolean = false,
    val appOpenEnabled: Boolean = false,
    val emergencyKillSwitch: Boolean = false,
    val testMode: Boolean = true,
    val acAdsEnabled: Boolean = true,
    val fridgeAdsEnabled: Boolean = true,
    val washerAdsEnabled: Boolean = true,
    val interstitialCooldownMin: Long = 3L,
    val sessionFrequencyCap: Long = 6L,
    val androidAppId: String = "ca-app-pub-3940256099942544~3347511713",
    val androidBannerId: String = "ca-app-pub-3940256099942544/6300978111",
    val androidInterstitialId: String = "ca-app-pub-3940256099942544/1033173712",
    val androidRewardedId: String = "ca-app-pub-3940256099942544/5224354917",
    val androidNativeId: String = "ca-app-pub-3940256099942544/2247696110",
    val androidAppOpenId: String = "ca-app-pub-3940256099942544/9257395921",
    val iosAppId: String = "ca-app-pub-3940256099942544~1458002511",
    val iosBannerId: String = "ca-app-pub-3940256099942544/2934735716",
    val announcement: String = "",
    val maintenanceNotice: String = "",
    val minSupportedVersion: String = "3.0",
    val latestVersionName: String = "3.0",
    val latestVersionCode: Long = 3L,
    val communityEnabled: Boolean = true,
    val techniciansEnabled: Boolean = true,
    val documentsEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val storageAutoFailover: Boolean = true,
    val updatedByUid: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AuditLogCloud(
    @DocumentId val id: String = "",
    val adminUid: String = "",
    val adminEmail: String = "",
    val action: String = "",
    val targetType: String = "",
    val targetId: String = "",
    val details: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AdminRoleCloud(
    @DocumentId val id: String = "",
    val userId: String = "",
    val role: String = "SUPER_ADMIN",
    @ServerTimestamp val createdAt: Timestamp? = null
)

