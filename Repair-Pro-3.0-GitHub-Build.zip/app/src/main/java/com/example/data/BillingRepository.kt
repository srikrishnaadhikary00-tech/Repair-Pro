package com.example.data

import android.content.Context
import com.example.data.local.BillingDao
import com.example.data.local.CustomerEntity
import com.example.data.local.InvoiceEntity
import com.example.data.local.InvoicePaymentEntity
import com.example.data.local.RepairProDatabase
import com.example.data.remote.BillingDomainHelper
import com.example.data.remote.CloudTimestamp
import com.example.data.remote.SupabaseClient
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Calendar
import java.util.UUID

data class BillingSummaryStats(
    val todayCollection: Double = 0.0,
    val monthCollection: Double = 0.0,
    val totalOutstanding: Double = 0.0,
    val totalInvoices: Int = 0,
    val pendingSyncCount: Int = 0
)

class BillingRepository(
    private val dao: BillingDao,
    private val supabaseClient: SupabaseClient,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        dao = RepairProDatabase.getInstance(context.applicationContext).billingDao(),
        supabaseClient = SupabaseClient(
            firebaseTokenProvider = { forceRefresh ->
                runCatching { Firebase.auth.currentUser?.getIdToken(forceRefresh)?.await()?.token }.getOrNull()
            }
        )
    )

    fun observeCustomers(uid: String): Flow<List<CustomerEntity>> = dao.observeCustomers(uid)

    fun observeInvoices(uid: String): Flow<List<InvoiceEntity>> = dao.observeInvoices(uid)

    fun observePayments(uid: String): Flow<List<InvoicePaymentEntity>> = dao.observeAllPayments(uid)

    fun observePaymentsForInvoice(invoiceId: String, uid: String): Flow<List<InvoicePaymentEntity>> =
        dao.observePaymentsForInvoice(invoiceId, uid)

    fun computeStats(
        invoices: List<InvoiceEntity>,
        payments: List<InvoicePaymentEntity>,
        customers: List<CustomerEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): BillingSummaryStats {
        val cal = Calendar.getInstance().apply { timeInMillis = nowMillis }
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startOfToday = cal.timeInMillis

        cal.set(Calendar.DAY_OF_MONTH, 1)
        val startOfMonth = cal.timeInMillis

        val todayFromPayments = payments.filter { it.paidAtMillis >= startOfToday }.sumOf { it.amount }
        val monthFromPayments = payments.filter { it.paidAtMillis >= startOfMonth }.sumOf { it.amount }

        val outstanding = invoices.sumOf { (it.remainingBalance ?: 0.0).coerceAtLeast(0.0) }
        val pendingSync = invoices.count { it.syncStatus != "SYNCED" } +
            customers.count { it.syncStatus != "SYNCED" } +
            payments.count { it.syncStatus != "SYNCED" }

        return BillingSummaryStats(
            todayCollection = BillingDomainHelper.round2(todayFromPayments),
            monthCollection = BillingDomainHelper.round2(monthFromPayments),
            totalOutstanding = BillingDomainHelper.round2(outstanding),
            totalInvoices = invoices.size,
            pendingSyncCount = pendingSync
        )
    }

    suspend fun saveInvoiceOfflineFirst(
        technicianUid: String,
        existingInvoiceId: String?,
        customerId: String?,
        customerName: String,
        customerMobile: String,
        customerAddress: String,
        applianceCategory: String,
        applianceBrand: String,
        modelNumber: String,
        serialNumber: String,
        reportedProblem: String,
        workDone: String,
        partsUsed: String,
        partsQuantity: Int,
        partsCharges: Double?,
        serviceCharges: Double?,
        visitingCharges: Double?,
        otherCharges: Double?,
        discountAmount: Double?,
        initialAmountReceived: Double?,
        paymentMethod: String,
        paymentDueDate: String,
        warrantyInfo: String,
        notes: String,
        reminderDate: String,
        isOnline: Boolean
    ): Result<InvoiceEntity> = withContext(Dispatchers.IO) {
        val validationError = BillingDomainHelper.validateCustomerAndInvoiceInput(
            customerName = customerName,
            customerMobile = customerMobile,
            partsCharges = partsCharges,
            serviceCharges = serviceCharges,
            visitingCharges = visitingCharges,
            otherCharges = otherCharges,
            discountAmount = discountAmount,
            amountReceived = initialAmountReceived
        )
        if (validationError != null) {
            return@withContext Result.failure(IllegalArgumentException(validationError))
        }

        val now = System.currentTimeMillis()
        val cleanName = customerName.trim().take(100)
        val cleanMobile = customerMobile.trim().take(20)
        val cleanAddress = customerAddress.trim().take(300)

        val existingCustomer = if (!customerId.isNullOrBlank()) {
            dao.getCustomer(customerId, technicianUid)
        } else {
            dao.findCustomerByMobile(technicianUid, cleanMobile)
        }

        val resolvedCustomer = if (existingCustomer != null) {
            existingCustomer.copy(
                name = cleanName,
                mobileNumber = cleanMobile,
                address = cleanAddress.ifBlank { existingCustomer.address },
                syncStatus = "PENDING_SYNC",
                updatedAtMillis = now
            )
        } else {
            CustomerEntity(
                customerId = "cust_${UUID.randomUUID().toString().replace("-", "").take(14)}",
                technicianUid = technicianUid,
                name = cleanName,
                mobileNumber = cleanMobile,
                address = cleanAddress,
                notes = "",
                syncStatus = "PENDING_SYNC",
                createdAtMillis = now,
                updatedAtMillis = now
            )
        }
        dao.upsertCustomer(resolvedCustomer)

        val existingInvoice = existingInvoiceId?.takeIf { it.isNotBlank() }?.let {
            dao.getInvoice(it, technicianUid)
        }

        val totalBill = BillingDomainHelper.calculateTotalBill(
            partsCharges = partsCharges,
            serviceCharges = serviceCharges,
            visitingCharges = visitingCharges,
            otherCharges = otherCharges,
            discountAmount = discountAmount
        )

        val existingPayments = existingInvoice?.let {
            dao.getPaymentsForInvoice(it.invoiceId, technicianUid)
        } ?: emptyList()

        val resolvedReceived: Double? = if (existingInvoice != null) {
            if (existingPayments.isNotEmpty()) {
                BillingDomainHelper.round2(existingPayments.sumOf { it.amount })
            } else {
                initialAmountReceived ?: existingInvoice.amountReceived
            }
        } else {
            initialAmountReceived
        }

        val remaining = BillingDomainHelper.calculateRemainingBalance(totalBill, resolvedReceived)
        val status = BillingDomainHelper.resolvePaymentStatus(totalBill, resolvedReceived)

        val invoiceId = existingInvoice?.invoiceId
            ?: "inv_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        val invoiceNumber = existingInvoice?.invoiceNumber
            ?: BillingDomainHelper.generateInvoiceNumber(
                nowMillis = now,
                randomSuffix = UUID.randomUUID().toString().replace("-", "").take(4)
            )

        val entity = InvoiceEntity(
            invoiceId = invoiceId,
            invoiceNumber = invoiceNumber,
            technicianUid = technicianUid,
            customerId = resolvedCustomer.customerId,
            customerName = cleanName,
            customerMobile = cleanMobile,
            customerAddress = cleanAddress,
            applianceCategory = applianceCategory.trim().take(60),
            applianceBrand = applianceBrand.trim().take(60),
            modelNumber = modelNumber.trim().take(80),
            serialNumber = serialNumber.trim().take(80),
            reportedProblem = reportedProblem.trim().take(600),
            workDone = workDone.trim().take(800),
            partsUsed = partsUsed.trim().take(500),
            partsQuantity = partsQuantity.coerceIn(0, 1000),
            partsCharges = partsCharges,
            serviceCharges = serviceCharges,
            visitingCharges = visitingCharges,
            otherCharges = otherCharges,
            discountAmount = discountAmount,
            totalBill = totalBill,
            amountReceived = resolvedReceived,
            remainingBalance = remaining,
            paymentStatus = status,
            paymentMethod = paymentMethod.trim().take(40),
            paymentDueDate = paymentDueDate.trim().take(32),
            warrantyInfo = warrantyInfo.trim().take(200),
            notes = notes.trim().take(500),
            reminderDate = reminderDate.trim().take(32),
            syncStatus = "PENDING_SYNC",
            createdAtMillis = existingInvoice?.createdAtMillis ?: now,
            updatedAtMillis = now
        )
        dao.upsertInvoice(entity)

        if (existingInvoice == null && initialAmountReceived != null && initialAmountReceived > 0.0) {
            val upfrontPayment = InvoicePaymentEntity(
                paymentId = "pay_${UUID.randomUUID().toString().replace("-", "").take(14)}",
                invoiceId = invoiceId,
                technicianUid = technicianUid,
                amount = BillingDomainHelper.round2(initialAmountReceived),
                paymentMethod = paymentMethod.trim().ifBlank { "Cash" }.take(40),
                note = "Initial payment at invoice creation",
                idempotencyKey = "init_$invoiceId",
                syncStatus = "PENDING_SYNC",
                paidAtMillis = now
            )
            dao.upsertPayment(upfrontPayment)
        }

        if (isOnline) {
            syncPendingWithSupabase(technicianUid)
        }
        Result.success(entity)
    }

    suspend fun recordPayment(
        technicianUid: String,
        invoiceId: String,
        amount: Double?,
        paymentMethod: String,
        note: String,
        idempotencyKey: String,
        isOnline: Boolean
    ): Result<InvoiceEntity> = withContext(Dispatchers.IO) {
        val invoice = dao.getInvoice(invoiceId, technicianUid)
            ?: return@withContext Result.failure(IllegalStateException("Invoice not found."))
        val existing = dao.getPaymentsForInvoice(invoiceId, technicianUid)
        val keys = existing.mapNotNull { it.idempotencyKey.takeIf { k -> k.isNotBlank() } }.toSet()
        val error = BillingDomainHelper.validateNewPayment(
            amount = amount,
            currentRemaining = invoice.remainingBalance,
            existingIdempotencyKeys = keys,
            idempotencyKey = idempotencyKey
        )
        if (error != null) {
            return@withContext Result.failure(IllegalArgumentException(error))
        }

        val now = System.currentTimeMillis()
        val payment = InvoicePaymentEntity(
            paymentId = "pay_${UUID.randomUUID().toString().replace("-", "").take(14)}",
            invoiceId = invoiceId,
            technicianUid = technicianUid,
            amount = BillingDomainHelper.round2(amount!!),
            paymentMethod = paymentMethod.trim().ifBlank { "Cash" }.take(40),
            note = note.trim().take(300),
            idempotencyKey = idempotencyKey.take(80),
            syncStatus = "PENDING_SYNC",
            paidAtMillis = now
        )
        val updated = dao.recordPaymentAndRecalculate(payment)
            ?: return@withContext Result.failure(IllegalStateException("Unable to update invoice payment."))
        if (isOnline) {
            syncPendingWithSupabase(technicianUid)
        }
        Result.success(updated)
    }

    suspend fun updateReminderDate(
        technicianUid: String,
        invoiceId: String,
        reminderDate: String,
        isOnline: Boolean
    ): Result<InvoiceEntity> = withContext(Dispatchers.IO) {
        val existing = dao.getInvoice(invoiceId, technicianUid)
            ?: return@withContext Result.failure(IllegalStateException("Invoice not found."))
        val updated = existing.copy(
            reminderDate = reminderDate.trim().take(32),
            syncStatus = "PENDING_SYNC",
            updatedAtMillis = System.currentTimeMillis()
        )
        dao.upsertInvoice(updated)
        if (isOnline) {
            syncPendingWithSupabase(technicianUid)
        }
        Result.success(updated)
    }

    suspend fun deleteInvoice(technicianUid: String, invoiceId: String, isOnline: Boolean): Result<Unit> =
        withContext(Dispatchers.IO) {
            dao.deletePaymentsForInvoice(invoiceId, technicianUid)
            dao.deleteInvoice(invoiceId, technicianUid)
            if (isOnline && auth.currentUser?.uid == technicianUid) {
                val encUid = URLEncoder.encode(technicianUid, "UTF-8")
                val encInv = URLEncoder.encode(invoiceId, "UTF-8")
                runCatching {
                    supabaseClient.deleteRows(
                        "technician_invoice_payments",
                        "technician_uid=eq.$encUid&invoice_id=eq.$encInv"
                    )
                    supabaseClient.deleteRows(
                        "technician_invoices",
                        "technician_uid=eq.$encUid&invoice_id=eq.$encInv"
                    )
                }
            }
            Result.success(Unit)
        }

    suspend fun syncPendingWithFirestore(technicianUid: String): Result<Int> =
        syncPendingWithSupabase(technicianUid)

    suspend fun syncPendingWithSupabase(technicianUid: String): Result<Int> = withContext(Dispatchers.IO) {
        val currentUid = auth.currentUser?.uid
        if (currentUid.isNullOrBlank() || currentUid != technicianUid) {
            return@withContext Result.success(0)
        }
        var syncedCount = 0
        val encUid = URLEncoder.encode(technicianUid, "UTF-8")
        return@withContext runCatching {
            // 1. Push pending customers
            val pendingCustomers = dao.getPendingCustomers(technicianUid)
            for (c in pendingCustomers) {
                supabaseClient.upsertTableRow(
                    "technician_customers",
                    buildCustomerJson(c),
                    onConflict = "customer_id"
                ).getOrThrow()
                dao.upsertCustomer(c.copy(syncStatus = "SYNCED"))
                syncedCount += 1
            }

            // 2. Push pending invoices
            val pendingInvoices = dao.getPendingInvoices(technicianUid)
            for (inv in pendingInvoices) {
                supabaseClient.upsertTableRow(
                    "technician_invoices",
                    buildInvoiceJson(inv),
                    onConflict = "invoice_id"
                ).getOrThrow()
                dao.upsertInvoice(inv.copy(syncStatus = "SYNCED"))
                syncedCount += 1
            }

            // 3. Push pending payments
            val pendingPayments = dao.getPendingPayments(technicianUid)
            for (pay in pendingPayments) {
                supabaseClient.upsertTableRow(
                    "technician_invoice_payments",
                    buildPaymentJson(pay),
                    onConflict = "payment_id"
                ).getOrThrow()
                dao.upsertPayment(pay.copy(syncStatus = "SYNCED"))
                syncedCount += 1
            }

            // 4. Pull remote owner records and merge safely
            val remoteCustomers = supabaseClient.selectRows(
                "technician_customers",
                "technician_uid=eq.$encUid&select=*",
                requireAuth = true
            ).getOrNull()
            if (remoteCustomers != null) {
                val mergedCustomers = mutableListOf<CustomerEntity>()
                for (i in 0 until remoteCustomers.length()) {
                    val obj = remoteCustomers.optJSONObject(i) ?: continue
                    val id = obj.optString("customer_id")
                    if (id.isBlank()) continue
                    val local = dao.getCustomer(id, technicianUid)
                    val remoteUpdated = CloudTimestamp.parseIso(obj.optString("updated_at"))?.toEpochMillis() ?: 0L
                    if (local == null || (local.syncStatus == "SYNCED" && remoteUpdated > local.updatedAtMillis)) {
                        mergedCustomers.add(
                            CustomerEntity(
                                customerId = id,
                                technicianUid = technicianUid,
                                name = obj.optString("name"),
                                mobileNumber = obj.optString("mobile_number"),
                                address = obj.optString("address"),
                                notes = obj.optString("notes"),
                                syncStatus = "SYNCED",
                                createdAtMillis = CloudTimestamp.parseIso(obj.optString("created_at"))?.toEpochMillis() ?: remoteUpdated,
                                updatedAtMillis = remoteUpdated
                            )
                        )
                    }
                }
                if (mergedCustomers.isNotEmpty()) dao.upsertCustomers(mergedCustomers)
            }

            val remoteInvoices = supabaseClient.selectRows(
                "technician_invoices",
                "technician_uid=eq.$encUid&select=*",
                requireAuth = true
            ).getOrNull()
            if (remoteInvoices != null) {
                val mergedInvoices = mutableListOf<InvoiceEntity>()
                for (i in 0 until remoteInvoices.length()) {
                    val obj = remoteInvoices.optJSONObject(i) ?: continue
                    val id = obj.optString("invoice_id")
                    if (id.isBlank()) continue
                    val local = dao.getInvoice(id, technicianUid)
                    val remoteUpdated = CloudTimestamp.parseIso(obj.optString("updated_at"))?.toEpochMillis() ?: 0L
                    if (local == null || (local.syncStatus == "SYNCED" && remoteUpdated > local.updatedAtMillis)) {
                        mergedInvoices.add(
                            InvoiceEntity(
                                invoiceId = id,
                                invoiceNumber = obj.optString("invoice_number"),
                                technicianUid = technicianUid,
                                customerId = obj.optString("customer_id"),
                                customerName = obj.optString("customer_name"),
                                customerMobile = obj.optString("customer_mobile"),
                                customerAddress = obj.optString("customer_address"),
                                applianceCategory = obj.optString("appliance_category"),
                                applianceBrand = obj.optString("appliance_brand"),
                                modelNumber = obj.optString("model_number"),
                                serialNumber = obj.optString("serial_number"),
                                reportedProblem = obj.optString("reported_problem"),
                                workDone = obj.optString("work_done"),
                                partsUsed = obj.optString("parts_used"),
                                partsQuantity = obj.optInt("parts_quantity", 0),
                                partsCharges = obj.optDoubleOrNull("parts_charges"),
                                serviceCharges = obj.optDoubleOrNull("service_charges"),
                                visitingCharges = obj.optDoubleOrNull("visiting_charges"),
                                otherCharges = obj.optDoubleOrNull("other_charges"),
                                discountAmount = obj.optDoubleOrNull("discount_amount"),
                                totalBill = obj.optDoubleOrNull("total_bill"),
                                amountReceived = obj.optDoubleOrNull("amount_received"),
                                remainingBalance = obj.optDoubleOrNull("remaining_balance"),
                                paymentStatus = obj.optString("payment_status", BillingDomainHelper.STATUS_AMOUNT_NOT_ENTERED),
                                paymentMethod = obj.optString("payment_method"),
                                paymentDueDate = obj.optString("payment_due_date"),
                                warrantyInfo = obj.optString("warranty_info"),
                                notes = obj.optString("notes"),
                                reminderDate = obj.optString("reminder_date"),
                                syncStatus = "SYNCED",
                                createdAtMillis = CloudTimestamp.parseIso(obj.optString("created_at"))?.toEpochMillis() ?: remoteUpdated,
                                updatedAtMillis = remoteUpdated
                            )
                        )
                    }
                }
                if (mergedInvoices.isNotEmpty()) dao.upsertInvoices(mergedInvoices)
            }

            val remotePayments = supabaseClient.selectRows(
                "technician_invoice_payments",
                "technician_uid=eq.$encUid&select=*",
                requireAuth = true
            ).getOrNull()
            if (remotePayments != null) {
                val mergedPayments = mutableListOf<InvoicePaymentEntity>()
                for (i in 0 until remotePayments.length()) {
                    val obj = remotePayments.optJSONObject(i) ?: continue
                    val id = obj.optString("payment_id")
                    if (id.isBlank()) continue
                    mergedPayments.add(
                        InvoicePaymentEntity(
                            paymentId = id,
                            invoiceId = obj.optString("invoice_id"),
                            technicianUid = technicianUid,
                            amount = obj.optDouble("amount", 0.0),
                            paymentMethod = obj.optString("payment_method", "Cash"),
                            note = obj.optString("note"),
                            idempotencyKey = obj.optString("idempotency_key"),
                            syncStatus = "SYNCED",
                            paidAtMillis = CloudTimestamp.parseIso(obj.optString("paid_at"))?.toEpochMillis() ?: System.currentTimeMillis()
                        )
                    )
                }
                if (mergedPayments.isNotEmpty()) dao.upsertPayments(mergedPayments)
            }

            syncedCount
        }
    }

    private fun safeIso(millis: Long): String {
        val clamped = minOf(millis, System.currentTimeMillis())
        return CloudTimestamp.toIsoString(CloudTimestamp.fromMillis(clamped))
    }

    private fun JSONObject.optDoubleOrNull(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        val v = optDouble(key, Double.NaN)
        return if (v.isFinite()) v else null
    }

    private fun buildCustomerJson(c: CustomerEntity): JSONObject = JSONObject()
        .put("customer_id", c.customerId)
        .put("technician_uid", c.technicianUid)
        .put("name", c.name.take(100))
        .put("mobile_number", c.mobileNumber.take(20))
        .put("address", c.address.take(300))
        .put("notes", c.notes.take(500))
        .put("created_at", safeIso(c.createdAtMillis))
        .put("updated_at", safeIso(c.updatedAtMillis))

    private fun buildInvoiceJson(inv: InvoiceEntity): JSONObject = JSONObject()
        .put("invoice_id", inv.invoiceId)
        .put("invoice_number", inv.invoiceNumber.take(40))
        .put("technician_uid", inv.technicianUid)
        .put("customer_id", inv.customerId)
        .put("customer_name", inv.customerName.take(100))
        .put("customer_mobile", inv.customerMobile.take(20))
        .put("customer_address", inv.customerAddress.take(300))
        .put("appliance_category", inv.applianceCategory.take(60))
        .put("appliance_brand", inv.applianceBrand.take(60))
        .put("model_number", inv.modelNumber.take(80))
        .put("serial_number", inv.serialNumber.take(80))
        .put("reported_problem", inv.reportedProblem.take(600))
        .put("work_done", inv.workDone.take(800))
        .put("parts_used", inv.partsUsed.take(500))
        .put("parts_quantity", inv.partsQuantity.coerceIn(0, 1000))
        .put("parts_charges", inv.partsCharges ?: JSONObject.NULL)
        .put("service_charges", inv.serviceCharges ?: JSONObject.NULL)
        .put("visiting_charges", inv.visitingCharges ?: JSONObject.NULL)
        .put("other_charges", inv.otherCharges ?: JSONObject.NULL)
        .put("discount_amount", inv.discountAmount ?: JSONObject.NULL)
        .put("total_bill", inv.totalBill ?: JSONObject.NULL)
        .put("amount_received", inv.amountReceived ?: JSONObject.NULL)
        .put("remaining_balance", inv.remainingBalance ?: JSONObject.NULL)
        .put("payment_status", inv.paymentStatus)
        .put("payment_method", inv.paymentMethod.take(40))
        .put("payment_due_date", inv.paymentDueDate.take(32))
        .put("warranty_info", inv.warrantyInfo.take(200))
        .put("notes", inv.notes.take(500))
        .put("reminder_date", inv.reminderDate.take(32))
        .put("created_at", safeIso(inv.createdAtMillis))
        .put("updated_at", safeIso(inv.updatedAtMillis))

    private fun buildPaymentJson(p: InvoicePaymentEntity): JSONObject = JSONObject()
        .put("payment_id", p.paymentId)
        .put("invoice_id", p.invoiceId)
        .put("technician_uid", p.technicianUid)
        .put("amount", p.amount)
        .put("payment_method", p.paymentMethod.take(40))
        .put("note", p.note.take(300))
        .put("idempotency_key", p.idempotencyKey.take(80))
        .put("paid_at", safeIso(p.paidAtMillis))
}
