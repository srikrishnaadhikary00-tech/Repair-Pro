package com.example.data

import android.content.Context
import com.example.R
import com.example.data.local.BillingDao
import com.example.data.local.CustomerEntity
import com.example.data.local.InvoiceEntity
import com.example.data.local.InvoicePaymentEntity
import com.example.data.local.RepairProDatabase
import com.example.data.remote.BillingDomainHelper
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Date
import java.util.UUID

data class BillingSummaryStats(
    val todayCollection: Double = 0.0,
    val monthCollection: Double = 0.0,
    val totalOutstanding: Double = 0.0,
    val totalInvoices: Int = 0,
    val pendingSyncCount: Int = 0
)

class BillingRepository(
    private val dao: BillingDao,
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        dao = RepairProDatabase.getInstance(context.applicationContext).billingDao(),
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    fun observeCustomers(uid: String): Flow<List<CustomerEntity>> = dao.observeCustomers(uid)

    fun observeInvoices(uid: String): Flow<List<InvoiceEntity>> = dao.observeInvoices(uid)

    fun observePayments(uid: String): Flow<List<InvoicePaymentEntity>> = dao.observeAllPayments(uid)

    fun observePaymentsForInvoice(invoiceId: String, uid: String): Flow<List<InvoicePaymentEntity>> =
        dao.observePaymentsForInvoice(invoiceId, uid)

    fun computeStats(
        invoices: List<InvoiceEntity>,
        payments: List<InvoicePaymentEntity>,
        customers: List<CustomerEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): BillingSummaryStats {
        val cal = Calendar.getInstance().apply { timeInMillis = nowMillis }
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startOfToday = cal.timeInMillis

        cal.set(Calendar.DAY_OF_MONTH, 1)
        val startOfMonth = cal.timeInMillis

        val todayFromPayments = payments.filter { it.paidAtMillis >= startOfToday }.sumOf { it.amount }
        val monthFromPayments = payments.filter { it.paidAtMillis >= startOfMonth }.sumOf { it.amount }

        // Include initial received amounts on invoices without explicit payment rows if needed,
        // otherwise payments table tracks every payment row created at invoice creation & later.
        val outstanding = invoices.sumOf { (it.remainingBalance ?: 0.0).coerceAtLeast(0.0) }
        val pendingSync = invoices.count { it.syncStatus != "SYNCED" } +
            customers.count { it.syncStatus != "SYNCED" } +
            payments.count { it.syncStatus != "SYNCED" }

        return BillingSummaryStats(
            todayCollection = BillingDomainHelper.round2(todayFromPayments),
            monthCollection = BillingDomainHelper.round2(monthFromPayments),
            totalOutstanding = BillingDomainHelper.round2(outstanding),
            totalInvoices = invoices.size,
            pendingSyncCount = pendingSync
        )
    }

    suspend fun saveInvoiceOfflineFirst(
        technicianUid: String,
        existingInvoiceId: String?,
        customerId: String?,
        customerName: String,
        customerMobile: String,
        customerAddress: String,
        applianceCategory: String,
        applianceBrand: String,
        modelNumber: String,
        serialNumber: String,
        reportedProblem: String,
        workDone: String,
        partsUsed: String,
        partsQuantity: Int,
        partsCharges: Double?,
        serviceCharges: Double?,
        visitingCharges: Double?,
        otherCharges: Double?,
        discountAmount: Double?,
        initialAmountReceived: Double?,
        paymentMethod: String,
        paymentDueDate: String,
        warrantyInfo: String,
        notes: String,
        reminderDate: String,
        isOnline: Boolean
    ): Result<InvoiceEntity> = withContext(Dispatchers.IO) {
        val validationError = BillingDomainHelper.validateCustomerAndInvoiceInput(
            customerName = customerName,
            customerMobile = customerMobile,
            partsCharges = partsCharges,
            serviceCharges = serviceCharges,
            visitingCharges = visitingCharges,
            otherCharges = otherCharges,
            discountAmount = discountAmount,
            amountReceived = initialAmountReceived
        )
        if (validationError != null) {
            return@withContext Result.failure(IllegalArgumentException(validationError))
        }

        val now = System.currentTimeMillis()
        val cleanName = customerName.trim().take(100)
        val cleanMobile = customerMobile.trim().take(20)
        val cleanAddress = customerAddress.trim().take(300)

        // Reuse or create customer strictly scoped to technicianUid
        val existingCustomer = if (!customerId.isNullOrBlank()) {
            dao.getCustomer(customerId, technicianUid)
        } else {
            dao.findCustomerByMobile(technicianUid, cleanMobile)
        }

        val resolvedCustomer = if (existingCustomer != null) {
            existingCustomer.copy(
                name = cleanName,
                mobileNumber = cleanMobile,
                address = cleanAddress.ifBlank { existingCustomer.address },
                syncStatus = "PENDING_SYNC",
                updatedAtMillis = now
            )
        } else {
            CustomerEntity(
                customerId = "cust_${UUID.randomUUID().toString().replace("-", "").take(14)}",
                technicianUid = technicianUid,
                name = cleanName,
                mobileNumber = cleanMobile,
                address = cleanAddress,
                notes = "",
                syncStatus = "PENDING_SYNC",
                createdAtMillis = now,
                updatedAtMillis = now
            )
        }
        dao.upsertCustomer(resolvedCustomer)

        val existingInvoice = existingInvoiceId?.takeIf { it.isNotBlank() }?.let {
            dao.getInvoice(it, technicianUid)
        }

        val totalBill = BillingDomainHelper.calculateTotalBill(
            partsCharges = partsCharges,
            serviceCharges = serviceCharges,
            visitingCharges = visitingCharges,
            otherCharges = otherCharges,
            discountAmount = discountAmount
        )

        val existingPayments = existingInvoice?.let {
            dao.getPaymentsForInvoice(it.invoiceId, technicianUid)
        } ?: emptyList()

        val resolvedReceived: Double? = if (existingInvoice != null) {
            if (existingPayments.isNotEmpty()) {
                BillingDomainHelper.round2(existingPayments.sumOf { it.amount })
            } else {
                initialAmountReceived ?: existingInvoice.amountReceived
            }
        } else {
            initialAmountReceived
        }

        val remaining = BillingDomainHelper.calculateRemainingBalance(totalBill, resolvedReceived)
        val status = BillingDomainHelper.resolvePaymentStatus(totalBill, resolvedReceived)

        val invoiceId = existingInvoice?.invoiceId
            ?: "inv_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        val invoiceNumber = existingInvoice?.invoiceNumber
            ?: BillingDomainHelper.generateInvoiceNumber(
                nowMillis = now,
                randomSuffix = UUID.randomUUID().toString().replace("-", "").take(4)
            )

        val entity = InvoiceEntity(
            invoiceId = invoiceId,
            invoiceNumber = invoiceNumber,
            technicianUid = technicianUid,
            customerId = resolvedCustomer.customerId,
            customerName = cleanName,
            customerMobile = cleanMobile,
            customerAddress = cleanAddress,
            applianceCategory = applianceCategory.trim().take(60),
            applianceBrand = applianceBrand.trim().take(60),
            modelNumber = modelNumber.trim().take(80),
            serialNumber = serialNumber.trim().take(80),
            reportedProblem = reportedProblem.trim().take(600),
            workDone = workDone.trim().take(800),
            partsUsed = partsUsed.trim().take(500),
            partsQuantity = partsQuantity.coerceIn(0, 1000),
            partsCharges = partsCharges,
            serviceCharges = serviceCharges,
            visitingCharges = visitingCharges,
            otherCharges = otherCharges,
            discountAmount = discountAmount,
            totalBill = totalBill,
            amountReceived = resolvedReceived,
            remainingBalance = remaining,
            paymentStatus = status,
            paymentMethod = paymentMethod.trim().take(40),
            paymentDueDate = paymentDueDate.trim().take(32),
            warrantyInfo = warrantyInfo.trim().take(200),
            notes = notes.trim().take(500),
            reminderDate = reminderDate.trim().take(32),
            syncStatus = "PENDING_SYNC",
            createdAtMillis = existingInvoice?.createdAtMillis ?: now,
            updatedAtMillis = now
        )
        dao.upsertInvoice(entity)

        // If creating a new invoice with an upfront payment > 0, record the payment entry too
        if (existingInvoice == null && initialAmountReceived != null && initialAmountReceived > 0.0) {
            val upfrontPayment = InvoicePaymentEntity(
                paymentId = "pay_${UUID.randomUUID().toString().replace("-", "").take(14)}",
                invoiceId = invoiceId,
                technicianUid = technicianUid,
                amount = BillingDomainHelper.round2(initialAmountReceived),
                paymentMethod = paymentMethod.trim().ifBlank { "Cash" }.take(40),
                note = "Initial payment at invoice creation",
                idempotencyKey = "init_$invoiceId",
                syncStatus = "PENDING_SYNC",
                paidAtMillis = now
            )
            dao.upsertPayment(upfrontPayment)
        }

        if (isOnline) {
            syncPendingWithFirestore(technicianUid)
        }
        Result.success(entity)
    }

    suspend fun recordPayment(
        technicianUid: String,
        invoiceId: String,
        amount: Double?,
        paymentMethod: String,
        note: String,
        idempotencyKey: String,
        isOnline: Boolean
    ): Result<InvoiceEntity> = withContext(Dispatchers.IO) {
        val invoice = dao.getInvoice(invoiceId, technicianUid)
            ?: return@withContext Result.failure(IllegalStateException("Invoice not found."))
        val existing = dao.getPaymentsForInvoice(invoiceId, technicianUid)
        val keys = existing.mapNotNull { it.idempotencyKey.takeIf { k -> k.isNotBlank() } }.toSet()
        val error = BillingDomainHelper.validateNewPayment(
            amount = amount,
            currentRemaining = invoice.remainingBalance,
            existingIdempotencyKeys = keys,
            idempotencyKey = idempotencyKey
        )
        if (error != null) {
            return@withContext Result.failure(IllegalArgumentException(error))
        }

        val now = System.currentTimeMillis()
        val payment = InvoicePaymentEntity(
            paymentId = "pay_${UUID.randomUUID().toString().replace("-", "").take(14)}",
            invoiceId = invoiceId,
            technicianUid = technicianUid,
            amount = BillingDomainHelper.round2(amount!!),
            paymentMethod = paymentMethod.trim().ifBlank { "Cash" }.take(40),
            note = note.trim().take(300),
            idempotencyKey = idempotencyKey.take(80),
            syncStatus = "PENDING_SYNC",
            paidAtMillis = now
        )
        val updated = dao.recordPaymentAndRecalculate(payment)
            ?: return@withContext Result.failure(IllegalStateException("Unable to update invoice payment."))
        if (isOnline) {
            syncPendingWithFirestore(technicianUid)
        }
        Result.success(updated)
    }

    suspend fun updateReminderDate(
        technicianUid: String,
        invoiceId: String,
        reminderDate: String,
        isOnline: Boolean
    ): Result<InvoiceEntity> = withContext(Dispatchers.IO) {
        val existing = dao.getInvoice(invoiceId, technicianUid)
            ?: return@withContext Result.failure(IllegalStateException("Invoice not found."))
        val updated = existing.copy(
            reminderDate = reminderDate.trim().take(32),
            syncStatus = "PENDING_SYNC",
            updatedAtMillis = System.currentTimeMillis()
        )
        dao.upsertInvoice(updated)
        if (isOnline) {
            syncPendingWithFirestore(technicianUid)
        }
        Result.success(updated)
    }

    suspend fun deleteInvoice(technicianUid: String, invoiceId: String, isOnline: Boolean): Result<Unit> =
        withContext(Dispatchers.IO) {
            dao.deletePaymentsForInvoice(invoiceId, technicianUid)
            dao.deleteInvoice(invoiceId, technicianUid)
            if (isOnline && auth.currentUser?.uid == technicianUid) {
                runCatching {
                    val pays = db.collection("invoice_payments")
                        .whereEqualTo("technicianUid", technicianUid)
                        .whereEqualTo("invoiceId", invoiceId)
                        .get().await()
                    pays.documents.forEach { it.reference.delete().await() }
                    db.collection("invoices").document(invoiceId).delete().await()
                }
            }
            Result.success(Unit)
        }

    suspend fun syncPendingWithFirestore(technicianUid: String): Result<Int> = withContext(Dispatchers.IO) {
        val currentUid = auth.currentUser?.uid
        if (currentUid.isNullOrBlank() || currentUid != technicianUid) {
            return@withContext Result.success(0)
        }
        var syncedCount = 0
        return@withContext runCatching {
            // 1. Push pending customers
            val pendingCustomers = dao.getPendingCustomers(technicianUid)
            for (c in pendingCustomers) {
                val payload = buildCustomerPayload(c)
                db.collection("customers").document(c.customerId).set(payload).await()
                dao.upsertCustomer(c.copy(syncStatus = "SYNCED"))
                syncedCount += 1
            }

            // 2. Push pending invoices
            val pendingInvoices = dao.getPendingInvoices(technicianUid)
            for (inv in pendingInvoices) {
                val payload = buildInvoicePayload(inv)
                db.collection("invoices").document(inv.invoiceId).set(payload).await()
                dao.upsertInvoice(inv.copy(syncStatus = "SYNCED"))
                syncedCount += 1
            }

            // 3. Push pending payments (create-only in Firestore rules)
            val pendingPayments = dao.getPendingPayments(technicianUid)
            for (pay in pendingPayments) {
                val docRef = db.collection("invoice_payments").document(pay.paymentId)
                val snap = docRef.get().await()
                if (!snap.exists()) {
                    docRef.set(buildPaymentPayload(pay)).await()
                }
                dao.upsertPayment(pay.copy(syncStatus = "SYNCED"))
                syncedCount += 1
            }

            // 4. Pull remote owner records and merge safely (never overwrite local PENDING_SYNC rows)
            val remoteCustomers = db.collection("customers")
                .whereEqualTo("technicianUid", technicianUid)
                .get().await()
            val mergedCustomers = mutableListOf<CustomerEntity>()
            for (doc in remoteCustomers.documents) {
                val id = doc.getString("customerId") ?: doc.id
                val local = dao.getCustomer(id, technicianUid)
                val remoteUpdated = doc.getTimestamp("updatedAt")?.toDate()?.time ?: 0L
                if (local == null || (local.syncStatus == "SYNCED" && remoteUpdated > local.updatedAtMillis)) {
                    mergedCustomers.add(
                        CustomerEntity(
                            customerId = id,
                            technicianUid = technicianUid,
                            name = doc.getString("name").orEmpty(),
                            mobileNumber = doc.getString("mobileNumber").orEmpty(),
                            address = doc.getString("address").orEmpty(),
                            notes = doc.getString("notes").orEmpty(),
                            syncStatus = "SYNCED",
                            createdAtMillis = doc.getTimestamp("createdAt")?.toDate()?.time ?: remoteUpdated,
                            updatedAtMillis = remoteUpdated
                        )
                    )
                }
            }
            if (mergedCustomers.isNotEmpty()) dao.upsertCustomers(mergedCustomers)

            val remoteInvoices = db.collection("invoices")
                .whereEqualTo("technicianUid", technicianUid)
                .get().await()
            val mergedInvoices = mutableListOf<InvoiceEntity>()
            for (doc in remoteInvoices.documents) {
                val id = doc.getString("invoiceId") ?: doc.id
                val local = dao.getInvoice(id, technicianUid)
                val remoteUpdated = doc.getTimestamp("updatedAt")?.toDate()?.time ?: 0L
                if (local == null || (local.syncStatus == "SYNCED" && remoteUpdated > local.updatedAtMillis)) {
                    mergedInvoices.add(
                        InvoiceEntity(
                            invoiceId = id,
                            invoiceNumber = doc.getString("invoiceNumber").orEmpty(),
                            technicianUid = technicianUid,
                            customerId = doc.getString("customerId").orEmpty(),
                            customerName = doc.getString("customerName").orEmpty(),
                            customerMobile = doc.getString("customerMobile").orEmpty(),
                            customerAddress = doc.getString("customerAddress").orEmpty(),
                            applianceCategory = doc.getString("applianceCategory").orEmpty(),
                            applianceBrand = doc.getString("applianceBrand").orEmpty(),
                            modelNumber = doc.getString("modelNumber").orEmpty(),
                            serialNumber = doc.getString("serialNumber").orEmpty(),
                            reportedProblem = doc.getString("reportedProblem").orEmpty(),
                            workDone = doc.getString("workDone").orEmpty(),
                            partsUsed = doc.getString("partsUsed").orEmpty(),
                            partsQuantity = (doc.getLong("partsQuantity") ?: 0L).toInt(),
                            partsCharges = doc.getDouble("partsCharges"),
                            serviceCharges = doc.getDouble("serviceCharges"),
                            visitingCharges = doc.getDouble("visitingCharges"),
                            otherCharges = doc.getDouble("otherCharges"),
                            discountAmount = doc.getDouble("discountAmount"),
                            totalBill = doc.getDouble("totalBill"),
                            amountReceived = doc.getDouble("amountReceived"),
                            remainingBalance = doc.getDouble("remainingBalance"),
                            paymentStatus = doc.getString("paymentStatus") ?: BillingDomainHelper.STATUS_AMOUNT_NOT_ENTERED,
                            paymentMethod = doc.getString("paymentMethod").orEmpty(),
                            paymentDueDate = doc.getString("paymentDueDate").orEmpty(),
                            warrantyInfo = doc.getString("warrantyInfo").orEmpty(),
                            notes = doc.getString("notes").orEmpty(),
                            reminderDate = doc.getString("reminderDate").orEmpty(),
                            syncStatus = "SYNCED",
                            createdAtMillis = doc.getTimestamp("createdAt")?.toDate()?.time ?: remoteUpdated,
                            updatedAtMillis = remoteUpdated
                        )
                    )
                }
            }
            if (mergedInvoices.isNotEmpty()) dao.upsertInvoices(mergedInvoices)

            val remotePayments = db.collection("invoice_payments")
                .whereEqualTo("technicianUid", technicianUid)
                .get().await()
            val mergedPayments = mutableListOf<InvoicePaymentEntity>()
            for (doc in remotePayments.documents) {
                val id = doc.getString("paymentId") ?: doc.id
                mergedPayments.add(
                    InvoicePaymentEntity(
                        paymentId = id,
                        invoiceId = doc.getString("invoiceId").orEmpty(),
                        technicianUid = technicianUid,
                        amount = doc.getDouble("amount") ?: 0.0,
                        paymentMethod = doc.getString("paymentMethod") ?: "Cash",
                        note = doc.getString("note").orEmpty(),
                        idempotencyKey = doc.getString("idempotencyKey").orEmpty(),
                        syncStatus = "SYNCED",
                        paidAtMillis = doc.getTimestamp("paidAt")?.toDate()?.time ?: System.currentTimeMillis()
                    )
                )
            }
            if (mergedPayments.isNotEmpty()) dao.upsertPayments(mergedPayments)

            syncedCount
        }
    }

    private fun safePastTimestamp(millis: Long): Timestamp {
        val clamped = minOf(millis, System.currentTimeMillis())
        return Timestamp(Date(clamped))
    }

    private fun buildCustomerPayload(c: CustomerEntity): Map<String, Any> {
        val m = mutableMapOf<String, Any>(
            "customerId" to c.customerId,
            "technicianUid" to c.technicianUid,
            "name" to c.name.take(100),
            "mobileNumber" to c.mobileNumber.take(20),
            "createdAt" to safePastTimestamp(c.createdAtMillis),
            "updatedAt" to safePastTimestamp(c.updatedAtMillis)
        )
        if (c.address.isNotBlank()) m["address"] = c.address.take(300)
        if (c.notes.isNotBlank()) m["notes"] = c.notes.take(500)
        return m
    }

    private fun buildInvoicePayload(inv: InvoiceEntity): Map<String, Any> {
        val m = mutableMapOf<String, Any>(
            "invoiceId" to inv.invoiceId,
            "invoiceNumber" to inv.invoiceNumber.take(40),
            "technicianUid" to inv.technicianUid,
            "customerId" to inv.customerId,
            "customerName" to inv.customerName.take(100),
            "customerMobile" to inv.customerMobile.take(20),
            "paymentStatus" to inv.paymentStatus,
            "partsQuantity" to inv.partsQuantity.coerceIn(0, 1000),
            "createdAt" to safePastTimestamp(inv.createdAtMillis),
            "updatedAt" to safePastTimestamp(inv.updatedAtMillis)
        )
        if (inv.customerAddress.isNotBlank()) m["customerAddress"] = inv.customerAddress.take(300)
        if (inv.applianceCategory.isNotBlank()) m["applianceCategory"] = inv.applianceCategory.take(60)
        if (inv.applianceBrand.isNotBlank()) m["applianceBrand"] = inv.applianceBrand.take(60)
        if (inv.modelNumber.isNotBlank()) m["modelNumber"] = inv.modelNumber.take(80)
        if (inv.serialNumber.isNotBlank()) m["serialNumber"] = inv.serialNumber.take(80)
        if (inv.reportedProblem.isNotBlank()) m["reportedProblem"] = inv.reportedProblem.take(600)
        if (inv.workDone.isNotBlank()) m["workDone"] = inv.workDone.take(800)
        if (inv.partsUsed.isNotBlank()) m["partsUsed"] = inv.partsUsed.take(500)
        inv.partsCharges?.let { m["partsCharges"] = it }
        inv.serviceCharges?.let { m["serviceCharges"] = it }
        inv.visitingCharges?.let { m["visitingCharges"] = it }
        inv.otherCharges?.let { m["otherCharges"] = it }
        inv.discountAmount?.let { m["discountAmount"] = it }
        inv.totalBill?.let { m["totalBill"] = it }
        inv.amountReceived?.let { m["amountReceived"] = it }
        inv.remainingBalance?.let { m["remainingBalance"] = it }
        if (inv.paymentMethod.isNotBlank()) m["paymentMethod"] = inv.paymentMethod.take(40)
        if (inv.paymentDueDate.isNotBlank()) m["paymentDueDate"] = inv.paymentDueDate.take(32)
        if (inv.warrantyInfo.isNotBlank()) m["warrantyInfo"] = inv.warrantyInfo.take(200)
        if (inv.notes.isNotBlank()) m["notes"] = inv.notes.take(500)
        if (inv.reminderDate.isNotBlank()) m["reminderDate"] = inv.reminderDate.take(32)
        return m
    }

    private fun buildPaymentPayload(p: InvoicePaymentEntity): Map<String, Any> {
        val m = mutableMapOf<String, Any>(
            "paymentId" to p.paymentId,
            "invoiceId" to p.invoiceId,
            "technicianUid" to p.technicianUid,
            "amount" to p.amount,
            "paymentMethod" to p.paymentMethod.take(40),
            "paidAt" to safePastTimestamp(p.paidAtMillis)
        )
        if (p.note.isNotBlank()) m["note"] = p.note.take(300)
        if (p.idempotencyKey.isNotBlank()) m["idempotencyKey"] = p.idempotencyKey.take(80)
        return m
    }
}
