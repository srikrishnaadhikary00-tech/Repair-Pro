package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.remote.V2CloudRepository
import com.example.data.remote.ensureFirebaseInitialized
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

class RepairProMessagingService : FirebaseMessagingService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        if (!ensureFirebaseInitialized(applicationContext)) return
        val uid = try {
            Firebase.auth.currentUser?.uid
        } catch (_: Exception) {
            null
        } ?: return
        serviceScope.launch {
            try {
                V2CloudRepository(applicationContext).saveFcmToken(uid, token)
            } catch (_: Exception) {
                // Non-fatal
            }
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        ensureChannels(applicationContext)
        val title = message.notification?.title ?: message.data["title"] ?: getString(R.string.app_name)
        val body = message.notification?.body ?: message.data["body"] ?: return
        val channelId = when (message.data["channel"]?.lowercase()) {
            "community" -> CHANNEL_COMMUNITY
            "verification" -> CHANNEL_VERIFICATION
            else -> CHANNEL_ANNOUNCEMENTS
        }
        val route = message.data["route"] ?: "notifications"
        val imageUrl = message.data["imageUrl"]
            ?: message.notification?.imageUrl?.toString().orEmpty()

        if (imageUrl.startsWith("https://", ignoreCase = true)) {
            serviceScope.launch {
                val bmp = downloadBitmapSafely(imageUrl)
                showLocalNotification(applicationContext, title, body, channelId, route, bmp)
            }
        } else {
            showLocalNotification(applicationContext, title, body, channelId, route, null)
        }
    }

    companion object {
        const val CHANNEL_ANNOUNCEMENTS = "repair_pro_announcements"
        const val CHANNEL_COMMUNITY = "repair_pro_community"
        const val CHANNEL_VERIFICATION = "repair_pro_verification"
        const val EXTRA_TARGET_ROUTE = "repair_pro_target_route"

        fun ensureChannels(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_ANNOUNCEMENTS,
                    "Repair Pro Announcements",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply { description = "Admin updates, new repair guides, and safety advisories." },
                NotificationChannel(
                    CHANNEL_COMMUNITY,
                    "Technician Community",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply { description = "Post approvals, comments, and technician replies." },
                NotificationChannel(
                    CHANNEL_VERIFICATION,
                    "Technician Verification",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply { description = "Verification approval and account status updates." }
            )
            channels.forEach { manager.createNotificationChannel(it) }
        }

        fun hasNotificationPermission(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        }

        private fun downloadBitmapSafely(imageUrl: String): Bitmap? {
            if (!imageUrl.startsWith("https://", ignoreCase = true)) return null
            return runCatching {
                val conn = (URL(imageUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6000
                    readTimeout = 6000
                    doInput = true
                }
                conn.inputStream.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }

        fun showLocalNotification(
            context: Context,
            title: String,
            body: String,
            channelId: String = CHANNEL_ANNOUNCEMENTS,
            targetRoute: String = "notifications",
            bigImage: Bitmap? = null
        ) {
            if (!hasNotificationPermission(context)) return
            ensureChannels(context)
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_TARGET_ROUTE, targetRoute)
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                targetRoute.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            if (bigImage != null) {
                builder.setLargeIcon(bigImage)
                builder.setStyle(
                    NotificationCompat.BigPictureStyle()
                        .bigPicture(bigImage)
                        .setSummaryText(body)
                )
            } else {
                builder.setStyle(NotificationCompat.BigTextStyle().bigText(body))
            }

            try {
                NotificationManagerCompat.from(context).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder.build())
            } catch (_: SecurityException) {
                // Permission revoked between check and notify
            }
        }

        fun syncCurrentFcmToken(context: Context, userId: String) {
            if (userId.isBlank() || !ensureFirebaseInitialized(context)) return
            try {
                FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                    if (!token.isNullOrBlank()) {
                        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                            try {
                                V2CloudRepository(context.applicationContext).saveFcmToken(userId, token)
                            } catch (_: Exception) {
                                // Non-fatal
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                // Safe in Robolectric or environments without Play Services
            }
        }

        fun unregisterCurrentFcmToken(context: Context, userId: String) {
            if (userId.isBlank() || !ensureFirebaseInitialized(context)) return
            try {
                FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                    if (!token.isNullOrBlank()) {
                        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                            try {
                                V2CloudRepository(context.applicationContext).deleteFcmToken(userId, token)
                            } catch (_: Exception) {
                                // Non-fatal
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                // Safe in environments without Play Services
            }
        }
    }
}
