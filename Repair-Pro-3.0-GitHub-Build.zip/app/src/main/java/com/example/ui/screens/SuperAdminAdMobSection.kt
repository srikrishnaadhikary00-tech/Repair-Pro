package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdsClick
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.ads.AdMobManager
import com.example.data.remote.AppSettingCloud
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun SuperAdminAdMobSection(
    currentConfig: AppSettingCloud,
    onSaveConfig: (AppSettingCloud) -> Unit
) {
    var draft by remember(currentConfig) { mutableStateOf(currentConfig) }
    var subTab by remember { mutableIntStateOf(0) } // 0=General, 1=AC, 2=Fridge, 3=Washing

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CyanAccent,
        unfocusedBorderColor = CardBorderSubtle,
        focusedTextColor = TextPrimaryWhite,
        unfocusedTextColor = TextPrimaryWhite,
        focusedContainerColor = DeepCardSurface,
        unfocusedContainerColor = DeepCardSurface
    )

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Header Card matching reference AdMob Control Panel
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ElevatedCardSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.AdsClick, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(26.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Google AdMob — Ads Control",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimaryWhite
                        )
                        Text(
                            text = "Remote visibility, frequency cap & unit ID controls",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate
                        )
                    }
                }

                val hasValidProdAppId = AdMobManager.isValidProductionAppId(BuildConfig.ADMOB_APP_ID)
                val hasValidProdBanner = AdMobManager.isValidProductionUnitId(draft.androidBannerId)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = (if (hasValidProdAppId && hasValidProdBanner) SuccessGreen else WarningAmber).copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, (if (hasValidProdAppId && hasValidProdBanner) SuccessGreen else WarningAmber).copy(alpha = 0.45f))
                ) {
                    Text(
                        text = if (hasValidProdAppId && hasValidProdBanner) {
                            "Build App ID & Production Units Verified (${BuildConfig.ADMOB_APP_ID.take(24)}…)"
                        } else {
                            "Build App ID: ${if (hasValidProdAppId) "Production Ready" else "Google Test ID Active"} • Production ads remain suppressed in release builds until ADMOB_APP_ID & non-test unit IDs are configured."
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (hasValidProdAppId && hasValidProdBanner) SuccessGreen else WarningAmber,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }

                AdToggleRow(
                    title = "Enable All Ads (Global Master)",
                    subtitle = "Master switch for all app ad placements",
                    checked = draft.adsGlobalEnabled,
                    testTagName = "admob_global_switch",
                    onCheckedChange = { draft = draft.copy(adsGlobalEnabled = it) }
                )

                // Emergency Kill Switch
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = ErrorCrimson.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.55f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = ErrorCrimson, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Emergency Kill Switch", style = MaterialTheme.typography.labelLarge, color = ErrorCrimson)
                            Text("Immediately hides all ads across all screens", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        }
                        Switch(
                            checked = draft.emergencyKillSwitch,
                            onCheckedChange = { draft = draft.copy(emergencyKillSwitch = it) },
                            modifier = Modifier.testTag("admob_kill_switch"),
                            colors = SwitchDefaults.colors(checkedThumbColor = TextPrimaryWhite, checkedTrackColor = ErrorCrimson)
                        )
                    }
                }
            }
        }

        // Category Tabs matching reference: General | AC | Fridge | Washing
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(DeepCardSurface)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("General", "AC", "Fridge", "Washing").forEachIndexed { idx, label ->
                val selected = subTab == idx
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { subTab = idx }
                        .testTag("admob_tab_$idx"),
                    color = if (selected) ElectricBluePrimary else Color.Transparent,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) TextPrimaryWhite else TextSecondarySlate,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(vertical = 9.dp, horizontal = 6.dp)
                    )
                }
            }
        }

        when (subTab) {
            0 -> {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = SecondaryNavySurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CardBorderSubtle)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        AdToggleRow("Banner Ads", "Bottom non-intrusive banner placements", draft.bannerEnabled, "admob_banner_switch") {
                            draft = draft.copy(bannerEnabled = it)
                        }
                        AdToggleRow("Interstitial Ads", "Respects cooldown & never interrupts safety alerts", draft.interstitialEnabled, "admob_interstitial_switch") {
                            draft = draft.copy(interstitialEnabled = it)
                        }
                        AdToggleRow("Rewarded Ads", "Optional user-initiated bonus actions", draft.rewardedEnabled, "admob_rewarded_switch") {
                            draft = draft.copy(rewardedEnabled = it)
                        }
                        AdToggleRow("Native Ads", "In-feed native card placement", draft.nativeEnabled, "admob_native_switch") {
                            draft = draft.copy(nativeEnabled = it)
                        }
                        AdToggleRow("App Open Ads", "Respects 15-min cooldown on app resume", draft.appOpenEnabled, "admob_app_open_switch") {
                            draft = draft.copy(appOpenEnabled = it)
                        }
                        AdToggleRow("Test Mode (Development)", "Uses official Google AdMob test ad units", draft.testMode, "admob_test_mode_switch") {
                            draft = draft.copy(testMode = it)
                        }

                        // Interstitial Cooldown selector
                        Text("Ad Frequency (Interstitial Cooldown)", style = MaterialTheme.typography.labelLarge, color = CyanAccent)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(1L, 3L, 5L, 10L, 15L).forEach { mins ->
                                FilterChip(
                                    selected = draft.interstitialCooldownMin == mins,
                                    onClick = { draft = draft.copy(interstitialCooldownMin = mins) },
                                    label = { Text("Every $mins min") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ElectricBluePrimary,
                                        selectedLabelColor = TextPrimaryWhite,
                                        containerColor = DeepCardSurface,
                                        labelColor = TextSecondarySlate
                                    )
                                )
                            }
                        }

                        Text("Session Frequency Cap", style = MaterialTheme.typography.labelLarge, color = CyanAccent)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(3L, 6L, 10L).forEach { cap ->
                                FilterChip(
                                    selected = draft.sessionFrequencyCap == cap,
                                    onClick = { draft = draft.copy(sessionFrequencyCap = cap) },
                                    label = { Text("Max $cap / session") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ElectricBluePrimary,
                                        selectedLabelColor = TextPrimaryWhite,
                                        containerColor = DeepCardSurface,
                                        labelColor = TextSecondarySlate
                                    )
                                )
                            }
                        }
                    }
                }

                // Unit IDs Configuration
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = SecondaryNavySurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CardBorderSubtle)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Android & iOS Ad Unit IDs", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
                        OutlinedTextField(
                            value = draft.androidAppId,
                            onValueChange = { draft = draft.copy(androidAppId = it.take(120)) },
                            label = { Text("Android App ID (Requires rebuild for Manifest)") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = draft.androidBannerId,
                            onValueChange = { draft = draft.copy(androidBannerId = it.take(120)) },
                            label = { Text("Android Banner Ad Unit ID") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = draft.androidInterstitialId,
                            onValueChange = { draft = draft.copy(androidInterstitialId = it.take(120)) },
                            label = { Text("Android Interstitial Ad Unit ID") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = draft.androidRewardedId,
                            onValueChange = { draft = draft.copy(androidRewardedId = it.take(120)) },
                            label = { Text("Android Rewarded Ad Unit ID") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = draft.androidNativeId,
                            onValueChange = { draft = draft.copy(androidNativeId = it.take(120)) },
                            label = { Text("Android Native Ad Unit ID") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = draft.androidAppOpenId,
                            onValueChange = { draft = draft.copy(androidAppOpenId = it.take(120)) },
                            label = { Text("Android App Open Ad Unit ID") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = draft.iosAppId,
                            onValueChange = { draft = draft.copy(iosAppId = it.take(120)) },
                            label = { Text("iOS App ID (Requires Info.plist rebuild)") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = draft.iosBannerId,
                            onValueChange = { draft = draft.copy(iosBannerId = it.take(120)) },
                            label = { Text("iOS Banner Ad Unit ID") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            1 -> CategoryAdControlCard(
                categoryTitle = "Air Conditioner (AC) Screens",
                enabled = draft.acAdsEnabled,
                onToggle = { draft = draft.copy(acAdsEnabled = it) }
            )
            2 -> CategoryAdControlCard(
                categoryTitle = "Refrigerator (Fridge) Screens",
                enabled = draft.fridgeAdsEnabled,
                onToggle = { draft = draft.copy(fridgeAdsEnabled = it) }
            )
            3 -> CategoryAdControlCard(
                categoryTitle = "Washing Machine Screens",
                enabled = draft.washerAdsEnabled,
                onToggle = { draft = draft.copy(washerAdsEnabled = it) }
            )
        }

        // Honest Platform & AdMob Reporting Notice
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = WarningAmber.copy(alpha = 0.12f),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.45f))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(Icons.Filled.Info, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(18.dp))
                Text(
                    text = "Visibility switches, frequency caps, and ad unit IDs sync remotely in real time via Firestore. Changing the Android Manifest App ID or iOS Info.plist App ID requires a new store build. Live impressions and earnings require connecting Google AdMob Reporting API in your AdMob account.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate
                )
            }
        }

        Button(
            onClick = { onSaveConfig(draft) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("admob_save_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
        ) {
            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Save & Publish AdMob Config", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CategoryAdControlCard(
    categoryTitle: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SecondaryNavySurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            AdToggleRow(
                title = "Show Ads on $categoryTitle",
                subtitle = "Controls category directory, brand list, and filtered search banners",
                checked = enabled,
                testTagName = "admob_cat_toggle",
                onCheckedChange = onToggle
            )
            Text(
                text = "Policy Guardrail: Ads are automatically suppressed offline and never injected inside electrical or refrigerant safety warnings.",
                style = MaterialTheme.typography.bodySmall,
                color = SuccessGreen
            )
        }
    }
}

@Composable
private fun AdToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    testTagName: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTagName),
            colors = SwitchDefaults.colors(
                checkedThumbColor = TextPrimaryWhite,
                checkedTrackColor = ElectricBluePrimary
            )
        )
    }
}
