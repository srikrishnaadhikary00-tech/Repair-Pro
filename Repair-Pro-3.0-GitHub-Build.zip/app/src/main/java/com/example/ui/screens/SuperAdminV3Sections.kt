package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.remote.BackendConnectionStatus
import com.example.data.remote.CommunityPostItem
import com.example.data.remote.PushNotificationItem
import com.example.data.remote.RepairDocumentItem
import com.example.data.remote.StorageProviderItem
import com.example.data.remote.SystemErrorLogItem
import com.example.data.remote.TechnicianProfileItem
import com.example.data.remote.UserProfileCloud
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
private fun adminFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = CyanAccent,
    unfocusedBorderColor = CardBorderSubtle,
    focusedTextColor = TextPrimaryWhite,
    unfocusedTextColor = TextPrimaryWhite,
    focusedContainerColor = DeepCardSurface,
    unfocusedContainerColor = DeepCardSurface
)

/**
 * Push Notification Center (Admin Section) — Session-safe by design:
 * Sending or encountering backend HTTP 401/403/500 NEVER logs out or redirects the admin.
 */
@Composable
fun AdminPushNotificationSection(
    notifications: List<PushNotificationItem>,
    busy: Boolean,
    onSendPush: (title: String, body: String, targetType: String, targetUids: List<String>) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var targetType by remember { mutableStateOf("ALL") }
    var targetUidsText by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SecondaryNavySurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = CyanAccent)
                    Text("Push Notification Center (FCM v1)", style = MaterialTheme.typography.titleMedium, color = TextPrimaryWhite)
                }
                Text(
                    "Session-safe delivery: backend errors display inline and never end your Super Admin session.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SuccessGreen
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ALL" to "All Users", "TECHNICIANS" to "Technicians", "SELECTED" to "Selected UIDs").forEach { (id, label) ->
                        FilterChip(
                            selected = targetType == id,
                            onClick = { targetType = id },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricBluePrimary,
                                selectedLabelColor = TextPrimaryWhite,
                                containerColor = DeepCardSurface,
                                labelColor = TextSecondarySlate
                            )
                        )
                    }
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it.take(120) },
                    label = { Text("Notification Title") },
                    singleLine = true,
                    colors = adminFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("admin_push_title_input")
                )
                OutlinedTextField(
                    value = body,
                    onValueChange = { body = it.take(500) },
                    label = { Text("Notification Message") },
                    minLines = 2,
                    colors = adminFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("admin_push_body_input")
                )
                if (targetType == "SELECTED") {
                    OutlinedTextField(
                        value = targetUidsText,
                        onValueChange = { targetUidsText = it },
                        label = { Text("Target Firebase UIDs (comma-separated)") },
                        singleLine = true,
                        colors = adminFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Button(
                    enabled = !busy && title.isNotBlank() && body.isNotBlank(),
                    onClick = {
                        val uids = targetUidsText.split(",").map { it.trim() }.filter { it.isNotBlank() }
                        onSendPush(title.trim(), body.trim(), targetType, uids)
                        title = ""
                        body = ""
                    },
                    modifier = Modifier.fillMaxWidth().testTag("admin_send_push_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (busy) "Sending…" else "Send Push Notification", fontWeight = FontWeight.Bold)
                }
            }
        }

        Text("Delivery History (${notifications.size})", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
        notifications.take(15).forEach { n ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CardBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(n.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                        Text(n.deliveryStatus, style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    }
                    Text(n.body, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                    Text("Target: ${n.targetType} • Sent: ${n.successCount} • Failed: ${n.failureCount}", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate)
                }
            }
        }
    }
}

@Composable
fun AdminTechniciansSection(
    technicians: List<TechnicianProfileItem>,
    onManageTechnician: (techId: String, approvalStatus: String?, verified: Boolean?, active: Boolean?, blocked: Boolean?) -> Unit,
    onInspectVerificationDoc: (techId: String, onUrlReady: (String) -> Unit) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Technician Applications & Directory (${technicians.size})", style = MaterialTheme.typography.titleMedium, color = CyanAccent)
        if (technicians.isEmpty()) {
            Text("No technician profiles submitted yet.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
        }
        technicians.forEach { tech ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, if (tech.verified) SuccessGreen.copy(alpha = 0.5f) else CardBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(tech.fullName, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                            if (tech.verified) Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = CyanAccent, modifier = Modifier.size(16.dp))
                        }
                        Text(tech.approvalStatus, style = MaterialTheme.typography.labelSmall, color = if (tech.approvalStatus == "APPROVED") SuccessGreen else WarningAmber)
                    }
                    Text("${tech.city} • ${tech.serviceLocation} • ${tech.experienceYears} yrs • ${tech.publicPhone}", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                    Text("Categories: ${tech.applianceCategories.joinToString(", ").uppercase()} • Private Verification Docs Protected", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        Button(
                            onClick = { onManageTechnician(tech.id, "APPROVED", true, true, false) },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = DeepCardSurface),
                            shape = RoundedCornerShape(8.dp)
                        ) { Text("Approve & Verify", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
                        OutlinedButton(
                            onClick = { onManageTechnician(tech.id, "REJECTED", false, false, null) },
                            shape = RoundedCornerShape(8.dp)
                        ) { Text("Reject", color = WarningAmber, style = MaterialTheme.typography.labelSmall) }
                        OutlinedButton(
                            onClick = {
                                onInspectVerificationDoc(tech.id) { signedUrl ->
                                    runCatching {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(signedUrl)))
                                    }
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, CyanAccent)
                        ) { Text("Inspect ID", color = CyanAccent, style = MaterialTheme.typography.labelSmall) }
                        OutlinedButton(
                            onClick = { onManageTechnician(tech.id, null, null, !tech.blocked, !tech.blocked) },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.6f))
                        ) { Text(if (tech.blocked) "Unblock" else "Block", color = ErrorCrimson, style = MaterialTheme.typography.labelSmall) }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminCommunityModerationSection(
    posts: List<CommunityPostItem>,
    onModeratePost: (postId: String, status: String) -> Unit,
    onDeletePost: (postId: String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Community Posts Moderation (${posts.size})", style = MaterialTheme.typography.titleMedium, color = CyanAccent)
        if (posts.isEmpty()) {
            Text("No community posts yet.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
        }
        posts.forEach { post ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CardBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(post.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, modifier = Modifier.weight(1f))
                        Text(post.moderationStatus, style = MaterialTheme.typography.labelSmall, color = if (post.moderationStatus == "APPROVED") SuccessGreen else WarningAmber)
                    }
                    Text("By ${post.authorName} • ${post.categoryId.uppercase()} • Likes: ${post.likesCount} • Comments: ${post.commentsCount}", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    Text(post.body, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onModeratePost(post.id, "APPROVED") }) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Approve", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(onClick = { onModeratePost(post.id, "REJECTED") }) {
                            Text("Reject / Hide", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = { onDeletePost(post.id) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete post", tint = ErrorCrimson)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminDocumentsSection(
    documents: List<RepairDocumentItem>,
    busy: Boolean,
    onSaveDocument: (RepairDocumentItem, Uri?, () -> Unit) -> Unit,
    onDeleteDocument: (String) -> Unit
) {
    var docType by remember { mutableStateOf("PDF") }
    var categoryId by remember { mutableStateOf("ac") }
    var brandName by remember { mutableStateOf("") }
    var modelName by remember { mutableStateOf("") }
    var errorCode by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var fileUrl by remember { mutableStateOf("") }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        pickedUri = uri
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SecondaryNavySurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Upload / Publish PDF or Circuit Diagram", style = MaterialTheme.typography.titleMedium, color = CyanAccent)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("PDF" to "PDF Manual", "CIRCUIT_DIAGRAM" to "Circuit Diagram").forEach { (id, label) ->
                        FilterChip(selected = docType == id, onClick = { docType = id }, label = { Text(label) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                        FilterChip(selected = categoryId == id, onClick = { categoryId = id }, label = { Text(label) })
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it.take(160) }, label = { Text("Document Title *") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = brandName, onValueChange = { brandName = it.take(60) }, label = { Text("Brand") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = modelName, onValueChange = { modelName = it.take(60) }, label = { Text("Model") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = errorCode, onValueChange = { errorCode = it.uppercase().take(32) }, label = { Text("Related Error Code (optional)") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it.take(400) }, label = { Text("Description") }, minLines = 2, colors = adminFieldColors(), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = fileUrl, onValueChange = { fileUrl = it.take(500) }, label = { Text("Direct File URL (or pick file below)") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.fillMaxWidth())
                OutlinedButton(
                    onClick = { filePicker.launch(if (docType == "PDF") "application/pdf" else "image/*") },
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, CyanAccent)
                ) {
                    Icon(Icons.Filled.AttachFile, contentDescription = null, tint = CyanAccent)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (pickedUri == null) "Pick ${if (docType == "PDF") "PDF" else "Diagram Image"} to Upload via Multi-Cloud" else "File Selected (Ready to Upload)", color = TextPrimaryWhite)
                }
                Button(
                    enabled = !busy && title.isNotBlank() && (fileUrl.isNotBlank() || pickedUri != null),
                    onClick = {
                        onSaveDocument(
                            RepairDocumentItem(
                                docType = docType,
                                categoryId = categoryId,
                                brandName = brandName.trim(),
                                modelName = modelName.trim(),
                                errorCode = errorCode.trim(),
                                title = title.trim(),
                                description = description.trim(),
                                fileUrl = fileUrl.trim(),
                                published = true
                            ),
                            pickedUri
                        ) {
                            title = ""
                            brandName = ""
                            modelName = ""
                            errorCode = ""
                            description = ""
                            fileUrl = ""
                            pickedUri = null
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Publish Document", fontWeight = FontWeight.Bold)
                }
            }
        }

        Text("Published & Draft Documents (${documents.size})", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
        documents.forEach { doc ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CardBorderSubtle)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(doc.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                        Text("${doc.docType} • ${doc.categoryId.uppercase()} • ${doc.brandName} • ${if (doc.published) "PUBLISHED" else "DRAFT"}", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    }
                    Switch(
                        checked = doc.published,
                        onCheckedChange = { onSaveDocument(doc.copy(published = it), null) {} },
                        colors = SwitchDefaults.colors(checkedTrackColor = SuccessGreen)
                    )
                    IconButton(onClick = { onDeleteDocument(doc.id) }) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete document", tint = ErrorCrimson)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminMultiCloudStorageSection(
    providers: List<StorageProviderItem>,
    connectionStatus: BackendConnectionStatus,
    errorLogs: List<SystemErrorLogItem>,
    busy: Boolean,
    onSaveProvider: (StorageProviderItem) -> Unit,
    onTestProvider: (StorageProviderItem) -> Unit,
    onRefreshHealth: () -> Unit,
    onStorageAction: (StorageProviderItem, String) -> Unit = { _, _ -> },
    onMigrateProvider: (StorageProviderItem, String) -> Unit = { _, _ -> }
) {
    var editingId by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var providerType by remember { mutableStateOf("SUPABASE") }
    var endpointUrl by remember { mutableStateOf("") }
    var bucketName by remember { mutableStateOf("") }
    var region by remember { mutableStateOf("auto") }
    var publicBaseUrl by remember { mutableStateOf("") }
    var secretRefKey by remember { mutableStateOf("") }
    var quotaMb by remember { mutableStateOf("1024") }

    fun resetForm() {
        editingId = ""
        name = ""
        providerType = "SUPABASE"
        endpointUrl = ""
        bucketName = ""
        region = "auto"
        publicBaseUrl = ""
        secretRefKey = ""
        quotaMb = "1024"
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Firebase & Supabase Live Health Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ElevatedCardSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Backend Connection Health (v${BuildConfig.VERSION_NAME})", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
                    IconButton(onClick = onRefreshHealth) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh status", tint = CyanAccent)
                    }
                }
                Text("Firebase Project: gen-lang-client-0218221723 (${if (connectionStatus.firebaseConnected) "CONNECTED" else "CHECK"})", style = MaterialTheme.typography.bodySmall, color = SuccessGreen)
                Text("Supabase Ref: ${BuildConfig.SUPABASE_PROJECT_REF} (${if (connectionStatus.supabaseReachable) "REACHABLE" else "PENDING KEY / DEPLOY"})", style = MaterialTheme.typography.bodySmall, color = if (connectionStatus.supabaseReachable) SuccessGreen else WarningAmber)
                Text(connectionStatus.supabaseMessage, style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate)
            }
        }

        // Add / Edit External Storage Provider
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SecondaryNavySurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, CardBorderSubtle)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.CloudQueue, contentDescription = null, tint = CyanAccent)
                        Text(
                            if (editingId.isNotBlank()) "Edit Storage Provider" else "Multi-Cloud Storage Manager",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimaryWhite
                        )
                    }
                    if (editingId.isNotBlank()) {
                        OutlinedButton(onClick = { resetForm() }) {
                            Text("Cancel Edit", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Text(
                    "Authoritative Supabase Edge Registry: routes uploads automatically on quota/timeout errors without APK updates (never bypasses 401/403). Secrets reside strictly in Supabase Secrets.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate
                )
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("SUPABASE", "CLOUDFLARE_R2", "BACKBLAZE_B2", "CUSTOM_S3").forEach { t ->
                        FilterChip(selected = providerType == t, onClick = { providerType = t }, label = { Text(t) })
                    }
                }
                OutlinedTextField(value = name, onValueChange = { name = it.take(80) }, label = { Text("Provider Display Name *") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = endpointUrl, onValueChange = { endpointUrl = it.take(250) }, label = { Text("HTTPS Endpoint URL *") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = bucketName, onValueChange = { bucketName = it.take(80) }, label = { Text("Bucket / Project Ref") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = region, onValueChange = { region = it.take(40) }, label = { Text("Region") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = quotaMb, onValueChange = { quotaMb = it.filter(Char::isDigit).take(7) }, label = { Text("Quota MB") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = secretRefKey, onValueChange = { secretRefKey = it.take(80) }, label = { Text("Server Secret Env Ref") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = publicBaseUrl, onValueChange = { publicBaseUrl = it.take(250) }, label = { Text("Public CDN / Base URL (optional, public buckets only)") }, singleLine = true, colors = adminFieldColors(), modifier = Modifier.fillMaxWidth())
                Button(
                    enabled = !busy && name.isNotBlank() && endpointUrl.isNotBlank(),
                    onClick = {
                        val capBytes = (quotaMb.toLongOrNull() ?: 1024L).coerceAtLeast(50L) * 1024L * 1024L
                        val existing = providers.find { it.id == editingId }
                        val defaultSecret = when (providerType) {
                            "SUPABASE" -> "SUPABASE_SERVICE_ROLE_KEY"
                            "CLOUDFLARE_R2" -> "R2_STORAGE_CREDS"
                            "BACKBLAZE_B2" -> "B2_STORAGE_CREDS"
                            else -> "S3_STORAGE_CREDS"
                        }
                        onSaveProvider(
                            StorageProviderItem(
                                id = editingId,
                                name = name.trim(),
                                providerType = providerType,
                                endpointUrl = endpointUrl.trim(),
                                projectRef = bucketName.trim().ifBlank { "default" },
                                region = region.trim().ifBlank { if (providerType == "CLOUDFLARE_R2") "auto" else "us-east-1" },
                                publicBaseUrl = publicBaseUrl.trim(),
                                secretEnvKey = secretRefKey.trim().ifBlank { defaultSecret },
                                capacityBytes = capBytes,
                                primary = existing?.primary ?: providers.isEmpty(),
                                backup = existing?.backup ?: providers.isNotEmpty(),
                                enabled = existing?.enabled ?: true,
                                autoFailoverEnabled = existing?.autoFailoverEnabled ?: true
                            )
                        )
                        resetForm()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                ) {
                    Text(if (editingId.isNotBlank()) "Save Provider Changes" else "Save Storage Provider", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Configured Providers List
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Configured Storage Providers (${providers.size})", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
            OutlinedButton(enabled = !busy, onClick = onRefreshHealth) {
                Text("Sync Registry", color = CyanAccent, style = MaterialTheme.typography.labelSmall)
            }
        }
        if (providers.isEmpty()) {
            Text(
                "No authoritative storage providers synced yet. Ensure SUPABASE_ANON_KEY is set and tap Sync Registry.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondarySlate
            )
        }
        providers.forEach { p ->
            val usedMb = p.usedBytes / (1024L * 1024L)
            val totalMb = (p.capacityBytes / (1024L * 1024L)).coerceAtLeast(1L)
            val secretLabel = when (p.secretConfigured) {
                true -> "Secret OK"
                false -> "Secret Missing (${p.secretEnvKey})"
                null -> "Secret: ${p.secretEnvKey}"
            }
            val migrationTargets = providers.filter { it.id != p.id && it.enabled }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, if (p.primary) SuccessGreen.copy(alpha = 0.6f) else CardBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("${p.name} (${p.providerType})", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                        Text(
                            if (p.primary) "PRIMARY" else if (p.backup) "BACKUP" else "STANDBY",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (p.primary) SuccessGreen else CyanAccent
                        )
                    }
                    Text("${p.endpointUrl} • Bucket: ${p.projectRef} • Region: ${p.region} • Active Files: ${p.activeFilesCount} • $usedMb/$totalMb MB", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                    Text(
                        "$secretLabel • Failover: ${if (p.autoFailoverEnabled) "ON" else "OFF"} • ${if (p.enabled) "ENABLED" else "DISABLED"} • Health: ${p.lastTestStatus} ${if (p.lastTestMessage.isNotBlank()) "— ${p.lastTestMessage}" else ""}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (p.secretConfigured == false) WarningAmber else CyanAccent
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        OutlinedButton(enabled = !busy, onClick = {
                            editingId = p.id
                            name = p.name
                            providerType = p.providerType
                            endpointUrl = p.endpointUrl
                            bucketName = p.projectRef
                            region = p.region
                            publicBaseUrl = p.publicBaseUrl
                            secretRefKey = p.secretEnvKey
                            quotaMb = totalMb.toString()
                        }) {
                            Text("Edit", color = TextPrimaryWhite, style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(enabled = !busy, onClick = { onTestProvider(p) }) {
                            Text("Test Connection", color = CyanAccent, style = MaterialTheme.typography.labelSmall)
                        }
                        if (!p.primary) {
                            OutlinedButton(enabled = !busy, onClick = { onStorageAction(p, "SET_PRIMARY") }) {
                                Text("Set Primary", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        if (!p.backup && !p.primary) {
                            OutlinedButton(enabled = !busy, onClick = { onStorageAction(p, "SET_BACKUP") }) {
                                Text("Set Backup", color = CyanAccent, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        OutlinedButton(enabled = !busy, onClick = { onStorageAction(p, "TOGGLE_FAILOVER") }) {
                            Text(if (p.autoFailoverEnabled) "Failover Off" else "Failover On", color = TextPrimaryWhite, style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(enabled = !busy, onClick = { onStorageAction(p, "TOGGLE_ENABLED") }) {
                            Text(if (p.enabled) "Disable" else "Enable", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                        }
                        if (p.activeFilesCount > 0 && migrationTargets.isNotEmpty()) {
                            migrationTargets.forEach { target ->
                                OutlinedButton(
                                    enabled = !busy,
                                    onClick = { onMigrateProvider(p, target.id) },
                                    border = BorderStroke(1.dp, CyanAccent)
                                ) {
                                    Text("Migrate → ${target.name}", color = CyanAccent, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                        if (!p.primary) {
                            OutlinedButton(
                                enabled = !busy && p.activeFilesCount == 0,
                                onClick = { onStorageAction(p, "DELETE") },
                                border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    if (p.activeFilesCount > 0) "Delete (${p.activeFilesCount} files)" else "Delete",
                                    color = if (p.activeFilesCount > 0) TextSecondarySlate else ErrorCrimson,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
        }

        if (errorLogs.isNotEmpty()) {
            Text("Recent System Error Logs (${errorLogs.size})", style = MaterialTheme.typography.titleSmall, color = WarningAmber)
            errorLogs.take(10).forEach { err ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = SecondaryNavySurface,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("${err.source} • ${err.severity}", style = MaterialTheme.typography.labelMedium, color = ErrorCrimson)
                        Text(err.message, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminUsersManagementSection(
    users: List<UserProfileCloud>,
    onSetBlocked: (uid: String, blocked: Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Registered Users (${users.size})", style = MaterialTheme.typography.titleMedium, color = CyanAccent)
        if (users.isEmpty()) {
            Text("No user profiles synced yet.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
        }
        users.forEach { u ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (u.isBlocked) ErrorCrimson.copy(alpha = 0.6f) else CardBorderSubtle)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(u.displayName.ifBlank { "Repair Pro User" }, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                        Text("${u.email} • Lang: ${u.preferredLanguage.uppercase()}", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        if (u.isBlocked) Text("BLOCKED", style = MaterialTheme.typography.labelSmall, color = ErrorCrimson, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { onSetBlocked(u.id, !u.isBlocked) },
                        border = BorderStroke(1.dp, if (u.isBlocked) SuccessGreen else ErrorCrimson)
                    ) {
                        Icon(Icons.Filled.Block, contentDescription = null, tint = if (u.isBlocked) SuccessGreen else ErrorCrimson, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (u.isBlocked) "Unblock" else "Block", color = if (u.isBlocked) SuccessGreen else ErrorCrimson, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
