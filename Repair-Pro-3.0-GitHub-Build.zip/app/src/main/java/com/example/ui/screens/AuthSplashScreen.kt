package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.data.remote.attemptAutoSignIn
import com.example.data.remote.onGoogleSignInClicked
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.ui.components.LanguageSwitcherRow
import com.example.ui.components.LiquidGlassAnimatedEnter
import com.example.ui.components.LiquidGlassBackground
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.RepairProBrandLogo
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun AuthSplashScreen(
    selectedLanguage: AppLanguage,
    onSelectLanguage: (AppLanguage) -> Unit,
    onAuthSuccess: () -> Unit,
    onAdminPortalRequested: () -> Unit = {},
    firebaseConfigured: Boolean = true
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val strings = StringsProvider.get(selectedLanguage)
    val palette = LiquidGlassTheme.colors

    LaunchedEffect(firebaseConfigured) {
        if (firebaseConfigured) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = onAuthSuccess,
                onUnauthenticated = { /* Show interactive Sign in with Google button */ },
                scope = scope
            )
        }
    }

    LiquidGlassBackground(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                LiquidGlassAnimatedEnter {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(modifier = Modifier.height(10.dp))
                        RepairProBrandLogo()
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = strings.tagline,
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(18.dp))

                        // 3D Liquid Glass Appliances Hero Showcase
                        LiquidGlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(26.dp),
                            elevated = true,
                            accentBorder = true,
                            contentPadding = 6.dp
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.liquid_glass_hero_splash_1795701645608),
                                contentDescription = "Air Conditioner, Refrigerator, and Washing Machine",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(182.dp)
                                    .clip(RoundedCornerShape(20.dp))
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Language Picker
                        Text(
                            text = strings.chooseLanguage,
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LanguageSwitcherRow(
                            currentLanguage = selectedLanguage,
                            onSelect = onSelectLanguage
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Translucent Glass Feature Highlights Card
                        LiquidGlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(22.dp),
                            elevated = true,
                            contentPadding = 16.dp
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                listOf(
                                    strings.featureErrorCodes,
                                    strings.featureProblems,
                                    strings.featureRepairGuides,
                                    strings.featureOnlineCommunity
                                ).forEach { feature ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = null,
                                            tint = palette.primaryAccent,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = feature,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = palette.textPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val hasClientIdIssue = com.example.data.remote.resolveDefaultWebClientId(context) == null
                    if (!firebaseConfigured || hasClientIdIssue) {
                        LiquidGlassCard(
                            shape = RoundedCornerShape(18.dp),
                            elevated = true,
                            customBorderColor = palette.secondaryAccent.copy(alpha = 0.55f),
                            contentPadding = 12.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("firebase_setup_required_card")
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = if (!firebaseConfigured) {
                                        "Firebase Setup Needed (google-services.json)"
                                    } else {
                                        "OAuth Web Client ID Needed"
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = palette.primaryAccent,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (!firebaseConfigured) {
                                        "Provide your original google-services.json for project gen-lang-client-0218221723 (package com.aistudio.repairpro.kxmvqz) inside app/ to enable Google Sign-In and Push Notifications."
                                    } else {
                                        "Set FIREBASE_WEB_CLIENT_ID in AI Studio Secrets to a valid OAuth 2.0 Web Client ID (*.apps.googleusercontent.com), not an AIza API key."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary
                                )
                            }
                        }
                    }
                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.error,
                            textAlign = TextAlign.Center
                        )
                    }

                    Button(
                        onClick = {
                            errorMessage = null
                            isLoading = true
                            onGoogleSignInClicked(
                                context = context,
                                credentialManager = credentialManager,
                                onAuthSuccess = {
                                    isLoading = false
                                    onAuthSuccess()
                                },
                                onAuthError = { msg ->
                                    isLoading = false
                                    errorMessage = msg
                                },
                                scope = scope,
                                onAuthCancelled = {
                                    isLoading = false
                                }
                            )
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("google_sign_in_button"),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.primaryAccent,
                            contentColor = palette.onPrimaryAccent
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = palette.onPrimaryAccent,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = strings.signInWithGoogle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            errorMessage = null
                            isLoading = true
                            onAdminPortalRequested()
                            onGoogleSignInClicked(
                                context = context,
                                credentialManager = credentialManager,
                                onAuthSuccess = {
                                    isLoading = false
                                    onAuthSuccess()
                                },
                                onAuthError = { msg ->
                                    isLoading = false
                                    errorMessage = msg
                                },
                                scope = scope,
                                onAuthCancelled = {
                                    isLoading = false
                                }
                            )
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("super_admin_portal_sign_in_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = palette.glassFill,
                            contentColor = palette.primaryAccent
                        ),
                        border = BorderStroke(1.dp, palette.primaryAccent.copy(alpha = 0.45f))
                    ) {
                        Text(
                            text = "${strings.superAdminPanel} — Sign In",
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.primaryAccent
                        )
                    }

                    Text(
                        text = strings.welcomeSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
