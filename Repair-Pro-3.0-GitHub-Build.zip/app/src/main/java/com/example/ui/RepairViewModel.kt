package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.RepairRepository
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.BrandEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.OfflinePackageEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.local.SearchHistoryEntity
import com.example.data.remote.AdminRoleCloud
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.AuditLogCloud
import com.example.data.remote.CatalogEntryCloud
import com.example.data.remote.ProblemReportCloud
import com.example.data.remote.SavedGuideCloud
import com.example.i18n.AppLanguage
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class RepairViewModel(
    private val repository: RepairRepository,
    val currentUserId: String,
    val userDisplayName: String,
    val userEmail: String,
    initialLanguage: AppLanguage = AppLanguage.EN
) : ViewModel() {

    private val _language = MutableStateFlow(initialLanguage)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _isOnline = MutableStateFlow(repository.isNetworkAvailable())
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _isAdmin = MutableStateFlow(repository.cloud.isCurrentUserBootstrapAdmin())
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private val _isBootstrapAdmin = MutableStateFlow(repository.cloud.isCurrentUserBootstrapAdmin())
    val isBootstrapAdmin: StateFlow<Boolean> = _isBootstrapAdmin.asStateFlow()

    private val _adminRoleChecked = MutableStateFlow(false)
    val adminRoleChecked: StateFlow<Boolean> = _adminRoleChecked.asStateFlow()

    private val _adConsentGranted = MutableStateFlow(true)
    val adConsentGranted: StateFlow<Boolean> = _adConsentGranted.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _syncInProgress = MutableStateFlow(false)
    val syncInProgress: StateFlow<Boolean> = _syncInProgress.asStateFlow()

    private val _lastCloudSyncTime = MutableStateFlow<Long?>(null)
    val lastCloudSyncTime: StateFlow<Long?> = _lastCloudSyncTime.asStateFlow()

    val categories: StateFlow<List<ApplianceCategoryEntity>> = repository.categories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val brands: StateFlow<List<BrandEntity>> = repository.allBrands
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val errorCodes: StateFlow<List<ErrorCodeEntity>> = repository.allErrorCodes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val problems: StateFlow<List<ProblemGuideEntity>> = repository.allProblems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val searchHistory: StateFlow<List<SearchHistoryEntity>> = repository.searchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val offlinePackages: StateFlow<List<OfflinePackageEntity>> = repository.offlinePackages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val savedGuides: StateFlow<List<SavedGuideCloud>> = safeCloudFlow(
        source = repository.cloud.observeSavedGuides(currentUserId),
        fallback = emptyList(),
        label = "saved_guides"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val userReports: StateFlow<List<ProblemReportCloud>> = safeCloudFlow(
        source = repository.cloud.observeUserProblemReports(currentUserId),
        fallback = emptyList(),
        label = "user_reports"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val publishedCloudCatalog: StateFlow<List<CatalogEntryCloud>> = safeCloudFlow(
        source = repository.cloud.observePublishedCatalog(currentUserId),
        fallback = emptyList(),
        label = "published_catalog"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adMobConfig: StateFlow<AppSettingCloud> = safeCloudFlow(
        source = repository.cloud.observeAdMobConfig(currentUserId),
        fallback = AppSettingCloud(id = "admob_config", configType = "ADMOB"),
        label = "admob_config"
    ).stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000L),
        AppSettingCloud(id = "admob_config", configType = "ADMOB")
    )

    val globalConfig: StateFlow<AppSettingCloud> = safeCloudFlow(
        source = repository.cloud.observeGlobalConfig(currentUserId),
        fallback = AppSettingCloud(id = "global_config", configType = "GLOBAL"),
        label = "global_config"
    ).stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000L),
        AppSettingCloud(id = "global_config", configType = "GLOBAL")
    )

    // Admin-only streams: only attach when _isAdmin is true so non-admins never trigger PERMISSION_DENIED
    val adminAllReports: StateFlow<List<ProblemReportCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.cloud.observeAllProblemReportsForAdmin(currentUserId),
                emptyList(),
                "admin_reports"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminAllCatalog: StateFlow<List<CatalogEntryCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.cloud.observeAllCatalogForAdmin(currentUserId),
                emptyList(),
                "admin_catalog"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminAuditLogs: StateFlow<List<AuditLogCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.cloud.observeAuditLogsForAdmin(currentUserId),
                emptyList(),
                "audit_logs"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminRoles: StateFlow<List<AdminRoleCloud>> = _isBootstrapAdmin
        .flatMapLatest { bootstrap ->
            if (bootstrap) safeCloudFlow(
                repository.cloud.observeAdminRolesForBootstrapAdmin(currentUserId),
                emptyList(),
                "admins"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val totalModelCount: StateFlow<Int> = brands
        .combine(categories) { brandList, _ ->
            brandList.sumOf { brand ->
                brand.modelsCsv.split(",").count { it.isNotBlank() }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0)

    init {
        viewModelScope.launch {
            repository.ensureOfflineDatabaseSeeded()
            _isOnline.value = repository.isNetworkAvailable()
            repository.cloud.ensureUserProfile(
                userId = currentUserId,
                displayName = userDisplayName,
                preferredLanguage = _language.value.code
            )
            _isBootstrapAdmin.value = repository.cloud.isCurrentUserBootstrapAdmin()
            _isAdmin.value = repository.cloud.checkIsAdmin(currentUserId)
            _adminRoleChecked.value = true
        }
        // Keep user profile preferences synced
        viewModelScope.launch {
            safeCloudFlow(repository.cloud.observeUserProfile(currentUserId), null, "profile")
                .collect { profile ->
                    if (profile != null) {
                        _adConsentGranted.value = profile.adConsentGranted
                    }
                }
        }
        // Automatically merge published cloud catalog into offline Room DB
        viewModelScope.launch {
            publishedCloudCatalog.collect { entries ->
                if (entries.isNotEmpty()) {
                    repository.mergeCloudCatalogIntoOfflineDb(entries)
                    _lastCloudSyncTime.value = System.currentTimeMillis()
                }
            }
        }
    }

    private fun <T> safeCloudFlow(source: Flow<T>, fallback: T, label: String): Flow<T> {
        return source.catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Cloud stream error ($label): ${(firestoreError ?: error).message}")
            emit(fallback)
        }
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
        viewModelScope.launch {
            repository.cloud.updateUserPreferences(currentUserId, preferredLanguage = lang.code)
        }
    }

    fun setAdConsent(granted: Boolean) {
        _adConsentGranted.value = granted
        viewModelScope.launch {
            val res = repository.cloud.updateUserPreferences(currentUserId, adConsentGranted = granted)
            if (res.isSuccess) {
                _statusBanner.value = if (granted) "Personalized ad consent updated" else "Non-personalized ads enabled"
            }
        }
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun recordSearch(query: String, categoryId: String? = null) {
        viewModelScope.launch {
            repository.recordSearch(query, categoryId)
        }
    }

    fun clearSearchHistory() {
        viewModelScope.launch {
            repository.clearSearchHistory()
        }
    }

    fun isGuideSaved(itemType: String, itemId: String): Boolean {
        return savedGuides.value.any { it.itemType == itemType && it.itemId == itemId }
    }

    fun toggleSavedGuide(
        itemType: String,
        itemId: String,
        categoryId: String,
        title: String,
        subtitle: String
    ) {
        viewModelScope.launch {
            val existing = savedGuides.value.firstOrNull { it.itemType == itemType && it.itemId == itemId }
            val result = if (existing != null) {
                repository.cloud.removeSavedGuide(currentUserId, existing.id)
            } else {
                repository.cloud.saveGuide(currentUserId, itemType, itemId, categoryId, title, subtitle)
            }
            if (result.isFailure) {
                _statusBanner.value = "Sync failed: ${result.exceptionOrNull()?.localizedMessage ?: "Offline"}"
            } else {
                _statusBanner.value = if (existing != null) "Removed from Saved Guides" else "Saved for quick access"
            }
        }
    }

    fun syncOfflineDatabase() {
        viewModelScope.launch {
            _syncInProgress.value = true
            _isOnline.value = repository.isNetworkAvailable()
            try {
                repository.ensureOfflineDatabaseSeeded()
                val merged = repository.mergeCloudCatalogIntoOfflineDb(publishedCloudCatalog.value)
                _lastCloudSyncTime.value = System.currentTimeMillis()
                _statusBanner.value = if (_isOnline.value) {
                    "Offline database verified & synced ($merged cloud updates merged)"
                } else {
                    "Offline mode active — local SQLite database is ready for airplane mode"
                }
            } finally {
                _syncInProgress.value = false
            }
        }
    }

    fun toggleOfflinePackage(categoryId: String, downloaded: Boolean) {
        viewModelScope.launch {
            repository.toggleOfflinePackage(categoryId, downloaded)
            _statusBanner.value = if (downloaded) "Offline pack updated & verified" else "Offline pack paused"
        }
    }

    fun submitProblemReport(
        categoryId: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        description: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.cloud.submitProblemReport(
                userId = currentUserId,
                categoryId = categoryId,
                brandName = brandName,
                modelName = modelName,
                errorCode = errorCode,
                description = description,
                preferredLanguage = _language.value.code
            )
            if (result.isSuccess) {
                _statusBanner.value = "Problem report submitted successfully!"
                onSuccess()
            } else {
                _statusBanner.value = result.exceptionOrNull()?.localizedMessage ?: "Unable to submit report"
            }
        }
    }

    // --- SUPER ADMIN MUTATIONS ---
    fun adminUpdateReportStatus(reportId: String, newStatus: String, adminNote: String) {
        viewModelScope.launch {
            val res = repository.cloud.updateProblemReportStatus(reportId, newStatus, adminNote)
            _statusBanner.value = if (res.isSuccess) "Report marked $newStatus" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminPublishCatalogEntry(entry: CatalogEntryCloud, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.cloud.publishCatalogEntry(entry)
            if (res.isSuccess) {
                _statusBanner.value = "Published '${entry.titleEn}' to cloud & offline sync"
                onDone()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to publish entry"
            }
        }
    }

    fun adminDeleteCatalogEntry(entryId: String) {
        viewModelScope.launch {
            val res = repository.cloud.deleteCatalogEntry(entryId)
            _statusBanner.value = if (res.isSuccess) "Catalog entry removed" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminSaveAdMobConfig(config: AppSettingCloud) {
        viewModelScope.launch {
            val res = repository.cloud.saveAdMobConfig(config)
            if (res.isSuccess) {
                com.example.data.remote.SupabaseApiClient.syncRemoteSettings(admobConfig = config)
            }
            _statusBanner.value = if (res.isSuccess) "AdMob remote settings saved & audited" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminSaveGlobalConfig(
        announcement: String,
        maintenanceNotice: String,
        minVersion: String,
        storageAutoFailover: Boolean = true
    ) {
        viewModelScope.launch {
            val res = repository.cloud.saveGlobalConfig(
                announcement = announcement,
                maintenanceNotice = maintenanceNotice,
                minSupportedVersion = minVersion,
                storageAutoFailover = storageAutoFailover
            )
            if (res.isSuccess) {
                com.example.data.remote.SupabaseApiClient.syncRemoteSettings(
                    announcement = announcement,
                    maintenanceNotice = maintenanceNotice,
                    minSupportedVersion = minVersion,
                    storageAutoFailover = storageAutoFailover
                )
            }
            _statusBanner.value = if (res.isSuccess) "Remote App Settings updated" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminUpsertRole(targetUid: String, role: String) {
        viewModelScope.launch {
            val res = repository.cloud.upsertAdminRole(targetUid, role)
            _statusBanner.value = if (res.isSuccess) "Admin role ($role) saved in Firestore" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminRevokeRole(targetUid: String) {
        viewModelScope.launch {
            val res = repository.cloud.removeAdminRole(targetUid)
            _statusBanner.value = if (res.isSuccess) "Admin role revoked" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun exportCatalogBackupJson(): String {
        return repository.exportCatalogAsJson(errorCodes.value, problems.value)
    }

    fun deleteMyCloudData(onDeleted: () -> Unit) {
        viewModelScope.launch {
            val res = repository.cloud.deleteUserCloudData(currentUserId)
            if (res.isSuccess) {
                _statusBanner.value = "Cloud profile, bookmarks, and reports deleted."
                onDeleted()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Deletion failed"
            }
        }
    }

    companion object {
        private const val TAG = "RepairViewModel"
    }
}
