package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.DownloadedDocumentEntity
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.RepairDocumentItem
import com.example.ui.components.AdMobNativeSlot
import com.example.ui.components.AuroraGlassCard
import com.example.ui.components.AuroraGlowingDownloadButton
import com.example.ui.components.AuroraPdfBadgeIcon
import com.example.ui.components.AuroraPillFilter
import com.example.ui.components.OfflinePdfViewerDialog
import com.example.ui.components.ZoomableImageDialog
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanBorderGradient
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.PurpleBorderGradient
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import java.io.File
import java.util.Locale

@Composable
fun DocumentsLibraryScreen(
    publishedDocs: List<RepairDocumentItem>,
    downloadedDocs: List<DownloadedDocumentEntity>,
    busy: Boolean,
    onBack: () -> Unit,
    onDownloadOffline: (RepairDocumentItem) -> Unit,
    onDeleteOffline: (DownloadedDocumentEntity) -> Unit,
    initialTypeFilter: String = "ALL",
    adMobConfig: AppSettingCloud = AppSettingCloud(id = "admob_config", configType = "ADMOB", nativeEnabled = false),
    isOnline: Boolean = true,
    adConsentGranted: Boolean = true
) {
    var activeTab by remember { mutableIntStateOf(0) } // 0 = Library, 1 = Offline Saved
    var typeFilter by remember(initialTypeFilter) { mutableStateOf(initialTypeFilter) } // ALL, PDF, CIRCUIT_DIAGRAM
    var categoryFilter by remember { mutableStateOf("all") } // all, ac, fridge, washer
    var showSearchBar by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    var activePdfToView by remember { mutableStateOf<Pair<String, String>?>(null) }
    var activeDiagramToView by remember { mutableStateOf<Pair<Any, String>?>(null) }

    val downloadedMap = remember(downloadedDocs) { downloadedDocs.associateBy { it.docId } }

    val filteredCloud = remember(publishedDocs, typeFilter, categoryFilter, searchQuery) {
        val q = searchQuery.trim().lowercase()
        publishedDocs.filter { doc ->
            (typeFilter == "ALL" || doc.docType.equals(typeFilter, ignoreCase = true)) &&
                (categoryFilter == "all" || doc.categoryId.equals(categoryFilter, ignoreCase = true)) &&
                (q.isEmpty() ||
                    doc.title.lowercase().contains(q) ||
                    doc.brandName.lowercase().contains(q) ||
                    doc.modelName.lowercase().contains(q) ||
                    doc.errorCode.lowercase().contains(q) ||
                    doc.description.lowercase().contains(q))
        }
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CyanAccent,
        unfocusedBorderColor = CardBorderSubtle,
        focusedTextColor = TextPrimaryWhite,
        unfocusedTextColor = TextPrimaryWhite,
        focusedContainerColor = DeepCardSurface,
        unfocusedContainerColor = DeepCardSurface
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("documents_library_screen"),
        contentPadding = PaddingValues(top = 8.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header: Back | PDF Manuals | Search
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("documents_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Text(
                    text = if (typeFilter == "CIRCUIT_DIAGRAM") "Circuit Diagrams" else "PDF Manuals",
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = { showSearchBar = !showSearchBar },
                    modifier = Modifier.testTag("documents_search_toggle")
                ) {
                    Icon(
                        imageVector = if (showSearchBar) Icons.Filled.Close else Icons.Filled.Search,
                        contentDescription = "Search manuals",
                        tint = CyanAccent
                    )
                }
            }
        }

        // Toggleable Aurora Search Bar
        item {
            AnimatedVisibility(visible = showSearchBar || searchQuery.isNotEmpty()) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search brand, model, error code or manual…") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = CyanAccent) },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("documents_search_input")
                )
            }
        }

        // Appliance Category Filter Pills matching Reference Screen 5: AC | Refrigerator | Washing Machine
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AuroraPillFilter(
                    label = "All",
                    selected = categoryFilter == "all" && activeTab == 0,
                    onClick = {
                        activeTab = 0
                        categoryFilter = "all"
                    }
                )
                AuroraPillFilter(
                    label = "AC",
                    selected = categoryFilter == "ac" && activeTab == 0,
                    onClick = {
                        activeTab = 0
                        categoryFilter = "ac"
                    }
                )
                AuroraPillFilter(
                    label = "Refrigerator",
                    selected = categoryFilter == "fridge" && activeTab == 0,
                    onClick = {
                        activeTab = 0
                        categoryFilter = "fridge"
                    }
                )
                AuroraPillFilter(
                    label = "Washing Machine",
                    selected = categoryFilter == "washer" && activeTab == 0,
                    onClick = {
                        activeTab = 0
                        categoryFilter = "washer"
                    }
                )
            }
        }

        // Sub-filter row: Library / Offline Ready + All Files / PDFs / Circuit Diagrams
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AuroraPillFilter(
                    label = "Cloud Library (${publishedDocs.size})",
                    selected = activeTab == 0 && typeFilter == "ALL",
                    onClick = { activeTab = 0; typeFilter = "ALL" },
                    modifier = Modifier.testTag("docs_tab_cloud")
                )
                AuroraPillFilter(
                    label = "PDFs",
                    selected = activeTab == 0 && typeFilter == "PDF",
                    onClick = { activeTab = 0; typeFilter = "PDF" }
                )
                AuroraPillFilter(
                    label = "Circuit Diagrams",
                    selected = activeTab == 0 && typeFilter == "CIRCUIT_DIAGRAM",
                    onClick = { activeTab = 0; typeFilter = "CIRCUIT_DIAGRAM" }
                )
                AuroraPillFilter(
                    label = "Offline (${downloadedDocs.size})",
                    leadingIcon = Icons.Filled.OfflinePin,
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    modifier = Modifier.testTag("docs_tab_offline")
                )
            }
        }

        if (activeTab == 0) {
            if (filteredCloud.isEmpty()) {
                item {
                    AuroraGlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Description, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(38.dp))
                            Text("No published manuals or circuit diagrams match this filter.", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                            Text(
                                "Super Admins can publish PDF manuals & circuit schematics from the Admin Panel.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                        }
                    }
                }
            } else {
                items(filteredCloud, key = { it.id }) { doc ->
                    val offlineCopy = downloadedMap[doc.id]
                    val isDiagram = doc.docType.equals("CIRCUIT_DIAGRAM", ignoreCase = true)
                    val sizeText = formatFileSize(doc.fileSizeBytes)
                    val subtitleMeta = listOfNotNull(
                        doc.modelName.takeIf { it.isNotBlank() } ?: doc.brandName.takeIf { it.isNotBlank() },
                        sizeText
                    ).joinToString(" • ")

                    AuroraGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 18.dp,
                        borderBrush = if (offlineCopy != null) CyanBorderGradient else PurpleBorderGradient,
                        onClick = {
                            if (isDiagram) {
                                val model: Any = if (offlineCopy != null && File(offlineCopy.localFilePath).exists()) {
                                    File(offlineCopy.localFilePath)
                                } else doc.fileUrl
                                activeDiagramToView = model to doc.title
                            } else if (offlineCopy != null && File(offlineCopy.localFilePath).exists()) {
                                activePdfToView = offlineCopy.localFilePath to doc.title
                            }
                        }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (isDiagram) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Brush.linearGradient(listOf(ElectricBluePrimary.copy(alpha = 0.35f), CyanAccent.copy(alpha = 0.25f))))
                                        .border(1.dp, CyanAccent.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Filled.Memory, contentDescription = "Circuit Diagram", tint = CyanAccent, modifier = Modifier.size(24.dp))
                                }
                            } else {
                                AuroraPdfBadgeIcon(size = 44.dp)
                            }

                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(
                                    text = doc.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimaryWhite,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = subtitleMeta.ifBlank { "${doc.brandName} • ${doc.categoryId.uppercase()}" },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyanAccent,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (doc.description.isNotBlank()) {
                                    Text(
                                        text = doc.description,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondarySlate,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            if (offlineCopy != null && File(offlineCopy.localFilePath).exists()) {
                                Button(
                                    onClick = {
                                        if (isDiagram) activeDiagramToView = File(offlineCopy.localFilePath) to doc.title
                                        else activePdfToView = offlineCopy.localFilePath to doc.title
                                    },
                                    shape = RoundedCornerShape(50),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = DeepCardSurface)
                                ) {
                                    Icon(
                                        imageVector = if (isDiagram) Icons.Filled.Visibility else Icons.Filled.PictureAsPdf,
                                        contentDescription = null,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Open", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                AuroraGlowingDownloadButton(
                                    onClick = { onDownloadOffline(doc) },
                                    enabled = !busy && doc.fileUrl.isNotBlank(),
                                    contentDescription = "Download ${doc.title}"
                                )
                            }
                        }
                    }
                }
            }
            item {
                AdMobNativeSlot(
                    config = adMobConfig,
                    categoryId = if (categoryFilter == "all") null else categoryFilter,
                    isOnline = isOnline,
                    consentGranted = adConsentGranted,
                    screenTag = "documents"
                )
            }
        } else {
            if (downloadedDocs.isEmpty()) {
                item {
                    AuroraGlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.OfflinePin, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(36.dp))
                            Text("No offline PDFs or circuit diagrams saved yet.", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                            Text("Tap the glowing download button on any manual to read it offline anytime.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        }
                    }
                }
            } else {
                items(downloadedDocs, key = { it.docId }) { localDoc ->
                    val isDiagram = localDoc.docType.equals("CIRCUIT_DIAGRAM", ignoreCase = true)
                    AuroraGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 18.dp,
                        borderBrush = CyanBorderGradient
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (isDiagram) {
                                Icon(Icons.Filled.Memory, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(30.dp))
                            } else {
                                AuroraPdfBadgeIcon(size = 40.dp)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(localDoc.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    text = "${localDoc.categoryId.uppercase()} • ${localDoc.brandName} • ${formatFileSize(localDoc.fileSizeBytes)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanAccent
                                )
                            }
                            Button(
                                onClick = {
                                    if (isDiagram) activeDiagramToView = File(localDoc.localFilePath) to localDoc.title
                                    else activePdfToView = localDoc.localFilePath to localDoc.title
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                                shape = RoundedCornerShape(50),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text("Open", fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { onDeleteOffline(localDoc) }) {
                                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete offline file", tint = ErrorCrimson)
                            }
                        }
                    }
                }
            }
        }
    }

    activePdfToView?.let { (path, title) ->
        OfflinePdfViewerDialog(
            filePath = path,
            title = title,
            onDismiss = { activePdfToView = null }
        )
    }

    activeDiagramToView?.let { (model, title) ->
        ZoomableImageDialog(
            imageModel = model,
            title = title,
            onDismiss = { activeDiagramToView = null }
        )
    }
}

private fun formatFileSize(bytes: Long): String {
    if (bytes <= 0L) return "PDF"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1.0) {
        String.format(Locale.US, "%.1f MB", mb)
    } else {
        "${(bytes / 1024L).coerceAtLeast(1L)} KB"
    }
}
