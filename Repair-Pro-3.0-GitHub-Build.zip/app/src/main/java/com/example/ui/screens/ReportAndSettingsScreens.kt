package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalLaundryService
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.ProblemReportCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.ui.components.LanguageSwitcherRow
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.RepairProTopHeader
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun ReportProblemScreen(
    language: AppLanguage,
    myReports: List<ProblemReportCloud>,
    onBack: () -> Unit,
    onSubmitReport: (
        categoryId: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        description: String,
        onSuccess: () -> Unit
    ) -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val strings = StringsProvider.get(language)
    var categoryId by remember { mutableStateOf("ac") }
    var brandName by remember { mutableStateOf("") }
    var modelName by remember { mutableStateOf("") }
    var errorCode by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var validationError by remember { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> selectedPhotoUri = uri }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = strings.reportProblemTitle,
                onBack = onBack,
                backTestTag = "report_back_button"
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                    val selected = categoryId == id
                    FilterChip(
                        selected = selected,
                        onClick = { categoryId = id },
                        label = { Text(label) },
                        colors = liquidGlassFilterChipColors(),
                        border = liquidGlassFilterChipBorder(selected),
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            }
        }

        item {
            val fieldColors = liquidGlassFieldColors()
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                elevated = true,
                contentPadding = 16.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = brandName,
                        onValueChange = { brandName = it.take(80) },
                        label = { Text(strings.reportBrandLabel) },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("report_brand_input")
                    )
                    OutlinedTextField(
                        value = modelName,
                        onValueChange = { modelName = it.take(100) },
                        label = { Text(strings.reportModelLabel) },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = errorCode,
                        onValueChange = { errorCode = it.uppercase().take(32) },
                        label = { Text(strings.reportCodeLabel) },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it.take(1500) },
                        label = { Text(strings.reportDescLabel) },
                        minLines = 3,
                        maxLines = 5,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("report_description_input")
                    )

                    OutlinedButton(
                        onClick = {
                            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, palette.glassBorderAccent)
                    ) {
                        Icon(Icons.Filled.PhotoLibrary, contentDescription = null, tint = palette.primaryAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (selectedPhotoUri == null) "Attach Optional Reference Photo (Local Preview)" else "Change Attached Photo",
                            color = palette.textPrimary
                        )
                    }

                    if (selectedPhotoUri != null) {
                        AsyncImage(
                            model = selectedPhotoUri,
                            contentDescription = "Attached photo preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                    }

                    if (validationError != null) {
                        Text(validationError!!, style = MaterialTheme.typography.bodySmall, color = palette.error)
                    }

                    Button(
                        onClick = {
                            when {
                                brandName.trim().isEmpty() -> validationError = "Please enter the appliance brand."
                                description.trim().length < 5 -> validationError = "Please describe the problem (at least 5 characters)."
                                else -> {
                                    validationError = null
                                    onSubmitReport(categoryId, brandName, modelName, errorCode, description) {
                                        brandName = ""
                                        modelName = ""
                                        errorCode = ""
                                        description = ""
                                        selectedPhotoUri = null
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("submit_report_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.primaryAccent,
                            contentColor = palette.onPrimaryAccent
                        )
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.submitReport, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (myReports.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Text(strings.myReports, style = MaterialTheme.typography.titleMedium, color = palette.primaryAccent, fontWeight = FontWeight.Bold)
            }
            items(myReports, key = { it.id }) { rep ->
                val statusColor = when (rep.status) {
                    "PUBLISHED" -> palette.success
                    "REVIEWED" -> palette.primaryAccent
                    else -> palette.warning
                }
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    elevated = true,
                    contentPadding = 14.dp
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${rep.brandName} (${rep.categoryId.uppercase()})${if (rep.errorCode.isNotBlank()) " • ${rep.errorCode}" else ""}",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                color = statusColor.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, statusColor.copy(alpha = 0.35f))
                            ) {
                                Text(
                                    text = rep.status,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = statusColor,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Text(rep.description, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        if (rep.adminNote.isNotBlank()) {
                            Text(
                                text = "Technician Note: ${rep.adminNote}",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.success
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Reference Screen 8: More / User Profile Menu (Online-Only — zero offline download UI).
 */
@Composable
fun SettingsScreen(
    language: AppLanguage,
    userDisplayName: String,
    userEmail: String,
    userPhotoUrl: String = "",
    isVerifiedTechnician: Boolean = false,
    verificationStatus: String = "",
    unreadNotificationCount: Int = 0,
    isAdmin: Boolean,
    adConsentGranted: Boolean,
    aiEnabled: Boolean = true,
    billingEnabled: Boolean = true,
    onOpenMenu: () -> Unit = {},
    onSelectLanguage: (AppLanguage) -> Unit,
    onToggleAdConsent: (Boolean) -> Unit,
    onOpenVerification: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenWasherGuides: () -> Unit,
    onOpenDocuments: () -> Unit,
    onOpenTechnicians: () -> Unit,
    onOpenSavedGuides: () -> Unit,
    onOpenMyPosts: () -> Unit,
    onOpenWizard: () -> Unit,
    onOpenReportProblem: () -> Unit,
    onOpenAiAssistant: () -> Unit = {},
    onOpenBilling: () -> Unit = {},
    onOpenAdminConsole: () -> Unit,
    onDeleteCloudData: () -> Unit,
    onSignOut: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val strings = StringsProvider.get(language)
    var activeLegalDialog by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 6.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            RepairProTopHeader(
                subtitle = strings.navMore,
                userName = userDisplayName,
                userPhotoUrl = userPhotoUrl,
                unreadNotifications = unreadNotificationCount,
                onOpenMenu = onOpenMenu,
                onOpenNotifications = onOpenNotifications,
                onOpenProfile = {}
            )
        }

        // Signed-in User Profile Card
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevated = true,
                accentBorder = true,
                contentPadding = 16.dp
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(palette.primaryAccent.copy(alpha = 0.16f))
                            .border(1.5.dp, palette.glassBorderAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (userPhotoUrl.startsWith("https://")) {
                            AsyncImage(
                                model = userPhotoUrl,
                                contentDescription = userDisplayName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(56.dp).clip(CircleShape)
                            )
                        } else {
                            Text(
                                text = userDisplayName.trim().take(1).uppercase().ifBlank { "R" },
                                style = MaterialTheme.typography.titleLarge,
                                color = palette.primaryAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(userDisplayName, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary, fontWeight = FontWeight.Bold)
                            if (isVerifiedTechnician) {
                                Icon(Icons.Filled.Verified, contentDescription = "Verified Technician", tint = palette.success, modifier = Modifier.size(18.dp))
                            }
                        }
                        Text(userEmail, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (isVerifiedTechnician) {
                                Surface(color = palette.success.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp)) {
                                    Text(
                                        text = "VERIFIED TECHNICIAN",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.success,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            if (isAdmin) {
                                Surface(color = palette.primaryAccent.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp)) {
                                    Text(
                                        text = "SUPER ADMIN",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.primaryAccent,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Super Admin Console Entry (Visible for Admin)
        if (isAdmin) {
            item {
                SettingsRowCard(
                    icon = Icons.Filled.AdminPanelSettings,
                    title = strings.superAdminPanel,
                    subtitle = "Manage Guides, Verifications, Community, PDFs, Notifications & AdMob",
                    accent = palette.primaryAccent,
                    testTagName = "settings_admin_console",
                    onClick = onOpenAdminConsole
                )
            }
        }

        // Phase 2 AI & Billing Tools
        if (aiEnabled) {
            item {
                SettingsRowCard(
                    icon = Icons.Filled.AutoAwesome,
                    title = strings.aiTitle,
                    subtitle = strings.aiSubtitle,
                    accent = palette.primaryAccent,
                    testTagName = "settings_ai_assistant",
                    onClick = onOpenAiAssistant
                )
            }
        }
        if (billingEnabled) {
            item {
                SettingsRowCard(
                    icon = Icons.Filled.ReceiptLong,
                    title = strings.billingTitle,
                    subtitle = strings.billingSubtitle,
                    accent = palette.success,
                    testTagName = "settings_billing",
                    onClick = onOpenBilling
                )
            }
        }

        // Primary V2.0 Tools & Account Menu
        item {
            SettingsRowCard(
                icon = Icons.Filled.VerifiedUser,
                title = strings.technicianVerificationTitle,
                subtitle = when (verificationStatus.uppercase()) {
                    "VERIFIED" -> "Approved — Verified Technician Badge Active"
                    "PENDING" -> "Application under Super Admin review"
                    "REJECTED" -> "Action required — view rejection reason & reapply"
                    "SUSPENDED" -> "Verification suspended — view status"
                    else -> "Apply to get a Verified Technician badge & directory listing"
                },
                accent = palette.success,
                testTagName = "settings_technician_verification",
                onClick = onOpenVerification
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.Notifications,
                title = strings.notificationsTitle,
                subtitle = if (unreadNotificationCount > 0) "$unreadNotificationCount unread updates & announcements" else "Inbox, community replies & admin announcements",
                accent = palette.primaryAccent,
                testTagName = "settings_notifications",
                onClick = onOpenNotifications
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.LocalLaundryService,
                title = "Washing Machine Guides",
                subtitle = "Front load, top load & semi-automatic error codes and repairs",
                accent = palette.secondaryAccent,
                testTagName = "settings_washer_guides",
                onClick = onOpenWasherGuides
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.Description,
                title = strings.pdfAndDiagramsTitle,
                subtitle = "View online service manuals, PCB photos & circuit diagrams",
                accent = palette.warning,
                testTagName = "settings_technical_documents",
                onClick = onOpenDocuments
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.Engineering,
                title = strings.findTechnicianTitle,
                subtitle = "Browse verified local AC, Fridge & Washer technicians",
                accent = palette.success,
                testTagName = "settings_find_technicians",
                onClick = onOpenTechnicians
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.Bookmark,
                title = strings.savedGuides,
                subtitle = "Your cloud-bookmarked error codes & repair guides",
                accent = palette.primaryAccent,
                testTagName = "settings_saved_guides",
                onClick = onOpenSavedGuides
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.Forum,
                title = "My Community Posts",
                subtitle = "Track pending, approved & bookmarked community discussions",
                accent = palette.secondaryAccent,
                testTagName = "settings_my_community_posts",
                onClick = onOpenMyPosts
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.AutoFixHigh,
                title = strings.wizardTitle,
                subtitle = "Step-by-step interactive symptom troubleshooting",
                accent = palette.primaryAccent,
                testTagName = "settings_wizard",
                onClick = onOpenWizard
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.ReportProblem,
                title = "${strings.reportProblemTitle} / ${strings.myReports}",
                subtitle = "Submit an unlisted error code or track your submitted reports",
                accent = palette.warning,
                testTagName = "settings_report_problem",
                onClick = onOpenReportProblem
            )
        }

        // Language Selection
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                elevated = true,
                contentPadding = 16.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.languageSetting, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                    LanguageSwitcherRow(currentLanguage = language, onSelect = onSelectLanguage)
                }
            }
        }

        // Advertising Privacy & Consent Control
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                elevated = true,
                contentPadding = 14.dp
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(strings.adPrivacyConsent, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (adConsentGranted) "Personalized ads permitted (UMP compliant)" else "Non-personalized ads only",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                    Switch(
                        checked = adConsentGranted,
                        onCheckedChange = onToggleAdConsent,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = palette.onPrimaryAccent,
                            checkedTrackColor = palette.primaryAccent
                        )
                    )
                }
            }
        }

        // Legal & About Links
        item {
            SettingsRowCard(
                icon = Icons.Filled.Policy,
                title = strings.privacyPolicy,
                subtitle = "Data safety, camera OCR, credential security & Google Sign-In",
                accent = palette.primaryAccent,
                testTagName = "settings_privacy_policy",
                onClick = { activeLegalDialog = "privacy" }
            )
        }
        item {
            SettingsRowCard(
                icon = Icons.Filled.Info,
                title = "${strings.aboutApp} & ${strings.termsOfUse}",
                subtitle = "Repair Pro V2.0 • Online Repair Platform & Safety Disclaimer",
                accent = palette.primaryAccent,
                testTagName = "settings_about_app",
                onClick = { activeLegalDialog = "about" }
            )
        }

        // Delete Cloud Data & Sign Out
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("settings_delete_data_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, palette.error.copy(alpha = 0.6f))
                ) {
                    Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = palette.error, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Delete Data", color = palette.error, style = MaterialTheme.typography.labelMedium)
                }
                Button(
                    onClick = onSignOut,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("settings_sign_out_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.glassFillElevated,
                        contentColor = palette.textPrimary
                    )
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.signOut, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }

    if (activeLegalDialog != null) {
        val isPrivacy = activeLegalDialog == "privacy"
        AlertDialog(
            onDismissRequest = { activeLegalDialog = null },
            containerColor = palette.dialogSurface,
            title = {
                Text(
                    text = if (isPrivacy) strings.privacyPolicy else "${strings.aboutApp} & ${strings.termsOfUse}",
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isPrivacy) {
                        "Repair Pro V2.0 Privacy & Data Safety Policy:\n\n" +
                            "1. Camera Permission: Used strictly on-device via ML Kit OCR to recognize appliance display error codes. Camera frames are never uploaded without user action.\n" +
                            "2. Photo & PDF Picker: Uses zero-permission Android Photo Picker & System Document Picker.\n" +
                            "3. Private Verification Documents: Technician verification IDs/certificates are stored in private Firebase Storage readable only by the applicant and Super Admin.\n" +
                            "4. Online-Only Content: Repair guides, manuals, and circuit diagrams are streamed online so users always receive verified, up-to-date safety guidance.\n" +
                            "5. Advertising Consent: You may switch between personalized and non-personalized ads anytime in More -> Ad Privacy & Consent.\n" +
                            "6. Data Deletion: Tap 'Delete Data' to permanently erase your cloud profile, bookmarks, and submitted reports."
                    } else {
                        "Repair Pro V2.0 — Online Multilingual Home Appliance Repair Platform\n\n" +
                            "Languages: English, বাংলা (Bengali), हिन्दी (Hindi).\n" +
                            "Categories: Air Conditioner, Refrigerator, Washing Machine.\n\n" +
                            "Safety & Liability Terms:\n" +
                            "Repair Pro clearly separates safe user maintenance checks from hazardous high-voltage, PCB, and pressurized refrigerant repairs. Always disconnect mains power before servicing any appliance and hire a verified licensed technician for electrical or gas work."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = { activeLegalDialog = null }) {
                    Text("Close", color = palette.primaryAccent, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = palette.dialogSurface,
            title = { Text(strings.deleteMyData, color = palette.error, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "This permanently deletes your Firestore profile, cloud-saved guides, and submitted problem reports.",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteCloudData()
                    }
                ) {
                    Text("Delete Permanently", color = palette.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = palette.textPrimary)
                }
            }
        )
    }
}

@Composable
private fun SettingsRowCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color = LiquidGlassTheme.colors.primaryAccent,
    testTagName: String,
    onClick: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTagName),
        shape = RoundedCornerShape(18.dp),
        elevated = true,
        onClick = onClick,
        contentPadding = 14.dp
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = palette.textSecondary)
        }
    }
}
