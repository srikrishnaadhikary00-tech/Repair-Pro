package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.BillingSummaryStats
import com.example.data.local.CustomerEntity
import com.example.data.local.InvoiceEntity
import com.example.data.remote.BillingConfigCloud
import com.example.data.remote.BillingDomainHelper
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.theme.LiquidGlassTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BillingDashboardScreen(
    language: AppLanguage,
    billingConfig: BillingConfigCloud,
    invoices: List<InvoiceEntity>,
    customers: List<CustomerEntity>,
    stats: BillingSummaryStats,
    isOnline: Boolean,
    syncing: Boolean,
    onBack: () -> Unit,
    onCreateInvoice: () -> Unit,
    onOpenInvoiceDetail: (String) -> Unit,
    onTriggerSync: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val strings = StringsProvider.get(language)
    var selectedTab by remember { mutableIntStateOf(0) } // 0=All Invoices, 1=Pending Balances, 2=Customers
    var searchQuery by remember { mutableStateOf("") }
    var selectedCustomerId by remember { mutableStateOf<String?>(null) }

    val filteredInvoices = remember(invoices, searchQuery, selectedTab, selectedCustomerId) {
        val q = searchQuery.trim().lowercase()
        invoices.filter { inv ->
            val tabMatch = when (selectedTab) {
                1 -> inv.paymentStatus == BillingDomainHelper.STATUS_UNPAID ||
                    inv.paymentStatus == BillingDomainHelper.STATUS_PARTIALLY_PAID
                else -> true
            }
            val custMatch = selectedCustomerId == null || inv.customerId == selectedCustomerId
            val searchMatch = q.isEmpty() ||
                inv.customerName.lowercase().contains(q) ||
                inv.customerMobile.lowercase().contains(q) ||
                inv.invoiceNumber.lowercase().contains(q) ||
                inv.applianceBrand.lowercase().contains(q)
            tabMatch && custMatch && searchMatch
        }
    }

    val filteredCustomers = remember(customers, searchQuery) {
        val q = searchQuery.trim().lowercase()
        customers.filter { c ->
            q.isEmpty() || c.name.lowercase().contains(q) || c.mobileNumber.lowercase().contains(q)
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        floatingActionButton = {
            if (billingConfig.invoiceEnabled) {
                FloatingActionButton(
                    onClick = onCreateInvoice,
                    containerColor = palette.primaryAccent,
                    contentColor = palette.onPrimaryAccent,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.testTag("billing_create_fab")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "New Invoice")
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("billing_dashboard_screen"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 92.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LiquidGlassBackBar(
                    title = strings.billingTitle,
                    subtitle = strings.billingSubtitle,
                    onBack = onBack,
                    backTestTag = "billing_back_button",
                    trailing = {
                        IconButton(
                            onClick = onTriggerSync,
                            enabled = !syncing,
                            modifier = Modifier.testTag("billing_sync_button")
                        ) {
                            Icon(
                                imageVector = if (stats.pendingSyncCount > 0) Icons.Filled.CloudSync else Icons.Filled.CloudDone,
                                contentDescription = "Sync billing data",
                                tint = if (stats.pendingSyncCount > 0) palette.warning else palette.success
                            )
                        }
                    }
                )
            }

            if (!billingConfig.invoiceEnabled) {
                item {
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        customContainerColor = palette.warning.copy(alpha = if (palette.isDark) 0.14f else 0.10f),
                        customBorderColor = palette.warning.copy(alpha = 0.5f),
                        contentPadding = 14.dp
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Invoice Creation Paused by Admin", color = palette.warning, fontWeight = FontWeight.Bold)
                            Text("Creating new invoices is currently disabled remotely, while your saved offline records remain viewable.", style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                        }
                    }
                }
            }

            // Daily / Monthly / Outstanding KPI Strip
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BillingKpiCard(
                        title = "Today",
                        value = BillingDomainHelper.formatInr(stats.todayCollection),
                        accent = palette.success,
                        modifier = Modifier.weight(1f)
                    )
                    BillingKpiCard(
                        title = "This Month",
                        value = BillingDomainHelper.formatInr(stats.monthCollection),
                        accent = palette.primaryAccent,
                        modifier = Modifier.weight(1f)
                    )
                    BillingKpiCard(
                        title = "Outstanding",
                        value = BillingDomainHelper.formatInr(stats.totalOutstanding),
                        accent = palette.warning,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Offline / Sync Status Banner
            item {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = 0.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Sync, contentDescription = null, tint = if (isOnline) palette.primaryAccent else palette.warning, modifier = Modifier.size(18.dp))
                            Text(
                                text = when {
                                    syncing -> "Syncing private billing records..."
                                    !isOnline -> "Offline Mode (${stats.pendingSyncCount} pending sync)"
                                    stats.pendingSyncCount > 0 -> "${stats.pendingSyncCount} local changes waiting to sync"
                                    else -> "All ${stats.totalInvoices} invoices synced to your account"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary
                            )
                        }
                        if (isOnline && stats.pendingSyncCount > 0 && !syncing) {
                            TextButton(onClick = onTriggerSync) {
                                Text("Sync Now", color = palette.primaryAccent)
                            }
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("Search customer name, mobile, or invoice #") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = palette.primaryAccent) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = liquidGlassFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("billing_search_input")
                )
            }

            // Tabs
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        0 to "Invoices (${invoices.size})",
                        1 to "Outstanding",
                        2 to "Customers (${customers.size})"
                    ).forEach { (idx, title) ->
                        val selected = selectedTab == idx
                        FilterChip(
                            selected = selected,
                            onClick = {
                                selectedTab = idx
                                if (idx != 0) selectedCustomerId = null
                            },
                            label = { Text(title) },
                            colors = liquidGlassFilterChipColors(),
                            border = liquidGlassFilterChipBorder(selected),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("billing_tab_$idx")
                        )
                    }
                }
            }

            if (selectedCustomerId != null) {
                item {
                    val custName = customers.firstOrNull { it.customerId == selectedCustomerId }?.name ?: "Customer"
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        accentBorder = true,
                        contentPadding = 0.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Showing history for $custName", color = palette.primaryAccent, style = MaterialTheme.typography.labelMedium)
                            TextButton(onClick = { selectedCustomerId = null }) {
                                Text("Show All", color = palette.textPrimary)
                            }
                        }
                    }
                }
            }

            if (selectedTab == 2) {
                if (filteredCustomers.isEmpty()) {
                    item {
                        EmptyBillingCard("No customers saved yet", "Tap + to create an invoice. Customers are saved automatically for repeat service tracking.")
                    }
                } else {
                    items(filteredCustomers, key = { it.customerId }) { cust ->
                        val custInvoices = invoices.filter { it.customerId == cust.customerId }
                        val due = custInvoices.sumOf { (it.remainingBalance ?: 0.0).coerceAtLeast(0.0) }
                        LiquidGlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            elevated = true,
                            onClick = {
                                selectedCustomerId = cust.customerId
                                selectedTab = 0
                            },
                            contentPadding = 14.dp
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Filled.Person, contentDescription = null, tint = palette.primaryAccent)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cust.name, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.Bold)
                                    Text(cust.mobileNumber, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                                    if (cust.address.isNotBlank()) {
                                        Text(cust.address, style = MaterialTheme.typography.labelSmall, color = palette.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${custInvoices.size} bills", style = MaterialTheme.typography.labelSmall, color = palette.primaryAccent)
                                    if (due > 0.0) {
                                        Text("Due ${BillingDomainHelper.formatInr(due)}", style = MaterialTheme.typography.labelSmall, color = palette.warning, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (filteredInvoices.isEmpty()) {
                    item {
                        EmptyBillingCard(
                            title = if (selectedTab == 1) "No pending balances" else "No invoices yet",
                            subtitle = if (selectedTab == 1) "All billed invoices with entered amounts are settled." else "Tap + to create your first offline-ready customer service invoice."
                        )
                    }
                } else {
                    items(filteredInvoices, key = { it.invoiceId }) { inv ->
                        InvoiceListCard(inv = inv, onClick = { onOpenInvoiceDetail(inv.invoiceId) })
                    }
                }
            }
        }
    }
}

@Composable
private fun BillingKpiCard(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        elevated = true,
        customBorderColor = accent.copy(alpha = 0.42f),
        contentPadding = 12.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = palette.textSecondary)
            Text(value, style = MaterialTheme.typography.titleSmall, color = accent, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun InvoiceListCard(inv: InvoiceEntity, onClick: () -> Unit) {
    val palette = LiquidGlassTheme.colors
    val statusColor = when (inv.paymentStatus) {
        BillingDomainHelper.STATUS_FULLY_PAID -> palette.success
        BillingDomainHelper.STATUS_PARTIALLY_PAID -> palette.warning
        BillingDomainHelper.STATUS_UNPAID -> palette.error
        else -> palette.textSecondary
    }
    val dateLabel = remember(inv.createdAtMillis) {
        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(inv.createdAtMillis))
    }

    LiquidGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("invoice_card_${inv.invoiceId}"),
        shape = RoundedCornerShape(20.dp),
        elevated = true,
        onClick = onClick,
        contentPadding = 14.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = inv.customerName,
                    style = MaterialTheme.typography.titleSmall,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.35f))
                ) {
                    Text(
                        text = inv.paymentStatus.replace('_', ' '),
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Text(
                text = "${inv.invoiceNumber} • ${inv.customerMobile} • $dateLabel",
                style = MaterialTheme.typography.labelSmall,
                color = palette.textSecondary
            )
            val appInfo = listOf(inv.applianceBrand, inv.applianceCategory, inv.modelNumber)
                .filter { it.isNotBlank() }.joinToString(" • ")
            if (appInfo.isNotBlank()) {
                Text(appInfo, style = MaterialTheme.typography.bodySmall, color = palette.primaryAccent, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (inv.totalBill == null) "Amount Not Entered" else "Total: ${BillingDomainHelper.formatInr(inv.totalBill)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                val rem = inv.remainingBalance
                if (rem != null && rem > 0.009) {
                    Text(
                        text = "Balance: ${BillingDomainHelper.formatInr(rem)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.warning,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyBillingCard(title: String, subtitle: String) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        elevated = true,
        contentPadding = 24.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Filled.ReceiptLong, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(36.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
        }
    }
}
