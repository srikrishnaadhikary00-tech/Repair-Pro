package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.SeedDataPart2
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.SafetyWarningBanner
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun TroubleshootingWizardScreen(
    initialCategoryId: String,
    language: AppLanguage,
    onBack: () -> Unit,
    onOpenProblemDetail: (String) -> Unit,
    onOpenErrorDetail: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    val palette = LiquidGlassTheme.colors
    var selectedCategory by remember { mutableStateOf(initialCategoryId.ifBlank { "ac" }) }
    val rootId = "${selectedCategory}_start"
    var nodeStack by remember(selectedCategory) { mutableStateOf(listOf(rootId)) }

    val tree = SeedDataPart2.wizardTrees[selectedCategory] ?: SeedDataPart2.wizardTrees["ac"].orEmpty()
    val currentNode = tree[nodeStack.lastOrNull()] ?: tree.values.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = strings.wizardTitle,
                subtitle = strings.wizardSubtitle,
                onBack = onBack,
                backTestTag = "wizard_back_button"
            )
        }

        // Category Selector Chips
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                    val selected = selectedCategory == id
                    FilterChip(
                        selected = selected,
                        onClick = { selectedCategory = id },
                        label = { Text(label) },
                        colors = liquidGlassFilterChipColors(),
                        border = liquidGlassFilterChipBorder(selected)
                    )
                }
            }
        }

        if (currentNode != null) {
            if (currentNode.options.isNotEmpty()) {
                val question = resolveLocalizedText(
                    language,
                    currentNode.questionEn,
                    currentNode.questionBn,
                    currentNode.questionHi
                ).text
                item {
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        elevated = true,
                        accentBorder = true,
                        contentPadding = 18.dp
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Filled.AutoFixHigh, contentDescription = null, tint = palette.primaryAccent)
                                Text(
                                    text = "Step ${nodeStack.size}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = palette.primaryAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = question,
                                style = MaterialTheme.typography.headlineSmall,
                                color = palette.textPrimary
                            )
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        currentNode.options.forEachIndexed { idx, opt ->
                            val label = resolveLocalizedText(language, opt.labelEn, opt.labelBn, opt.labelHi).text
                            LiquidGlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("wizard_option_$idx"),
                                shape = RoundedCornerShape(18.dp),
                                onClick = { nodeStack = nodeStack + opt.nextNodeId },
                                contentPadding = 16.dp
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = palette.textPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                        contentDescription = null,
                                        tint = palette.primaryAccent
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                val conclusion = resolveLocalizedText(
                    language,
                    currentNode.conclusionEn.orEmpty(),
                    currentNode.conclusionBn.orEmpty(),
                    currentNode.conclusionHi.orEmpty()
                ).text
                val safeCheck = resolveLocalizedText(
                    language,
                    currentNode.safeCheckEn.orEmpty(),
                    currentNode.safeCheckBn.orEmpty(),
                    currentNode.safeCheckHi.orEmpty()
                ).text
                val techWarn = resolveLocalizedText(
                    language,
                    currentNode.technicianWarningEn.orEmpty(),
                    currentNode.technicianWarningBn.orEmpty(),
                    currentNode.technicianWarningHi.orEmpty()
                ).text

                item {
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        elevated = true,
                        accentBorder = true,
                        contentPadding = 16.dp
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(strings.possibleCauses, style = MaterialTheme.typography.titleMedium, color = palette.primaryAccent, fontWeight = FontWeight.Bold)
                            Text(conclusion, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
                        }
                    }
                }

                item {
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        customContainerColor = palette.success.copy(alpha = if (palette.isDark) 0.14f else 0.10f),
                        customBorderColor = palette.success.copy(alpha = 0.45f),
                        contentPadding = 14.dp
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = palette.success)
                            Text(safeCheck, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
                        }
                    }
                }

                if (techWarn.isNotBlank()) {
                    item {
                        SafetyWarningBanner(
                            title = strings.safetyWarningTitle,
                            message = techWarn
                        )
                    }
                }

                if (currentNode.relatedProblemId != null) {
                    item {
                        Button(
                            onClick = { onOpenProblemDetail(currentNode.relatedProblemId) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("wizard_open_guide_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.primaryAccent,
                                contentColor = palette.onPrimaryAccent
                            )
                        ) {
                            Text("${strings.solution} →", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (currentNode.relatedErrorCodeId != null) {
                    item {
                        Button(
                            onClick = { onOpenErrorDetail(currentNode.relatedErrorCodeId) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("wizard_open_code_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.primaryAccent,
                                contentColor = palette.onPrimaryAccent
                            )
                        ) {
                            Text("${strings.errorCodes} →", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (nodeStack.size > 1) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { nodeStack = nodeStack.dropLast(1) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, palette.glassBorderAccent),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = palette.glassFill,
                                contentColor = palette.textPrimary
                            )
                        ) {
                            Text("Previous Step", color = palette.textPrimary)
                        }
                        OutlinedButton(
                            onClick = { nodeStack = listOf(rootId) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, palette.primaryAccent.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = palette.glassFill,
                                contentColor = palette.primaryAccent
                            )
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.wizardRestart, color = palette.primaryAccent)
                        }
                    }
                }
            }
        }
    }
}
