package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.SeedDataPart2
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AuroraGlassCard
import com.example.ui.components.AuroraPillFilter
import com.example.ui.components.SafetyWarningBanner
import com.example.ui.theme.AuroraAccentGradient
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanBorderGradient
import com.example.ui.theme.PurpleBorderGradient
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate

@Composable
fun TroubleshootingWizardScreen(
    initialCategoryId: String,
    language: AppLanguage,
    onBack: () -> Unit,
    onOpenProblemDetail: (String) -> Unit,
    onOpenErrorDetail: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    var selectedCategory by remember { mutableStateOf(initialCategoryId.ifBlank { "ac" }) }
    val rootId = "${selectedCategory}_start"
    var nodeStack by remember(selectedCategory) { mutableStateOf(listOf(rootId)) }

    val tree = SeedDataPart2.wizardTrees[selectedCategory] ?: SeedDataPart2.wizardTrees["ac"].orEmpty()
    val currentNode = tree[nodeStack.lastOrNull()] ?: tree.values.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x66122142))
                        .border(1.dp, CyanAccent.copy(alpha = 0.4f), CircleShape)
                        .testTag("wizard_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(strings.wizardTitle, style = MaterialTheme.typography.titleLarge, color = TextPrimaryWhite)
                    Text(strings.wizardSubtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                }
            }
        }

        // Category Selector Aurora Pills
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                    AuroraPillFilter(
                        label = label,
                        selected = selectedCategory == id,
                        onClick = { selectedCategory = id }
                    )
                }
            }
        }

        if (currentNode != null) {
            if (currentNode.options.isNotEmpty()) {
                val question = resolveLocalizedText(
                    language,
                    currentNode.questionEn,
                    currentNode.questionBn,
                    currentNode.questionHi
                ).text
                item {
                    AuroraGlassCard(
                        cornerRadius = 20.dp,
                        borderBrush = PurpleBorderGradient,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Filled.AutoFixHigh, contentDescription = null, tint = CyanAccent)
                                Text(
                                    text = "Step ${nodeStack.size}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = question,
                                style = MaterialTheme.typography.headlineSmall,
                                color = TextPrimaryWhite
                            )
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        currentNode.options.forEachIndexed { idx, opt ->
                            val label = resolveLocalizedText(language, opt.labelEn, opt.labelBn, opt.labelHi).text
                            AuroraGlassCard(
                                cornerRadius = 16.dp,
                                borderBrush = CyanBorderGradient,
                                onClick = { nodeStack = nodeStack + opt.nextNodeId },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("wizard_option_$idx")
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimaryWhite,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                        contentDescription = null,
                                        tint = CyanAccent
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // Diagnostic Conclusion Card
                val conclusion = resolveLocalizedText(
                    language,
                    currentNode.conclusionEn.orEmpty(),
                    currentNode.conclusionBn.orEmpty(),
                    currentNode.conclusionHi.orEmpty()
                ).text
                val safeCheck = resolveLocalizedText(
                    language,
                    currentNode.safeCheckEn.orEmpty(),
                    currentNode.safeCheckBn.orEmpty(),
                    currentNode.safeCheckHi.orEmpty()
                ).text
                val techWarn = resolveLocalizedText(
                    language,
                    currentNode.technicianWarningEn.orEmpty(),
                    currentNode.technicianWarningBn.orEmpty(),
                    currentNode.technicianWarningHi.orEmpty()
                ).text

                item {
                    AuroraGlassCard(
                        cornerRadius = 18.dp,
                        borderBrush = PurpleBorderGradient,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(strings.possibleCauses, style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
                            Text(conclusion, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryWhite)
                        }
                    }
                }

                item {
                    AuroraGlassCard(
                        cornerRadius = 16.dp,
                        borderBrush = Brush.linearGradient(listOf(SuccessGreen.copy(alpha = 0.7f), CyanAccent.copy(alpha = 0.4f))),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen)
                            Text(safeCheck, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryWhite)
                        }
                    }
                }

                if (techWarn.isNotBlank()) {
                    item {
                        SafetyWarningBanner(
                            title = strings.safetyWarningTitle,
                            message = techWarn
                        )
                    }
                }

                if (currentNode.relatedProblemId != null) {
                    item {
                        Button(
                            onClick = { onOpenProblemDetail(currentNode.relatedProblemId) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(AuroraAccentGradient)
                                .testTag("wizard_open_guide_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = TextPrimaryWhite)
                        ) {
                            Text("${strings.solution} →", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (currentNode.relatedErrorCodeId != null) {
                    item {
                        Button(
                            onClick = { onOpenErrorDetail(currentNode.relatedErrorCodeId) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(AuroraAccentGradient)
                                .testTag("wizard_open_code_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = TextPrimaryWhite)
                        ) {
                            Text("${strings.errorCodes} →", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (nodeStack.size > 1) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { nodeStack = nodeStack.dropLast(1) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f))
                        ) {
                            Text("Previous Step", color = TextPrimaryWhite)
                        }
                        OutlinedButton(
                            onClick = { nodeStack = listOf(rootId) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.65f))
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.wizardRestart, color = CyanAccent)
                        }
                    }
                }
            }
        }
    }
}
