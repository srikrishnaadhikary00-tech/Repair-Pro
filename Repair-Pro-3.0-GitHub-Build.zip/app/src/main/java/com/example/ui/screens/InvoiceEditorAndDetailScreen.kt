package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.billing.InvoicePdfGenerator
import com.example.billing.ManualReminderLauncher
import com.example.data.local.InvoiceEntity
import com.example.data.local.InvoicePaymentEntity
import com.example.data.remote.BillingConfigCloud
import com.example.data.remote.BillingDomainHelper
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.theme.LiquidGlassTheme
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Composable
fun InvoiceEditorScreen(
    existingInvoice: InvoiceEntity?,
    onBack: () -> Unit,
    onSave: (
        existingInvoiceId: String?,
        customerId: String?,
        customerName: String,
        customerMobile: String,
        customerAddress: String,
        applianceCategory: String,
        applianceBrand: String,
        modelNumber: String,
        serialNumber: String,
        reportedProblem: String,
        workDone: String,
        partsUsed: String,
        partsQuantity: Int,
        partsCharges: Double?,
        serviceCharges: Double?,
        visitingCharges: Double?,
        otherCharges: Double?,
        discountAmount: Double?,
        amountReceived: Double?,
        paymentMethod: String,
        paymentDueDate: String,
        warrantyInfo: String,
        notes: String,
        reminderDate: String
    ) -> Unit
) {
    val palette = LiquidGlassTheme.colors
    var customerName by remember(existingInvoice) { mutableStateOf(existingInvoice?.customerName.orEmpty()) }
    var customerMobile by remember(existingInvoice) { mutableStateOf(existingInvoice?.customerMobile.orEmpty()) }
    var customerAddress by remember(existingInvoice) { mutableStateOf(existingInvoice?.customerAddress.orEmpty()) }

    var showApplianceSection by remember { mutableStateOf(existingInvoice != null) }
    var applianceCategory by remember(existingInvoice) { mutableStateOf(existingInvoice?.applianceCategory.orEmpty()) }
    var applianceBrand by remember(existingInvoice) { mutableStateOf(existingInvoice?.applianceBrand.orEmpty()) }
    var modelNumber by remember(existingInvoice) { mutableStateOf(existingInvoice?.modelNumber.orEmpty()) }
    var serialNumber by remember(existingInvoice) { mutableStateOf(existingInvoice?.serialNumber.orEmpty()) }
    var reportedProblem by remember(existingInvoice) { mutableStateOf(existingInvoice?.reportedProblem.orEmpty()) }
    var workDone by remember(existingInvoice) { mutableStateOf(existingInvoice?.workDone.orEmpty()) }
    var partsUsed by remember(existingInvoice) { mutableStateOf(existingInvoice?.partsUsed.orEmpty()) }
    var partsQtyText by remember(existingInvoice) { mutableStateOf(existingInvoice?.partsQuantity?.takeIf { it > 0 }?.toString().orEmpty()) }

    var showChargesSection by remember { mutableStateOf(true) }
    var partsChargeText by remember(existingInvoice) { mutableStateOf(existingInvoice?.partsCharges?.toString().orEmpty()) }
    var serviceChargeText by remember(existingInvoice) { mutableStateOf(existingInvoice?.serviceCharges?.toString().orEmpty()) }
    var visitingChargeText by remember(existingInvoice) { mutableStateOf(existingInvoice?.visitingCharges?.toString().orEmpty()) }
    var otherChargeText by remember(existingInvoice) { mutableStateOf(existingInvoice?.otherCharges?.toString().orEmpty()) }
    var discountText by remember(existingInvoice) { mutableStateOf(existingInvoice?.discountAmount?.toString().orEmpty()) }
    var receivedText by remember(existingInvoice) { mutableStateOf(existingInvoice?.amountReceived?.toString().orEmpty()) }

    var showNotesSection by remember { mutableStateOf(existingInvoice != null) }
    var paymentMethod by remember(existingInvoice) { mutableStateOf(existingInvoice?.paymentMethod.orEmpty().ifBlank { "Cash" }) }
    var paymentDueDate by remember(existingInvoice) { mutableStateOf(existingInvoice?.paymentDueDate.orEmpty()) }
    var warrantyInfo by remember(existingInvoice) { mutableStateOf(existingInvoice?.warrantyInfo.orEmpty()) }
    var notes by remember(existingInvoice) { mutableStateOf(existingInvoice?.notes.orEmpty()) }
    var reminderDate by remember(existingInvoice) { mutableStateOf(existingInvoice?.reminderDate.orEmpty()) }
    var validationError by remember { mutableStateOf<String?>(null) }

    val partsVal = BillingDomainHelper.parseOptionalAmount(partsChargeText)
    val serviceVal = BillingDomainHelper.parseOptionalAmount(serviceChargeText)
    val visitingVal = BillingDomainHelper.parseOptionalAmount(visitingChargeText)
    val otherVal = BillingDomainHelper.parseOptionalAmount(otherChargeText)
    val discountVal = BillingDomainHelper.parseOptionalAmount(discountText)
    val receivedVal = BillingDomainHelper.parseOptionalAmount(receivedText)
    val previewTotal = BillingDomainHelper.calculateTotalBill(partsVal, serviceVal, visitingVal, otherVal, discountVal)
    val previewRemaining = BillingDomainHelper.calculateRemainingBalance(previewTotal, receivedVal)
    val previewStatus = BillingDomainHelper.resolvePaymentStatus(previewTotal, receivedVal)

    val fieldColors = liquidGlassFieldColors()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("invoice_editor_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = if (existingInvoice == null) "Create Service Invoice" else "Edit ${existingInvoice.invoiceNumber}",
                subtitle = "Only Customer Name & Mobile are mandatory",
                onBack = onBack,
                backTestTag = "invoice_editor_back"
            )
        }

        // Mandatory Customer Section
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                elevated = true,
                accentBorder = true,
                contentPadding = 16.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Customer Information (Required)", style = MaterialTheme.typography.titleSmall, color = palette.primaryAccent, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it.take(100); validationError = null },
                        label = { Text("Customer Name *") },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("invoice_customer_name_input")
                    )
                    OutlinedTextField(
                        value = customerMobile,
                        onValueChange = { customerMobile = it.take(20); validationError = null },
                        label = { Text("Mobile Number *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("invoice_customer_mobile_input")
                    )
                    OutlinedTextField(
                        value = customerAddress,
                        onValueChange = { customerAddress = it.take(300) },
                        label = { Text("Address (Optional)") },
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Collapsible Appliance & Work Done
        item {
            CollapsibleSectionCard(
                title = "Appliance & Repair Details (Optional)",
                expanded = showApplianceSection,
                onToggle = { showApplianceSection = !showApplianceSection }
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("AC", "Refrigerator", "Washing Machine").forEach { cat ->
                        val selected = applianceCategory == cat
                        FilterChip(
                            selected = selected,
                            onClick = { applianceCategory = if (selected) "" else cat },
                            label = { Text(cat) },
                            colors = liquidGlassFilterChipColors(),
                            border = liquidGlassFilterChipBorder(selected),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = applianceBrand,
                        onValueChange = { applianceBrand = it.take(60) },
                        label = { Text("Brand") },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = modelNumber,
                        onValueChange = { modelNumber = it.take(80) },
                        label = { Text("Model") },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = serialNumber,
                    onValueChange = { serialNumber = it.take(80) },
                    label = { Text("Serial Number") },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = reportedProblem,
                    onValueChange = { reportedProblem = it.take(600) },
                    label = { Text("Problem Reported") },
                    minLines = 2,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = workDone,
                    onValueChange = { workDone = it.take(800) },
                    label = { Text("Work Done") },
                    minLines = 2,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = partsUsed,
                        onValueChange = { partsUsed = it.take(500) },
                        label = { Text("Parts Replaced") },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = partsQtyText,
                        onValueChange = { partsQtyText = it.filter { ch -> ch.isDigit() }.take(4) },
                        label = { Text("Qty") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.width(84.dp)
                    )
                }
            }
        }

        // Collapsible Charges & Payment
        item {
            CollapsibleSectionCard(
                title = "Charges & Payment in ₹ (All Optional)",
                expanded = showChargesSection,
                onToggle = { showChargesSection = !showChargesSection }
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AmountField("Parts ₹", partsChargeText, { partsChargeText = it }, Modifier.weight(1f))
                    AmountField("Service ₹", serviceChargeText, { serviceChargeText = it }, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AmountField("Visiting ₹", visitingChargeText, { visitingChargeText = it }, Modifier.weight(1f))
                    AmountField("Other ₹", otherChargeText, { otherChargeText = it }, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AmountField("Discount ₹", discountText, { discountText = it }, Modifier.weight(1f))
                    AmountField(
                        label = if (existingInvoice == null) "Received ₹" else "Received ₹ (locked if payments exist)",
                        value = receivedText,
                        onChange = { if (existingInvoice == null) receivedText = it },
                        modifier = Modifier.weight(1f),
                        enabled = existingInvoice == null
                    )
                }

                // Live Preview
                Surface(
                    color = palette.glassFillSubtle,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, palette.glassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total: ${BillingDomainHelper.formatInr(previewTotal)}", color = palette.textPrimary, fontWeight = FontWeight.Bold)
                            Text("Status: ${previewStatus.replace('_', ' ')}", style = MaterialTheme.typography.labelSmall, color = palette.primaryAccent)
                        }
                        if (previewRemaining != null) {
                            Text("Balance: ${BillingDomainHelper.formatInr(previewRemaining)}", color = palette.warning, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Collapsible Method / Warranty / Reminder
        item {
            CollapsibleSectionCard(
                title = "Due Date, Warranty, Notes & Reminder (Optional)",
                expanded = showNotesSection,
                onToggle = { showNotesSection = !showNotesSection }
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BillingDomainHelper.ALLOWED_PAYMENT_METHODS.forEach { method ->
                        val selected = paymentMethod == method
                        FilterChip(
                            selected = selected,
                            onClick = { paymentMethod = method },
                            label = { Text(method) },
                            colors = liquidGlassFilterChipColors(),
                            border = liquidGlassFilterChipBorder(selected),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = paymentDueDate,
                        onValueChange = { paymentDueDate = it.take(32) },
                        label = { Text("Due Date (YYYY-MM-DD)") },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = reminderDate,
                        onValueChange = { reminderDate = it.take(32) },
                        label = { Text("Reminder Date") },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = warrantyInfo,
                    onValueChange = { warrantyInfo = it.take(200) },
                    label = { Text("Warranty Info") },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it.take(500) },
                    label = { Text("Additional Notes") },
                    minLines = 2,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (validationError != null) {
            item {
                Text(validationError.orEmpty(), color = palette.error, style = MaterialTheme.typography.bodySmall)
            }
        }

        item {
            Button(
                onClick = {
                    val err = BillingDomainHelper.validateCustomerAndInvoiceInput(
                        customerName = customerName,
                        customerMobile = customerMobile,
                        partsCharges = partsVal,
                        serviceCharges = serviceVal,
                        visitingCharges = visitingVal,
                        otherCharges = otherVal,
                        discountAmount = discountVal,
                        amountReceived = receivedVal
                    )
                    if (err != null) {
                        validationError = err
                        return@Button
                    }
                    onSave(
                        existingInvoice?.invoiceId,
                        existingInvoice?.customerId,
                        customerName,
                        customerMobile,
                        customerAddress,
                        applianceCategory,
                        applianceBrand,
                        modelNumber,
                        serialNumber,
                        reportedProblem,
                        workDone,
                        partsUsed,
                        partsQtyText.toIntOrNull() ?: 0,
                        partsVal,
                        serviceVal,
                        visitingVal,
                        otherVal,
                        discountVal,
                        receivedVal,
                        paymentMethod,
                        paymentDueDate,
                        warrantyInfo,
                        notes,
                        reminderDate
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.primaryAccent,
                    contentColor = palette.onPrimaryAccent
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("invoice_save_button")
            ) {
                Text(if (existingInvoice == null) "Save Invoice" else "Update Invoice", fontWeight = FontWeight.Bold)
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun InvoiceDetailScreen(
    language: AppLanguage,
    invoice: InvoiceEntity?,
    payments: List<InvoicePaymentEntity>,
    billingConfig: BillingConfigCloud,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
    onRecordPayment: (amount: Double?, method: String, note: String, idempotencyKey: String) -> Unit,
    onDeleteInvoice: (String) -> Unit,
    onShowMessage: (String) -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val context = LocalContext.current
    val strings = StringsProvider.get(language)
    var showPaymentDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var pendingDownloadPdf by remember { mutableStateOf<File?>(null) }

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { destUri ->
        val src = pendingDownloadPdf
        pendingDownloadPdf = null
        if (destUri != null && src != null) {
            val res = InvoicePdfGenerator.copyPdfToDestinationUri(context, src, destUri)
            onShowMessage(if (res.isSuccess) "Invoice PDF saved." else res.exceptionOrNull()?.localizedMessage ?: "Failed to save PDF.")
        }
    }

    if (invoice == null) {
        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LiquidGlassBackBar(
                title = "Invoice",
                onBack = onBack,
                backTestTag = "invoice_detail_back"
            )
            Text("Invoice not found.", color = palette.textPrimary)
        }
        return
    }

    val canWhatsApp = BillingDomainHelper.canSendReminder(
        paymentStatus = invoice.paymentStatus,
        remainingBalance = invoice.remainingBalance,
        featureEnabled = billingConfig.whatsappReminderEnabled
    )
    val canSms = BillingDomainHelper.canSendReminder(
        paymentStatus = invoice.paymentStatus,
        remainingBalance = invoice.remainingBalance,
        featureEnabled = billingConfig.smsReminderEnabled
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("invoice_detail_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = invoice.invoiceNumber,
                subtitle = invoice.customerName,
                onBack = onBack,
                backTestTag = "invoice_detail_back",
                trailing = {
                    IconButton(onClick = { onEdit(invoice.invoiceId) }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit Invoice", tint = palette.primaryAccent)
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete Invoice", tint = palette.error)
                    }
                }
            )
        }

        // Balance Summary Card
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                elevated = true,
                accentBorder = true,
                contentPadding = 16.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Payment Status: ${invoice.paymentStatus.replace('_', ' ')}", color = palette.primaryAccent, fontWeight = FontWeight.Bold)
                    Text("Total Bill: ${BillingDomainHelper.formatInr(invoice.totalBill)}", style = MaterialTheme.typography.headlineSmall, color = palette.textPrimary, fontWeight = FontWeight.Bold)
                    invoice.amountReceived?.let {
                        Text("Received: ${BillingDomainHelper.formatInr(it)}", color = palette.success, style = MaterialTheme.typography.bodyMedium)
                    }
                    invoice.remainingBalance?.let {
                        Text("Remaining Balance: ${BillingDomainHelper.formatInr(it)}", color = if (it > 0) palette.warning else palette.success, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = { showPaymentDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.primaryAccent,
                            contentColor = palette.onPrimaryAccent
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("invoice_record_payment_button")
                    ) {
                        Icon(Icons.Filled.AddCard, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Record Payment", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // PDF Export & Share Actions
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        val gen = InvoicePdfGenerator.generateInvoicePdf(
                            context = context,
                            invoice = invoice,
                            payments = payments,
                            businessTitle = billingConfig.invoiceBusinessTitle,
                            termsNote = billingConfig.invoiceTermsNote
                        )
                        if (gen.isSuccess) {
                            val file = gen.getOrThrow()
                            pendingDownloadPdf = file
                            savePdfLauncher.launch(file.name)
                        } else {
                            onShowMessage(gen.exceptionOrNull()?.localizedMessage ?: "PDF generation failed.")
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, palette.primaryAccent),
                    modifier = Modifier.weight(1f).testTag("invoice_download_pdf_button")
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.downloadPdfInvoice, color = palette.primaryAccent)
                }
                Button(
                    onClick = {
                        val gen = InvoicePdfGenerator.generateInvoicePdf(
                            context = context,
                            invoice = invoice,
                            payments = payments,
                            businessTitle = billingConfig.invoiceBusinessTitle,
                            termsNote = billingConfig.invoiceTermsNote
                        )
                        if (gen.isSuccess) {
                            val shareIntent = InvoicePdfGenerator.createSharePdfIntent(context, gen.getOrThrow(), invoice.invoiceNumber)
                            runCatching { context.startActivity(Intent.createChooser(shareIntent, strings.sharePdfInvoice)) }
                                .onFailure { onShowMessage("No PDF share target found.") }
                        } else {
                            onShowMessage(gen.exceptionOrNull()?.localizedMessage ?: "PDF generation failed.")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.glassFillElevated,
                        contentColor = palette.textPrimary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).testTag("invoice_share_pdf_button")
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.sharePdfInvoice)
                }
            }
        }

        // Strictly Manual WhatsApp / SMS Reminders (only when unpaid/partially paid & enabled)
        if (canWhatsApp || canSms) {
            item {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevated = true,
                    customBorderColor = palette.warning.copy(alpha = 0.45f),
                    contentPadding = 14.dp
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Manual Payment Reminder", style = MaterialTheme.typography.titleSmall, color = palette.warning, fontWeight = FontWeight.Bold)
                        Text(
                            text = "Opens WhatsApp or your SMS app with a pre-filled ${language.englishName} message. Nothing is sent automatically.",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                        if (canWhatsApp) {
                            Button(
                                onClick = {
                                    val res = ManualReminderLauncher.launchWhatsAppReminder(context, invoice, billingConfig, language.code)
                                    if (res.isFailure) onShowMessage(res.exceptionOrNull()?.localizedMessage ?: "WhatsApp unavailable.")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = palette.success),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().testTag("invoice_whatsapp_reminder_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(strings.sendWhatsappReminder, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (canSms) {
                            OutlinedButton(
                                onClick = {
                                    val res = ManualReminderLauncher.launchSmsReminder(context, invoice, billingConfig, language.code)
                                    if (res.isFailure) onShowMessage(res.exceptionOrNull()?.localizedMessage ?: "SMS app unavailable.")
                                },
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, palette.primaryAccent),
                                modifier = Modifier.fillMaxWidth().testTag("invoice_sms_reminder_button")
                            ) {
                                Icon(Icons.Filled.Sms, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(strings.sendSmsReminder, color = palette.primaryAccent)
                            }
                        }
                    }
                }
            }
        }

        // Invoice Full Details Card
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                elevated = true,
                contentPadding = 14.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Customer & Service Summary", style = MaterialTheme.typography.titleSmall, color = palette.primaryAccent, fontWeight = FontWeight.Bold)
                    Text("Mobile: ${invoice.customerMobile}", color = palette.textPrimary, style = MaterialTheme.typography.bodySmall)
                    if (invoice.customerAddress.isNotBlank()) Text("Address: ${invoice.customerAddress}", color = palette.textSecondary, style = MaterialTheme.typography.bodySmall)
                    val appLine = listOf(invoice.applianceCategory, invoice.applianceBrand, invoice.modelNumber).filter { it.isNotBlank() }.joinToString(" • ")
                    if (appLine.isNotBlank()) Text("Appliance: $appLine", color = palette.textPrimary, style = MaterialTheme.typography.bodySmall)
                    if (invoice.reportedProblem.isNotBlank()) Text("Problem: ${invoice.reportedProblem}", color = palette.textSecondary, style = MaterialTheme.typography.bodySmall)
                    if (invoice.workDone.isNotBlank()) Text("Work Done: ${invoice.workDone}", color = palette.textPrimary, style = MaterialTheme.typography.bodySmall)
                    if (invoice.partsUsed.isNotBlank()) Text("Parts: ${invoice.partsUsed} (Qty: ${invoice.partsQuantity})", color = palette.textSecondary, style = MaterialTheme.typography.bodySmall)
                    if (invoice.warrantyInfo.isNotBlank()) Text("Warranty: ${invoice.warrantyInfo}", color = palette.success, style = MaterialTheme.typography.bodySmall)
                    if (invoice.reminderDate.isNotBlank()) Text("Reminder Date: ${invoice.reminderDate}", color = palette.warning, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // Payment History
        if (payments.isNotEmpty()) {
            item {
                val fmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevated = true,
                    contentPadding = 14.dp
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Payment History (${payments.size})", style = MaterialTheme.typography.titleSmall, color = palette.primaryAccent, fontWeight = FontWeight.Bold)
                        payments.forEachIndexed { idx, pay ->
                            if (idx > 0) HorizontalDivider(color = palette.glassBorder)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text("${BillingDomainHelper.formatInr(pay.amount)} (${pay.paymentMethod})", color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                                    Text(fmt.format(Date(pay.paidAtMillis)), style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                                    if (pay.note.isNotBlank()) Text(pay.note, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                                }
                                Text(if (pay.syncStatus == "SYNCED") "Synced" else "Local", style = MaterialTheme.typography.labelSmall, color = palette.primaryAccent)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPaymentDialog) {
        var amountInput by remember { mutableStateOf(invoice.remainingBalance?.takeIf { it > 0 }?.toString().orEmpty()) }
        var methodInput by remember { mutableStateOf(invoice.paymentMethod.ifBlank { "Cash" }) }
        var noteInput by remember { mutableStateOf("") }
        val requestKey = remember { UUID.randomUUID().toString() }

        AlertDialog(
            onDismissRequest = { showPaymentDialog = false },
            containerColor = palette.dialogSurface,
            title = { Text("Record Payment", color = palette.textPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Amount in ₹") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = liquidGlassFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BillingDomainHelper.ALLOWED_PAYMENT_METHODS.take(3).forEach { m ->
                            val selected = methodInput == m
                            FilterChip(
                                selected = selected,
                                onClick = { methodInput = m },
                                label = { Text(m) },
                                colors = liquidGlassFilterChipColors(),
                                border = liquidGlassFilterChipBorder(selected),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                    OutlinedTextField(
                        value = noteInput,
                        onValueChange = { noteInput = it.take(200) },
                        label = { Text("Note (Optional)") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = liquidGlassFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val amt = BillingDomainHelper.parseOptionalAmount(amountInput)
                    onRecordPayment(amt, methodInput, noteInput, requestKey)
                    showPaymentDialog = false
                }) {
                    Text("Save Payment", color = palette.primaryAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPaymentDialog = false }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = palette.dialogSurface,
            title = { Text("Delete Invoice?", color = palette.error, fontWeight = FontWeight.Bold) },
            text = { Text("Delete ${invoice.invoiceNumber} for ${invoice.customerName}?", color = palette.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    onDeleteInvoice(invoice.invoiceId)
                }) {
                    Text("Delete", color = palette.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = palette.textPrimary)
                }
            }
        )
    }
}

@Composable
private fun CollapsibleSectionCard(
    title: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        elevated = true,
        contentPadding = 14.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                Icon(
                    imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = palette.primaryAccent
                )
            }
            AnimatedVisibility(visible = expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    content()
                }
            }
        }
    }
}

@Composable
private fun AmountField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw ->
            val filtered = raw.filter { it.isDigit() || it == '.' }
            onChange(filtered.take(12))
        },
        enabled = enabled,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = liquidGlassFieldColors(),
        modifier = modifier
    )
}
