package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Full-screen pinch-to-zoom Image & Circuit Diagram Viewer.
 */
@Composable
fun ZoomableImageDialog(
    imageModel: Any,
    title: String,
    onDismiss: () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.95f))
                .testTag("media_viewer_dialog")
        ) {
            AsyncImage(
                model = imageModel,
                contentDescription = title,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (scale * zoom).coerceIn(1f, 5f)
                            scale = newScale
                            offset = if (newScale > 1f) offset + pan else Offset.Zero
                        }
                    }
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(DeepCardSurface.copy(alpha = 0.90f))
                    .border(1.dp, CyanAccent.copy(alpha = 0.35f))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimaryWhite,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { scale = (scale + 0.5f).coerceAtMost(5f) }) {
                    Icon(Icons.Filled.ZoomIn, contentDescription = "Zoom in", tint = CyanAccent)
                }
                IconButton(onClick = {
                    scale = (scale - 0.5f).coerceAtLeast(1f)
                    if (scale <= 1f) offset = Offset.Zero
                }) {
                    Icon(Icons.Filled.ZoomOut, contentDescription = "Zoom out", tint = CyanAccent)
                }
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("media_viewer_close")) {
                    Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextPrimaryWhite)
                }
            }
        }
    }
}

/**
 * Native Android PdfRenderer Offline PDF Viewer (zero external dependencies, 100% offline-capable).
 */
@Composable
fun OfflinePdfViewerDialog(
    filePath: String,
    title: String,
    onDismiss: () -> Unit
) {
    var pageIndex by remember { mutableIntStateOf(0) }
    var pageCount by remember { mutableIntStateOf(0) }
    var currentBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var scale by remember { mutableFloatStateOf(1f) }

    val rendererHolder = remember(filePath) {
        runCatching {
            val file = File(filePath)
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            pfd to renderer
        }
    }

    DisposableEffect(filePath) {
        onDispose {
            rendererHolder.onSuccess { (pfd, renderer) ->
                runCatching { renderer.close() }
                runCatching { pfd.close() }
            }
        }
    }

    LaunchedEffect(filePath, pageIndex) {
        rendererHolder.onFailure {
            errorText = "Unable to open PDF offline: ${it.localizedMessage}"
        }.onSuccess { (_, renderer) ->
            pageCount = renderer.pageCount
            if (pageCount <= 0) {
                errorText = "PDF has no renderable pages."
            } else {
                val safeIdx = pageIndex.coerceIn(0, pageCount - 1)
                currentBitmap = withContext(Dispatchers.IO) {
                    val page = renderer.openPage(safeIdx)
                    val width = (page.width * 2).coerceIn(600, 1800)
                    val height = (page.height * 2).coerceIn(800, 2600)
                    val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                    bmp
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .testTag("offline_pdf_viewer")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepCardSurface.copy(alpha = 0.92f))
                    .border(1.dp, CyanAccent.copy(alpha = 0.35f))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, maxLines = 1)
                    Text(
                        text = if (pageCount > 0) "Page ${pageIndex + 1} of $pageCount • Offline Mode" else "Loading PDF…",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanAccent
                    )
                }
                IconButton(onClick = { scale = (scale + 0.5f).coerceAtMost(4f) }) {
                    Icon(Icons.Filled.ZoomIn, contentDescription = "Zoom in", tint = CyanAccent)
                }
                IconButton(onClick = { scale = (scale - 0.5f).coerceAtLeast(1f) }) {
                    Icon(Icons.Filled.ZoomOut, contentDescription = "Zoom out", tint = CyanAccent)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close PDF", tint = TextPrimaryWhite)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                when {
                    errorText != null -> Text(errorText!!, color = ErrorCrimson, modifier = Modifier.padding(20.dp))
                    currentBitmap != null -> {
                        Image(
                            bitmap = currentBitmap!!.asImageBitmap(),
                            contentDescription = "$title page ${pageIndex + 1}",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(scaleX = scale, scaleY = scale)
                        )
                    }
                    else -> CircularProgressIndicator(color = CyanAccent)
                }
            }

            if (pageCount > 1) {
                Surface(color = DeepCardSurface, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(10.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            enabled = pageIndex > 0,
                            onClick = { pageIndex = (pageIndex - 1).coerceAtLeast(0) }
                        ) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous page", tint = CyanAccent)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("${pageIndex + 1} / $pageCount", color = TextSecondarySlate)
                        Spacer(modifier = Modifier.width(12.dp))
                        IconButton(
                            enabled = pageIndex < pageCount - 1,
                            onClick = { pageIndex = (pageIndex + 1).coerceAtMost(pageCount - 1) }
                        ) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next page", tint = CyanAccent)
                        }
                    }
                }
            }
        }
    }
}
