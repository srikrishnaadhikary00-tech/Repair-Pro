package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.CommunityReportCloud
import com.example.data.remote.CommunityUserRestrictionCloud
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun AdminCommunityModerationHeader(
    allPosts: List<CommunityPostCloud>,
    allReports: List<CommunityReportCloud>,
    blockedUsers: List<CommunityUserRestrictionCloud> = emptyList(),
    activeFilter: String,
    onSelectFilter: (String) -> Unit
) {
    val pendingCount = allPosts.count { it.approvalStatus == "PENDING" }
    val approvedCount = allPosts.count { it.approvalStatus == "APPROVED" }
    val rejectedCount = allPosts.count { it.approvalStatus == "REJECTED" }
    val openReports = allReports.count { it.status == "OPEN" }
    val blockedCount = blockedUsers.size

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Technician Community Moderation",
            style = MaterialTheme.typography.titleMedium,
            color = CyanAccent,
            modifier = Modifier.testTag("admin_community_heading")
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            CommunityStatMini("Pending", "$pendingCount", if (pendingCount > 0) WarningAmber else SuccessGreen, Modifier.weight(1f))
            CommunityStatMini("Approved", "$approvedCount", SuccessGreen, Modifier.weight(1f))
            CommunityStatMini("Reports", "$openReports", if (openReports > 0) ErrorCrimson else CyanAccent, Modifier.weight(1f))
            CommunityStatMini("Blocked", "$blockedCount", if (blockedCount > 0) ErrorCrimson else TextSecondarySlate, Modifier.weight(1f))
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val hiddenDeletedCount = allPosts.count { it.isHidden || it.isDeleted }
            listOf(
                "PENDING" to "Pending ($pendingCount)",
                "APPROVED" to "Approved ($approvedCount)",
                "REJECTED" to "Rejected ($rejectedCount)",
                "HIDDEN" to "Hidden/Deleted ($hiddenDeletedCount)",
                "ALL" to "All (${allPosts.size})",
                "REPORTS" to "Reports ($openReports)",
                "BLOCKED" to "Blocked Users ($blockedCount)"
            ).forEach { (key, label) ->
                FilterChip(
                    selected = activeFilter == key,
                    onClick = { onSelectFilter(key) },
                    label = { Text(label) },
                    modifier = Modifier.testTag("admin_community_filter_${key.lowercase()}"),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricBluePrimary,
                        selectedLabelColor = TextPrimaryWhite,
                        containerColor = SecondaryNavySurface,
                        labelColor = TextSecondarySlate
                    )
                )
            }
        }
    }
}

@Composable
private fun CommunityStatMini(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge, color = accent, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate, maxLines = 1)
        }
    }
}

@Composable
fun AdminCommunityPostModerationCard(
    post: CommunityPostCloud,
    isAuthorBlocked: Boolean = false,
    onModerate: (postId: String, newStatus: String, note: String, authorUid: String, postTitle: String) -> Unit,
    onTogglePin: (postId: String, pinned: Boolean) -> Unit = { _, _ -> },
    onBlockUser: (targetUid: String, userName: String, blocked: Boolean, reason: String) -> Unit = { _, _, _, _ -> },
    onToggleHidden: (postId: String, hidden: Boolean) -> Unit = { _, _ -> },
    onSoftDelete: (CommunityPostCloud, String) -> Unit = { _, _ -> },
    onRestore: (String) -> Unit = {},
    onEditPost: (postId: String, title: String, body: String, brand: String, model: String, code: String) -> Unit = { _, _, _, _, _, _ -> },
    onRemovePhoto: (CommunityPostCloud, Int) -> Unit = { _, _ -> },
    onDelete: (CommunityPostCloud) -> Unit
) {
    val pid = post.postId.ifBlank { post.id }
    val photos = remember(post) { post.resolvedPhotoUrls() }
    var note by remember(pid, post.moderationNote) { mutableStateOf(post.moderationNote) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxWidth().testTag("admin_community_post_$pid"),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (post.isPinned) CyanAccent.copy(alpha = 0.6f) else CardBorderSubtle)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(post.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${post.category} • By ${post.authorName} • ${formatCommunityTimestamp(post.createdAt)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanAccent
                    )
                }
                CommunityStatusPill(status = post.approvalStatus)
            }

            if (post.brandName.isNotBlank() || post.errorCode.isNotBlank() || post.reportCount > 0L || post.isPinned) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (post.isPinned) {
                        Text("PINNED", style = MaterialTheme.typography.labelSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
                    }
                    if (post.brandName.isNotBlank()) {
                        Text("Brand: ${post.brandName}", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate)
                    }
                    if (post.errorCode.isNotBlank()) {
                        Text("Code: ${post.errorCode}", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                    }
                    if (post.reportCount > 0L) {
                        Text("Flags: ${post.reportCount}", style = MaterialTheme.typography.labelSmall, color = ErrorCrimson, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (post.body.isNotBlank()) {
                Text(post.body, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
            }

            if (post.isHidden || post.isDeleted) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (post.isHidden) {
                        Text("HIDDEN", style = MaterialTheme.typography.labelSmall, color = WarningAmber, fontWeight = FontWeight.Bold)
                    }
                    if (post.isDeleted) {
                        Text("SOFT DELETED", style = MaterialTheme.typography.labelSmall, color = ErrorCrimson, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (photos.size == 1) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    AsyncImage(
                        model = photos.first(),
                        contentDescription = "Community post attachment",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 120.dp, max = 190.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(DeepCardSurface)
                    )
                    IconButton(
                        onClick = { onRemovePhoto(post, 0) },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                            .size(30.dp)
                            .background(SecondaryNavySurface.copy(alpha = 0.85f), CircleShape)
                            .testTag("admin_remove_photo_${pid}_0")
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Remove photo", tint = ErrorCrimson, modifier = Modifier.size(16.dp))
                    }
                }
            } else if (photos.size > 1) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    photos.forEachIndexed { idx, url ->
                        Box(modifier = Modifier.width(150.dp).height(120.dp)) {
                            AsyncImage(
                                model = url,
                                contentDescription = "Community photo ${idx + 1}",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .width(150.dp)
                                    .height(120.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DeepCardSurface)
                            )
                            IconButton(
                                onClick = { onRemovePhoto(post, idx) },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(28.dp)
                                    .background(SecondaryNavySurface.copy(alpha = 0.85f), CircleShape)
                                    .testTag("admin_remove_photo_${pid}_$idx")
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove photo", tint = ErrorCrimson, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it.take(400) },
                label = { Text("Moderation Note (sent to author notification)") },
                singleLine = true,
                colors = communityTextFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { onModerate(pid, "APPROVED", note.trim(), post.authorUid, post.title) },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = DeepCardSurface),
                    modifier = Modifier.weight(1f).testTag("admin_approve_post_$pid")
                ) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Approve", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { onModerate(pid, "REJECTED", note.trim(), post.authorUid, post.title) },
                    border = BorderStroke(1.dp, WarningAmber),
                    modifier = Modifier.weight(1f).testTag("admin_reject_post_$pid")
                ) {
                    Icon(Icons.Filled.Close, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reject", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
                OutlinedButton(
                    onClick = { confirmDelete = true },
                    border = BorderStroke(1.dp, ErrorCrimson),
                    modifier = Modifier.testTag("admin_delete_post_$pid")
                ) {
                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete post", tint = ErrorCrimson, modifier = Modifier.size(16.dp))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { onTogglePin(pid, !post.isPinned) },
                    border = BorderStroke(1.dp, CyanAccent),
                    modifier = Modifier.weight(1f).testTag("admin_pin_post_$pid")
                ) {
                    Icon(Icons.Filled.PushPin, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (post.isPinned) "Unpin" else "Pin to Top", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                }
                if (post.authorUid.isNotBlank()) {
                    OutlinedButton(
                        onClick = {
                            onBlockUser(
                                post.authorUid,
                                post.authorName.ifBlank { post.authorUid },
                                !isAuthorBlocked,
                                note.trim().ifBlank { "Community policy violation" }
                            )
                        },
                        border = BorderStroke(1.dp, if (isAuthorBlocked) SuccessGreen else ErrorCrimson),
                        modifier = Modifier.weight(1f).testTag("admin_block_author_$pid")
                    ) {
                        Icon(
                            Icons.Filled.Block,
                            contentDescription = null,
                            tint = if (isAuthorBlocked) SuccessGreen else ErrorCrimson,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isAuthorBlocked) "Unblock User" else "Block User",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isAuthorBlocked) SuccessGreen else ErrorCrimson
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { showEditDialog = true },
                    border = BorderStroke(1.dp, CyanAccent),
                    modifier = Modifier.weight(1f).testTag("admin_edit_post_$pid")
                ) {
                    Icon(Icons.Filled.Edit, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Edit", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                }
                OutlinedButton(
                    onClick = { onToggleHidden(pid, !post.isHidden) },
                    border = BorderStroke(1.dp, if (post.isHidden) SuccessGreen else WarningAmber),
                    modifier = Modifier.weight(1f).testTag("admin_hide_post_$pid")
                ) {
                    Icon(
                        if (post.isHidden) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = null,
                        tint = if (post.isHidden) SuccessGreen else WarningAmber,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (post.isHidden) "Unhide" else "Hide",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (post.isHidden) SuccessGreen else WarningAmber
                    )
                }
                if (post.isDeleted) {
                    OutlinedButton(
                        onClick = { onRestore(pid) },
                        border = BorderStroke(1.dp, SuccessGreen),
                        modifier = Modifier.weight(1f).testTag("admin_restore_post_$pid")
                    ) {
                        Icon(Icons.Filled.RestoreFromTrash, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Restore", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                    }
                } else {
                    OutlinedButton(
                        onClick = { onSoftDelete(post, note.trim()) },
                        border = BorderStroke(1.dp, WarningAmber),
                        modifier = Modifier.weight(1f).testTag("admin_soft_delete_post_$pid")
                    ) {
                        Text("Soft Del", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                    }
                }
            }
        }
    }

    if (showEditDialog) {
        var editTitle by remember(pid) { mutableStateOf(post.title) }
        var editBody by remember(pid) { mutableStateOf(post.body) }
        var editBrand by remember(pid) { mutableStateOf(post.brandName) }
        var editModel by remember(pid) { mutableStateOf(post.modelName) }
        var editCode by remember(pid) { mutableStateOf(post.errorCode) }
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            containerColor = SecondaryNavySurface,
            title = { Text("Edit Community Post", color = CyanAccent, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = editTitle, onValueChange = { editTitle = it.take(140) }, label = { Text("Title *") }, colors = communityTextFieldColors(), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editBody, onValueChange = { editBody = it.take(3000) }, label = { Text("Description") }, minLines = 3, colors = communityTextFieldColors(), modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = editBrand, onValueChange = { editBrand = it.take(80) }, label = { Text("Brand") }, singleLine = true, colors = communityTextFieldColors(), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = editCode, onValueChange = { editCode = it.take(32) }, label = { Text("Code") }, singleLine = true, colors = communityTextFieldColors(), modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(value = editModel, onValueChange = { editModel = it.take(100) }, label = { Text("Model") }, singleLine = true, colors = communityTextFieldColors(), modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showEditDialog = false
                        onEditPost(pid, editTitle, editBody, editBrand, editModel, editCode)
                    },
                    enabled = editTitle.trim().length >= 2,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) { Text("Cancel", color = TextSecondarySlate) }
            }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = SecondaryNavySurface,
            title = { Text("Delete Community Post?", color = ErrorCrimson, fontWeight = FontWeight.Bold) },
            text = { Text("Permanently remove \"${post.title}\" and all attached photos?", color = TextPrimaryWhite) },
            confirmButton = {
                Button(
                    onClick = {
                        confirmDelete = false
                        onDelete(post)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorCrimson)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text("Cancel", color = TextSecondarySlate)
                }
            }
        )
    }
}

@Composable
fun AdminBlockedUserRow(
    restriction: CommunityUserRestrictionCloud,
    onUnblock: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = restriction.userName.ifBlank { restriction.userId },
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "UID: ${restriction.userId} • ${restriction.reason.ifBlank { "Restricted" }}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondarySlate
                )
            }
            OutlinedButton(
                onClick = onUnblock,
                border = BorderStroke(1.dp, SuccessGreen)
            ) {
                Text("Unblock", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun AdminCommunityReportCard(
    report: CommunityReportCloud,
    targetPost: CommunityPostCloud?,
    onUpdateReport: (reportId: String, newStatus: String, adminNote: String) -> Unit,
    onDeleteTargetPost: (CommunityPostCloud) -> Unit
) {
    val rid = report.reportId.ifBlank { report.id }
    var adminNote by remember(rid, report.adminNote) { mutableStateOf(report.adminNote) }

    Surface(
        modifier = Modifier.fillMaxWidth().testTag("admin_community_report_$rid"),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (report.status == "OPEN") ErrorCrimson.copy(alpha = 0.5f) else CardBorderSubtle)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.Flag, contentDescription = null, tint = ErrorCrimson, modifier = Modifier.size(16.dp))
                    Text(report.reason, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                }
                CommunityStatusPill(status = report.status)
            }
            Text(
                text = "Reporter: ${report.reporterName.ifBlank { report.reporterUid }} • Post: ${targetPost?.title ?: report.postId}" +
                    if (report.commentId.isNotBlank()) " • Comment: ${report.commentId}" else "",
                style = MaterialTheme.typography.labelSmall,
                color = CyanAccent
            )
            if (report.details.isNotBlank()) {
                Text(report.details, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
            }
            OutlinedTextField(
                value = adminNote,
                onValueChange = { adminNote = it.take(400) },
                label = { Text("Admin Resolution Note") },
                singleLine = true,
                colors = communityTextFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { onUpdateReport(rid, "RESOLVED", adminNote.trim()) },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = DeepCardSurface),
                    modifier = Modifier.weight(1f).testTag("admin_resolve_report_$rid")
                ) {
                    Text("Resolve", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { onUpdateReport(rid, "DISMISSED", adminNote.trim()) },
                    border = BorderStroke(1.dp, TextSecondarySlate),
                    modifier = Modifier.weight(1f).testTag("admin_dismiss_report_$rid")
                ) {
                    Text("Dismiss", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate)
                }
                if (targetPost != null) {
                    OutlinedButton(
                        onClick = { onDeleteTargetPost(targetPost) },
                        border = BorderStroke(1.dp, ErrorCrimson)
                    ) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete reported post", tint = ErrorCrimson, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
