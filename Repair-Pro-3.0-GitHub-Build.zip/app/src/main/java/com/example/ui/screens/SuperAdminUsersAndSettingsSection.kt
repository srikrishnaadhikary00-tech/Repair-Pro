package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.UserProfileCloud
import com.example.ui.theme.CardBorderCyan
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun AdminUsersModerationHeader(
    users: List<UserProfileCloud>,
    searchQuery: String,
    statusFilter: String,
    onSearchChange: (String) -> Unit,
    onFilterChange: (String) -> Unit,
    onSyncMyClaims: () -> Unit
) {
    val activeCount = users.count { !it.isAccountBlockedOrSuspended }
    val blockedCount = users.count { it.isAccountBlockedOrSuspended }
    val restrictedCount = users.count { it.communityRestricted || it.uploadRestricted }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.ManageAccounts, contentDescription = null, tint = CyanAccent)
                Text(
                    text = "Users & Account Moderation",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyanAccent,
                    modifier = Modifier.testTag("admin_users_heading")
                )
            }
            OutlinedButton(
                onClick = onSyncMyClaims,
                border = BorderStroke(1.dp, CyanAccent),
                modifier = Modifier.testTag("admin_sync_claims_button")
            ) {
                Icon(Icons.Filled.Sync, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Sync Claims", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Surface(modifier = Modifier.weight(1f), color = ElevatedCardSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, CardBorderSubtle)) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("${users.size}", style = MaterialTheme.typography.titleLarge, color = CyanAccent, fontWeight = FontWeight.Bold)
                    Text("Total Users", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate)
                }
            }
            Surface(modifier = Modifier.weight(1f), color = ElevatedCardSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.4f))) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("$activeCount", style = MaterialTheme.typography.titleLarge, color = SuccessGreen, fontWeight = FontWeight.Bold)
                    Text("Active", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate)
                }
            }
            Surface(modifier = Modifier.weight(1f), color = ElevatedCardSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.4f))) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("$blockedCount", style = MaterialTheme.typography.titleLarge, color = ErrorCrimson, fontWeight = FontWeight.Bold)
                    Text("Suspended/Blk", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate, maxLines = 1)
                }
            }
            Surface(modifier = Modifier.weight(1f), color = ElevatedCardSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.4f))) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("$restrictedCount", style = MaterialTheme.typography.titleLarge, color = WarningAmber, fontWeight = FontWeight.Bold)
                    Text("Restricted", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate)
                }
            }
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { onSearchChange(it.take(100)) },
            label = { Text("Search user by name, email, or UID") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = CyanAccent) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyanAccent,
                unfocusedBorderColor = CardBorderSubtle,
                focusedTextColor = TextPrimaryWhite,
                unfocusedTextColor = TextPrimaryWhite,
                focusedContainerColor = DeepCardSurface,
                unfocusedContainerColor = DeepCardSurface
            ),
            modifier = Modifier.fillMaxWidth().testTag("admin_users_search_input")
        )

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                "ALL" to "All (${users.size})",
                "ACTIVE" to "Active ($activeCount)",
                "MODERATED" to "Suspended/Blocked ($blockedCount)",
                "RESTRICTED" to "Restricted ($restrictedCount)"
            ).forEach { (key, label) ->
                FilterChip(
                    selected = statusFilter == key,
                    onClick = { onFilterChange(key) },
                    label = { Text(label) },
                    modifier = Modifier.testTag("admin_users_filter_${key.lowercase()}")
                )
            }
        }
    }
}

@Composable
fun AdminUserModerationCard(
    user: UserProfileCloud,
    currentUserUid: String,
    onModerateUser: (targetUid: String, action: String, reason: String) -> Unit,
    onDeleteUserAccount: (targetUid: String, reason: String) -> Unit
) {
    val uid = user.userId.ifBlank { user.id }
    val isSelf = uid == currentUserUid
    var reason by remember(uid, user.moderationReason) { mutableStateOf(user.moderationReason) }
    var confirmPermanentDelete by remember { mutableStateOf(false) }

    val statusColor = when {
        user.blocked || user.accountStatus.equals("BLOCKED", ignoreCase = true) -> ErrorCrimson
        user.suspended || user.accountStatus.equals("SUSPENDED", ignoreCase = true) -> WarningAmber
        else -> SuccessGreen
    }
    val statusText = when {
        user.blocked || user.accountStatus.equals("BLOCKED", ignoreCase = true) -> "BLOCKED"
        user.suspended || user.accountStatus.equals("SUSPENDED", ignoreCase = true) -> "SUSPENDED"
        else -> "ACTIVE"
    }

    Surface(
        modifier = Modifier.fillMaxWidth().testTag("admin_user_card_$uid"),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (user.isAccountBlockedOrSuspended) statusColor.copy(alpha = 0.55f) else CardBorderSubtle)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = user.displayName.ifBlank { "Unnamed User" } + if (isSelf) " (You)" else "",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (user.email.isNotBlank()) {
                        Text(user.email, style = MaterialTheme.typography.labelSmall, color = CyanAccent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("UID: $uid", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Surface(
                    color = statusColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (user.isVerifiedTechnician) {
                    Text("Verified Tech", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                }
                if (user.communityRestricted) {
                    Text("Community Restricted", style = MaterialTheme.typography.labelSmall, color = WarningAmber, fontWeight = FontWeight.Bold)
                }
                if (user.uploadRestricted) {
                    Text("Uploads Restricted", style = MaterialTheme.typography.labelSmall, color = ErrorCrimson, fontWeight = FontWeight.Bold)
                }
            }

            OutlinedTextField(
                value = reason,
                onValueChange = { reason = it.take(300) },
                label = { Text("Moderation Reason (optional)") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = CardBorderSubtle,
                    focusedTextColor = TextPrimaryWhite,
                    unfocusedTextColor = TextPrimaryWhite,
                    focusedContainerColor = DeepCardSurface,
                    unfocusedContainerColor = DeepCardSurface
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val action = if (user.suspended) "unsuspend" else "suspend"
                        onModerateUser(uid, action, reason.trim())
                    },
                    enabled = !isSelf,
                    border = BorderStroke(1.dp, if (user.suspended) SuccessGreen else WarningAmber),
                    modifier = Modifier.testTag("admin_user_suspend_$uid")
                ) {
                    Text(
                        text = if (user.suspended) "Unsuspend" else "Suspend",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (user.suspended) SuccessGreen else WarningAmber
                    )
                }
                OutlinedButton(
                    onClick = {
                        val action = if (user.blocked) "unblock" else "block"
                        onModerateUser(uid, action, reason.trim())
                    },
                    enabled = !isSelf,
                    border = BorderStroke(1.dp, if (user.blocked) SuccessGreen else ErrorCrimson),
                    modifier = Modifier.testTag("admin_user_block_$uid")
                ) {
                    Icon(Icons.Filled.Block, contentDescription = null, tint = if (user.blocked) SuccessGreen else ErrorCrimson, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (user.blocked) "Unblock" else "Block",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (user.blocked) SuccessGreen else ErrorCrimson
                    )
                }
                OutlinedButton(
                    onClick = {
                        val action = if (user.communityRestricted) "unrestrict_community" else "restrict_community"
                        onModerateUser(uid, action, reason.trim())
                    },
                    enabled = !isSelf,
                    border = BorderStroke(1.dp, if (user.communityRestricted) SuccessGreen else CyanAccent),
                    modifier = Modifier.testTag("admin_user_comm_restrict_$uid")
                ) {
                    Text(
                        text = if (user.communityRestricted) "Allow Community" else "Restrict Community",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (user.communityRestricted) SuccessGreen else CyanAccent
                    )
                }
                OutlinedButton(
                    onClick = {
                        val action = if (user.uploadRestricted) "unrestrict_upload" else "restrict_upload"
                        onModerateUser(uid, action, reason.trim())
                    },
                    enabled = !isSelf,
                    border = BorderStroke(1.dp, if (user.uploadRestricted) SuccessGreen else WarningAmber),
                    modifier = Modifier.testTag("admin_user_upload_restrict_$uid")
                ) {
                    Icon(Icons.Filled.UploadFile, contentDescription = null, tint = if (user.uploadRestricted) SuccessGreen else WarningAmber, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (user.uploadRestricted) "Allow Uploads" else "Restrict Uploads",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (user.uploadRestricted) SuccessGreen else WarningAmber
                    )
                }
                if (user.isAccountBlockedOrSuspended || user.communityRestricted || user.uploadRestricted) {
                    OutlinedButton(
                        onClick = { onModerateUser(uid, "restore", reason.trim()) },
                        enabled = !isSelf,
                        border = BorderStroke(1.dp, SuccessGreen)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Restore All", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                    }
                }
                OutlinedButton(
                    onClick = { confirmPermanentDelete = true },
                    enabled = !isSelf,
                    border = BorderStroke(1.dp, ErrorCrimson),
                    modifier = Modifier.testTag("admin_user_delete_$uid")
                ) {
                    Icon(Icons.Filled.DeleteForever, contentDescription = "Delete Account", tint = ErrorCrimson, modifier = Modifier.size(15.dp))
                }
            }
        }
    }

    if (confirmPermanentDelete) {
        AlertDialog(
            onDismissRequest = { confirmPermanentDelete = false },
            containerColor = SecondaryNavySurface,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = ErrorCrimson)
                    Text("Permanently Delete User?", color = ErrorCrimson, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    text = "This invokes the server-side admin Edge Function to delete ${user.displayName.ifBlank { uid }} (${user.email}) from Firebase Auth, revoke refresh tokens, and clean up cloud profile & verification files.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimaryWhite
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmPermanentDelete = false
                        onDeleteUserAccount(uid, reason.trim().ifBlank { "Deleted by Super Admin" })
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorCrimson)
                ) {
                    Text("Delete Permanently")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmPermanentDelete = false }) {
                    Text("Cancel", color = TextSecondarySlate)
                }
            }
        )
    }
}

@Composable
fun AdminExpandedGlobalSettingsCard(
    globalConfig: AppSettingCloud,
    publishedCount: Int,
    onSaveFullConfig: (AppSettingCloud) -> Unit,
    onExportJson: () -> Unit
) {
    var announcement by remember(globalConfig) { mutableStateOf(globalConfig.announcement) }
    var maintenanceNotice by remember(globalConfig) { mutableStateOf(globalConfig.maintenanceNotice) }
    var maintenanceMode by remember(globalConfig) { mutableStateOf(globalConfig.maintenanceMode) }
    var schemaVersionText by remember(globalConfig) { mutableStateOf(globalConfig.schemaVersion.toString()) }
    var minVersion by remember(globalConfig) { mutableStateOf(globalConfig.minSupportedVersion.ifBlank { "1.0.0" }) }
    var minVersionCodeText by remember(globalConfig) { mutableStateOf(globalConfig.minSupportedVersionCode.toString()) }
    var latestVersionCodeText by remember(globalConfig) { mutableStateOf(globalConfig.latestVersionCode.toString()) }
    var latestVersionName by remember(globalConfig) { mutableStateOf(globalConfig.latestVersionName.ifBlank { "1.2.0" }) }
    var forceUpdate by remember(globalConfig) { mutableStateOf(globalConfig.forceUpdate) }
    var updateMessage by remember(globalConfig) { mutableStateOf(globalConfig.updateMessage) }
    var updateUrl by remember(globalConfig) { mutableStateOf(globalConfig.updateUrl) }

    var communityEnabled by remember(globalConfig) { mutableStateOf(globalConfig.communityEnabled) }
    var techniciansEnabled by remember(globalConfig) { mutableStateOf(globalConfig.techniciansEnabled) }
    var billingEnabled by remember(globalConfig) { mutableStateOf(globalConfig.billingEnabled) }
    var verificationEnabled by remember(globalConfig) { mutableStateOf(globalConfig.verificationEnabled) }
    var scannerEnabled by remember(globalConfig) { mutableStateOf(globalConfig.scannerEnabled) }
    var reportsEnabled by remember(globalConfig) { mutableStateOf(globalConfig.reportsEnabled) }
    var pdfsEnabled by remember(globalConfig) { mutableStateOf(globalConfig.pdfsEnabled) }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CyanAccent,
        unfocusedBorderColor = CardBorderSubtle,
        focusedTextColor = TextPrimaryWhite,
        unfocusedTextColor = TextPrimaryWhite,
        focusedContainerColor = DeepCardSurface,
        unfocusedContainerColor = DeepCardSurface
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CardBorderCyan)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = CyanAccent)
                Text("Remote App Control, Version Policy & Feature Flags", style = MaterialTheme.typography.titleSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
            }
            Text(
                text = "$publishedCount published cloud catalog entries streaming live to online users.",
                style = MaterialTheme.typography.bodySmall,
                color = SuccessGreen
            )

            OutlinedTextField(value = announcement, onValueChange = { announcement = it.take(400) }, label = { Text("Home Announcement Banner") }, colors = fieldColors, modifier = Modifier.fillMaxWidth())

            AdminSettingToggleRow("Maintenance Mode (Locks Non-Admin Users)", maintenanceMode, { maintenanceMode = it }, isDanger = true)
            OutlinedTextField(value = maintenanceNotice, onValueChange = { maintenanceNotice = it.take(400) }, label = { Text("Maintenance Notice") }, colors = fieldColors, modifier = Modifier.fillMaxWidth())

            HorizontalDivider(color = CardBorderSubtle)
            Text("APK Version & Update Policy", style = MaterialTheme.typography.labelLarge, color = CyanAccent)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = minVersion, onValueChange = { minVersion = it.take(24) }, label = { Text("Min Version Name") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                OutlinedTextField(value = minVersionCodeText, onValueChange = { minVersionCodeText = it.filter(Char::isDigit).take(8) }, label = { Text("Min VersionCode") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = latestVersionName, onValueChange = { latestVersionName = it.take(24) }, label = { Text("Latest Version") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                OutlinedTextField(value = latestVersionCodeText, onValueChange = { latestVersionCodeText = it.filter(Char::isDigit).take(8) }, label = { Text("Latest Code") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(value = schemaVersionText, onValueChange = { schemaVersionText = it.filter(Char::isDigit).take(6) }, label = { Text("Remote Schema Version") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
            AdminSettingToggleRow("Force Update When Below Min VersionCode", forceUpdate, { forceUpdate = it }, isDanger = true)
            OutlinedTextField(value = updateMessage, onValueChange = { updateMessage = it.take(400) }, label = { Text("Update Prompt Message") }, colors = fieldColors, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = updateUrl, onValueChange = { updateUrl = it.take(600) }, label = { Text("Play Store / APK Update URL (https://...)") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())

            HorizontalDivider(color = CardBorderSubtle)
            Text("Live Feature Switches (No APK Update Needed)", style = MaterialTheme.typography.labelLarge, color = CyanAccent)

            AdminSettingToggleRow("Technician Community Tab", communityEnabled, onCheckedChange = { communityEnabled = it })
            AdminSettingToggleRow("Find Technicians Directory", techniciansEnabled, onCheckedChange = { techniciansEnabled = it })
            AdminSettingToggleRow("Billing & Invoice Manager", billingEnabled, onCheckedChange = { billingEnabled = it })
            AdminSettingToggleRow("Technician Verification Applications", verificationEnabled, onCheckedChange = { verificationEnabled = it })
            AdminSettingToggleRow("Camera Error Scanner", scannerEnabled, onCheckedChange = { scannerEnabled = it })
            AdminSettingToggleRow("Problem Reporting", reportsEnabled, onCheckedChange = { reportsEnabled = it })
            AdminSettingToggleRow("PDF Manuals & Circuit Diagrams", pdfsEnabled, onCheckedChange = { pdfsEnabled = it })

            Button(
                onClick = {
                    val updated = globalConfig.copy(
                        configType = "GLOBAL",
                        announcement = announcement.trim(),
                        maintenanceNotice = maintenanceNotice.trim(),
                        maintenanceMode = maintenanceMode,
                        schemaVersion = schemaVersionText.toLongOrNull()?.coerceAtLeast(1L) ?: globalConfig.schemaVersion,
                        minSupportedVersion = minVersion.trim().ifBlank { "1.0.0" },
                        minSupportedVersionCode = minVersionCodeText.toLongOrNull()?.coerceAtLeast(1L) ?: 1L,
                        latestVersionCode = latestVersionCodeText.toLongOrNull()?.coerceAtLeast(1L) ?: 3L,
                        latestVersionName = latestVersionName.trim().ifBlank { "1.2.0" },
                        forceUpdate = forceUpdate,
                        updateMessage = updateMessage.trim(),
                        updateUrl = updateUrl.trim(),
                        communityEnabled = communityEnabled,
                        techniciansEnabled = techniciansEnabled,
                        billingEnabled = billingEnabled,
                        verificationEnabled = verificationEnabled,
                        scannerEnabled = scannerEnabled,
                        reportsEnabled = reportsEnabled,
                        pdfsEnabled = pdfsEnabled
                    )
                    onSaveFullConfig(updated)
                },
                modifier = Modifier.fillMaxWidth().testTag("admin_save_global_settings"),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Remote App Settings", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onExportJson,
                modifier = Modifier.fillMaxWidth().testTag("admin_export_backup_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CyanAccent)
            ) {
                Icon(Icons.Filled.Backup, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Export Complete Catalog JSON Backup", color = CyanAccent)
            }
        }
    }
}

@Composable
private fun AdminSettingToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    isDanger: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = if (isDanger && checked) ErrorCrimson else TextPrimaryWhite,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = if (isDanger) ErrorCrimson else ElectricBluePrimary
            )
        )
    }
}
