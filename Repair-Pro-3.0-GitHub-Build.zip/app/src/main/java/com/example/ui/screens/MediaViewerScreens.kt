package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ZoomOutMap
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.TechnicalDocumentCloud
import com.example.i18n.UiStrings
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.OnlineOnlyOfflineGuardCard
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.components.liquidGlassSecondaryChipColors
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.LiquidGlassTheme
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

@Composable
fun ZoomableImageViewerScreen(
    imageUrl: String,
    title: String,
    onBack: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        val nextScale = (scale * zoomChange).coerceIn(1f, 5f)
        scale = nextScale
        offset = if (nextScale > 1f) offset + panChange else Offset.Zero
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("zoomable_image_viewer")
    ) {
        LiquidGlassBackBar(
            title = title.ifBlank { "Image Viewer" },
            onBack = onBack,
            backTestTag = "viewer_back_button",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            trailing = {
                Surface(
                    modifier = Modifier.size(48.dp),
                    shape = CircleShape,
                    color = palette.glassFillElevated,
                    shadowElevation = if (palette.isDark) 2.dp else 4.dp,
                    border = BorderStroke(1.dp, palette.glassBorder)
                ) {
                    IconButton(
                        onClick = {
                            scale = 1f
                            offset = Offset.Zero
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("viewer_reset_zoom")
                    ) {
                        Icon(Icons.Filled.ZoomOutMap, contentDescription = "Reset zoom", tint = palette.primaryAccent)
                    }
                }
            }
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            if (scale > 1.2f) {
                                scale = 1f
                                offset = Offset.Zero
                            } else {
                                scale = 2.5f
                            }
                        }
                    )
                }
                .transformable(state = transformState),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = imageUrl,
                contentDescription = title,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            )
            Surface(
                color = palette.dockGlassFill,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, palette.glassBorder),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 18.dp)
            ) {
                Text(
                    text = "Pinch or double-tap to zoom (${String.format("%.1f", scale)}x)",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textSecondary,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

/**
 * Online-only PDF viewer using Android PdfRenderer.
 * Streams PDF into a transient temp file deleted on exit — NO offline download button.
 */
@Composable
fun OnlinePdfViewerScreen(
    pdfUrl: String,
    title: String,
    isOnline: Boolean,
    onRetryConnectivity: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var retryTick by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var tempFile by remember { mutableStateOf<File?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var currentPage by remember { mutableIntStateOf(0) }
    var renderedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        val nextScale = (scale * zoomChange).coerceIn(1f, 4f)
        scale = nextScale
        offset = if (nextScale > 1f) offset + panChange else Offset.Zero
    }

    DisposableEffect(pdfUrl) {
        onDispose {
            try {
                tempFile?.delete()
            } catch (_: Exception) {
                // Non-fatal cleanup
            }
        }
    }

    LaunchedEffect(pdfUrl, retryTick, isOnline) {
        if (!isOnline) {
            loading = false
            return@LaunchedEffect
        }
        loading = true
        errorMessage = null
        val result = withContext(Dispatchers.IO) {
            runCatching {
                require(pdfUrl.startsWith("https://")) { "Invalid PDF document URL." }
                val outFile = File(context.cacheDir, "online_view_${System.currentTimeMillis()}.pdf")
                val conn = (URL(pdfUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000
                    readTimeout = 20_000
                    requestMethod = "GET"
                }
                try {
                    val code = conn.responseCode
                    require(code in 200..299) { "Server returned HTTP $code while streaming PDF." }
                    conn.inputStream.use { input ->
                        outFile.outputStream().use { output -> input.copyTo(output) }
                    }
                } finally {
                    conn.disconnect()
                }
                val pfd = ParcelFileDescriptor.open(outFile, ParcelFileDescriptor.MODE_READ_ONLY)
                val count = pfd.use { fd ->
                    PdfRenderer(fd).use { renderer -> renderer.pageCount }
                }
                outFile to count
            }
        }
        loading = false
        result.onSuccess { (file, count) ->
            tempFile?.delete()
            tempFile = file
            pageCount = count
            currentPage = 0
        }.onFailure { err ->
            errorMessage = err.localizedMessage ?: "Unable to stream PDF document."
        }
    }

    LaunchedEffect(tempFile, currentPage) {
        val file = tempFile ?: return@LaunchedEffect
        if (pageCount <= 0) return@LaunchedEffect
        val bmp = withContext(Dispatchers.IO) {
            runCatching {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                    PdfRenderer(fd).use { renderer ->
                        renderer.openPage(currentPage.coerceIn(0, renderer.pageCount - 1)).use { page ->
                            val targetWidth = (page.width * 2).coerceIn(720, 1800)
                            val targetHeight = (page.height * (targetWidth.toFloat() / page.width.coerceAtLeast(1))).toInt().coerceAtLeast(400)
                            val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                            bitmap.eraseColor(android.graphics.Color.WHITE)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bitmap
                        }
                    }
                }
            }.getOrNull()
        }
        renderedBitmap = bmp
        scale = 1f
        offset = Offset.Zero
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBackground)
            .testTag("online_pdf_viewer")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SecondaryNavySurface)
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("pdf_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Column {
                    Text(
                        text = title.ifBlank { "Online PDF Manual" },
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimaryWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (pageCount > 0) "Online View Only • Page ${currentPage + 1} of $pageCount" else "Online View Only",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanAccent
                    )
                }
            }
            IconButton(
                onClick = {
                    scale = 1f
                    offset = Offset.Zero
                }
            ) {
                Icon(Icons.Filled.ZoomOutMap, contentDescription = "Reset zoom", tint = CyanAccent)
            }
        }

        if (!isOnline) {
            Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                OnlineOnlyOfflineGuardCard(
                    onRetry = {
                        onRetryConnectivity()
                        retryTick += 1
                    }
                )
            }
            return
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .transformable(state = transformState),
            contentAlignment = Alignment.Center
        ) {
            when {
                loading -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(color = CyanAccent)
                        Text("Streaming PDF manual...", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                    }
                }
                errorMessage != null -> {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.PictureAsPdf, contentDescription = null, tint = ErrorCrimson, modifier = Modifier.size(44.dp))
                        Text(errorMessage ?: "Unable to load PDF.", color = TextPrimaryWhite, style = MaterialTheme.typography.bodyMedium)
                        Button(
                            onClick = { retryTick += 1 },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Retry")
                        }
                    }
                }
                renderedBitmap != null -> {
                    Image(
                        bitmap = renderedBitmap!!.asImageBitmap(),
                        contentDescription = "PDF page ${currentPage + 1}",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offset.x,
                                translationY = offset.y
                            )
                    )
                }
            }
        }

        if (pageCount > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SecondaryNavySurface)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { if (currentPage > 0) currentPage -= 1 },
                    enabled = currentPage > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = ElevatedCardSurface)
                ) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous page")
                    Text("Prev")
                }
                Text(
                    text = "Page ${currentPage + 1} / $pageCount",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimaryWhite
                )
                Button(
                    onClick = { if (currentPage < pageCount - 1) currentPage += 1 },
                    enabled = currentPage < pageCount - 1,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                ) {
                    Text("Next")
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next page")
                }
            }
        }
    }
}

@Composable
fun TechnicalDocumentsLibraryScreen(
    strings: UiStrings,
    documents: List<TechnicalDocumentCloud>,
    isOnline: Boolean,
    initialCategory: String = "ALL",
    cachedPdfIds: Set<String> = emptySet(),
    downloadingPdfIds: Set<String> = emptySet(),
    onDownloadOffline: (TechnicalDocumentCloud) -> Unit = {},
    onRemoveOffline: (String) -> Unit = {},
    onOpenOfflinePdf: (docId: String, title: String) -> Unit = { _, _ -> },
    onRetryConnectivity: () -> Unit,
    onOpenPdf: (url: String, title: String) -> Unit,
    onOpenImage: (url: String, title: String) -> Unit,
    onBack: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    var selectedCategory by remember { mutableStateOf(initialCategory) }
    var selectedType by remember { mutableStateOf("ALL") }
    var query by remember { mutableStateOf("") }

    val filtered = remember(documents, selectedCategory, selectedType, query, isOnline, cachedPdfIds) {
        val q = query.trim().lowercase()
        documents.filter { doc ->
            val docKey = doc.docId.ifBlank { doc.id }
            val availableOfflineNow = isOnline || (doc.offlineAvailable && !doc.isDeleted && docKey in cachedPdfIds)
            val catOk = selectedCategory == "ALL" || doc.categoryId.equals(selectedCategory, ignoreCase = true)
            val typeOk = selectedType == "ALL" || doc.docType.equals(selectedType, ignoreCase = true)
            val qOk = q.isEmpty() ||
                doc.title.lowercase().contains(q) ||
                doc.brandName.lowercase().contains(q) ||
                doc.modelName.lowercase().contains(q) ||
                doc.description.lowercase().contains(q)
            availableOfflineNow && catOk && typeOk && qOk
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("technical_documents_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = strings.pdfAndDiagramsTitle,
                subtitle = if (isOnline) "Service manuals & wiring schematics • Approved offline save supported"
                else "Offline mode • Showing admin-approved saved manuals",
                onBack = onBack,
                backTestTag = "docs_back_button"
            )
        }

        if (!isOnline) {
            item {
                OnlineOnlyOfflineGuardCard(
                    title = strings.noInternetTitle,
                    message = if (cachedPdfIds.isNotEmpty()) {
                        "Online manuals are paused. ${cachedPdfIds.size} approved offline manual(s) available below."
                    } else {
                        strings.noInternetGuidesMessage
                    },
                    retryLabel = strings.retry,
                    onRetry = onRetryConnectivity
                )
            }
            if (cachedPdfIds.isEmpty()) return@LazyColumn
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search brand, model, manual or circuit diagram...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("docs_search_input"),
                shape = RoundedCornerShape(16.dp),
                colors = liquidGlassFieldColors(),
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear", tint = palette.textSecondary)
                        }
                    }
                }
            )
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val cats = listOf("ALL" to "All", "ac" to "AC", "fridge" to "Fridge", "washer" to "Washer", "general" to "General")
                items(cats) { (id, label) ->
                    val selected = selectedCategory == id
                    FilterChip(
                        selected = selected,
                        onClick = { selectedCategory = id },
                        label = { Text(label) },
                        colors = liquidGlassFilterChipColors(),
                        border = liquidGlassFilterChipBorder(selected)
                    )
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val types = listOf("ALL" to "All Types", "PDF_MANUAL" to "PDF Manuals", "CIRCUIT_DIAGRAM" to "Circuit Diagrams", "REPAIR_PHOTO" to "Repair Photos")
                items(types) { (id, label) ->
                    val selected = selectedType == id
                    FilterChip(
                        selected = selected,
                        onClick = { selectedType = id },
                        label = { Text(label) },
                        colors = liquidGlassSecondaryChipColors(),
                        border = liquidGlassFilterChipBorder(selected)
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            item {
                LiquidGlassCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = 24.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Filled.Description, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(36.dp))
                        Text("No technical manuals or diagrams published yet", color = palette.textPrimary, style = MaterialTheme.typography.titleSmall)
                        Text("Super Admin uploads of PDF service manuals and circuit diagrams appear here live.", color = palette.textSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        } else {
            items(filtered, key = { it.docId.ifBlank { it.id } }) { doc ->
                val docKey = doc.docId.ifBlank { doc.id }
                val isPdf = doc.mimeType.contains("pdf", ignoreCase = true) || doc.docType == "PDF_MANUAL"
                val isCachedOffline = docKey in cachedPdfIds
                val isDownloading = docKey in downloadingPdfIds
                val iconTint = when (doc.docType) {
                    "PDF_MANUAL" -> palette.error
                    "CIRCUIT_DIAGRAM" -> palette.secondaryAccent
                    else -> palette.success
                }
                LiquidGlassCard(
                    shape = RoundedCornerShape(20.dp),
                    onClick = {
                        if (isPdf) {
                            if (!isOnline && isCachedOffline) {
                                onOpenOfflinePdf(docKey, doc.title)
                            } else {
                                onOpenPdf(doc.fileUrl, doc.title)
                            }
                        } else {
                            onOpenImage(doc.fileUrl, doc.title)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tech_doc_card_$docKey"),
                    contentPadding = 14.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(iconTint.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (doc.docType) {
                                    "PDF_MANUAL" -> Icons.Filled.PictureAsPdf
                                    "CIRCUIT_DIAGRAM" -> Icons.Filled.AccountTree
                                    else -> Icons.Filled.Image
                                },
                                contentDescription = doc.docType,
                                tint = iconTint
                            )
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(doc.title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.Bold)
                            val meta = listOfNotNull(
                                doc.categoryId.uppercase(),
                                doc.brandName.takeIf { it.isNotBlank() },
                                doc.modelName.takeIf { it.isNotBlank() }
                            ).joinToString(" • ")
                            Text(meta, style = MaterialTheme.typography.labelSmall, color = palette.primaryAccent, fontWeight = FontWeight.SemiBold)
                            if (doc.description.isNotBlank()) {
                                Text(doc.description, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                            if (isCachedOffline) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Filled.OfflinePin, contentDescription = null, tint = palette.success, modifier = Modifier.size(14.dp))
                                    Text("Saved Offline", style = MaterialTheme.typography.labelSmall, color = palette.success)
                                }
                            }
                        }
                        if (isPdf && doc.docType == "PDF_MANUAL" && doc.offlineAvailable && !doc.isDeleted) {
                            if (isDownloading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = palette.primaryAccent,
                                    strokeWidth = 2.dp
                                )
                            } else if (isCachedOffline) {
                                IconButton(
                                    onClick = { onRemoveOffline(docKey) },
                                    modifier = Modifier.testTag("tech_doc_remove_offline_$docKey")
                                ) {
                                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Remove offline PDF", tint = palette.textSecondary)
                                }
                            } else if (isOnline) {
                                IconButton(
                                    onClick = { onDownloadOffline(doc) },
                                    modifier = Modifier.testTag("tech_doc_download_offline_$docKey")
                                ) {
                                    Icon(Icons.Filled.Download, contentDescription = "Save PDF offline", tint = palette.primaryAccent)
                                }
                            }
                        }
                        Surface(
                            color = palette.primaryAccent.copy(alpha = if (palette.isDark) 0.22f else 0.12f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = when {
                                    isPdf && !isOnline && isCachedOffline -> "OFFLINE"
                                    isPdf -> "VIEW PDF"
                                    else -> "ZOOM"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.primaryAccent,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
