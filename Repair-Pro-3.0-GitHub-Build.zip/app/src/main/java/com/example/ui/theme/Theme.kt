package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class LiquidGlassPalette(
    val isDark: Boolean,
    val background: Color,
    val secondaryBackground: Color,
    val glassAccent: Color,
    val primaryAccent: Color,
    val secondaryAccent: Color,
    val onPrimaryAccent: Color,
    val cardSurface: Color,
    val glassFill: Color,
    val glassFillElevated: Color,
    val glassFillSubtle: Color,
    val dockGlassFill: Color,
    val dialogSurface: Color,
    val glassBorder: Color,
    val glassBorderAccent: Color,
    val specularSheenTop: Color,
    val specularSheenBottom: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val orbPrimary: Color,
    val orbSecondary: Color,
    val screenGradient: Brush,
    val heroGradient: Brush,
    val primaryButtonGradient: Brush
)

val LightLiquidGlassPalette = LiquidGlassPalette(
    isDark = false,
    background = LiquidLightBackground,
    secondaryBackground = LiquidLightSecondaryBackground,
    glassAccent = LiquidLightGlassAccent,
    primaryAccent = LiquidLightPrimaryAccent,
    secondaryAccent = LiquidLightSecondaryAccent,
    onPrimaryAccent = Color.White,
    cardSurface = LiquidLightCardSurface,
    glassFill = LiquidLightCardSurface.copy(alpha = 0.78f),
    glassFillElevated = LiquidLightCardSurface.copy(alpha = 0.90f),
    glassFillSubtle = LiquidLightSecondaryBackground.copy(alpha = 0.62f),
    dockGlassFill = LiquidLightCardSurface.copy(alpha = 0.88f),
    dialogSurface = LiquidLightCardSurface.copy(alpha = 0.96f),
    glassBorder = Color.White.copy(alpha = 0.88f),
    glassBorderAccent = LiquidLightPrimaryAccent.copy(alpha = 0.34f),
    specularSheenTop = Color.White.copy(alpha = 0.78f),
    specularSheenBottom = LiquidLightGlassAccent.copy(alpha = 0.24f),
    textPrimary = LiquidLightTextPrimary,
    textSecondary = LiquidLightTextSecondary,
    textMuted = LiquidLightTextMuted,
    success = SuccessGreenLightMode,
    warning = WarningAmberLightMode,
    error = ErrorCrimsonLightMode,
    orbPrimary = LiquidLightPrimaryAccent.copy(alpha = 0.14f),
    orbSecondary = LiquidLightGlassAccent.copy(alpha = 0.52f),
    screenGradient = Brush.verticalGradient(
        colors = listOf(
            LiquidLightBackground,
            Color(0xFFE7EEFF),
            LiquidLightSecondaryBackground
        )
    ),
    heroGradient = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.92f),
            LiquidLightSecondaryBackground.copy(alpha = 0.78f),
            LiquidLightGlassAccent.copy(alpha = 0.68f)
        )
    ),
    primaryButtonGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF6650D2), LiquidLightPrimaryAccent, Color(0xFF5D8CE6))
    )
)

val DarkLiquidGlassPalette = LiquidGlassPalette(
    isDark = true,
    background = LiquidDarkBackground,
    secondaryBackground = LiquidDarkSecondaryBackground,
    glassAccent = LiquidDarkSecondaryAccent,
    primaryAccent = LiquidDarkPrimaryAccent,
    secondaryAccent = LiquidDarkSecondaryAccent,
    onPrimaryAccent = Color(0xFF090E1A),
    cardSurface = LiquidDarkGlassSurface,
    glassFill = LiquidDarkGlassSurface.copy(alpha = 0.72f),
    glassFillElevated = LiquidDarkGlassSurface.copy(alpha = 0.86f),
    glassFillSubtle = LiquidDarkSecondaryBackground.copy(alpha = 0.80f),
    dockGlassFill = Color(0xE0141D2E),
    dialogSurface = Color(0xF5151F30),
    glassBorder = Color.White.copy(alpha = 0.16f),
    glassBorderAccent = LiquidDarkSecondaryAccent.copy(alpha = 0.38f),
    specularSheenTop = Color.White.copy(alpha = 0.15f),
    specularSheenBottom = LiquidDarkSecondaryAccent.copy(alpha = 0.08f),
    textPrimary = LiquidDarkTextPrimary,
    textSecondary = LiquidDarkTextSecondary,
    textMuted = LiquidDarkTextMuted,
    success = SuccessGreen,
    warning = WarningAmber,
    error = ErrorCrimson,
    orbPrimary = LiquidDarkPrimaryAccent.copy(alpha = 0.14f),
    orbSecondary = LiquidDarkSecondaryAccent.copy(alpha = 0.12f),
    screenGradient = Brush.verticalGradient(
        colors = listOf(
            LiquidDarkBackground,
            Color(0xFF0C1322),
            LiquidDarkSecondaryBackground
        )
    ),
    heroGradient = Brush.linearGradient(
        colors = listOf(
            LiquidDarkGlassSurface.copy(alpha = 0.88f),
            Color(0xFF17233A).copy(alpha = 0.84f),
            Color(0xFF142A3E).copy(alpha = 0.82f)
        )
    ),
    primaryButtonGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF7B68EE), LiquidDarkPrimaryAccent, LiquidDarkSecondaryAccent)
    )
)

val LocalLiquidGlassColors = staticCompositionLocalOf { DarkLiquidGlassPalette }

object LiquidGlassTheme {
    val colors: LiquidGlassPalette
        @Composable
        get() = LocalLiquidGlassColors.current
}

private val RepairProLightColorScheme = lightColorScheme(
    primary = LiquidLightPrimaryAccent,
    onPrimary = Color.White,
    primaryContainer = LiquidLightSecondaryBackground,
    onPrimaryContainer = LiquidLightTextPrimary,
    secondary = LiquidLightSecondaryAccent,
    onSecondary = Color.White,
    secondaryContainer = LiquidLightGlassAccent,
    onSecondaryContainer = LiquidLightTextPrimary,
    tertiary = SuccessGreenLightMode,
    onTertiary = Color.White,
    background = LiquidLightBackground,
    onBackground = LiquidLightTextPrimary,
    surface = LiquidLightCardSurface,
    onSurface = LiquidLightTextPrimary,
    surfaceVariant = LiquidLightSecondaryBackground,
    onSurfaceVariant = LiquidLightTextSecondary,
    outline = LiquidLightPrimaryAccent.copy(alpha = 0.28f),
    outlineVariant = Color(0xFFCBD5E1),
    error = ErrorCrimsonLightMode,
    onError = Color.White,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF7F1D1D)
)

private val RepairProDarkColorScheme = darkColorScheme(
    primary = LiquidDarkPrimaryAccent,
    onPrimary = Color(0xFF090E1A),
    primaryContainer = LiquidDarkGlassSurface,
    onPrimaryContainer = LiquidDarkTextPrimary,
    secondary = LiquidDarkSecondaryAccent,
    onSecondary = LiquidDarkBackground,
    secondaryContainer = LiquidDarkSecondaryBackground,
    onSecondaryContainer = LiquidDarkTextPrimary,
    tertiary = SuccessGreen,
    onTertiary = LiquidDarkBackground,
    background = LiquidDarkBackground,
    onBackground = LiquidDarkTextPrimary,
    surface = LiquidDarkSecondaryBackground,
    onSurface = LiquidDarkTextPrimary,
    surfaceVariant = LiquidDarkGlassSurface,
    onSurfaceVariant = LiquidDarkTextSecondary,
    outline = Color.White.copy(alpha = 0.16f),
    outlineVariant = Color(0xFF28354C),
    error = ErrorCrimson,
    onError = Color.White,
    errorContainer = Color(0xFF3E121B),
    onErrorContainer = Color(0xFFFFB3BC)
)

private val RepairProShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun RepairProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val palette = if (darkTheme) DarkLiquidGlassPalette else LightLiquidGlassPalette
    val colorScheme = if (darkTheme) RepairProDarkColorScheme else RepairProLightColorScheme

    CompositionLocalProvider(LocalLiquidGlassColors provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = RepairProTypography,
            shapes = RepairProShapes,
            content = content
        )
    }
}
