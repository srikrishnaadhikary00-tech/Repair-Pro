package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.TechnicianVerificationRequestCloud
import com.example.data.remote.V2DomainHelper
import com.example.i18n.UiStrings
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun TechnicianVerificationScreen(
    strings: UiStrings,
    defaultName: String,
    existingRequest: TechnicianVerificationRequestCloud?,
    submitting: Boolean,
    uploadProgress: Float?,
    isUploadRestricted: Boolean = false,
    uploadBlockedReason: String = "",
    onBack: () -> Unit,
    onSubmit: (
        draft: TechnicianVerificationRequestCloud,
        profilePhotoBytes: ByteArray?,
        profilePhotoMime: String,
        credentialBytes: ByteArray?,
        credentialMime: String,
        credentialFileName: String
    ) -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val context = LocalContext.current
    val currentStatus = existingRequest?.status ?: "NONE"
    val canSubmit = currentStatus in listOf("NONE", "PENDING", "REJECTED") && !isUploadRestricted

    var fullName by remember(existingRequest) { mutableStateOf(existingRequest?.fullName?.ifBlank { defaultName } ?: defaultName) }
    var mobileNumber by remember(existingRequest) { mutableStateOf(existingRequest?.mobileNumber ?: "") }
    var experience by remember(existingRequest) { mutableStateOf(existingRequest?.experience ?: "") }
    var bio by remember(existingRequest) { mutableStateOf(existingRequest?.bio ?: "") }
    var fullAddress by remember(existingRequest) { mutableStateOf(existingRequest?.fullAddress ?: "") }
    var state by remember(existingRequest) { mutableStateOf(existingRequest?.state ?: "") }
    var district by remember(existingRequest) { mutableStateOf(existingRequest?.district ?: "") }
    var cityArea by remember(existingRequest) { mutableStateOf(existingRequest?.cityArea ?: "") }
    var pinCode by remember(existingRequest) { mutableStateOf(existingRequest?.pinCode ?: "") }
    var selectedCategories by remember(existingRequest) {
        mutableStateOf(existingRequest?.serviceCategories?.toSet() ?: setOf("AC"))
    }

    var pickedAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var pickedAvatarBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pickedAvatarMime by remember { mutableStateOf("image/jpeg") }

    var pickedCredBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pickedCredMime by remember { mutableStateOf("application/pdf") }
    var pickedCredName by remember(existingRequest) { mutableStateOf(existingRequest?.credentialDocName ?: "") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null && bytes.size < 10 * 1024 * 1024) {
                pickedAvatarUri = uri
                pickedAvatarBytes = bytes
                pickedAvatarMime = context.contentResolver.getType(uri) ?: "image/jpeg"
                validationError = null
            } else {
                validationError = "Profile photo must be under 10 MB."
            }
        }
    }

    val credentialPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null && bytes.size < 10 * 1024 * 1024) {
                pickedCredBytes = bytes
                pickedCredMime = context.contentResolver.getType(uri) ?: "application/pdf"
                pickedCredName = resolveDisplayName(context, uri) ?: "Credential_Document"
                validationError = null
            } else {
                validationError = "Credential document must be under 10 MB."
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("technician_verification_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = strings.technicianVerificationTitle,
                subtitle = "Apply for an Admin-Verified Technician Badge",
                onBack = onBack,
                backTestTag = "verification_back_button"
            )
        }

        if (isUploadRestricted) {
            item {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth().testTag("verification_upload_restricted_banner"),
                    shape = RoundedCornerShape(18.dp),
                    customContainerColor = palette.error.copy(alpha = if (palette.isDark) 0.16f else 0.10f),
                    customBorderColor = palette.error.copy(alpha = 0.55f),
                    contentPadding = 14.dp
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = palette.error)
                        Column {
                            Text("File Uploads Restricted", color = palette.error, fontWeight = FontWeight.Bold)
                            Text(
                                text = uploadBlockedReason.ifBlank { "Super Admin restricted verification uploads for this account." },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textPrimary
                            )
                        }
                    }
                }
            }
        }

        // Live Status Card
        if (existingRequest != null) {
            item {
                val (statusColor, statusTitle, statusIcon) = when (existingRequest.status) {
                    "VERIFIED" -> Triple(palette.success, "Verified Technician Active", Icons.Filled.Verified)
                    "REJECTED" -> Triple(palette.error, "Verification Rejected", Icons.Filled.Warning)
                    "SUSPENDED" -> Triple(palette.error, "Account Suspended", Icons.Filled.Warning)
                    else -> Triple(palette.warning, "Pending Super Admin Review", Icons.Filled.HourglassTop)
                }
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth().testTag("verification_status_banner"),
                    shape = RoundedCornerShape(20.dp),
                    customContainerColor = statusColor.copy(alpha = if (palette.isDark) 0.15f else 0.10f),
                    customBorderColor = statusColor.copy(alpha = 0.55f),
                    contentPadding = 14.dp
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(statusIcon, contentDescription = statusTitle, tint = statusColor, modifier = Modifier.size(26.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(statusTitle, style = MaterialTheme.typography.titleSmall, color = statusColor, fontWeight = FontWeight.Bold)
                            val detail = when (existingRequest.status) {
                                "VERIFIED" -> "Your profile is verified and visible to customers in Find Technicians."
                                "REJECTED" -> existingRequest.rejectionReason.ifBlank { "Please update your details or credentials and resubmit." }
                                "SUSPENDED" -> existingRequest.rejectionReason.ifBlank { "Your verified technician status is suspended by Super Admin." }
                                else -> "Your details & private credentials are in the Super Admin verification queue."
                            }
                            Text(detail, style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                        }
                    }
                }
            }
        }

        // Profile Photo & Private Credential Upload Card
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                elevated = true,
                contentPadding = 16.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Profile Photo & Private Credentials", style = MaterialTheme.typography.titleSmall, color = palette.primaryAccent, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(palette.glassFillSubtle)
                                .border(1.4.dp, palette.glassBorderAccent, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            val avatarModel: Any? = pickedAvatarUri ?: existingRequest?.profilePhotoUrl?.takeIf { it.startsWith("https://") }
                            if (avatarModel != null) {
                                AsyncImage(
                                    model = avatarModel,
                                    contentDescription = "Technician photo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                                )
                            } else {
                                Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, tint = palette.primaryAccent)
                            }
                        }
                        OutlinedButton(
                            onClick = { avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            enabled = canSubmit && !submitting,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, palette.primaryAccent),
                            modifier = Modifier.testTag("verification_pick_avatar_button")
                        ) {
                            Text("Select Profile Photo", color = palette.primaryAccent)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ID / Trade Certificate (Private)", style = MaterialTheme.typography.labelLarge, color = palette.textPrimary)
                            Text(
                                text = pickedCredName.ifBlank { "Optional PDF or image — visible only to you & Super Admin" },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (pickedCredName.isNotBlank()) palette.success else palette.textMuted
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = { credentialPicker.launch(arrayOf("application/pdf", "image/*")) },
                            enabled = canSubmit && !submitting,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, palette.glassBorderAccent),
                            modifier = Modifier.testTag("verification_pick_credential_button")
                        ) {
                            Icon(Icons.Filled.AttachFile, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Attach", color = palette.primaryAccent)
                        }
                    }
                }
            }
        }

        // Service Categories
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Service Specializations", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    V2DomainHelper.ALLOWED_SERVICE_CATEGORIES.forEach { cat ->
                        val selected = cat in selectedCategories
                        FilterChip(
                            selected = selected,
                            onClick = {
                                if (!canSubmit) return@FilterChip
                                selectedCategories = if (selected && selectedCategories.size > 1) {
                                    selectedCategories - cat
                                } else {
                                    selectedCategories + cat
                                }
                            },
                            label = { Text(if (cat == "Washing Machine") "Washer" else cat) },
                            colors = liquidGlassFilterChipColors(),
                            border = liquidGlassFilterChipBorder(selected),
                            shape = RoundedCornerShape(14.dp)
                        )
                    }
                }
            }
        }

        // Form Fields
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                VerificationTextField("Full Name *", fullName, { fullName = it }, canSubmit, "ver_name_input")
                VerificationTextField("Mobile Number *", mobileNumber, { mobileNumber = it }, canSubmit, "ver_mobile_input")
                VerificationTextField("Years of Experience (e.g. 6 Years)", experience, { experience = it }, canSubmit, "ver_exp_input")
                VerificationTextField("Workshop / Service Bio", bio, { bio = it }, canSubmit, "ver_bio_input", minLines = 3)
                VerificationTextField("Full Workshop / Service Address *", fullAddress, { fullAddress = it }, canSubmit, "ver_address_input")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        VerificationTextField("State *", state, { state = it }, canSubmit, "ver_state_input")
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        VerificationTextField("District *", district, { district = it }, canSubmit, "ver_district_input")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        VerificationTextField("City / Area *", cityArea, { cityArea = it }, canSubmit, "ver_city_input")
                    }
                    Box(modifier = Modifier.weight(0.8f)) {
                        VerificationTextField("PIN Code *", pinCode, { pinCode = it }, canSubmit, "ver_pin_input")
                    }
                }
            }
        }

        if (uploadProgress != null) {
            item {
                LinearProgressIndicator(
                    progress = { uploadProgress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)),
                    color = palette.primaryAccent,
                    trackColor = palette.glassFillSubtle
                )
            }
        }

        if (validationError != null) {
            item {
                Text(validationError ?: "", color = palette.warning, style = MaterialTheme.typography.bodySmall)
            }
        }

        item {
            Button(
                onClick = {
                    val cats = selectedCategories.toList()
                    val err = V2DomainHelper.validateVerificationApplication(
                        fullName = fullName,
                        mobileNumber = mobileNumber,
                        fullAddress = fullAddress,
                        state = state,
                        district = district,
                        cityArea = cityArea,
                        pinCode = pinCode,
                        serviceCategories = cats
                    )
                    if (err != null) {
                        validationError = err
                        return@Button
                    }
                    validationError = null
                    val draft = TechnicianVerificationRequestCloud(
                        fullName = fullName.trim(),
                        mobileNumber = mobileNumber.trim(),
                        fullAddress = fullAddress.trim(),
                        state = state.trim(),
                        district = district.trim(),
                        cityArea = cityArea.trim(),
                        pinCode = pinCode.trim(),
                        serviceCategories = cats,
                        experience = experience.trim(),
                        bio = bio.trim(),
                        profilePhotoUrl = existingRequest?.profilePhotoUrl ?: "",
                        profilePhotoStoragePath = existingRequest?.profilePhotoStoragePath ?: "",
                        credentialDocUrl = existingRequest?.credentialDocUrl ?: "",
                        credentialDocStoragePath = existingRequest?.credentialDocStoragePath ?: "",
                        credentialDocName = pickedCredName
                    )
                    onSubmit(draft, pickedAvatarBytes, pickedAvatarMime, pickedCredBytes, pickedCredMime, pickedCredName)
                },
                enabled = canSubmit && !submitting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.primaryAccent,
                    contentColor = palette.onPrimaryAccent
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("verification_submit_button")
            ) {
                if (submitting) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = palette.onPrimaryAccent, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Submitting Application...")
                } else {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (currentStatus) {
                            "VERIFIED" -> "Already Verified"
                            "SUSPENDED" -> "Contact Admin"
                            "PENDING" -> "Update Pending Application"
                            "REJECTED" -> "Resubmit for Verification"
                            else -> "Submit for Verification"
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun VerificationTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    enabled: Boolean,
    tag: String,
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        enabled = enabled,
        minLines = minLines,
        singleLine = minLines == 1,
        modifier = Modifier.fillMaxWidth().testTag(tag),
        shape = RoundedCornerShape(14.dp),
        colors = liquidGlassFieldColors()
    )
}

private fun resolveDisplayName(context: android.content.Context, uri: Uri): String? {
    return try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
        }
    } catch (_: Exception) {
        null
    }
}
