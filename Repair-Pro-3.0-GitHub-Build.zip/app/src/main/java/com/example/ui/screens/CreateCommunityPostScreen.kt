package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.COMMUNITY_CATEGORIES
import com.example.data.remote.CommunityDomainHelper
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.PendingCommunityPhoto
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.theme.LiquidGlassTheme
import java.io.ByteArrayOutputStream

private data class LocalPickedPhoto(
    val uri: Uri,
    val bytes: ByteArray,
    val mimeType: String,
    val contentHash: String
)

@Composable
fun CreateCommunityPostScreen(
    userName: String,
    userPhotoUrl: String,
    isVerifiedTechnician: Boolean,
    isAdmin: Boolean,
    isBlocked: Boolean,
    blockedReason: String,
    isUploadRestricted: Boolean = false,
    uploadBlockedReason: String = "",
    editingPost: CommunityPostCloud? = null,
    submitting: Boolean,
    uploadProgress: Float?,
    compressionMaxDim: Int = 1440,
    compressionQuality: Int = 82,
    compressionMaxSizeKb: Int = 4500,
    duplicateCheckEnabled: Boolean = true,
    onBack: () -> Unit,
    onSubmitNew: (
        category: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        title: String,
        body: String,
        photos: List<PendingCommunityPhoto>
    ) -> Unit,
    onSubmitEdit: (
        postId: String,
        category: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        title: String,
        body: String,
        existingPhotoUrls: List<String>,
        existingStoragePaths: List<String>,
        newPhotos: List<PendingCommunityPhoto>
    ) -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val context = LocalContext.current
    var category by remember(editingPost) { mutableStateOf(editingPost?.category ?: "AC") }
    var title by remember(editingPost) { mutableStateOf(editingPost?.title ?: "") }
    var body by remember(editingPost) { mutableStateOf(editingPost?.body ?: "") }
    var brandName by remember(editingPost) { mutableStateOf(editingPost?.brandName ?: "") }
    var modelName by remember(editingPost) { mutableStateOf(editingPost?.modelName ?: "") }
    var errorCode by remember(editingPost) { mutableStateOf(editingPost?.errorCode ?: "") }

    var existingUrls by remember(editingPost) { mutableStateOf(editingPost?.resolvedPhotoUrls() ?: emptyList()) }
    var existingPaths by remember(editingPost) { mutableStateOf(editingPost?.resolvedStoragePaths() ?: emptyList()) }
    var newPhotos by remember { mutableStateOf<List<LocalPickedPhoto>>(emptyList()) }
    var localError by remember { mutableStateOf<String?>(null) }

    val totalPhotosCount = existingUrls.size + newPhotos.size

    val multiPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 4)
    ) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        val remainingSlots = (4 - existingUrls.size - newPhotos.size).coerceAtLeast(0)
        val seenUris = newPhotos.map { it.uri.toString() }.toMutableSet()
        val seenHashes = newPhotos.map { it.contentHash }.toMutableSet()
        val picked = mutableListOf<LocalPickedPhoto>()
        var skippedDuplicates = 0

        for (uri in uris) {
            if (picked.size >= remainingSlots) break
            if (!seenUris.add(uri.toString())) {
                skippedDuplicates += 1
                continue
            }
            val compressed = compressUriToJpeg(
                context = context,
                uri = uri,
                maxDimensionPx = compressionMaxDim,
                initialQuality = compressionQuality,
                maxFileSizeKb = compressionMaxSizeKb
            ) ?: continue
            val hash = CommunityDomainHelper.sha256Hex(compressed)
            if (duplicateCheckEnabled && !seenHashes.add(hash)) {
                skippedDuplicates += 1
                continue
            }
            picked.add(
                LocalPickedPhoto(
                    uri = uri,
                    bytes = compressed,
                    mimeType = "image/jpeg",
                    contentHash = hash
                )
            )
        }
        if (picked.isEmpty() && remainingSlots > 0) {
            localError = if (skippedDuplicates > 0) {
                "Duplicate photo skipped. Please select a different photo."
            } else {
                "Unable to read selected image(s). Please try another photo."
            }
        } else {
            newPhotos = (newPhotos + picked).take((4 - existingUrls.size).coerceAtLeast(0))
            localError = if (skippedDuplicates > 0) {
                "Skipped $skippedDuplicates duplicate photo(s)."
            } else {
                null
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("create_community_post_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = if (editingPost != null) "Edit Post" else "Create Post",
                subtitle = if (isAdmin) "Admin posts publish immediately" else "Posts are reviewed by Super Admin before going live",
                onBack = onBack,
                backTestTag = "create_post_back_button"
            )
        }

        if (isBlocked || isUploadRestricted) {
            item {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    customContainerColor = palette.error.copy(alpha = if (palette.isDark) 0.16f else 0.10f),
                    customBorderColor = palette.error.copy(alpha = 0.5f),
                    contentPadding = 14.dp
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = palette.error)
                        Column {
                            Text(
                                text = if (isBlocked) "Community Posting Restricted" else "Media Uploads Restricted",
                                color = palette.error,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isBlocked) {
                                    blockedReason.ifBlank { "Your account is currently restricted from posting in Technician Community." }
                                } else {
                                    uploadBlockedReason.ifBlank { "Your account is restricted from uploading new repair photos. Text-only posts are still allowed." }
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textPrimary
                            )
                        }
                    }
                }
            }
        }

        // Logged-in Author Card
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                elevated = true,
                contentPadding = 14.dp
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(palette.primaryAccent.copy(alpha = 0.16f))
                            .border(1.dp, palette.glassBorderAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (userPhotoUrl.startsWith("https://")) {
                            AsyncImage(
                                model = userPhotoUrl,
                                contentDescription = userName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(44.dp).clip(CircleShape)
                            )
                        } else {
                            Text(
                                text = userName.take(1).uppercase().ifBlank { "T" },
                                color = palette.primaryAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(userName, color = palette.textPrimary, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                            if (isVerifiedTechnician) {
                                Icon(Icons.Filled.Verified, contentDescription = "Verified Technician", tint = palette.success, modifier = Modifier.size(16.dp))
                            }
                        }
                        Text("Sharing to Repair Pro Community", style = MaterialTheme.typography.labelSmall, color = palette.textSecondary)
                    }
                }
            }
        }

        // Category Selection
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Appliance Category", style = MaterialTheme.typography.labelMedium, color = palette.primaryAccent, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(COMMUNITY_CATEGORIES) { _, cat ->
                        val selected = category == cat
                        FilterChip(
                            selected = selected,
                            onClick = { category = cat },
                            label = { Text(cat) },
                            colors = liquidGlassFilterChipColors(),
                            border = liquidGlassFilterChipBorder(selected),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("create_post_cat_${cat.lowercase().replace(" ", "_")}")
                        )
                    }
                }
            }
        }

        // Title & Main Post Input
        item {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it; localError = null },
                label = { Text("Post Title (optional for photo-only posts)") },
                placeholder = { Text("e.g., LG Dual Inverter CH05 PCB communication fix") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("create_post_title_input"),
                shape = RoundedCornerShape(16.dp),
                colors = liquidGlassFieldColors()
            )
        }

        item {
            OutlinedTextField(
                value = body,
                onValueChange = { body = it; localError = null },
                label = { Text("Share your repair experience, question, or solution...") },
                minLines = 5,
                maxLines = 10,
                modifier = Modifier.fillMaxWidth().testTag("create_post_body_input"),
                shape = RoundedCornerShape(16.dp),
                colors = liquidGlassFieldColors()
            )
        }

        // Optional Appliance Tags
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = brandName,
                    onValueChange = { brandName = it },
                    label = { Text("Brand") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = liquidGlassFieldColors()
                )
                OutlinedTextField(
                    value = errorCode,
                    onValueChange = { errorCode = it },
                    label = { Text("Error Code") },
                    singleLine = true,
                    modifier = Modifier.weight(0.8f),
                    shape = RoundedCornerShape(14.dp),
                    colors = liquidGlassFieldColors()
                )
            }
        }

        item {
            OutlinedTextField(
                value = modelName,
                onValueChange = { modelName = it },
                label = { Text("Model / Series (Optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = liquidGlassFieldColors()
            )
        }

        // Multi-Photo Picker Section (up to 4 photos via Android Photo Picker)
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                elevated = true,
                contentPadding = 14.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Attach Repair Photos ($totalPhotosCount/4)", style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                            Text("Auto-compressed for fast upload", style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        }
                        OutlinedButton(
                            onClick = {
                                multiPhotoPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            enabled = totalPhotosCount < 4 && !submitting && !isBlocked && !isUploadRestricted,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, palette.primaryAccent),
                            modifier = Modifier.testTag("create_post_add_photos_button")
                        ) {
                            Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isUploadRestricted) "Restricted" else "Add Photos", color = palette.primaryAccent)
                        }
                    }

                    if (existingUrls.isNotEmpty() || newPhotos.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            itemsIndexed(existingUrls) { idx, url ->
                                Box(modifier = Modifier.size(92.dp)) {
                                    AsyncImage(
                                        model = url,
                                        contentDescription = "Existing photo ${idx + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(RoundedCornerShape(14.dp))
                                            .border(1.dp, palette.glassBorder, RoundedCornerShape(14.dp))
                                    )
                                    IconButton(
                                        onClick = {
                                            existingUrls = existingUrls.filterIndexed { i, _ -> i != idx }
                                            existingPaths = existingPaths.filterIndexed { i, _ -> i != idx }
                                        },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .size(28.dp)
                                            .background(palette.dialogSurface, CircleShape)
                                    ) {
                                        Icon(Icons.Filled.Close, contentDescription = "Remove photo", tint = palette.error, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            itemsIndexed(newPhotos) { idx, item ->
                                Box(modifier = Modifier.size(92.dp)) {
                                    AsyncImage(
                                        model = item.uri,
                                        contentDescription = "Selected photo ${idx + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(RoundedCornerShape(14.dp))
                                            .border(1.dp, palette.primaryAccent.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                                    )
                                    IconButton(
                                        onClick = { newPhotos = newPhotos.filterIndexed { i, _ -> i != idx } },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .size(28.dp)
                                            .background(palette.dialogSurface, CircleShape)
                                    ) {
                                        Icon(Icons.Filled.Close, contentDescription = "Remove photo", tint = palette.error, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (uploadProgress != null) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Uploading photos... ${(uploadProgress * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.primaryAccent
                    )
                    LinearProgressIndicator(
                        progress = { uploadProgress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)),
                        color = palette.primaryAccent,
                        trackColor = palette.glassFillSubtle
                    )
                }
            }
        }

        if (localError != null) {
            item {
                Text(localError ?: "", color = palette.warning, style = MaterialTheme.typography.bodySmall)
            }
        }

        item {
            Button(
                onClick = {
                    val hasPhotos = totalPhotosCount > 0
                    val err = CommunityDomainHelper.validatePostDraft(title, body, category, hasPhotos)
                    if (err != null) {
                        localError = err
                        return@Button
                    }
                    val pendingPhotos = newPhotos.map { PendingCommunityPhoto(it.bytes, it.mimeType) }
                    if (editingPost != null) {
                        onSubmitEdit(
                            editingPost.postId.ifBlank { editingPost.id },
                            category,
                            brandName,
                            modelName,
                            errorCode,
                            title,
                            body,
                            existingUrls,
                            existingPaths,
                            pendingPhotos
                        )
                    } else {
                        onSubmitNew(category, brandName, modelName, errorCode, title, body, pendingPhotos)
                    }
                },
                enabled = !submitting && !isBlocked,
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.primaryAccent,
                    contentColor = palette.onPrimaryAccent
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("create_post_submit_button")
            ) {
                if (submitting) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = palette.onPrimaryAccent, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Submitting...")
                } else {
                    Text(
                        text = if (editingPost != null) "Save Post Changes" else "Submit Post",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

private fun compressUriToJpeg(
    context: android.content.Context,
    uri: Uri,
    maxDimensionPx: Int = 1440,
    initialQuality: Int = 82,
    maxFileSizeKb: Int = 4500
): ByteArray? {
    return try {
        val raw = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val decoded = BitmapFactory.decodeByteArray(raw, 0, raw.size)
            ?: return raw.takeIf { it.isNotEmpty() && it.size < 5 * 1024 * 1024 }
        val maxDim = maxDimensionPx.coerceIn(480, 4096)
        val scaled = if (decoded.width > maxDim || decoded.height > maxDim) {
            val ratio = maxDim.toFloat() / maxOf(decoded.width, decoded.height).toFloat()
            Bitmap.createScaledBitmap(
                decoded,
                (decoded.width * ratio).toInt().coerceAtLeast(1),
                (decoded.height * ratio).toInt().coerceAtLeast(1),
                true
            )
        } else {
            decoded
        }
        if (scaled !== decoded) {
            decoded.recycle()
        }
        var quality = initialQuality.coerceIn(40, 100)
        val maxBytes = maxFileSizeKb.coerceIn(100, 5120) * 1024
        var result: ByteArray
        while (true) {
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
            result = out.toByteArray()
            if (result.size <= maxBytes || quality <= 45) break
            quality = (quality - 15).coerceAtLeast(45)
        }
        scaled.recycle()
        result.takeIf { it.isNotEmpty() && it.size < 5 * 1024 * 1024 }
    } catch (_: Exception) {
        null
    }
}
