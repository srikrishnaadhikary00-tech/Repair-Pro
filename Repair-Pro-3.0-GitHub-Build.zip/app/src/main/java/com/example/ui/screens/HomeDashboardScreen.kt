package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Troubleshoot
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.local.SearchHistoryEntity
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.CatalogEntryCloud
import com.example.data.remote.RepairDocumentItem
import com.example.data.remote.SavedGuideCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AdMobBannerSlot
import com.example.ui.components.AuroraApplianceShowcaseCard
import com.example.ui.components.AuroraGlassCard
import com.example.ui.components.AuroraGlowingDownloadButton
import com.example.ui.components.AuroraPdfBadgeIcon
import com.example.ui.components.AuroraQuickToolTile
import com.example.ui.components.AuroraSearchBar
import com.example.ui.components.AuroraVersionBadge
import com.example.ui.components.ErrorCodePill
import com.example.ui.components.LanguageSwitcherRow
import com.example.ui.components.SmartRepairBannerCard
import com.example.ui.theme.AuroraPurple
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun HomeDashboardScreen(
    language: AppLanguage,
    categories: List<ApplianceCategoryEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    searchHistory: List<SearchHistoryEntity>,
    savedGuides: List<SavedGuideCloud>,
    publishedCatalog: List<CatalogEntryCloud>,
    adMobConfig: AppSettingCloud,
    globalConfig: AppSettingCloud,
    isOnline: Boolean,
    isAdmin: Boolean,
    adConsentGranted: Boolean,
    onSelectLanguage: (AppLanguage) -> Unit,
    onOpenSearch: (String) -> Unit,
    onOpenCategory: (String) -> Unit,
    onOpenErrorSearch: () -> Unit,
    onOpenProblemSearch: () -> Unit,
    onOpenScanner: () -> Unit,
    onOpenWizard: (String) -> Unit,
    onOpenOfflineDownloads: () -> Unit,
    onOpenSaved: () -> Unit,
    onOpenReportProblem: () -> Unit,
    onOpenAdminConsole: () -> Unit,
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit,
    onOpenCommunity: () -> Unit = {},
    onOpenTechnicians: () -> Unit = {},
    onOpenDocuments: () -> Unit = {},
    onOpenNotifications: () -> Unit = {},
    publishedDocuments: List<RepairDocumentItem> = emptyList(),
    unreadNotificationsCount: Int = 0,
    onOpenCategories: () -> Unit = {},
    onOpenCircuitDiagrams: () -> Unit = {},
    onDownloadDocument: (RepairDocumentItem) -> Unit = {}
) {
    val strings = StringsProvider.get(language)
    var showMenuSheet by remember { mutableStateOf(false) }
    var showMoreToolsSheet by remember { mutableStateOf(false) }

    val primaryCategories = remember(categories) {
        val coreOrder = listOf("ac", "fridge", "washer")
        val core = coreOrder.mapNotNull { id -> categories.firstOrNull { it.id.equals(id, true) } }
        core.ifEmpty { categories.take(3) }
    }
    val extraCategories = remember(categories, primaryCategories) {
        val primaryIds = primaryCategories.map { it.id }.toSet()
        categories.filterNot { primaryIds.contains(it.id) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Top Bar: Menu | Repair Pro [3.0] + Subtitle | Notification Bell
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = { showMenuSheet = true },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0x55122040))
                        .testTag("home_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Menu,
                        contentDescription = "Menu",
                        tint = TextPrimaryWhite,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Repair Pro",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 23.sp
                            ),
                            color = TextPrimaryWhite
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        AuroraVersionBadge(versionText = "3.0", compact = true)
                    }
                    Text(
                        text = if (language == AppLanguage.EN) "Appliance Repair & Service Guide" else strings.tagline,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box {
                    IconButton(
                        onClick = onOpenNotifications,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(0x55122040))
                            .testTag("home_notifications_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.NotificationsNone,
                            contentDescription = "Notifications",
                            tint = TextPrimaryWhite,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    if (unreadNotificationsCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(10.dp)
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(CyanAccent)
                        )
                    }
                }
            }
        }

        // 2. Glowing Pill Search Bar with Scanner Shortcut
        item {
            AuroraSearchBar(
                placeholder = if (language == AppLanguage.EN) "Search brand, model, error code..." else strings.searchPlaceholder,
                onSearchClick = { onOpenSearch("") },
                onScannerClick = onOpenScanner
            )
        }

        // Super Admin Announcement / Maintenance Banner (if active)
        if (globalConfig.announcement.isNotBlank() || globalConfig.maintenanceNotice.isNotBlank()) {
            item {
                val isMaint = globalConfig.maintenanceNotice.isNotBlank()
                val accent = if (isMaint) WarningAmber else CyanAccent
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = accent.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.Campaign, contentDescription = "Announcement", tint = accent)
                        Text(
                            text = if (isMaint) globalConfig.maintenanceNotice else globalConfig.announcement,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimaryWhite
                        )
                    }
                }
            }
        }

        // 3. Smart Repair Solutions Promotional Banner
        item {
            SmartRepairBannerCard(
                title = "Smart Repair Solutions",
                subtitle = "AC • Refrigerator • Washing Machine",
                onClick = { onOpenWizard("ac") }
            )
        }

        // 4. Three Premium 3D Appliance Cards in One Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                primaryCategories.forEach { cat ->
                    val rawName = resolveLocalizedText(language, cat.nameEn, cat.nameBn, cat.nameHi).text
                    val displayName = when {
                        language == AppLanguage.EN && cat.id.equals("ac", true) -> "Air\nConditioner"
                        language == AppLanguage.EN && cat.id.equals("fridge", true) -> "Refrigerator"
                        language == AppLanguage.EN && cat.id.equals("washer", true) -> "Washing\nMachine"
                        else -> rawName
                    }
                    AuroraApplianceShowcaseCard(
                        categoryId = cat.id,
                        title = displayName,
                        onClick = { onOpenCategory(cat.id) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Extra Admin-Added Categories if present
        if (extraCategories.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    extraCategories.take(3).forEach { cat ->
                        val title = resolveLocalizedText(language, cat.nameEn, cat.nameBn, cat.nameHi).text
                        AuroraApplianceShowcaseCard(
                            categoryId = cat.id,
                            title = title,
                            onClick = { onOpenCategory(cat.id) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 5. Two-Row Quick Tools Grid (8 Glass Tiles matching Reference Screen 2)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AuroraQuickToolTile(
                        icon = Icons.Filled.QrCodeScanner,
                        label = "Error\nScanner",
                        accentColor = CyanAccent,
                        testTagName = "shortcut_camera_scan",
                        onClick = onOpenScanner,
                        modifier = Modifier.weight(1f)
                    )
                    AuroraQuickToolTile(
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        label = "Repair\nGuide",
                        accentColor = ElectricBluePrimary,
                        testTagName = "shortcut_repair_wizard",
                        onClick = { onOpenWizard("ac") },
                        modifier = Modifier.weight(1f)
                    )
                    AuroraQuickToolTile(
                        icon = Icons.Filled.DescriptionPlaceholder,
                        label = "PDF\nManuals",
                        accentColor = Color(0xFFFF6B81),
                        testTagName = "shortcut_documents",
                        onClick = onOpenDocuments,
                        isPdfTile = true,
                        modifier = Modifier.weight(1f)
                    )
                    AuroraQuickToolTile(
                        icon = Icons.Filled.AccountTree,
                        label = "Circuit\nDiagrams",
                        accentColor = CyanAccent,
                        testTagName = "shortcut_circuit_diagrams",
                        onClick = onOpenCircuitDiagrams,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AuroraQuickToolTile(
                        icon = Icons.Filled.Engineering,
                        label = "Technicians",
                        accentColor = CyanAccent,
                        testTagName = "shortcut_technicians",
                        onClick = onOpenTechnicians,
                        modifier = Modifier.weight(1f)
                    )
                    AuroraQuickToolTile(
                        icon = Icons.Filled.Forum,
                        label = "Community",
                        accentColor = AuroraPurple,
                        testTagName = "shortcut_community",
                        onClick = onOpenCommunity,
                        modifier = Modifier.weight(1f)
                    )
                    AuroraQuickToolTile(
                        icon = Icons.Filled.Storage,
                        label = "Offline Data",
                        accentColor = CyanAccent,
                        testTagName = "shortcut_offline_data",
                        onClick = onOpenOfflineDownloads,
                        modifier = Modifier.weight(1f)
                    )
                    AuroraQuickToolTile(
                        icon = Icons.Filled.Apps,
                        label = "More",
                        accentColor = ElectricBluePrimary,
                        testTagName = "shortcut_more_tools",
                        onClick = { showMoreToolsSheet = true },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 6. Latest Updates Section (Using REAL Backend Documents, Published Catalog & Error Codes)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Whatshot,
                            contentDescription = null,
                            tint = Color(0xFFFF7A3D),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = if (language == AppLanguage.EN) "Latest Updates" else strings.latestPublished,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                if (publishedDocuments.isNotEmpty()) onOpenDocuments()
                                else onOpenSearch("")
                            }
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "View All",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondarySlate
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            tint = TextSecondarySlate,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Latest Published PDF/Manual from Real Firestore Backend if available
                val latestDoc = publishedDocuments.firstOrNull()
                if (latestDoc != null) {
                    AuroraGlassCard(
                        cornerRadius = 18.dp,
                        onClick = onOpenDocuments,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            AuroraPdfBadgeIcon(size = 44.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = latestDoc.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimaryWhite,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val subtitleParts = listOfNotNull(
                                    latestDoc.brandName.takeIf { it.isNotBlank() },
                                    latestDoc.modelName.takeIf { it.isNotBlank() },
                                    latestDoc.docType.uppercase()
                                ).joinToString(" • ")
                                Text(
                                    text = subtitleParts.ifBlank { latestDoc.categoryId.uppercase() },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyanAccent,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            AuroraGlowingDownloadButton(
                                onClick = { onDownloadDocument(latestDoc) },
                                enabled = latestDoc.fileUrl.isNotBlank(),
                                contentDescription = "Download ${latestDoc.title}"
                            )
                        }
                    }
                }

                // Real Verified Error Code / Cloud Catalog Entries
                val featuredCodes = errorCodes.take(if (latestDoc != null) 2 else 3)
                featuredCodes.forEach { codeItem ->
                    val title = resolveLocalizedText(language, codeItem.titleEn, codeItem.titleBn, codeItem.titleHi).text
                    AuroraGlassCard(
                        cornerRadius = 16.dp,
                        onClick = { onOpenErrorDetail(codeItem.id) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            ErrorCodePill(code = codeItem.code)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${codeItem.brandName} • $title",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimaryWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = codeItem.modelSeries,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = CyanAccent
                            )
                        }
                    }
                }

                if (publishedCatalog.isNotEmpty()) {
                    Text(
                        text = "+ ${publishedCatalog.size} live admin-published updates synced",
                        style = MaterialTheme.typography.labelSmall,
                        color = SuccessGreen
                    )
                }
            }
        }

        // 7. AdMob Banner Placement (Remote-controlled by Super Admin, cleanly above floating nav)
        item {
            AdMobBannerSlot(
                config = adMobConfig,
                categoryId = null,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "home"
            )
        }
    }

    // Top-Left Hamburger Quick Menu Dialog (Languages, Status, Admin, Report, Categories)
    if (showMenuSheet) {
        AlertDialog(
            onDismissRequest = { showMenuSheet = false },
            containerColor = SecondaryNavySurface,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Repair Pro", style = MaterialTheme.typography.titleLarge, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        AuroraVersionBadge(versionText = "3.0", compact = true)
                    }
                    IconButton(onClick = { showMenuSheet = false }) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextSecondarySlate)
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.languageSetting, style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                    LanguageSwitcherRow(currentLanguage = language, onSelect = onSelectLanguage)

                    Surface(
                        color = (if (isOnline) SuccessGreen else WarningAmber).copy(alpha = 0.14f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, (if (isOnline) SuccessGreen else WarningAmber).copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth().clickable {
                            showMenuSheet = false
                            onOpenOfflineDownloads()
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isOnline) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
                                contentDescription = null,
                                tint = if (isOnline) SuccessGreen else WarningAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = if (isOnline) strings.offlineReady else strings.offlineModeActive,
                                style = MaterialTheme.typography.labelMedium,
                                color = TextPrimaryWhite
                            )
                        }
                    }

                    QuickMenuRow(Icons.Filled.Category, strings.navCategories, CyanAccent) {
                        showMenuSheet = false; onOpenCategories()
                    }
                    QuickMenuRow(Icons.Filled.Bookmark, "${strings.savedGuides} (${savedGuides.size})", ElectricBluePrimary) {
                        showMenuSheet = false; onOpenSaved()
                    }
                    QuickMenuRow(Icons.Filled.ReportProblem, strings.reportProblemTitle, WarningAmber) {
                        showMenuSheet = false; onOpenReportProblem()
                    }
                    if (isAdmin) {
                        QuickMenuRow(Icons.Filled.AdminPanelSettings, strings.superAdminPanel, AuroraPurple) {
                            showMenuSheet = false; onOpenAdminConsole()
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMenuSheet = false }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }

    // "More" Quick Tools Sheet (Error Code Search, Problem Search, All Categories, Saved, Report, Admin)
    if (showMoreToolsSheet) {
        AlertDialog(
            onDismissRequest = { showMoreToolsSheet = false },
            containerColor = SecondaryNavySurface,
            title = {
                Text("More Repair Tools", style = MaterialTheme.typography.titleLarge, color = TextPrimaryWhite)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickMenuRow(Icons.Filled.Search, strings.errorCodeSearch.replace("\n", " "), CyanAccent) {
                        showMoreToolsSheet = false; onOpenErrorSearch()
                    }
                    QuickMenuRow(Icons.Filled.Troubleshoot, strings.problemSearch.replace("\n", " "), ElectricBluePrimary) {
                        showMoreToolsSheet = false; onOpenProblemSearch()
                    }
                    QuickMenuRow(Icons.Filled.Category, strings.navCategories, CyanAccent) {
                        showMoreToolsSheet = false; onOpenCategories()
                    }
                    QuickMenuRow(Icons.Filled.Bookmark, strings.savedGuides, SuccessGreen) {
                        showMoreToolsSheet = false; onOpenSaved()
                    }
                    QuickMenuRow(Icons.Filled.ReportProblem, strings.reportProblemTitle, WarningAmber) {
                        showMoreToolsSheet = false; onOpenReportProblem()
                    }
                    if (isAdmin) {
                        QuickMenuRow(Icons.Filled.AdminPanelSettings, strings.superAdminPanel, AuroraPurple) {
                            showMoreToolsSheet = false; onOpenAdminConsole()
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMoreToolsSheet = false }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }
}

private val Icons.Filled.DescriptionPlaceholder: ImageVector
    get() = Icons.Filled.Apps

@Composable
private fun QuickMenuRow(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
            Text(label, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, modifier = Modifier.weight(1f))
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextSecondarySlate)
        }
    }
}
