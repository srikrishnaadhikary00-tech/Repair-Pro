package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.remote.AppSettingCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AdMobBannerSlot
import com.example.ui.components.CompactApplianceHomeCard
import com.example.ui.components.DashboardStatCard
import com.example.ui.components.ElectricQuickTile
import com.example.ui.components.ErrorCodePill
import com.example.ui.components.LanguageSwitcherRow
import com.example.ui.components.OnlineOnlyOfflineGuardCard
import com.example.ui.components.RepairProTopHeader
import com.example.ui.theme.CardBorderCyan
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.HeroGlowGradient
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun HomeDashboardScreen(
    language: AppLanguage,
    userName: String,
    userPhotoUrl: String,
    unreadNotificationCount: Int,
    categories: List<ApplianceCategoryEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    verifiedTechnicianCount: Int,
    communityPostCount: Int,
    technicalDocCount: Int,
    isOnline: Boolean,
    isAdmin: Boolean,
    adMobConfig: AppSettingCloud,
    globalConfig: AppSettingCloud,
    adConsentGranted: Boolean,
    aiEnabled: Boolean = true,
    billingEnabled: Boolean = true,
    onLanguageChange: (AppLanguage) -> Unit,
    onRetryConnection: () -> Unit,
    onOpenMenu: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenCategory: (String) -> Unit,
    onOpenScanner: () -> Unit,
    onOpenWizard: (String) -> Unit,
    onOpenSaved: () -> Unit,
    onOpenReport: () -> Unit,
    onOpenTechnicians: () -> Unit,
    onOpenCommunity: () -> Unit,
    onOpenDocuments: () -> Unit,
    onOpenVerification: () -> Unit,
    onOpenAiAssistant: () -> Unit = {},
    onOpenBilling: () -> Unit = {},
    onOpenAdmin: () -> Unit,
    onOpenUpdateUrl: (String) -> Unit = {},
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    val firstName = userName.trim().substringBefore(" ").ifBlank { "Technician" }
    val totalGuides = errorCodes.size + problems.size

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 6.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Global Header matching Reference Screen 1
        item {
            RepairProTopHeader(
                subtitle = strings.tagline,
                userName = userName,
                userPhotoUrl = userPhotoUrl,
                unreadNotifications = unreadNotificationCount,
                onOpenMenu = onOpenMenu,
                onOpenNotifications = onOpenNotifications,
                onOpenProfile = onOpenProfile
            )
        }

        // Super Admin Broadcast Announcement Banner (if configured live in Firestore)
        if (globalConfig.announcement.isNotBlank()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = ElectricBluePrimary.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Campaign,
                            contentDescription = "Announcement",
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = globalConfig.announcement,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimaryWhite,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (globalConfig.hasSoftUpdateAvailable(BuildConfig.VERSION_CODE)) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().testTag("home_soft_update_banner"),
                    color = WarningAmber.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.55f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SystemUpdate,
                            contentDescription = "App Update Available",
                            tint = WarningAmber,
                            modifier = Modifier.size(22.dp)
                        )
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "Update Available (${globalConfig.latestVersionName.ifBlank { "New Release" }})",
                                style = MaterialTheme.typography.labelLarge,
                                color = WarningAmber,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = globalConfig.updateMessage.ifBlank { "A newer version of Repair Pro is ready with fixes and improvements." },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimaryWhite
                            )
                        }
                        if (globalConfig.updateUrl.startsWith("https://")) {
                            OutlinedButton(
                                onClick = { onOpenUpdateUrl(globalConfig.updateUrl) },
                                border = BorderStroke(1.dp, WarningAmber)
                            ) {
                                Text("Update", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        // Blue-Glow Welcome Hero Banner with Language Switcher & Integrated Search Bar
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, CardBorderCyan, RoundedCornerShape(20.dp)),
                color = SecondaryNavySurface,
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .background(HeroGlowGradient)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${strings.welcomeBackPrefix}, $firstName",
                                style = MaterialTheme.typography.titleLarge,
                                color = TextPrimaryWhite,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = strings.welcomeBannerSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                        }
                    }

                    LanguageSwitcherRow(
                        currentLanguage = language,
                        onSelect = onLanguageChange
                    )

                    // Search Bar Pill with Camera OCR Trigger
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, CardBorderCyan, RoundedCornerShape(14.dp))
                            .clickable(onClick = onOpenSearch)
                            .testTag("home_search_bar"),
                        color = DeepCardSurface,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = strings.navSearch,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = strings.searchPlaceholder,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(9.dp))
                                    .clickable(onClick = onOpenScanner)
                                    .testTag("home_search_camera_button"),
                                color = ElectricBluePrimary.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(9.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CameraAlt,
                                    contentDescription = strings.cameraScan,
                                    tint = CyanAccent,
                                    modifier = Modifier
                                        .padding(7.dp)
                                        .size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3 Appliance Category Cards in One Row (AC | Fridge | Washing Machine)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val orderedIds = listOf("ac", "fridge", "washer")
                orderedIds.forEach { catId ->
                    val cat = categories.firstOrNull { it.id == catId }
                    val shortTitle = when (catId) {
                        "ac" -> strings.navAc
                        "fridge" -> strings.navFridge
                        else -> if (cat != null) {
                            resolveLocalizedText(language, cat.nameEn, cat.nameBn, cat.nameHi).text
                        } else "Washer"
                    }
                    val count = errorCodes.count { it.categoryId == catId } +
                        problems.count { it.categoryId == catId }
                    CompactApplianceHomeCard(
                        categoryId = catId,
                        title = shortTitle,
                        countBadge = "$count Guides",
                        onClick = { onOpenCategory(catId) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 3 Real Live Stats Cards (Guides | Verified Techs | Community Posts)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DashboardStatCard(
                    value = totalGuides.toString(),
                    label = strings.totalGuidesLabel,
                    accent = CyanAccent,
                    modifier = Modifier.weight(1f)
                )
                DashboardStatCard(
                    value = verifiedTechnicianCount.toString(),
                    label = strings.verifiedTechsLabel,
                    accent = SuccessGreen,
                    modifier = Modifier.weight(1f)
                )
                DashboardStatCard(
                    value = communityPostCount.toString(),
                    label = strings.communityPostsLabel,
                    accent = ElectricBluePrimary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Actions (2x3 Grid — zero offline download tiles)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Quick Tools",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.SemiBold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (globalConfig.scannerEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.CameraAlt,
                            label = strings.cameraScan,
                            accentColor = CyanAccent,
                            testTagName = "quick_tile_scanner",
                            onClick = onOpenScanner,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                    ElectricQuickTile(
                        icon = Icons.Filled.AutoFixHigh,
                        label = strings.wizardTitle,
                        accentColor = ElectricBluePrimary,
                        testTagName = "quick_tile_wizard",
                        onClick = { onOpenWizard("ac") },
                        modifier = Modifier.weight(1f)
                    )
                    if (globalConfig.pdfsEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.Description,
                            label = if (technicalDocCount > 0) "PDFs ($technicalDocCount)" else "PDFs &\nDiagrams",
                            accentColor = WarningAmber,
                            testTagName = "quick_tile_documents",
                            onClick = onOpenDocuments,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (globalConfig.communityEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.Forum,
                            label = strings.communityTitle,
                            accentColor = CyanAccent,
                            testTagName = "quick_tile_community",
                            onClick = onOpenCommunity,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                    if (globalConfig.techniciansEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.Engineering,
                            label = strings.findTechnicianTitle,
                            accentColor = SuccessGreen,
                            testTagName = "quick_tile_technicians",
                            onClick = onOpenTechnicians,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                    if (globalConfig.verificationEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.VerifiedUser,
                            label = "Get\nVerified",
                            accentColor = ElectricBluePrimary,
                            testTagName = "quick_tile_verification",
                            onClick = onOpenVerification,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ElectricQuickTile(
                        icon = Icons.Filled.Bookmark,
                        label = strings.navSaved,
                        accentColor = SuccessGreen,
                        testTagName = "quick_tile_saved",
                        onClick = onOpenSaved,
                        modifier = Modifier.weight(1f)
                    )
                    if (globalConfig.reportsEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.ReportProblem,
                            label = strings.reportProblemTitle,
                            accentColor = WarningAmber,
                            testTagName = "quick_tile_report",
                            onClick = onOpenReport,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                    if (isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.AdminPanelSettings,
                            label = "Super\nAdmin",
                            accentColor = CyanAccent,
                            testTagName = "home_super_admin_button",
                            onClick = onOpenAdmin,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
                val showBillingTile = billingEnabled && (globalConfig.billingEnabled || isAdmin)
                if (aiEnabled || showBillingTile) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (aiEnabled) {
                            ElectricQuickTile(
                                icon = Icons.Filled.AutoAwesome,
                                label = "AI\nAssistant",
                                accentColor = CyanAccent,
                                testTagName = "quick_tile_ai_assistant",
                                onClick = onOpenAiAssistant,
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                        if (showBillingTile) {
                            ElectricQuickTile(
                                icon = Icons.Filled.ReceiptLong,
                                label = "Billing &\nInvoices",
                                accentColor = SuccessGreen,
                                testTagName = "quick_tile_billing",
                                onClick = onOpenBilling,
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Online-Only Recent Repair Guides Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.latestPublished,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Online Library",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyanAccent
                )
            }
        }

        if (!isOnline) {
            item {
                OnlineOnlyOfflineGuardCard(
                    title = strings.noInternetTitle,
                    message = strings.noInternetGuidesMessage,
                    retryLabel = strings.retry,
                    onRetry = onRetryConnection
                )
            }
        } else {
            val recentCodes = errorCodes.take(4)
            items(recentCodes, key = { it.id }) { codeItem ->
                val title = resolveLocalizedText(language, codeItem.titleEn, codeItem.titleBn, codeItem.titleHi).text
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onOpenErrorDetail(codeItem.id) }
                        .testTag("home_popular_code_${codeItem.id}"),
                    color = ElevatedCardSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CardBorderSubtle)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ErrorCodePill(code = codeItem.code)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${codeItem.brandName} — $title",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = codeItem.modelSeries,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Open guide",
                            tint = CyanAccent
                        )
                    }
                }
            }

            val featuredProblems = problems.take(2)
            items(featuredProblems, key = { it.id }) { prob ->
                val title = resolveLocalizedText(language, prob.titleEn, prob.titleBn, prob.titleHi).text
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onOpenProblemDetail(prob.id) }
                        .testTag("home_featured_problem_${prob.id}"),
                    color = ElevatedCardSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CardBorderSubtle)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${prob.categoryId.uppercase()} • Step-by-Step Repair Guide",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Open problem guide",
                            tint = CyanAccent
                        )
                    }
                }
            }
        }

        // Real Google Mobile Ads Banner Slot (Super Admin controlled)
        item {
            AdMobBannerSlot(
                config = adMobConfig,
                categoryId = null,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "home"
            )
        }
    }
}
