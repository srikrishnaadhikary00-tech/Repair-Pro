package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.remote.AppSettingCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AdMobBannerSlot
import com.example.ui.components.CompactApplianceHomeCard
import com.example.ui.components.DashboardStatCard
import com.example.ui.components.ElectricQuickTile
import com.example.ui.components.ErrorCodePill
import com.example.ui.components.LanguageSwitcherRow
import com.example.ui.components.LiquidGlassAnimatedEnter
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.OnlineOnlyOfflineGuardCard
import com.example.ui.components.RepairProAiIcon
import com.example.ui.components.RepairProTopHeader
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun HomeDashboardScreen(
    language: AppLanguage,
    userName: String,
    userPhotoUrl: String,
    unreadNotificationCount: Int,
    categories: List<ApplianceCategoryEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    verifiedTechnicianCount: Int,
    communityPostCount: Int,
    technicalDocCount: Int,
    isOnline: Boolean,
    isAdmin: Boolean,
    adMobConfig: AppSettingCloud,
    globalConfig: AppSettingCloud,
    adConsentGranted: Boolean,
    aiEnabled: Boolean = true,
    billingEnabled: Boolean = true,
    onLanguageChange: (AppLanguage) -> Unit,
    onRetryConnection: () -> Unit,
    onOpenMenu: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenCategory: (String) -> Unit,
    onOpenScanner: () -> Unit,
    onOpenWizard: (String) -> Unit,
    onOpenSaved: () -> Unit,
    onOpenReport: () -> Unit,
    onOpenTechnicians: () -> Unit,
    onOpenCommunity: () -> Unit,
    onOpenDocuments: () -> Unit,
    onOpenVerification: () -> Unit,
    onOpenAiAssistant: () -> Unit = {},
    onOpenBilling: () -> Unit = {},
    onOpenAdmin: () -> Unit,
    onOpenUpdateUrl: (String) -> Unit = {},
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    val palette = LiquidGlassTheme.colors
    val firstName = userName.trim().substringBefore(" ").ifBlank { "Technician" }
    val totalGuides = errorCodes.size + problems.size

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 6.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            RepairProTopHeader(
                subtitle = strings.tagline,
                userName = userName,
                userPhotoUrl = userPhotoUrl,
                unreadNotifications = unreadNotificationCount,
                onOpenMenu = onOpenMenu,
                onOpenNotifications = onOpenNotifications,
                onOpenProfile = onOpenProfile
            )
        }

        // Super Admin Broadcast Announcement Banner (if configured live in Supabase)
        if (globalConfig.announcement.isNotBlank()) {
            item {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    customContainerColor = palette.primaryAccent.copy(alpha = if (palette.isDark) 0.16f else 0.10f),
                    customBorderColor = palette.primaryAccent.copy(alpha = 0.42f),
                    contentPadding = 12.dp
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Campaign,
                            contentDescription = "Announcement",
                            tint = palette.primaryAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = globalConfig.announcement,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textPrimary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (globalConfig.hasSoftUpdateAvailable(BuildConfig.VERSION_CODE)) {
            item {
                LiquidGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_soft_update_banner"),
                    shape = RoundedCornerShape(18.dp),
                    customContainerColor = palette.warning.copy(alpha = if (palette.isDark) 0.16f else 0.12f),
                    customBorderColor = palette.warning.copy(alpha = 0.50f),
                    contentPadding = 12.dp
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SystemUpdate,
                            contentDescription = "App Update Available",
                            tint = palette.warning,
                            modifier = Modifier.size(22.dp)
                        )
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "Update Available (${globalConfig.latestVersionName.ifBlank { "New Release" }})",
                                style = MaterialTheme.typography.labelLarge,
                                color = palette.warning,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = globalConfig.updateMessage.ifBlank { "A newer version of Repair Pro is ready with fixes and improvements." },
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textPrimary
                            )
                        }
                        if (globalConfig.updateUrl.startsWith("https://")) {
                            OutlinedButton(
                                onClick = { onOpenUpdateUrl(globalConfig.updateUrl) },
                                border = BorderStroke(1.dp, palette.warning)
                            ) {
                                Text("Update", color = palette.warning, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        // Liquid Glass Welcome Hero Banner with Language Switcher & Integrated Search Pill
        item {
            LiquidGlassAnimatedEnter {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(26.dp),
                    elevated = true,
                    accentBorder = true
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(palette.heroGradient)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${strings.welcomeBackPrefix}, $firstName",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = palette.textPrimary,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = strings.welcomeBannerSubtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary
                                )
                            }
                        }

                        LanguageSwitcherRow(
                            currentLanguage = language,
                            onSelect = onLanguageChange
                        )

                        // Translucent Glass Search Bar Pill with Camera OCR Trigger
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .border(1.dp, palette.glassBorderAccent, RoundedCornerShape(16.dp))
                                .clickable(onClick = onOpenSearch)
                                .testTag("home_search_bar"),
                            color = palette.glassFillElevated,
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Search,
                                        contentDescription = strings.navSearch,
                                        tint = palette.primaryAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = strings.searchPlaceholder,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.textSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(11.dp))
                                        .clickable(onClick = onOpenScanner)
                                        .testTag("home_search_camera_button"),
                                    color = palette.primaryAccent.copy(alpha = if (palette.isDark) 0.24f else 0.14f),
                                    shape = RoundedCornerShape(11.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CameraAlt,
                                        contentDescription = strings.cameraScan,
                                        tint = palette.primaryAccent,
                                        modifier = Modifier
                                            .padding(8.dp)
                                            .size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3D Liquid Glass Appliance Category Cards in One Row (AC | Fridge | Washing Machine)
        item {
            LiquidGlassAnimatedEnter(delayMillis = 50) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val orderedIds = listOf("ac", "fridge", "washer")
                    orderedIds.forEach { catId ->
                        val cat = categories.firstOrNull { it.id == catId }
                        val shortTitle = when (catId) {
                            "ac" -> strings.navAc
                            "fridge" -> strings.navFridge
                            else -> if (cat != null) {
                                resolveLocalizedText(language, cat.nameEn, cat.nameBn, cat.nameHi).text
                            } else "Washer"
                        }
                        val count = errorCodes.count { it.categoryId == catId } +
                            problems.count { it.categoryId == catId }
                        CompactApplianceHomeCard(
                            categoryId = catId,
                            title = shortTitle,
                            countBadge = "$count Guides",
                            onClick = { onOpenCategory(catId) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 3 Live Stats Glass Cards (Guides | Verified Techs | Community Posts)
        item {
            LiquidGlassAnimatedEnter(delayMillis = 90) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DashboardStatCard(
                        value = totalGuides.toString(),
                        label = strings.totalGuidesLabel,
                        accent = palette.secondaryAccent,
                        modifier = Modifier.weight(1f)
                    )
                    DashboardStatCard(
                        value = verifiedTechnicianCount.toString(),
                        label = strings.verifiedTechsLabel,
                        accent = palette.success,
                        modifier = Modifier.weight(1f)
                    )
                    DashboardStatCard(
                        value = communityPostCount.toString(),
                        label = strings.communityPostsLabel,
                        accent = palette.primaryAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Quick Actions Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Quick Tools",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (globalConfig.scannerEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.CameraAlt,
                            label = strings.cameraScan,
                            accentColor = palette.secondaryAccent,
                            testTagName = "quick_tile_scanner",
                            onClick = onOpenScanner,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                    ElectricQuickTile(
                        icon = Icons.Filled.AutoFixHigh,
                        label = strings.wizardTitle,
                        accentColor = palette.primaryAccent,
                        testTagName = "quick_tile_wizard",
                        onClick = { onOpenWizard("ac") },
                        modifier = Modifier.weight(1f)
                    )
                    if (globalConfig.pdfsEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.Description,
                            label = if (technicalDocCount > 0) "PDFs ($technicalDocCount)" else "PDFs &\nDiagrams",
                            accentColor = palette.warning,
                            testTagName = "quick_tile_documents",
                            onClick = onOpenDocuments,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (globalConfig.communityEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.Forum,
                            label = strings.communityTitle,
                            accentColor = palette.secondaryAccent,
                            testTagName = "quick_tile_community",
                            onClick = onOpenCommunity,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                    if (globalConfig.techniciansEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.Engineering,
                            label = strings.findTechnicianTitle,
                            accentColor = palette.success,
                            testTagName = "quick_tile_technicians",
                            onClick = onOpenTechnicians,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                    if (globalConfig.verificationEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.VerifiedUser,
                            label = "Get\nVerified",
                            accentColor = palette.primaryAccent,
                            testTagName = "quick_tile_verification",
                            onClick = onOpenVerification,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ElectricQuickTile(
                        icon = Icons.Filled.Bookmark,
                        label = strings.navSaved,
                        accentColor = palette.success,
                        testTagName = "quick_tile_saved",
                        onClick = onOpenSaved,
                        modifier = Modifier.weight(1f)
                    )
                    if (globalConfig.reportsEnabled || isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.ReportProblem,
                            label = strings.reportProblemTitle,
                            accentColor = palette.warning,
                            testTagName = "quick_tile_report",
                            onClick = onOpenReport,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                    if (isAdmin) {
                        ElectricQuickTile(
                            icon = Icons.Filled.AdminPanelSettings,
                            label = "Super\nAdmin",
                            accentColor = palette.primaryAccent,
                            testTagName = "home_super_admin_button",
                            onClick = onOpenAdmin,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
                val showBillingTile = billingEnabled && (globalConfig.billingEnabled || isAdmin)
                if (aiEnabled || showBillingTile) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (aiEnabled) {
                            ElectricQuickTile(
                                icon = Icons.Filled.AutoAwesome,
                                label = "Repair Pro\nAI",
                                accentColor = palette.primaryAccent,
                                testTagName = "quick_tile_ai_assistant",
                                onClick = onOpenAiAssistant,
                                modifier = Modifier.weight(1f),
                                customIcon = { RepairProAiIcon(modifier = Modifier.size(22.dp)) }
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                        if (showBillingTile) {
                            ElectricQuickTile(
                                icon = Icons.Filled.ReceiptLong,
                                label = "Billing &\nInvoices",
                                accentColor = palette.success,
                                testTagName = "quick_tile_billing",
                                onClick = onOpenBilling,
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Online-Only Recent Repair Guides Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.latestPublished,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Online Library",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.primaryAccent,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        if (!isOnline) {
            item {
                OnlineOnlyOfflineGuardCard(
                    title = strings.noInternetTitle,
                    message = strings.noInternetGuidesMessage,
                    retryLabel = strings.retry,
                    onRetry = onRetryConnection
                )
            }
        } else {
            val recentCodes = errorCodes.take(4)
            items(recentCodes, key = { it.id }) { codeItem ->
                val title = resolveLocalizedText(language, codeItem.titleEn, codeItem.titleBn, codeItem.titleHi).text
                LiquidGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_popular_code_${codeItem.id}"),
                    shape = RoundedCornerShape(18.dp),
                    onClick = { onOpenErrorDetail(codeItem.id) },
                    contentPadding = 12.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ErrorCodePill(code = codeItem.code)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${codeItem.brandName} — $title",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = codeItem.modelSeries,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Open guide",
                            tint = palette.primaryAccent
                        )
                    }
                }
            }

            val featuredProblems = problems.take(2)
            items(featuredProblems, key = { it.id }) { prob ->
                val title = resolveLocalizedText(language, prob.titleEn, prob.titleBn, prob.titleHi).text
                LiquidGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_featured_problem_${prob.id}"),
                    shape = RoundedCornerShape(18.dp),
                    onClick = { onOpenProblemDetail(prob.id) },
                    contentPadding = 12.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${prob.categoryId.uppercase()} • Step-by-Step Repair Guide",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Open problem guide",
                            tint = palette.primaryAccent
                        )
                    }
                }
            }
        }

        // Real Google Mobile Ads Banner Slot (Super Admin controlled)
        item {
            AdMobBannerSlot(
                config = adMobConfig,
                categoryId = null,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "home"
            )
        }
    }
}
