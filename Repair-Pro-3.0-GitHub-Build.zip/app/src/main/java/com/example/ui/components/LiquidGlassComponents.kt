package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LiquidGlassTheme

/**
 * Lightweight, low-end-device-friendly Liquid Glass backdrop with ambient pastel/slate depth
 * and soft radial specular orbs (zero offscreen GPU blur passes).
 */
@Composable
fun LiquidGlassBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val palette = LiquidGlassTheme.colors
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(palette.screenGradient)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val topOrbRadius = size.width * 0.72f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(palette.orbPrimary, Color.Transparent),
                    center = Offset(size.width * 0.14f, size.height * 0.08f),
                    radius = topOrbRadius
                ),
                center = Offset(size.width * 0.14f, size.height * 0.08f),
                radius = topOrbRadius
            )
            val rightOrbRadius = size.width * 0.68f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(palette.orbSecondary, Color.Transparent),
                    center = Offset(size.width * 0.92f, size.height * 0.34f),
                    radius = rightOrbRadius
                ),
                center = Offset(size.width * 0.92f, size.height * 0.34f),
                radius = rightOrbRadius
            )
            val bottomOrbRadius = size.width * 0.75f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(palette.orbPrimary.copy(alpha = palette.orbPrimary.alpha * 0.85f), Color.Transparent),
                    center = Offset(size.width * 0.35f, size.height * 0.92f),
                    radius = bottomOrbRadius
                ),
                center = Offset(size.width * 0.35f, size.height * 0.92f),
                radius = bottomOrbRadius
            )
        }
        content()
    }
}

/**
 * Translucent Liquid Glass card with soft border highlight, specular top sheen, and subtle shadow.
 */
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    elevated: Boolean = false,
    accentBorder: Boolean = false,
    customContainerColor: Color? = null,
    customBorderColor: Color? = null,
    onClick: (() -> Unit)? = null,
    contentPadding: Dp = 0.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (onClick != null && pressed) 0.982f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioNoBouncy),
        label = "glassCardScale"
    )

    val fillColor = customContainerColor ?: if (elevated) palette.glassFillElevated else palette.glassFill
    val borderBrush = when {
        customBorderColor != null -> Brush.linearGradient(
            listOf(customBorderColor, customBorderColor.copy(alpha = 0.45f))
        )
        accentBorder -> Brush.linearGradient(
            listOf(
                if (palette.isDark) palette.secondaryAccent.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.95f),
                palette.primaryAccent.copy(alpha = if (palette.isDark) 0.36f else 0.30f)
            )
        )
        else -> Brush.linearGradient(
            listOf(
                palette.glassBorder,
                palette.primaryAccent.copy(alpha = if (palette.isDark) 0.14f else 0.12f)
            )
        )
    }

    val clickableModifier = if (onClick != null) {
        Modifier
            .clip(shape)
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onClick
            )
    } else {
        Modifier
    }

    Surface(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .then(clickableModifier),
        shape = shape,
        color = fillColor,
        shadowElevation = if (palette.isDark) 4.dp else 6.dp,
        tonalElevation = 0.dp,
        border = BorderStroke(1.dp, borderBrush)
    ) {
        Box(
            modifier = Modifier.background(
                Brush.verticalGradient(
                    colors = listOf(
                        palette.specularSheenTop.copy(alpha = if (palette.isDark) 0.14f else 0.42f),
                        Color.Transparent,
                        palette.specularSheenBottom.copy(alpha = if (palette.isDark) 0.08f else 0.16f)
                    )
                )
            )
        ) {
            Column(
                modifier = if (contentPadding > 0.dp) Modifier.padding(contentPadding) else Modifier,
                content = content
            )
        }
    }
}

/**
 * Lightweight smooth entrance transition for major cards/sections.
 */
@Composable
fun LiquidGlassAnimatedEnter(
    delayMillis: Int = 0,
    content: @Composable () -> Unit
) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(
            animationSpec = tween(durationMillis = 320, delayMillis = delayMillis, easing = FastOutSlowInEasing)
        ) + slideInVertically(
            animationSpec = tween(durationMillis = 320, delayMillis = delayMillis, easing = FastOutSlowInEasing),
            initialOffsetY = { it / 14 }
        )
    ) {
        content()
    }
}

/**
 * Frosted Liquid Glass Back Header Bar with 48dp circular back button and optional trailing action.
 */
@Composable
fun LiquidGlassBackBar(
    title: String,
    subtitle: String? = null,
    onBack: () -> Unit,
    backTestTag: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable RowScope.() -> Unit)? = null
) {
    val palette = LiquidGlassTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(
            modifier = Modifier.size(48.dp),
            shape = CircleShape,
            color = palette.glassFillElevated,
            shadowElevation = if (palette.isDark) 2.dp else 4.dp,
            border = BorderStroke(1.dp, palette.glassBorder)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag(backTestTag)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = palette.textPrimary
                )
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = palette.textPrimary,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (trailing != null) {
            Row(verticalAlignment = Alignment.CenterVertically, content = trailing)
        }
    }
}

data class FloatingGlassNavItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

/**
 * Floating translucent Liquid Glass pill bottom navigation bar with safe-area padding
 * and spring-animated active pill capsule.
 */
@Composable
fun FloatingLiquidGlassBottomBar(
    items: List<FloatingGlassNavItem>,
    isSelected: (FloatingGlassNavItem) -> Boolean,
    onSelect: (FloatingGlassNavItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(30.dp),
            color = palette.dockGlassFill,
            shadowElevation = if (palette.isDark) 10.dp else 14.dp,
            border = BorderStroke(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        if (palette.isDark) Color.White.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.96f),
                        palette.primaryAccent.copy(alpha = if (palette.isDark) 0.24f else 0.18f)
                    )
                )
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                palette.specularSheenTop.copy(alpha = if (palette.isDark) 0.12f else 0.48f),
                                Color.Transparent
                            )
                        )
                    )
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.forEach { dest ->
                    val selected = isSelected(dest)
                    val iconScale by animateFloatAsState(
                        targetValue = if (selected) 1.10f else 1f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "navIconScale_${dest.route}"
                    )
                    val pillColor = if (selected) {
                        palette.primaryAccent.copy(alpha = if (palette.isDark) 0.24f else 0.15f)
                    } else {
                        Color.Transparent
                    }
                    val contentTint = if (selected) palette.primaryAccent else palette.textSecondary

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(22.dp))
                            .background(pillColor)
                            .then(
                                if (selected) {
                                    Modifier.border(
                                        width = 0.8.dp,
                                        color = palette.primaryAccent.copy(alpha = if (palette.isDark) 0.42f else 0.28f),
                                        shape = RoundedCornerShape(22.dp)
                                    )
                                } else {
                                    Modifier
                                }
                            )
                            .clickable { onSelect(dest) }
                            .padding(vertical = 6.dp, horizontal = 2.dp)
                            .testTag(dest.testTag),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = dest.icon,
                            contentDescription = dest.label,
                            tint = contentTint,
                            modifier = Modifier
                                .size(22.dp)
                                .graphicsLayer {
                                    scaleX = iconScale
                                    scaleY = iconScale
                                }
                        )
                        Text(
                            text = dest.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = contentTint,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

/**
 * Lightweight skeleton loading placeholder with subtle breathing glass shimmer.
 */
@Composable
fun LiquidGlassSkeletonCard(
    modifier: Modifier = Modifier,
    height: Dp = 84.dp
) {
    val palette = LiquidGlassTheme.colors
    val transition = rememberInfiniteTransition(label = "glassSkeleton")
    val pulse by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.72f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 950, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glassSkeletonAlpha"
    )
    LiquidGlassCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        contentPadding = 14.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height((height - 28.dp).coerceAtLeast(42.dp)),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(palette.primaryAccent.copy(alpha = 0.14f * pulse))
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.68f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(palette.textMuted.copy(alpha = 0.22f * pulse))
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.42f)
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(palette.textMuted.copy(alpha = 0.16f * pulse))
                )
            }
        }
    }
}

@Composable
fun liquidGlassFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = LiquidGlassTheme.colors.primaryAccent,
    unfocusedBorderColor = LiquidGlassTheme.colors.glassBorderAccent.copy(alpha = 0.42f),
    focusedContainerColor = LiquidGlassTheme.colors.glassFillElevated,
    unfocusedContainerColor = LiquidGlassTheme.colors.glassFill,
    focusedTextColor = LiquidGlassTheme.colors.textPrimary,
    unfocusedTextColor = LiquidGlassTheme.colors.textPrimary,
    focusedLabelColor = LiquidGlassTheme.colors.primaryAccent,
    unfocusedLabelColor = LiquidGlassTheme.colors.textSecondary,
    focusedPlaceholderColor = LiquidGlassTheme.colors.textMuted,
    unfocusedPlaceholderColor = LiquidGlassTheme.colors.textMuted,
    cursorColor = LiquidGlassTheme.colors.primaryAccent
)

@Composable
fun liquidGlassFilterChipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = LiquidGlassTheme.colors.primaryAccent,
    selectedLabelColor = LiquidGlassTheme.colors.onPrimaryAccent,
    containerColor = LiquidGlassTheme.colors.glassFill,
    labelColor = LiquidGlassTheme.colors.textSecondary
)

@Composable
fun liquidGlassSecondaryChipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = LiquidGlassTheme.colors.secondaryAccent.copy(
        alpha = if (LiquidGlassTheme.colors.isDark) 0.24f else 0.16f
    ),
    selectedLabelColor = if (LiquidGlassTheme.colors.isDark) {
        LiquidGlassTheme.colors.secondaryAccent
    } else {
        LiquidGlassTheme.colors.primaryAccent
    },
    containerColor = LiquidGlassTheme.colors.glassFill,
    labelColor = LiquidGlassTheme.colors.textSecondary
)

@Composable
fun liquidGlassFilterChipBorder(selected: Boolean) = FilterChipDefaults.filterChipBorder(
    enabled = true,
    selected = selected,
    borderColor = LiquidGlassTheme.colors.glassBorderAccent.copy(alpha = 0.45f),
    selectedBorderColor = LiquidGlassTheme.colors.primaryAccent
)
