package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.TechnicianProfileItem
import com.example.ui.components.AuroraGlassCard
import com.example.ui.components.AuroraPillFilter
import com.example.ui.theme.AuroraPurple
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanBorderGradient
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.PurpleBorderGradient
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun TechnicianDirectoryScreen(
    technicians: List<TechnicianProfileItem>,
    busy: Boolean,
    onBack: () -> Unit,
    onRegisterTechnician: (
        fullName: String,
        publicPhone: String,
        serviceDetails: String,
        experienceYears: Long,
        serviceLocation: String,
        city: String,
        categories: List<String>,
        profilePhotoUri: Uri?,
        verificationDocUri: Uri?,
        onDone: () -> Unit
    ) -> Unit
) {
    val context = LocalContext.current
    var showRegisterForm by remember { mutableStateOf(false) }
    var showSearchBar by remember { mutableStateOf(false) }
    var showCategoryRow by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var primaryFilter by remember { mutableStateOf("ALL") } // ALL | VERIFIED | NEARBY
    var filterCat by remember { mutableStateOf("all") }
    var selectedTechForDetails by remember { mutableStateOf<TechnicianProfileItem?>(null) }

    // Registration fields
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var serviceDetails by remember { mutableStateOf("") }
    var experience by remember { mutableStateOf("3") }
    var location by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var selectedCats by remember { mutableStateOf(setOf("ac")) }
    var profilePhotoUri by remember { mutableStateOf<Uri?>(null) }
    var verificationDocUri by remember { mutableStateOf<Uri?>(null) }

    val profilePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        profilePhotoUri = uri
    }
    val verificationPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        verificationDocUri = uri
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CyanAccent,
        unfocusedBorderColor = CardBorderSubtle,
        focusedTextColor = TextPrimaryWhite,
        unfocusedTextColor = TextPrimaryWhite,
        focusedContainerColor = DeepCardSurface,
        unfocusedContainerColor = DeepCardSurface
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("technician_directory_screen"),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header: Back | Technicians | Search
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("technician_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Text(
                    text = "Technicians",
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = { showSearchBar = !showSearchBar },
                    modifier = Modifier.testTag("technician_search_toggle")
                ) {
                    Icon(
                        imageVector = if (showSearchBar) Icons.Filled.Close else Icons.Filled.Search,
                        contentDescription = "Search technicians",
                        tint = CyanAccent
                    )
                }
            }
        }

        // Toggleable Aurora Search Bar
        item {
            AnimatedVisibility(visible = showSearchBar) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search technician name, city, or service…") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = CyanAccent) },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (showRegisterForm) {
            item {
                AuroraGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 20.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Technician Registration", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { showRegisterForm = false }) {
                                Text("Back to List", color = TextSecondarySlate)
                            }
                        }
                        Text(
                            "Verification documents are stored privately in verification-documents and visible ONLY to Super Admins — never shown publicly.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SuccessGreen
                        )
                        OutlinedTextField(value = fullName, onValueChange = { fullName = it.take(100) }, label = { Text("Full Name *") }, singleLine = true, colors = fieldColors, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = phone, onValueChange = { phone = it.take(32) }, label = { Text("Public Service Phone (Optional)") }, singleLine = true, colors = fieldColors, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = experience, onValueChange = { experience = it.filter(Char::isDigit).take(2) }, label = { Text("Experience (Years)") }, singleLine = true, colors = fieldColors, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = location, onValueChange = { location = it.take(140) }, label = { Text("Service Location / Area *") }, singleLine = true, colors = fieldColors, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = city, onValueChange = { city = it.take(80) }, label = { Text("City") }, singleLine = true, colors = fieldColors, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = serviceDetails, onValueChange = { serviceDetails = it.take(800) }, label = { Text("Appliance Specialties & Service Details *") }, minLines = 2, colors = fieldColors, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())

                        Text("Appliance Categories", style = MaterialTheme.typography.labelLarge, color = TextPrimaryWhite)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                                AuroraPillFilter(
                                    label = label,
                                    selected = selectedCats.contains(id),
                                    onClick = {
                                        selectedCats = if (selectedCats.contains(id) && selectedCats.size > 1) selectedCats - id else selectedCats + id
                                    }
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { profilePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f))
                            ) {
                                Icon(Icons.Filled.Person, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (profilePhotoUri == null) "Profile Photo" else "Photo Ready", color = TextPrimaryWhite)
                            }
                            OutlinedButton(
                                onClick = { verificationPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.5f))
                            ) {
                                Icon(Icons.Filled.Badge, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (verificationDocUri == null) "Private ID Doc" else "ID Ready", color = TextPrimaryWhite)
                            }
                        }

                        Button(
                            enabled = !busy && fullName.isNotBlank() && serviceDetails.isNotBlank() && location.isNotBlank(),
                            onClick = {
                                onRegisterTechnician(
                                    fullName,
                                    phone,
                                    serviceDetails,
                                    experience.toLongOrNull() ?: 1L,
                                    location,
                                    city,
                                    selectedCats.toList(),
                                    profilePhotoUri,
                                    verificationDocUri
                                ) {
                                    showRegisterForm = false
                                    fullName = ""
                                    phone = ""
                                    serviceDetails = ""
                                    location = ""
                                    city = ""
                                    profilePhotoUri = null
                                    verificationDocUri = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("submit_technician_btn")
                        ) {
                            Text(if (busy) "Submitting…" else "Submit for Admin Verification", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            // Filter Pills Row matching Reference Screen 4: All | Verified | Nearby | [Filter Button]
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AuroraPillFilter(
                            label = "All",
                            selected = primaryFilter == "ALL",
                            onClick = { primaryFilter = "ALL" }
                        )
                        AuroraPillFilter(
                            label = "Verified",
                            leadingIcon = Icons.Filled.CheckCircle,
                            selected = primaryFilter == "VERIFIED",
                            onClick = { primaryFilter = "VERIFIED" }
                        )
                        AuroraPillFilter(
                            label = "Nearby",
                            selected = primaryFilter == "NEARBY",
                            onClick = { primaryFilter = "NEARBY" }
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (showCategoryRow || filterCat != "all") ElectricBluePrimary.copy(alpha = 0.35f) else Color(0xB3122040))
                            .border(1.dp, CyanAccent.copy(alpha = 0.55f), CircleShape)
                            .clickable { showCategoryRow = !showCategoryRow }
                            .testTag("technician_category_filter_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FilterList,
                            contentDescription = "Filter by appliance category",
                            tint = CyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            if (showCategoryRow) {
                item {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("all" to "All Appliances", "ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                            AuroraPillFilter(
                                label = label,
                                selected = filterCat == id,
                                onClick = { filterCat = id }
                            )
                        }
                    }
                }
            }

            val visibleTechs = technicians.filter { t ->
                val verifiedMatch = primaryFilter != "VERIFIED" || t.verified
                val nearbyMatch = primaryFilter != "NEARBY" || t.city.isNotBlank() || t.serviceLocation.isNotBlank()
                val catMatch = filterCat == "all" || t.applianceCategories.any { it.equals(filterCat, ignoreCase = true) }
                val qMatch = searchQuery.isBlank() ||
                    t.fullName.contains(searchQuery, ignoreCase = true) ||
                    t.serviceLocation.contains(searchQuery, ignoreCase = true) ||
                    t.city.contains(searchQuery, ignoreCase = true) ||
                    t.serviceDetails.contains(searchQuery, ignoreCase = true)
                verifiedMatch && nearbyMatch && catMatch && qMatch
            }

            if (visibleTechs.isEmpty()) {
                item {
                    AuroraGlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
                        Column(
                            modifier = Modifier.padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Engineering, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(36.dp))
                            Text(
                                text = "No approved technicians match this filter yet.",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite
                            )
                            Text(
                                text = "Only real admin-approved technicians are shown here. Technicians can apply below.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                        }
                    }
                }
            } else {
                items(visibleTechs, key = { it.id }) { tech ->
                    val categorySummary = tech.applianceCategories.joinToString(" • ") {
                        when (it.lowercase()) {
                            "ac" -> "AC"
                            "fridge" -> "Fridge"
                            "washer" -> "Washing Machine"
                            else -> it.uppercase()
                        }
                    }
                    val locationLine = listOf(tech.serviceLocation, tech.city).filter { it.isNotBlank() }.joinToString(", ")

                    AuroraGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 20.dp,
                        borderBrush = if (tech.verified) CyanBorderGradient else PurpleBorderGradient,
                        onClick = { selectedTechForDetails = tech }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Profile Avatar with active dot
                            Box {
                                if (tech.profilePhotoUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = tech.profilePhotoUrl,
                                        contentDescription = tech.fullName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(58.dp)
                                            .clip(CircleShape)
                                            .border(1.5.dp, CyanAccent.copy(alpha = 0.65f), CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(58.dp)
                                            .clip(CircleShape)
                                            .background(
                                                Brush.linearGradient(listOf(ElectricBluePrimary, AuroraPurple))
                                            )
                                            .border(1.5.dp, CyanAccent.copy(alpha = 0.65f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Engineering,
                                            contentDescription = null,
                                            tint = TextPrimaryWhite,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                                if (tech.active) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(13.dp)
                                            .clip(CircleShape)
                                            .background(SuccessGreen)
                                            .border(2.dp, DeepCardSurface, CircleShape)
                                    )
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Text(
                                        text = tech.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimaryWhite,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (tech.verified) {
                                        Icon(
                                            imageVector = Icons.Filled.Verified,
                                            contentDescription = "Verified Technician",
                                            tint = CyanAccent,
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                }
                                if (categorySummary.isNotBlank()) {
                                    Text(
                                        text = categorySummary,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondarySlate,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = "${tech.experienceYears} yrs exp",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WarningAmber
                                )
                                if (locationLine.isNotBlank()) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.LocationOn,
                                            contentDescription = null,
                                            tint = TextSecondarySlate,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Text(
                                            text = locationLine,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondarySlate,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }

                            // Glowing Circular Call / Contact Button matching Reference Screen 4
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(CyanAccent.copy(alpha = 0.28f), ElectricBluePrimary.copy(alpha = 0.16f))
                                        )
                                    )
                                    .border(1.2.dp, CyanAccent.copy(alpha = 0.8f), CircleShape)
                                    .clickable {
                                        if (tech.publicPhone.isNotBlank()) {
                                            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${tech.publicPhone}"))
                                            context.startActivity(dialIntent)
                                        } else {
                                            selectedTechForDetails = tech
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Phone,
                                    contentDescription = "Contact ${tech.fullName}",
                                    tint = CyanAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }

            // "Join as Tech" Footer Card (Keeps registration accessible without cluttering top reference layout)
            item {
                AuroraGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("technician_register_toggle"),
                    cornerRadius = 18.dp,
                    onClick = { showRegisterForm = true }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Are you an Appliance Technician?",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Apply for Super Admin verification to appear in the directory",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = ElectricBluePrimary.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, CyanAccent)
                        ) {
                            Text(
                                text = "Join as Tech",
                                style = MaterialTheme.typography.labelMedium,
                                color = CyanAccent,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Technician Details Dialog
    selectedTechForDetails?.let { tech ->
        AlertDialog(
            onDismissRequest = { selectedTechForDetails = null },
            containerColor = SecondaryNavySurface,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tech.fullName, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                    if (tech.verified) {
                        Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = CyanAccent, modifier = Modifier.size(18.dp))
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Experience: ${tech.experienceYears} year(s)", color = CyanAccent, style = MaterialTheme.typography.labelLarge)
                    Text("Specialties: ${tech.applianceCategories.joinToString(", ") { it.uppercase() }}", color = TextPrimaryWhite, style = MaterialTheme.typography.bodySmall)
                    Text("Location: ${listOf(tech.serviceLocation, tech.city).filter { it.isNotBlank() }.joinToString(", ")}", color = TextSecondarySlate, style = MaterialTheme.typography.bodySmall)
                    if (tech.serviceDetails.isNotBlank()) {
                        Text(tech.serviceDetails, color = TextPrimaryWhite, style = MaterialTheme.typography.bodyMedium)
                    }
                    if (tech.publicPhone.isNotBlank()) {
                        Text("Phone: ${tech.publicPhone}", color = SuccessGreen, style = MaterialTheme.typography.labelLarge)
                    } else {
                        Text("No public phone number provided by this technician.", color = TextSecondarySlate, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                if (tech.publicPhone.isNotBlank()) {
                    Button(
                        onClick = {
                            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${tech.publicPhone}")))
                            selectedTechForDetails = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                    ) {
                        Icon(Icons.Filled.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Call Now")
                    }
                } else {
                    TextButton(onClick = { selectedTechForDetails = null }) {
                        Text("Close", color = CyanAccent)
                    }
                }
            },
            dismissButton = {
                if (tech.publicPhone.isNotBlank()) {
                    TextButton(onClick = { selectedTechForDetails = null }) {
                        Text("Close", color = TextSecondarySlate)
                    }
                }
            }
        )
    }
}
