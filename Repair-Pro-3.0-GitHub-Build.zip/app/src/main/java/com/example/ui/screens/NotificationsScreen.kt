package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.AnnouncementCloud
import com.example.data.remote.UserNotificationCloud
import com.example.i18n.UiStrings
import com.example.notifications.RepairProMessagingService
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.theme.LiquidGlassTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotificationsScreen(
    strings: UiStrings,
    userNotifications: List<UserNotificationCloud>,
    announcements: List<AnnouncementCloud>,
    readAnnouncementIds: Set<String>,
    notificationsEnabled: Boolean,
    onToggleNotifications: (Boolean) -> Unit,
    onMarkNotificationRead: (String) -> Unit,
    onMarkAnnouncementRead: (String) -> Unit,
    onNavigateRoute: (String) -> Unit,
    onBack: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val context = LocalContext.current
    var permissionGranted by remember {
        mutableStateOf(RepairProMessagingService.hasNotificationPermission(context))
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
    }
    val fmt = remember { SimpleDateFormat("dd MMM • HH:mm", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("notifications_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = strings.notificationsTitle,
                subtitle = "Community replies, verification updates & admin announcements",
                onBack = onBack,
                backTestTag = "notifications_back_button"
            )
        }

        // Notification Preference & Android 13+ POST_NOTIFICATIONS Runtime Permission
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                elevated = true,
                contentPadding = 14.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("In-App & Push Alerts", style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                            Text("Post approvals, replies, verification & safety updates", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        }
                        Switch(
                            checked = notificationsEnabled,
                            onCheckedChange = onToggleNotifications,
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = palette.primaryAccent,
                                checkedThumbColor = palette.onPrimaryAccent
                            ),
                            modifier = Modifier.testTag("notifications_toggle_switch")
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !permissionGranted) {
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.primaryAccent,
                                contentColor = palette.onPrimaryAccent
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("request_notification_permission_button")
                        ) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("Allow Android Push Notifications", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        if (announcements.isNotEmpty()) {
            item {
                Text("Official Announcements", style = MaterialTheme.typography.titleMedium, color = palette.primaryAccent, fontWeight = FontWeight.Bold)
            }
            items(announcements, key = { "ann_${it.announcementId.ifBlank { it.id }}" }) { ann ->
                val annId = ann.announcementId.ifBlank { ann.id }
                val isUnread = annId !in readAnnouncementIds
                LiquidGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("announcement_card_$annId"),
                    shape = RoundedCornerShape(20.dp),
                    elevated = true,
                    accentBorder = isUnread,
                    onClick = {
                        if (isUnread) onMarkAnnouncementRead(annId)
                        if (ann.targetRoute.isNotBlank()) onNavigateRoute(ann.targetRoute)
                    },
                    contentPadding = 14.dp
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(palette.primaryAccent.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Campaign, contentDescription = null, tint = palette.primaryAccent)
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(ann.title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (isUnread) {
                                    Box(modifier = Modifier.size(9.dp).clip(CircleShape).background(palette.primaryAccent))
                                }
                            }
                            Text(ann.body, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                            if (ann.imageUrl.startsWith("https://")) {
                                AsyncImage(
                                    model = ann.imageUrl,
                                    contentDescription = ann.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                )
                            }
                            val ts = ann.createdAt?.toDate()?.let { fmt.format(it) } ?: ""
                            Text("${ann.category} • $ts", style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        }
                    }
                }
            }
        }

        item {
            Text("Personal Activity", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary, fontWeight = FontWeight.Bold)
        }

        if (userNotifications.isEmpty()) {
            item {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    elevated = true,
                    contentPadding = 24.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Filled.Notifications, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(34.dp))
                        Text("You're all caught up", style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.Bold)
                        Text("Approvals, comments, replies, and technician verification updates will appear here.", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                    }
                }
            }
        } else {
            items(userNotifications, key = { "ntf_${it.notificationId.ifBlank { it.id }}" }) { item ->
                val notifId = item.notificationId.ifBlank { item.id }
                val iconAndTint = when (item.type) {
                    "POST_APPROVED" -> Icons.Filled.CheckCircle to palette.success
                    "VERIFICATION_APPROVED" -> Icons.Filled.Verified to palette.success
                    "COMMENT", "REPLY" -> Icons.Filled.Forum to palette.primaryAccent
                    else -> Icons.Filled.Notifications to palette.warning
                }
                LiquidGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("user_notification_card_$notifId"),
                    shape = RoundedCornerShape(20.dp),
                    elevated = true,
                    accentBorder = !item.isRead,
                    onClick = {
                        if (!item.isRead) onMarkNotificationRead(notifId)
                        if (item.targetRoute.isNotBlank()) onNavigateRoute(item.targetRoute)
                    },
                    contentPadding = 14.dp
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(iconAndTint.second.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(iconAndTint.first, contentDescription = item.type, tint = iconAndTint.second, modifier = Modifier.size(20.dp))
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(item.title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (!item.isRead) {
                                    Box(modifier = Modifier.size(9.dp).clip(CircleShape).background(palette.primaryAccent))
                                }
                            }
                            Text(item.body, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                            if (item.imageUrl.startsWith("https://")) {
                                AsyncImage(
                                    model = item.imageUrl,
                                    contentDescription = item.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(130.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                )
                            }
                            val ts = item.createdAt?.toDate()?.let { fmt.format(it) } ?: fmt.format(Date())
                            Text(ts, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
