package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.remote.PushNotificationItem
import com.example.ui.components.AuroraGlassCard
import com.example.ui.theme.AuroraAccentGradient
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.PurpleBorderGradient
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun NotificationsScreen(
    notifications: List<PushNotificationItem>,
    fcmToken: String?,
    onBack: () -> Unit,
    onRefreshToken: () -> Unit
) {
    val context = LocalContext.current
    var permissionGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) onRefreshToken()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("notifications_screen"),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x66122142))
                        .border(1.dp, CyanAccent.copy(alpha = 0.4f), CircleShape)
                        .testTag("notifications_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Notifications & Alerts", style = MaterialTheme.typography.titleLarge, color = TextPrimaryWhite)
                    Text("Repair updates, new manuals & technician notices", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                }
            }
        }

        // FCM Status & Permission Card
        item {
            val statusColor = if (permissionGranted) SuccessGreen else WarningAmber
            AuroraGlassCard(
                cornerRadius = 18.dp,
                borderBrush = Brush.linearGradient(listOf(statusColor.copy(alpha = 0.65f), CyanAccent.copy(alpha = 0.45f))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(statusColor.copy(alpha = 0.16f))
                                .border(1.dp, statusColor.copy(alpha = 0.45f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (permissionGranted) Icons.Filled.NotificationsActive else Icons.Filled.NotificationsOff,
                                contentDescription = null,
                                tint = statusColor
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (permissionGranted) "Push Notifications Enabled (FCM)" else "Enable Push Notifications",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (!fcmToken.isNullOrBlank()) {
                                    "Device registered: ${fcmToken.take(16)}…"
                                } else {
                                    "Tap Sync Token to register this device for Repair Pro alerts."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!permissionGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            Button(
                                onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(AuroraAccentGradient)
                                    .testTag("request_notification_permission_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = TextPrimaryWhite),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Allow Alerts", fontWeight = FontWeight.Bold)
                            }
                        }
                        OutlinedButton(
                            onClick = onRefreshToken,
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.65f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sync FCM Token", color = CyanAccent)
                        }
                    }
                }
            }
        }

        if (notifications.isEmpty()) {
            item {
                AuroraGlassCard(
                    cornerRadius = 16.dp,
                    borderBrush = PurpleBorderGradient,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("No notifications yet.", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                        Text(
                            text = "Announcements sent from the Super Admin Panel will appear here.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate
                        )
                    }
                }
            }
        } else {
            items(notifications, key = { it.id }) { item ->
                AuroraGlassCard(
                    cornerRadius = 16.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, modifier = Modifier.weight(1f))
                            Surface(
                                color = ElectricBluePrimary.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(50),
                                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f))
                            ) {
                                Text(
                                    text = item.targetType,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanAccent,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(item.body, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        if (item.deliveryStatus.isNotBlank()) {
                            Text(
                                text = "Status: ${item.deliveryStatus}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (item.deliveryStatus.contains("SENT", true)) SuccessGreen else WarningAmber
                            )
                        }
                    }
                }
            }
        }
    }
}
