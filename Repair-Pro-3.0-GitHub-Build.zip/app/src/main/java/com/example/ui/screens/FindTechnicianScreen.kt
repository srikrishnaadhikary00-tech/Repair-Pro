package com.example.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WorkHistory
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.example.data.remote.TechnicianCloud
import com.example.data.remote.V2DomainHelper
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.UiStrings
import com.example.ui.UiState
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.LiquidGlassSkeletonCard
import com.example.ui.components.OnlineOnlyOfflineGuardCard
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.components.liquidGlassSecondaryChipColors
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun FindTechnicianScreen(
    language: AppLanguage,
    techniciansState: UiState<List<TechnicianCloud>>,
    isOnline: Boolean,
    onRetry: () -> Unit,
    onShowMessage: (String) -> Unit,
    onBack: (() -> Unit)? = null,
    onApplyVerification: (() -> Unit)? = null,
    onCallTechnician: ((String) -> Unit)? = null
) {
    val palette = LiquidGlassTheme.colors
    val strings = StringsProvider.get(language)
    val context = LocalContext.current

    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf("ALL") }
    var selectedDistrict by rememberSaveable { mutableStateOf("ALL") }
    var selectedTechnicianDetail by remember { mutableStateOf<TechnicianCloud?>(null) }

    val allActiveTechnicians = remember(techniciansState) {
        when (techniciansState) {
            is UiState.Success -> techniciansState.data.filter { it.isPubliclyVisible }
            else -> emptyList()
        }
    }

    val districts = remember(allActiveTechnicians) {
        allActiveTechnicians
            .map { it.district.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .sortedBy { it.lowercase() }
    }

    val filteredTechnicians = remember(allActiveTechnicians, searchQuery, selectedCategory, selectedDistrict) {
        val q = searchQuery.trim().lowercase()
        allActiveTechnicians.filter { tech ->
            val matchesQuery = q.isEmpty() ||
                tech.fullName.lowercase().contains(q) ||
                tech.district.lowercase().contains(q) ||
                tech.cityArea.lowercase().contains(q) ||
                tech.state.lowercase().contains(q) ||
                tech.fullAddress.lowercase().contains(q) ||
                tech.pinCode.lowercase().contains(q)
            val matchesCategory = selectedCategory == "ALL" ||
                tech.serviceCategories.any { it.equals(selectedCategory, ignoreCase = true) }
            val matchesDistrict = selectedDistrict == "ALL" ||
                tech.district.trim().equals(selectedDistrict, ignoreCase = true)
            matchesQuery && matchesCategory && matchesDistrict
        }
    }

    val dialPhone: (String) -> Unit = { phone ->
        val cleanPhone = phone.trim().replace(Regex("[^+0-9]"), "")
        if (onCallTechnician != null) {
            onCallTechnician(cleanPhone)
        } else {
            try {
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone"))
                context.startActivity(dialIntent)
            } catch (_: ActivityNotFoundException) {
                onShowMessage(strings.dialerUnavailable)
            } catch (_: Exception) {
                onShowMessage(strings.dialerUnavailable)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("find_technician_list"),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (onBack != null) {
                        Surface(
                            modifier = Modifier.size(48.dp),
                            shape = CircleShape,
                            color = palette.glassFillElevated,
                            shadowElevation = if (palette.isDark) 2.dp else 4.dp,
                            border = BorderStroke(1.dp, palette.glassBorder)
                        ) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.fillMaxSize().testTag("find_tech_back_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = palette.textPrimary)
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(palette.primaryAccent.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Engineering,
                                contentDescription = null,
                                tint = palette.primaryAccent,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = strings.findTechnicianTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("find_technician_heading")
                        )
                        Text(
                            text = strings.findTechnicianSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                }
                if (techniciansState is UiState.Success) {
                    Surface(
                        color = palette.success.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, palette.success.copy(alpha = 0.42f))
                    ) {
                        Text(
                            text = "${filteredTechnicians.size}",
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.success,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Apply for Verification CTA Banner
        if (onApplyVerification != null) {
            item {
                LiquidGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("find_tech_apply_verification_cta"),
                    shape = RoundedCornerShape(20.dp),
                    elevated = true,
                    accentBorder = true,
                    onClick = onApplyVerification,
                    contentPadding = 14.dp
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(22.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Are you a Repair Technician?",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Apply for Technician Verification to earn a Verified Badge & directory listing.",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textSecondary
                            )
                        }
                        Text(
                            text = "Apply",
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.primaryAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (!isOnline) {
            item {
                OnlineOnlyOfflineGuardCard(
                    title = strings.noInternetTitle,
                    message = "Please connect to the internet to browse verified technicians.",
                    retryLabel = strings.retry,
                    onRetry = onRetry
                )
            }
            return@LazyColumn
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it.take(80) },
                placeholder = {
                    Text(
                        text = strings.searchTechniciansPlaceholder,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = {
                    Icon(Icons.Filled.Search, contentDescription = strings.navSearch, tint = palette.primaryAccent)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { searchQuery = "" },
                            modifier = Modifier.testTag("tech_search_clear")
                        ) {
                            Icon(Icons.Filled.Clear, contentDescription = "Clear search", tint = palette.textSecondary)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                colors = liquidGlassFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tech_search_input")
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val categoryOptions = listOf(
                    "ALL" to strings.allCategories,
                    "AC" to strings.categoryAc,
                    "Refrigerator" to strings.categoryFridge,
                    "Washing Machine" to strings.categoryWasher
                )
                categoryOptions.forEach { (key, label) ->
                    val selected = selectedCategory == key
                    FilterChip(
                        selected = selected,
                        onClick = { selectedCategory = key },
                        label = { Text(label) },
                        modifier = Modifier.testTag("tech_cat_chip_${key.lowercase().replace(" ", "_")}"),
                        colors = liquidGlassFilterChipColors(),
                        border = liquidGlassFilterChipBorder(selected),
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            }
        }

        if (districts.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = null,
                        tint = palette.primaryAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    FilterChip(
                        selected = selectedDistrict == "ALL",
                        onClick = { selectedDistrict = "ALL" },
                        label = { Text(strings.allDistricts) },
                        modifier = Modifier.testTag("tech_district_chip_all"),
                        colors = liquidGlassSecondaryChipColors(),
                        border = liquidGlassFilterChipBorder(selectedDistrict == "ALL"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    districts.forEach { dist ->
                        val selected = selectedDistrict.equals(dist, ignoreCase = true)
                        FilterChip(
                            selected = selected,
                            onClick = { selectedDistrict = dist },
                            label = { Text(dist) },
                            modifier = Modifier.testTag("tech_district_chip_${dist.lowercase().replace(" ", "_")}"),
                            colors = liquidGlassSecondaryChipColors(),
                            border = liquidGlassFilterChipBorder(selected),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        }

        when (techniciansState) {
            is UiState.Loading -> {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                            .testTag("tech_loading_indicator"),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = palette.primaryAccent)
                        Text(strings.loadingTechnicians, style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                        LiquidGlassSkeletonCard(height = 104.dp)
                        LiquidGlassSkeletonCard(height = 104.dp)
                    }
                }
            }

            is UiState.Error -> {
                item {
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth().testTag("tech_error_card"),
                        shape = RoundedCornerShape(20.dp),
                        customContainerColor = palette.error.copy(alpha = if (palette.isDark) 0.14f else 0.10f),
                        customBorderColor = palette.error.copy(alpha = 0.45f),
                        contentPadding = 20.dp
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = palette.error, modifier = Modifier.size(40.dp))
                            Text(strings.techniciansErrorMessage, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary, textAlign = TextAlign.Center)
                            Button(
                                onClick = onRetry,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.primaryAccent,
                                    contentColor = palette.onPrimaryAccent
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.testTag("tech_retry_button")
                            ) {
                                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.retry, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            is UiState.Success -> {
                if (filteredTechnicians.isEmpty()) {
                    item {
                        LiquidGlassCard(
                            modifier = Modifier.fillMaxWidth().testTag("tech_empty_state"),
                            shape = RoundedCornerShape(22.dp),
                            elevated = true,
                            contentPadding = 24.dp
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(Icons.Filled.PersonSearch, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(44.dp))
                                Text(strings.noTechniciansFound, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary, fontWeight = FontWeight.Bold)
                                Text(strings.noTechniciansSubtitle, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary, textAlign = TextAlign.Center)
                                if (searchQuery.isNotBlank() || selectedCategory != "ALL" || selectedDistrict != "ALL") {
                                    OutlinedButton(
                                        onClick = {
                                            searchQuery = ""
                                            selectedCategory = "ALL"
                                            selectedDistrict = "ALL"
                                        },
                                        border = BorderStroke(1.dp, palette.primaryAccent),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.testTag("tech_clear_filters_button")
                                    ) {
                                        Text(strings.clearFilters, color = palette.primaryAccent)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    items(filteredTechnicians, key = { it.id.ifBlank { it.technicianId } }) { tech ->
                        TechnicianProfileCard(
                            technician = tech,
                            strings = strings,
                            onCardClick = { selectedTechnicianDetail = tech },
                            onCallClick = { dialPhone(tech.mobileNumber) }
                        )
                    }
                }
            }
        }
    }

    val detailTech = selectedTechnicianDetail
    if (detailTech != null) {
        TechnicianProfileModalDialog(
            technician = detailTech,
            strings = strings,
            onDismiss = { selectedTechnicianDetail = null },
            onCallClick = {
                selectedTechnicianDetail = null
                dialPhone(detailTech.mobileNumber)
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TechnicianProfileModalDialog(
    technician: TechnicianCloud,
    strings: UiStrings,
    onDismiss: () -> Unit,
    onCallClick: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val isVerified = V2DomainHelper.isVerifiedTechnicianRecord(technician)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.dialogSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TechnicianAvatar(photoUrl = technician.photoUrl, fullName = technician.fullName)
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(technician.fullName, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary, fontWeight = FontWeight.Bold)
                        if (isVerified) {
                            Icon(Icons.Filled.Verified, contentDescription = "Verified Technician", tint = palette.success, modifier = Modifier.size(18.dp))
                        }
                    }
                    if (isVerified) {
                        Text("Verified Repair Pro Technician", style = MaterialTheme.typography.labelSmall, color = palette.success)
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (technician.experience.isNotBlank()) {
                    Text("${strings.experienceLabel}: ${technician.experience}", style = MaterialTheme.typography.labelLarge, color = palette.primaryAccent)
                }
                if (technician.bio.isNotBlank()) {
                    Text(technician.bio, style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                }
                if (technician.serviceCategories.isNotEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        technician.serviceCategories.forEach { cat ->
                            Surface(color = palette.primaryAccent.copy(alpha = 0.14f), shape = RoundedCornerShape(8.dp)) {
                                Text(cat, style = MaterialTheme.typography.labelSmall, color = palette.primaryAccent, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                            }
                        }
                    }
                }
                Surface(
                    color = palette.glassFillSubtle,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, palette.glassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = listOf(technician.cityArea, technician.district, technician.state, technician.pinCode)
                                .filter { it.isNotBlank() }
                                .joinToString(", "),
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textPrimary
                        )
                        if (technician.fullAddress.isNotBlank()) {
                            Text(technician.fullAddress, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        }
                        Text(technician.mobileNumber, style = MaterialTheme.typography.labelMedium, fontFamily = JetBrainsMonoFontFamily, color = palette.success)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onCallClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.primaryAccent,
                    contentColor = palette.onPrimaryAccent
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.callNow)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = palette.textSecondary)
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TechnicianProfileCard(
    technician: TechnicianCloud,
    strings: UiStrings,
    onCardClick: () -> Unit,
    onCallClick: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val cardKey = technician.id.ifBlank { technician.technicianId }
    val isVerified = V2DomainHelper.isVerifiedTechnicianRecord(technician)

    LiquidGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("technician_card_$cardKey"),
        shape = RoundedCornerShape(22.dp),
        elevated = true,
        accentBorder = isVerified,
        onClick = onCardClick,
        contentPadding = 16.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                TechnicianAvatar(
                    photoUrl = technician.photoUrl,
                    fullName = technician.fullName
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = technician.fullName,
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (isVerified) {
                            Icon(
                                imageVector = Icons.Filled.Verified,
                                contentDescription = "Verified Technician",
                                tint = palette.success,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    if (technician.experience.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.WorkHistory,
                                contentDescription = null,
                                tint = palette.primaryAccent,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "${strings.experienceLabel}: ${technician.experience}",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.primaryAccent
                            )
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        technician.serviceCategories.forEach { category ->
                            val localizedCat = when (category) {
                                "AC" -> strings.categoryAc
                                "Refrigerator" -> strings.categoryFridge
                                "Washing Machine" -> strings.categoryWasher
                                else -> category
                            }
                            Surface(
                                color = palette.primaryAccent.copy(alpha = 0.13f),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, palette.glassBorderAccent)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Build,
                                        contentDescription = null,
                                        tint = palette.primaryAccent,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = localizedCat,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.textPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = palette.glassFillSubtle,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, palette.glassBorder)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = null,
                            tint = palette.primaryAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = buildString {
                                append(technician.cityArea)
                                if (technician.district.isNotBlank()) append(", ${technician.district}")
                                if (technician.state.isNotBlank()) append(" • ${technician.state}")
                                if (technician.pinCode.isNotBlank()) append(" - ${technician.pinCode}")
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = technician.fullAddress,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Phone,
                            contentDescription = null,
                            tint = palette.success,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = technician.mobileNumber,
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = palette.textPrimary
                        )
                    }
                }
            }

            Button(
                onClick = onCallClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("call_tech_$cardKey"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.primaryAccent,
                    contentColor = palette.onPrimaryAccent
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.Call,
                    contentDescription = strings.callNow,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${strings.callNow} • ${technician.mobileNumber}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun TechnicianAvatar(
    photoUrl: String,
    fullName: String
) {
    val palette = LiquidGlassTheme.colors
    val initials = remember(fullName) {
        val parts = fullName.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        when {
            parts.isEmpty() -> "RP"
            parts.size == 1 -> parts[0].take(2).uppercase()
            else -> "${parts.first().first()}${parts.last().first()}".uppercase()
        }
    }

    val fallbackBox: @Composable () -> Unit = {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(palette.primaryAccent, palette.secondaryAccent.copy(alpha = 0.85f))))
                .border(1.5.dp, palette.glassBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initials,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
    }

    if (photoUrl.startsWith("https://")) {
        SubcomposeAsyncImage(
            model = photoUrl,
            contentDescription = "$fullName profile photo",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(palette.glassFillElevated)
                .border(1.5.dp, palette.glassBorderAccent, CircleShape),
            loading = { fallbackBox() },
            error = { fallbackBox() }
        )
    } else {
        fallbackBox()
    }
}
