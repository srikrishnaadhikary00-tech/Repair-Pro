package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.BrandEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.TechnicalDocumentCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AdMobBannerSlot
import com.example.ui.components.ErrorCodePill
import com.example.ui.components.GlowingApplianceCard
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.OnlineOnlyOfflineGuardCard
import com.example.ui.components.RepairProTopHeader
import com.example.ui.components.VerificationBadge
import com.example.ui.components.categoryDrawableRes
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun CategoriesDirectoryScreen(
    language: AppLanguage,
    categories: List<ApplianceCategoryEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    onSelectCategory: (String) -> Unit,
    onOpenWizard: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    val palette = LiquidGlassTheme.colors
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = strings.navCategories,
                    style = MaterialTheme.typography.headlineMedium,
                    color = palette.textPrimary
                )
                Text(
                    text = strings.tagline,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
            }
        }
        items(categories, key = { it.id }) { cat ->
            val name = resolveLocalizedText(language, cat.nameEn, cat.nameBn, cat.nameHi).text
            val sub = resolveLocalizedText(language, cat.subtitleEn, cat.subtitleBn, cat.subtitleHi).text
            val codeCount = errorCodes.count { it.categoryId == cat.id }
            val probCount = problems.count { it.categoryId == cat.id }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                GlowingApplianceCard(
                    categoryId = cat.id,
                    title = name,
                    subtitle = sub,
                    badgeText = "$codeCount Error Codes • $probCount Guides",
                    onClick = { onSelectCategory(cat.id) }
                )
                Button(
                    onClick = { onOpenWizard(cat.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_wizard_${cat.id}"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.glassFillElevated,
                        contentColor = palette.primaryAccent
                    ),
                    border = BorderStroke(1.dp, palette.glassBorderAccent),
                    shape = RoundedCornerShape(16.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoFixHigh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("${strings.wizardTitle}: $name", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun CategoryDetailBrandScreen(
    categoryId: String,
    language: AppLanguage,
    category: ApplianceCategoryEntity?,
    brands: List<BrandEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    categoryDocuments: List<TechnicalDocumentCloud> = emptyList(),
    adMobConfig: AppSettingCloud,
    isOnline: Boolean,
    adConsentGranted: Boolean,
    showTopHeader: Boolean = false,
    userName: String = "",
    userPhotoUrl: String = "",
    unreadNotificationCount: Int = 0,
    onRetryConnection: () -> Unit = {},
    onOpenMenu: () -> Unit = {},
    onOpenNotifications: () -> Unit = {},
    onOpenProfile: () -> Unit = {},
    onBack: () -> Unit,
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit,
    onOpenWizard: (String) -> Unit,
    onOpenScanner: () -> Unit,
    onOpenPdfViewer: (url: String, title: String) -> Unit = { _, _ -> },
    onOpenImageViewer: (url: String, title: String) -> Unit = { _, _ -> }
) {
    val strings = StringsProvider.get(language)
    val palette = LiquidGlassTheme.colors
    val categoryTitle = if (category != null) {
        resolveLocalizedText(language, category.nameEn, category.nameBn, category.nameHi).text
    } else categoryId.uppercase()

    var selectedBrandId by remember { mutableStateOf<String?>(null) }
    var selectedModel by remember { mutableStateOf<String?>(null) }
    var activeTab by remember { mutableIntStateOf(0) } // 0 = Brands, 1 = Common Problems, 2 = Error Codes
    var searchQuery by remember { mutableStateOf("") }

    val selectedBrand = brands.firstOrNull { it.id == selectedBrandId }
    val q = searchQuery.trim().lowercase()

    val filteredBrands = remember(brands, q) {
        if (q.isBlank()) brands else brands.filter {
            it.name.lowercase().contains(q) || it.modelsCsv.lowercase().contains(q)
        }
    }
    val filteredProblems = remember(problems, q, language) {
        if (q.isBlank()) problems else problems.filter { prob ->
            val t = resolveLocalizedText(language, prob.titleEn, prob.titleBn, prob.titleHi).text
            val s = resolveLocalizedText(language, prob.symptomsEn, prob.symptomsBn, prob.symptomsHi).text
            t.lowercase().contains(q) || s.lowercase().contains(q) || prob.relatedErrorCodes.lowercase().contains(q)
        }
    }
    val filteredCodes = remember(errorCodes, selectedBrandId, selectedModel, q, language) {
        errorCodes.filter { code ->
            val brandMatch = selectedBrandId == null ||
                code.brandId == selectedBrandId ||
                code.brandName.equals(selectedBrand?.name, ignoreCase = true)
            val modelMatch = selectedModel == null ||
                code.modelSeries.contains(selectedModel!!.substringBefore(" "), ignoreCase = true)
            val queryMatch = if (q.isBlank()) true else {
                val t = resolveLocalizedText(language, code.titleEn, code.titleBn, code.titleHi).text
                code.code.lowercase().contains(q) ||
                    code.brandName.lowercase().contains(q) ||
                    t.lowercase().contains(q) ||
                    code.modelSeries.lowercase().contains(q)
            }
            brandMatch && (modelMatch || selectedModel == null) && queryMatch
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (showTopHeader) {
            item {
                RepairProTopHeader(
                    subtitle = categoryTitle,
                    userName = userName,
                    userPhotoUrl = userPhotoUrl,
                    unreadNotifications = unreadNotificationCount,
                    onOpenMenu = onOpenMenu,
                    onOpenNotifications = onOpenNotifications,
                    onOpenProfile = onOpenProfile
                )
            }
        } else {
            item {
                LiquidGlassBackBar(
                    title = categoryTitle,
                    onBack = onBack,
                    backTestTag = "category_back_button",
                    trailing = {
                        Surface(
                            modifier = Modifier.size(48.dp),
                            shape = CircleShape,
                            color = palette.glassFillElevated,
                            shadowElevation = if (palette.isDark) 2.dp else 4.dp,
                            border = BorderStroke(1.dp, palette.glassBorder)
                        ) {
                            IconButton(
                                onClick = onOpenScanner,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("category_scanner_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CameraAlt,
                                    contentDescription = strings.cameraScan,
                                    tint = palette.primaryAccent
                                )
                            }
                        }
                    }
                )
            }
        }

        // 3D Liquid Glass Appliance Hero Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(156.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, palette.glassBorder, RoundedCornerShape(24.dp))
            ) {
                Image(
                    painter = painterResource(id = categoryDrawableRes(categoryId)),
                    contentDescription = categoryTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xD80A111F))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(14.dp)
                ) {
                    Text(
                        text = categoryTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${brands.size} Brands • ${errorCodes.size} Error Codes • ${problems.size} Guides",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF7DD3FC)
                    )
                }
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onOpenWizard(categoryId) }
                        .testTag("category_wizard_cta"),
                    color = palette.primaryAccent,
                    shape = RoundedCornerShape(14.dp),
                    shadowElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoFixHigh,
                            contentDescription = null,
                            tint = palette.onPrimaryAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Wizard",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.onPrimaryAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Online-only enforcement for repair guides
        if (!isOnline) {
            item {
                OnlineOnlyOfflineGuardCard(
                    title = strings.noInternetTitle,
                    message = strings.noInternetGuidesMessage,
                    retryLabel = strings.retry,
                    onRetry = onRetryConnection
                )
            }
            return@LazyColumn
        }

        // Inline Category Search + Camera OCR button
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search $categoryTitle code, brand, or issue...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = palette.primaryAccent) },
                trailingIcon = {
                    IconButton(onClick = onOpenScanner, modifier = Modifier.testTag("category_inline_scanner_btn")) {
                        Icon(Icons.Filled.CameraAlt, contentDescription = strings.cameraScan, tint = palette.primaryAccent)
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = liquidGlassFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("category_search_input")
            )
        }

        // Category PDF Manuals & Circuit Diagrams Strip
        if (categoryDocuments.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = strings.pdfAndDiagramsTitle,
                        style = MaterialTheme.typography.labelLarge,
                        color = palette.primaryAccent,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categoryDocuments.forEach { doc ->
                            val isPdf = doc.docType.equals("PDF_MANUAL", ignoreCase = true) ||
                                doc.mimeType.contains("pdf", ignoreCase = true)
                            LiquidGlassCard(
                                modifier = Modifier.testTag("category_doc_${doc.id}"),
                                shape = RoundedCornerShape(16.dp),
                                accentBorder = true,
                                onClick = {
                                    if (isPdf) onOpenPdfViewer(doc.fileUrl, doc.title)
                                    else onOpenImageViewer(doc.fileUrl, doc.title)
                                },
                                contentPadding = 10.dp
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isPdf) Icons.Filled.Description else Icons.Filled.Image,
                                        contentDescription = doc.title,
                                        tint = if (isPdf) palette.warning else palette.primaryAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Column {
                                        Text(
                                            text = doc.title,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = palette.textPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = if (isPdf) "Online PDF Manual" else "Circuit / Repair Diagram",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = palette.textSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Frosted Segmented Tabs: Brands | Common Problems | Error Codes
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                contentPadding = 4.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val tabs = listOf(
                        strings.selectBrand.substringAfter(" ").ifBlank { "Brands" },
                        strings.commonProblems,
                        strings.errorCodes
                    )
                    tabs.forEachIndexed { idx, title ->
                        val selected = activeTab == idx
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { activeTab = idx }
                                .testTag("category_tab_$idx"),
                            color = if (selected) palette.primaryAccent else Color.Transparent,
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) palette.onPrimaryAccent else palette.textSecondary,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .padding(vertical = 10.dp, horizontal = 6.dp)
                                    .align(Alignment.CenterVertically)
                            )
                        }
                    }
                }
            }
        }

        // Quick Brand Filter Chips
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedBrandId == null,
                    onClick = {
                        selectedBrandId = null
                        selectedModel = null
                    },
                    label = { Text(strings.allBrands) },
                    colors = liquidGlassFilterChipColors(),
                    border = liquidGlassFilterChipBorder(selectedBrandId == null)
                )
                brands.forEach { brand ->
                    val isSelected = selectedBrandId == brand.id
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedBrandId = brand.id
                            selectedModel = null
                        },
                        label = { Text(brand.name) },
                        colors = liquidGlassFilterChipColors(),
                        border = liquidGlassFilterChipBorder(isSelected)
                    )
                }
            }
        }

        // Model / Series selector when a specific brand is selected
        if (selectedBrand != null) {
            item {
                val models = selectedBrand.modelsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "${selectedBrand.name} — ${strings.selectModel}",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.primaryAccent,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        models.forEach { model ->
                            val isSelected = selectedModel == model
                            LiquidGlassCard(
                                modifier = Modifier,
                                shape = RoundedCornerShape(12.dp),
                                customContainerColor = if (isSelected) {
                                    palette.primaryAccent.copy(alpha = if (palette.isDark) 0.24f else 0.14f)
                                } else null,
                                customBorderColor = if (isSelected) palette.primaryAccent else null,
                                onClick = {
                                    selectedModel = if (isSelected) null else model
                                    activeTab = 2
                                },
                                contentPadding = 0.dp
                            ) {
                                Text(
                                    text = model,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) palette.primaryAccent else palette.textPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        when (activeTab) {
            0 -> {
                items(filteredBrands, key = { it.id }) { brand ->
                    val codeCount = errorCodes.count {
                        it.brandId == brand.id || it.brandName.equals(brand.name, ignoreCase = true)
                    }
                    LiquidGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("brand_row_${brand.id}"),
                        shape = RoundedCornerShape(18.dp),
                        accentBorder = selectedBrandId == brand.id,
                        onClick = {
                            selectedBrandId = brand.id
                            activeTab = 2
                        },
                        contentPadding = 14.dp
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(palette.primaryAccent.copy(alpha = if (palette.isDark) 0.22f else 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = brand.name.take(2).uppercase(),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = palette.primaryAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = brand.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = brand.modelsCsv.replace(",", " • "),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (codeCount > 0) {
                                Surface(
                                    color = palette.success.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "$codeCount Codes",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.success,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = palette.textSecondary
                            )
                        }
                    }
                }
            }
            1 -> {
                items(filteredProblems, key = { it.id }) { prob ->
                    val title = resolveLocalizedText(language, prob.titleEn, prob.titleBn, prob.titleHi).text
                    val symptoms = resolveLocalizedText(language, prob.symptomsEn, prob.symptomsBn, prob.symptomsHi).text
                    val tintColor = problemIconTint(prob.iconKey)
                    LiquidGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("problem_row_${prob.id}"),
                        shape = RoundedCornerShape(18.dp),
                        onClick = { onOpenProblemDetail(prob.id) },
                        contentPadding = 14.dp
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(tintColor.copy(alpha = 0.16f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = problemIconForKey(prob.iconKey),
                                    contentDescription = null,
                                    tint = tintColor,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = symptoms.lineSequence().firstOrNull().orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = palette.primaryAccent
                            )
                        }
                    }
                }
            }
            2 -> {
                if (filteredCodes.isEmpty()) {
                    item {
                        LiquidGlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            contentPadding = 18.dp
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "No matching verified error codes found.",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = "Tap 'All' to view verified codes for this appliance category, or report an undocumented code from More.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary
                                )
                            }
                        }
                    }
                } else {
                    items(filteredCodes, key = { it.id }) { codeItem ->
                        val title = resolveLocalizedText(language, codeItem.titleEn, codeItem.titleBn, codeItem.titleHi).text
                        LiquidGlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("error_row_${codeItem.id}"),
                            shape = RoundedCornerShape(18.dp),
                            onClick = { onOpenErrorDetail(codeItem.id) },
                            contentPadding = 14.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                ErrorCodePill(code = codeItem.code)
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "${codeItem.brandName} — $title",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = palette.textPrimary,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = codeItem.modelSeries,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.textSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    VerificationBadge(
                                        status = codeItem.verificationStatus,
                                        verifiedLabel = strings.verifiedBadge,
                                        unverifiedLabel = strings.unverifiedBadge
                                    )
                                }
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = null,
                                    tint = palette.primaryAccent
                                )
                            }
                        }
                    }
                }
            }
        }

        // Category-Specific Real AdMob Slot
        item {
            AdMobBannerSlot(
                config = adMobConfig,
                categoryId = categoryId,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "category_$categoryId"
            )
        }
    }
}

private fun problemIconForKey(key: String): ImageVector = when (key) {
    "ac_cooling", "fridge_cool", "ice" -> Icons.Filled.AcUnit
    "water_drop", "water_inlet" -> Icons.Filled.WaterDrop
    "power_off" -> Icons.Filled.PowerSettingsNew
    "vibration" -> Icons.Filled.Vibration
    else -> Icons.Filled.Build
}

@Composable
private fun problemIconTint(key: String): Color {
    val palette = LiquidGlassTheme.colors
    return when (key) {
        "ac_cooling", "fridge_cool", "ice" -> palette.secondaryAccent
        "water_drop", "water_inlet" -> palette.primaryAccent
        "power_off" -> palette.error
        "vibration" -> palette.warning
        else -> palette.success
    }
}
