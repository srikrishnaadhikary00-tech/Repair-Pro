package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.BrandEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.remote.AppSettingCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AdMobBannerSlot
import com.example.ui.components.AuroraGlassCard
import com.example.ui.components.AuroraPillFilter
import com.example.ui.components.ErrorCodePill
import com.example.ui.components.GlowingApplianceCard
import com.example.ui.components.VerificationBadge
import com.example.ui.components.categoryDrawableRes
import com.example.ui.theme.AuroraPurple
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanBorderGradient
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.PurpleBorderGradient
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun CategoriesDirectoryScreen(
    language: AppLanguage,
    categories: List<ApplianceCategoryEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    onSelectCategory: (String) -> Unit,
    onOpenWizard: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = strings.navCategories,
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimaryWhite,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = strings.tagline,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondarySlate
            )
        }
        items(categories, key = { it.id }) { cat ->
            val name = resolveLocalizedText(language, cat.nameEn, cat.nameBn, cat.nameHi).text
            val sub = resolveLocalizedText(language, cat.subtitleEn, cat.subtitleBn, cat.subtitleHi).text
            val codeCount = errorCodes.count { it.categoryId == cat.id }
            val probCount = problems.count { it.categoryId == cat.id }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                GlowingApplianceCard(
                    categoryId = cat.id,
                    title = name,
                    subtitle = sub,
                    badgeText = "$codeCount Error Codes • $probCount Guides",
                    onClick = { onSelectCategory(cat.id) }
                )
                Button(
                    onClick = { onOpenWizard(cat.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_wizard_${cat.id}"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricBluePrimary.copy(alpha = 0.25f),
                        contentColor = CyanAccent
                    ),
                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoFixHigh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("${strings.wizardTitle}: $name", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun CategoryDetailBrandScreen(
    categoryId: String,
    language: AppLanguage,
    category: ApplianceCategoryEntity?,
    brands: List<BrandEntity>,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    adMobConfig: AppSettingCloud,
    isOnline: Boolean,
    adConsentGranted: Boolean,
    onBack: () -> Unit,
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit,
    onOpenWizard: (String) -> Unit,
    onOpenScanner: () -> Unit
) {
    val strings = StringsProvider.get(language)
    val categoryTitle = if (category != null) {
        resolveLocalizedText(language, category.nameEn, category.nameBn, category.nameHi).text
    } else categoryId.uppercase()

    var selectedBrandId by remember { mutableStateOf<String?>(null) }
    var selectedModel by remember { mutableStateOf<String?>(null) }
    var activeTab by remember { mutableIntStateOf(0) } // 0 = Brands & Models, 1 = Common Problems, 2 = Error Codes

    val selectedBrand = brands.firstOrNull { it.id == selectedBrandId }
    val filteredCodes = remember(errorCodes, selectedBrandId, selectedModel) {
        errorCodes.filter { code ->
            (selectedBrandId == null || code.brandId == selectedBrandId || code.brandName.equals(selectedBrand?.name, ignoreCase = true)) &&
                (selectedModel == null || code.modelSeries.contains(selectedModel!!.substringBefore(" "), ignoreCase = true) || true)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top App Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("category_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                    }
                    Text(
                        text = categoryTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(CyanAccent.copy(alpha = 0.16f))
                        .border(1.dp, CyanAccent.copy(alpha = 0.5f), CircleShape)
                        .clickable(onClick = onOpenScanner)
                        .testTag("category_scanner_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.CameraAlt,
                        contentDescription = strings.cameraScan,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Category Appliance Banner Artwork with Aurora Border
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .border(1.3.dp, CyanBorderGradient, RoundedCornerShape(22.dp))
            ) {
                Image(
                    painter = painterResource(id = categoryDrawableRes(categoryId)),
                    contentDescription = categoryTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xCC040917))
                            )
                        )
                )
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(50))
                        .clickable { onOpenWizard(categoryId) }
                        .testTag("category_wizard_cta"),
                    color = ElectricBluePrimary,
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.7f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoFixHigh,
                            contentDescription = null,
                            tint = TextPrimaryWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = strings.wizardTitle,
                            style = MaterialTheme.typography.labelMedium,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Segmented Aurora Glass Tabs: Brands | Common Problems | Error Codes
        item {
            AuroraGlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 16.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val tabs = listOf(
                        strings.selectBrand.substringAfter(" ").ifBlank { "Brands" },
                        strings.commonProblems,
                        strings.errorCodes
                    )
                    tabs.forEachIndexed { idx, title ->
                        val selected = activeTab == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (selected) Brush.horizontalGradient(listOf(ElectricBluePrimary, CyanAccent))
                                    else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                                )
                                .clickable { activeTab = idx }
                                .testTag("category_tab_$idx"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) TextPrimaryWhite else TextSecondarySlate,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Quick Brand Filter Pills
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AuroraPillFilter(
                    label = strings.allBrands,
                    selected = selectedBrandId == null,
                    onClick = {
                        selectedBrandId = null
                        selectedModel = null
                    }
                )
                brands.forEach { brand ->
                    AuroraPillFilter(
                        label = brand.name,
                        selected = selectedBrandId == brand.id,
                        onClick = {
                            selectedBrandId = brand.id
                            selectedModel = null
                        }
                    )
                }
            }
        }

        // Model / Series selector when a specific brand is selected
        if (selectedBrand != null) {
            item {
                val models = selectedBrand.modelsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "${selectedBrand.name} — ${strings.selectModel}",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyanAccent
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        models.forEach { model ->
                            val isSelected = selectedModel == model
                            AuroraPillFilter(
                                label = model,
                                selected = isSelected,
                                onClick = {
                                    selectedModel = if (isSelected) null else model
                                    activeTab = 2
                                }
                            )
                        }
                    }
                }
            }
        }

        when (activeTab) {
            0 -> {
                items(brands, key = { it.id }) { brand ->
                    val codeCount = errorCodes.count {
                        it.brandId == brand.id || it.brandName.equals(brand.name, ignoreCase = true)
                    }
                    AuroraGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("brand_row_${brand.id}"),
                        cornerRadius = 16.dp,
                        borderBrush = if (selectedBrandId == brand.id) CyanBorderGradient else PurpleBorderGradient,
                        onClick = {
                            selectedBrandId = brand.id
                            activeTab = 2
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(ElectricBluePrimary.copy(alpha = 0.45f), AuroraPurple.copy(alpha = 0.4f))))
                                    .border(1.dp, CyanAccent.copy(alpha = 0.45f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = brand.name.take(2).uppercase(),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = brand.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimaryWhite,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = brand.modelsCsv.replace(",", " • "),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (codeCount > 0) {
                                Surface(
                                    color = SuccessGreen.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "$codeCount Codes",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SuccessGreen,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = CyanAccent
                            )
                        }
                    }
                }
            }
            1 -> {
                items(problems, key = { it.id }) { prob ->
                    val title = resolveLocalizedText(language, prob.titleEn, prob.titleBn, prob.titleHi).text
                    val symptoms = resolveLocalizedText(language, prob.symptomsEn, prob.symptomsBn, prob.symptomsHi).text
                    AuroraGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("problem_row_${prob.id}"),
                        cornerRadius = 16.dp,
                        onClick = { onOpenProblemDetail(prob.id) }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(problemIconTint(prob.iconKey).copy(alpha = 0.18f))
                                    .border(1.dp, problemIconTint(prob.iconKey).copy(alpha = 0.45f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = problemIconForKey(prob.iconKey),
                                    contentDescription = null,
                                    tint = problemIconTint(prob.iconKey),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimaryWhite,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = symptoms.lineSequence().firstOrNull().orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = CyanAccent
                            )
                        }
                    }
                }
            }
            2 -> {
                if (filteredCodes.isEmpty()) {
                    item {
                        AuroraGlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 16.dp) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "No brand-specific verified codes cached for this filter yet.",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimaryWhite
                                )
                                Text(
                                    text = "Tap 'All' to view verified codes for this appliance category, or report an undocumented code from Profile.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondarySlate
                                )
                            }
                        }
                    }
                } else {
                    items(filteredCodes, key = { it.id }) { codeItem ->
                        val title = resolveLocalizedText(language, codeItem.titleEn, codeItem.titleBn, codeItem.titleHi).text
                        AuroraGlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("error_row_${codeItem.id}"),
                            cornerRadius = 16.dp,
                            onClick = { onOpenErrorDetail(codeItem.id) }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                ErrorCodePill(code = codeItem.code)
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "${codeItem.brandName} — $title",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimaryWhite,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = codeItem.modelSeries,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondarySlate,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    VerificationBadge(
                                        status = codeItem.verificationStatus,
                                        verifiedLabel = strings.verifiedBadge,
                                        unverifiedLabel = strings.unverifiedBadge
                                    )
                                }
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = null,
                                    tint = CyanAccent
                                )
                            }
                        }
                    }
                }
            }
        }

        // Category-Specific AdMob Slot
        item {
            AdMobBannerSlot(
                config = adMobConfig,
                categoryId = categoryId,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "category_$categoryId"
            )
        }
    }
}

private fun problemIconForKey(key: String): ImageVector = when (key) {
    "ac_cooling", "fridge_cool", "ice" -> Icons.Filled.AcUnit
    "water_drop", "water_inlet" -> Icons.Filled.WaterDrop
    "power_off" -> Icons.Filled.PowerSettingsNew
    "vibration" -> Icons.Filled.Vibration
    else -> Icons.Filled.Build
}

private fun problemIconTint(key: String): Color = when (key) {
    "ac_cooling", "fridge_cool", "ice" -> CyanAccent
    "water_drop", "water_inlet" -> ElectricBluePrimary
    "power_off" -> ErrorCrimson
    "vibration" -> WarningAmber
    else -> SuccessGreen
}
