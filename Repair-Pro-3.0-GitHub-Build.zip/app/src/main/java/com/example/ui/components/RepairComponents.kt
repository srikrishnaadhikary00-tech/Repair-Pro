package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.remote.AppSettingCloud
import com.example.i18n.AppLanguage
import com.example.ui.theme.AuroraPurple
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanBorderGradient
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@DrawableRes
fun categoryDrawableRes(categoryId: String): Int = when (categoryId.lowercase()) {
    "ac" -> R.drawable.img_cat_ac_1795249926667
    "fridge" -> R.drawable.img_cat_fridge_1795249926943
    "washer" -> R.drawable.img_cat_washer_1795249925832
    else -> R.drawable.img_splash_appliances_1795249925550
}

@Composable
fun RepairProBrandLogo(
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        RepairProGearWrenchLogo(size = if (compact) 34.dp else 52.dp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Repair ",
                style = if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineLarge,
                color = TextPrimaryWhite,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Pro",
                style = if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineLarge,
                color = CyanAccent,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            AuroraVersionBadge(versionText = "3.0", compact = compact)
        }
    }
}

@Composable
fun GlowingApplianceCard(
    categoryId: String,
    title: String,
    subtitle: String,
    badgeText: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    AuroraGlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("appliance_card_$categoryId"),
        cornerRadius = 20.dp,
        borderBrush = if (categoryId.equals("washer", true)) {
            Brush.horizontalGradient(listOf(AuroraPurple.copy(alpha = 0.85f), CyanAccent.copy(alpha = 0.55f)))
        } else {
            CyanBorderGradient
        },
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = categoryDrawableRes(categoryId)),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(96.dp)
                    .height(74.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, CyanAccent.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = ElectricBluePrimary.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(0.8.dp, CyanAccent.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanAccent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Open $title",
                tint = CyanAccent,
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

@Composable
fun ElectricQuickTile(
    icon: ImageVector,
    label: String,
    accentColor: Color = CyanAccent,
    testTagName: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    AuroraQuickToolTile(
        icon = icon,
        label = label,
        accentColor = accentColor,
        testTagName = testTagName,
        onClick = onClick,
        modifier = modifier
    )
}

@Composable
fun LanguageSwitcherRow(
    currentLanguage: AppLanguage,
    onSelect: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0xB3081126))
            .border(1.dp, CyanAccent.copy(alpha = 0.38f), RoundedCornerShape(50))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        AppLanguage.entries.forEach { lang ->
            val selected = lang == currentLanguage
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (selected) Brush.horizontalGradient(listOf(ElectricBluePrimary, CyanAccent))
                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .clickable { onSelect(lang) }
                    .minimumInteractiveComponentSize()
                    .testTag("lang_chip_${lang.code}"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = lang.nativeLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) TextPrimaryWhite else TextSecondarySlate,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun ErrorCodePill(
    code: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ElectricBluePrimary.copy(alpha = 0.24f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.7f))
    ) {
        Text(
            text = code,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = CyanAccent,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun VerificationBadge(
    status: String,
    verifiedLabel: String,
    unverifiedLabel: String,
    modifier: Modifier = Modifier
) {
    val verified = status.equals("VERIFIED", ignoreCase = true)
    val badgeColor = if (verified) SuccessGreen else WarningAmber
    Surface(
        modifier = modifier,
        color = badgeColor.copy(alpha = 0.14f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                imageVector = if (verified) Icons.Filled.CheckCircle else Icons.Filled.Info,
                contentDescription = if (verified) verifiedLabel else unverifiedLabel,
                tint = badgeColor,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = if (verified) verifiedLabel else unverifiedLabel,
                style = MaterialTheme.typography.labelSmall,
                color = badgeColor
            )
        }
    }
}

@Composable
fun SafetyWarningBanner(
    title: String,
    message: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ErrorCrimson.copy(alpha = 0.14f)),
        border = BorderStroke(1.1.dp, ErrorCrimson.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = title,
                tint = ErrorCrimson,
                modifier = Modifier.size(24.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = ErrorCrimson,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimaryWhite
                )
            }
        }
    }
}

@Composable
fun AdMobBannerSlot(
    config: AppSettingCloud,
    categoryId: String? = null,
    isOnline: Boolean,
    consentGranted: Boolean,
    screenTag: String,
    modifier: Modifier = Modifier
) {
    com.example.ads.RealAdMobBannerView(
        config = config,
        categoryId = categoryId,
        isOnline = isOnline,
        consentGranted = consentGranted,
        screenTag = screenTag,
        modifier = modifier
    )
}

@Composable
fun AdMobNativeSlot(
    config: AppSettingCloud,
    categoryId: String? = null,
    isOnline: Boolean,
    consentGranted: Boolean,
    screenTag: String,
    modifier: Modifier = Modifier
) {
    com.example.ads.RealAdMobNativeAdView(
        config = config,
        categoryId = categoryId,
        isOnline = isOnline,
        consentGranted = consentGranted,
        screenTag = screenTag,
        modifier = modifier
    )
}
