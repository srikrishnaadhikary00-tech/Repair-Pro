package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.R
import com.example.ads.AdMobManager
import com.example.data.remote.AppSettingCloud
import com.example.i18n.AppLanguage
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LiquidGlassTheme

@DrawableRes
fun categoryDrawableRes(categoryId: String): Int = when (categoryId.lowercase()) {
    "ac" -> R.drawable.liquid_glass_ac_1795701643857
    "fridge" -> R.drawable.liquid_glass_fridge_1795701644342
    "washer" -> R.drawable.liquid_glass_washer_1795701645054
    else -> R.drawable.liquid_glass_hero_splash_1795701645608
}

/**
 * Global Liquid Glass Ultra Top Header:
 * Frosted glass menu orb -> Repair Pro brand logo + subtitle ->
 * Notification glass pill + User avatar ring.
 */
@Composable
fun RepairProTopHeader(
    subtitle: String,
    userName: String,
    userPhotoUrl: String,
    unreadNotifications: Int,
    onOpenMenu: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Surface(
                modifier = Modifier.size(48.dp),
                shape = CircleShape,
                color = palette.glassFillElevated,
                shadowElevation = if (palette.isDark) 2.dp else 4.dp,
                border = BorderStroke(1.dp, palette.glassBorder)
            ) {
                IconButton(
                    onClick = onOpenMenu,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("global_header_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Menu,
                        contentDescription = "Open navigation menu",
                        tint = palette.textPrimary
                    )
                }
            }
            Column {
                RepairProBrandLogo(compact = true)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box {
                Surface(
                    modifier = Modifier.size(48.dp),
                    shape = CircleShape,
                    color = palette.glassFillElevated,
                    shadowElevation = if (palette.isDark) 2.dp else 4.dp,
                    border = BorderStroke(1.dp, palette.glassBorder)
                ) {
                    IconButton(
                        onClick = onOpenNotifications,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("global_header_notifications_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Notifications,
                            contentDescription = "Notifications",
                            tint = if (unreadNotifications > 0) palette.primaryAccent else palette.textSecondary
                        )
                    }
                }
                if (unreadNotifications > 0) {
                    Surface(
                        color = palette.error,
                        shape = CircleShape,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 4.dp, end = 4.dp)
                    ) {
                        Text(
                            text = if (unreadNotifications > 9) "9+" else unreadNotifications.toString(),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(palette.primaryAccent.copy(alpha = 0.18f))
                    .border(1.5.dp, palette.primaryAccent.copy(alpha = 0.65f), CircleShape)
                    .clickable(onClick = onOpenProfile)
                    .testTag("global_header_avatar_button"),
                contentAlignment = Alignment.Center
            ) {
                if (userPhotoUrl.startsWith("https://")) {
                    AsyncImage(
                        model = userPhotoUrl,
                        contentDescription = "User profile",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                    )
                } else {
                    Text(
                        text = userName.trim().take(1).uppercase().ifBlank { "R" },
                        color = palette.primaryAccent,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }
        }
    }
}

/**
 * Online-only repair guide guard. Shown whenever the device has no internet connection.
 */
@Composable
fun OnlineOnlyOfflineGuardCard(
    title: String = "No Internet Connection",
    message: String = "Please connect to the internet to view repair guides.",
    retryLabel: String = "Retry",
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("online_only_offline_guard"),
        shape = RoundedCornerShape(22.dp),
        elevated = true,
        customBorderColor = palette.warning.copy(alpha = 0.55f),
        contentPadding = 24.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(palette.warning.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.CloudOff,
                    contentDescription = title,
                    tint = palette.warning,
                    modifier = Modifier.size(30.dp)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
                textAlign = TextAlign.Center
            )
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.primaryAccent,
                    contentColor = palette.onPrimaryAccent
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("online_only_retry_button")
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(retryLabel, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun CompactApplianceHomeCard(
    categoryId: String,
    title: String,
    countBadge: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = modifier.testTag("appliance_card_$categoryId"),
        shape = RoundedCornerShape(20.dp),
        elevated = true,
        accentBorder = true,
        onClick = onClick,
        contentPadding = 9.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Image(
                painter = painterResource(id = categoryDrawableRes(categoryId)),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .border(0.8.dp, palette.glassBorder, RoundedCornerShape(13.dp))
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = palette.textPrimary,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
            Surface(
                color = if (palette.isDark) {
                    palette.primaryAccent.copy(alpha = 0.22f)
                } else {
                    palette.glassAccent.copy(alpha = 0.65f)
                },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = countBadge,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (palette.isDark) palette.secondaryAccent else palette.textPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun DashboardStatCard(
    value: String,
    label: String,
    accent: Color = LiquidGlassTheme.colors.primaryAccent,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        customBorderColor = accent.copy(alpha = 0.28f),
        contentPadding = 10.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = accent,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = palette.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun RepairProBrandLogo(
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val palette = LiquidGlassTheme.colors
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(if (compact) 32.dp else 46.dp)
                .clip(RoundedCornerShape(if (compact) 11.dp else 14.dp))
                .background(palette.primaryButtonGradient)
                .border(1.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(if (compact) 11.dp else 14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Build,
                contentDescription = "Repair Pro Logo",
                tint = Color.White,
                modifier = Modifier.size(if (compact) 18.dp else 24.dp)
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Repair ",
                style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.headlineLarge,
                color = palette.textPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Pro",
                style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.headlineLarge,
                color = palette.primaryAccent,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Custom vector icon for Repair Pro AI — rendered strictly separately from text labels.
 */
@Composable
fun RepairProAiIcon(
    modifier: Modifier = Modifier,
    primaryTint: Color = LiquidGlassTheme.colors.primaryAccent,
    secondaryTint: Color = LiquidGlassTheme.colors.secondaryAccent
) {
    Canvas(modifier = modifier.size(22.dp)) {
        val w = size.width
        val h = size.height
        val strokeWidth = (minOf(w, h) * 0.085f).coerceAtLeast(1.6f)

        // Outer glass diagnostic badge frame
        drawRoundRect(
            brush = Brush.linearGradient(listOf(primaryTint, secondaryTint)),
            topLeft = Offset(w * 0.08f, h * 0.08f),
            size = Size(w * 0.84f, h * 0.84f),
            cornerRadius = CornerRadius(w * 0.24f, h * 0.24f),
            style = Stroke(width = strokeWidth)
        )

        // Four-point AI star in center
        val cx = w * 0.48f
        val cy = h * 0.50f
        val rOuter = w * 0.27f
        val rInner = w * 0.09f
        val starPath = Path().apply {
            moveTo(cx, cy - rOuter)
            lineTo(cx + rInner, cy - rInner)
            lineTo(cx + rOuter, cy)
            lineTo(cx + rInner, cy + rInner)
            lineTo(cx, cy + rOuter)
            lineTo(cx - rInner, cy + rInner)
            lineTo(cx - rOuter, cy)
            lineTo(cx - rInner, cy - rInner)
            close()
        }
        drawPath(
            path = starPath,
            brush = Brush.linearGradient(listOf(primaryTint, secondaryTint))
        )

        // Accent micro sparkle dot
        drawCircle(
            color = secondaryTint,
            radius = w * 0.065f,
            center = Offset(w * 0.76f, h * 0.24f)
        )

        // Diagnostic pulse line accent at bottom
        val pulsePath = Path().apply {
            moveTo(w * 0.24f, h * 0.77f)
            lineTo(w * 0.37f, h * 0.77f)
            lineTo(w * 0.44f, h * 0.69f)
            lineTo(w * 0.54f, h * 0.83f)
            lineTo(w * 0.62f, h * 0.77f)
            lineTo(w * 0.76f, h * 0.77f)
        }
        drawPath(
            path = pulsePath,
            color = primaryTint.copy(alpha = 0.88f),
            style = Stroke(width = strokeWidth * 0.85f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun GlowingApplianceCard(
    categoryId: String,
    title: String,
    subtitle: String,
    badgeText: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("appliance_card_$categoryId"),
        shape = RoundedCornerShape(22.dp),
        elevated = true,
        accentBorder = true,
        onClick = onClick,
        contentPadding = 12.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = categoryDrawableRes(categoryId)),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(96.dp)
                    .height(74.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, palette.glassBorder, RoundedCornerShape(14.dp))
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = palette.primaryAccent.copy(alpha = if (palette.isDark) 0.22f else 0.13f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.primaryAccent,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Open $title",
                tint = palette.primaryAccent,
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

@Composable
fun ElectricQuickTile(
    icon: ImageVector,
    label: String,
    accentColor: Color = LiquidGlassTheme.colors.primaryAccent,
    testTagName: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    customIcon: (@Composable () -> Unit)? = null
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag(testTagName),
        shape = RoundedCornerShape(19.dp),
        onClick = onClick,
        contentPadding = 10.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = if (palette.isDark) 0.20f else 0.14f))
                    .border(0.8.dp, accentColor.copy(alpha = 0.28f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (customIcon != null) {
                    customIcon()
                } else {
                    Icon(
                        imageVector = icon,
                        contentDescription = label.replace("\n", " "),
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(7.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = palette.textPrimary,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 2,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
fun LanguageSwitcherRow(
    currentLanguage: AppLanguage,
    onSelect: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(palette.glassFillSubtle)
            .border(1.dp, palette.glassBorder, RoundedCornerShape(14.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        AppLanguage.entries.forEach { lang ->
            val selected = lang == currentLanguage
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelect(lang) }
                    .testTag("lang_chip_${lang.code}"),
                color = if (selected) palette.primaryAccent else Color.Transparent,
                shape = RoundedCornerShape(10.dp),
                shadowElevation = if (selected) 3.dp else 0.dp
            ) {
                Text(
                    text = lang.nativeLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) palette.onPrimaryAccent else palette.textSecondary,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun ErrorCodePill(
    code: String,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    Surface(
        modifier = modifier,
        color = if (palette.isDark) {
            palette.primaryAccent.copy(alpha = 0.22f)
        } else {
            palette.glassAccent.copy(alpha = 0.65f)
        },
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, palette.primaryAccent.copy(alpha = 0.45f))
    ) {
        Text(
            text = code,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = if (palette.isDark) palette.secondaryAccent else palette.primaryAccent,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun VerificationBadge(
    status: String,
    verifiedLabel: String,
    unverifiedLabel: String,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    val verified = status.equals("VERIFIED", ignoreCase = true)
    val badgeColor = if (verified) palette.success else palette.warning
    Surface(
        modifier = modifier,
        color = badgeColor.copy(alpha = 0.14f),
        shape = RoundedCornerShape(9.dp),
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.42f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                imageVector = if (verified) Icons.Filled.CheckCircle else Icons.Filled.Info,
                contentDescription = if (verified) verifiedLabel else unverifiedLabel,
                tint = badgeColor,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = if (verified) verifiedLabel else unverifiedLabel,
                style = MaterialTheme.typography.labelSmall,
                color = badgeColor,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun SafetyWarningBanner(
    title: String,
    message: String,
    modifier: Modifier = Modifier
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        customContainerColor = palette.error.copy(alpha = if (palette.isDark) 0.16f else 0.10f),
        customBorderColor = palette.error.copy(alpha = 0.48f),
        contentPadding = 14.dp
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = title,
                tint = palette.error,
                modifier = Modifier.size(24.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = palette.error,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textPrimary
                )
            }
        }
    }
}

/**
 * Real Google Mobile Ads SDK Banner Slot controlled by Super Admin Supabase config
 * (global toggle, emergency kill switch, banner toggle, per-category AC/Fridge/Washer switches,
 * testMode flag, online check, and user NPA consent).
 */
@Composable
fun AdMobBannerSlot(
    config: AppSettingCloud,
    categoryId: String? = null,
    isOnline: Boolean,
    consentGranted: Boolean,
    screenTag: String,
    modifier: Modifier = Modifier
) {
    if (!isOnline || !AdMobManager.isBannerAllowed(config, categoryId)) return

    val palette = LiquidGlassTheme.colors
    val context = LocalContext.current
    val unitId = AdMobManager.resolveBannerUnitId(config)
    val adView = remember(unitId, consentGranted) {
        AdMobManager.createBannerAdView(context, config, consentGranted)
    }

    DisposableEffect(adView) {
        onDispose {
            try {
                adView?.destroy()
            } catch (_: Throwable) {
                // Safe teardown
            }
        }
    }

    LiquidGlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("admob_banner_$screenTag"),
        shape = RoundedCornerShape(16.dp)
    ) {
        if (adView != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { adView },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            // Safe fallback container for JVM Robolectric tests where Play Services AdView is absent
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (config.testMode) "Google AdMob Banner (Test Mode)" else "Google AdMob Banner",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.textPrimary
                    )
                    Text(
                        text = unitId,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textMuted,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
