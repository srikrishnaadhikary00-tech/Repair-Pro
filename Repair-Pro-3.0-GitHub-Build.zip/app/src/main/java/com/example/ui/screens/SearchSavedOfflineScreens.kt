package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.local.SearchHistoryEntity
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.SavedGuideCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AdMobBannerSlot
import com.example.ui.components.ErrorCodePill
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.OnlineOnlyOfflineGuardCard
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.components.liquidGlassSecondaryChipColors
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun SmartSearchScreen(
    initialQuery: String,
    initialFilterType: String, // "ALL", "ERROR", "PROBLEM"
    language: AppLanguage,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    searchHistory: List<SearchHistoryEntity>,
    adMobConfig: AppSettingCloud,
    isOnline: Boolean,
    adConsentGranted: Boolean,
    onRetryConnection: () -> Unit = {},
    onBack: (() -> Unit)? = null,
    onRecordSearch: (String) -> Unit,
    onClearHistory: () -> Unit,
    onOpenScanner: () -> Unit,
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    val palette = LiquidGlassTheme.colors
    var query by remember(initialQuery) { mutableStateOf(initialQuery) }
    var categoryFilter by remember { mutableStateOf("all") }
    var typeFilter by remember(initialFilterType) { mutableStateOf(initialFilterType) }

    val q = query.trim().lowercase()
    val matchedCodes = remember(q, categoryFilter, typeFilter, errorCodes) {
        if (typeFilter == "PROBLEM") emptyList()
        else errorCodes.filter { c ->
            val catOk = categoryFilter == "all" || c.categoryId == categoryFilter
            val queryOk = q.isBlank() || listOf(
                c.code, c.brandName, c.modelSeries,
                c.titleEn, c.titleBn, c.titleHi,
                c.meaningEn, c.meaningBn, c.meaningHi,
                c.symptomsEn, c.symptomsBn, c.symptomsHi
            ).any { it.lowercase().contains(q) }
            catOk && queryOk
        }
    }

    val matchedProblems = remember(q, categoryFilter, typeFilter, problems) {
        if (typeFilter == "ERROR") emptyList()
        else problems.filter { p ->
            val catOk = categoryFilter == "all" || p.categoryId == categoryFilter
            val queryOk = q.isBlank() || listOf(
                p.titleEn, p.titleBn, p.titleHi,
                p.symptomsEn, p.symptomsBn, p.symptomsHi,
                p.causesEn, p.causesBn, p.causesHi,
                p.relatedErrorCodes
            ).any { it.lowercase().contains(q) }
            catOk && queryOk
        }
    }

    val popularSuggestions = listOf("CH05", "E1", "OE", "Not Cooling", "Er FF", "Water Leak", "dE", "5E")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (onBack != null) {
            item {
                LiquidGlassBackBar(
                    title = strings.navSearch,
                    onBack = onBack,
                    backTestTag = "search_back_button"
                )
            }
        }

        if (!isOnline) {
            item {
                OnlineOnlyOfflineGuardCard(
                    title = strings.noInternetTitle,
                    message = strings.noInternetGuidesMessage,
                    retryLabel = strings.retry,
                    onRetry = onRetryConnection
                )
            }
            return@LazyColumn
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(strings.searchPlaceholder) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = palette.primaryAccent) },
                trailingIcon = {
                    Row {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Clear", tint = palette.textSecondary)
                            }
                        }
                        IconButton(onClick = onOpenScanner) {
                            Icon(Icons.Filled.CameraAlt, contentDescription = strings.cameraScan, tint = palette.primaryAccent)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("smart_search_input"),
                colors = liquidGlassFieldColors()
            )
        }

        // Category + Type Filter Chips
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("all" to strings.allBrands, "ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                    val selected = categoryFilter == id
                    FilterChip(
                        selected = selected,
                        onClick = { categoryFilter = id },
                        label = { Text(label) },
                        colors = liquidGlassFilterChipColors(),
                        border = liquidGlassFilterChipBorder(selected)
                    )
                }
                FilterChip(
                    selected = typeFilter == "ERROR",
                    onClick = { typeFilter = if (typeFilter == "ERROR") "ALL" else "ERROR" },
                    label = { Text(strings.errorCodes) },
                    colors = liquidGlassSecondaryChipColors(),
                    border = liquidGlassFilterChipBorder(typeFilter == "ERROR")
                )
                FilterChip(
                    selected = typeFilter == "PROBLEM",
                    onClick = { typeFilter = if (typeFilter == "PROBLEM") "ALL" else "PROBLEM" },
                    label = { Text(strings.commonProblems) },
                    colors = liquidGlassSecondaryChipColors(),
                    border = liquidGlassFilterChipBorder(typeFilter == "PROBLEM")
                )
            }
        }

        // Suggestions & History when empty
        if (q.isBlank()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = strings.popularSearches,
                        style = MaterialTheme.typography.labelLarge,
                        color = palette.primaryAccent,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        popularSuggestions.forEach { term ->
                            LiquidGlassCard(
                                shape = RoundedCornerShape(12.dp),
                                onClick = {
                                    query = term
                                    onRecordSearch(term)
                                },
                                contentPadding = 0.dp
                            ) {
                                Text(
                                    text = term,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = palette.textPrimary,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
            if (searchHistory.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.recentSearches, style = MaterialTheme.typography.labelLarge, color = palette.textSecondary)
                        Text(
                            text = "Clear",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.error,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable(onClick = onClearHistory)
                        )
                    }
                }
            }
        }

        if (matchedCodes.isNotEmpty()) {
            item {
                Text(
                    text = "${strings.errorCodes} (${matchedCodes.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = palette.primaryAccent,
                    fontWeight = FontWeight.SemiBold
                )
            }
            items(matchedCodes, key = { it.id }) { c ->
                val title = resolveLocalizedText(language, c.titleEn, c.titleBn, c.titleHi).text
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    onClick = {
                        if (q.isNotBlank()) onRecordSearch(query)
                        onOpenErrorDetail(c.id)
                    },
                    contentPadding = 12.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ErrorCodePill(code = c.code)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${c.brandName} • $title",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = c.modelSeries,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        if (matchedProblems.isNotEmpty()) {
            item {
                Text(
                    text = "${strings.commonProblems} (${matchedProblems.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = palette.primaryAccent,
                    fontWeight = FontWeight.SemiBold
                )
            }
            items(matchedProblems, key = { it.id }) { p ->
                val title = resolveLocalizedText(language, p.titleEn, p.titleBn, p.titleHi).text
                val sym = resolveLocalizedText(language, p.symptomsEn, p.symptomsBn, p.symptomsHi).text
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    onClick = {
                        if (q.isNotBlank()) onRecordSearch(query)
                        onOpenProblemDetail(p.id)
                    },
                    contentPadding = 12.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.Build, contentDescription = null, tint = palette.primaryAccent)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary)
                            Text(
                                text = sym.lineSequence().firstOrNull().orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        if (matchedCodes.isEmpty() && matchedProblems.isEmpty()) {
            item {
                Text(
                    text = strings.noResultsFound,
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            }
        }

        item {
            AdMobBannerSlot(
                config = adMobConfig,
                categoryId = if (categoryFilter == "all") null else categoryFilter,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "search"
            )
        }
    }
}

@Composable
fun SavedGuidesScreen(
    language: AppLanguage,
    savedGuides: List<SavedGuideCloud>,
    onBack: (() -> Unit)? = null,
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit,
    onRemoveGuide: (SavedGuideCloud) -> Unit
) {
    val strings = StringsProvider.get(language)
    val palette = LiquidGlassTheme.colors
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            if (onBack != null) {
                LiquidGlassBackBar(
                    title = strings.savedGuides,
                    onBack = onBack,
                    backTestTag = "saved_back_button"
                )
            } else {
                Text(strings.savedGuides, style = MaterialTheme.typography.headlineSmall, color = palette.textPrimary)
            }
        }
        if (savedGuides.isEmpty()) {
            item {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = 24.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Filled.Bookmark,
                            contentDescription = null,
                            tint = palette.primaryAccent,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(strings.noSavedYet, style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                    }
                }
            }
        } else {
            items(savedGuides, key = { it.id }) { guide ->
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    onClick = {
                        if (guide.itemType == "ERROR_CODE") onOpenErrorDetail(guide.itemId)
                        else onOpenProblemDetail(guide.itemId)
                    },
                    contentPadding = 14.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(guide.title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary)
                            Text(
                                text = guide.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = { onRemoveGuide(guide) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Remove", tint = palette.error)
                        }
                    }
                }
            }
        }
    }
}
