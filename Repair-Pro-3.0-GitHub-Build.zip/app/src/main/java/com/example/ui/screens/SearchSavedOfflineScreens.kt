package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ads.AdMobManager
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.OfflinePackageEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.local.SearchHistoryEntity
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.SavedGuideCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.AdMobBannerSlot
import com.example.ui.components.AdMobNativeSlot
import com.example.ui.components.AuroraGlassCard
import com.example.ui.components.AuroraPillFilter
import com.example.ui.components.ErrorCodePill
import com.example.ui.theme.AuroraAccentGradient
import com.example.ui.theme.AuroraPurple
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanBorderGradient
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.GlassCardFillBottom
import com.example.ui.theme.GlassCardFillTop
import com.example.ui.theme.PurpleBorderGradient
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SmartSearchScreen(
    initialQuery: String,
    initialFilterType: String, // "ALL", "ERROR", "PROBLEM"
    language: AppLanguage,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    searchHistory: List<SearchHistoryEntity>,
    adMobConfig: AppSettingCloud,
    isOnline: Boolean,
    adConsentGranted: Boolean,
    onRecordSearch: (String) -> Unit,
    onClearHistory: () -> Unit,
    onOpenScanner: () -> Unit,
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    var query by remember(initialQuery) { mutableStateOf(initialQuery) }
    var categoryFilter by remember { mutableStateOf("all") }
    var typeFilter by remember(initialFilterType) { mutableStateOf(initialFilterType) }

    val q = query.trim().lowercase()
    val matchedCodes = remember(q, categoryFilter, typeFilter, errorCodes) {
        if (typeFilter == "PROBLEM") emptyList()
        else errorCodes.filter { c ->
            val catOk = categoryFilter == "all" || c.categoryId == categoryFilter
            val queryOk = q.isBlank() || listOf(
                c.code, c.brandName, c.modelSeries,
                c.titleEn, c.titleBn, c.titleHi,
                c.meaningEn, c.meaningBn, c.meaningHi,
                c.symptomsEn, c.symptomsBn, c.symptomsHi
            ).any { it.lowercase().contains(q) }
            catOk && queryOk
        }
    }

    val matchedProblems = remember(q, categoryFilter, typeFilter, problems) {
        if (typeFilter == "ERROR") emptyList()
        else problems.filter { p ->
            val catOk = categoryFilter == "all" || p.categoryId == categoryFilter
            val queryOk = q.isBlank() || listOf(
                p.titleEn, p.titleBn, p.titleHi,
                p.symptomsEn, p.symptomsBn, p.symptomsHi,
                p.causesEn, p.causesBn, p.causesHi,
                p.relatedErrorCodes
            ).any { it.lowercase().contains(q) }
            catOk && queryOk
        }
    }

    val popularSuggestions = listOf("CH05", "E1", "OE", "Not Cooling", "Er FF", "Water Leak", "dE", "5E")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(strings.searchPlaceholder, color = TextSecondarySlate) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = CyanAccent) },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Clear", tint = TextSecondarySlate)
                            }
                        }
                        IconButton(onClick = onOpenScanner) {
                            Icon(Icons.Filled.CameraAlt, contentDescription = strings.cameraScan, tint = CyanAccent)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("smart_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = AuroraPurple.copy(alpha = 0.55f),
                    focusedTextColor = TextPrimaryWhite,
                    unfocusedTextColor = TextPrimaryWhite,
                    focusedContainerColor = GlassCardFillTop,
                    unfocusedContainerColor = GlassCardFillBottom
                )
            )
        }

        // Category + Type Aurora Pill Filters
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("all" to strings.allBrands, "ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                    AuroraPillFilter(
                        label = label,
                        selected = categoryFilter == id,
                        onClick = { categoryFilter = id }
                    )
                }
                AuroraPillFilter(
                    label = strings.errorCodes,
                    selected = typeFilter == "ERROR",
                    onClick = { typeFilter = if (typeFilter == "ERROR") "ALL" else "ERROR" }
                )
                AuroraPillFilter(
                    label = strings.commonProblems,
                    selected = typeFilter == "PROBLEM",
                    onClick = { typeFilter = if (typeFilter == "PROBLEM") "ALL" else "PROBLEM" }
                )
            }
        }

        // Suggestions & History when empty
        if (q.isBlank()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.popularSearches, style = MaterialTheme.typography.labelLarge, color = CyanAccent)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        popularSuggestions.forEach { term ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable {
                                        query = term
                                        onRecordSearch(term)
                                    },
                                color = GlassCardFillTop,
                                shape = RoundedCornerShape(50),
                                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.4f))
                            ) {
                                Text(
                                    text = term,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextPrimaryWhite,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
            if (searchHistory.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.recentSearches, style = MaterialTheme.typography.labelLarge, color = TextSecondarySlate)
                        Text(
                            text = "Clear",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErrorCrimson,
                            modifier = Modifier.clickable(onClick = onClearHistory)
                        )
                    }
                }
            }
        }

        if (matchedCodes.isNotEmpty()) {
            item {
                Text(
                    text = "${strings.errorCodes} (${matchedCodes.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = CyanAccent,
                    fontWeight = FontWeight.Bold
                )
            }
            items(matchedCodes, key = { it.id }) { c ->
                val title = resolveLocalizedText(language, c.titleEn, c.titleBn, c.titleHi).text
                AuroraGlassCard(
                    cornerRadius = 16.dp,
                    borderBrush = CyanBorderGradient,
                    onClick = {
                        if (q.isNotBlank()) onRecordSearch(query)
                        onOpenErrorDetail(c.id)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ErrorCodePill(code = c.code)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${c.brandName} • $title",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = c.modelSeries,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = CyanAccent)
                    }
                }
            }
        }

        if (matchedProblems.isNotEmpty()) {
            item {
                Text(
                    text = "${strings.commonProblems} (${matchedProblems.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = CyanAccent,
                    fontWeight = FontWeight.Bold
                )
            }
            items(matchedProblems, key = { it.id }) { p ->
                val title = resolveLocalizedText(language, p.titleEn, p.titleBn, p.titleHi).text
                val sym = resolveLocalizedText(language, p.symptomsEn, p.symptomsBn, p.symptomsHi).text
                AuroraGlassCard(
                    cornerRadius = 16.dp,
                    borderBrush = PurpleBorderGradient,
                    onClick = {
                        if (q.isNotBlank()) onRecordSearch(query)
                        onOpenProblemDetail(p.id)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(11.dp))
                                .background(ElectricBluePrimary.copy(alpha = 0.2f))
                                .border(1.dp, CyanAccent.copy(alpha = 0.45f), RoundedCornerShape(11.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Build, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(19.dp))
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                            Text(
                                text = sym.lineSequence().firstOrNull().orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = CyanAccent)
                    }
                }
            }
        }

        if (matchedCodes.isEmpty() && matchedProblems.isEmpty()) {
            item {
                AuroraGlassCard(
                    cornerRadius = 16.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = strings.noResultsFound,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondarySlate,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            }
        }

        item {
            AdMobNativeSlot(
                config = adMobConfig,
                categoryId = if (categoryFilter == "all") null else categoryFilter,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "search"
            )
        }

        item {
            AdMobBannerSlot(
                config = adMobConfig,
                categoryId = if (categoryFilter == "all") null else categoryFilter,
                isOnline = isOnline,
                consentGranted = adConsentGranted,
                screenTag = "search"
            )
        }
    }
}

@Composable
fun SavedGuidesScreen(
    language: AppLanguage,
    savedGuides: List<SavedGuideCloud>,
    onOpenErrorDetail: (String) -> Unit,
    onOpenProblemDetail: (String) -> Unit,
    onRemoveGuide: (SavedGuideCloud) -> Unit
) {
    val strings = StringsProvider.get(language)
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Filled.Bookmark, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(24.dp))
                Text(strings.savedGuides, style = MaterialTheme.typography.headlineMedium, color = TextPrimaryWhite)
            }
        }
        if (savedGuides.isEmpty()) {
            item {
                AuroraGlassCard(
                    cornerRadius = 18.dp,
                    borderBrush = PurpleBorderGradient,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Filled.Bookmark,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(strings.noSavedYet, style = MaterialTheme.typography.bodyMedium, color = TextSecondarySlate)
                    }
                }
            }
        } else {
            items(savedGuides, key = { it.id }) { guide ->
                AuroraGlassCard(
                    cornerRadius = 16.dp,
                    onClick = {
                        if (guide.itemType == "ERROR_CODE") onOpenErrorDetail(guide.itemId)
                        else onOpenProblemDetail(guide.itemId)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(guide.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                            Text(
                                text = guide.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = { onRemoveGuide(guide) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Remove", tint = ErrorCrimson)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OfflineDownloadsScreen(
    language: AppLanguage,
    packages: List<OfflinePackageEntity>,
    isOnline: Boolean,
    syncInProgress: Boolean,
    lastSyncTime: Long?,
    onBack: () -> Unit,
    onSyncNow: () -> Unit,
    onTogglePackage: (String, Boolean) -> Unit,
    adMobConfig: AppSettingCloud = AppSettingCloud(id = "admob_config", configType = "ADMOB", rewardedEnabled = false),
    onWatchRewardedSupport: (() -> Unit)? = null
) {
    val strings = StringsProvider.get(language)
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x66122142))
                        .border(1.dp, CyanAccent.copy(alpha = 0.4f), CircleShape)
                        .testTag("offline_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Text(strings.offlineDownloadsTitle, style = MaterialTheme.typography.titleLarge, color = TextPrimaryWhite)
            }
        }

        item {
            val statusColor = if (isOnline) SuccessGreen else WarningAmber
            AuroraGlassCard(
                cornerRadius = 18.dp,
                borderBrush = Brush.linearGradient(listOf(statusColor.copy(alpha = 0.7f), CyanAccent.copy(alpha = 0.45f))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(
                            imageVector = if (isOnline) Icons.Filled.CheckCircle else Icons.Filled.CloudOff,
                            contentDescription = null,
                            tint = statusColor
                        )
                        Text(
                            text = if (isOnline) strings.offlineReady else strings.offlineModeActive,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = "${strings.lastSynced}: ${if (lastSyncTime != null) dateFormat.format(Date(lastSyncTime)) else "Pre-loaded SQLite Ready"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate
                    )
                    Button(
                        onClick = onSyncNow,
                        enabled = !syncInProgress,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(AuroraAccentGradient)
                            .testTag("offline_sync_now_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = TextPrimaryWhite)
                    ) {
                        if (syncInProgress) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = TextPrimaryWhite, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.syncNow, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        items(packages, key = { it.categoryId }) { pack ->
            AuroraGlassCard(
                cornerRadius = 16.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background((if (pack.downloaded) CyanAccent else TextSecondarySlate).copy(alpha = 0.14f))
                            .border(1.dp, (if (pack.downloaded) CyanAccent else CardBorderSubtle).copy(alpha = 0.45f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CloudDownload,
                            contentDescription = null,
                            tint = if (pack.downloaded) CyanAccent else TextSecondarySlate,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(pack.packageName, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                        Text(
                            text = "${pack.recordCount} records • ${pack.sizeKb} KB • v${pack.version}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate
                        )
                        Text(
                            text = if (pack.downloaded) strings.downloadedPack else strings.downloadPack,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (pack.downloaded) SuccessGreen else WarningAmber
                        )
                    }
                    Switch(
                        checked = pack.downloaded,
                        onCheckedChange = { onTogglePackage(pack.categoryId, it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TextPrimaryWhite,
                            checkedTrackColor = ElectricBluePrimary
                        )
                    )
                }
            }
        }

        if (onWatchRewardedSupport != null && AdMobManager.isRewardedEligible(adMobConfig, isOnline)) {
            item {
                AuroraGlassCard(
                    cornerRadius = 16.dp,
                    borderBrush = CyanBorderGradient,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("Support Free Offline Database", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                            Text("Optional short ad — all offline repair guides remain 100% free.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        }
                        Button(
                            onClick = onWatchRewardedSupport,
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("offline_rewarded_support_button")
                        ) {
                            Text("Watch Ad", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
