package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.remote.COMMUNITY_REPORT_REASONS
import com.example.data.remote.CommunityDomainHelper
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.LiquidGlassTheme
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun communityTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = CyanAccent,
    unfocusedBorderColor = CardBorderSubtle,
    focusedTextColor = TextPrimaryWhite,
    unfocusedTextColor = TextPrimaryWhite,
    focusedLabelColor = CyanAccent,
    unfocusedLabelColor = TextSecondarySlate,
    focusedContainerColor = DeepCardSurface,
    unfocusedContainerColor = DeepCardSurface
)

@Composable
fun CommunityStatusPill(
    status: String,
    modifier: Modifier = Modifier,
    useThemePalette: Boolean = false
) {
    val palette = LiquidGlassTheme.colors
    val successColor = if (useThemePalette) palette.success else SuccessGreen
    val errorColor = if (useThemePalette) palette.error else ErrorCrimson
    val warningColor = if (useThemePalette) palette.warning else WarningAmber
    val mutedColor = if (useThemePalette) palette.textSecondary else TextSecondarySlate

    val (bg, fg, label) = when (status.uppercase()) {
        "APPROVED", "VERIFIED" -> Triple(successColor.copy(alpha = 0.15f), successColor, status.uppercase())
        "REJECTED", "SUSPENDED" -> Triple(errorColor.copy(alpha = 0.15f), errorColor, status.uppercase())
        "RESOLVED" -> Triple(successColor.copy(alpha = 0.15f), successColor, "RESOLVED")
        "DISMISSED" -> Triple(mutedColor.copy(alpha = 0.16f), mutedColor, "DISMISSED")
        "OPEN" -> Triple(errorColor.copy(alpha = 0.15f), errorColor, "OPEN")
        else -> Triple(warningColor.copy(alpha = 0.15f), warningColor, "PENDING")
    }
    Surface(
        modifier = modifier,
        color = bg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.42f))
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

fun formatCommunityTimestamp(timestamp: Timestamp?): String {
    if (timestamp == null) return "Just now"
    val diffSec = (System.currentTimeMillis() / 1000L) - timestamp.seconds
    return when {
        diffSec < 60L -> "Just now"
        diffSec < 3600L -> "${diffSec / 60L}m ago"
        diffSec < 86400L -> "${diffSec / 3600L}h ago"
        diffSec < 604800L -> "${diffSec / 86400L}d ago"
        else -> SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(timestamp.seconds * 1000L))
    }
}

@Composable
fun EditCommunityCommentDialog(
    initialBody: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val palette = LiquidGlassTheme.colors
    var body by remember(initialBody) { mutableStateOf(initialBody) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.dialogSurface,
        titleContentColor = palette.textPrimary,
        textContentColor = palette.textPrimary,
        title = { Text("Edit Comment", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = body,
                    onValueChange = {
                        body = it.take(1000)
                        errorMsg = null
                    },
                    label = { Text("Comment") },
                    minLines = 3,
                    maxLines = 6,
                    shape = RoundedCornerShape(14.dp),
                    colors = liquidGlassFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("edit_comment_input")
                )
                if (!errorMsg.isNullOrBlank()) {
                    Text(errorMsg!!, style = MaterialTheme.typography.labelSmall, color = palette.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val err = CommunityDomainHelper.validateCommentBody(body)
                    if (err != null) {
                        errorMsg = err
                    } else {
                        onSave(body.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.primaryAccent,
                    contentColor = palette.onPrimaryAccent
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_edit_comment_button")
            ) {
                Text("Save", fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}

@Composable
fun ReportCommunityDialog(
    targetLabel: String,
    onDismiss: () -> Unit,
    onSubmit: (reason: String, details: String) -> Unit
) {
    val palette = LiquidGlassTheme.colors
    var selectedReason by remember { mutableStateOf(COMMUNITY_REPORT_REASONS.first().first) }
    var details by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.dialogSurface,
        titleContentColor = palette.textPrimary,
        textContentColor = palette.textPrimary,
        title = {
            Text("Report $targetLabel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Select a reason for Super Admin moderation review:",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
                COMMUNITY_REPORT_REASONS.forEach { (code, label) ->
                    val selected = selectedReason == code
                    LiquidGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("report_reason_${code.lowercase()}"),
                        shape = RoundedCornerShape(12.dp),
                        elevated = selected,
                        accentBorder = selected,
                        customContainerColor = if (selected) {
                            palette.primaryAccent.copy(alpha = if (palette.isDark) 0.24f else 0.14f)
                        } else {
                            palette.glassFillSubtle
                        },
                        customBorderColor = if (selected) palette.primaryAccent else null,
                        onClick = { selectedReason = code },
                        contentPadding = 0.dp
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (selected) palette.primaryAccent else palette.textPrimary,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it.take(600) },
                    label = { Text("Additional details (Optional)") },
                    minLines = 2,
                    maxLines = 4,
                    shape = RoundedCornerShape(14.dp),
                    colors = liquidGlassFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("report_details_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(selectedReason, details.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = palette.error),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("report_submit_button")
            ) {
                Text("Submit Report")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("report_cancel_button")
            ) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}
