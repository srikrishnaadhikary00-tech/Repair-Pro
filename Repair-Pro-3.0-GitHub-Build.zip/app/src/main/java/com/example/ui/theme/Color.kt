package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Repair Pro 3.0 — 3D Aurora Glass Palette (Midnight Navy, Electric Cyan, Aurora Purple)
val DeepNavyBackground = Color(0xFF040712)
val SecondaryNavySurface = Color(0xFF0D172E)
val ElevatedCardSurface = Color(0xFF142242)
val DeepCardSurface = Color(0xFF091022)
val GlassCardFillTop = Color(0xCC132244)
val GlassCardFillBottom = Color(0xB3091228)

val ElectricBluePrimary = Color(0xFF008CFF)
val CyanAccent = Color(0xFF00D8FF)
val AuroraPurple = Color(0xFF8B5CF6)
val AuroraViolet = Color(0xFFA855F7)
val AuroraIndigo = Color(0xFF4F46E5)

val CyanGlowSoft = Color(0x3800D8FF)
val BlueGlowSoft = Color(0x38008CFF)
val PurpleGlowSoft = Color(0x388B5CF6)

val TextPrimaryWhite = Color(0xFFFFFFFF)
val TextSecondarySlate = Color(0xFFA9B8CC)
val TextMutedSteel = Color(0xFF7589A8)
val SuccessGreen = Color(0xFF16C784)
val WarningAmber = Color(0xFFFFB020)
val ErrorCrimson = Color(0xFFFF4757)
val PdfBadgeRed = Color(0xFFE53935)

val CardBorderSubtle = Color(0xFF233962)
val CardBorderCyan = Color(0xFF00C8FF)
val CardBorderPurple = Color(0xFF8B5CF6)

val PrimaryBlueGradient = Brush.horizontalGradient(
    colors = listOf(ElectricBluePrimary, CyanAccent)
)

val AuroraAccentGradient = Brush.horizontalGradient(
    colors = listOf(CyanAccent, ElectricBluePrimary, AuroraPurple)
)

val CyanBorderGradient = Brush.linearGradient(
    colors = listOf(
        CyanAccent.copy(alpha = 0.78f),
        ElectricBluePrimary.copy(alpha = 0.48f),
        AuroraPurple.copy(alpha = 0.62f)
    )
)

val PurpleBorderGradient = Brush.linearGradient(
    colors = listOf(
        AuroraPurple.copy(alpha = 0.82f),
        ElectricBluePrimary.copy(alpha = 0.55f),
        CyanAccent.copy(alpha = 0.50f)
    )
)

val DarkScreenGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF071127), DeepNavyBackground, Color(0xFF03050D))
)

val CardSurfaceGradient = Brush.verticalGradient(
    colors = listOf(GlassCardFillTop, GlassCardFillBottom)
)
