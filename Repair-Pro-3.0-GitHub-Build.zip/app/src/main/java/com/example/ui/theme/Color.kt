package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// =====================================================================
// Liquid Glass Ultra Color Tokens (Light Mode + Dark Mode)
// =====================================================================

// Light Mode Palette
val LiquidLightBackground = Color(0xFFF4F7FF)
val LiquidLightSecondaryBackground = Color(0xFFDCE4FF)
val LiquidLightGlassAccent = Color(0xFFB7E8F5)
val LiquidLightPrimaryAccent = Color(0xFF7965D9)
val LiquidLightSecondaryAccent = Color(0xFF0284C7) // High-contrast sky blue accent on light glass
val LiquidLightCardSurface = Color(0xFFFFFFFF)
val LiquidLightTextPrimary = Color(0xFF101827)
val LiquidLightTextSecondary = Color(0xFF475569)
val LiquidLightTextMuted = Color(0xFF64748B)

// Dark Mode Palette
val LiquidDarkBackground = Color(0xFF080D18)
val LiquidDarkSecondaryBackground = Color(0xFF101827)
val LiquidDarkGlassSurface = Color(0xFF1C2638)
val LiquidDarkPrimaryAccent = Color(0xFFA594FF)
val LiquidDarkSecondaryAccent = Color(0xFF7DD3FC)
val LiquidDarkTextPrimary = Color(0xFFF8FAFC)
val LiquidDarkTextSecondary = Color(0xFFCBD5E1)
val LiquidDarkTextMuted = Color(0xFF94A3B8)

// Semantic Status Accents
val SuccessGreen = Color(0xFF18C97E)
val SuccessGreenLightMode = Color(0xFF059669)
val WarningAmber = Color(0xFFFFB020)
val WarningAmberLightMode = Color(0xFFD97706)
val ErrorCrimson = Color(0xFFFF5263)
val ErrorCrimsonLightMode = Color(0xFFDC2626)

// =====================================================================
// Legacy Color Tokens Preserved for Untouched Admin & PDF Modules
// =====================================================================
val DeepNavyBackground = Color(0xFF020B16)
val SecondaryNavySurface = Color(0xFF061426)
val DeepCardSurface = Color(0xFF081D32)
val ElevatedCardSurface = Color(0xFF0C2740)
val ElectricBluePrimary = Color(0xFF008CFF)
val CyanAccent = Color(0xFF00D8FF)
val CyanGlowSoft = Color(0x3800D8FF)
val BlueGlowSoft = Color(0x38008CFF)
val TextPrimaryWhite = Color(0xFFFFFFFF)
val TextSecondarySlate = Color(0xFFA8BED0)
val TextMutedSteel = Color(0xFF6F88A2)
val CardBorderSubtle = Color(0x47008CFF)
val CardBorderCyan = Color(0x8800D8FF)

val PrimaryBlueGradient = Brush.horizontalGradient(
    colors = listOf(ElectricBluePrimary, CyanAccent)
)

val CyanBorderGradient = Brush.linearGradient(
    colors = listOf(CyanAccent.copy(alpha = 0.72f), ElectricBluePrimary.copy(alpha = 0.30f))
)

val DarkScreenGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF051326), DeepNavyBackground, Color(0xFF010811))
)

val CardSurfaceGradient = Brush.verticalGradient(
    colors = listOf(ElevatedCardSurface, DeepCardSurface)
)

val HeroGlowGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF09315C), Color(0xFF07213E), Color(0xFF041428))
)
