package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AuroraIndigo
import com.example.ui.theme.AuroraPurple
import com.example.ui.theme.AuroraViolet
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanBorderGradient
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.GlassCardFillBottom
import com.example.ui.theme.GlassCardFillTop
import com.example.ui.theme.PdfBadgeRed
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import kotlin.math.cos
import kotlin.math.sin

/**
 * Lightweight GPU-friendly 3D Aurora Backdrop matching the reference midnight blue,
 * cyan, and purple-violet atmospheric waves without expensive offscreen blurs.
 */
@Composable
fun AuroraBackdrop(
    modifier: Modifier = Modifier,
    intenseSplashWaves: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavyBackground)
            .drawBehind {
                val w = size.width
                val h = size.height

                // Deep midnight base vertical sheen
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF060E24),
                            Color(0xFF040713),
                            Color(0xFF050A18)
                        )
                    )
                )

                // Top-left cyan aurora glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            CyanAccent.copy(alpha = if (intenseSplashWaves) 0.28f else 0.17f),
                            ElectricBluePrimary.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        center = Offset(w * 0.14f, h * 0.14f),
                        radius = w * 0.72f
                    ),
                    radius = w * 0.72f,
                    center = Offset(w * 0.14f, h * 0.14f)
                )

                // Right-side electric purple/violet aurora glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            AuroraPurple.copy(alpha = if (intenseSplashWaves) 0.30f else 0.19f),
                            AuroraViolet.copy(alpha = 0.09f),
                            Color.Transparent
                        ),
                        center = Offset(w * 0.88f, h * 0.34f),
                        radius = w * 0.78f
                    ),
                    radius = w * 0.78f,
                    center = Offset(w * 0.88f, h * 0.34f)
                )

                // Lower cyan-blue ambient glow behind bottom showcase/nav
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            ElectricBluePrimary.copy(alpha = if (intenseSplashWaves) 0.26f else 0.15f),
                            CyanAccent.copy(alpha = if (intenseSplashWaves) 0.16f else 0.07f),
                            Color.Transparent
                        ),
                        center = Offset(w * 0.48f, h * 0.86f),
                        radius = w * 0.85f
                    ),
                    radius = w * 0.85f,
                    center = Offset(w * 0.48f, h * 0.86f)
                )

                // Sweeping translucent aurora wave ribbon for splash / hero screens
                if (intenseSplashWaves) {
                    val wavePath = Path().apply {
                        moveTo(0f, h * 0.72f)
                        cubicTo(
                            w * 0.28f, h * 0.64f,
                            w * 0.65f, h * 0.82f,
                            w, h * 0.69f
                        )
                    }
                    drawPath(
                        path = wavePath,
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                CyanAccent.copy(alpha = 0.45f),
                                ElectricBluePrimary.copy(alpha = 0.35f),
                                AuroraPurple.copy(alpha = 0.42f)
                            )
                        ),
                        style = Stroke(width = 6f, cap = StrokeCap.Round)
                    )
                }
            },
        content = content
    )
}

/**
 * Translucent Liquid Glass Card with subtle top specular reflection and cyan-purple glow border.
 */
@Composable
fun AuroraGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 18.dp,
    borderBrush: Brush = CyanBorderGradient,
    fillColors: List<Color> = listOf(GlassCardFillTop, GlassCardFillBottom),
    borderWidth: Dp = 1.15.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val baseModifier = modifier
        .clip(shape)
        .background(Brush.verticalGradient(fillColors))
        .border(width = borderWidth, brush = borderBrush, shape = shape)
        .drawBehind {
            // Subtle glass specular top edge highlight
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = 0.20f),
                        CyanAccent.copy(alpha = 0.24f),
                        Color.Transparent
                    )
                ),
                start = Offset(size.width * 0.08f, 1.5f),
                end = Offset(size.width * 0.92f, 1.5f),
                strokeWidth = 2f
            )
        }
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }

    Column(
        modifier = baseModifier,
        content = content
    )
}

/**
 * Glowing "3.0" capsule pill badge seen in the Splash and Home header.
 */
@Composable
fun AuroraVersionBadge(
    versionText: String = "3.0",
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        ElectricBluePrimary.copy(alpha = 0.45f),
                        CyanAccent.copy(alpha = 0.32f),
                        AuroraPurple.copy(alpha = 0.40f)
                    )
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(listOf(CyanAccent, AuroraPurple)),
                shape = RoundedCornerShape(50)
            )
            .padding(
                horizontal = if (compact) 8.dp else 16.dp,
                vertical = if (compact) 2.dp else 5.dp
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = versionText,
            style = if (compact) MaterialTheme.typography.labelSmall else MaterialTheme.typography.labelLarge,
            color = TextPrimaryWhite,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.6.sp
        )
    }
}

/**
 * Glowing Repair Pro Gear + Wrench emblem drawn smoothly in Canvas matching Screen 1.
 */
@Composable
fun RepairProGearWrenchLogo(
    size: Dp = 84.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val r = this.size.minDimension / 2f

            // Outer cyan radial halo
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        CyanAccent.copy(alpha = 0.48f),
                        ElectricBluePrimary.copy(alpha = 0.18f),
                        Color.Transparent
                    ),
                    center = c,
                    radius = r
                ),
                radius = r,
                center = c
            )

            // Gear teeth ring
            val toothCount = 8
            val gearOuterR = r * 0.72f
            val gearInnerR = r * 0.56f
            for (i in 0 until toothCount) {
                val angleDeg = i * (360f / toothCount)
                rotate(degrees = angleDeg, pivot = c) {
                    drawRoundRect(
                        brush = Brush.verticalGradient(listOf(CyanAccent, ElectricBluePrimary)),
                        topLeft = Offset(c.x - r * 0.13f, c.y - gearOuterR),
                        size = Size(r * 0.26f, r * 0.22f),
                        cornerRadius = CornerRadius(r * 0.06f, r * 0.06f)
                    )
                }
            }

            // Main gear body
            drawCircle(
                brush = Brush.linearGradient(
                    colors = listOf(CyanAccent, ElectricBluePrimary, Color(0xFF0059D6)),
                    start = Offset(c.x - gearInnerR, c.y - gearInnerR),
                    end = Offset(c.x + gearInnerR, c.y + gearInnerR)
                ),
                radius = gearInnerR,
                center = c
            )

            // Inner cutout
            drawCircle(
                color = Color(0xFF071127),
                radius = gearInnerR * 0.62f,
                center = c
            )
        }
        Icon(
            imageVector = Icons.Filled.Build,
            contentDescription = "Repair Pro Logo",
            tint = CyanAccent,
            modifier = Modifier.size(size * 0.36f)
        )
    }
}

/**
 * Smooth animated circular loading indicator matching the bottom of Screen 1.
 */
@Composable
fun AuroraCircularLoader(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    val transition = rememberInfiniteTransition(label = "aurora_loader")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "loader_angle"
    )

    Canvas(modifier = modifier.size(size)) {
        val strokePx = 4.dp.toPx()
        // Subtle ring track
        drawCircle(
            color = CyanAccent.copy(alpha = 0.15f),
            style = Stroke(width = strokePx)
        )
        rotate(degrees = angle) {
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        Color.Transparent,
                        ElectricBluePrimary.copy(alpha = 0.55f),
                        CyanAccent,
                        Color.White
                    )
                ),
                startAngle = 0f,
                sweepAngle = 250f,
                useCenter = false,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }
    }
}

/**
 * Glowing Pill Search Bar with Scanner shortcut matching Reference Screen 2.
 */
@Composable
fun AuroraSearchBar(
    placeholder: String,
    onSearchClick: () -> Unit,
    onScannerClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(26.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xD9101E3B),
                        Color(0xCC162448),
                        Color(0xD91E1B4B)
                    )
                )
            )
            .border(
                width = 1.3.dp,
                brush = Brush.horizontalGradient(
                    listOf(CyanAccent.copy(alpha = 0.78f), ElectricBluePrimary.copy(alpha = 0.65f), AuroraPurple.copy(alpha = 0.78f))
                ),
                shape = shape
            )
            .clickable(onClick = onSearchClick)
            .testTag("home_search_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = "Search",
                tint = TextPrimaryWhite.copy(alpha = 0.9f),
                modifier = Modifier.size(21.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = placeholder,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondarySlate,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(CyanAccent.copy(alpha = 0.28f), ElectricBluePrimary.copy(alpha = 0.35f))
                        )
                    )
                    .border(1.dp, CyanAccent.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
                    .clickable(onClick = onScannerClick)
                    .testTag("home_search_camera_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.QrCodeScanner,
                    contentDescription = "Open Scanner",
                    tint = TextPrimaryWhite,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

/**
 * "Smart Repair Solutions" Hero Promotional Banner matching Reference Screen 2.
 */
@Composable
fun SmartRepairBannerCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(114.dp)
            .clip(shape)
            .background(
                Brush.horizontalGradient(
                    colors = listOf(Color(0xFF09142B), Color(0xFF0E254D), Color(0xFF15295A))
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(
                    listOf(CyanAccent.copy(alpha = 0.55f), ElectricBluePrimary.copy(alpha = 0.75f), AuroraPurple.copy(alpha = 0.55f))
                ),
                shape = shape
            )
            .clickable(onClick = onClick)
            .testTag("smart_repair_banner")
    ) {
        // Right-side realistic 3D AC showcase image blended into the aurora card
        Image(
            painter = painterResource(id = R.drawable.img_cat_ac_1795249926667),
            contentDescription = title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(170.dp)
                .height(114.dp)
        )

        // Smooth dark gradient scrim from left so text has effortless high contrast
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colorStops = arrayOf(
                            0.0f to Color(0xF5071126),
                            0.55f to Color(0xDC0A1936),
                            0.85f to Color(0x660B1E42),
                            1.0f to Color(0x33071126)
                        )
                    )
                )
        )

        // Bottom cyan aurora wave flourish
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val path = Path().apply {
                moveTo(0f, h * 0.85f)
                cubicTo(w * 0.25f, h * 0.65f, w * 0.55f, h * 0.98f, w, h * 0.74f)
            }
            drawPath(
                path = path,
                brush = Brush.horizontalGradient(
                    listOf(CyanAccent.copy(alpha = 0.55f), ElectricBluePrimary.copy(alpha = 0.25f), AuroraPurple.copy(alpha = 0.45f))
                ),
                style = Stroke(width = 3f)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyanAccent.copy(alpha = 0.18f))
                            .border(1.dp, CyanAccent.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "Wizard Ready →",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            // Small glowing Repair Pro badge near AC right corner matching reference
            Box(
                modifier = Modifier
                    .align(Alignment.Bottom)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xB3071127))
                    .border(1.dp, CyanAccent.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Build,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = "Repair Pro",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimaryWhite,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

/**
 * Vertical 3D Appliance Showcase Card matching the 3-in-a-row layout of Screen 2
 * (AC = Cyan Glow, Refrigerator = Electric Blue-Indigo Glow, Washing Machine = Violet-Purple Glow).
 */
@Composable
fun AuroraApplianceShowcaseCard(
    categoryId: String,
    title: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (glowTop, glowBottom, borderColors) = when (categoryId.lowercase()) {
        "ac" -> Triple(
            Color(0xFF0A4D7C),
            Color(0xFF071D3C),
            listOf(CyanAccent.copy(alpha = 0.9f), ElectricBluePrimary.copy(alpha = 0.7f))
        )
        "fridge" -> Triple(
            Color(0xFF1F3888),
            Color(0xFF111842),
            listOf(Color(0xFF5FA8FF).copy(alpha = 0.9f), AuroraPurple.copy(alpha = 0.75f))
        )
        else -> Triple(
            Color(0xFF42218E),
            Color(0xFF19123E),
            listOf(AuroraViolet.copy(alpha = 0.9f), ElectricBluePrimary.copy(alpha = 0.7f))
        )
    }

    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .height(144.dp)
            .clip(shape)
            .background(
                Brush.verticalGradient(colors = listOf(glowTop, glowBottom))
            )
            .border(
                width = 1.4.dp,
                brush = Brush.verticalGradient(borderColors),
                shape = shape
            )
            .clickable(onClick = onClick)
            .testTag("appliance_card_$categoryId")
    ) {
        // Subtle radial light behind the 3D appliance
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = 0.16f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.34f),
                    radius = size.width * 0.55f
                ),
                radius = size.width * 0.55f,
                center = Offset(size.width * 0.5f, size.height * 0.34f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(74.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x66040A19)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = categoryDrawableRes(categoryId)),
                    contentDescription = title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                if (categoryId.equals("ac", ignoreCase = true)) {
                    Icon(
                        imageVector = Icons.Filled.AcUnit,
                        contentDescription = null,
                        tint = CyanAccent.copy(alpha = 0.85f),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(5.dp)
                            .size(13.dp)
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    lineHeight = 14.sp,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                // Small glowing diamond sparkle accent from reference
                Canvas(modifier = Modifier.size(8.dp)) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val path = Path().apply {
                        moveTo(cx, 0f)
                        lineTo(cx + 2f, cy - 2f)
                        lineTo(size.width, cy)
                        lineTo(cx + 2f, cy + 2f)
                        lineTo(cx, size.height)
                        lineTo(cx - 2f, cy + 2f)
                        lineTo(0f, cy)
                        lineTo(cx - 2f, cy - 2f)
                        close()
                    }
                    drawPath(path = path, color = borderColors.first())
                }
            }
        }
    }
}

/**
 * Glass Quick Tool Tile for the 4x2 grid matching Reference Screen 2.
 */
@Composable
fun AuroraQuickToolTile(
    icon: ImageVector,
    label: String,
    accentColor: Color,
    testTagName: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isPdfTile: Boolean = false
) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier = modifier
            .height(86.dp)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xC7132346), Color(0xB3091227))
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(accentColor.copy(alpha = 0.45f), AuroraPurple.copy(alpha = 0.25f))
                ),
                shape = shape
            )
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .testTag(testTagName),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (isPdfTile) {
                AuroraPdfBadgeIcon(size = 34.dp)
            } else {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(accentColor.copy(alpha = 0.16f))
                        .border(0.8.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(11.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label.replace("\n", " "),
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextPrimaryWhite,
                fontSize = 10.5.sp,
                lineHeight = 12.5.sp,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Stylized Red & White "PDF" document icon matching Screens 2 & 5 of the reference image.
 */
@Composable
fun AuroraPdfBadgeIcon(
    size: Dp = 42.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFE6ECF7)))
            )
            .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(size * 0.45f)
                .background(PdfBadgeRed),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "PDF",
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                fontSize = (size.value * 0.25f).sp,
                letterSpacing = 0.4.sp
            )
        }
        Icon(
            imageVector = Icons.Filled.Description,
            contentDescription = "PDF Document",
            tint = PdfBadgeRed,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = size * 0.10f)
                .size(size * 0.40f)
        )
    }
}

/**
 * Glowing circular cyan download action button matching Screens 2 & 5.
 */
@Composable
fun AuroraGlowingDownloadButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    contentDescription: String = "Download PDF"
) {
    Box(
        modifier = modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        CyanAccent.copy(alpha = if (enabled) 0.28f else 0.10f),
                        ElectricBluePrimary.copy(alpha = if (enabled) 0.16f else 0.06f)
                    )
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(listOf(CyanAccent.copy(alpha = 0.85f), ElectricBluePrimary.copy(alpha = 0.5f))),
                shape = CircleShape
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Filled.CloudDownload,
            contentDescription = contentDescription,
            tint = if (enabled) CyanAccent else TextSecondarySlate,
            modifier = Modifier.size(20.dp)
        )
    }
}

/**
 * Aurora Glass Filter Pill matching Community, Technicians, and PDF Manuals screens.
 */
@Composable
fun AuroraPillFilter(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null
) {
    val shape = RoundedCornerShape(50)
    val bgBrush = if (selected) {
        Brush.horizontalGradient(listOf(ElectricBluePrimary, CyanAccent))
    } else {
        Brush.horizontalGradient(listOf(Color(0xB3122040), Color(0x990B152D)))
    }

    Row(
        modifier = modifier
            .height(38.dp)
            .clip(shape)
            .background(bgBrush)
            .border(
                width = 1.dp,
                color = if (selected) CyanAccent else AuroraPurple.copy(alpha = 0.38f),
                shape = shape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (leadingIcon != null) {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = TextPrimaryWhite,
                modifier = Modifier.size(15.dp)
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) TextPrimaryWhite else TextSecondarySlate,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

/**
 * Floating Liquid Glass Bottom Navigation Bar matching Screens 2 & 3 of the reference image:
 * Home | Community | [Center Circular Glowing Scanner] | PDF | Profile
 */
@Composable
fun FloatingLiquidGlassNavBar(
    currentRoute: String,
    homeLabel: String,
    communityLabel: String,
    pdfLabel: String,
    profileLabel: String,
    onNavigateHome: () -> Unit,
    onNavigateCommunity: () -> Unit,
    onOpenScanner: () -> Unit,
    onNavigatePdf: () -> Unit,
    onNavigateProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val barShape = RoundedCornerShape(30.dp)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        // Translucent floating glass capsule
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .border(
                    width = 1.25.dp,
                    brush = Brush.horizontalGradient(
                        listOf(
                            CyanAccent.copy(alpha = 0.65f),
                            ElectricBluePrimary.copy(alpha = 0.45f),
                            AuroraPurple.copy(alpha = 0.65f)
                        )
                    ),
                    shape = barShape
                ),
            shape = barShape,
            color = Color(0xE60B152C),
            tonalElevation = 0.dp,
            shadowElevation = 12.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color(0x4400B4FF),
                                Color(0x330D1B3B),
                                Color(0x447C3AED)
                            )
                        )
                    )
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                LiquidNavTabItem(
                    selected = currentRoute == "home",
                    selectedIcon = Icons.Filled.Home,
                    unselectedIcon = Icons.Outlined.Home,
                    label = homeLabel,
                    testTag = "nav_home",
                    onClick = onNavigateHome,
                    modifier = Modifier.weight(1f)
                )
                LiquidNavTabItem(
                    selected = currentRoute == "community",
                    selectedIcon = Icons.Filled.Forum,
                    unselectedIcon = Icons.Outlined.Forum,
                    label = communityLabel,
                    testTag = "nav_community",
                    onClick = onNavigateCommunity,
                    modifier = Modifier.weight(1f)
                )

                // Spacer reserved for elevated glowing center scanner button
                Spacer(modifier = Modifier.width(68.dp))

                LiquidNavTabItem(
                    selected = currentRoute == "documents",
                    selectedIcon = Icons.Filled.Description,
                    unselectedIcon = Icons.Outlined.Description,
                    label = pdfLabel,
                    testTag = "nav_pdf",
                    onClick = onNavigatePdf,
                    modifier = Modifier.weight(1f)
                )
                LiquidNavTabItem(
                    selected = currentRoute == "settings",
                    selectedIcon = Icons.Filled.Person,
                    unselectedIcon = Icons.Outlined.Person,
                    label = profileLabel,
                    testTag = "nav_settings",
                    onClick = onNavigateProfile,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Elevated Glowing Center Circular Scanner Button
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-10).dp)
                .size(62.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(CyanAccent, ElectricBluePrimary, Color(0xFF0055D4))
                    )
                )
                .border(
                    width = 2.dp,
                    brush = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.85f), CyanAccent)),
                    shape = CircleShape
                )
                .clickable(onClick = onOpenScanner)
                .testTag("nav_scanner_center"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.QrCodeScanner,
                contentDescription = "Error Code Scanner",
                tint = TextPrimaryWhite,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
private fun LiquidNavTabItem(
    selected: Boolean,
    selectedIcon: ImageVector,
    unselectedIcon: ImageVector,
    label: String,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.08f else 1.0f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "nav_scale"
    )
    val contentColor by animateColorAsState(
        targetValue = if (selected) CyanAccent else TextSecondarySlate,
        label = "nav_color"
    )

    Column(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
            .scale(scale)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(if (selected) CyanAccent.copy(alpha = 0.18f) else Color.Transparent)
                .padding(horizontal = 10.dp, vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (selected) selectedIcon else unselectedIcon,
                contentDescription = label,
                tint = contentColor,
                modifier = Modifier.size(21.dp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) TextPrimaryWhite else TextSecondarySlate,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
