package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.CommunityCommentItem
import com.example.data.remote.CommunityPostItem
import com.example.ui.components.AuroraGlassCard
import com.example.ui.components.AuroraPillFilter
import com.example.ui.components.ZoomableImageDialog
import com.example.ui.theme.AuroraPurple
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanBorderGradient
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.PurpleBorderGradient
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun CommunityScreen(
    currentUserId: String,
    posts: List<CommunityPostItem>,
    activeComments: List<CommunityCommentItem>,
    busy: Boolean,
    onBack: () -> Unit,
    onCreatePost: (categoryId: String, title: String, body: String, photos: List<Uri>, onDone: () -> Unit) -> Unit,
    onEditPost: (postId: String, title: String, body: String) -> Unit,
    onDeletePost: (postId: String) -> Unit,
    onToggleLike: (CommunityPostItem) -> Unit,
    onToggleSave: (CommunityPostItem) -> Unit,
    onOpenComments: (String?) -> Unit,
    onAddComment: (postId: String, parentCommentId: String, text: String) -> Unit,
    onReportPost: (postId: String, reason: String) -> Unit
) {
    val context = LocalContext.current
    var showCreateDialog by remember { mutableStateOf(false) }
    var categoryId by remember { mutableStateOf("ac") }
    var filterCat by remember { mutableStateOf("all") }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var selectedPhotos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var zoomPhotoUrl by remember { mutableStateOf<String?>(null) }
    var editingPost by remember { mutableStateOf<CommunityPostItem?>(null) }
    var reportingPost by remember { mutableStateOf<CommunityPostItem?>(null) }
    var activePostForComments by remember { mutableStateOf<CommunityPostItem?>(null) }
    var commentText by remember { mutableStateOf("") }
    var replyToCommentId by remember { mutableStateOf("") }

    // Zero-permission multi-photo picker (Play Policy compliant)
    val multiPhotoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(5)
    ) { uris ->
        selectedPhotos = uris.take(5)
    }

    val visiblePosts = remember(posts, filterCat, currentUserId) {
        posts.filter {
            when (filterCat) {
                "all" -> true
                "saved" -> it.savedByUids.contains(currentUserId)
                else -> it.categoryId.equals(filterCat, ignoreCase = true)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("community_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top Bar matching Reference Screen 3
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("community_back_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryWhite
                        )
                    }
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Groups,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Community",
                            style = MaterialTheme.typography.headlineSmall,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(48.dp))
                }
            }

            // Glass Category Filter Pills: All Posts | AC | Fridge | Washer | Saved
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "all" to "All Posts",
                        "ac" to "AC",
                        "fridge" to "Fridge",
                        "washer" to "Washer",
                        "saved" to "Saved"
                    ).forEach { (id, label) ->
                        AuroraPillFilter(
                            label = label,
                            selected = filterCat == id,
                            onClick = { filterCat = id }
                        )
                    }
                }
            }

            if (visiblePosts.isEmpty()) {
                item {
                    AuroraGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 20.dp
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Forum,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(38.dp)
                            )
                            Text(
                                text = "No community posts yet",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimaryWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Tap the + button to ask a question or share real repair photos with technicians and users.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                            Button(
                                onClick = { showCreateDialog = true },
                                shape = RoundedCornerShape(50),
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Create Post", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                items(visiblePosts, key = { it.id }) { post ->
                    val isMine = post.authorUid == currentUserId
                    val liked = post.likedByUids.contains(currentUserId)
                    val saved = post.savedByUids.contains(currentUserId)
                    var menuExpanded by remember(post.id) { mutableStateOf(false) }

                    AuroraGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("community_post_${post.id}"),
                        cornerRadius = 20.dp,
                        borderBrush = if (post.verifiedTechnician) CyanBorderGradient else PurpleBorderGradient
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Author Header with Avatar, Verified Badge, Role & Menu
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                if (post.verifiedTechnician) listOf(CyanAccent, ElectricBluePrimary)
                                                else listOf(AuroraPurple, ElectricBluePrimary)
                                            )
                                        )
                                        .border(1.5.dp, Color.White.copy(alpha = 0.5f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = post.authorName.trim().take(2).uppercase().ifBlank { "RP" },
                                        style = MaterialTheme.typography.labelLarge,
                                        color = TextPrimaryWhite,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Text(
                                            text = post.authorName.ifBlank { "Repair Pro User" },
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimaryWhite,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (post.verifiedTechnician) {
                                            Icon(
                                                imageVector = Icons.Filled.Verified,
                                                contentDescription = "Verified Technician",
                                                tint = CyanAccent,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(if (post.verifiedTechnician) CyanAccent else SuccessGreen)
                                        )
                                        Text(
                                            text = if (post.verifiedTechnician) {
                                                "Verified Technician • ${post.categoryId.uppercase()}"
                                            } else {
                                                "User • ${post.categoryId.uppercase()}"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondarySlate
                                        )
                                    }
                                }

                                Box {
                                    IconButton(onClick = { menuExpanded = true }) {
                                        Icon(
                                            imageVector = Icons.Filled.MoreHoriz,
                                            contentDescription = "Post options",
                                            tint = TextSecondarySlate
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = menuExpanded,
                                        onDismissRequest = { menuExpanded = false },
                                        containerColor = SecondaryNavySurface
                                    ) {
                                        if (isMine) {
                                            DropdownMenuItem(
                                                text = { Text("Edit Post", color = TextPrimaryWhite) },
                                                leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null, tint = CyanAccent) },
                                                onClick = {
                                                    menuExpanded = false
                                                    editingPost = post
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Delete Post", color = ErrorCrimson) },
                                                leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = ErrorCrimson) },
                                                onClick = {
                                                    menuExpanded = false
                                                    onDeletePost(post.id)
                                                }
                                            )
                                        } else {
                                            DropdownMenuItem(
                                                text = { Text("Report Post", color = WarningAmber) },
                                                leadingIcon = { Icon(Icons.Filled.Flag, contentDescription = null, tint = WarningAmber) },
                                                onClick = {
                                                    menuExpanded = false
                                                    reportingPost = post
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            if (post.title.isNotBlank()) {
                                Text(
                                    text = post.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimaryWhite,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = post.body,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondarySlate
                            )

                            // Multi-photo row matching Reference Screen 3 side-by-side photos
                            if (post.photoUrls.isNotEmpty()) {
                                if (post.photoUrls.size == 1) {
                                    AsyncImage(
                                        model = post.photoUrls.first(),
                                        contentDescription = "Community repair photo",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(175.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .border(1.dp, CyanAccent.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                                            .clickable { zoomPhotoUrl = post.photoUrls.first() }
                                    )
                                } else {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        post.photoUrls.forEach { url ->
                                            AsyncImage(
                                                model = url,
                                                contentDescription = "Community repair photo",
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .width(156.dp)
                                                    .height(126.dp)
                                                    .clip(RoundedCornerShape(14.dp))
                                                    .border(1.dp, CyanAccent.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                                                    .clickable { zoomPhotoUrl = url }
                                            )
                                        }
                                    }
                                }
                            }

                            // Action Row: Like | Comment | Share | Save
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { onToggleLike(post) }
                                            .padding(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                            contentDescription = "Like",
                                            tint = if (liked) ErrorCrimson else TextSecondarySlate,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(
                                            text = "${post.likesCount}",
                                            color = TextPrimaryWhite,
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                activePostForComments = post
                                                onOpenComments(post.id)
                                            }
                                            .padding(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.ChatBubbleOutline,
                                            contentDescription = "Comment",
                                            tint = TextSecondarySlate,
                                            modifier = Modifier.size(19.dp)
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(
                                            text = "${post.commentsCount}",
                                            color = TextPrimaryWhite,
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            val shareText = buildString {
                                                if (post.title.isNotBlank()) append("${post.title}\n\n")
                                                append(post.body)
                                                append("\n\n— Shared from Repair Pro 3.0 Community")
                                            }
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, shareText)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Share Post"))
                                        },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Share,
                                            contentDescription = "Share post",
                                            tint = TextSecondarySlate,
                                            modifier = Modifier.size(19.dp)
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { onToggleSave(post) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = if (saved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                        contentDescription = "Save post",
                                        tint = if (saved) CyanAccent else TextSecondarySlate,
                                        modifier = Modifier.size(21.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Glowing Floating Create Post (+) Button matching Reference Screen 3
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 18.dp, bottom = 96.dp)
                .size(58.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(CyanAccent, ElectricBluePrimary, Color(0xFF0055D4))
                    )
                )
                .border(1.8.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                .clickable { showCreateDialog = true }
                .testTag("community_fab_create_post"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Create Community Post",
                tint = TextPrimaryWhite,
                modifier = Modifier.size(28.dp)
            )
        }
    }

    // Aurora Glass Create Post Dialog (For both Ordinary Users & Technicians)
    if (showCreateDialog) {
        val fieldColors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CyanAccent,
            unfocusedBorderColor = CardBorderSubtle,
            focusedTextColor = TextPrimaryWhite,
            unfocusedTextColor = TextPrimaryWhite,
            focusedContainerColor = DeepCardSurface,
            unfocusedContainerColor = DeepCardSurface
        )
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = SecondaryNavySurface,
            title = {
                Text("Create Community Post", color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                            AuroraPillFilter(
                                label = label,
                                selected = categoryId == id,
                                onClick = { categoryId = id }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it.take(140) },
                        label = { Text("Title (e.g., Inverter PCB error check)") },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("community_post_title")
                    )
                    OutlinedTextField(
                        value = body,
                        onValueChange = { body = it.take(2000) },
                        label = { Text("Describe fault, measurements, or question…") },
                        minLines = 3,
                        maxLines = 5,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("community_post_body")
                    )
                    if (selectedPhotos.isNotEmpty()) {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            selectedPhotos.forEach { uri ->
                                AsyncImage(
                                    model = uri,
                                    contentDescription = "Selected photo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(10.dp))
                                )
                            }
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            multiPhotoPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("community_pick_photos_btn")
                    ) {
                        Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (selectedPhotos.isEmpty()) "Add Photos (up to 5)" else "${selectedPhotos.size} Photo(s) Selected",
                            color = TextPrimaryWhite
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = !busy && body.trim().length >= 3,
                    onClick = {
                        onCreatePost(categoryId, title, body, selectedPhotos) {
                            title = ""
                            body = ""
                            selectedPhotos = emptyList()
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                    modifier = Modifier.testTag("community_publish_btn")
                ) {
                    Text(if (busy) "Posting…" else "Publish", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = TextSecondarySlate)
                }
            }
        )
    }

    // Zoomable Photo Dialog
    if (zoomPhotoUrl != null) {
        ZoomableImageDialog(imageModel = zoomPhotoUrl!!, title = "Community Photo", onDismiss = { zoomPhotoUrl = null })
    }

    // Comments & Nested Replies Dialog
    if (activePostForComments != null) {
        val post = activePostForComments!!
        AlertDialog(
            onDismissRequest = {
                activePostForComments = null
                replyToCommentId = ""
                onOpenComments(null)
            },
            containerColor = SecondaryNavySurface,
            title = { Text("Comments & Replies", color = TextPrimaryWhite) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (activeComments.isEmpty()) {
                        Text("No comments yet. Start the discussion!", color = TextSecondarySlate, style = MaterialTheme.typography.bodySmall)
                    } else {
                        activeComments.forEach { c ->
                            val isReply = c.parentCommentId.isNotBlank()
                            Surface(
                                color = DeepCardSurface,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().padding(start = if (isReply) 16.dp else 0.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(c.authorName, style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                                        if (c.verifiedTechnician) {
                                            Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = SuccessGreen, modifier = Modifier.size(13.dp))
                                        }
                                        Spacer(modifier = Modifier.weight(1f))
                                        IconButton(onClick = { replyToCommentId = c.id }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.AutoMirrored.Filled.Reply, contentDescription = "Reply", tint = TextSecondarySlate, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    Text(c.body, style = MaterialTheme.typography.bodySmall, color = TextPrimaryWhite)
                                }
                            }
                        }
                    }
                    if (replyToCommentId.isNotBlank()) {
                        Text("Replying to comment… (Tap Send)", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = commentText,
                            onValueChange = { commentText = it.take(1000) },
                            placeholder = { Text("Write a comment or reply…") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            if (commentText.isNotBlank()) {
                                onAddComment(post.id, replyToCommentId, commentText)
                                commentText = ""
                                replyToCommentId = ""
                            }
                        }) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send comment", tint = CyanAccent)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    activePostForComments = null
                    replyToCommentId = ""
                    onOpenComments(null)
                }) { Text("Close", color = CyanAccent) }
            }
        )
    }

    // Edit Own Post Dialog
    if (editingPost != null) {
        var editTitle by remember(editingPost) { mutableStateOf(editingPost!!.title) }
        var editBody by remember(editingPost) { mutableStateOf(editingPost!!.body) }
        AlertDialog(
            onDismissRequest = { editingPost = null },
            containerColor = SecondaryNavySurface,
            title = { Text("Edit Post", color = TextPrimaryWhite) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = editTitle, onValueChange = { editTitle = it.take(140) }, label = { Text("Title") })
                    OutlinedTextField(value = editBody, onValueChange = { editBody = it.take(2000) }, label = { Text("Message") }, minLines = 3)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onEditPost(editingPost!!.id, editTitle, editBody)
                    editingPost = null
                }) { Text("Save", color = CyanAccent) }
            },
            dismissButton = {
                TextButton(onClick = { editingPost = null }) { Text("Cancel", color = TextSecondarySlate) }
            }
        )
    }

    // Report Post Dialog
    if (reportingPost != null) {
        var reason by remember { mutableStateOf("Spam or unsafe repair advice") }
        AlertDialog(
            onDismissRequest = { reportingPost = null },
            containerColor = SecondaryNavySurface,
            title = { Text("Report Post", color = WarningAmber) },
            text = {
                OutlinedTextField(value = reason, onValueChange = { reason = it.take(300) }, label = { Text("Reason") })
            },
            confirmButton = {
                TextButton(onClick = {
                    onReportPost(reportingPost!!.id, reason)
                    reportingPost = null
                }) { Text("Submit Report", color = ErrorCrimson) }
            },
            dismissButton = {
                TextButton(onClick = { reportingPost = null }) { Text("Cancel", color = TextSecondarySlate) }
            }
        )
    }
}
