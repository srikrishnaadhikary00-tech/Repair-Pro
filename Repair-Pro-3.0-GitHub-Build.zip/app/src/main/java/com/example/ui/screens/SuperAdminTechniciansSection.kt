package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HideImage
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.TechnicianCloud
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun AdminTechnicianEditorCard(
    initialTech: TechnicianCloud?,
    onCancelEdit: () -> Unit,
    onSave: (technician: TechnicianCloud, photoBytes: ByteArray?, mimeType: String, onDone: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    var fullName by remember(initialTech) { mutableStateOf(initialTech?.fullName.orEmpty()) }
    var mobile by remember(initialTech) { mutableStateOf(initialTech?.mobileNumber.orEmpty()) }
    var address by remember(initialTech) { mutableStateOf(initialTech?.fullAddress.orEmpty()) }
    var state by remember(initialTech) { mutableStateOf(initialTech?.state.orEmpty()) }
    var district by remember(initialTech) { mutableStateOf(initialTech?.district.orEmpty()) }
    var cityArea by remember(initialTech) { mutableStateOf(initialTech?.cityArea.orEmpty()) }
    var pinCode by remember(initialTech) { mutableStateOf(initialTech?.pinCode.orEmpty()) }
    var experience by remember(initialTech) { mutableStateOf(initialTech?.experience.orEmpty()) }
    var active by remember(initialTech) { mutableStateOf((initialTech?.status ?: "ACTIVE") == "ACTIVE") }
    var selectedCategories by remember(initialTech) {
        mutableStateOf(initialTech?.serviceCategories?.toSet()?.ifEmpty { setOf("AC") } ?: setOf("AC"))
    }
    var selectedPhotoUri by remember(initialTech) { mutableStateOf<Uri?>(null) }
    var errorMsg by remember(initialTech) { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> selectedPhotoUri = uri }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CyanAccent,
        unfocusedBorderColor = CardBorderSubtle,
        focusedTextColor = TextPrimaryWhite,
        unfocusedTextColor = TextPrimaryWhite,
        focusedContainerColor = DeepCardSurface,
        unfocusedContainerColor = DeepCardSurface
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SecondaryNavySurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (initialTech == null) "Add New Technician" else "Edit Technician: ${initialTech.fullName}",
                    style = MaterialTheme.typography.titleSmall,
                    color = CyanAccent
                )
                if (initialTech != null) {
                    TextButton(onClick = onCancelEdit) {
                        Text("Cancel", color = TextSecondarySlate)
                    }
                }
            }

            OutlinedButton(
                onClick = {
                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.PhotoLibrary, contentDescription = null, tint = CyanAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (selectedPhotoUri == null) "Select Profile Photo (Optional)" else "Change Profile Photo",
                    color = TextPrimaryWhite
                )
            }

            if (selectedPhotoUri != null || !initialTech?.photoUrl.isNullOrBlank()) {
                AsyncImage(
                    model = selectedPhotoUri ?: initialTech?.photoUrl,
                    contentDescription = "Technician photo preview",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
            }

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it.take(100) },
                label = { Text("Full Name *") },
                singleLine = true,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth().testTag("admin_tech_name")
            )
            OutlinedTextField(
                value = mobile,
                onValueChange = { mobile = it.take(20) },
                label = { Text("Mobile Number *") },
                singleLine = true,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth().testTag("admin_tech_mobile")
            )
            OutlinedTextField(
                value = address,
                onValueChange = { address = it.take(300) },
                label = { Text("Full Address *") },
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth().testTag("admin_tech_address")
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = state,
                    onValueChange = { state = it.take(80) },
                    label = { Text("State *") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.weight(1f).testTag("admin_tech_state")
                )
                OutlinedTextField(
                    value = district,
                    onValueChange = { district = it.take(80) },
                    label = { Text("District *") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.weight(1f).testTag("admin_tech_district")
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = cityArea,
                    onValueChange = { cityArea = it.take(80) },
                    label = { Text("City / Area *") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.weight(1f).testTag("admin_tech_area")
                )
                OutlinedTextField(
                    value = pinCode,
                    onValueChange = { pinCode = it.take(12) },
                    label = { Text("PIN Code *") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.weight(1f).testTag("admin_tech_pin")
                )
            }
            OutlinedTextField(
                value = experience,
                onValueChange = { experience = it.take(80) },
                label = { Text("Experience (Optional, e.g. 6 Years)") },
                singleLine = true,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            Text("Service Categories *", style = MaterialTheme.typography.labelMedium, color = TextSecondarySlate)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("AC", "Refrigerator", "Washing Machine").forEach { cat ->
                    val selected = cat in selectedCategories
                    FilterChip(
                        selected = selected,
                        onClick = {
                            selectedCategories = if (selected && selectedCategories.size > 1) {
                                selectedCategories - cat
                            } else {
                                selectedCategories + cat
                            }
                        },
                        label = { Text(cat) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricBluePrimary,
                            selectedLabelColor = TextPrimaryWhite,
                            containerColor = DeepCardSurface,
                            labelColor = TextSecondarySlate
                        )
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (active) "Status: ACTIVE (Visible in App)" else "Status: INACTIVE (Hidden)",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (active) SuccessGreen else WarningAmber
                )
                Switch(
                    checked = active,
                    onCheckedChange = { active = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = SuccessGreen)
                )
            }

            if (errorMsg != null) {
                Text(errorMsg!!, style = MaterialTheme.typography.bodySmall, color = ErrorCrimson)
            }

            Button(
                onClick = {
                    val cleanName = fullName.trim()
                    val cleanPhone = mobile.trim()
                    val cleanAddr = address.trim()
                    val cleanState = state.trim()
                    val cleanDist = district.trim()
                    val cleanArea = cityArea.trim()
                    val cleanPin = pinCode.trim()
                    when {
                        cleanName.length < 2 -> errorMsg = "Enter a valid technician name."
                        !Regex("^[+0-9\\s\\-()]{6,20}$").matches(cleanPhone) -> errorMsg = "Enter a valid mobile number."
                        cleanAddr.length < 3 || cleanState.isEmpty() || cleanDist.isEmpty() || cleanArea.isEmpty() ->
                            errorMsg = "Address, state, district, and city/area are required."
                        !Regex("^[a-zA-Z0-9\\s\\-]{4,12}$").matches(cleanPin) -> errorMsg = "Enter a valid PIN code."
                        selectedCategories.isEmpty() -> errorMsg = "Select at least one service category."
                        else -> {
                            errorMsg = null
                            val photoPair = selectedPhotoUri?.let { uri ->
                                try {
                                    val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                                    bytes?.let { it to mime }
                                } catch (_: Exception) {
                                    null
                                }
                            }
                            val model = (initialTech ?: TechnicianCloud()).copy(
                                fullName = cleanName,
                                mobileNumber = cleanPhone,
                                fullAddress = cleanAddr,
                                state = cleanState,
                                district = cleanDist,
                                cityArea = cleanArea,
                                pinCode = cleanPin,
                                serviceCategories = selectedCategories.toList(),
                                experience = experience.trim(),
                                status = if (active) "ACTIVE" else "INACTIVE"
                            )
                            onSave(model, photoPair?.first, photoPair?.second ?: "image/jpeg") {
                                if (initialTech == null) {
                                    fullName = ""
                                    mobile = ""
                                    address = ""
                                    state = ""
                                    district = ""
                                    cityArea = ""
                                    pinCode = ""
                                    experience = ""
                                    selectedPhotoUri = null
                                } else {
                                    onCancelEdit()
                                }
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("admin_save_tech_button"),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (initialTech == null) "Save Technician" else "Update Technician", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AdminTechnicianRow(
    technician: TechnicianCloud,
    onEdit: () -> Unit,
    onToggleStatus: () -> Unit,
    onSuspend: (Boolean) -> Unit = {},
    onSoftDelete: (Boolean) -> Unit = {},
    onRemovePhoto: () -> Unit = {},
    onDelete: () -> Unit
) {
    var confirmDelete by remember { mutableStateOf(false) }
    val isActive = technician.status == "ACTIVE" && !technician.isSuspended && !technician.isDeleted

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_tech_row_${technician.id}"),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (isActive) CardBorderSubtle else WarningAmber.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(technician.fullName, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${technician.mobileNumber} • ${technician.cityArea}, ${technician.district}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate
                    )
                    Text(
                        text = technician.serviceCategories.joinToString(" • "),
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanAccent
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onEdit, modifier = Modifier.testTag("admin_tech_edit_${technician.id}")) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit", tint = CyanAccent)
                    }
                    IconButton(onClick = { confirmDelete = true }, modifier = Modifier.testTag("admin_tech_delete_${technician.id}")) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = ErrorCrimson)
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val statusLabel = when {
                    technician.isDeleted -> "SOFT DELETED (Hidden)"
                    technician.isSuspended -> "SUSPENDED (Hidden)"
                    technician.status == "ACTIVE" -> "ACTIVE (Visible in App)"
                    else -> "INACTIVE (Hidden)"
                }
                val statusTint = when {
                    technician.isDeleted || technician.isSuspended -> ErrorCrimson
                    technician.status == "ACTIVE" -> SuccessGreen
                    else -> WarningAmber
                }
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = statusTint,
                    fontWeight = FontWeight.Bold
                )
                OutlinedButton(
                    onClick = onToggleStatus,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("admin_tech_toggle_${technician.id}")
                ) {
                    Text(
                        text = if (technician.status == "ACTIVE") "Deactivate" else "Activate",
                        color = if (technician.status == "ACTIVE") WarningAmber else SuccessGreen,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = { onSuspend(!technician.isSuspended) },
                    border = BorderStroke(1.dp, if (technician.isSuspended) SuccessGreen else ErrorCrimson),
                    modifier = Modifier.testTag("admin_tech_suspend_${technician.id}")
                ) {
                    Icon(Icons.Filled.Block, contentDescription = null, tint = if (technician.isSuspended) SuccessGreen else ErrorCrimson, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (technician.isSuspended) "Unsuspend" else "Suspend", color = if (technician.isSuspended) SuccessGreen else ErrorCrimson, style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = { onSoftDelete(!technician.isDeleted) },
                    border = BorderStroke(1.dp, if (technician.isDeleted) SuccessGreen else WarningAmber),
                    modifier = Modifier.testTag("admin_tech_soft_delete_${technician.id}")
                ) {
                    Icon(
                        if (technician.isDeleted) Icons.Filled.RestoreFromTrash else Icons.Filled.DeleteOutline,
                        contentDescription = null,
                        tint = if (technician.isDeleted) SuccessGreen else WarningAmber,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (technician.isDeleted) "Restore" else "Soft Delete", color = if (technician.isDeleted) SuccessGreen else WarningAmber, style = MaterialTheme.typography.labelSmall)
                }
                if (technician.photoUrl.isNotBlank() || technician.photoStoragePath.isNotBlank()) {
                    OutlinedButton(
                        onClick = onRemovePhoto,
                        border = BorderStroke(1.dp, CyanAccent),
                        modifier = Modifier.testTag("admin_tech_remove_photo_${technician.id}")
                    ) {
                        Icon(Icons.Filled.HideImage, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Remove Photo", color = CyanAccent, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = SecondaryNavySurface,
            title = { Text("Delete Technician?", color = ErrorCrimson) },
            text = {
                Text(
                    text = "Permanently remove ${technician.fullName} (${technician.mobileNumber}) from Repair Pro?",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmDelete = false
                        onDelete()
                    }
                ) {
                    Text("Delete", color = ErrorCrimson)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text("Cancel", color = TextPrimaryWhite)
                }
            }
        )
    }
}
