package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.remote.CatalogEntryCloud
import com.example.data.remote.TechnicalDocumentCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.resolveLocalizedText
import com.example.ui.components.ErrorCodePill
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.OnlineOnlyOfflineGuardCard
import com.example.ui.components.SafetyWarningBanner
import com.example.ui.components.VerificationBadge
import com.example.ui.components.categoryDrawableRes
import com.example.ui.theme.LiquidGlassTheme

@Composable
fun ErrorCodeDetailScreen(
    errorCode: ErrorCodeEntity?,
    language: AppLanguage,
    isSaved: Boolean,
    isOnline: Boolean = true,
    cloudEntry: CatalogEntryCloud? = null,
    relatedDocuments: List<TechnicalDocumentCloud> = emptyList(),
    onRetryConnection: () -> Unit = {},
    onOpenImageViewer: (url: String, title: String) -> Unit = { _, _ -> },
    onOpenPdfViewer: (url: String, title: String) -> Unit = { _, _ -> },
    onBack: () -> Unit,
    onToggleSave: () -> Unit
) {
    val strings = StringsProvider.get(language)
    val context = LocalContext.current
    val palette = LiquidGlassTheme.colors

    if (!isOnline) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LiquidGlassBackBar(
                title = strings.errorCodes,
                onBack = onBack,
                backTestTag = "error_detail_back"
            )
            OnlineOnlyOfflineGuardCard(
                title = strings.noInternetTitle,
                message = strings.noInternetGuidesMessage,
                retryLabel = strings.retry,
                onRetry = onRetryConnection
            )
        }
        return
    }

    if (errorCode == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(strings.noResultsFound, color = palette.textPrimary)
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.primaryAccent,
                        contentColor = palette.onPrimaryAccent
                    )
                ) { Text("Back") }
            }
        }
        return
    }

    val titleRes = resolveLocalizedText(language, errorCode.titleEn, errorCode.titleBn, errorCode.titleHi)
    val meaningRes = resolveLocalizedText(language, errorCode.meaningEn, errorCode.meaningBn, errorCode.meaningHi)
    val symptomsRes = resolveLocalizedText(language, errorCode.symptomsEn, errorCode.symptomsBn, errorCode.symptomsHi)
    val causesRes = resolveLocalizedText(language, errorCode.causesEn, errorCode.causesBn, errorCode.causesHi)
    val diagRes = resolveLocalizedText(language, errorCode.diagnosticsEn, errorCode.diagnosticsBn, errorCode.diagnosticsHi)
    val solRes = resolveLocalizedText(language, errorCode.solutionsEn, errorCode.solutionsBn, errorCode.solutionsHi)
    val safetyRes = resolveLocalizedText(language, errorCode.safetyWarningEn, errorCode.safetyWarningBn, errorCode.safetyWarningHi)
    val anyFallback = titleRes.usedFallback || meaningRes.usedFallback || solRes.usedFallback

    var activeTab by remember { mutableIntStateOf(0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = "${errorCode.brandName} • ${errorCode.code}",
                onBack = onBack,
                backTestTag = "error_detail_back",
                trailing = { ErrorCodePill(code = errorCode.code) }
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = titleRes.text,
                    style = MaterialTheme.typography.headlineSmall,
                    color = palette.primaryAccent,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${errorCode.brandName} • ${errorCode.modelSeries}",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    VerificationBadge(
                        status = errorCode.verificationStatus,
                        verifiedLabel = strings.verifiedBadge,
                        unverifiedLabel = strings.unverifiedBadge
                    )
                }
                if (anyFallback) {
                    FallbackNoticeChip(strings.fallbackTranslationNotice)
                }
            }
        }

        item {
            DetailSectionTabs(
                tabs = listOf(strings.overview, strings.causes, strings.solution, strings.safety),
                activeIndex = activeTab,
                onSelect = { activeTab = it }
            )
        }

        item {
            val adminPhoto = cloudEntry?.photoUrl.orEmpty()
            if (adminPhoto.startsWith("https://")) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .border(1.dp, palette.glassBorder, RoundedCornerShape(22.dp))
                        .clickable { onOpenImageViewer(adminPhoto, titleRes.text) }
                        .testTag("detail_zoomable_photo")
                ) {
                    AsyncImage(
                        model = adminPhoto,
                        contentDescription = titleRes.text,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = palette.glassFillElevated,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, palette.glassBorder),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Filled.ZoomIn, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(16.dp))
                            Text("Tap to zoom", style = MaterialTheme.typography.labelSmall, color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            } else {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    elevated = true,
                    contentPadding = 4.dp
                ) {
                    Image(
                        painter = painterResource(id = categoryDrawableRes(errorCode.categoryId)),
                        contentDescription = titleRes.text,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(145.dp)
                            .clip(RoundedCornerShape(18.dp))
                    )
                }
            }
        }

        when (activeTab) {
            0 -> {
                item { DetailInfoCard(title = strings.overview, body = meaningRes.text) }
                item { DetailInfoCard(title = strings.symptoms, body = symptomsRes.text) }
                item { SafetyWarningBanner(title = strings.safetyWarningTitle, message = safetyRes.text) }
            }
            1 -> {
                item { DetailBulletCard(title = strings.possibleCauses, rawLines = causesRes.text) }
                item { DetailInfoCard(title = strings.symptoms, body = symptomsRes.text) }
            }
            2 -> {
                item { NumberedStepsCard(title = strings.diagnosticSteps, rawSteps = diagRes.text) }
                item { DetailInfoCard(title = strings.solution, body = solRes.text) }
            }
            3 -> {
                item { SafetyWarningBanner(title = strings.safetyWarningTitle, message = safetyRes.text) }
                item {
                    DetailInfoCard(
                        title = strings.sourceLabel,
                        body = "${errorCode.sourceDocumentation}\nStatus: ${errorCode.verificationStatus}"
                    )
                }
            }
        }

        // Admin-attached PDF Manuals & Circuit Diagrams (Online-Only viewing)
        if (cloudEntry?.pdfUrl?.isNotBlank() == true ||
            cloudEntry?.diagramUrl?.isNotBlank() == true ||
            relatedDocuments.isNotEmpty()
        ) {
            item {
                GuideAttachmentsCard(
                    cloudEntry = cloudEntry,
                    relatedDocuments = relatedDocuments,
                    onOpenPdfViewer = onOpenPdfViewer,
                    onOpenImageViewer = onOpenImageViewer
                )
            }
        }

        item {
            Text(
                text = "${strings.sourceLabel}: ${errorCode.sourceDocumentation}",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary
            )
        }

        item {
            SaveAndShareRow(
                isSaved = isSaved,
                saveLabel = if (isSaved) strings.savedLabel else strings.saveGuide,
                shareLabel = strings.shareGuide,
                onToggleSave = onToggleSave,
                onShare = {
                    val shareText = buildString {
                        append("Repair Pro — ${errorCode.brandName} Error Code ${errorCode.code}\n")
                        append("${titleRes.text}\n\n")
                        append("${meaningRes.text}\n\n")
                        append("${strings.solution}:\n${solRes.text}\n\n")
                        append("${strings.safetyWarningTitle}: ${safetyRes.text}")
                    }
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareText)
                    }
                    context.startActivity(Intent.createChooser(intent, strings.shareGuide))
                }
            )
        }
    }
}

@Composable
fun ProblemDetailScreen(
    problem: ProblemGuideEntity?,
    language: AppLanguage,
    isSaved: Boolean,
    isOnline: Boolean = true,
    cloudEntry: CatalogEntryCloud? = null,
    relatedDocuments: List<TechnicalDocumentCloud> = emptyList(),
    onRetryConnection: () -> Unit = {},
    onOpenImageViewer: (url: String, title: String) -> Unit = { _, _ -> },
    onOpenPdfViewer: (url: String, title: String) -> Unit = { _, _ -> },
    onBack: () -> Unit,
    onToggleSave: () -> Unit,
    onSearchRelatedCode: (String) -> Unit
) {
    val strings = StringsProvider.get(language)
    val context = LocalContext.current
    val palette = LiquidGlassTheme.colors

    if (!isOnline) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LiquidGlassBackBar(
                title = strings.solution,
                onBack = onBack,
                backTestTag = "problem_detail_back"
            )
            OnlineOnlyOfflineGuardCard(
                title = strings.noInternetTitle,
                message = strings.noInternetGuidesMessage,
                retryLabel = strings.retry,
                onRetry = onRetryConnection
            )
        }
        return
    }

    if (problem == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(strings.noResultsFound, color = palette.textPrimary)
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.primaryAccent,
                        contentColor = palette.onPrimaryAccent
                    )
                ) { Text("Back") }
            }
        }
        return
    }

    val titleRes = resolveLocalizedText(language, problem.titleEn, problem.titleBn, problem.titleHi)
    val symptomsRes = resolveLocalizedText(language, problem.symptomsEn, problem.symptomsBn, problem.symptomsHi)
    val causesRes = resolveLocalizedText(language, problem.causesEn, problem.causesBn, problem.causesHi)
    val stepsRes = resolveLocalizedText(language, problem.safeStepsEn, problem.safeStepsBn, problem.safeStepsHi)
    val solRes = resolveLocalizedText(language, problem.recommendedSolutionEn, problem.recommendedSolutionBn, problem.recommendedSolutionHi)
    val safetyRes = resolveLocalizedText(language, problem.safetyWarningEn, problem.safetyWarningBn, problem.safetyWarningHi)
    val techRes = resolveLocalizedText(language, problem.technicianCriteriaEn, problem.technicianCriteriaBn, problem.technicianCriteriaHi)
    val anyFallback = titleRes.usedFallback || stepsRes.usedFallback || solRes.usedFallback

    var activeTab by remember { mutableIntStateOf(0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = strings.solution,
                onBack = onBack,
                backTestTag = "problem_detail_back"
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = titleRes.text,
                    style = MaterialTheme.typography.headlineSmall,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                VerificationBadge(
                    status = problem.verificationStatus,
                    verifiedLabel = strings.verifiedBadge,
                    unverifiedLabel = strings.unverifiedBadge
                )
                if (anyFallback) {
                    FallbackNoticeChip(strings.fallbackTranslationNotice)
                }
            }
        }

        item {
            DetailSectionTabs(
                tabs = listOf(strings.overview, strings.causes, strings.solution, strings.safety),
                activeIndex = activeTab,
                onSelect = { activeTab = it }
            )
        }

        item {
            val adminPhoto = cloudEntry?.photoUrl.orEmpty()
            if (adminPhoto.startsWith("https://")) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .border(1.dp, palette.glassBorder, RoundedCornerShape(22.dp))
                        .clickable { onOpenImageViewer(adminPhoto, titleRes.text) }
                ) {
                    AsyncImage(
                        model = adminPhoto,
                        contentDescription = titleRes.text,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = palette.glassFillElevated,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, palette.glassBorder),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Filled.ZoomIn, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(16.dp))
                            Text("Tap to zoom", style = MaterialTheme.typography.labelSmall, color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            } else {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    elevated = true,
                    contentPadding = 4.dp
                ) {
                    Image(
                        painter = painterResource(id = categoryDrawableRes(problem.categoryId)),
                        contentDescription = titleRes.text,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(145.dp)
                            .clip(RoundedCornerShape(18.dp))
                    )
                }
            }
        }

        when (activeTab) {
            0 -> {
                item { DetailBulletCard(title = strings.possibleCauses, rawLines = causesRes.text) }
                item { NumberedStepsCard(title = strings.stepByStepSolution, rawSteps = stepsRes.text) }
                item { SafetyWarningBanner(title = strings.safetyWarningTitle, message = safetyRes.text) }
            }
            1 -> {
                item { DetailBulletCard(title = strings.symptoms, rawLines = symptomsRes.text) }
                item { DetailBulletCard(title = strings.possibleCauses, rawLines = causesRes.text) }
            }
            2 -> {
                item { NumberedStepsCard(title = strings.stepByStepSolution, rawSteps = stepsRes.text) }
                item { DetailInfoCard(title = strings.solution, body = solRes.text) }
                if (problem.requiredTools.isNotBlank()) {
                    item {
                        DetailInfoCard(title = strings.requiredTools, body = problem.requiredTools)
                    }
                }
            }
            3 -> {
                item { SafetyWarningBanner(title = strings.safetyWarningTitle, message = safetyRes.text) }
                item {
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        customContainerColor = palette.warning.copy(alpha = if (palette.isDark) 0.14f else 0.10f),
                        customBorderColor = palette.warning.copy(alpha = 0.45f),
                        contentPadding = 14.dp
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(Icons.Filled.Engineering, contentDescription = null, tint = palette.warning)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(strings.whenToCallTech, style = MaterialTheme.typography.labelLarge, color = palette.warning, fontWeight = FontWeight.Bold)
                                Text(techRes.text, style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                            }
                        }
                    }
                }
            }
        }

        if (cloudEntry?.pdfUrl?.isNotBlank() == true ||
            cloudEntry?.diagramUrl?.isNotBlank() == true ||
            relatedDocuments.isNotEmpty()
        ) {
            item {
                GuideAttachmentsCard(
                    cloudEntry = cloudEntry,
                    relatedDocuments = relatedDocuments,
                    onOpenPdfViewer = onOpenPdfViewer,
                    onOpenImageViewer = onOpenImageViewer
                )
            }
        }

        val codes = problem.relatedErrorCodes.split(",").map { it.trim() }.filter { it.isNotBlank() }
        if (codes.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.relatedErrorCodes, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        codes.forEach { code ->
                            ErrorCodePill(
                                code = code,
                                modifier = Modifier.clickable { onSearchRelatedCode(code) }
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "${strings.sourceLabel}: ${problem.sourceDocumentation}",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary
            )
        }

        item {
            SaveAndShareRow(
                isSaved = isSaved,
                saveLabel = if (isSaved) strings.savedLabel else strings.saveGuide,
                shareLabel = strings.shareGuide,
                onToggleSave = onToggleSave,
                onShare = {
                    val shareText = buildString {
                        append("Repair Pro — ${titleRes.text}\n\n")
                        append("${strings.stepByStepSolution}:\n${stepsRes.text}\n\n")
                        append("${strings.safetyWarningTitle}: ${safetyRes.text}")
                    }
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareText)
                    }
                    context.startActivity(Intent.createChooser(intent, strings.shareGuide))
                }
            )
        }
    }
}

@Composable
private fun GuideAttachmentsCard(
    cloudEntry: CatalogEntryCloud?,
    relatedDocuments: List<TechnicalDocumentCloud>,
    onOpenPdfViewer: (url: String, title: String) -> Unit,
    onOpenImageViewer: (url: String, title: String) -> Unit
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        accentBorder = true,
        contentPadding = 14.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "Online PDFs & Circuit Diagrams",
                style = MaterialTheme.typography.titleSmall,
                color = palette.primaryAccent,
                fontWeight = FontWeight.Bold
            )
            if (cloudEntry != null && cloudEntry.diagramUrl.startsWith("https://")) {
                AttachmentActionRow(
                    title = cloudEntry.diagramTitle.ifBlank { "Circuit / Wiring Diagram" },
                    subtitle = "Tap to open pinch-to-zoom viewer",
                    isPdf = false,
                    onClick = { onOpenImageViewer(cloudEntry.diagramUrl, cloudEntry.diagramTitle.ifBlank { "${cloudEntry.titleEn} — Circuit Diagram" }) }
                )
            }
            if (cloudEntry != null && cloudEntry.pdfUrl.startsWith("https://")) {
                AttachmentActionRow(
                    title = cloudEntry.pdfTitle.ifBlank { "Service Manual PDF" },
                    subtitle = "Online-only PDF viewer",
                    isPdf = true,
                    onClick = { onOpenPdfViewer(cloudEntry.pdfUrl, cloudEntry.pdfTitle.ifBlank { cloudEntry.titleEn }) }
                )
            }
            relatedDocuments.forEach { doc ->
                val isPdf = doc.docType.equals("PDF_MANUAL", ignoreCase = true) || doc.mimeType.contains("pdf", ignoreCase = true)
                AttachmentActionRow(
                    title = doc.title,
                    subtitle = listOf(doc.brandName, doc.modelName, if (isPdf) "PDF Manual" else "Diagram")
                        .filter { it.isNotBlank() }
                        .joinToString(" • "),
                    isPdf = isPdf,
                    onClick = {
                        if (isPdf) onOpenPdfViewer(doc.fileUrl, doc.title)
                        else onOpenImageViewer(doc.fileUrl, doc.title)
                    }
                )
            }
        }
    }
}

@Composable
private fun AttachmentActionRow(
    title: String,
    subtitle: String,
    isPdf: Boolean,
    onClick: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        elevated = true,
        onClick = onClick,
        contentPadding = 12.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = if (isPdf) Icons.Filled.Description else Icons.Filled.Image,
                contentDescription = title,
                tint = if (isPdf) palette.warning else palette.primaryAccent,
                modifier = Modifier.size(22.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = palette.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(
                text = "View",
                style = MaterialTheme.typography.labelMedium,
                color = palette.primaryAccent,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DetailSectionTabs(
    tabs: List<String>,
    activeIndex: Int,
    onSelect: (Int) -> Unit
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        contentPadding = 4.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            tabs.forEachIndexed { idx, label ->
                val selected = idx == activeIndex
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onSelect(idx) }
                        .testTag("detail_tab_$idx"),
                    color = if (selected) palette.primaryAccent else Color.Transparent,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) palette.onPrimaryAccent else palette.textSecondary,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(vertical = 9.dp, horizontal = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun DetailInfoCard(title: String, body: String) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        contentPadding = 14.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Filled.Build, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(16.dp))
                Text(title, style = MaterialTheme.typography.titleSmall, color = palette.primaryAccent, fontWeight = FontWeight.SemiBold)
            }
            Text(body, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
        }
    }
}

@Composable
private fun DetailBulletCard(title: String, rawLines: String) {
    val palette = LiquidGlassTheme.colors
    val lines = rawLines.lines().map { it.trim().removePrefix("•").trim() }.filter { it.isNotBlank() }
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        contentPadding = 14.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = palette.primaryAccent, fontWeight = FontWeight.SemiBold)
            lines.forEach { line ->
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = palette.success,
                        modifier = Modifier
                            .padding(top = 2.dp)
                            .size(16.dp)
                    )
                    Text(line, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
                }
            }
        }
    }
}

@Composable
private fun NumberedStepsCard(title: String, rawSteps: String) {
    val palette = LiquidGlassTheme.colors
    val steps = rawSteps.lines().map { it.trim() }.filter { it.isNotBlank() }
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        contentPadding = 14.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = palette.primaryAccent, fontWeight = FontWeight.SemiBold)
            steps.forEachIndexed { idx, step ->
                val cleanStep = step.replaceFirst(Regex("^[0-9০-৯०-९]+[.)]\\s*"), "")
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(palette.primaryAccent.copy(alpha = if (palette.isDark) 0.24f else 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${idx + 1}",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.primaryAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = cleanStep,
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun FallbackNoticeChip(message: String) {
    val palette = LiquidGlassTheme.colors
    Surface(
        color = palette.warning.copy(alpha = 0.14f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, palette.warning.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = palette.warning, modifier = Modifier.size(14.dp))
            Text(message, style = MaterialTheme.typography.labelSmall, color = palette.warning)
        }
    }
}

@Composable
private fun SaveAndShareRow(
    isSaved: Boolean,
    saveLabel: String,
    shareLabel: String,
    onToggleSave: () -> Unit,
    onShare: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedButton(
            onClick = onToggleSave,
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("detail_save_button"),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, if (isSaved) palette.success else palette.primaryAccent),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = if (isSaved) palette.success.copy(alpha = 0.16f) else palette.glassFillElevated,
                contentColor = if (isSaved) palette.success else palette.primaryAccent
            )
        ) {
            Icon(
                imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                contentDescription = saveLabel,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(saveLabel, style = MaterialTheme.typography.labelLarge)
        }
        Button(
            onClick = onShare,
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("detail_share_button"),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = palette.primaryAccent,
                contentColor = palette.onPrimaryAccent
            )
        ) {
            Icon(Icons.Filled.Share, contentDescription = shareLabel, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(shareLabel, style = MaterialTheme.typography.labelLarge)
        }
    }
}
