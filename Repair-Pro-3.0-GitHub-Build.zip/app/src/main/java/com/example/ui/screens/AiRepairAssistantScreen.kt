package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.remote.AiConfigCloud
import com.example.data.remote.AiDiagnosisResult
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.ui.UiState
import com.example.ui.components.LiquidGlassBackBar
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.LiquidGlassSkeletonCard
import com.example.ui.components.liquidGlassFieldColors
import com.example.ui.components.liquidGlassFilterChipBorder
import com.example.ui.components.liquidGlassFilterChipColors
import com.example.ui.theme.LiquidGlassTheme

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiRepairAssistantScreen(
    language: AppLanguage,
    aiConfig: AiConfigCloud,
    isOnline: Boolean,
    diagnosisState: UiState<AiDiagnosisResult?>,
    onRetryConnection: () -> Unit,
    onSubmitDiagnosis: (
        appliance: String,
        brand: String,
        model: String,
        problem: String,
        errorCode: String,
        outputLangCode: String
    ) -> Unit,
    onClearResult: () -> Unit,
    onBack: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    val strings = StringsProvider.get(language)
    val appliances = remember(aiConfig.aiSupportedAppliances) {
        aiConfig.aiSupportedAppliances.ifEmpty { AiConfigCloud.DEFAULT_APPLIANCES }
    }
    val brandsByAppliance = remember(aiConfig.aiBrandsModelsJson) { aiConfig.brandsMap() }

    var selectedAppliance by remember(appliances) { mutableStateOf(appliances.first()) }
    val suggestedBrands = remember(selectedAppliance, brandsByAppliance) {
        brandsByAppliance[selectedAppliance]
            ?: brandsByAppliance.entries.firstOrNull { selectedAppliance.contains(it.key, ignoreCase = true) }?.value
            ?: listOf("LG", "Samsung", "Voltas", "Daikin", "Whirlpool", "IFB", "Bosch", "Godrej")
    }

    var selectedBrand by remember(selectedAppliance) { mutableStateOf(suggestedBrands.firstOrNull().orEmpty()) }
    var customBrand by remember { mutableStateOf("") }
    var modelNumber by remember { mutableStateOf("") }
    var problemText by remember { mutableStateOf("") }
    var errorCodeText by remember { mutableStateOf("") }
    var outputLang by remember(language) { mutableStateOf(language.code) }
    var localError by remember { mutableStateOf<String?>(null) }

    val supportedLangs = remember(aiConfig.aiSupportedLanguages) {
        aiConfig.aiSupportedLanguages.ifEmpty { listOf("en", "bn", "hi") }
    }

    val fieldColors = liquidGlassFieldColors()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("ai_assistant_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LiquidGlassBackBar(
                title = strings.aiTitle,
                subtitle = strings.aiSubtitle,
                onBack = onBack,
                backTestTag = "ai_back_button",
                trailing = {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = palette.primaryAccent)
                }
            )
        }

        if (!aiConfig.aiEnabled) {
            item {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth().testTag("ai_disabled_banner"),
                    shape = RoundedCornerShape(20.dp),
                    customContainerColor = palette.warning.copy(alpha = if (palette.isDark) 0.14f else 0.10f),
                    customBorderColor = palette.warning.copy(alpha = 0.50f),
                    contentPadding = 16.dp
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "AI Smart Repair Assistant Paused",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.warning,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "This feature is currently turned off by the Super Admin. You can still use offline guides, error code search, troubleshooting wizard, and billing.",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textPrimary
                        )
                    }
                }
            }
            return@LazyColumn
        }

        if (!isOnline) {
            item {
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevated = true,
                    accentBorder = true,
                    contentPadding = 14.dp
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = palette.warning)
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Internet Required for AI", color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                            Text("Connect to mobile data or Wi-Fi to run AI diagnostics.", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        }
                        OutlinedButton(
                            onClick = onRetryConnection,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, palette.primaryAccent)
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = palette.primaryAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.retry, color = palette.primaryAccent)
                        }
                    }
                }
            }
        }

        // Hero Safety Notice Card
        item {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                elevated = true,
                accentBorder = true,
                contentPadding = 0.dp
            ) {
                Column(
                    modifier = Modifier.background(palette.heroGradient).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = palette.warning, modifier = Modifier.size(18.dp))
                        Text(
                            text = "Safety-First Diagnostic Assistant",
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.primaryAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Always unplug mains power before opening panels or touching capacitors. AI separates probable causes from verified measurements and never invents unverified model error codes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary
                    )
                }
            }
        }

        // Step 1: Select Appliance
        item {
            StepCard(stepNumber = "Step 1", title = "Select Appliance") {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    appliances.forEach { app ->
                        val selected = selectedAppliance == app
                        FilterChip(
                            selected = selected,
                            onClick = { selectedAppliance = app },
                            label = { Text(app) },
                            colors = liquidGlassFilterChipColors(),
                            border = liquidGlassFilterChipBorder(selected),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("ai_step1_${app.lowercase().replace(" ", "_")}")
                        )
                    }
                }
            }
        }

        // Step 2: Select Brand / Company
        item {
            StepCard(stepNumber = "Step 2", title = "Select Brand / Company") {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    suggestedBrands.forEach { b ->
                        val selected = selectedBrand == b && customBrand.isBlank()
                        FilterChip(
                            selected = selected,
                            onClick = { selectedBrand = b; customBrand = "" },
                            label = { Text(b) },
                            colors = liquidGlassFilterChipColors(),
                            border = liquidGlassFilterChipBorder(selected),
                            shape = RoundedCornerShape(14.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = customBrand,
                    onValueChange = { customBrand = it.take(50) },
                    label = { Text("Or enter other brand") },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("ai_brand_input")
                )
            }
        }

        // Step 3: Enter Model Number (Optional)
        item {
            StepCard(stepNumber = "Step 3", title = "Enter Model Number (Optional)") {
                OutlinedTextField(
                    value = modelNumber,
                    onValueChange = { modelNumber = it.take(80) },
                    label = { Text("e.g., LS-Q18YNZA, RT28T3022") },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("ai_model_input")
                )
            }
        }

        // Step 4: Describe Problem / Symptoms
        item {
            StepCard(stepNumber = "Step 4", title = "Describe the Problem or Symptoms") {
                OutlinedTextField(
                    value = problemText,
                    onValueChange = { problemText = it.take(1200); localError = null },
                    label = { Text("Describe cooling, noise, leakage, power, or spin behavior...") },
                    minLines = 3,
                    maxLines = 6,
                    colors = fieldColors,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("ai_problem_input")
                )
            }
        }

        // Step 5: Optional Error Code + Skip
        item {
            StepCard(stepNumber = "Step 5", title = "Enter Error Code (Optional / Skip)") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = errorCodeText,
                        onValueChange = { errorCodeText = it.uppercase().take(32) },
                        label = { Text("Error Code (e.g. CH05, E1, OE)") },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("ai_error_code_input")
                    )
                    OutlinedButton(
                        onClick = { errorCodeText = "" },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, palette.glassBorderAccent)
                    ) {
                        Text("Skip", color = palette.textSecondary)
                    }
                }
            }
        }

        // Step 6: Select Output Language
        item {
            StepCard(stepNumber = "Step 6", title = "Select Output Language") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    supportedLangs.forEach { code ->
                        val label = when (code) {
                            "bn" -> "বাংলা (Bengali)"
                            "hi" -> "हिंदी (Hindi)"
                            else -> "English"
                        }
                        val selected = outputLang == code
                        FilterChip(
                            selected = selected,
                            onClick = { outputLang = code },
                            label = { Text(label) },
                            colors = liquidGlassFilterChipColors(),
                            border = liquidGlassFilterChipBorder(selected),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("ai_lang_$code")
                        )
                    }
                }
            }
        }

        if (localError != null) {
            item {
                Text(localError.orEmpty(), color = palette.error, style = MaterialTheme.typography.bodySmall)
            }
        }

        // Step 7: Submit Diagnosis Button
        item {
            val isLoading = diagnosisState is UiState.Loading
            Button(
                onClick = {
                    val effectiveBrand = customBrand.trim().ifBlank { selectedBrand }
                    when {
                        effectiveBrand.isBlank() -> localError = "Please select or enter an appliance brand."
                        problemText.trim().length < 4 -> localError = "Please describe the appliance problem (at least 4 characters)."
                        else -> {
                            localError = null
                            onSubmitDiagnosis(
                                selectedAppliance,
                                effectiveBrand,
                                modelNumber,
                                problemText,
                                errorCodeText,
                                outputLang
                            )
                        }
                    }
                },
                enabled = !isLoading && isOnline,
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.primaryAccent,
                    contentColor = palette.onPrimaryAccent
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("ai_send_button")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = palette.onPrimaryAccent, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Analyzing Appliance Safely...")
                } else {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Get AI Repair Diagnosis", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Output Section
        when (diagnosisState) {
            is UiState.Error -> {
                item {
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        customContainerColor = palette.error.copy(alpha = if (palette.isDark) 0.16f else 0.10f),
                        customBorderColor = palette.error.copy(alpha = 0.50f),
                        contentPadding = 14.dp
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("AI Request Failed", color = palette.error, fontWeight = FontWeight.Bold)
                            Text(diagnosisState.message, color = palette.textPrimary, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            is UiState.Success -> {
                val res = diagnosisState.data
                if (res != null) {
                    item {
                        AiDiagnosisResultCards(
                            result = res,
                            onReset = {
                                problemText = ""
                                errorCodeText = ""
                                onClearResult()
                            }
                        )
                    }
                }
            }
            UiState.Loading -> {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        LiquidGlassSkeletonCard(height = 96.dp)
                        LiquidGlassSkeletonCard(height = 110.dp)
                        LiquidGlassSkeletonCard(height = 96.dp)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun StepCard(
    stepNumber: String,
    title: String,
    content: @Composable () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        elevated = true,
        contentPadding = 14.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = palette.primaryAccent.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp)) {
                    Text(
                        text = stepNumber,
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.primaryAccent,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                Text(title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
            }
            content()
        }
    }
}

@Composable
private fun AiDiagnosisResultCards(
    result: AiDiagnosisResult,
    onReset: () -> Unit
) {
    val palette = LiquidGlassTheme.colors
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.testTag("ai_result_cards")) {
        // Safety Warning Card
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            customContainerColor = palette.error.copy(alpha = if (palette.isDark) 0.16f else 0.10f),
            customBorderColor = palette.error.copy(alpha = 0.55f),
            contentPadding = 14.dp
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Filled.Warning, contentDescription = null, tint = palette.error)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("CRITICAL SAFETY WARNING", color = palette.error, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text(result.safetyWarning, color = palette.textPrimary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        if (result.errorCodeExplanation.isNotBlank()) {
            val statusColor = if (result.errorCodeStatus == "VERIFIED_GENERAL") palette.success else palette.warning
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                elevated = true,
                customBorderColor = statusColor.copy(alpha = 0.5f),
                contentPadding = 14.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (result.errorCodeStatus == "VERIFIED_GENERAL") "Error Code Context" else "Error Code Note (Verify with OEM Manual)",
                        color = statusColor,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(result.errorCodeExplanation, color = palette.textPrimary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        BulletSectionCard("Possible Causes", result.possibleCauses, palette.primaryAccent, Icons.Filled.HelpOutline)
        BulletSectionCard("Components to Inspect", result.componentsToInspect, palette.secondaryAccent, Icons.Filled.Search)
        BulletSectionCard("Diagnostic Checks", result.diagnosticChecks, palette.warning, Icons.Filled.Build)
        BulletSectionCard("Safe Troubleshooting Steps", result.safeTroubleshootingSteps, palette.success, Icons.Filled.CheckCircle)
        BulletSectionCard("Repair Options & Technician Criteria", result.repairOptions, palette.primaryAccent, Icons.Filled.Build)
        BulletSectionCard("Follow-Up Questions to Confirm", result.followUpQuestions, palette.textSecondary, Icons.Filled.HelpOutline)

        if (result.summaryNote.isNotBlank() || result.perUserLimit > 0) {
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                contentPadding = 12.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (result.summaryNote.isNotBlank()) {
                        Text(result.summaryNote, color = palette.textPrimary, style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        text = "Model: ${result.modelUsed} • Daily Quota: ${result.userUsedToday}/${result.perUserLimit}",
                        color = palette.textMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        OutlinedButton(
            onClick = onReset,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, palette.primaryAccent),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Start New AI Diagnosis", color = palette.primaryAccent, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun BulletSectionCard(
    title: String,
    items: List<String>,
    accent: Color,
    icon: ImageVector
) {
    if (items.isEmpty()) return
    val palette = LiquidGlassTheme.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        elevated = true,
        contentPadding = 14.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
                Text(title, style = MaterialTheme.typography.titleSmall, color = accent, fontWeight = FontWeight.Bold)
            }
            items.forEachIndexed { idx, line ->
                Text(
                    text = "${idx + 1}. $line",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textPrimary
                )
            }
        }
    }
}
