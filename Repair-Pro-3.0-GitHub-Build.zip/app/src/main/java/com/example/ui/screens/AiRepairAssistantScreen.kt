package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.remote.AiConfigCloud
import com.example.data.remote.AiDiagnosisResult
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.ui.UiState
import com.example.ui.theme.CardBorderCyan
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.HeroGlowGradient
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMutedSteel
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiRepairAssistantScreen(
    language: AppLanguage,
    aiConfig: AiConfigCloud,
    isOnline: Boolean,
    diagnosisState: UiState<AiDiagnosisResult?>,
    onRetryConnection: () -> Unit,
    onSubmitDiagnosis: (
        appliance: String,
        brand: String,
        model: String,
        problem: String,
        errorCode: String,
        outputLangCode: String
    ) -> Unit,
    onClearResult: () -> Unit,
    onBack: () -> Unit
) {
    val strings = StringsProvider.get(language)
    val appliances = remember(aiConfig.aiSupportedAppliances) {
        aiConfig.aiSupportedAppliances.ifEmpty { AiConfigCloud.DEFAULT_APPLIANCES }
    }
    val brandsByAppliance = remember(aiConfig.aiBrandsModelsJson) { aiConfig.brandsMap() }

    var selectedAppliance by remember(appliances) { mutableStateOf(appliances.first()) }
    val suggestedBrands = remember(selectedAppliance, brandsByAppliance) {
        brandsByAppliance[selectedAppliance]
            ?: brandsByAppliance.entries.firstOrNull { selectedAppliance.contains(it.key, ignoreCase = true) }?.value
            ?: listOf("LG", "Samsung", "Voltas", "Daikin", "Whirlpool", "IFB", "Bosch", "Godrej")
    }

    var selectedBrand by remember(selectedAppliance) { mutableStateOf(suggestedBrands.firstOrNull().orEmpty()) }
    var customBrand by remember { mutableStateOf("") }
    var modelNumber by remember { mutableStateOf("") }
    var problemText by remember { mutableStateOf("") }
    var errorCodeText by remember { mutableStateOf("") }
    var outputLang by remember(language) { mutableStateOf(language.code) }
    var localError by remember { mutableStateOf<String?>(null) }

    val supportedLangs = remember(aiConfig.aiSupportedLanguages) {
        aiConfig.aiSupportedLanguages.ifEmpty { listOf("en", "bn", "hi") }
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CyanAccent,
        unfocusedBorderColor = CardBorderSubtle,
        focusedContainerColor = DeepCardSurface,
        unfocusedContainerColor = DeepCardSurface,
        focusedTextColor = TextPrimaryWhite,
        unfocusedTextColor = TextPrimaryWhite
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBackground)
            .testTag("ai_assistant_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("ai_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.aiTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = strings.aiSubtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondarySlate
                    )
                }
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = CyanAccent)
            }
        }

        if (!aiConfig.aiEnabled) {
            item {
                Surface(
                    color = WarningAmber.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().testTag("ai_disabled_banner")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "AI Smart Repair Assistant Paused",
                            style = MaterialTheme.typography.titleMedium,
                            color = WarningAmber,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "This feature is currently turned off by the Super Admin. You can still use offline guides, error code search, troubleshooting wizard, and billing.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimaryWhite
                        )
                    }
                }
            }
            return@LazyColumn
        }

        if (!isOnline) {
            item {
                Surface(
                    color = ElevatedCardSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CardBorderCyan),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = WarningAmber)
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Internet Required for AI", color = TextPrimaryWhite, fontWeight = FontWeight.SemiBold)
                            Text("Connect to mobile data or Wi-Fi to run AI diagnostics.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        }
                        OutlinedButton(onClick = onRetryConnection) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.retry, color = CyanAccent)
                        }
                    }
                }
            }
        }

        // Hero Safety Notice Card
        item {
            Surface(
                color = ElevatedCardSurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderCyan),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.background(HeroGlowGradient).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(18.dp))
                        Text(
                            text = "Safety-First Diagnostic Assistant",
                            style = MaterialTheme.typography.labelLarge,
                            color = CyanAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Always unplug mains power before opening panels or touching capacitors. AI separates probable causes from verified measurements and never invents unverified model error codes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate
                    )
                }
            }
        }

        // Step 1: Select Appliance
        item {
            StepCard(stepNumber = "Step 1", title = "Select Appliance") {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    appliances.forEach { app ->
                        FilterChip(
                            selected = selectedAppliance == app,
                            onClick = { selectedAppliance = app },
                            label = { Text(app) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricBluePrimary,
                                selectedLabelColor = TextPrimaryWhite,
                                containerColor = DeepCardSurface,
                                labelColor = TextSecondarySlate
                            ),
                            modifier = Modifier.testTag("ai_step1_${app.lowercase().replace(" ", "_")}")
                        )
                    }
                }
            }
        }

        // Step 2: Select Brand / Company
        item {
            StepCard(stepNumber = "Step 2", title = "Select Brand / Company") {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    suggestedBrands.forEach { b ->
                        FilterChip(
                            selected = selectedBrand == b && customBrand.isBlank(),
                            onClick = { selectedBrand = b; customBrand = "" },
                            label = { Text(b) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricBluePrimary,
                                selectedLabelColor = TextPrimaryWhite,
                                containerColor = DeepCardSurface,
                                labelColor = TextSecondarySlate
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = customBrand,
                    onValueChange = { customBrand = it.take(50) },
                    label = { Text("Or enter other brand", color = TextSecondarySlate) },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("ai_brand_input")
                )
            }
        }

        // Step 3: Enter Model Number (Optional)
        item {
            StepCard(stepNumber = "Step 3", title = "Enter Model Number (Optional)") {
                OutlinedTextField(
                    value = modelNumber,
                    onValueChange = { modelNumber = it.take(80) },
                    label = { Text("e.g., LS-Q18YNZA, RT28T3022", color = TextSecondarySlate) },
                    singleLine = true,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("ai_model_input")
                )
            }
        }

        // Step 4: Describe Problem / Symptoms
        item {
            StepCard(stepNumber = "Step 4", title = "Describe the Problem or Symptoms") {
                OutlinedTextField(
                    value = problemText,
                    onValueChange = { problemText = it.take(1200); localError = null },
                    label = { Text("Describe cooling, noise, leakage, power, or spin behavior...", color = TextSecondarySlate) },
                    minLines = 3,
                    maxLines = 6,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("ai_problem_input")
                )
            }
        }

        // Step 5: Optional Error Code + Skip
        item {
            StepCard(stepNumber = "Step 5", title = "Enter Error Code (Optional / Skip)") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = errorCodeText,
                        onValueChange = { errorCodeText = it.uppercase().take(32) },
                        label = { Text("Error Code (e.g. CH05, E1, OE)", color = TextSecondarySlate) },
                        singleLine = true,
                        colors = fieldColors,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("ai_error_code_input")
                    )
                    OutlinedButton(
                        onClick = { errorCodeText = "" },
                        border = BorderStroke(1.dp, CardBorderSubtle)
                    ) {
                        Text("Skip", color = TextSecondarySlate)
                    }
                }
            }
        }

        // Step 6: Select Output Language
        item {
            StepCard(stepNumber = "Step 6", title = "Select Output Language") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    supportedLangs.forEach { code ->
                        val label = when (code) {
                            "bn" -> "বাংলা (Bengali)"
                            "hi" -> "हिंदी (Hindi)"
                            else -> "English"
                        }
                        FilterChip(
                            selected = outputLang == code,
                            onClick = { outputLang = code },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricBluePrimary,
                                selectedLabelColor = TextPrimaryWhite,
                                containerColor = DeepCardSurface,
                                labelColor = TextSecondarySlate
                            ),
                            modifier = Modifier.testTag("ai_lang_$code")
                        )
                    }
                }
            }
        }

        if (localError != null) {
            item {
                Text(localError.orEmpty(), color = ErrorCrimson, style = MaterialTheme.typography.bodySmall)
            }
        }

        // Step 7: Submit Diagnosis Button
        item {
            val isLoading = diagnosisState is UiState.Loading
            Button(
                onClick = {
                    val effectiveBrand = customBrand.trim().ifBlank { selectedBrand }
                    when {
                        effectiveBrand.isBlank() -> localError = "Please select or enter an appliance brand."
                        problemText.trim().length < 4 -> localError = "Please describe the appliance problem (at least 4 characters)."
                        else -> {
                            localError = null
                            onSubmitDiagnosis(
                                selectedAppliance,
                                effectiveBrand,
                                modelNumber,
                                problemText,
                                errorCodeText,
                                outputLang
                            )
                        }
                    }
                },
                enabled = !isLoading && isOnline,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("ai_send_button")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = TextPrimaryWhite, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Analyzing Appliance Safely...")
                } else {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Get AI Repair Diagnosis", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Output Section
        when (diagnosisState) {
            is UiState.Error -> {
                item {
                    Surface(
                        color = ErrorCrimson.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("AI Request Failed", color = ErrorCrimson, fontWeight = FontWeight.Bold)
                            Text(diagnosisState.message, color = TextPrimaryWhite, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            is UiState.Success -> {
                val res = diagnosisState.data
                if (res != null) {
                    item {
                        AiDiagnosisResultCards(
                            result = res,
                            onReset = {
                                problemText = ""
                                errorCodeText = ""
                                onClearResult()
                            }
                        )
                    }
                }
            }
            UiState.Loading -> Unit
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun StepCard(
    stepNumber: String,
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CardBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = ElectricBluePrimary.copy(alpha = 0.22f), shape = RoundedCornerShape(6.dp)) {
                    Text(
                        text = stepNumber,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanAccent,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, fontWeight = FontWeight.SemiBold)
            }
            content()
        }
    }
}

@Composable
private fun AiDiagnosisResultCards(
    result: AiDiagnosisResult,
    onReset: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.testTag("ai_result_cards")) {
        // Safety Warning Card
        Surface(
            color = ErrorCrimson.copy(alpha = 0.14f),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.55f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Filled.Warning, contentDescription = null, tint = ErrorCrimson)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("CRITICAL SAFETY WARNING", color = ErrorCrimson, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text(result.safetyWarning, color = TextPrimaryWhite, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        if (result.errorCodeExplanation.isNotBlank()) {
            val statusColor = if (result.errorCodeStatus == "VERIFIED_GENERAL") SuccessGreen else WarningAmber
            Surface(
                color = ElevatedCardSurface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, statusColor.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (result.errorCodeStatus == "VERIFIED_GENERAL") "Error Code Context" else "Error Code Note (Verify with OEM Manual)",
                        color = statusColor,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(result.errorCodeExplanation, color = TextPrimaryWhite, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        BulletSectionCard("Possible Causes", result.possibleCauses, CyanAccent, Icons.Filled.HelpOutline)
        BulletSectionCard("Components to Inspect", result.componentsToInspect, ElectricBluePrimary, Icons.Filled.Search)
        BulletSectionCard("Diagnostic Checks", result.diagnosticChecks, WarningAmber, Icons.Filled.Build)
        BulletSectionCard("Safe Troubleshooting Steps", result.safeTroubleshootingSteps, SuccessGreen, Icons.Filled.CheckCircle)
        BulletSectionCard("Repair Options & Technician Criteria", result.repairOptions, CyanAccent, Icons.Filled.Build)
        BulletSectionCard("Follow-Up Questions to Confirm", result.followUpQuestions, TextSecondarySlate, Icons.Filled.HelpOutline)

        if (result.summaryNote.isNotBlank() || result.perUserLimit > 0) {
            Surface(
                color = DeepCardSurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CardBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (result.summaryNote.isNotBlank()) {
                        Text(result.summaryNote, color = TextPrimaryWhite, style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        text = "Model: ${result.modelUsed} • Daily Quota: ${result.userUsedToday}/${result.perUserLimit}",
                        color = TextMutedSteel,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        OutlinedButton(
            onClick = onReset,
            border = BorderStroke(1.dp, CyanAccent),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Start New AI Diagnosis", color = CyanAccent)
        }
    }
}

@Composable
private fun BulletSectionCard(
    title: String,
    items: List<String>,
    accent: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    if (items.isEmpty()) return
    Surface(
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
                Text(title, style = MaterialTheme.typography.titleSmall, color = accent, fontWeight = FontWeight.Bold)
            }
            items.forEachIndexed { idx, line ->
                Text(
                    text = "${idx + 1}. $line",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimaryWhite
                )
            }
        }
    }
}
