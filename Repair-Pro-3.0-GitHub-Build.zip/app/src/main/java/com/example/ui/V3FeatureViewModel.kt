package com.example.ui

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.RepairRepository
import com.example.data.local.DownloadedDocumentEntity
import com.example.data.remote.BackendConnectionStatus
import com.example.data.remote.CommunityCommentItem
import com.example.data.remote.CommunityPostItem
import com.example.data.remote.PushNotificationItem
import com.example.data.remote.RepairDocumentItem
import com.example.data.remote.StorageProviderItem
import com.example.data.remote.SupabaseApiClient
import com.example.data.remote.SystemErrorLogItem
import com.example.data.remote.TechnicianProfileItem
import com.example.data.remote.UserProfileCloud
import com.example.notifications.NotificationHelper
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalCoroutinesApi::class)
class V3FeatureViewModel(
    private val repository: RepairRepository,
    private val appContext: Context,
    val currentUserId: String,
    val userDisplayName: String,
    val userEmail: String,
    isAdminFlow: StateFlow<Boolean>
) : ViewModel() {

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _connectionStatus = MutableStateFlow(BackendConnectionStatus())
    val connectionStatus: StateFlow<BackendConnectionStatus> = _connectionStatus.asStateFlow()

    private val _fcmToken = MutableStateFlow<String?>(null)
    val fcmToken: StateFlow<String?> = _fcmToken.asStateFlow()

    private val _activeCommentsPostId = MutableStateFlow<String?>(null)

    val communityPosts: StateFlow<List<CommunityPostItem>> = safeFlow(
        repository.v3.observeApprovedCommunityPosts(currentUserId),
        emptyList(),
        "community_posts"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val activePostComments: StateFlow<List<CommunityCommentItem>> = _activeCommentsPostId
        .flatMapLatest { postId ->
            if (postId.isNullOrBlank()) flowOf(emptyList())
            else safeFlow(repository.v3.observeComments(postId, currentUserId), emptyList(), "comments")
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val publicTechnicians: StateFlow<List<TechnicianProfileItem>> = safeFlow(
        repository.v3.observePublicTechnicians(currentUserId),
        emptyList(),
        "public_technicians"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val publishedDocuments: StateFlow<List<RepairDocumentItem>> = safeFlow(
        repository.v3.observePublishedDocuments(currentUserId),
        emptyList(),
        "repair_documents"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val downloadedDocuments: StateFlow<List<DownloadedDocumentEntity>> = repository.downloadedDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val notifications: StateFlow<List<PushNotificationItem>> = safeFlow(
        repository.v3.observeNotifications(currentUserId),
        emptyList(),
        "notifications"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Admin-only streams
    val adminCommunityPosts: StateFlow<List<CommunityPostItem>> = isAdminFlow
        .flatMapLatest { admin ->
            if (admin) safeFlow(repository.v3.observeAllCommunityPostsForAdmin(currentUserId), emptyList(), "admin_posts")
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminTechnicians: StateFlow<List<TechnicianProfileItem>> = isAdminFlow
        .flatMapLatest { admin ->
            if (admin) safeFlow(repository.v3.observeAllTechniciansForAdmin(currentUserId), emptyList(), "admin_techs")
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminDocuments: StateFlow<List<RepairDocumentItem>> = isAdminFlow
        .flatMapLatest { admin ->
            if (admin) safeFlow(repository.v3.observeAllDocumentsForAdmin(currentUserId), emptyList(), "admin_docs")
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _supabaseStorageProviders = MutableStateFlow<List<StorageProviderItem>>(emptyList())
    private val _supabaseErrorLogs = MutableStateFlow<List<SystemErrorLogItem>>(emptyList())

    val adminStorageProviders: StateFlow<List<StorageProviderItem>> = isAdminFlow
        .flatMapLatest { admin ->
            if (!admin) flowOf(emptyList()) else _supabaseStorageProviders
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminUsers: StateFlow<List<UserProfileCloud>> = isAdminFlow
        .flatMapLatest { admin ->
            if (admin) safeFlow(repository.v3.observeUsersForAdmin(currentUserId), emptyList(), "admin_users")
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminErrorLogs: StateFlow<List<SystemErrorLogItem>> = isAdminFlow
        .flatMapLatest { admin ->
            if (!admin) flowOf(emptyList())
            else combine(
                safeFlow(repository.v3.observeErrorLogsForAdmin(currentUserId), emptyList(), "error_logs"),
                _supabaseErrorLogs
            ) { firestoreLogs, supabaseLogs ->
                (supabaseLogs + firestoreLogs).distinctBy { it.id }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    init {
        refreshConnectionHealth()
        syncFcmToken()
        viewModelScope.launch {
            isAdminFlow.collect { admin ->
                if (admin && SupabaseApiClient.isConfigured()) {
                    refreshStorageOverview()
                }
            }
        }
    }

    fun clearStatus() {
        _statusMessage.value = null
    }

    fun refreshConnectionHealth() {
        viewModelScope.launch {
            _connectionStatus.value = SupabaseApiClient.checkHealth()
            if (_connectionStatus.value.supabaseReachable) {
                refreshStorageOverview()
            }
        }
    }

    fun refreshStorageOverview() {
        if (!SupabaseApiClient.isConfigured()) return
        viewModelScope.launch {
            SupabaseApiClient.fetchStorageOverview().onSuccess { overview ->
                _supabaseStorageProviders.value = overview.providers
                _supabaseErrorLogs.value = overview.errorLogs
                if (overview.providers.isNotEmpty()) {
                    repository.v3.adminMirrorStorageProviders(overview.providers)
                }
            }
        }
    }

    fun syncFcmToken() {
        viewModelScope.launch {
            NotificationHelper.ensureNotificationChannel(appContext)
            _fcmToken.value = NotificationHelper.syncCurrentFcmToken(appContext)
        }
    }

    fun openCommentsForPost(postId: String?) {
        _activeCommentsPostId.value = postId
    }

    private fun extensionForMime(mime: String, fallbackExt: String): String {
        return when (mime.lowercase()) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/jpeg", "image/jpg" -> "jpg"
            "application/pdf" -> "pdf"
            else -> fallbackExt
        }
    }

    private suspend fun uploadUriToSupabase(
        uri: Uri,
        bucket: String,
        fallbackExt: String,
        entityType: String? = null
    ): Result<SupabaseApiClient.UploadedFileResult> =
        withContext(Dispatchers.IO) {
            try {
                val cr = appContext.contentResolver
                val mime = cr.getType(uri) ?: if (fallbackExt == "pdf") "application/pdf" else "image/jpeg"
                val ext = extensionForMime(mime, fallbackExt)
                val bytes = cr.openInputStream(uri)?.use { it.readBytes() }
                    ?: return@withContext Result.failure(IllegalStateException("Unable to read selected file."))
                val filename = "upload_${System.currentTimeMillis()}.$ext"
                SupabaseApiClient.uploadFileWithMetadata(bucket, filename, mime, bytes, entityType = entityType)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    // ---------------- COMMUNITY ACTIONS ----------------
    fun createCommunityPost(
        categoryId: String,
        title: String,
        body: String,
        selectedPhotoUris: List<Uri>,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val uploadedUrls = mutableListOf<String>()
                var uploadWarning: String? = null
                if (selectedPhotoUris.isNotEmpty() && !SupabaseApiClient.isConfigured()) {
                    _statusMessage.value = "Photo upload requires SUPABASE_ANON_KEY in AI Studio Secrets."
                    return@launch
                }
                for (uri in selectedPhotoUris.take(5)) {
                    val up = uploadUriToSupabase(uri, "community-photos", "jpg", entityType = "community_post")
                    if (up.isSuccess) {
                        val resObj = up.getOrThrow()
                        uploadedUrls.add(resObj.publicUrl)
                        if (resObj.failoverUsed) {
                            uploadWarning = "Uploaded via backup provider (${resObj.providerName})."
                        }
                    } else {
                        _statusMessage.value = "Photo upload failed: ${up.exceptionOrNull()?.localizedMessage}"
                        return@launch
                    }
                }
                val isVerifiedTech = publicTechnicians.value.any { it.userId == currentUserId && it.verified }
                val res = repository.v3.createCommunityPost(
                    authorName = userDisplayName,
                    categoryId = categoryId,
                    title = title,
                    body = body,
                    photoUrls = uploadedUrls,
                    verifiedTechnician = isVerifiedTech
                )
                if (res.isSuccess) {
                    _statusMessage.value = uploadWarning ?: "Community post published!"
                    onDone()
                } else {
                    _statusMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to publish post"
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun editOwnPost(postId: String, title: String, body: String) {
        viewModelScope.launch {
            val res = repository.v3.editCommunityPost(postId, title, body)
            _statusMessage.value = if (res.isSuccess) "Post updated" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun deletePost(postId: String) {
        viewModelScope.launch {
            val res = repository.v3.deleteCommunityPost(postId)
            _statusMessage.value = if (res.isSuccess) "Post deleted" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun toggleLike(post: CommunityPostItem) {
        viewModelScope.launch { repository.v3.toggleLikePost(post) }
    }

    fun toggleSavePost(post: CommunityPostItem) {
        viewModelScope.launch {
            val res = repository.v3.toggleSavePost(post)
            if (res.isSuccess) _statusMessage.value = "Updated saved community posts"
        }
    }

    fun addComment(postId: String, parentCommentId: String, text: String) {
        viewModelScope.launch {
            val isVerifiedTech = publicTechnicians.value.any { it.userId == currentUserId && it.verified }
            val res = repository.v3.addComment(postId, parentCommentId, userDisplayName, isVerifiedTech, text)
            if (res.isFailure) _statusMessage.value = res.exceptionOrNull()?.localizedMessage
        }
    }

    fun reportPost(postId: String, reason: String) {
        viewModelScope.launch {
            val res = repository.v3.reportCommunityPost(postId, reason)
            _statusMessage.value = if (res.isSuccess) "Post reported to moderators" else res.exceptionOrNull()?.localizedMessage
        }
    }

    // ---------------- TECHNICIAN ACTIONS ----------------
    fun registerAsTechnician(
        fullName: String,
        publicPhone: String,
        serviceDetails: String,
        experienceYears: Long,
        serviceLocation: String,
        city: String,
        categories: List<String>,
        profilePhotoUri: Uri?,
        verificationDocUri: Uri?,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            _busy.value = true
            try {
                var profileUrl = ""
                var privateDocUrl = ""
                if ((profilePhotoUri != null || verificationDocUri != null) && !SupabaseApiClient.isConfigured()) {
                    _statusMessage.value = "Photo & ID upload requires SUPABASE_ANON_KEY in AI Studio Secrets."
                    return@launch
                }
                if (profilePhotoUri != null) {
                    val photoUp = uploadUriToSupabase(profilePhotoUri, "technician-photos", "jpg", entityType = "technician_profile")
                    if (photoUp.isSuccess) profileUrl = photoUp.getOrThrow().publicUrl
                    else {
                        _statusMessage.value = "Profile photo upload failed: ${photoUp.exceptionOrNull()?.localizedMessage}"
                        return@launch
                    }
                }
                if (verificationDocUri != null) {
                    val docUp = uploadUriToSupabase(verificationDocUri, "verification-documents", "jpg", entityType = "technician_verification")
                    if (docUp.isSuccess) privateDocUrl = docUp.getOrThrow().publicUrl
                    else {
                        _statusMessage.value = "Verification ID upload failed: ${docUp.exceptionOrNull()?.localizedMessage}"
                        return@launch
                    }
                }
                val res = repository.v3.registerTechnician(
                    fullName = fullName,
                    profilePhotoUrl = profileUrl,
                    publicPhone = publicPhone,
                    serviceDetails = serviceDetails,
                    experienceYears = experienceYears,
                    serviceLocation = serviceLocation,
                    city = city,
                    categories = categories,
                    privateVerificationDocUrl = privateDocUrl
                )
                if (res.isSuccess) {
                    _statusMessage.value = "Technician application submitted for Admin verification."
                    onDone()
                } else {
                    _statusMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Submission failed"
                }
            } finally {
                _busy.value = false
            }
        }
    }

    // ---------------- PDF & CIRCUIT DIAGRAM OFFLINE DOWNLOAD ----------------
    fun downloadDocumentOffline(doc: RepairDocumentItem) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val res = repository.downloadDocumentForOffline(doc)
                _statusMessage.value = if (res.isSuccess) {
                    "Downloaded '${doc.title}' for offline viewing!"
                } else {
                    "Download failed: ${res.exceptionOrNull()?.localizedMessage}"
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun removeOfflineDocument(entity: DownloadedDocumentEntity) {
        viewModelScope.launch {
            repository.deleteOfflineDocument(entity.docId, entity.localFilePath)
            _statusMessage.value = "Removed offline copy of '${entity.title}'"
        }
    }

    // ---------------- ADMIN v3.0 MUTATIONS ----------------
    fun adminModeratePost(postId: String, status: String, reason: String = "") {
        viewModelScope.launch {
            val res = repository.v3.adminModeratePost(postId, status, reason)
            _statusMessage.value = if (res.isSuccess) "Post marked $status" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminManageTechnician(
        techId: String,
        approvalStatus: String? = null,
        verified: Boolean? = null,
        active: Boolean? = null,
        blocked: Boolean? = null
    ) {
        viewModelScope.launch {
            val res = repository.v3.adminManageTechnician(techId, approvalStatus, verified, active, blocked)
            _statusMessage.value = if (res.isSuccess) "Technician status updated" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminSaveDocument(docItem: RepairDocumentItem, localFileUri: Uri?, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            _busy.value = true
            try {
                var updatedItem = docItem
                if (localFileUri != null) {
                    if (!SupabaseApiClient.isConfigured()) {
                        _statusMessage.value = "File upload requires SUPABASE_ANON_KEY in AI Studio Secrets."
                        return@launch
                    }
                    val bucket = if (docItem.docType == "CIRCUIT_DIAGRAM") "circuit-diagrams" else "repair-pdfs"
                    val ext = if (docItem.docType == "CIRCUIT_DIAGRAM") "jpg" else "pdf"
                    val up = uploadUriToSupabase(localFileUri, bucket, ext, entityType = "repair_document")
                    if (up.isSuccess) {
                        val uploaded = up.getOrThrow()
                        updatedItem = docItem.copy(
                            fileUrl = uploaded.publicUrl,
                            mimeType = uploaded.mimeType.ifBlank { docItem.mimeType },
                            fileSizeBytes = uploaded.sizeBytes,
                            storageProviderId = uploaded.providerId
                        )
                        refreshStorageOverview()
                    } else {
                        _statusMessage.value = "Storage upload failed: ${up.exceptionOrNull()?.localizedMessage}"
                        return@launch
                    }
                }
                val res = repository.v3.adminSaveDocument(updatedItem)
                if (res.isSuccess) {
                    _statusMessage.value = "Document '${docItem.title}' saved!"
                    onDone()
                } else {
                    _statusMessage.value = res.exceptionOrNull()?.localizedMessage
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun adminDeleteDocument(docId: String) {
        viewModelScope.launch {
            val res = repository.v3.adminDeleteDocument(docId)
            _statusMessage.value = if (res.isSuccess) "Document deleted" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminSendPushNotification(title: String, body: String, targetType: String, targetUids: List<String>) {
        viewModelScope.launch {
            _busy.value = true
            try {
                // Session-safe: failures only update statusMessage, NEVER sign out admin!
                val res = repository.v3.adminSendPushNotification(title, body, targetType, targetUids)
                _statusMessage.value = res.getOrElse { it.localizedMessage ?: "Push notification error (session kept active)" }
            } finally {
                _busy.value = false
            }
        }
    }

    fun adminInspectVerificationDoc(techId: String, onUrlReady: (String) -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val refRes = repository.v3.adminGetPrivateVerificationDocRef(techId)
                if (refRes.isFailure) {
                    _statusMessage.value = refRes.exceptionOrNull()?.localizedMessage ?: "No private verification document found."
                    return@launch
                }
                val rawUrl = refRes.getOrThrow()
                if (rawUrl.startsWith("private://")) {
                    if (!SupabaseApiClient.isConfigured()) {
                        _statusMessage.value = "Inspecting private verification docs requires SUPABASE_ANON_KEY in Secrets."
                        return@launch
                    }
                    val signedRes = SupabaseApiClient.getAdminVerificationSignedUrl(rawUrl)
                    if (signedRes.isSuccess) {
                        val signedUrl = signedRes.getOrThrow()
                        if (signedUrl.startsWith("https://")) {
                            onUrlReady(signedUrl)
                        } else {
                            _statusMessage.value = "Signed URL returned invalid scheme."
                        }
                    } else {
                        _statusMessage.value = "Unable to mint signed URL: ${signedRes.exceptionOrNull()?.localizedMessage}"
                    }
                } else if (rawUrl.startsWith("https://")) {
                    onUrlReady(rawUrl)
                } else {
                    _statusMessage.value = "Unsupported verification document reference."
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun adminSaveStorageProvider(provider: StorageProviderItem) {
        viewModelScope.launch {
            _busy.value = true
            try {
                if (!SupabaseApiClient.isConfigured()) {
                    _statusMessage.value = "Storage provider registration requires SUPABASE_ANON_KEY in AI Studio Secrets (Firestore-only fallback removed)."
                    return@launch
                }
                val edgeRes = SupabaseApiClient.upsertStorageProvider(provider)
                if (edgeRes.isSuccess) {
                    val list = edgeRes.getOrThrow()
                    _supabaseStorageProviders.value = list
                    repository.v3.adminMirrorStorageProviders(list)
                    _statusMessage.value = "Storage provider '${provider.name}' synced to authoritative Supabase registry"
                } else {
                    _statusMessage.value = "Supabase sync failed: ${edgeRes.exceptionOrNull()?.localizedMessage}"
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun adminStorageAction(provider: StorageProviderItem, action: String) {
        viewModelScope.launch {
            _busy.value = true
            try {
                if (!SupabaseApiClient.isConfigured()) {
                    _statusMessage.value = "Storage action ($action) requires SUPABASE_ANON_KEY in AI Studio Secrets."
                    return@launch
                }
                val edgeRes = SupabaseApiClient.performStorageProviderAction(provider.id, action)
                if (edgeRes.isSuccess) {
                    val (json, providers) = edgeRes.getOrThrow()
                    _supabaseStorageProviders.value = providers
                    repository.v3.adminMirrorStorageProviders(providers)
                    _statusMessage.value = if (action.equals("TEST", ignoreCase = true)) {
                        val st = json.optString("status", "CONNECTED")
                        val msg = json.optString("message", "OK")
                        "${provider.name}: $st — $msg"
                    } else {
                        "${provider.name}: $action applied on Supabase registry"
                    }
                } else {
                    _statusMessage.value = "${provider.name} ($action) failed: ${edgeRes.exceptionOrNull()?.localizedMessage}"
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun adminMigrateStorageFiles(sourceProvider: StorageProviderItem, targetProviderId: String) {
        viewModelScope.launch {
            _busy.value = true
            try {
                if (!SupabaseApiClient.isConfigured()) {
                    _statusMessage.value = "File migration requires SUPABASE_ANON_KEY in AI Studio Secrets."
                    return@launch
                }
                val edgeRes = SupabaseApiClient.performStorageProviderAction(
                    providerId = sourceProvider.id,
                    action = "MIGRATE",
                    targetProviderId = targetProviderId
                )
                if (edgeRes.isSuccess) {
                    val (json, providers) = edgeRes.getOrThrow()
                    _supabaseStorageProviders.value = providers
                    repository.v3.adminMirrorStorageProviders(providers)
                    val migratedCount = json.optInt("migratedCount", 0)
                    val failedCount = json.optInt("failedCount", 0)
                    val verified = json.optBoolean("checksumVerified", false)
                    val remaining = json.optInt("remainingOnSource", 0)
                    _statusMessage.value = "Migrated $migratedCount file(s)${if (verified) " (SHA-256 verified)" else ""}${if (failedCount > 0) ", $failedCount failed" else ""}. Remaining on ${sourceProvider.name}: $remaining."
                } else {
                    _statusMessage.value = "Migration failed: ${edgeRes.exceptionOrNull()?.localizedMessage}"
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun adminTestStorageProvider(provider: StorageProviderItem) {
        adminStorageAction(provider, "TEST")
    }

    fun adminSetUserBlocked(targetUid: String, blocked: Boolean) {
        viewModelScope.launch {
            val res = repository.v3.adminSetUserBlocked(targetUid, blocked)
            _statusMessage.value = if (res.isSuccess) {
                if (blocked) "User blocked" else "User unblocked"
            } else res.exceptionOrNull()?.localizedMessage
        }
    }

    private fun <T> safeFlow(source: Flow<T>, fallback: T, label: String): Flow<T> {
        return source.catch { err ->
            val fe = generateSequence(err) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
            if (fe == null && err is CancellationException) throw err
            Log.w("V3FeatureVM", "Stream error ($label): ${(fe ?: err).message}")
            emit(fallback)
        }
    }
}
