package com.example.billing

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.local.InvoiceEntity
import com.example.data.remote.BillingConfigCloud
import com.example.data.remote.BillingDomainHelper

object ManualReminderLauncher {
    fun buildInvoiceReminderMessage(
        invoice: InvoiceEntity,
        billingConfig: BillingConfigCloud,
        languageCode: String
    ): String {
        val applianceSummary = listOf(invoice.applianceBrand, invoice.applianceCategory)
            .filter { it.isNotBlank() }
            .joinToString(" ")
            .ifBlank { "Appliance" }
        return BillingDomainHelper.buildReminderMessage(
            languageCode = languageCode,
            billingConfig = billingConfig,
            customerName = invoice.customerName,
            invoiceNumber = invoice.invoiceNumber,
            applianceSummary = applianceSummary,
            totalBill = invoice.totalBill,
            amountReceived = invoice.amountReceived,
            remainingBalance = invoice.remainingBalance,
            dueDate = invoice.paymentDueDate
        )
    }

    fun launchWhatsAppReminder(
        context: Context,
        invoice: InvoiceEntity,
        billingConfig: BillingConfigCloud,
        languageCode: String
    ): Result<Unit> {
        if (!BillingDomainHelper.canSendReminder(
                paymentStatus = invoice.paymentStatus,
                remainingBalance = invoice.remainingBalance,
                featureEnabled = billingConfig.whatsappReminderEnabled
            )
        ) {
            return Result.failure(IllegalStateException("WhatsApp reminder is only available for unpaid or partially paid invoices when enabled."))
        }
        val message = buildInvoiceReminderMessage(invoice, billingConfig, languageCode)
        val waUri = Uri.parse(BillingDomainHelper.buildWhatsAppUriString(invoice.customerMobile, message))
        val pm = context.packageManager

        val whatsappPkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pkg ->
            runCatching { pm.getPackageInfo(pkg, 0) }.isSuccess
        }

        val intent = Intent(Intent.ACTION_VIEW, waUri).apply {
            if (whatsappPkg != null) setPackage(whatsappPkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(pm) != null) {
            runCatching { context.startActivity(intent) }
        } else {
            // Fallback without package pin in case browser/wa link handler exists
            val generic = Intent(Intent.ACTION_VIEW, waUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (generic.resolveActivity(pm) != null) {
                runCatching { context.startActivity(generic) }
            } else {
                Result.failure(IllegalStateException("WhatsApp is not installed on this device. You can use SMS Reminder instead."))
            }
        }
    }

    fun launchSmsReminder(
        context: Context,
        invoice: InvoiceEntity,
        billingConfig: BillingConfigCloud,
        languageCode: String
    ): Result<Unit> {
        if (!BillingDomainHelper.canSendReminder(
                paymentStatus = invoice.paymentStatus,
                remainingBalance = invoice.remainingBalance,
                featureEnabled = billingConfig.smsReminderEnabled
            )
        ) {
            return Result.failure(IllegalStateException("SMS reminder is only available for unpaid or partially paid invoices when enabled."))
        }
        val message = buildInvoiceReminderMessage(invoice, billingConfig, languageCode)
        val smsUri = Uri.parse(BillingDomainHelper.buildSmsUriString(invoice.customerMobile))
        val intent = Intent(Intent.ACTION_SENDTO, smsUri).apply {
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            runCatching { context.startActivity(intent) }
        } else {
            Result.failure(IllegalStateException("No SMS messaging app found on this device."))
        }
    }
}
