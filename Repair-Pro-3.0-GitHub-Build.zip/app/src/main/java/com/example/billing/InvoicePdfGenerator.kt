package com.example.billing

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.example.data.local.InvoiceEntity
import com.example.data.local.InvoicePaymentEntity
import com.example.data.remote.BillingDomainHelper
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object InvoicePdfGenerator {
    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 36

    fun generateInvoicePdf(
        context: Context,
        invoice: InvoiceEntity,
        payments: List<InvoicePaymentEntity>,
        businessTitle: String,
        termsNote: String
    ): Result<File> = runCatching {
        val dir = File(context.cacheDir, "invoices").apply { mkdirs() }
        val safeName = invoice.invoiceNumber.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val outFile = File(dir, "RepairPro_$safeName.pdf")

        val pdf = PdfDocument()
        var pageNumber = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
        var canvas = page.canvas
        var y = MARGIN.toFloat()

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0055AA")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val sectionPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0B2A4A")
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1E293B")
            textSize = 11f
            typeface = Typeface.DEFAULT
        }
        val mutedPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 10f
            typeface = Typeface.DEFAULT
        }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 1f
        }
        val accentBannerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E6F4FF")
        }

        val contentWidth = PAGE_WIDTH - (MARGIN * 2)

        fun ensureSpace(neededHeight: Float) {
            if (y + neededHeight > PAGE_HEIGHT - MARGIN) {
                pdf.finishPage(page)
                pageNumber += 1
                page = pdf.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
                canvas = page.canvas
                y = MARGIN.toFloat()
            }
        }

        fun drawWrapped(text: String, paint: TextPaint, width: Int = contentWidth, extraBottom: Float = 6f) {
            if (text.isBlank()) return
            val layout = StaticLayout.Builder
                .obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(2f, 1.1f)
                .build()
            ensureSpace(layout.height + extraBottom)
            canvas.save()
            canvas.translate(MARGIN.toFloat(), y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + extraBottom
        }

        // Header banner
        canvas.drawRect(MARGIN.toFloat(), y, (PAGE_WIDTH - MARGIN).toFloat(), y + 66f, accentBannerPaint)
        y += 12f
        drawWrapped(businessTitle.ifBlank { "Repair Pro Service Invoice" }, titlePaint, contentWidth, 4f)
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(invoice.createdAtMillis))
        drawWrapped("Invoice #: ${invoice.invoiceNumber}   •   Date: $dateStr", mutedPaint, contentWidth, 14f)

        canvas.drawLine(MARGIN.toFloat(), y, (PAGE_WIDTH - MARGIN).toFloat(), y, linePaint)
        y += 12f

        // Customer Section
        drawWrapped("Customer Details", sectionPaint, contentWidth, 4f)
        drawWrapped("Name: ${invoice.customerName}", bodyPaint, contentWidth, 3f)
        drawWrapped("Mobile: ${invoice.customerMobile}", bodyPaint, contentWidth, 3f)
        if (invoice.customerAddress.isNotBlank()) {
            drawWrapped("Address: ${invoice.customerAddress}", bodyPaint, contentWidth, 3f)
        }
        y += 6f

        // Appliance & Service Details (only include entered details)
        val hasApplianceInfo = listOf(
            invoice.applianceCategory,
            invoice.applianceBrand,
            invoice.modelNumber,
            invoice.serialNumber,
            invoice.reportedProblem,
            invoice.workDone,
            invoice.partsUsed
        ).any { it.isNotBlank() }

        if (hasApplianceInfo) {
            drawWrapped("Appliance & Work Summary", sectionPaint, contentWidth, 4f)
            val appLine = listOf(invoice.applianceCategory, invoice.applianceBrand, invoice.modelNumber)
                .filter { it.isNotBlank() }.joinToString(" • ")
            if (appLine.isNotBlank()) drawWrapped("Appliance: $appLine", bodyPaint, contentWidth, 3f)
            if (invoice.serialNumber.isNotBlank()) drawWrapped("Serial No: ${invoice.serialNumber}", bodyPaint, contentWidth, 3f)
            if (invoice.reportedProblem.isNotBlank()) drawWrapped("Reported Problem: ${invoice.reportedProblem}", bodyPaint, contentWidth, 3f)
            if (invoice.workDone.isNotBlank()) drawWrapped("Work Done: ${invoice.workDone}", bodyPaint, contentWidth, 3f)
            if (invoice.partsUsed.isNotBlank()) {
                val qtyText = if (invoice.partsQuantity > 0) " (Qty: ${invoice.partsQuantity})" else ""
                drawWrapped("Parts Replaced: ${invoice.partsUsed}$qtyText", bodyPaint, contentWidth, 3f)
            }
            y += 6f
        }

        // Charges Breakdown
        drawWrapped("Billing Summary", sectionPaint, contentWidth, 4f)
        val rows = listOfNotNull(
            invoice.partsCharges?.let { "Parts Charges" to BillingDomainHelper.formatInr(it) },
            invoice.serviceCharges?.let { "Service Charges" to BillingDomainHelper.formatInr(it) },
            invoice.visitingCharges?.let { "Visiting Charges" to BillingDomainHelper.formatInr(it) },
            invoice.otherCharges?.let { "Other Charges" to BillingDomainHelper.formatInr(it) },
            invoice.discountAmount?.takeIf { it > 0 }?.let { "Discount" to "-${BillingDomainHelper.formatInr(it)}" }
        )
        if (rows.isEmpty() && invoice.totalBill == null) {
            drawWrapped("Amount: Not Entered", bodyPaint, contentWidth, 4f)
        } else {
            rows.forEach { (label, valStr) ->
                drawWrapped("$label: $valStr", bodyPaint, contentWidth, 3f)
            }
            canvas.drawLine(MARGIN.toFloat(), y + 2f, (PAGE_WIDTH - MARGIN).toFloat(), y + 2f, linePaint)
            y += 8f
            drawWrapped("Total Bill: ${BillingDomainHelper.formatInr(invoice.totalBill)}", sectionPaint, contentWidth, 3f)
            invoice.amountReceived?.let {
                drawWrapped("Amount Received: ${BillingDomainHelper.formatInr(it)}", bodyPaint, contentWidth, 3f)
            }
            invoice.remainingBalance?.let {
                drawWrapped("Remaining Balance: ${BillingDomainHelper.formatInr(it)}", sectionPaint, contentWidth, 3f)
            }
        }
        drawWrapped("Payment Status: ${invoice.paymentStatus.replace('_', ' ')}", bodyPaint, contentWidth, 3f)
        if (invoice.paymentMethod.isNotBlank()) drawWrapped("Payment Method: ${invoice.paymentMethod}", bodyPaint, contentWidth, 3f)
        if (invoice.paymentDueDate.isNotBlank()) drawWrapped("Due Date: ${invoice.paymentDueDate}", bodyPaint, contentWidth, 3f)

        if (payments.isNotEmpty()) {
            y += 6f
            drawWrapped("Payment History", sectionPaint, contentWidth, 4f)
            val fmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            payments.forEach { p ->
                drawWrapped(
                    "• ${fmt.format(Date(p.paidAtMillis))} — ${BillingDomainHelper.formatInr(p.amount)} (${p.paymentMethod})${if (p.note.isNotBlank()) " — ${p.note}" else ""}",
                    bodyPaint,
                    contentWidth,
                    3f
                )
            }
        }

        if (invoice.warrantyInfo.isNotBlank() || invoice.notes.isNotBlank() || termsNote.isNotBlank()) {
            y += 8f
            canvas.drawLine(MARGIN.toFloat(), y, (PAGE_WIDTH - MARGIN).toFloat(), y, linePaint)
            y += 10f
            if (invoice.warrantyInfo.isNotBlank()) drawWrapped("Warranty: ${invoice.warrantyInfo}", bodyPaint, contentWidth, 3f)
            if (invoice.notes.isNotBlank()) drawWrapped("Notes: ${invoice.notes}", bodyPaint, contentWidth, 3f)
            if (termsNote.isNotBlank()) drawWrapped("Terms: $termsNote", mutedPaint, contentWidth, 4f)
        }

        pdf.finishPage(page)
        FileOutputStream(outFile).use { stream -> pdf.writeTo(stream) }
        pdf.close()
        outFile
    }

    fun createSharePdfIntent(context: Context, pdfFile: File, invoiceNumber: String): Intent {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Service Invoice #$invoiceNumber")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun copyPdfToDestinationUri(context: Context, sourcePdf: File, destUri: Uri): Result<Unit> = runCatching {
        context.contentResolver.openOutputStream(destUri)?.use { out ->
            sourcePdf.inputStream().use { input -> input.copyTo(out) }
        } ?: throw IllegalStateException("Unable to open destination file.")
    }
}
