package com.example.ads

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import com.example.BuildConfig
import com.example.data.remote.AppSettingCloud
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Real Google Mobile Ads SDK manager for Repair Pro v3.0.
 * - Obeys remote Super Admin configuration (global toggle, emergency kill switch, per-format toggles,
 *   per-category toggles, cooldown & session frequency caps, and test mode).
 * - Uses official Google AdMob test unit IDs during development/test mode.
 * - Keeps production ads disabled until BOTH a valid non-test build-time App ID and non-test production
 *   Ad Unit IDs are configured.
 * - Honors user ad consent (adds npa=1 extra for non-personalized ads when consent is revoked).
 */
object AdMobManager {
    private const val TAG = "AdMobManager"
    private const val TEST_PUBLISHER_PREFIX = "ca-app-pub-3940256099942544"
    private val APP_ID_REGEX = Regex("^ca-app-pub-\\d{16}~\\d{10}$")
    private val UNIT_ID_REGEX = Regex("^ca-app-pub-\\d{16}/\\d{10}$")

    const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"
    const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"

    private val initialized = AtomicBoolean(false)
    @Volatile private var cachedInterstitial: InterstitialAd? = null
    @Volatile private var cachedRewarded: RewardedAd? = null
    @Volatile private var cachedAppOpen: AppOpenAd? = null
    @Volatile private var lastInterstitialShownMs: Long = 0L
    @Volatile private var sessionInterstitialCount: Int = 0
    @Volatile private var lastAppOpenShownMs: Long = 0L

    private val bgScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun isRobolectricEnv(): Boolean = Build.FINGERPRINT.equals("robolectric", ignoreCase = true)

    fun isInitialized(): Boolean = initialized.get()

    fun isValidProductionAppId(appId: String): Boolean {
        val trimmed = appId.trim()
        return APP_ID_REGEX.matches(trimmed) && !trimmed.startsWith(TEST_PUBLISHER_PREFIX)
    }

    fun isValidProductionUnitId(unitId: String): Boolean {
        val trimmed = unitId.trim()
        return UNIT_ID_REGEX.matches(trimmed) && !trimmed.startsWith(TEST_PUBLISHER_PREFIX)
    }

    private fun resolveUnitId(
        config: AppSettingCloud,
        configuredUnitId: String,
        testFallbackId: String,
        buildAppId: String,
        isDebugBuild: Boolean
    ): String? {
        if (config.testMode || isDebugBuild) {
            return testFallbackId
        }
        val candidate = configuredUnitId.trim()
        return if (isValidProductionAppId(buildAppId) && isValidProductionUnitId(candidate)) {
            candidate
        } else {
            null
        }
    }

    fun initialize(context: Context, testMode: Boolean = true) {
        if (isRobolectricEnv()) {
            initialized.set(true)
            return
        }
        if (initialized.compareAndSet(false, true)) {
            val appCtx = context.applicationContext
            bgScope.launch {
                try {
                    if (testMode || BuildConfig.DEBUG) {
                        val config = RequestConfiguration.Builder()
                            .setTestDeviceIds(listOf(AdRequest.DEVICE_ID_EMULATOR))
                            .build()
                        MobileAds.setRequestConfiguration(config)
                    }
                    MobileAds.initialize(appCtx) { status ->
                        Log.i(TAG, "Google Mobile Ads SDK initialized: ${status.adapterStatusMap.keys}")
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "MobileAds initialization skipped: ${e.message}")
                }
            }
        }
    }

    fun resolveBannerUnitId(
        config: AppSettingCloud,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): String? = resolveUnitId(config, config.androidBannerId, TEST_BANNER_ID, buildAppId, isDebugBuild)

    fun resolveInterstitialUnitId(
        config: AppSettingCloud,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): String? = resolveUnitId(config, config.androidInterstitialId, TEST_INTERSTITIAL_ID, buildAppId, isDebugBuild)

    fun resolveRewardedUnitId(
        config: AppSettingCloud,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): String? = resolveUnitId(config, config.androidRewardedId, TEST_REWARDED_ID, buildAppId, isDebugBuild)

    fun resolveNativeUnitId(
        config: AppSettingCloud,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): String? = resolveUnitId(config, config.androidNativeId, TEST_NATIVE_ID, buildAppId, isDebugBuild)

    fun resolveAppOpenUnitId(
        config: AppSettingCloud,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): String? = resolveUnitId(config, config.androidAppOpenId, TEST_APP_OPEN_ID, buildAppId, isDebugBuild)

    fun buildAdRequest(consentGranted: Boolean): AdRequest {
        val builder = AdRequest.Builder()
        if (!consentGranted) {
            val extras = Bundle().apply { putString("npa", "1") }
            builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        return builder.build()
    }

    private fun isCategoryAllowed(config: AppSettingCloud, categoryId: String?): Boolean =
        when (categoryId?.lowercase()) {
            "ac" -> config.acAdsEnabled
            "fridge" -> config.fridgeAdsEnabled
            "washer" -> config.washerAdsEnabled
            else -> true
        }

    fun isBannerEligible(
        config: AppSettingCloud,
        categoryId: String?,
        isOnline: Boolean,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): Boolean {
        return isOnline &&
            config.adsGlobalEnabled &&
            !config.emergencyKillSwitch &&
            config.bannerEnabled &&
            isCategoryAllowed(config, categoryId) &&
            resolveBannerUnitId(config, buildAppId, isDebugBuild) != null
    }

    fun isInterstitialEligible(
        config: AppSettingCloud,
        categoryId: String? = null,
        isOnline: Boolean = true,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): Boolean {
        return isOnline &&
            config.adsGlobalEnabled &&
            !config.emergencyKillSwitch &&
            config.interstitialEnabled &&
            isCategoryAllowed(config, categoryId) &&
            resolveInterstitialUnitId(config, buildAppId, isDebugBuild) != null
    }

    fun isRewardedEligible(
        config: AppSettingCloud,
        isOnline: Boolean = true,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): Boolean {
        return isOnline &&
            config.adsGlobalEnabled &&
            !config.emergencyKillSwitch &&
            config.rewardedEnabled &&
            resolveRewardedUnitId(config, buildAppId, isDebugBuild) != null
    }

    fun isNativeEligible(
        config: AppSettingCloud,
        categoryId: String? = null,
        isOnline: Boolean = true,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): Boolean {
        return isOnline &&
            config.adsGlobalEnabled &&
            !config.emergencyKillSwitch &&
            config.nativeEnabled &&
            isCategoryAllowed(config, categoryId) &&
            resolveNativeUnitId(config, buildAppId, isDebugBuild) != null
    }

    fun isAppOpenEligible(
        config: AppSettingCloud,
        isOnline: Boolean = true,
        buildAppId: String = BuildConfig.ADMOB_APP_ID,
        isDebugBuild: Boolean = BuildConfig.DEBUG
    ): Boolean {
        return isOnline &&
            config.adsGlobalEnabled &&
            !config.emergencyKillSwitch &&
            config.appOpenEnabled &&
            resolveAppOpenUnitId(config, buildAppId, isDebugBuild) != null
    }

    fun preloadInterstitial(context: Context, config: AppSettingCloud, consentGranted: Boolean) {
        if (isRobolectricEnv()) return
        if (!isInterstitialEligible(config, isOnline = true)) return
        if (cachedInterstitial != null) return

        val unitId = resolveInterstitialUnitId(config) ?: return
        InterstitialAd.load(
            context.applicationContext,
            unitId,
            buildAdRequest(consentGranted),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    cachedInterstitial = ad
                    Log.d(TAG, "Interstitial ad loaded ($unitId)")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    cachedInterstitial = null
                    Log.w(TAG, "Interstitial failed to load: ${error.message}")
                }
            }
        )
    }

    fun maybeShowInterstitial(
        activity: Activity,
        config: AppSettingCloud,
        isOnline: Boolean,
        consentGranted: Boolean,
        categoryId: String? = null,
        onDismissed: () -> Unit = {}
    ): Boolean {
        if (isRobolectricEnv() || !isInterstitialEligible(config, categoryId, isOnline)) {
            onDismissed()
            return false
        }
        val cooldownMs = config.interstitialCooldownMin.coerceIn(1L, 60L) * 60_000L
        val now = System.currentTimeMillis()
        if (sessionInterstitialCount >= config.sessionFrequencyCap.coerceIn(1L, 50L)) {
            onDismissed()
            return false
        }
        if (now - lastInterstitialShownMs < cooldownMs) {
            onDismissed()
            return false
        }
        val ad = cachedInterstitial
        if (ad == null) {
            preloadInterstitial(activity, config, consentGranted)
            onDismissed()
            return false
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                cachedInterstitial = null
                preloadInterstitial(activity, config, consentGranted)
                onDismissed()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                cachedInterstitial = null
                onDismissed()
            }
        }
        lastInterstitialShownMs = now
        sessionInterstitialCount++
        ad.show(activity)
        return true
    }

    fun preloadRewarded(context: Context, config: AppSettingCloud, consentGranted: Boolean) {
        if (isRobolectricEnv()) return
        if (!isRewardedEligible(config, isOnline = true)) return
        if (cachedRewarded != null) return

        val unitId = resolveRewardedUnitId(config) ?: return
        RewardedAd.load(
            context.applicationContext,
            unitId,
            buildAdRequest(consentGranted),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    cachedRewarded = ad
                    Log.d(TAG, "Rewarded ad loaded ($unitId)")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    cachedRewarded = null
                    Log.w(TAG, "Rewarded failed to load: ${error.message}")
                }
            }
        )
    }

    fun showRewarded(
        activity: Activity,
        config: AppSettingCloud,
        consentGranted: Boolean,
        isOnline: Boolean = true,
        onRewardEarned: () -> Unit,
        onUnavailable: () -> Unit = {}
    ) {
        if (isRobolectricEnv() || !isRewardedEligible(config, isOnline)) {
            onUnavailable()
            return
        }
        val ad = cachedRewarded
        if (ad == null) {
            preloadRewarded(activity, config, consentGranted)
            onUnavailable()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                cachedRewarded = null
                preloadRewarded(activity, config, consentGranted)
            }
        }
        ad.show(activity) { onRewardEarned() }
    }

    fun preloadAppOpen(context: Context, config: AppSettingCloud, consentGranted: Boolean) {
        if (isRobolectricEnv()) return
        if (!isAppOpenEligible(config, isOnline = true)) return
        if (cachedAppOpen != null) return

        val unitId = resolveAppOpenUnitId(config) ?: return
        AppOpenAd.load(
            context.applicationContext,
            unitId,
            buildAdRequest(consentGranted),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    cachedAppOpen = ad
                    Log.d(TAG, "App Open ad loaded ($unitId)")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    cachedAppOpen = null
                    Log.w(TAG, "App Open failed to load: ${error.message}")
                }
            }
        )
    }

    fun maybeShowAppOpen(
        activity: Activity,
        config: AppSettingCloud,
        consentGranted: Boolean,
        isOnline: Boolean = true
    ) {
        if (isRobolectricEnv() || !isAppOpenEligible(config, isOnline)) return
        val now = System.currentTimeMillis()
        if (now - lastAppOpenShownMs < 15 * 60_000L) return
        val ad = cachedAppOpen ?: run {
            preloadAppOpen(activity, config, consentGranted)
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                cachedAppOpen = null
                preloadAppOpen(activity, config, consentGranted)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                cachedAppOpen = null
            }
        }
        lastAppOpenShownMs = now
        ad.show(activity)
    }
}

/**
 * Real Google Mobile Ads SDK Banner Composable.
 * Never renders a fake static banner — uses real AdView on Android devices & emulators.
 */
@Composable
fun RealAdMobBannerView(
    config: AppSettingCloud,
    categoryId: String?,
    isOnline: Boolean,
    consentGranted: Boolean,
    screenTag: String,
    modifier: Modifier = Modifier
) {
    if (!AdMobManager.isBannerEligible(config, categoryId, isOnline)) return
    if (AdMobManager.isRobolectricEnv()) return

    val context = LocalContext.current
    val unitId = remember(config.testMode, config.androidBannerId) {
        AdMobManager.resolveBannerUnitId(config)
    } ?: return

    val adView = remember(unitId, consentGranted) {
        AdView(context).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = unitId
            adListener = object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w("AdMobBanner", "Banner failed ($screenTag): ${error.message}")
                }
            }
            loadAd(AdMobManager.buildAdRequest(consentGranted))
        }
    }

    DisposableEffect(adView) {
        onDispose { adView.destroy() }
    }

    AndroidView(
        factory = { adView },
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .testTag("admob_banner_$screenTag")
    )
}

/**
 * Real Google Mobile Ads Native Ad Composable backed by NativeAdView + AdLoader.
 * Includes the required "Ad" attribution badge and renders only when Native Ads are
 * enabled remotely and eligible for the current build mode.
 */
@Composable
fun RealAdMobNativeAdView(
    config: AppSettingCloud,
    categoryId: String?,
    isOnline: Boolean,
    consentGranted: Boolean,
    screenTag: String,
    modifier: Modifier = Modifier
) {
    if (!AdMobManager.isNativeEligible(config, categoryId, isOnline)) return
    if (AdMobManager.isRobolectricEnv()) return

    val context = LocalContext.current
    val unitId = remember(config.testMode, config.androidNativeId) {
        AdMobManager.resolveNativeUnitId(config)
    } ?: return

    var loadedNativeAd by remember(unitId, consentGranted) { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(unitId, consentGranted) {
        var active = true
        val adLoader = AdLoader.Builder(context, unitId)
            .forNativeAd { nativeAd ->
                if (!active) {
                    nativeAd.destroy()
                } else {
                    loadedNativeAd?.destroy()
                    loadedNativeAd = nativeAd
                }
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w("AdMobNative", "Native ad failed ($screenTag): ${error.message}")
                }
            })
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()

        adLoader.loadAd(AdMobManager.buildAdRequest(consentGranted))

        onDispose {
            active = false
            loadedNativeAd?.destroy()
            loadedNativeAd = null
        }
    }

    val nativeAd = loadedNativeAd ?: return
    AndroidView(
        factory = { ctx ->
            val dp = ctx.resources.displayMetrics.density
            fun d(v: Int): Int = (v * dp).toInt()

            val adView = NativeAdView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(d(14), d(12), d(14), d(12))
                background = GradientDrawable().apply {
                    cornerRadius = d(16).toFloat()
                    setColor(Color.parseColor("#B3111C30"))
                    setStroke(d(1), Color.parseColor("#6600C8FF"))
                }
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val topRow = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val badge = TextView(ctx).apply {
                text = "Ad"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTextColor(Color.parseColor("#081124"))
                setPadding(d(7), d(2), d(7), d(2))
                background = GradientDrawable().apply {
                    cornerRadius = d(6).toFloat()
                    setColor(Color.parseColor("#00C8FF"))
                }
            }
            val headlineView = TextView(ctx).apply {
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(d(10), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            topRow.addView(badge)
            topRow.addView(headlineView)

            val bodyView = TextView(ctx).apply {
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(Color.parseColor("#A9B8CC"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, d(6), 0, d(8))
            }

            val mediaView = MediaView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    d(136)
                )
            }

            val ctaButton = Button(ctx).apply {
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    cornerRadius = d(10).toFloat()
                    setColor(Color.parseColor("#008CFF"))
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = d(8) }
            }

            card.addView(topRow)
            card.addView(bodyView)
            card.addView(mediaView)
            card.addView(ctaButton)
            adView.addView(card)

            adView.headlineView = headlineView
            adView.bodyView = bodyView
            adView.mediaView = mediaView
            adView.callToActionView = ctaButton
            adView
        },
        update = { adView ->
            (adView.headlineView as? TextView)?.text = nativeAd.headline.orEmpty()
            val bodyText = nativeAd.body.orEmpty()
            (adView.bodyView as? TextView)?.apply {
                text = bodyText
                visibility = if (bodyText.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            }
            (adView.callToActionView as? Button)?.apply {
                val cta = nativeAd.callToAction.orEmpty()
                text = cta
                visibility = if (cta.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            }
            adView.mediaView?.mediaContent = nativeAd.mediaContent
            adView.setNativeAd(nativeAd)
        },
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .testTag("admob_native_$screenTag")
    )
}
