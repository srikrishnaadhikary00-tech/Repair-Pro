package com.example.ads

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Bundle
import com.example.data.remote.AppSettingCloud
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import java.util.concurrent.atomic.AtomicBoolean

object AdMobManager {

    const val TEST_BANNER_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_INTERSTITIAL_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

    private val initialized = AtomicBoolean(false)
    @Volatile
    private var cachedInterstitial: InterstitialAd? = null
    @Volatile
    private var lastInterstitialShownAtMs: Long = 0L
    @Volatile
    private var sessionInterstitialCount: Int = 0

    fun isRobolectricRuntime(): Boolean {
        return Build.FINGERPRINT.equals("robolectric", ignoreCase = true)
    }

    fun initializeSafely(context: Context) {
        if (isRobolectricRuntime()) return
        if (initialized.compareAndSet(false, true)) {
            try {
                MobileAds.initialize(context.applicationContext) {}
            } catch (_: Throwable) {
                initialized.set(false)
            }
        }
    }

    fun isBannerAllowed(config: AppSettingCloud, categoryId: String? = null): Boolean {
        if (!config.adsGlobalEnabled || config.emergencyKillSwitch || !config.bannerEnabled) {
            return false
        }
        return isCategoryEnabled(config, categoryId)
    }

    fun isInterstitialAllowed(
        config: AppSettingCloud,
        categoryId: String? = null,
        nowMs: Long = System.currentTimeMillis(),
        lastShownMs: Long = lastInterstitialShownAtMs,
        shownInSession: Int = sessionInterstitialCount
    ): Boolean {
        if (!config.adsGlobalEnabled || config.emergencyKillSwitch || !config.interstitialEnabled) {
            return false
        }
        if (!isCategoryEnabled(config, categoryId)) return false
        if (shownInSession >= config.sessionFrequencyCap.coerceAtLeast(1L)) return false
        val cooldownMs = config.interstitialCooldownMin.coerceAtLeast(1L) * 60_000L
        if (lastShownMs > 0L && (nowMs - lastShownMs) < cooldownMs) return false
        return true
    }

    private fun isCategoryEnabled(config: AppSettingCloud, categoryId: String?): Boolean {
        return when (categoryId?.lowercase()) {
            "ac" -> config.acAdsEnabled
            "fridge" -> config.fridgeAdsEnabled
            "washer" -> config.washerAdsEnabled
            else -> true
        }
    }

    fun resolveBannerUnitId(config: AppSettingCloud): String {
        if (config.testMode) return TEST_BANNER_UNIT_ID
        val custom = config.androidBannerId.trim()
        return if (custom.startsWith("ca-app-pub-")) custom else TEST_BANNER_UNIT_ID
    }

    fun resolveInterstitialUnitId(config: AppSettingCloud): String {
        if (config.testMode) return TEST_INTERSTITIAL_UNIT_ID
        val custom = config.androidInterstitialId.trim()
        return if (custom.startsWith("ca-app-pub-")) custom else TEST_INTERSTITIAL_UNIT_ID
    }

    fun buildAdRequest(adConsentGranted: Boolean): AdRequest {
        val builder = AdRequest.Builder()
        if (!adConsentGranted) {
            val extras = Bundle().apply { putString("npa", "1") }
            builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        return builder.build()
    }

    fun createBannerAdView(
        context: Context,
        config: AppSettingCloud,
        adConsentGranted: Boolean
    ): AdView? {
        if (isRobolectricRuntime()) return null
        return try {
            initializeSafely(context)
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = resolveBannerUnitId(config)
                loadAd(buildAdRequest(adConsentGranted))
            }
        } catch (_: Throwable) {
            null
        }
    }

    fun preloadInterstitialIfEligible(
        context: Context,
        config: AppSettingCloud,
        adConsentGranted: Boolean
    ) {
        if (isRobolectricRuntime() || cachedInterstitial != null) return
        if (!config.adsGlobalEnabled || config.emergencyKillSwitch || !config.interstitialEnabled) return
        try {
            initializeSafely(context)
            InterstitialAd.load(
                context.applicationContext,
                resolveInterstitialUnitId(config),
                buildAdRequest(adConsentGranted),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        cachedInterstitial = ad
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        cachedInterstitial = null
                    }
                }
            )
        } catch (_: Throwable) {
            cachedInterstitial = null
        }
    }

    fun maybeShowInterstitial(
        activity: Activity?,
        config: AppSettingCloud,
        categoryId: String?,
        adConsentGranted: Boolean
    ): Boolean {
        if (activity == null || isRobolectricRuntime()) return false
        val now = System.currentTimeMillis()
        if (!isInterstitialAllowed(config, categoryId, now)) return false
        val ad = cachedInterstitial ?: run {
            preloadInterstitialIfEligible(activity, config, adConsentGranted)
            return false
        }
        return try {
            cachedInterstitial = null
            lastInterstitialShownAtMs = now
            sessionInterstitialCount += 1
            ad.show(activity)
            preloadInterstitialIfEligible(activity, config, adConsentGranted)
            true
        } catch (_: Throwable) {
            false
        }
    }

    internal fun resetSessionCountersForTest() {
        lastInterstitialShownAtMs = 0L
        sessionInterstitialCount = 0
        cachedInterstitial = null
    }
}
