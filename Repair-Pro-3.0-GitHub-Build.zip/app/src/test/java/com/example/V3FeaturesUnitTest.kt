package com.example

import com.example.ads.AdMobManager
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.SupabaseApiClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure JVM unit tests for Repair Pro v3.0 core configuration, provider normalization,
 * and Google AdMob production/test gating rules across all 5 supported formats.
 */
class V3FeaturesUnitTest {

    @Test
    fun `app version and project identifiers match Repair Pro v3_0 requirements`() {
        assertEquals("3.0", BuildConfig.VERSION_NAME)
        assertEquals(3, BuildConfig.VERSION_CODE)
        assertEquals("com.aistudio.repairpro.kxmvqz", BuildConfig.APPLICATION_ID)
        assertEquals("xuakzzjtcgcvudkgxpbd", BuildConfig.SUPABASE_PROJECT_REF)
        assertEquals("https://xuakzzjtcgcvudkgxpbd.supabase.co", BuildConfig.SUPABASE_URL)
        assertTrue(BuildConfig.ADMOB_APP_ID.startsWith("ca-app-pub-"))
    }

    @Test
    fun `Supabase provider type normalization maps S3 aliases to canonical CUSTOM_S3`() {
        assertEquals("CUSTOM_S3", SupabaseApiClient.normalizeProviderType("S3_COMPATIBLE"))
        assertEquals("CUSTOM_S3", SupabaseApiClient.normalizeProviderType("CUSTOM_ENDPOINT"))
        assertEquals("CLOUDFLARE_R2", SupabaseApiClient.normalizeProviderType("cloudflare_r2"))
        assertEquals("CUSTOM_S3", SupabaseApiClient.normalizeProviderType("unknown_type"))
    }

    @Test
    fun `AdMobManager obeys kill switch offline guard category toggles and test mode`() {
        val enabledConfig = AppSettingCloud(
            id = "admob_config",
            configType = "ADMOB",
            adsGlobalEnabled = true,
            emergencyKillSwitch = false,
            bannerEnabled = true,
            interstitialEnabled = true,
            rewardedEnabled = true,
            nativeEnabled = true,
            appOpenEnabled = true,
            testMode = true,
            acAdsEnabled = true,
            fridgeAdsEnabled = false,
            washerAdsEnabled = true
        )

        // Eligibility checks
        assertTrue(AdMobManager.isBannerEligible(enabledConfig, "ac", isOnline = true))
        assertFalse(AdMobManager.isBannerEligible(enabledConfig, "fridge", isOnline = true))
        assertTrue(AdMobManager.isBannerEligible(enabledConfig, "washer", isOnline = true))
        assertFalse(AdMobManager.isBannerEligible(enabledConfig, "ac", isOnline = false))
        assertTrue(AdMobManager.isInterstitialEligible(enabledConfig, "ac", isOnline = true))
        assertTrue(AdMobManager.isRewardedEligible(enabledConfig, isOnline = true))
        assertTrue(AdMobManager.isNativeEligible(enabledConfig, "ac", isOnline = true))
        assertTrue(AdMobManager.isAppOpenEligible(enabledConfig, isOnline = true))

        // Emergency kill switch suppresses all formats immediately
        val killed = enabledConfig.copy(emergencyKillSwitch = true)
        assertFalse(AdMobManager.isBannerEligible(killed, "ac", isOnline = true))
        assertFalse(AdMobManager.isInterstitialEligible(killed, "ac", isOnline = true))
        assertFalse(AdMobManager.isRewardedEligible(killed, isOnline = true))
        assertFalse(AdMobManager.isNativeEligible(killed, "ac", isOnline = true))
        assertFalse(AdMobManager.isAppOpenEligible(killed, isOnline = true))

        // Global master toggle off suppresses all ads
        val globalOff = enabledConfig.copy(adsGlobalEnabled = false)
        assertFalse(AdMobManager.isBannerEligible(globalOff, "ac", isOnline = true))
        assertFalse(AdMobManager.isNativeEligible(globalOff, "ac", isOnline = true))

        // Test mode always returns official Google AdMob test unit IDs
        assertEquals(AdMobManager.TEST_BANNER_ID, AdMobManager.resolveBannerUnitId(enabledConfig))
        assertEquals(AdMobManager.TEST_INTERSTITIAL_ID, AdMobManager.resolveInterstitialUnitId(enabledConfig))
        assertEquals(AdMobManager.TEST_REWARDED_ID, AdMobManager.resolveRewardedUnitId(enabledConfig))
        assertEquals(AdMobManager.TEST_NATIVE_ID, AdMobManager.resolveNativeUnitId(enabledConfig))
        assertEquals(AdMobManager.TEST_APP_OPEN_ID, AdMobManager.resolveAppOpenUnitId(enabledConfig))
    }

    @Test
    fun `production release suppresses ads until valid non-test App ID and Unit IDs are set`() {
        val defaultProdAttempt = AppSettingCloud(
            id = "admob_config",
            configType = "ADMOB",
            adsGlobalEnabled = true,
            bannerEnabled = true,
            interstitialEnabled = true,
            rewardedEnabled = true,
            nativeEnabled = true,
            appOpenEnabled = true,
            testMode = false
        )

        // Release build + default Google Test App ID -> all formats suppressed
        assertFalse(
            AdMobManager.isBannerEligible(
                defaultProdAttempt,
                "ac",
                isOnline = true,
                buildAppId = AdMobManager.TEST_APP_ID,
                isDebugBuild = false
            )
        )
        assertNull(
            AdMobManager.resolveBannerUnitId(
                defaultProdAttempt,
                buildAppId = AdMobManager.TEST_APP_ID,
                isDebugBuild = false
            )
        )

        // Release build + valid production App ID but still test unit IDs -> suppressed
        val validProdAppId = "ca-app-pub-1234567890123456~1234567890"
        assertFalse(
            AdMobManager.isNativeEligible(
                defaultProdAttempt,
                "ac",
                isOnline = true,
                buildAppId = validProdAppId,
                isDebugBuild = false
            )
        )
        assertNull(
            AdMobManager.resolveAppOpenUnitId(
                defaultProdAttempt,
                buildAppId = validProdAppId,
                isDebugBuild = false
            )
        )

        // Release build + valid production App ID AND valid non-test unit IDs -> enabled & resolves real IDs
        val fullProdConfig = defaultProdAttempt.copy(
            androidBannerId = "ca-app-pub-1234567890123456/1111111111",
            androidInterstitialId = "ca-app-pub-1234567890123456/2222222222",
            androidRewardedId = "ca-app-pub-1234567890123456/3333333333",
            androidNativeId = "ca-app-pub-1234567890123456/4444444444",
            androidAppOpenId = "ca-app-pub-1234567890123456/5555555555"
        )
        assertTrue(AdMobManager.isBannerEligible(fullProdConfig, "ac", true, validProdAppId, false))
        assertTrue(AdMobManager.isInterstitialEligible(fullProdConfig, "ac", true, validProdAppId, false))
        assertTrue(AdMobManager.isRewardedEligible(fullProdConfig, true, validProdAppId, false))
        assertTrue(AdMobManager.isNativeEligible(fullProdConfig, "ac", true, validProdAppId, false))
        assertTrue(AdMobManager.isAppOpenEligible(fullProdConfig, true, validProdAppId, false))

        assertEquals(
            "ca-app-pub-1234567890123456/4444444444",
            AdMobManager.resolveNativeUnitId(fullProdConfig, validProdAppId, false)
        )
    }
}
