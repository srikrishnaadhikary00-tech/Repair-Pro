package com.example

import com.example.data.local.StorageConfigCache
import com.example.data.remote.MultiCloudStorageRouter
import com.example.data.remote.StorageProviderConfig
import com.example.data.remote.StorageRoutingConfig
import com.example.data.remote.SupabaseClient
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class CloudMigrationAndFailoverUnitTest {

    private class InMemoryStorageConfigCache(
        initial: StorageRoutingConfig? = null
    ) : StorageConfigCache {
        var current: StorageRoutingConfig? = initial
        override suspend fun getCachedStorageConfigSnapshot(): StorageRoutingConfig? = current
        override suspend fun saveStorageConfig(
            config: StorageRoutingConfig,
            rawProvidersJson: String,
            rawCategoryMappingsJson: String
        ) {
            current = config
        }
    }

    private fun jsonResponse(req: okhttp3.Request, code: Int, body: String): Response =
        Response.Builder()
            .request(req)
            .protocol(Protocol.HTTP_1_1)
            .code(code)
            .message(if (code in 200..299) "OK" else "Error")
            .body(body.toResponseBody("application/json".toMediaTypeOrNull()))
            .build()

    private fun bytesResponse(req: okhttp3.Request, code: Int, bytes: ByteArray, contentType: String): Response =
        Response.Builder()
            .request(req)
            .protocol(Protocol.HTTP_1_1)
            .code(code)
            .message(if (code in 200..299) "OK" else "Error")
            .body(bytes.toResponseBody(contentType.toMediaTypeOrNull()))
            .build()

    @Test
    fun `isPrimaryDatabaseSupabase distinguishes default supabase vs promoted cpanel primary`() {
        val supa = StorageProviderConfig(
            providerId = "supabase_primary",
            providerType = StorageProviderConfig.TYPE_SUPABASE_STORAGE,
            role = StorageProviderConfig.ROLE_PRIMARY,
            enabled = true
        )
        val cpanelBackup = StorageProviderConfig(
            providerId = "cpanel_main",
            providerType = StorageProviderConfig.TYPE_PHP_HOSTING,
            endpointUrl = "https://hosting.example.com/repairpro/index.php",
            supportsStorage = true,
            supportsDatabase = true,
            dbEnabled = true,
            role = StorageProviderConfig.ROLE_BACKUP,
            enabled = true
        )

        val router = MultiCloudStorageRouter(authProvider = { null })

        assertTrue(
            router.isPrimaryDatabaseSupabase(
                StorageRoutingConfig(
                    providers = listOf(supa, cpanelBackup),
                    primaryDbProviderId = "supabase_primary"
                )
            )
        )

        assertFalse(
            router.isPrimaryDatabaseSupabase(
                StorageRoutingConfig(
                    providers = listOf(
                        supa.copy(role = StorageProviderConfig.ROLE_BACKUP),
                        cpanelBackup.copy(role = StorageProviderConfig.ROLE_PRIMARY)
                    ),
                    primaryDbProviderId = "cpanel_main"
                )
            )
        )
    }

    @Test
    fun `selectOrderedProvidersForBucket respects communityOnly and verification isolation`() {
        val supa = StorageProviderConfig(
            providerId = "supabase_primary",
            providerType = StorageProviderConfig.TYPE_SUPABASE_STORAGE,
            role = StorageProviderConfig.ROLE_BACKUP,
            enabled = true
        )
        val cpanelCommunityOnly = StorageProviderConfig(
            providerId = "cpanel_comm",
            providerType = StorageProviderConfig.TYPE_PHP_HOSTING,
            endpointUrl = "https://hosting.example.com/repairpro/index.php",
            communityOnly = true,
            supportsStorage = true,
            role = StorageProviderConfig.ROLE_PRIMARY,
            enabled = true
        )
        val cpanelFull = cpanelCommunityOnly.copy(
            providerId = "cpanel_full",
            communityOnly = false
        )

        val commOnlyConfig = StorageRoutingConfig(providers = listOf(supa, cpanelCommunityOnly))
        assertEquals(
            listOf("cpanel_comm", "supabase_primary"),
            MultiCloudStorageRouter.selectOrderedProvidersForBucket(commOnlyConfig, "community").map { it.providerId }
        )
        assertEquals(
            listOf("supabase_primary"),
            MultiCloudStorageRouter.selectOrderedProvidersForBucket(commOnlyConfig, "verification").map { it.providerId }
        )

        val fullConfig = StorageRoutingConfig(providers = listOf(supa, cpanelFull))
        assertEquals(
            listOf("cpanel_full", "supabase_primary"),
            MultiCloudStorageRouter.selectOrderedProvidersForBucket(fullConfig, "verification").map { it.providerId }
        )
    }

    @Test
    fun `resolveActiveExternalDbProvider and resolveFailoverExternalDbProviders honor category mappings and flags`() = runBlocking {
        val cpanelCommunity = StorageProviderConfig(
            providerId = "cpanel_comm",
            providerType = StorageProviderConfig.TYPE_PHP_HOSTING,
            endpointUrl = "https://hosting.example.com/comm/index.php",
            communityOnly = true,
            supportsDatabase = true,
            dbEnabled = true,
            role = StorageProviderConfig.ROLE_BACKUP,
            enabled = true
        )
        val cpanelMain = StorageProviderConfig(
            providerId = "cpanel_main",
            providerType = StorageProviderConfig.TYPE_PHP_HOSTING,
            endpointUrl = "https://hosting.example.com/main/index.php",
            communityOnly = false,
            supportsDatabase = true,
            dbEnabled = true,
            role = StorageProviderConfig.ROLE_PRIMARY,
            enabled = true
        )
        val disabledDb = StorageProviderConfig(
            providerId = "cpanel_disabled",
            providerType = StorageProviderConfig.TYPE_PHP_HOSTING,
            endpointUrl = "https://hosting.example.com/off/index.php",
            supportsDatabase = true,
            dbEnabled = false,
            role = StorageProviderConfig.ROLE_BACKUP,
            enabled = true
        )

        val cache = InMemoryStorageConfigCache(
            StorageRoutingConfig(
                providers = listOf(cpanelCommunity, cpanelMain, disabledDb),
                categoryMappings = mapOf("community" to "cpanel_comm")
            )
        )
        val mockHttp = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                jsonResponse(chain.request(), 503, "{\"message\":\"Supabase paused\"}")
            })
            .build()
        val supaClient = SupabaseClient(httpClient = mockHttp, firebaseTokenProvider = { "mock-jwt" })
        val router = MultiCloudStorageRouter(
            authProvider = { null },
            httpClient = mockHttp,
            supabaseClientOverride = supaClient,
            configCache = cache
        )

        val commFailover = router.resolveFailoverExternalDbProviders("community")
        assertEquals(listOf("cpanel_comm", "cpanel_main"), commFailover.map { it.providerId })

        val verifFailover = router.resolveFailoverExternalDbProviders("verification")
        assertEquals(listOf("cpanel_main"), verifFailover.map { it.providerId })

        val activeVerif = router.resolveActiveExternalDbProvider("verification")
        assertNotNull(activeVerif)
        assertEquals("cpanel_main", activeVerif?.providerId)

        val routerNoDb = MultiCloudStorageRouter(
            authProvider = { null },
            httpClient = mockHttp,
            supabaseClientOverride = supaClient,
            configCache = InMemoryStorageConfigCache(StorageRoutingConfig(providers = listOf(disabledDb)))
        )
        assertNull(routerNoDb.resolveActiveExternalDbProvider("community"))
    }

    @Test
    fun `loadRoutingConfig falls back to cached storage snapshot when supabase is unreachable`() = runBlocking {
        val expected = StorageRoutingConfig(
            autoFailoverEnabled = true,
            autoMigrationEnabled = true,
            autoCleanupEnabled = false,
            dbMigrationThresholdPct = 75,
            storageMigrationThresholdPct = 85,
            primaryDbProviderId = "cpanel_primary",
            providers = listOf(
                StorageProviderConfig(
                    providerId = "cpanel_primary",
                    providerType = StorageProviderConfig.TYPE_PHP_HOSTING,
                    endpointUrl = "https://hosting.example.com/repairpro/index.php",
                    supportsDatabase = true,
                    dbEnabled = true,
                    role = StorageProviderConfig.ROLE_PRIMARY,
                    enabled = true
                )
            )
        )
        val cache = InMemoryStorageConfigCache(expected)
        val mockHttp = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                jsonResponse(chain.request(), 503, "{\"error\":\"Project paused\"}")
            })
            .build()
        val supaClient = SupabaseClient(httpClient = mockHttp, firebaseTokenProvider = { "mock-jwt" })
        val router = MultiCloudStorageRouter(
            authProvider = { null },
            httpClient = mockHttp,
            supabaseClientOverride = supaClient,
            configCache = cache
        )

        val loaded = router.loadRoutingConfig(forceRefresh = true)
        assertEquals("cpanel_primary", loaded.primaryDbProviderId)
        assertTrue(loaded.autoMigrationEnabled)
        assertFalse(loaded.autoCleanupEnabled)
        assertEquals(75, loaded.dbMigrationThresholdPct)
        assertEquals(85, loaded.storageMigrationThresholdPct)
    }

    @Test
    fun `downloadAuthorizedBytes attaches refreshed firebase bearer token for private cpanel downloads`() = runBlocking {
        val cpanelEndpoint = "https://hosting.example.com/repairpro/index.php"
        val cache = InMemoryStorageConfigCache(
            StorageRoutingConfig(
                providers = listOf(
                    StorageProviderConfig(
                        providerId = "cpanel_main",
                        providerType = StorageProviderConfig.TYPE_PHP_HOSTING,
                        endpointUrl = cpanelEndpoint,
                        communityOnly = false,
                        role = StorageProviderConfig.ROLE_PRIMARY,
                        enabled = true
                    )
                )
            )
        )
        val capturedAuthHeaders = mutableListOf<String>()
        var tokenRefreshCount = 0
        val samplePdfBytes = "%PDF-1.4\n1 0 obj\n".toByteArray()

        val mockHttp = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val req = chain.request()
                val url = req.url.toString()
                if (!url.contains("action=download_private")) {
                    return@Interceptor jsonResponse(req, 503, "{}")
                }
                val auth = req.header("Authorization").orEmpty()
                capturedAuthHeaders.add(auth)
                if (auth == "Bearer expired-token") {
                    bytesResponse(req, 401, ByteArray(0), "application/json")
                } else {
                    bytesResponse(req, 200, samplePdfBytes, "application/pdf")
                }
            })
            .build()

        val supaClient = SupabaseClient(
            httpClient = mockHttp,
            firebaseTokenProvider = { forceRefresh ->
                if (forceRefresh) {
                    tokenRefreshCount++
                    "fresh-firebase-rs256-jwt"
                } else {
                    "expired-token"
                }
            }
        )
        val router = MultiCloudStorageRouter(
            authProvider = { null },
            httpClient = mockHttp,
            supabaseClientOverride = supaClient,
            configCache = cache
        )

        val privateUrl = "$cpanelEndpoint?action=download_private&token=hmac123"
        val bytes = router.downloadAuthorizedBytes(privateUrl).getOrThrow()

        assertEquals(1, tokenRefreshCount)
        assertEquals(listOf("Bearer expired-token", "Bearer fresh-firebase-rs256-jwt"), capturedAuthHeaders)
        assertTrue(bytes.contentEquals(samplePdfBytes))
    }

    @Test
    fun `supabase 507 and 503 trigger quota classification while delete resolution targets matching host`() = runBlocking {
        val mockHttp = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                jsonResponse(chain.request(), 507, "{\"error\":\"Quota exceeded\"}")
            })
            .build()
        val supaClient = SupabaseClient(httpClient = mockHttp, firebaseTokenProvider = { "mock-jwt" })
        val validJpegBytes = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(), 0x00, 0x10)
        val failedUpload = supaClient.uploadObject(
            bucketName = "community-photos",
            objectPath = "u1/img.jpg",
            bytes = validJpegBytes,
            mimeType = "image/jpeg",
            overrideUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
            overrideAnonKey = "anon-key"
        )
        assertTrue(failedUpload.isFailure)
        assertTrue(MultiCloudStorageRouter.isSupabaseQuotaOrOutageFailure(failedUpload.exceptionOrNull()))

        assertEquals(
            "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-push-notification",
            SupabaseClient.DEFAULT_FCM_ENDPOINT
        )
        assertTrue(MultiCloudStorageRouter.isSupabaseQuotaOrOutageFailure(IllegalStateException("HTTP 503 Service Unavailable")))
        assertTrue(MultiCloudStorageRouter.isSupabaseQuotaOrOutageFailure(IOException("Connection reset")))
        assertFalse(MultiCloudStorageRouter.isSupabaseQuotaOrOutageFailure(IllegalArgumentException("HTTP 400 Invalid field")))

        val actionUrl = MultiCloudStorageRouter.buildPhpActionUrl("https://host.example.com/api/", "db_query")
        assertEquals("https://host.example.com/api/index.php?action=db_query", actionUrl)

        val directScriptUrl = MultiCloudStorageRouter.buildPhpActionUrl("https://host.example.com/api/index.php", "upload")
        assertEquals("https://host.example.com/api/index.php?action=upload", directScriptUrl)

        val routing = StorageRoutingConfig(
            providers = listOf(
                StorageProviderConfig(
                    providerId = "supabase_primary",
                    providerType = StorageProviderConfig.TYPE_SUPABASE_STORAGE,
                    endpointUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co"
                ),
                StorageProviderConfig(
                    providerId = "cpanel_1",
                    providerType = StorageProviderConfig.TYPE_PHP_HOSTING,
                    endpointUrl = "https://host.example.com/api/index.php",
                    publicMediaBaseUrl = "https://host.example.com/api/uploads"
                )
            )
        )
        val matchedCpanel = MultiCloudStorageRouter.resolveProviderForDelete(
            config = routing,
            providerId = "",
            publicUrl = "https://host.example.com/api/uploads/community-photos/u1/a.jpg"
        )
        assertEquals("cpanel_1", matchedCpanel.providerId)
        assertEquals(
            "u1/a.jpg",
            MultiCloudStorageRouter.extractRelativePathFromUrl(
                "https://host.example.com/api/uploads/community-photos/u1/a.jpg",
                "community-photos"
            )
        )
    }

    @Test
    fun `parseRoutingConfig preserves safe supabase defaults, threshold clamps, and discovery URL deduplication`() {
        val defaults = MultiCloudStorageRouter.parseRoutingConfig(
            autoFailoverEnabled = true,
            fcmBackendUrl = "",
            providersJson = ""
        )
        assertEquals("supabase_primary", defaults.primaryDbProviderId)
        assertFalse(defaults.autoMigrationEnabled)
        assertFalse(defaults.autoCleanupEnabled)
        assertEquals(80, defaults.dbMigrationThresholdPct)
        assertEquals(80, defaults.storageMigrationThresholdPct)
        assertEquals(1, defaults.providers.size)
        assertEquals(StorageProviderConfig.TYPE_SUPABASE_STORAGE, defaults.providers.first().providerType)

        val clamped = MultiCloudStorageRouter.parseRoutingConfig(
            autoFailoverEnabled = true,
            fcmBackendUrl = "",
            providersJson = "",
            autoMigrationEnabled = true,
            autoCleanupEnabled = true,
            dbMigrationThresholdPct = 5,
            storageMigrationThresholdPct = 150,
            primaryDbProviderId = "   ",
            fallbackDiscoveryUrls = listOf(
                "https://host.example.com/api/index.php",
                "https://host.example.com/api/index.php",
                "https://backup.example.com/api/index.php"
            ),
            configVersion = 0L
        )
        assertEquals(20, clamped.dbMigrationThresholdPct)
        assertEquals(99, clamped.storageMigrationThresholdPct)
        assertEquals("supabase_primary", clamped.primaryDbProviderId)
        assertEquals(2, clamped.fallbackDiscoveryUrls.size)
        assertEquals(1L, clamped.configVersion)
    }

    @Test
    fun `open community posting helper allows text-only, photo-only, and text-plus-photo for any active user`() {
        val textOnlyErr = com.example.data.remote.CommunityDomainHelper.validatePostDraft(
            title = "Inverter compressor relay click",
            body = "Checked outdoor PCB 15V rail and thermistor resistance.",
            category = "AC",
            hasPhotos = false
        )
        assertNull(textOnlyErr)

        val photoOnlyErr = com.example.data.remote.CommunityDomainHelper.validatePostDraft(
            title = "",
            body = "",
            category = "Refrigerator",
            hasPhotos = true
        )
        assertNull(photoOnlyErr)
        assertEquals(
            "Refrigerator Repair Photo",
            com.example.data.remote.CommunityDomainHelper.resolvePostTitle("", "", "Refrigerator")
        )

        val textAndPhotoErr = com.example.data.remote.CommunityDomainHelper.validatePostDraft(
            title = "Drain motor wiring",
            body = "Photo shows burnt connector before splice.",
            category = "Washing Machine",
            hasPhotos = true
        )
        assertNull(textAndPhotoErr)

        val emptyNonPhotoErr = com.example.data.remote.CommunityDomainHelper.validatePostDraft(
            title = "",
            body = "",
            category = "General",
            hasPhotos = false
        )
        assertNotNull(emptyNonPhotoErr)

        val badCategoryErr = com.example.data.remote.CommunityDomainHelper.validatePostDraft(
            title = "Valid Title",
            body = "Valid description body",
            category = "Microwave",
            hasPhotos = true
        )
        assertNotNull(badCategoryErr)
    }
}
