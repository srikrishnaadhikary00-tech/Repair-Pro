package com.example

import com.example.data.local.OfflinePdfCacheManager
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.CommunityDomainHelper
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.SupabaseClient
import com.example.data.remote.TechnicalDocumentCloud
import com.example.data.remote.TechnicianCloud
import com.example.data.remote.UserProfileCloud
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import kotlin.io.path.createTempDirectory

class FinalReleaseSecurityAndAdminUnitTest {

    @Test
    fun `user moderation status blocks or suspends account consistently`() {
        val active = UserProfileCloud(userId = "u1", accountStatus = "ACTIVE", blocked = false, suspended = false)
        assertFalse(active.isAccountBlockedOrSuspended)

        assertTrue(active.copy(blocked = true).isAccountBlockedOrSuspended)
        assertTrue(active.copy(suspended = true).isAccountBlockedOrSuspended)
        assertTrue(active.copy(accountStatus = "BLOCKED").isAccountBlockedOrSuspended)
        assertTrue(active.copy(accountStatus = "SUSPENDED").isAccountBlockedOrSuspended)
        assertTrue(active.copy(accountStatus = "suspended").isAccountBlockedOrSuspended)
    }

    @Test
    fun `remote version gating evaluates force update vs soft update accurately`() {
        val cfg = AppSettingCloud(
            configType = "GLOBAL",
            minSupportedVersionCode = 3L,
            latestVersionCode = 5L,
            latestVersionName = "1.4.0",
            forceUpdate = true
        )

        // App version 2 is below minSupportedVersionCode 3 with forceUpdate=true -> forced
        assertTrue(cfg.requiresForceUpdate(2))
        assertFalse(cfg.hasSoftUpdateAvailable(2))

        // App version 3 meets minimum supported (3) -> no force update, soft prompt for v5
        assertFalse(cfg.requiresForceUpdate(3))
        assertTrue(cfg.hasSoftUpdateAvailable(3))

        // App version 5 is current -> neither forced nor soft update
        assertFalse(cfg.requiresForceUpdate(5))
        assertFalse(cfg.hasSoftUpdateAvailable(5))

        // If forceUpdate is disabled, outdated app falls back to soft prompt only
        val softOnly = cfg.copy(forceUpdate = false)
        assertFalse(softOnly.requiresForceUpdate(1))
        assertTrue(softOnly.hasSoftUpdateAvailable(1))
    }

    @Test
    fun `technician public visibility excludes inactive blocked suspended and soft deleted records`() {
        val visible = TechnicianCloud(id = "t1", status = "ACTIVE", blocked = false, isSuspended = false, isDeleted = false)
        assertTrue(visible.isPubliclyVisible)

        assertFalse(visible.copy(status = "INACTIVE").isPubliclyVisible)
        assertFalse(visible.copy(blocked = true).isPubliclyVisible)
        assertFalse(visible.copy(isSuspended = true).isPubliclyVisible)
        assertFalse(visible.copy(isDeleted = true).isPubliclyVisible)
    }

    @Test
    fun `community filter excludes hidden and soft deleted posts while preserving pinned order`() {
        val posts = listOf(
            CommunityPostCloud(id = "p_normal", postId = "p_normal", category = "AC", title = "AC Gas Check", isPinned = false),
            CommunityPostCloud(id = "p_pinned", postId = "p_pinned", category = "AC", title = "AC Safety Guide", isPinned = true),
            CommunityPostCloud(id = "p_hidden", postId = "p_hidden", category = "AC", title = "Hidden Post", isHidden = true),
            CommunityPostCloud(id = "p_deleted", postId = "p_deleted", category = "AC", title = "Deleted Post", isDeleted = true)
        )

        val result = CommunityDomainHelper.filterPosts(posts, "ALL", "")
        assertEquals(listOf("p_pinned", "p_normal"), result.map { it.postId })
    }

    @Test
    fun `offline pdf cache eligibility and admin sync purge revoked manuals safely`() {
        runBlocking {
            val tempDir = createTempDirectory("repairpro_pdf_cache_test").toFile()
            try {
                val manager = OfflinePdfCacheManager(tempDir)
                val eligible = TechnicalDocumentCloud(
                    id = "doc_ok",
                    docId = "doc_ok",
                    docType = "PDF_MANUAL",
                    title = "Daikin Inverter Guide",
                    fileUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co/storage/v1/object/public/repair-pdfs/daikin.pdf",
                    storagePath = "repair-pdfs/daikin.pdf",
                    published = true,
                    offlineAvailable = true,
                    isDeleted = false
                )
                assertTrue(manager.isDocumentEligibleForOffline(eligible))
                assertFalse(manager.isDocumentEligibleForOffline(eligible.copy(offlineAvailable = false)))
                assertFalse(manager.isDocumentEligibleForOffline(eligible.copy(published = false)))
                assertFalse(manager.isDocumentEligibleForOffline(eligible.copy(isDeleted = true)))
                assertFalse(manager.isDocumentEligibleForOffline(eligible.copy(docType = "CIRCUIT_DIAGRAM")))
                assertFalse(manager.isDocumentEligibleForOffline(eligible.copy(fileUrl = "http://insecure.example.com/a.pdf")))
                assertFalse(manager.isDocumentEligibleForOffline(eligible.copy(storagePath = "verification-documents/u1/id.pdf")))

                // Seed three cached PDFs + one stale .tmp file
                File(tempDir, "doc_ok.pdf").writeBytes("%PDF-1.4 ok".toByteArray())
                File(tempDir, "doc_revoked.pdf").writeBytes("%PDF-1.4 revoked".toByteArray())
                File(tempDir, "doc_deleted.pdf").writeBytes("%PDF-1.4 deleted".toByteArray())
                File(tempDir, "orphan.pdf.tmp").writeBytes(byteArrayOf(1, 2, 3))

                val remaining = manager.syncWithApprovedDocuments(
                    listOf(
                        eligible,
                        eligible.copy(id = "doc_revoked", docId = "doc_revoked", offlineAvailable = false),
                        eligible.copy(id = "doc_deleted", docId = "doc_deleted", isDeleted = true)
                    )
                )

                assertEquals(setOf("doc_ok"), remaining)
                assertNotNull(manager.getCachedPdfFile("doc_ok"))
                assertNull(manager.getCachedPdfFile("doc_revoked"))
                assertNull(manager.getCachedPdfFile("doc_deleted"))
                assertFalse(File(tempDir, "orphan.pdf.tmp").exists())

                manager.removeCachedDocument("doc_ok")
                assertTrue(manager.getCachedDocIds().isEmpty())
                manager.clearAll()
            } finally {
                tempDir.deleteRecursively()
            }
        }
    }

    @Test
    fun `binary upload magic byte and size validation rejects spoofed files`() {
        val jpeg = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte())
        val png = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
        val webp = byteArrayOf('R'.code.toByte(), 'I'.code.toByte(), 'F'.code.toByte(), 'F'.code.toByte(), 0, 0, 0, 0, 'W'.code.toByte(), 'E'.code.toByte(), 'B'.code.toByte(), 'P'.code.toByte())
        val pdf = "%PDF-1.7 sample".toByteArray()

        assertNull(SupabaseClient.validateBinaryUpload(jpeg, "image/jpeg", allowPdf = false, maxSizeBytes = 1024))
        assertNull(SupabaseClient.validateBinaryUpload(png, "image/png", allowPdf = false, maxSizeBytes = 1024))
        assertNull(SupabaseClient.validateBinaryUpload(webp, "image/webp", allowPdf = false, maxSizeBytes = 1024))
        assertNull(SupabaseClient.validateBinaryUpload(pdf, "application/pdf", allowPdf = true, maxSizeBytes = 1024))

        // Spoofed signatures & disallowed cases
        assertNotNull(SupabaseClient.validateBinaryUpload(ByteArray(0), "image/jpeg", allowPdf = false, maxSizeBytes = 1024))
        assertNotNull(SupabaseClient.validateBinaryUpload("not-a-jpeg".toByteArray(), "image/jpeg", allowPdf = false, maxSizeBytes = 1024))
        assertNotNull(SupabaseClient.validateBinaryUpload("<html>spoof</html>".toByteArray(), "application/pdf", allowPdf = true, maxSizeBytes = 1024))
        assertNotNull(SupabaseClient.validateBinaryUpload(pdf, "application/pdf", allowPdf = false, maxSizeBytes = 1024))
        assertNotNull(SupabaseClient.validateBinaryUpload(jpeg, "image/jpeg", allowPdf = false, maxSizeBytes = 2))
        assertNotNull(SupabaseClient.validateBinaryUpload(jpeg, "application/x-msdownload", allowPdf = true, maxSizeBytes = 1024))
    }

    @Test
    fun `supabase client refreshes firebase id token once on 401 and blocks unauthenticated calls`() = runBlocking {
        var callCount = 0
        val refreshFlags = mutableListOf<Boolean>()
        val authHeaders = mutableListOf<String>()

        val mockHttp = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val req = chain.request()
                callCount += 1
                authHeaders.add(req.header("Authorization").orEmpty())
                val status = if (callCount == 1) 401 else 200
                Response.Builder()
                    .request(req)
                    .protocol(Protocol.HTTP_1_1)
                    .code(status)
                    .message(if (status == 200) "OK" else "Unauthorized")
                    .body("{}".toResponseBody("application/json".toMediaTypeOrNull()))
                    .build()
            })
            .build()

        val clientWithRefresh = SupabaseClient(
            httpClient = mockHttp,
            firebaseTokenProvider = { forceRefresh ->
                refreshFlags.add(forceRefresh)
                if (forceRefresh) "fresh-firebase-jwt" else "stale-firebase-jwt"
            }
        )

        val validJpeg = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte())
        val uploadResult = clientWithRefresh.uploadObject(
            bucketName = "community-photos",
            objectPath = "u1/test.jpg",
            bytes = validJpeg,
            mimeType = "image/jpeg",
            overrideUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
            overrideAnonKey = "anon-key"
        )
        assertTrue(uploadResult.isSuccess)
        assertEquals(listOf(false, true), refreshFlags)
        assertEquals(listOf("Bearer stale-firebase-jwt", "Bearer fresh-firebase-jwt"), authHeaders)

        // Missing Firebase session is rejected before HTTP network call
        val clientUnauth = SupabaseClient(
            httpClient = mockHttp,
            firebaseTokenProvider = { null }
        )
        val unauthResult = clientUnauth.uploadObject(
            bucketName = "community-photos",
            objectPath = "u1/test.jpg",
            bytes = validJpeg,
            mimeType = "image/jpeg",
            overrideUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
            overrideAnonKey = "anon-key"
        )
        assertTrue(unauthResult.isFailure)
    }
}
