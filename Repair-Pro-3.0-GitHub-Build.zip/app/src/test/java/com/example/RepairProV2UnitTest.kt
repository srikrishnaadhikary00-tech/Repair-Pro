package com.example

import com.example.ads.AdMobManager
import com.example.data.remote.AnnouncementCloud
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.CommunityDomainHelper
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.TechnicianCloud
import com.example.data.remote.UserNotificationCloud
import com.example.data.remote.V2DomainHelper
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RepairProV2UnitTest {

    @Test
    fun `verification application validates required fields and specializations`() {
        val valid = V2DomainHelper.validateVerificationApplication(
            fullName = "Arjun Das",
            mobileNumber = "+91 98300 12345",
            fullAddress = "14 Park Circus",
            state = "West Bengal",
            district = "Kolkata",
            cityArea = "Park Circus",
            pinCode = "700017",
            serviceCategories = listOf("AC", "Refrigerator")
        )
        assertNull(valid)

        val badPhone = V2DomainHelper.validateVerificationApplication(
            fullName = "Arjun Das",
            mobileNumber = "123",
            fullAddress = "14 Park Circus",
            state = "West Bengal",
            district = "Kolkata",
            cityArea = "Park Circus",
            pinCode = "700017",
            serviceCategories = listOf("AC")
        )
        assertNotNull(badPhone)

        val noCategory = V2DomainHelper.validateVerificationApplication(
            fullName = "Arjun Das",
            mobileNumber = "+91 98300 12345",
            fullAddress = "14 Park Circus",
            state = "West Bengal",
            district = "Kolkata",
            cityArea = "Park Circus",
            pinCode = "700017",
            serviceCategories = emptyList()
        )
        assertNotNull(noCategory)
    }

    @Test
    fun `verified technician badge requires VERIFIED status and non-blocked state`() {
        val verified = TechnicianCloud(id = "t1", verificationStatus = "VERIFIED", blocked = false)
        val pending = TechnicianCloud(id = "t2", verificationStatus = "PENDING", blocked = false)
        val blocked = TechnicianCloud(id = "t3", verificationStatus = "VERIFIED", blocked = true)

        assertTrue(V2DomainHelper.isVerifiedTechnicianRecord(verified))
        assertFalse(V2DomainHelper.isVerifiedTechnicianRecord(pending))
        assertFalse(V2DomainHelper.isVerifiedTechnicianRecord(blocked))
    }

    @Test
    fun `unread notification counter combines personal inbox and unread broadcast announcements`() {
        val personal = listOf(
            UserNotificationCloud(id = "n1", notificationId = "n1", isRead = false),
            UserNotificationCloud(id = "n2", notificationId = "n2", isRead = true)
        )
        val announcements = listOf(
            AnnouncementCloud(id = "a1", announcementId = "a1", title = "V2 Launch"),
            AnnouncementCloud(id = "a2", announcementId = "a2", title = "Safety Note")
        )
        val readIds = setOf("a1")

        assertEquals(2, V2DomainHelper.countUnreadNotifications(personal, announcements, readIds))
    }

    @Test
    fun `admob manager enforces kill switch test mode category toggles cooldown and frequency cap`() {
        val base = AppSettingCloud(
            configType = "ADMOB",
            adsGlobalEnabled = true,
            bannerEnabled = true,
            interstitialEnabled = true,
            emergencyKillSwitch = false,
            testMode = true,
            acAdsEnabled = true,
            fridgeAdsEnabled = false,
            washerAdsEnabled = true,
            interstitialCooldownMin = 5L,
            sessionFrequencyCap = 2L,
            androidBannerId = "ca-app-pub-1111111111111111/2222222222",
            androidInterstitialId = "ca-app-pub-1111111111111111/3333333333"
        )

        // Banner rules
        assertTrue(AdMobManager.isBannerAllowed(base, "ac"))
        assertFalse(AdMobManager.isBannerAllowed(base, "fridge"))
        assertFalse(AdMobManager.isBannerAllowed(base.copy(emergencyKillSwitch = true), "ac"))

        // Test mode vs live custom unit ID
        assertEquals(AdMobManager.TEST_BANNER_UNIT_ID, AdMobManager.resolveBannerUnitId(base))
        assertEquals(
            "ca-app-pub-1111111111111111/2222222222",
            AdMobManager.resolveBannerUnitId(base.copy(testMode = false))
        )

        // Interstitial cooldown & cap
        val now = 1_000_000L
        assertTrue(AdMobManager.isInterstitialAllowed(base, "ac", nowMs = now, lastShownMs = 0L, shownInSession = 0))
        assertFalse(AdMobManager.isInterstitialAllowed(base, "ac", nowMs = now, lastShownMs = now - 60_000L, shownInSession = 1))
        assertTrue(AdMobManager.isInterstitialAllowed(base, "ac", nowMs = now, lastShownMs = now - 360_000L, shownInSession = 1))
        assertFalse(AdMobManager.isInterstitialAllowed(base, "ac", nowMs = now, lastShownMs = now - 360_000L, shownInSession = 2))
    }

    @Test
    fun `community post supports photo-only drafts and resolves multi-photo gallery`() {
        assertNull(CommunityDomainHelper.validatePostDraft(title = "", body = "", category = "AC", hasPhotos = true))
        assertNotNull(CommunityDomainHelper.validatePostDraft(title = "Hi", body = "ok", category = "AC", hasPhotos = false))

        val multiPost = CommunityPostCloud(
            photoUrl = "https://example.com/1.jpg",
            photoUrls = listOf("https://example.com/1.jpg", "https://example.com/2.jpg")
        )
        assertEquals(2, multiPost.resolvedPhotoUrls().size)
    }

    @Test
    fun `all three languages provide V2 navigation and online-only labels`() {
        AppLanguage.entries.forEach { lang ->
            val s = StringsProvider.get(lang)
            assertTrue(s.navHome.isNotBlank())
            assertTrue(s.navAc.isNotBlank())
            assertTrue(s.navFridge.isNotBlank())
            assertTrue(s.navCommunity.isNotBlank())
            assertTrue(s.navMore.isNotBlank())
            assertTrue(s.noInternetGuidesMessage.isNotBlank())
            assertTrue(s.technicianVerificationTitle.isNotBlank())
            assertTrue(s.pdfAndDiagramsTitle.isNotBlank())
            assertTrue(s.notificationsTitle.isNotBlank())
        }
    }
}
