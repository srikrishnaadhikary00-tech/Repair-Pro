package com.example

import com.example.data.remote.CommunityDomainHelper
import com.example.data.remote.MultiCloudStorageRouter
import com.example.data.remote.PendingCommunityPhoto
import com.example.data.remote.StorageProviderConfig
import com.example.data.remote.StorageRoutingConfig
import com.example.data.remote.SupabaseClient
import com.example.data.remote.isValidOAuthWebClientId
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MultiCloudAndPushUnitTest {

    @Test
    fun `placeholder detection ignores blank and YOUR_ prefixes`() {
        assertTrue(SupabaseClient.isPlaceholderOrBlank(null))
        assertTrue(SupabaseClient.isPlaceholderOrBlank(""))
        assertTrue(SupabaseClient.isPlaceholderOrBlank("   "))
        assertTrue(SupabaseClient.isPlaceholderOrBlank("YOUR_SUPABASE_ANON_KEY"))
        assertTrue(SupabaseClient.isPlaceholderOrBlank("your_placeholder"))
        assertFalse(SupabaseClient.isPlaceholderOrBlank("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.valid"))

        val client = SupabaseClient()
        assertFalse(client.isConfigured("https://xuakzzjtcgcvudkgxpbd.supabase.co", "YOUR_SUPABASE_ANON_KEY"))
        assertFalse(client.isConfigured("http://insecure.example.com", "valid-key"))
        assertTrue(client.isConfigured("https://xuakzzjtcgcvudkgxpbd.supabase.co", "sb-anon-valid-key"))
    }

    @Test
    fun `oauth web client id validator rejects firebase api keys and placeholders`() {
        assertFalse(isValidOAuthWebClientId(null))
        assertFalse(isValidOAuthWebClientId(""))
        assertFalse(isValidOAuthWebClientId("YOUR_OAUTH_WEB_CLIENT_ID.apps.googleusercontent.com"))
        assertFalse(isValidOAuthWebClientId("AIzaSyDummyFirebaseApiKey1234567890"))
        assertFalse(isValidOAuthWebClientId("1234567890-abcdefg"))
        assertTrue(isValidOAuthWebClientId("548310962148-exampleclientid1234.apps.googleusercontent.com"))
    }

    @Test
    fun `fcm endpoint resolution prevents stale send-fcm-v1 from overriding send-push-notification`() {
        val workingEndpoint = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-push-notification"
        val staleEndpoint = "https://xuakzzjtcgcvudkgxpbd.supabase.co/functions/v1/send-fcm-v1"

        assertEquals(workingEndpoint, SupabaseClient.DEFAULT_FCM_ENDPOINT)
        assertEquals(
            workingEndpoint,
            MultiCloudStorageRouter.resolveEffectiveFcmEndpoint(
                configuredRemoteUrl = staleEndpoint,
                buildConfigUrl = workingEndpoint
            )
        )
        assertEquals(
            workingEndpoint,
            MultiCloudStorageRouter.resolveEffectiveFcmEndpoint(
                configuredRemoteUrl = "",
                buildConfigUrl = workingEndpoint
            )
        )
        assertEquals(
            "https://custom.example.com/push",
            MultiCloudStorageRouter.resolveEffectiveFcmEndpoint(
                configuredRemoteUrl = "https://custom.example.com/push",
                buildConfigUrl = workingEndpoint
            )
        )

        val parsedFromStaleFirestore = MultiCloudStorageRouter.parseRoutingConfig(
            autoFailoverEnabled = true,
            fcmBackendUrl = staleEndpoint,
            providersJson = "",
            buildConfigFcmUrl = workingEndpoint
        )
        assertEquals(workingEndpoint, parsedFromStaleFirestore.fcmBackendUrl)
    }

    @Test
    fun `community photo deduplication skips matching byte hashes and caps at 4`() {
        val bytesA = byteArrayOf(10, 20, 30, 40)
        val bytesB = byteArrayOf(50, 60, 70, 80)
        val bytesC = byteArrayOf(11, 22, 33, 44)
        val bytesD = byteArrayOf(55, 66, 77, 88)
        val bytesE = byteArrayOf(99, 100, 101, 102)

        val hashA = CommunityDomainHelper.sha256Hex(bytesA)
        assertEquals(64, hashA.length)

        val candidates = listOf(
            PendingCommunityPhoto(bytesA),
            PendingCommunityPhoto(bytesA.copyOf()),
            PendingCommunityPhoto(bytesB),
            PendingCommunityPhoto(bytesC),
            PendingCommunityPhoto(bytesD),
            PendingCommunityPhoto(bytesE)
        )
        val (unique, skipped) = CommunityDomainHelper.deduplicatePhotos(
            existingHashes = setOf(CommunityDomainHelper.sha256Hex(bytesB)),
            candidates = candidates,
            maxAllowed = 4
        )
        // bytesA (kept), bytesA duplicate (skipped), bytesB in existingHashes (skipped),
        // bytesC/D/E kept -> 4 unique items up to maxAllowed=4, 2 duplicates skipped
        assertEquals(4, unique.size)
        assertEquals(2, skipped)
        assertTrue(unique[0].bytes.contentEquals(bytesA))
        assertTrue(unique[1].bytes.contentEquals(bytesC))
        assertTrue(unique[2].bytes.contentEquals(bytesD))
        assertTrue(unique[3].bytes.contentEquals(bytesE))
    }

    @Test
    fun `supabase upsertTableRow sends on_conflict and live technicians columns`() = runBlocking {
        var capturedUrl = ""
        var capturedPrefer = ""
        var capturedBody = ""
        val mockHttp = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val req = chain.request()
                capturedUrl = req.url.toString()
                capturedPrefer = req.header("Prefer").orEmpty()
                val buf = Buffer()
                req.body?.writeTo(buf)
                capturedBody = buf.readUtf8()
                Response.Builder()
                    .request(req)
                    .protocol(Protocol.HTTP_1_1)
                    .code(201)
                    .message("Created")
                    .body("".toResponseBody("application/json".toMediaTypeOrNull()))
                    .build()
            })
            .build()

        val rowJson = SupabaseClient.buildLiveTechnicianJson(
            id = "tech_01",
            name = "Arjun Sharma",
            phone = "+919876543210",
            photoUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co/storage/v1/object/public/technician-photos/tech_01.jpg",
            bio = "AC & Inverter specialist",
            specialty = "AC",
            location = "Kolkata"
        )

        val client = SupabaseClient(httpClient = mockHttp, firebaseTokenProvider = { "mock-firebase-jwt" })
        val res = client.upsertTableRowRawJson(
            tableName = "technicians",
            rawJson = rowJson,
            overrideUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
            overrideAnonKey = "test-anon-key",
            onConflict = "id"
        )

        assertTrue(res.isSuccess)
        assertEquals("https://xuakzzjtcgcvudkgxpbd.supabase.co/rest/v1/technicians?on_conflict=id", capturedUrl)
        assertEquals("resolution=merge-duplicates,return=minimal", capturedPrefer)
        assertTrue(capturedBody.contains("\"id\":\"tech_01\""))
        assertTrue(capturedBody.contains("\"name\":\"Arjun Sharma\""))
        assertTrue(capturedBody.contains("\"photo_url\":\"https://xuakzzjtcgcvudkgxpbd.supabase.co/storage/v1/object/public/technician-photos/tech_01.jpg\""))
        assertFalse(capturedBody.contains("technician_id"))
        assertFalse(capturedBody.contains("full_name"))
    }

    @Test
    fun `bucket mapping resolves all 5 repair pro storage buckets`() {
        val provider = StorageProviderConfig()
        assertEquals("community-photos", MultiCloudStorageRouter.resolveBucketName(provider, "community"))
        assertEquals("technician-photos", MultiCloudStorageRouter.resolveBucketName(provider, "technicians"))
        assertEquals("repair-pdfs", MultiCloudStorageRouter.resolveBucketName(provider, "pdfs"))
        assertEquals("circuit-diagrams", MultiCloudStorageRouter.resolveBucketName(provider, "diagrams"))
        assertEquals("verification-documents", MultiCloudStorageRouter.resolveBucketName(provider, "verification"))
    }

    @Test
    fun `parseRoutingConfig fallback and selectOrderedProviders enforce role priority and failover`() {
        val fallback = MultiCloudStorageRouter.parseRoutingConfig(
            autoFailoverEnabled = true,
            fcmBackendUrl = "",
            providersJson = ""
        )
        assertEquals(1, fallback.providers.size)
        assertEquals("supabase_primary", fallback.providers.first().providerId)
        assertEquals(SupabaseClient.DEFAULT_FCM_ENDPOINT, fallback.fcmBackendUrl)

        val routing = StorageRoutingConfig(
            autoFailoverEnabled = true,
            fcmBackendUrl = "https://custom.example.com/fcm",
            providers = listOf(
                StorageProviderConfig(
                    providerId = "r2_backup",
                    providerName = "Cloudflare R2",
                    providerType = StorageProviderConfig.TYPE_CLOUDFLARE_R2,
                    proxyUploadUrl = "https://proxy.example.com/sign",
                    role = StorageProviderConfig.ROLE_BACKUP,
                    enabled = true
                ),
                StorageProviderConfig(
                    providerId = "disabled_s3",
                    providerName = "Disabled S3",
                    providerType = StorageProviderConfig.TYPE_S3_COMPATIBLE,
                    role = StorageProviderConfig.ROLE_DISABLED,
                    enabled = true
                ),
                StorageProviderConfig(
                    providerId = "inactive_gcs",
                    providerName = "Inactive GCS",
                    providerType = StorageProviderConfig.TYPE_GOOGLE_CLOUD_STORAGE,
                    role = StorageProviderConfig.ROLE_BACKUP,
                    enabled = false
                ),
                StorageProviderConfig(
                    providerId = "supabase_primary",
                    providerName = "Supabase Primary",
                    providerType = StorageProviderConfig.TYPE_SUPABASE_STORAGE,
                    endpointUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
                    publicAnonKey = "anon-1",
                    role = StorageProviderConfig.ROLE_PRIMARY,
                    enabled = true
                )
            )
        )

        val orderedWithFailover = MultiCloudStorageRouter.selectOrderedProviders(routing)
        assertEquals(listOf("supabase_primary", "r2_backup"), orderedWithFailover.map { it.providerId })

        val orderedNoFailover = MultiCloudStorageRouter.selectOrderedProviders(
            routing.copy(autoFailoverEnabled = false)
        )
        assertEquals(listOf("supabase_primary"), orderedNoFailover.map { it.providerId })
    }

    @Test
    fun `supabase upload sends auth headers and builds public url`() = runBlocking {
        var capturedUrl = ""
        var capturedApiKey = ""
        var capturedAuth = ""
        val mockHttp = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val req = chain.request()
                capturedUrl = req.url.toString()
                capturedApiKey = req.header("apikey").orEmpty()
                capturedAuth = req.header("Authorization").orEmpty()
                Response.Builder()
                    .request(req)
                    .protocol(Protocol.HTTP_1_1)
                    .code(200)
                    .message("OK")
                    .body("{\"Key\":\"community-photos/u1/img.jpg\"}".toResponseBody("application/json".toMediaTypeOrNull()))
                    .build()
            })
            .build()

        val client = SupabaseClient(httpClient = mockHttp, firebaseTokenProvider = { "mock-firebase-jwt" })
        val validJpegBytes = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(), 0x00, 0x10)
        val result = client.uploadObject(
            bucketName = "community-photos",
            objectPath = "u1/img.jpg",
            bytes = validJpegBytes,
            mimeType = "image/jpeg",
            isPublicBucket = true,
            overrideUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
            overrideAnonKey = "test-anon-key"
        )

        assertTrue(result.isSuccess)
        val upload = result.getOrThrow()
        assertEquals("https://xuakzzjtcgcvudkgxpbd.supabase.co/storage/v1/object/community-photos/u1/img.jpg", capturedUrl)
        assertEquals("test-anon-key", capturedApiKey)
        assertEquals("Bearer mock-firebase-jwt", capturedAuth)
        assertEquals("https://xuakzzjtcgcvudkgxpbd.supabase.co/storage/v1/object/public/community-photos/u1/img.jpg", upload.publicUrl)
    }

    @Test
    fun `router fails over from primary supabase error to backup signed proxy`() = runBlocking {
        val mockHttp = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val req = chain.request()
                val url = req.url.toString()
                when {
                    url.contains("supabase.co/storage/v1/object") -> Response.Builder()
                        .request(req)
                        .protocol(Protocol.HTTP_1_1)
                        .code(507)
                        .message("Insufficient Storage")
                        .body("{\"error\":\"Quota exceeded\"}".toResponseBody("application/json".toMediaTypeOrNull()))
                        .build()

                    url == "https://proxy.example.com/sign" -> Response.Builder()
                        .request(req)
                        .protocol(Protocol.HTTP_1_1)
                        .code(200)
                        .message("OK")
                        .body(
                            "{\"uploadUrl\":\"https://r2-upload.example.com/presigned\",\"publicUrl\":\"https://cdn.example.com/repair-pdfs/manual.pdf\"}"
                                .toResponseBody("application/json".toMediaTypeOrNull())
                        )
                        .build()

                    url == "https://r2-upload.example.com/presigned" -> Response.Builder()
                        .request(req)
                        .protocol(Protocol.HTTP_1_1)
                        .code(200)
                        .message("OK")
                        .body("".toResponseBody("text/plain".toMediaTypeOrNull()))
                        .build()

                    else -> Response.Builder()
                        .request(req)
                        .protocol(Protocol.HTTP_1_1)
                        .code(404)
                        .message("Not Found")
                        .body("".toResponseBody("text/plain".toMediaTypeOrNull()))
                        .build()
                }
            })
            .build()

        val client = SupabaseClient(httpClient = mockHttp, firebaseTokenProvider = { "mock-firebase-jwt" })
        val router = MultiCloudStorageRouter(
            authProvider = { null },
            httpClient = mockHttp,
            supabaseClientOverride = client
        )

        val routingConfig = StorageRoutingConfig(
            autoFailoverEnabled = true,
            providers = listOf(
                StorageProviderConfig(
                    providerId = "supabase_primary",
                    providerType = StorageProviderConfig.TYPE_SUPABASE_STORAGE,
                    endpointUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
                    publicAnonKey = "anon-key",
                    role = StorageProviderConfig.ROLE_PRIMARY,
                    enabled = true
                ),
                StorageProviderConfig(
                    providerId = "r2_backup",
                    providerType = StorageProviderConfig.TYPE_CLOUDFLARE_R2,
                    proxyUploadUrl = "https://proxy.example.com/sign",
                    role = StorageProviderConfig.ROLE_BACKUP,
                    enabled = true
                )
            )
        )
        val ordered = MultiCloudStorageRouter.selectOrderedProviders(routingConfig)
        assertEquals(2, ordered.size)

        // Verify upload via Supabase fails gracefully with 507 and doesn't crash
        val failedPrimary = client.uploadObject(
            bucketName = "repair-pdfs",
            objectPath = "manual.pdf",
            bytes = "%PDF-1.4 test content".toByteArray(),
            mimeType = "application/pdf",
            overrideUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
            overrideAnonKey = "anon-key"
        )
        assertTrue(failedPrimary.isFailure)

        // Verify router completes cleanly when no FirebaseFirestore is initialized (returns default config)
        val loaded = router.loadRoutingConfig()
        assertEquals("supabase_primary", loaded.providers.first().providerId)
    }
}
