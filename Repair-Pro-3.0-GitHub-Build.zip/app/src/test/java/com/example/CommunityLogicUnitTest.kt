package com.example

import com.example.data.remote.CloudTimestamp
import com.example.data.remote.CommunityCommentCloud
import com.example.data.remote.CommunityDomainHelper
import com.example.data.remote.CommunityPostCloud
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommunityLogicUnitTest {

    @Test
    fun validatePostDraft_enforcesTitleBodyAndCategoryRules() {
        assertNotNull(CommunityDomainHelper.validatePostDraft("ab", "Valid description body", "AC"))
        assertNotNull(CommunityDomainHelper.validatePostDraft("Valid Title", "1234", "AC"))
        assertNotNull(CommunityDomainHelper.validatePostDraft("Valid Title", "Valid description body", "Microwave"))
        assertNull(CommunityDomainHelper.validatePostDraft("LG CH05 Outdoor PCB Repair", "Checked communication voltage on pin 3 and replaced optocoupler.", "AC"))
    }

    @Test
    fun validateCommentBody_rejectsBlankAndOversized() {
        assertNotNull(CommunityDomainHelper.validateCommentBody("   "))
        assertNotNull(CommunityDomainHelper.validateCommentBody("x".repeat(1001)))
        assertNull(CommunityDomainHelper.validateCommentBody("Check the 15V DC rail on the outdoor IPM board."))
    }

    @Test
    fun validateReportReason_acceptsKnownReasonsOnly() {
        assertTrue(CommunityDomainHelper.validateReportReason("SPAM"))
        assertTrue(CommunityDomainHelper.validateReportReason("UNSAFE_ADVICE"))
        assertFalse(CommunityDomainHelper.validateReportReason("INVALID_REASON"))
    }

    @Test
    fun buildCommentThreads_groupsNestedRepliesAndFlattensReplyToReplyUnderRoot() {
        val c1 = CommunityCommentCloud(
            id = "c1",
            commentId = "c1",
            postId = "p1",
            parentCommentId = "",
            authorName = "Raju",
            body = "Check outdoor communication wire voltage.",
            createdAt = CloudTimestamp(1000L, 0)
        )
        val r1 = CommunityCommentCloud(
            id = "r1",
            commentId = "r1",
            postId = "p1",
            parentCommentId = "c1",
            replyToAuthorName = "Raju",
            authorName = "Suman",
            body = "Getting pulsing 24V DC, still CH05.",
            createdAt = CloudTimestamp(1100L, 0)
        )
        val r2 = CommunityCommentCloud(
            id = "r2",
            commentId = "r2",
            postId = "p1",
            parentCommentId = "r1", // reply to a reply
            replyToAuthorName = "Suman",
            authorName = "Raju",
            body = "Then test the outdoor optocoupler PC817.",
            createdAt = CloudTimestamp(1200L, 0)
        )
        val c2 = CommunityCommentCloud(
            id = "c2",
            commentId = "c2",
            postId = "p1",
            parentCommentId = "",
            authorName = "Karan",
            body = "Also inspect neutral terminal tightness.",
            createdAt = CloudTimestamp(1050L, 0)
        )

        val threads = CommunityDomainHelper.buildCommentThreads(listOf(r2, c2, r1, c1))
        assertEquals(2, threads.size)
        assertEquals("c1", threads[0].parent.commentId)
        assertEquals(listOf("r1", "r2"), threads[0].replies.map { it.commentId })
        assertEquals("c2", threads[1].parent.commentId)
        assertTrue(threads[1].replies.isEmpty())
    }

    @Test
    fun buildCommentThreads_surfacesOrphanedReplyWhenParentWasDeleted() {
        val orphanReply = CommunityCommentCloud(
            id = "r_orphan",
            commentId = "r_orphan",
            postId = "p1",
            parentCommentId = "deleted_parent_id",
            replyToAuthorName = "FormerAuthor",
            authorName = "Suman",
            body = "Follow-up measurement: 12.1V steady.",
            createdAt = CloudTimestamp(2000L, 0)
        )

        val threads = CommunityDomainHelper.buildCommentThreads(listOf(orphanReply))
        assertEquals(1, threads.size)
        assertEquals("r_orphan", threads[0].parent.commentId)
        assertTrue(threads[0].replies.isEmpty())
    }

    @Test
    fun filterPosts_matchesCategoryAndSearchAcrossFields() {
        val posts = listOf(
            CommunityPostCloud(
                id = "p1",
                postId = "p1",
                category = "AC",
                brandName = "Daikin",
                modelName = "FTKM50",
                errorCode = "U4",
                authorName = "Subrata",
                title = "Indoor-Outdoor signal fault",
                body = "Replaced surge protector on outdoor PCB."
            ),
            CommunityPostCloud(
                id = "p2",
                postId = "p2",
                category = "Refrigerator",
                brandName = "LG",
                modelName = "Frost Free",
                errorCode = "Er FF",
                authorName = "Imran",
                title = "Freezer fan stopped",
                body = "Ice buildup jammed evaporator fan blade."
            )
        )

        assertEquals(1, CommunityDomainHelper.filterPosts(posts, "AC", "").size)
        assertEquals("p2", CommunityDomainHelper.filterPosts(posts, "ALL", "er ff").single().postId)
        assertEquals("p1", CommunityDomainHelper.filterPosts(posts, "ALL", "optocoupler").size.let { if (it == 0) "p1" else "" })
        assertEquals(1, CommunityDomainHelper.filterPosts(posts, "ALL", "daikin").size)
        assertEquals(0, CommunityDomainHelper.filterPosts(posts, "Washing Machine", "").size)
    }
}
