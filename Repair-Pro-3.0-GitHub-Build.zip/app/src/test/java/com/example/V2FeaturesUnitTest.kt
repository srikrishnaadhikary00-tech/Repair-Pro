package com.example

import com.example.ads.AdMobManager
import com.example.data.remote.AnnouncementCloud
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.CommunityDomainHelper
import com.example.data.remote.TechnicianCloud
import com.example.data.remote.UserNotificationCloud
import com.example.data.remote.V2DomainHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V2FeaturesUnitTest {

    @Test
    fun verificationApplicationValidation_enforcesRequiredFields() {
        assertNotNull(
            V2DomainHelper.validateVerificationApplication(
                fullName = "A",
                mobileNumber = "+91 98300 12345",
                fullAddress = "12 Park Street",
                state = "WB",
                district = "Kolkata",
                cityArea = "Park Street",
                pinCode = "700016",
                serviceCategories = listOf("AC")
            )
        )
        assertNotNull(
            V2DomainHelper.validateVerificationApplication(
                fullName = "Arjun Das",
                mobileNumber = "123",
                fullAddress = "12 Park Street",
                state = "WB",
                district = "Kolkata",
                cityArea = "Park Street",
                pinCode = "700016",
                serviceCategories = listOf("AC")
            )
        )
        assertNotNull(
            V2DomainHelper.validateVerificationApplication(
                fullName = "Arjun Das",
                mobileNumber = "+91 98300 12345",
                fullAddress = "12 Park Street",
                state = "WB",
                district = "Kolkata",
                cityArea = "Park Street",
                pinCode = "700016",
                serviceCategories = emptyList()
            )
        )
        assertNull(
            V2DomainHelper.validateVerificationApplication(
                fullName = "Arjun Das",
                mobileNumber = "+91 98300 12345",
                fullAddress = "12 Park Street, Workshop 4",
                state = "West Bengal",
                district = "Kolkata",
                cityArea = "Park Street",
                pinCode = "700016",
                serviceCategories = listOf("AC", "Refrigerator")
            )
        )
    }

    @Test
    fun unreadNotificationCounter_combinesPersonalAndBroadcastUnread() {
        val personal = listOf(
            UserNotificationCloud(id = "n1", notificationId = "n1", isRead = false),
            UserNotificationCloud(id = "n2", notificationId = "n2", isRead = true),
            UserNotificationCloud(id = "n3", notificationId = "n3", isRead = false)
        )
        val broadcasts = listOf(
            AnnouncementCloud(id = "a1", announcementId = "a1"),
            AnnouncementCloud(id = "a2", announcementId = "a2")
        )
        assertEquals(3, V2DomainHelper.countUnreadNotifications(personal, broadcasts, setOf("a1")))
        assertEquals(2, V2DomainHelper.countUnreadNotifications(personal, broadcasts, setOf("a1", "a2")))
    }

    @Test
    fun verifiedTechnicianRecord_requiresVerifiedStatusAndNotBlocked() {
        assertTrue(
            V2DomainHelper.isVerifiedTechnicianRecord(
                TechnicianCloud(verificationStatus = "VERIFIED", blocked = false)
            )
        )
        assertFalse(
            V2DomainHelper.isVerifiedTechnicianRecord(
                TechnicianCloud(verificationStatus = "PENDING", blocked = false)
            )
        )
        assertFalse(
            V2DomainHelper.isVerifiedTechnicianRecord(
                TechnicianCloud(verificationStatus = "VERIFIED", blocked = true)
            )
        )
    }

    @Test
    fun communityPostDraft_allowsPhotoOnlyPosts() {
        assertNull(
            CommunityDomainHelper.validatePostDraft(
                title = "PCB Burn Photo",
                body = "",
                category = "AC",
                hasPhotos = true
            )
        )
        assertNotNull(
            CommunityDomainHelper.validatePostDraft(
                title = "No body no photo",
                body = "",
                category = "AC",
                hasPhotos = false
            )
        )
    }

    @Test
    fun admobManager_respectsRemoteFlagsKillSwitchCategoryToggleAndCooldown() {
        val enabledCfg = AppSettingCloud(
            adsGlobalEnabled = true,
            bannerEnabled = true,
            interstitialEnabled = true,
            emergencyKillSwitch = false,
            testMode = false,
            acAdsEnabled = true,
            fridgeAdsEnabled = false,
            washerAdsEnabled = true,
            interstitialCooldownMin = 5L,
            sessionFrequencyCap = 2L,
            androidBannerId = "ca-app-pub-1111111111111111/2222222222",
            androidInterstitialId = "ca-app-pub-1111111111111111/3333333333"
        )

        assertTrue(AdMobManager.isBannerAllowed(enabledCfg, "ac"))
        assertFalse(AdMobManager.isBannerAllowed(enabledCfg, "fridge"))
        assertFalse(AdMobManager.isBannerAllowed(enabledCfg.copy(emergencyKillSwitch = true), "ac"))
        assertEquals("ca-app-pub-1111111111111111/2222222222", AdMobManager.resolveBannerUnitId(enabledCfg))
        assertEquals(AdMobManager.TEST_BANNER_UNIT_ID, AdMobManager.resolveBannerUnitId(enabledCfg.copy(testMode = true)))

        val now = 1_000_000L
        assertTrue(AdMobManager.isInterstitialAllowed(enabledCfg, "ac", nowMs = now, lastShownMs = 0L, shownInSession = 0))
        // Blocked within 5 min cooldown (300_000 ms)
        assertFalse(AdMobManager.isInterstitialAllowed(enabledCfg, "ac", nowMs = now, lastShownMs = now - 60_000L, shownInSession = 1))
        // Allowed after 5 min cooldown
        assertTrue(AdMobManager.isInterstitialAllowed(enabledCfg, "ac", nowMs = now, lastShownMs = now - 301_000L, shownInSession = 1))
        // Blocked once session cap (2) is reached
        assertFalse(AdMobManager.isInterstitialAllowed(enabledCfg, "ac", nowMs = now, lastShownMs = now - 400_000L, shownInSession = 2))
    }
}
