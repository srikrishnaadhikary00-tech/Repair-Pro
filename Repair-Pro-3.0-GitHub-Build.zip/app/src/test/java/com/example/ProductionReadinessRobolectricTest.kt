package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.DownloadedDocumentEntity
import com.example.data.local.RepairProDatabase
import com.example.data.local.SeedDataPart1
import com.example.data.local.SeedDataPart2
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.BackendConnectionStatus
import com.example.data.remote.CommunityPostItem
import com.example.data.remote.StorageProviderItem
import com.example.data.remote.TechnicianProfileItem
import com.example.ui.screens.SuperAdminScreen
import com.example.ui.theme.RepairProTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h2600dp")
class ProductionReadinessRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `room MIGRATION_1_2 preserves existing v1 user data and creates downloaded_documents`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbName = "migration_test_repair_pro.db"
        context.deleteDatabase(dbName)

        // 1. Create a v1 SQLite database manually with pre-v2 tables and insert user records
        val v1Helper = object : SQLiteOpenHelper(context, dbName, null, 1) {
            override fun onCreate(db: SQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `appliance_categories` (`id` TEXT NOT NULL, `nameEn` TEXT NOT NULL, `nameBn` TEXT NOT NULL, `nameHi` TEXT NOT NULL, `subtitleEn` TEXT NOT NULL, `subtitleBn` TEXT NOT NULL, `subtitleHi` TEXT NOT NULL, `iconKey` TEXT NOT NULL, `downloaded` INTEGER NOT NULL, `lastSyncedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `brands` (`id` TEXT NOT NULL, `categoryId` TEXT NOT NULL, `name` TEXT NOT NULL, `popular` INTEGER NOT NULL, `modelsCsv` TEXT NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `error_codes` (`id` TEXT NOT NULL, `categoryId` TEXT NOT NULL, `brandId` TEXT NOT NULL, `brandName` TEXT NOT NULL, `modelSeries` TEXT NOT NULL, `code` TEXT NOT NULL, `titleEn` TEXT NOT NULL, `titleBn` TEXT NOT NULL, `titleHi` TEXT NOT NULL, `meaningEn` TEXT NOT NULL, `meaningBn` TEXT NOT NULL, `meaningHi` TEXT NOT NULL, `symptomsEn` TEXT NOT NULL, `symptomsBn` TEXT NOT NULL, `symptomsHi` TEXT NOT NULL, `causesEn` TEXT NOT NULL, `causesBn` TEXT NOT NULL, `causesHi` TEXT NOT NULL, `diagnosticsEn` TEXT NOT NULL, `diagnosticsBn` TEXT NOT NULL, `diagnosticsHi` TEXT NOT NULL, `solutionsEn` TEXT NOT NULL, `solutionsBn` TEXT NOT NULL, `solutionsHi` TEXT NOT NULL, `safetyWarningEn` TEXT NOT NULL, `safetyWarningBn` TEXT NOT NULL, `safetyWarningHi` TEXT NOT NULL, `sourceDocumentation` TEXT NOT NULL, `verificationStatus` TEXT NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `problem_guides` (`id` TEXT NOT NULL, `categoryId` TEXT NOT NULL, `iconKey` TEXT NOT NULL, `titleEn` TEXT NOT NULL, `titleBn` TEXT NOT NULL, `titleHi` TEXT NOT NULL, `symptomsEn` TEXT NOT NULL, `symptomsBn` TEXT NOT NULL, `symptomsHi` TEXT NOT NULL, `causesEn` TEXT NOT NULL, `causesBn` TEXT NOT NULL, `causesHi` TEXT NOT NULL, `safeStepsEn` TEXT NOT NULL, `safeStepsBn` TEXT NOT NULL, `safeStepsHi` TEXT NOT NULL, `recommendedSolutionEn` TEXT NOT NULL, `recommendedSolutionBn` TEXT NOT NULL, `recommendedSolutionHi` TEXT NOT NULL, `requiredTools` TEXT NOT NULL, `relatedErrorCodes` TEXT NOT NULL, `safetyWarningEn` TEXT NOT NULL, `safetyWarningBn` TEXT NOT NULL, `safetyWarningHi` TEXT NOT NULL, `technicianCriteriaEn` TEXT NOT NULL, `technicianCriteriaBn` TEXT NOT NULL, `technicianCriteriaHi` TEXT NOT NULL, `sourceDocumentation` TEXT NOT NULL, `verificationStatus` TEXT NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `search_history` (`query` TEXT NOT NULL, `categoryId` TEXT, `timestamp` INTEGER NOT NULL, PRIMARY KEY(`query`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `offline_packages` (`categoryId` TEXT NOT NULL, `packageName` TEXT NOT NULL, `version` INTEGER NOT NULL, `recordCount` INTEGER NOT NULL, `sizeKb` INTEGER NOT NULL, `downloaded` INTEGER NOT NULL, `lastUpdatedAt` INTEGER NOT NULL, PRIMARY KEY(`categoryId`))"
                )
            }

            override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
        }
        v1Helper.writableDatabase.use { sqlDb ->
            sqlDb.execSQL("INSERT INTO `appliance_categories` VALUES ('ac', 'Air Conditioner', 'এসি', 'एसी', 'AC Repair', 'এসি মেরামত', 'एसी मरम्मत', 'ac', 1, 1000)")
            sqlDb.execSQL("INSERT INTO `search_history` VALUES ('CH05', 'ac', 123456)")
            sqlDb.execSQL("INSERT INTO `offline_packages` VALUES ('ac', 'AC Pack', 1, 10, 50, 1, 1000)")
        }
        v1Helper.close()

        // 2. Open with Room at version 2 using MIGRATION_1_2 (no destructive fallback!)
        val db = Room.databaseBuilder(context, RepairProDatabase::class.java, dbName)
            .addMigrations(RepairProDatabase.MIGRATION_1_2)
            .allowMainThreadQueries()
            .build()
        try {
            val dao = db.repairDao()
            // Verify v1 rows were preserved intact
            val cats = dao.observeCategories().first()
            assertEquals(1, cats.size)
            assertEquals("ac", cats.first().id)

            val history = dao.observeSearchHistory().first()
            assertEquals(1, history.size)
            assertEquals("CH05", history.first().query)

            // Verify newly migrated downloaded_documents table works cleanly
            dao.upsertDownloadedDocument(
                DownloadedDocumentEntity(
                    docId = "doc_1",
                    title = "LG Inverter Service Manual",
                    docType = "PDF",
                    categoryId = "ac",
                    brandName = "LG",
                    modelName = "Dual Inverter",
                    localFilePath = "/tmp/lg_manual.pdf",
                    mimeType = "application/pdf",
                    fileSizeBytes = 4096L,
                    downloadedAt = 2000L
                )
            )
            val docs = dao.observeDownloadedDocuments().first()
            assertEquals(1, docs.size)
            assertEquals("LG Inverter Service Manual", docs.first().title)
        } finally {
            db.close()
            context.deleteDatabase(dbName)
        }
    }

    @Test
    fun `admin panel handles moderation, multi-cloud actions, migration, delete guard, private ID inspection, and failover`() {
        var moderatedStatus: String? = null
        var lastStorageAction: Pair<String, String>? = null
        var lastMigration: Pair<String, String>? = null
        var testedProviderId: String? = null
        var inspectedTechId: String? = null
        var savedFailoverFlag: Boolean? = null

        val primaryProvider = StorageProviderItem(
            id = "supabase_primary",
            name = "Supabase Primary",
            providerType = "SUPABASE",
            endpointUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
            projectRef = "xuakzzjtcgcvudkgxpbd",
            secretEnvKey = "SUPABASE_SERVICE_ROLE_KEY",
            secretConfigured = true,
            activeFilesCount = 2,
            primary = true,
            backup = false,
            enabled = true,
            autoFailoverEnabled = true
        )
        val backupProvider = StorageProviderItem(
            id = "r2_backup",
            name = "Cloudflare R2",
            providerType = "CLOUDFLARE_R2",
            endpointUrl = "https://r2.example.com",
            projectRef = "repair-pro-bucket",
            secretEnvKey = "R2_STORAGE_CREDS",
            secretConfigured = false,
            activeFilesCount = 3,
            primary = false,
            backup = false,
            enabled = true,
            autoFailoverEnabled = true
        )
        val post = CommunityPostItem(
            id = "post_1",
            authorUid = "u1",
            authorName = "Tech Hasan",
            categoryId = "ac",
            title = "Daikin U4 Signal Fix",
            body = "Checked F1/F2 wiring continuity.",
            moderationStatus = "PENDING"
        )
        val tech = TechnicianProfileItem(
            id = "tech_1",
            firebaseUid = "u_tech_1",
            fullName = "Rahim Technician",
            city = "Dhaka",
            serviceLocation = "Mirpur",
            experienceYears = 6,
            publicPhone = "+8801700000000",
            applianceCategories = listOf("ac", "fridge"),
            approvalStatus = "PENDING",
            verified = false
        )

        composeRule.setContent {
            RepairProTheme {
                SuperAdminScreen(
                    isAdmin = true,
                    isBootstrapAdmin = true,
                    adminRoleChecked = true,
                    currentUserUid = "admin_1",
                    adminEmail = "admin@repairpro.app",
                    categories = SeedDataPart1.categories,
                    brands = SeedDataPart1.brands,
                    totalModels = 42,
                    errorCodes = SeedDataPart1.acErrorCodes,
                    problems = SeedDataPart2.fridgeAndWasherProblems,
                    allReports = emptyList(),
                    allCatalog = emptyList(),
                    auditLogs = emptyList(),
                    adminRoles = emptyList(),
                    adMobConfig = AppSettingCloud(id = "admob_config", configType = "ADMOB"),
                    globalConfig = AppSettingCloud(id = "global_config", configType = "GLOBAL", storageAutoFailover = true),
                    syncInProgress = false,
                    onBack = {},
                    onUpdateReportStatus = { _, _, _ -> },
                    onPublishCatalogEntry = { _, done -> done() },
                    onDeleteCatalogEntry = {},
                    onSaveAdMobConfig = {},
                    onSaveGlobalConfig = { _, _, _ -> },
                    onSyncOfflineNow = {},
                    onUpsertAdminRole = { _, _ -> },
                    onRevokeAdminRole = {},
                    onExportBackupJson = { "{}" },
                    adminTechnicians = listOf(tech),
                    adminCommunityPosts = listOf(post),
                    adminStorageProviders = listOf(primaryProvider, backupProvider),
                    backendStatus = BackendConnectionStatus(firebaseConnected = true, supabaseReachable = true),
                    onModerateCommunityPost = { _, status -> moderatedStatus = status },
                    onTestStorageProvider = { testedProviderId = it.id },
                    onStorageAction = { p, action -> lastStorageAction = p.id to action },
                    onMigrateStorageProvider = { src, targetId -> lastMigration = src.id to targetId },
                    onInspectVerificationDoc = { techId, _ -> inspectedTechId = techId },
                    onSaveGlobalFailover = { _, _, _, failover -> savedFailoverFlag = failover }
                )
            }
        }
        composeRule.waitForIdle()

        // 1. Community moderation Reject/Hide emits REJECTED (not HIDDEN) to satisfy firestore.rules
        composeRule.onNodeWithTag("admin_tab_9").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Reject / Hide").performClick()
        composeRule.waitForIdle()
        assertEquals("REJECTED", moderatedStatus)

        // 2. Technicians tab includes private ID inspection trigger ("Inspect ID")
        composeRule.onNodeWithTag("admin_tab_8").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Inspect ID").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        assertEquals("tech_1", inspectedTechId)

        // 3. Multi-Cloud Storage tab: no CLOUDINARY, forwards actions, disables delete while activeFilesCount > 0, and triggers migration
        composeRule.onNodeWithTag("admin_tab_11").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("CLOUDINARY").assertDoesNotExist()
        composeRule.onNodeWithText("Sync Registry").assertIsDisplayed()
        composeRule.onNodeWithText("Delete (3 files)").assertIsNotEnabled()

        composeRule.onNodeWithText("Set Primary").performClick()
        composeRule.waitForIdle()
        assertEquals("r2_backup" to "SET_PRIMARY", lastStorageAction)

        composeRule.onNodeWithText("Set Backup").performClick()
        composeRule.waitForIdle()
        assertEquals("r2_backup" to "SET_BACKUP", lastStorageAction)

        composeRule.onAllNodesWithText("Test Connection")[0].performClick()
        composeRule.waitForIdle()
        assertEquals("supabase_primary", testedProviderId)

        composeRule.onNodeWithText("Migrate → Cloudflare R2").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals("supabase_primary" to "r2_backup", lastMigration)

        // 4. Offline & Sync tab allows toggling Multi-Cloud Automatic Failover and saving
        composeRule.onNodeWithTag("admin_tab_5").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_storage_failover_switch").performClick()
        composeRule.onNodeWithTag("admin_save_global_settings").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals(false, savedFailoverFlag)
        assertFalse(moderatedStatus == "HIDDEN")
    }
}
