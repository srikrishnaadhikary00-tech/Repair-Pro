package com.example

import com.example.data.remote.AiConfigCloud
import com.example.data.remote.BillingConfigCloud
import com.example.data.remote.BillingDomainHelper
import com.example.data.remote.MultiCloudStorageRouter
import com.example.data.remote.Phase2ConfigParser
import com.example.data.remote.StorageProviderConfig
import com.example.data.remote.StorageRoutingConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Phase2BillingAndAiUnitTest {

    @Test
    fun `calculateTotalBill returns null when no charge is entered`() {
        val total = BillingDomainHelper.calculateTotalBill(
            partsCharges = null,
            serviceCharges = null,
            visitingCharges = null,
            otherCharges = null,
            discountAmount = null
        )
        assertNull(total)
        assertNull(BillingDomainHelper.calculateRemainingBalance(null, 0.0))
        assertEquals(
            BillingDomainHelper.STATUS_AMOUNT_NOT_ENTERED,
            BillingDomainHelper.resolvePaymentStatus(null, null)
        )
    }

    @Test
    fun `billing totals remaining balance and statuses calculate accurately`() {
        val total = BillingDomainHelper.calculateTotalBill(
            partsCharges = 1200.0,
            serviceCharges = 500.0,
            visitingCharges = 200.0,
            otherCharges = 100.0,
            discountAmount = 250.0
        )
        assertEquals(1750.0, total!!, 0.001)

        assertEquals(1750.0, BillingDomainHelper.calculateRemainingBalance(total, null)!!, 0.001)
        assertEquals(BillingDomainHelper.STATUS_UNPAID, BillingDomainHelper.resolvePaymentStatus(total, 0.0))

        assertEquals(750.0, BillingDomainHelper.calculateRemainingBalance(total, 1000.0)!!, 0.001)
        assertEquals(BillingDomainHelper.STATUS_PARTIALLY_PAID, BillingDomainHelper.resolvePaymentStatus(total, 1000.0))

        assertEquals(0.0, BillingDomainHelper.calculateRemainingBalance(total, 1750.0)!!, 0.001)
        assertEquals(BillingDomainHelper.STATUS_FULLY_PAID, BillingDomainHelper.resolvePaymentStatus(total, 1750.0))
    }

    @Test
    fun `customer and invoice validation requires only name and valid mobile`() {
        val ok = BillingDomainHelper.validateCustomerAndInvoiceInput(
            customerName = "Ramesh Das",
            customerMobile = "+91 98300 12345",
            partsCharges = null,
            serviceCharges = null,
            visitingCharges = null,
            otherCharges = null,
            discountAmount = null,
            amountReceived = null
        )
        assertNull(ok)

        val blankName = BillingDomainHelper.validateCustomerAndInvoiceInput(
            customerName = "  ",
            customerMobile = "9830012345",
            partsCharges = null,
            serviceCharges = null,
            visitingCharges = null,
            otherCharges = null,
            discountAmount = null,
            amountReceived = null
        )
        assertNotNull(blankName)

        val invalidMobile = BillingDomainHelper.validateCustomerAndInvoiceInput(
            customerName = "Ramesh Das",
            customerMobile = "123",
            partsCharges = null,
            serviceCharges = null,
            visitingCharges = null,
            otherCharges = null,
            discountAmount = null,
            amountReceived = null
        )
        assertNotNull(invalidMobile)

        val negativeCharge = BillingDomainHelper.validateCustomerAndInvoiceInput(
            customerName = "Ramesh Das",
            customerMobile = "9830012345",
            partsCharges = -10.0,
            serviceCharges = null,
            visitingCharges = null,
            otherCharges = null,
            discountAmount = null,
            amountReceived = null
        )
        assertNotNull(negativeCharge)
    }

    @Test
    fun `payment validation blocks zero negative overpayment and duplicate idempotency key`() {
        assertNotNull(BillingDomainHelper.validateNewPayment(0.0, 500.0, emptySet(), "k1"))
        assertNotNull(BillingDomainHelper.validateNewPayment(-50.0, 500.0, emptySet(), "k1"))
        assertNotNull(BillingDomainHelper.validateNewPayment(600.0, 500.0, emptySet(), "k1"))
        assertNotNull(BillingDomainHelper.validateNewPayment(200.0, 500.0, setOf("k1"), "k1"))
        assertNull(BillingDomainHelper.validateNewPayment(200.0, 500.0, setOf("k1"), "k2"))
    }

    @Test
    fun `reminder eligibility and multilingual templates render cleanly without automatic send`() {
        assertFalse(BillingDomainHelper.canSendReminder(BillingDomainHelper.STATUS_FULLY_PAID, 0.0, true))
        assertFalse(BillingDomainHelper.canSendReminder(BillingDomainHelper.STATUS_AMOUNT_NOT_ENTERED, null, true))
        assertFalse(BillingDomainHelper.canSendReminder(BillingDomainHelper.STATUS_UNPAID, 450.0, false))
        assertTrue(BillingDomainHelper.canSendReminder(BillingDomainHelper.STATUS_PARTIALLY_PAID, 450.0, true))

        val cfg = BillingConfigCloud()
        val msgEn = BillingDomainHelper.buildReminderMessage(
            languageCode = "en",
            billingConfig = cfg,
            customerName = "Anil Kumar",
            invoiceNumber = "RP-20261126-A1B2",
            applianceSummary = "AC LG",
            totalBill = 1500.0,
            amountReceived = 500.0,
            remainingBalance = 1000.0,
            dueDate = "2026-12-01"
        )
        assertTrue(msgEn.contains("Anil Kumar"))
        assertTrue(msgEn.contains("RP-20261126-A1B2"))
        assertTrue(msgEn.contains("₹1000"))

        val msgBn = BillingDomainHelper.buildReminderMessage(
            languageCode = "bn",
            billingConfig = cfg,
            customerName = "সুব্রত পাল",
            invoiceNumber = "RP-20261126-B9C8",
            applianceSummary = "Refrigerator",
            totalBill = 2000.0,
            amountReceived = 800.0,
            remainingBalance = 1200.0,
            dueDate = "2026-12-05"
        )
        assertTrue(msgBn.contains("সুব্রত পাল"))
        assertTrue(msgBn.contains("₹1200"))

        val waUri = BillingDomainHelper.buildWhatsAppUriString("9830012345", msgEn)
        assertTrue(waUri.startsWith("https://wa.me/919830012345?text="))
        val smsUri = BillingDomainHelper.buildSmsUriString("+91 98300 12345")
        assertTrue(smsUri.startsWith("smsto:"))
    }

    @Test
    fun `phase2 config parser parses AI and Billing remote configs safely`() {
        val aiMap = mapOf<String, Any?>(
            "aiEnabled" to false,
            "showAiNavItem" to false,
            "aiProvider" to "OPENAI_COMPATIBLE",
            "aiModel" to "gpt-4o-mini",
            "aiDailyLimit" to 250L,
            "aiPerUserLimit" to 10L,
            "aiSupportedAppliances" to listOf("Air Conditioner", "Washing Machine"),
            "aiSupportedLanguages" to listOf("en", "bn"),
            "aiBrandsModelsJson" to """{"Air Conditioner":["Daikin","Voltas"],"Washing Machine":["IFB"]}"""
        )
        val parsedAi = Phase2ConfigParser.parseAiConfigFromMap(aiMap)
        assertFalse(parsedAi.aiEnabled)
        assertFalse(parsedAi.showAiNavItem)
        assertEquals("OPENAI_COMPATIBLE", parsedAi.aiProvider)
        assertEquals("gpt-4o-mini", parsedAi.aiModel)
        assertEquals(250, parsedAi.aiDailyLimit)
        assertEquals(10, parsedAi.aiPerUserLimit)
        assertEquals(listOf("Air Conditioner", "Washing Machine"), parsedAi.aiSupportedAppliances)
        assertEquals(listOf("Daikin", "Voltas"), parsedAi.brandsMap()["Air Conditioner"])

        val defaultAi = Phase2ConfigParser.parseAiConfigFromMap(null)
        assertTrue(defaultAi.aiEnabled)
        assertEquals(AiConfigCloud.DEFAULT_AI_PROXY_URL, defaultAi.aiProxyEndpoint)

        val billingMap = mapOf<String, Any?>(
            "invoiceEnabled" to true,
            "whatsappReminderEnabled" to false,
            "smsReminderEnabled" to true,
            "invoiceBusinessTitle" to "CoolTech Repair Services",
            "reminderTemplatesJson" to """{"hi":"नमस्ते {customerName}, बकाया {remainingBalance}"}""",
            "billingSupportedLanguages" to listOf("hi", "en")
        )
        val parsedBilling = Phase2ConfigParser.parseBillingConfigFromMap(billingMap)
        assertTrue(parsedBilling.invoiceEnabled)
        assertFalse(parsedBilling.whatsappReminderEnabled)
        assertTrue(parsedBilling.smsReminderEnabled)
        assertEquals("CoolTech Repair Services", parsedBilling.invoiceBusinessTitle)
        assertEquals("नमस्ते {customerName}, बकाया {remainingBalance}", parsedBilling.templateFor("hi"))
    }

    @Test
    fun `php shared hosting communityOnly excludes private buckets and clamps compression bounds`() {
        val phpCommunity = StorageProviderConfig(
            providerId = "php_hostinger",
            providerName = "Hostinger PHP",
            providerType = StorageProviderConfig.TYPE_PHP_HOSTING,
            endpointUrl = "https://media.example.com/repairpro-api/index.php",
            communityOnly = true,
            role = StorageProviderConfig.ROLE_PRIMARY,
            enabled = true
        )
        val supaBackup = StorageProviderConfig(
            providerId = "supabase_primary",
            providerName = "Supabase",
            providerType = StorageProviderConfig.TYPE_SUPABASE_STORAGE,
            endpointUrl = "https://xuakzzjtcgcvudkgxpbd.supabase.co",
            publicAnonKey = "anon",
            role = StorageProviderConfig.ROLE_BACKUP,
            enabled = true
        )
        val config = StorageRoutingConfig(
            autoFailoverEnabled = true,
            compressionMaxDim = 9000,
            compressionQuality = 10,
            compressionMaxSizeKb = 99999,
            providers = listOf(phpCommunity, supaBackup)
        )

        val communityOrder = MultiCloudStorageRouter.selectOrderedProvidersForBucket(config, "community")
        assertEquals(listOf("php_hostinger", "supabase_primary"), communityOrder.map { it.providerId })

        val verificationOrder = MultiCloudStorageRouter.selectOrderedProvidersForBucket(config, "verification")
        assertEquals(listOf("supabase_primary"), verificationOrder.map { it.providerId })

        val pdfOrder = MultiCloudStorageRouter.selectOrderedProvidersForBucket(config, "pdfs")
        assertEquals(listOf("supabase_primary"), pdfOrder.map { it.providerId })

        val clamped = MultiCloudStorageRouter.parseRoutingConfig(
            autoFailoverEnabled = true,
            fcmBackendUrl = "",
            providersJson = "",
            compressionMaxDim = 99999,
            compressionQuality = 5,
            compressionMaxSizeKb = 50,
            duplicateCheckEnabled = false
        )
        assertEquals(4096, clamped.compressionMaxDim)
        assertEquals(40, clamped.compressionQuality)
        assertEquals(100, clamped.compressionMaxSizeKb)
        assertFalse(clamped.duplicateCheckEnabled)
    }

    @Test
    fun `multi-provider AI orders primary secondary backup and blocks paid models in free only mode`() {
        val providersJson = """
            [
              {"providerId":"openrouter_free","label":"OpenRouter Free","providerType":"OPENROUTER","role":"BACKUP","enabled":true,"isFree":true,"adminPaidApproved":false,"endpointUrl":"https://openrouter.ai/api/v1/chat/completions","model":"meta-llama/llama-3.3-70b-instruct:free","dailyLimit":200,"perUserLimit":10},
              {"providerId":"paid_openai","label":"Paid GPT-4o-mini","providerType":"OPENAI_COMPATIBLE","role":"PRIMARY","enabled":true,"isFree":false,"adminPaidApproved":true,"endpointUrl":"https://api.openai.com/v1/chat/completions","model":"gpt-4o-mini","dailyLimit":100,"perUserLimit":5},
              {"providerId":"groq_free","label":"Groq Free","providerType":"GROQ","role":"SECONDARY","enabled":true,"isFree":true,"adminPaidApproved":false,"endpointUrl":"https://api.groq.com/openai/v1/chat/completions","model":"llama-3.3-70b-versatile","dailyLimit":400,"perUserLimit":15},
              {"providerId":"openrouter_paid_model","label":"OpenRouter Non-Free Model","providerType":"OPENROUTER","role":"SECONDARY","enabled":true,"isFree":true,"adminPaidApproved":false,"endpointUrl":"https://openrouter.ai/api/v1/chat/completions","model":"openai/gpt-4o","dailyLimit":200,"perUserLimit":10},
              {"providerId":"gemini_free","label":"Google Gemini Free","providerType":"GEMINI","role":"PRIMARY","enabled":true,"isFree":true,"adminPaidApproved":false,"endpointUrl":"https://generativelanguage.googleapis.com","model":"gemini-2.5-flash","dailyLimit":500,"perUserLimit":15},
              {"providerId":"groq_disabled","label":"Disabled Groq","providerType":"GROQ","role":"BACKUP","enabled":false,"isFree":true,"adminPaidApproved":false,"endpointUrl":"https://api.groq.com/openai/v1/chat/completions","model":"llama-3.3-70b-versatile","dailyLimit":400,"perUserLimit":15}
            ]
        """.trimIndent()

        val freeOnlyConfig = Phase2ConfigParser.parseAiConfigFromMap(
            mapOf(
                "aiEnabled" to true,
                "aiFreeOnlyMode" to true,
                "aiAllowPaidFallback" to true,
                "aiAutoFailoverEnabled" to true,
                "aiProvider" to "GROQ",
                "aiProvidersJson" to providersJson
            )
        )
        assertTrue(freeOnlyConfig.aiFreeOnlyMode)
        assertEquals("GROQ", freeOnlyConfig.aiProvider)

        val eligibleFreeOrder = freeOnlyConfig.approvedOrderedProviders()
        assertEquals(
            listOf("gemini_free", "groq_free", "openrouter_free"),
            eligibleFreeOrder.map { it.providerId }
        )

        // When Free Only Mode is disabled, paid models STILL require both aiAllowPaidFallback=true and adminPaidApproved=true
        val paidUnapproved = freeOnlyConfig.copy(aiFreeOnlyMode = false, aiAllowPaidFallback = false)
        assertFalse(paidUnapproved.approvedOrderedProviders().any { it.providerId == "paid_openai" })

        val paidExplicitlyAuthorized = freeOnlyConfig.copy(aiFreeOnlyMode = false, aiAllowPaidFallback = true)
        assertTrue(paidExplicitlyAuthorized.approvedOrderedProviders().any { it.providerId == "paid_openai" })

        // When auto failover is disabled, only the highest priority approved provider is selected
        val singleOnly = freeOnlyConfig.copy(aiAutoFailoverEnabled = false)
        assertEquals(listOf("gemini_free"), singleOnly.approvedOrderedProviders().map { it.providerId })
    }
}
