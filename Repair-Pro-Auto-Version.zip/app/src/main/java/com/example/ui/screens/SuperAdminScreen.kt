package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AdsClick
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.BrandEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.remote.AdminRoleCloud
import com.example.data.remote.AnnouncementCloud
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.AuditLogCloud
import com.example.data.remote.CatalogEntryCloud
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.CommunityReportCloud
import com.example.data.remote.CommunityUserRestrictionCloud
import com.example.data.remote.ProblemReportCloud
import com.example.data.remote.TechnicalDocumentCloud
import com.example.data.remote.TechnicianCloud
import com.example.data.remote.TechnicianVerificationRequestCloud
import com.example.data.remote.V2DomainHelper
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

private data class AdminNavItem(val label: String, val icon: ImageVector)

@Composable
fun SuperAdminScreen(
    isAdmin: Boolean,
    isBootstrapAdmin: Boolean,
    adminRoleChecked: Boolean,
    currentUserUid: String,
    adminEmail: String,
    categories: List<ApplianceCategoryEntity>,
    brands: List<BrandEntity>,
    totalModels: Int,
    errorCodes: List<ErrorCodeEntity>,
    problems: List<ProblemGuideEntity>,
    allReports: List<ProblemReportCloud>,
    allCatalog: List<CatalogEntryCloud>,
    auditLogs: List<AuditLogCloud>,
    adminRoles: List<AdminRoleCloud>,
    adMobConfig: AppSettingCloud,
    globalConfig: AppSettingCloud,
    isSubmittingMedia: Boolean = false,
    uploadProgress: Float? = null,
    onBack: () -> Unit,
    onUpdateReportStatus: (reportId: String, status: String, note: String) -> Unit,
    onPublishCatalogEntry: (CatalogEntryCloud, onDone: () -> Unit) -> Unit,
    onUploadCatalogMedia: (
        categoryId: String,
        prefix: String,
        bytes: ByteArray,
        mimeType: String,
        onUploaded: (url: String, storagePath: String) -> Unit
    ) -> Unit = { _, _, _, _, _ -> },
    onDeleteCatalogEntry: (String) -> Unit,
    onSaveAdMobConfig: (AppSettingCloud) -> Unit,
    onSaveGlobalConfig: (announcement: String, maintenanceNotice: String, minVersion: String) -> Unit,
    onUpsertAdminRole: (targetUid: String, role: String) -> Unit,
    onRevokeAdminRole: (targetUid: String) -> Unit,
    onExportBackupJson: () -> String,
    allTechnicians: List<TechnicianCloud> = emptyList(),
    onSaveTechnician: (TechnicianCloud, ByteArray?, String, () -> Unit) -> Unit = { _, _, _, _ -> },
    onToggleTechnicianStatus: (TechnicianCloud) -> Unit = {},
    onDeleteTechnician: (TechnicianCloud) -> Unit = {},
    allCommunityPosts: List<CommunityPostCloud> = emptyList(),
    allCommunityReports: List<CommunityReportCloud> = emptyList(),
    communityRestrictions: List<CommunityUserRestrictionCloud> = emptyList(),
    onModerateCommunityPost: (postId: String, newStatus: String, note: String, authorUid: String, postTitle: String) -> Unit = { _, _, _, _, _ -> },
    onTogglePinCommunityPost: (postId: String, pinned: Boolean) -> Unit = { _, _ -> },
    onSetCommunityUserBlocked: (targetUid: String, userName: String, blocked: Boolean, reason: String) -> Unit = { _, _, _, _ -> },
    onDeleteCommunityPost: (CommunityPostCloud) -> Unit = {},
    onUpdateCommunityReportStatus: (reportId: String, newStatus: String, note: String) -> Unit = { _, _, _ -> },
    verificationRequests: List<TechnicianVerificationRequestCloud> = emptyList(),
    onReviewVerification: (TechnicianVerificationRequestCloud, String, String) -> Unit = { _, _, _ -> },
    technicalDocuments: List<TechnicalDocumentCloud> = emptyList(),
    onUploadTechnicalDocument: (
        docType: String,
        categoryId: String,
        brandName: String,
        modelName: String,
        linkedEntryId: String,
        title: String,
        description: String,
        fileBytes: ByteArray,
        mimeType: String,
        published: Boolean,
        onDone: () -> Unit
    ) -> Unit = { _, _, _, _, _, _, _, _, _, _, _ -> },
    onDeleteTechnicalDocument: (TechnicalDocumentCloud) -> Unit = {},
    announcements: List<AnnouncementCloud> = emptyList(),
    onPublishAnnouncement: (title: String, body: String, category: String, targetRoute: String, onDone: () -> Unit) -> Unit = { _, _, _, _, _ -> },
    onDeleteAnnouncement: (String) -> Unit = {},
    onOpenImageViewer: (url: String, title: String) -> Unit = { _, _ -> },
    onOpenPdfViewer: (url: String, title: String) -> Unit = { _, _ -> }
) {
    if (!adminRoleChecked && !isAdmin) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(color = CyanAccent)
                Text("Verifying server-side Super Admin role…", style = MaterialTheme.typography.bodyMedium, color = TextSecondarySlate)
            }
        }
        return
    }

    if (!isAdmin) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .testTag("admin_access_denied_view"),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = ErrorCrimson, modifier = Modifier.size(52.dp))
                Text("Super Admin access required", style = MaterialTheme.typography.titleLarge, color = TextPrimaryWhite)
                Text(
                    text = "Signed in as $adminEmail (UID: $currentUserUid). Your account does not have an authorized Firestore admin role.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate
                )
                Button(onClick = onBack, modifier = Modifier.testTag("admin_denied_back_button")) {
                    Text("Return to User App")
                }
            }
        }
        return
    }

    val navItems = listOf(
        AdminNavItem("Dashboard", Icons.Filled.Dashboard),
        AdminNavItem("Appliances", Icons.Filled.Category),
        AdminNavItem("Catalog & Guides", Icons.Filled.Inventory2),
        AdminNavItem("Reports", Icons.Filled.ReportProblem),
        AdminNavItem("AdMob Ads", Icons.Filled.AdsClick),
        AdminNavItem("App Settings", Icons.Filled.Tune),
        AdminNavItem("Roles & Logs", Icons.AutoMirrored.Filled.FactCheck),
        AdminNavItem("Technicians", Icons.Filled.Engineering),
        AdminNavItem("Community", Icons.Filled.Forum),
        AdminNavItem("Verifications", Icons.Filled.VerifiedUser),
        AdminNavItem("PDFs & Diagrams", Icons.Filled.Description),
        AdminNavItem("Notifications", Icons.Filled.Campaign)
    )
    var activeSection by remember { mutableIntStateOf(0) }
    var editingEntry by remember { mutableStateOf<CatalogEntryCloud?>(null) }
    var catalogDefaultCat by remember { mutableStateOf("ac") }
    var catalogDefaultType by remember { mutableStateOf("ERROR_CODE") }
    var catalogFilterCat by remember { mutableStateOf("all") }
    var reportFilterCat by remember { mutableStateOf("all") }
    var editingTech by remember { mutableStateOf<TechnicianCloud?>(null) }
    var techSearch by remember { mutableStateOf("") }
    var techFilterCat by remember { mutableStateOf("ALL") }
    var techFilterDistrict by remember { mutableStateOf("ALL") }
    var communityFilter by remember { mutableStateOf("PENDING") }
    var verificationFilter by remember { mutableStateOf("PENDING") }
    val context = LocalContext.current

    fun shareJsonBackup() {
        val json = onExportBackupJson()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_SUBJECT, "Repair Pro Online Catalog Backup")
            putExtra(Intent.EXTRA_TEXT, json)
        }
        context.startActivity(Intent.createChooser(intent, "Export Repair Pro Backup"))
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth >= 700.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (isWide) {
                Column(
                    modifier = Modifier
                        .width(232.dp)
                        .fillMaxHeight()
                        .background(DeepCardSurface)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                        }
                        Text("Super Admin", style = MaterialTheme.typography.titleMedium, color = CyanAccent)
                    }
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                        Text(
                            text = adminEmail,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondarySlate,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    navItems.forEachIndexed { idx, item ->
                        val selected = activeSection == idx
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { activeSection = idx }
                                .testTag("admin_nav_$idx"),
                            color = if (selected) ElectricBluePrimary else Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(item.icon, contentDescription = null, tint = if (selected) TextPrimaryWhite else CyanAccent, modifier = Modifier.size(18.dp))
                                Text(item.label, style = MaterialTheme.typography.labelLarge, color = if (selected) TextPrimaryWhite else TextSecondarySlate)
                            }
                        }
                    }
                }
            }

            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                if (!isWide) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Repair Pro V2.0 — Super Admin", style = MaterialTheme.typography.titleMedium, color = TextPrimaryWhite)
                            Text("Verified • $adminEmail", style = MaterialTheme.typography.labelSmall, color = SuccessGreen, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        navItems.forEachIndexed { idx, item ->
                            FilterChip(
                                selected = activeSection == idx,
                                onClick = { activeSection = idx },
                                leadingIcon = { Icon(item.icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text(item.label) },
                                modifier = Modifier.testTag("admin_tab_$idx"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricBluePrimary,
                                    selectedLabelColor = TextPrimaryWhite,
                                    selectedLeadingIconColor = TextPrimaryWhite,
                                    containerColor = SecondaryNavySurface,
                                    labelColor = TextSecondarySlate,
                                    iconColor = CyanAccent
                                )
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp)
                        .testTag("admin_content_list"),
                    contentPadding = PaddingValues(top = 10.dp, bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (activeSection) {
                        0 -> {
                            item { Text("Live System Metrics (Online Firebase)", style = MaterialTheme.typography.titleMedium, color = CyanAccent) }
                            item {
                                val pendingVerifs = verificationRequests.count { it.status == "PENDING" }
                                val verifiedTechs = allTechnicians.count { V2DomainHelper.isVerifiedTechnicianRecord(it) }
                                val pendingPosts = allCommunityPosts.count { it.approvalStatus == "PENDING" }
                                val openFlags = allCommunityReports.count { it.status == "OPEN" }
                                val pendingReports = allReports.count { it.status == "PENDING" }

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        AdminStatCard("Error Codes", "${errorCodes.size}", CyanAccent, Modifier.weight(1f))
                                        AdminStatCard("Repair Guides", "${problems.size}", ElectricBluePrimary, Modifier.weight(1f))
                                        AdminStatCard("PDFs & Docs", "${technicalDocuments.size}", WarningAmber, Modifier.weight(1f))
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        AdminStatCard("Verified Techs", "$verifiedTechs", SuccessGreen, Modifier.weight(1f))
                                        AdminStatCard("Pending Verif", "$pendingVerifs", if (pendingVerifs > 0) WarningAmber else SuccessGreen, Modifier.weight(1f))
                                        AdminStatCard("User Reports", "$pendingReports", if (pendingReports > 0) ErrorCrimson else SuccessGreen, Modifier.weight(1f))
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        AdminStatCard("Comm. Posts", "${allCommunityPosts.size}", CyanAccent, Modifier.weight(1f))
                                        AdminStatCard("Pending Posts", "$pendingPosts", if (pendingPosts > 0) WarningAmber else SuccessGreen, Modifier.weight(1f))
                                        AdminStatCard("Open Flags", "$openFlags", if (openFlags > 0) ErrorCrimson else CyanAccent, Modifier.weight(1f))
                                    }
                                }
                            }
                            item {
                                val totalItems = (errorCodes.size + problems.size).coerceAtLeast(1)
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = ElevatedCardSurface,
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, CardBorderSubtle)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Online Catalog Distribution", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                                        categories.forEach { cat ->
                                            val count = errorCodes.count { it.categoryId == cat.id } + problems.count { it.categoryId == cat.id }
                                            val pct = count.toFloat() / totalItems.toFloat()
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                    Text(cat.nameEn, style = MaterialTheme.typography.labelMedium, color = TextPrimaryWhite)
                                                    Text("$count items (${(pct * 100).toInt()}%)", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                                                }
                                                LinearProgressIndicator(
                                                    progress = { pct },
                                                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp)),
                                                    color = ElectricBluePrimary,
                                                    trackColor = DeepCardSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                Text("Quick Actions", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    Button(
                                        onClick = { activeSection = 2 },
                                        modifier = Modifier.weight(1f).testTag("admin_quick_publish"),
                                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Publish Guide", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    OutlinedButton(
                                        onClick = { activeSection = 9 },
                                        modifier = Modifier.weight(1f).testTag("admin_quick_verifications"),
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, SuccessGreen)
                                    ) {
                                        Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Verifications", color = SuccessGreen, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    OutlinedButton(
                                        onClick = { activeSection = 10 },
                                        modifier = Modifier.weight(1f).testTag("admin_quick_documents"),
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, CyanAccent)
                                    ) {
                                        Icon(Icons.Filled.Description, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Upload PDF", color = CyanAccent, maxLines = 1)
                                    }
                                    OutlinedButton(
                                        onClick = { activeSection = 11 },
                                        modifier = Modifier.weight(1f).testTag("admin_quick_notifications"),
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, WarningAmber)
                                    ) {
                                        Icon(Icons.Filled.Campaign, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Announce", color = WarningAmber, maxLines = 1)
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = { activeSection = 8 },
                                    modifier = Modifier.fillMaxWidth().testTag("admin_quick_community"),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, CyanAccent)
                                ) {
                                    Icon(Icons.Filled.Forum, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    val pendingPosts = allCommunityPosts.count { it.approvalStatus == "PENDING" }
                                    Text("Moderate Community ($pendingPosts Pending)", color = CyanAccent)
                                }
                            }
                        }

                        1 -> {
                            item {
                                AdminAppliancesManagementCard(
                                    categories = categories,
                                    brands = brands,
                                    errorCodes = errorCodes,
                                    problems = problems,
                                    onQuickAddForCategory = { catId, type ->
                                        editingEntry = null
                                        catalogDefaultCat = catId
                                        catalogDefaultType = type
                                        activeSection = 2
                                    }
                                )
                            }
                        }

                        2 -> {
                            item {
                                AdminCatalogEditorCard(
                                    initialEntry = editingEntry,
                                    defaultCategoryId = catalogDefaultCat,
                                    defaultEntryType = catalogDefaultType,
                                    uploadProgress = uploadProgress,
                                    onUploadCatalogMedia = onUploadCatalogMedia,
                                    onCancelEdit = { editingEntry = null },
                                    onPublish = onPublishCatalogEntry
                                )
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("all" to "All", "ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                                        FilterChip(
                                            selected = catalogFilterCat == id,
                                            onClick = { catalogFilterCat = id },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                            }
                            val visibleCatalog = allCatalog.filter { catalogFilterCat == "all" || it.categoryId == catalogFilterCat }
                            item {
                                Text("Online Cloud Catalog Entries (${visibleCatalog.size})", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
                            }
                            items(visibleCatalog, key = { it.id }) { entry ->
                                AdminCatalogItemRow(
                                    entry = entry,
                                    onEdit = { editingEntry = entry },
                                    onTogglePublished = {
                                        onPublishCatalogEntry(entry.copy(published = !entry.published)) {}
                                    },
                                    onDelete = { onDeleteCatalogEntry(entry.id) }
                                )
                            }
                        }

                        3 -> {
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("all" to "All", "ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                                        FilterChip(selected = reportFilterCat == id, onClick = { reportFilterCat = id }, label = { Text(label) })
                                    }
                                }
                            }
                            val filteredReports = allReports.filter { reportFilterCat == "all" || it.categoryId == reportFilterCat }
                            item {
                                Text("User Submitted Reports (${filteredReports.size})", style = MaterialTheme.typography.titleMedium, color = CyanAccent)
                            }
                            if (filteredReports.isEmpty()) {
                                item { Text("No user reports matching this filter.", style = MaterialTheme.typography.bodyMedium, color = TextSecondarySlate) }
                            } else {
                                items(filteredReports, key = { it.id }) { report ->
                                    AdminReportReviewCard(
                                        report = report,
                                        onUpdateStatus = { newStatus, note -> onUpdateReportStatus(report.id, newStatus, note) }
                                    )
                                }
                            }
                        }

                        4 -> {
                            item {
                                SuperAdminAdMobSection(currentConfig = adMobConfig, onSaveConfig = onSaveAdMobConfig)
                            }
                        }

                        5 -> {
                            item {
                                AdminGlobalSettingsCard(
                                    globalConfig = globalConfig,
                                    publishedCount = allCatalog.count { it.published },
                                    onSave = onSaveGlobalConfig,
                                    onExportJson = { shareJsonBackup() }
                                )
                            }
                        }

                        6 -> {
                            if (isBootstrapAdmin) {
                                item {
                                    AdminRoleManagementCard(
                                        currentUserUid = currentUserUid,
                                        adminRoles = adminRoles,
                                        onUpsertRole = onUpsertAdminRole,
                                        onRevokeRole = onRevokeAdminRole
                                    )
                                }
                            }
                            item {
                                Text(
                                    text = "Immutable Admin Audit Logs (${auditLogs.size})",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CyanAccent,
                                    modifier = Modifier.testTag("admin_audit_heading")
                                )
                            }
                            if (auditLogs.isEmpty()) {
                                item { Text("No audit logs yet. Admin changes are recorded automatically.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate) }
                            } else {
                                items(auditLogs, key = { it.id }) { log ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        color = SecondaryNavySurface,
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, CardBorderSubtle)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text("${log.action} • ${log.targetType}", style = MaterialTheme.typography.labelLarge, color = CyanAccent)
                                            Text(log.details, style = MaterialTheme.typography.bodySmall, color = TextPrimaryWhite)
                                            Text("By ${log.adminEmail}", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate)
                                        }
                                    }
                                }
                            }
                        }

                        7 -> {
                            val totalCount = allTechnicians.size
                            val activeCount = allTechnicians.count { it.status == "ACTIVE" }
                            val inactiveCount = totalCount - activeCount
                            val districts = allTechnicians
                                .map { it.district.trim() }
                                .filter { it.isNotBlank() }
                                .distinct()
                                .sortedBy { it.lowercase() }

                            item {
                                Text(
                                    text = "Technician Management",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CyanAccent,
                                    modifier = Modifier.testTag("admin_technicians_heading")
                                )
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    AdminStatCard("Total", "$totalCount", CyanAccent, Modifier.weight(1f))
                                    AdminStatCard("Active", "$activeCount", SuccessGreen, Modifier.weight(1f))
                                    AdminStatCard("Inactive", "$inactiveCount", WarningAmber, Modifier.weight(1f))
                                }
                            }
                            item {
                                AdminTechnicianEditorCard(
                                    initialTech = editingTech,
                                    onCancelEdit = { editingTech = null },
                                    onSave = onSaveTechnician
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = techSearch,
                                    onValueChange = { techSearch = it.take(80) },
                                    label = { Text("Search technicians by name or phone") },
                                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = CyanAccent) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("admin_tech_search"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyanAccent,
                                        unfocusedBorderColor = CardBorderSubtle,
                                        focusedTextColor = TextPrimaryWhite,
                                        unfocusedTextColor = TextPrimaryWhite,
                                        focusedContainerColor = DeepCardSurface,
                                        unfocusedContainerColor = DeepCardSurface
                                    )
                                )
                            }
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    listOf("ALL" to "All", "AC" to "AC", "Refrigerator" to "Refrigerator", "Washing Machine" to "Washing Machine").forEach { (id, label) ->
                                        FilterChip(selected = techFilterCat == id, onClick = { techFilterCat = id }, label = { Text(label) })
                                    }
                                }
                            }
                            if (districts.isNotEmpty()) {
                                item {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        FilterChip(selected = techFilterDistrict == "ALL", onClick = { techFilterDistrict = "ALL" }, label = { Text("All Districts") })
                                        districts.forEach { dist ->
                                            FilterChip(
                                                selected = techFilterDistrict.equals(dist, ignoreCase = true),
                                                onClick = { techFilterDistrict = dist },
                                                label = { Text(dist) }
                                            )
                                        }
                                    }
                                }
                            }
                            val q = techSearch.trim().lowercase()
                            val visibleTechnicians = allTechnicians.filter { tech ->
                                val matchesQ = q.isEmpty() ||
                                    tech.fullName.lowercase().contains(q) ||
                                    tech.mobileNumber.lowercase().contains(q) ||
                                    tech.district.lowercase().contains(q) ||
                                    tech.cityArea.lowercase().contains(q)
                                val matchesCat = techFilterCat == "ALL" ||
                                    tech.serviceCategories.any { it.equals(techFilterCat, ignoreCase = true) }
                                val matchesDist = techFilterDistrict == "ALL" ||
                                    tech.district.trim().equals(techFilterDistrict, ignoreCase = true)
                                matchesQ && matchesCat && matchesDist
                            }
                            item {
                                Text("Registered Technicians (${visibleTechnicians.size})", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
                            }
                            if (visibleTechnicians.isEmpty()) {
                                item { Text("No technicians match the current filters.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate) }
                            } else {
                                items(visibleTechnicians, key = { it.id.ifBlank { it.technicianId } }) { tech ->
                                    AdminTechnicianRow(
                                        technician = tech,
                                        onEdit = { editingTech = tech },
                                        onToggleStatus = { onToggleTechnicianStatus(tech) },
                                        onDelete = { onDeleteTechnician(tech) }
                                    )
                                }
                            }
                        }

                        8 -> {
                            val blockedUidSet = communityRestrictions.map { it.userId }.toSet()
                            item {
                                AdminCommunityModerationHeader(
                                    allPosts = allCommunityPosts,
                                    allReports = allCommunityReports,
                                    blockedUsers = communityRestrictions,
                                    activeFilter = communityFilter,
                                    onSelectFilter = { communityFilter = it }
                                )
                            }
                            when (communityFilter) {
                                "REPORTS" -> {
                                    if (allCommunityReports.isEmpty()) {
                                        item { Text("No community reports filed.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate) }
                                    } else {
                                        items(allCommunityReports, key = { it.reportId.ifBlank { it.id } }) { rep ->
                                            val matchedPost = allCommunityPosts.firstOrNull {
                                                it.postId == rep.postId || it.id == rep.postId
                                            }
                                            AdminCommunityReportCard(
                                                report = rep,
                                                targetPost = matchedPost,
                                                onUpdateReport = onUpdateCommunityReportStatus,
                                                onDeleteTargetPost = onDeleteCommunityPost
                                            )
                                        }
                                    }
                                }
                                "BLOCKED" -> {
                                    val activeBlocked = communityRestrictions
                                    if (activeBlocked.isEmpty()) {
                                        item { Text("No users are currently blocked from community posting.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate) }
                                    } else {
                                        items(activeBlocked, key = { it.userId }) { restriction ->
                                            AdminBlockedUserRow(
                                                restriction = restriction,
                                                onUnblock = {
                                                    onSetCommunityUserBlocked(restriction.userId, restriction.userName, false, "")
                                                }
                                            )
                                        }
                                    }
                                }
                                else -> {
                                    val filteredPosts = allCommunityPosts.filter { post ->
                                        communityFilter == "ALL" || post.approvalStatus == communityFilter
                                    }
                                    if (filteredPosts.isEmpty()) {
                                        item { Text("No community posts in '$communityFilter' queue.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate) }
                                    } else {
                                        items(filteredPosts, key = { it.postId.ifBlank { it.id } }) { post ->
                                            AdminCommunityPostModerationCard(
                                                post = post,
                                                isAuthorBlocked = blockedUidSet.contains(post.authorUid),
                                                onModerate = onModerateCommunityPost,
                                                onTogglePin = onTogglePinCommunityPost,
                                                onBlockUser = onSetCommunityUserBlocked,
                                                onDelete = onDeleteCommunityPost
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        9 -> {
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = "Technician Verification Applications",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = CyanAccent,
                                        modifier = Modifier.testTag("admin_verifications_heading")
                                    )
                                    Row(
                                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        listOf("PENDING", "VERIFIED", "REJECTED", "SUSPENDED", "ALL").forEach { st ->
                                            val cnt = if (st == "ALL") verificationRequests.size else verificationRequests.count { it.status == st }
                                            FilterChip(
                                                selected = verificationFilter == st,
                                                onClick = { verificationFilter = st },
                                                label = { Text("$st ($cnt)") }
                                            )
                                        }
                                    }
                                }
                            }
                            val filteredVerifs = verificationRequests.filter { verificationFilter == "ALL" || it.status == verificationFilter }
                            if (filteredVerifs.isEmpty()) {
                                item { Text("No technician verification applications in '$verificationFilter'.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate) }
                            } else {
                                items(filteredVerifs, key = { it.userId.ifBlank { it.id } }) { req ->
                                    AdminVerificationRequestCard(
                                        request = req,
                                        onReview = onReviewVerification,
                                        onOpenImageViewer = onOpenImageViewer,
                                        onOpenPdfViewer = onOpenPdfViewer
                                    )
                                }
                            }
                        }

                        10 -> {
                            item {
                                AdminTechnicalDocumentUploadCard(
                                    isSubmitting = isSubmittingMedia,
                                    uploadProgress = uploadProgress,
                                    onUpload = onUploadTechnicalDocument
                                )
                            }
                            item {
                                Text(
                                    text = "Uploaded PDF Manuals & Circuit Diagrams (${technicalDocuments.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = CyanAccent,
                                    modifier = Modifier.testTag("admin_documents_heading")
                                )
                            }
                            if (technicalDocuments.isEmpty()) {
                                item { Text("No PDF manuals or circuit diagrams uploaded yet.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate) }
                            } else {
                                items(technicalDocuments, key = { it.id }) { doc ->
                                    val isPdf = doc.docType.equals("PDF_MANUAL", ignoreCase = true) || doc.mimeType.contains("pdf", ignoreCase = true)
                                    AdminTechnicalDocumentRow(
                                        doc = doc,
                                        onPreview = {
                                            if (isPdf) onOpenPdfViewer(doc.fileUrl, doc.title)
                                            else onOpenImageViewer(doc.fileUrl, doc.title)
                                        },
                                        onDelete = { onDeleteTechnicalDocument(doc) }
                                    )
                                }
                            }
                        }

                        11 -> {
                            item {
                                AdminAnnouncementsCard(
                                    announcements = announcements,
                                    onPublishAnnouncement = onPublishAnnouncement,
                                    onDeleteAnnouncement = onDeleteAnnouncement
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatCard(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, color = accent, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun AdminReportReviewCard(
    report: ProblemReportCloud,
    onUpdateStatus: (String, String) -> Unit
) {
    var note by remember(report.id) { mutableStateOf(report.adminNote) }
    val statusColor = when (report.status) {
        "PUBLISHED" -> SuccessGreen
        "REVIEWED" -> CyanAccent
        else -> WarningAmber
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${report.brandName} (${report.categoryId.uppercase()}) ${report.errorCode}", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                Text(report.status, style = MaterialTheme.typography.labelSmall, color = statusColor, fontWeight = FontWeight.Bold)
            }
            Text(report.description, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
            OutlinedTextField(value = note, onValueChange = { note = it.take(400) }, label = { Text("Technician Review Note") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onUpdateStatus("REVIEWED", note) }, modifier = Modifier.weight(1f)) {
                    Text("Mark Reviewed", color = CyanAccent, style = MaterialTheme.typography.labelSmall)
                }
                Button(
                    onClick = { onUpdateStatus("PUBLISHED", note) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = DeepCardSurface)
                ) {
                    Text("Mark Published", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AdminGlobalSettingsCard(
    globalConfig: AppSettingCloud,
    publishedCount: Int,
    onSave: (String, String, String) -> Unit,
    onExportJson: () -> Unit
) {
    var announcement by remember(globalConfig) { mutableStateOf(globalConfig.announcement) }
    var maintenance by remember(globalConfig) { mutableStateOf(globalConfig.maintenanceNotice) }
    var minVersion by remember(globalConfig) { mutableStateOf(globalConfig.minSupportedVersion.ifBlank { "2.0.0" }) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CyanAccent,
        unfocusedBorderColor = CardBorderSubtle,
        focusedTextColor = TextPrimaryWhite,
        unfocusedTextColor = TextPrimaryWhite,
        focusedContainerColor = DeepCardSurface,
        unfocusedContainerColor = DeepCardSurface
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Online App Settings & Remote Config", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
            Text(
                text = "$publishedCount published cloud catalog entries streaming live to online Repair Pro V2.0 users.",
                style = MaterialTheme.typography.bodySmall,
                color = SuccessGreen
            )
            OutlinedTextField(value = announcement, onValueChange = { announcement = it.take(300) }, label = { Text("Home Announcement Banner") }, colors = fieldColors, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = maintenance, onValueChange = { maintenance = it.take(300) }, label = { Text("Maintenance Notice") }, colors = fieldColors, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = minVersion, onValueChange = { minVersion = it.take(24) }, label = { Text("Minimum Supported Version") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = { onSave(announcement, maintenance, minVersion) },
                modifier = Modifier.fillMaxWidth().testTag("admin_save_global_settings"),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Remote App Settings", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = onExportJson,
                modifier = Modifier.fillMaxWidth().testTag("admin_export_backup_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CyanAccent)
            ) {
                Icon(Icons.Filled.Backup, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Export Complete Catalog JSON Backup", color = CyanAccent)
            }
        }
    }
}

@Composable
private fun AdminRoleManagementCard(
    currentUserUid: String,
    adminRoles: List<AdminRoleCloud>,
    onUpsertRole: (String, String) -> Unit,
    onRevokeRole: (String) -> Unit
) {
    var targetUid by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf("CONTENT_EDITOR") }
    val selfRegistered = adminRoles.any { it.id == currentUserUid }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Server-Side Admin Role Management (admins/)", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
            if (!selfRegistered) {
                Button(
                    onClick = { onUpsertRole(currentUserUid, "SUPER_ADMIN") },
                    modifier = Modifier.fillMaxWidth().testTag("admin_register_self_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = DeepCardSurface)
                ) {
                    Text("Register My Account as SUPER_ADMIN in Firestore", fontWeight = FontWeight.Bold)
                }
            }
            OutlinedTextField(
                value = targetUid,
                onValueChange = { targetUid = it.take(128) },
                label = { Text("Target Firebase Auth UID") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("SUPER_ADMIN", "CONTENT_EDITOR", "TRANSLATOR", "ANALYST").forEach { role ->
                    FilterChip(selected = selectedRole == role, onClick = { selectedRole = role }, label = { Text(role) })
                }
            }
            Button(
                onClick = {
                    if (targetUid.isNotBlank()) {
                        onUpsertRole(targetUid.trim(), selectedRole)
                        targetUid = ""
                    }
                },
                enabled = targetUid.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
            ) {
                Text("Grant / Update Admin Role")
            }
            adminRoles.forEach { roleDoc ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(roleDoc.userId, style = MaterialTheme.typography.labelMedium, color = TextPrimaryWhite)
                        Text(roleDoc.role, style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                    }
                    IconButton(onClick = { onRevokeRole(roleDoc.id) }) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Revoke", tint = ErrorCrimson)
                    }
                }
            }
        }
    }
}
