package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Repair Pro V2.0 Exact Master Color System
val DeepNavyBackground = Color(0xFF020B16)     // Main background: #020B16
val SecondaryNavySurface = Color(0xFF061426)   // Secondary background: #061426
val DeepCardSurface = Color(0xFF081D32)        // Card background: #081D32
val ElevatedCardSurface = Color(0xFF0C2740)    // Elevated card background: #0C2740
val ElectricBluePrimary = Color(0xFF008CFF)    // Primary Electric Blue: #008CFF
val CyanAccent = Color(0xFF00D8FF)             // Bright Cyan: #00D8FF
val CyanGlowSoft = Color(0x3800D8FF)
val BlueGlowSoft = Color(0x38008CFF)
val TextPrimaryWhite = Color(0xFFFFFFFF)       // Main text: #FFFFFF
val TextSecondarySlate = Color(0xFFA8BED0)     // Secondary text: #A8BED0
val TextMutedSteel = Color(0xFF6F88A2)
val SuccessGreen = Color(0xFF18C97E)           // Success / Verified
val WarningAmber = Color(0xFFFFB020)           // Warning
val ErrorCrimson = Color(0xFFFF5263)           // Error / Report
val CardBorderSubtle = Color(0x47008CFF)       // Translucent Electric Blue border
val CardBorderCyan = Color(0x8800D8FF)

val PrimaryBlueGradient = Brush.horizontalGradient(
    colors = listOf(ElectricBluePrimary, CyanAccent)
)

val CyanBorderGradient = Brush.linearGradient(
    colors = listOf(CyanAccent.copy(alpha = 0.72f), ElectricBluePrimary.copy(alpha = 0.30f))
)

val DarkScreenGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF051326), DeepNavyBackground, Color(0xFF010811))
)

val CardSurfaceGradient = Brush.verticalGradient(
    colors = listOf(ElevatedCardSurface, DeepCardSurface)
)

val HeroGlowGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF09315C), Color(0xFF07213E), Color(0xFF041428))
)
