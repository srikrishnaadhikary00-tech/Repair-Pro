package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.AnnouncementCloud
import com.example.data.remote.TechnicalDocumentCloud
import com.example.data.remote.TechnicianVerificationRequestCloud
import com.example.ui.theme.CardBorderCyan
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

private const val MAX_REPAIR_DOC_BYTES = 20 * 1024 * 1024

@Composable
fun AdminVerificationRequestCard(
    request: TechnicianVerificationRequestCloud,
    onReview: (request: TechnicianVerificationRequestCloud, newStatus: String, reason: String) -> Unit,
    onOpenImageViewer: (url: String, title: String) -> Unit,
    onOpenPdfViewer: (url: String, title: String) -> Unit
) {
    var reason by remember(request.userId, request.rejectionReason) { mutableStateOf(request.rejectionReason) }
    val reqId = request.userId.ifBlank { request.id }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_verification_card_$reqId"),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            1.dp,
            if (request.status == "PENDING") WarningAmber.copy(alpha = 0.55f) else CardBorderSubtle
        )
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (request.profilePhotoUrl.startsWith("https://")) {
                        AsyncImage(
                            model = request.profilePhotoUrl,
                            contentDescription = request.fullName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                    }
                    Column {
                        Text(request.fullName, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                        Text("${request.mobileNumber} • ${request.experience}", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    }
                }
                CommunityStatusPill(status = request.status)
            }

            Text(
                text = "Area: ${listOf(request.cityArea, request.district, request.state, request.pinCode).filter { it.isNotBlank() }.joinToString(", ")}",
                style = MaterialTheme.typography.bodySmall,
                color = TextPrimaryWhite
            )
            if (request.fullAddress.isNotBlank()) {
                Text(request.fullAddress, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
            }
            if (request.serviceCategories.isNotEmpty()) {
                Text(
                    text = "Categories: ${request.serviceCategories.joinToString(", ")}",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyanAccent
                )
            }
            if (request.bio.isNotBlank()) {
                Text(request.bio, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
            }

            // View uploaded private credential document / profile photo
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                if (request.credentialDocUrl.startsWith("https://")) {
                    val isPdf = request.credentialDocName.endsWith(".pdf", ignoreCase = true) ||
                        request.credentialDocUrl.contains(".pdf", ignoreCase = true)
                    OutlinedButton(
                        onClick = {
                            if (isPdf) onOpenPdfViewer(request.credentialDocUrl, "${request.fullName} — Credential")
                            else onOpenImageViewer(request.credentialDocUrl, "${request.fullName} — Credential")
                        },
                        border = BorderStroke(1.dp, CyanAccent),
                        modifier = Modifier.weight(1f).testTag("admin_view_cred_$reqId")
                    ) {
                        Icon(Icons.Filled.Visibility, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = request.credentialDocName.ifBlank { "View Credential" },
                            color = CyanAccent,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                if (request.profilePhotoUrl.startsWith("https://")) {
                    OutlinedButton(
                        onClick = { onOpenImageViewer(request.profilePhotoUrl, request.fullName) },
                        border = BorderStroke(1.dp, CardBorderSubtle)
                    ) {
                        Icon(Icons.Filled.Image, contentDescription = "View avatar", tint = TextPrimaryWhite, modifier = Modifier.size(16.dp))
                    }
                }
            }

            OutlinedTextField(
                value = reason,
                onValueChange = { reason = it.take(400) },
                label = { Text("Rejection / Suspension Reason (if rejecting or suspending)") },
                singleLine = true,
                colors = communityTextFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { onReview(request, "VERIFIED", "") },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = DeepCardSurface),
                    modifier = Modifier.weight(1f).testTag("admin_approve_verif_$reqId")
                ) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Verify", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { onReview(request, "REJECTED", reason.trim().ifBlank { "Please provide clearer credential details." }) },
                    border = BorderStroke(1.dp, WarningAmber),
                    modifier = Modifier.weight(1f).testTag("admin_reject_verif_$reqId")
                ) {
                    Icon(Icons.Filled.Close, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reject", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
                OutlinedButton(
                    onClick = { onReview(request, "SUSPENDED", reason.trim().ifBlank { "Verification suspended by Super Admin." }) },
                    border = BorderStroke(1.dp, ErrorCrimson),
                    modifier = Modifier.testTag("admin_suspend_verif_$reqId")
                ) {
                    Icon(Icons.Filled.Block, contentDescription = "Suspend", tint = ErrorCrimson, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun AdminTechnicalDocumentUploadCard(
    isSubmitting: Boolean,
    uploadProgress: Float?,
    onUpload: (
        docType: String,
        categoryId: String,
        brandName: String,
        modelName: String,
        linkedEntryId: String,
        title: String,
        description: String,
        fileBytes: ByteArray,
        mimeType: String,
        published: Boolean,
        onDone: () -> Unit
    ) -> Unit
) {
    val context = LocalContext.current
    var docType by remember { mutableStateOf("PDF_MANUAL") }
    var categoryId by remember { mutableStateOf("ac") }
    var brandName by remember { mutableStateOf("") }
    var modelName by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedMime by remember { mutableStateOf("application/pdf") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            selectedMime = context.contentResolver.getType(uri) ?: "application/pdf"
            selectedFileName = resolveDocFileName(context, uri)
            if (title.isBlank()) title = selectedFileName.substringBeforeLast(".")
            errorMsg = null
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            selectedUri = uri
            selectedMime = context.contentResolver.getType(uri) ?: "image/jpeg"
            selectedFileName = resolveDocFileName(context, uri)
            errorMsg = null
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CardBorderCyan)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "Upload PDF Manual, Circuit Diagram or Repair Photo",
                style = MaterialTheme.typography.titleSmall,
                color = CyanAccent,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "PDF_MANUAL" to "PDF Manual",
                    "CIRCUIT_DIAGRAM" to "Circuit Diagram",
                    "REPAIR_PHOTO" to "Repair Photo"
                ).forEach { (typeKey, label) ->
                    FilterChip(
                        selected = docType == typeKey,
                        onClick = {
                            docType = typeKey
                            selectedUri = null
                            selectedFileName = ""
                        },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricBluePrimary,
                            selectedLabelColor = TextPrimaryWhite,
                            containerColor = DeepCardSurface,
                            labelColor = TextSecondarySlate
                        )
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("ac" to "AC", "fridge" to "Fridge", "washer" to "Washer").forEach { (id, label) ->
                    FilterChip(
                        selected = categoryId == id,
                        onClick = { categoryId = id },
                        label = { Text(label) }
                    )
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it.take(160) },
                label = { Text("Document / Diagram Title *") },
                singleLine = true,
                colors = communityTextFieldColors(),
                modifier = Modifier.fillMaxWidth().testTag("admin_doc_title_input")
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = brandName,
                    onValueChange = { brandName = it.take(80) },
                    label = { Text("Brand") },
                    singleLine = true,
                    colors = communityTextFieldColors(),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = modelName,
                    onValueChange = { modelName = it.take(80) },
                    label = { Text("Model / PCB") },
                    singleLine = true,
                    colors = communityTextFieldColors(),
                    modifier = Modifier.weight(1f)
                )
            }
            OutlinedTextField(
                value = description,
                onValueChange = { description = it.take(800) },
                label = { Text("Short Technical Summary") },
                minLines = 2,
                maxLines = 4,
                colors = communityTextFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedButton(
                onClick = {
                    if (docType == "PDF_MANUAL") {
                        pdfPicker.launch(arrayOf("application/pdf"))
                    } else {
                        imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                },
                enabled = !isSubmitting,
                border = BorderStroke(1.dp, CyanAccent),
                modifier = Modifier.fillMaxWidth().testTag("admin_pick_doc_file_button")
            ) {
                Icon(Icons.Filled.UploadFile, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (selectedFileName.isBlank()) {
                        if (docType == "PDF_MANUAL") "Choose PDF File (<20 MB)" else "Choose High-Res Image (<20 MB)"
                    } else {
                        "Selected: $selectedFileName"
                    },
                    color = CyanAccent,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (uploadProgress != null) {
                LinearProgressIndicator(
                    progress = { uploadProgress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = CyanAccent,
                    trackColor = DeepCardSurface
                )
            }
            if (!errorMsg.isNullOrBlank()) {
                Text(errorMsg!!, style = MaterialTheme.typography.labelSmall, color = ErrorCrimson)
            }

            Button(
                onClick = {
                    val uri = selectedUri
                    if (title.isBlank()) {
                        errorMsg = "Enter a document title."
                        return@Button
                    }
                    if (uri == null) {
                        errorMsg = "Please select a file to upload."
                        return@Button
                    }
                    val bytes = try {
                        context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    } catch (e: Exception) {
                        errorMsg = e.localizedMessage ?: "Failed to read selected file."
                        return@Button
                    }
                    if (bytes == null || bytes.isEmpty()) {
                        errorMsg = "Selected file is empty."
                        return@Button
                    }
                    if (bytes.size > MAX_REPAIR_DOC_BYTES) {
                        errorMsg = "File exceeds 20 MB limit."
                        return@Button
                    }
                    errorMsg = null
                    onUpload(
                        docType,
                        categoryId,
                        brandName.trim(),
                        modelName.trim(),
                        "",
                        title.trim(),
                        description.trim(),
                        bytes,
                        selectedMime,
                        true
                    ) {
                        title = ""
                        brandName = ""
                        modelName = ""
                        description = ""
                        selectedUri = null
                        selectedFileName = ""
                    }
                },
                enabled = !isSubmitting,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("admin_upload_doc_submit_button")
            ) {
                Text(if (isSubmitting) "Uploading…" else "Upload & Publish Online", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AdminTechnicalDocumentRow(
    doc: TechnicalDocumentCloud,
    onPreview: () -> Unit,
    onDelete: () -> Unit
) {
    val isPdf = doc.docType.equals("PDF_MANUAL", ignoreCase = true) || doc.mimeType.contains("pdf", ignoreCase = true)
    Surface(
        modifier = Modifier.fillMaxWidth().testTag("admin_doc_row_${doc.id}"),
        color = SecondaryNavySurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = if (isPdf) Icons.Filled.Description else Icons.Filled.Image,
                contentDescription = null,
                tint = if (isPdf) WarningAmber else CyanAccent,
                modifier = Modifier.size(24.dp)
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(doc.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    text = "${doc.categoryId.uppercase()} • ${doc.docType} • ${doc.brandName.ifBlank { "Universal" }}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondarySlate
                )
            }
            IconButton(onClick = onPreview) {
                Icon(Icons.Filled.Visibility, contentDescription = "Preview", tint = CyanAccent)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = ErrorCrimson)
            }
        }
    }
}

@Composable
fun AdminAnnouncementsCard(
    announcements: List<AnnouncementCloud>,
    onPublishAnnouncement: (title: String, body: String, category: String, targetRoute: String, onDone: () -> Unit) -> Unit,
    onDeleteAnnouncement: (String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("GENERAL") }
    var targetRoute by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ElevatedCardSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, CardBorderCyan)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Campaign, contentDescription = null, tint = CyanAccent)
                    Text("Publish App Announcement & Notification", style = MaterialTheme.typography.titleSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("GENERAL", "NEW_GUIDE", "COMMUNITY", "SAFETY").forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) }
                        )
                    }
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it.take(120) },
                    label = { Text("Notification Title *") },
                    singleLine = true,
                    colors = communityTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("admin_announcement_title_input")
                )
                OutlinedTextField(
                    value = body,
                    onValueChange = { body = it.take(800) },
                    label = { Text("Message Body *") },
                    minLines = 3,
                    colors = communityTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("admin_announcement_body_input")
                )
                OutlinedTextField(
                    value = targetRoute,
                    onValueChange = { targetRoute = it.take(120) },
                    label = { Text("Optional Target Route (e.g. community, documents, verification)") },
                    singleLine = true,
                    colors = communityTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        if (title.isNotBlank() && body.isNotBlank()) {
                            onPublishAnnouncement(title.trim(), body.trim(), category, targetRoute.trim()) {
                                title = ""
                                body = ""
                                targetRoute = ""
                            }
                        }
                    },
                    enabled = title.isNotBlank() && body.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("admin_publish_announcement_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Publish Announcement", fontWeight = FontWeight.Bold)
                }
            }
        }

        Text("Published Announcements (${announcements.size})", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
        if (announcements.isEmpty()) {
            Text("No active announcements published yet.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
        } else {
            announcements.forEach { item ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = SecondaryNavySurface,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CardBorderSubtle)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("${item.title} [${item.category}]", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                            Text(item.body, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        }
                        IconButton(onClick = { onDeleteAnnouncement(item.id) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = ErrorCrimson)
                        }
                    }
                }
            }
        }
    }
}

private fun resolveDocFileName(context: android.content.Context, uri: Uri): String {
    return try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
        } ?: uri.lastPathSegment ?: "document"
    } catch (_: Exception) {
        uri.lastPathSegment ?: "document"
    }
}
