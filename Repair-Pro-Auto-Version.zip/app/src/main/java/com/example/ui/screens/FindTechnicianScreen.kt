package com.example.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WorkHistory
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.example.data.remote.TechnicianCloud
import com.example.data.remote.V2DomainHelper
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.i18n.UiStrings
import com.example.ui.UiState
import com.example.ui.components.OnlineOnlyOfflineGuardCard
import com.example.ui.theme.CardBorderCyan
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CardSurfaceGradient
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate

@Composable
fun FindTechnicianScreen(
    language: AppLanguage,
    techniciansState: UiState<List<TechnicianCloud>>,
    isOnline: Boolean,
    onRetry: () -> Unit,
    onShowMessage: (String) -> Unit,
    onBack: (() -> Unit)? = null,
    onApplyVerification: (() -> Unit)? = null,
    onCallTechnician: ((String) -> Unit)? = null
) {
    val strings = StringsProvider.get(language)
    val context = LocalContext.current

    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf("ALL") }
    var selectedDistrict by rememberSaveable { mutableStateOf("ALL") }
    var selectedTechnicianDetail by remember { mutableStateOf<TechnicianCloud?>(null) }

    val allActiveTechnicians = remember(techniciansState) {
        when (techniciansState) {
            is UiState.Success -> techniciansState.data.filter { it.status == "ACTIVE" && !it.blocked }
            else -> emptyList()
        }
    }

    val districts = remember(allActiveTechnicians) {
        allActiveTechnicians
            .map { it.district.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .sortedBy { it.lowercase() }
    }

    val filteredTechnicians = remember(allActiveTechnicians, searchQuery, selectedCategory, selectedDistrict) {
        val q = searchQuery.trim().lowercase()
        allActiveTechnicians.filter { tech ->
            val matchesQuery = q.isEmpty() ||
                tech.fullName.lowercase().contains(q) ||
                tech.district.lowercase().contains(q) ||
                tech.cityArea.lowercase().contains(q) ||
                tech.state.lowercase().contains(q) ||
                tech.fullAddress.lowercase().contains(q) ||
                tech.pinCode.lowercase().contains(q)
            val matchesCategory = selectedCategory == "ALL" ||
                tech.serviceCategories.any { it.equals(selectedCategory, ignoreCase = true) }
            val matchesDistrict = selectedDistrict == "ALL" ||
                tech.district.trim().equals(selectedDistrict, ignoreCase = true)
            matchesQuery && matchesCategory && matchesDistrict
        }
    }

    val dialPhone: (String) -> Unit = { phone ->
        val cleanPhone = phone.trim().replace(Regex("[^+0-9]"), "")
        if (onCallTechnician != null) {
            onCallTechnician(cleanPhone)
        } else {
            try {
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone"))
                context.startActivity(dialIntent)
            } catch (_: ActivityNotFoundException) {
                onShowMessage(strings.dialerUnavailable)
            } catch (_: Exception) {
                onShowMessage(strings.dialerUnavailable)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("find_technician_list"),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (onBack != null) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("find_tech_back_button")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Engineering,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Column {
                        Text(
                            text = strings.findTechnicianTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("find_technician_heading")
                        )
                        Text(
                            text = strings.findTechnicianSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate
                        )
                    }
                }
                if (techniciansState is UiState.Success) {
                    Surface(
                        color = SuccessGreen.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "${filteredTechnicians.size}",
                            style = MaterialTheme.typography.labelLarge,
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Apply for Verification CTA Banner
        if (onApplyVerification != null) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(onClick = onApplyVerification)
                        .testTag("find_tech_apply_verification_cta"),
                    color = ElectricBluePrimary.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CardBorderCyan)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(22.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Are you a Repair Technician?",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimaryWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Apply for Technician Verification to earn a Verified Badge & directory listing.",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondarySlate
                            )
                        }
                        Text(
                            text = "Apply",
                            style = MaterialTheme.typography.labelLarge,
                            color = CyanAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (!isOnline) {
            item {
                OnlineOnlyOfflineGuardCard(
                    title = strings.noInternetTitle,
                    message = "Please connect to the internet to browse verified technicians.",
                    retryLabel = strings.retry,
                    onRetry = onRetry
                )
            }
            return@LazyColumn
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it.take(80) },
                placeholder = {
                    Text(
                        text = strings.searchTechniciansPlaceholder,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = {
                    Icon(Icons.Filled.Search, contentDescription = strings.navSearch, tint = CyanAccent)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { searchQuery = "" },
                            modifier = Modifier.testTag("tech_search_clear")
                        ) {
                            Icon(Icons.Filled.Clear, contentDescription = "Clear search", tint = TextSecondarySlate)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = CardBorderSubtle,
                    focusedTextColor = TextPrimaryWhite,
                    unfocusedTextColor = TextPrimaryWhite,
                    focusedContainerColor = SecondaryNavySurface,
                    unfocusedContainerColor = SecondaryNavySurface,
                    focusedPlaceholderColor = TextSecondarySlate,
                    unfocusedPlaceholderColor = TextSecondarySlate
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tech_search_input")
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val categoryOptions = listOf(
                    "ALL" to strings.allCategories,
                    "AC" to strings.categoryAc,
                    "Refrigerator" to strings.categoryFridge,
                    "Washing Machine" to strings.categoryWasher
                )
                categoryOptions.forEach { (key, label) ->
                    val selected = selectedCategory == key
                    FilterChip(
                        selected = selected,
                        onClick = { selectedCategory = key },
                        label = { Text(label) },
                        modifier = Modifier.testTag("tech_cat_chip_${key.lowercase().replace(" ", "_")}"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricBluePrimary,
                            selectedLabelColor = TextPrimaryWhite,
                            containerColor = SecondaryNavySurface,
                            labelColor = TextSecondarySlate
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = CardBorderSubtle,
                            selectedBorderColor = CyanAccent
                        )
                    )
                }
            }
        }

        if (districts.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    FilterChip(
                        selected = selectedDistrict == "ALL",
                        onClick = { selectedDistrict = "ALL" },
                        label = { Text(strings.allDistricts) },
                        modifier = Modifier.testTag("tech_district_chip_all"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanAccent.copy(alpha = 0.24f),
                            selectedLabelColor = CyanAccent,
                            containerColor = DeepCardSurface,
                            labelColor = TextSecondarySlate
                        )
                    )
                    districts.forEach { dist ->
                        val selected = selectedDistrict.equals(dist, ignoreCase = true)
                        FilterChip(
                            selected = selected,
                            onClick = { selectedDistrict = dist },
                            label = { Text(dist) },
                            modifier = Modifier.testTag("tech_district_chip_${dist.lowercase().replace(" ", "_")}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanAccent.copy(alpha = 0.24f),
                                selectedLabelColor = CyanAccent,
                                containerColor = DeepCardSurface,
                                labelColor = TextSecondarySlate
                            )
                        )
                    }
                }
            }
        }

        when (techniciansState) {
            is UiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp)
                            .testTag("tech_loading_indicator"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(color = CyanAccent)
                            Text(strings.loadingTechnicians, style = MaterialTheme.typography.bodyMedium, color = TextSecondarySlate)
                        }
                    }
                }
            }

            is UiState.Error -> {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().testTag("tech_error_card"),
                        color = ErrorCrimson.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = ErrorCrimson, modifier = Modifier.size(40.dp))
                            Text(strings.techniciansErrorMessage, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryWhite, textAlign = TextAlign.Center)
                            Button(
                                onClick = onRetry,
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("tech_retry_button")
                            ) {
                                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.retry, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            is UiState.Success -> {
                if (filteredTechnicians.isEmpty()) {
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth().testTag("tech_empty_state"),
                            color = ElevatedCardSurface,
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, CardBorderSubtle)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(Icons.Filled.PersonSearch, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(44.dp))
                                Text(strings.noTechniciansFound, style = MaterialTheme.typography.titleMedium, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                                Text(strings.noTechniciansSubtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate, textAlign = TextAlign.Center)
                                if (searchQuery.isNotBlank() || selectedCategory != "ALL" || selectedDistrict != "ALL") {
                                    OutlinedButton(
                                        onClick = {
                                            searchQuery = ""
                                            selectedCategory = "ALL"
                                            selectedDistrict = "ALL"
                                        },
                                        border = BorderStroke(1.dp, CyanAccent),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.testTag("tech_clear_filters_button")
                                    ) {
                                        Text(strings.clearFilters, color = CyanAccent)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    items(filteredTechnicians, key = { it.id.ifBlank { it.technicianId } }) { tech ->
                        TechnicianProfileCard(
                            technician = tech,
                            strings = strings,
                            onCardClick = { selectedTechnicianDetail = tech },
                            onCallClick = { dialPhone(tech.mobileNumber) }
                        )
                    }
                }
            }
        }
    }

    val detailTech = selectedTechnicianDetail
    if (detailTech != null) {
        TechnicianProfileModalDialog(
            technician = detailTech,
            strings = strings,
            onDismiss = { selectedTechnicianDetail = null },
            onCallClick = {
                selectedTechnicianDetail = null
                dialPhone(detailTech.mobileNumber)
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TechnicianProfileModalDialog(
    technician: TechnicianCloud,
    strings: UiStrings,
    onDismiss: () -> Unit,
    onCallClick: () -> Unit
) {
    val isVerified = V2DomainHelper.isVerifiedTechnicianRecord(technician)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SecondaryNavySurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TechnicianAvatar(photoUrl = technician.photoUrl, fullName = technician.fullName)
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(technician.fullName, style = MaterialTheme.typography.titleMedium, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                        if (isVerified) {
                            Icon(Icons.Filled.Verified, contentDescription = "Verified Technician", tint = SuccessGreen, modifier = Modifier.size(18.dp))
                        }
                    }
                    if (isVerified) {
                        Text("Verified Repair Pro Technician", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (technician.experience.isNotBlank()) {
                    Text("${strings.experienceLabel}: ${technician.experience}", style = MaterialTheme.typography.labelLarge, color = CyanAccent)
                }
                if (technician.bio.isNotBlank()) {
                    Text(technician.bio, style = MaterialTheme.typography.bodySmall, color = TextPrimaryWhite)
                }
                if (technician.serviceCategories.isNotEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        technician.serviceCategories.forEach { cat ->
                            Surface(color = ElectricBluePrimary.copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp)) {
                                Text(cat, style = MaterialTheme.typography.labelSmall, color = TextPrimaryWhite, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                            }
                        }
                    }
                }
                Surface(color = DeepCardSurface, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = listOf(technician.cityArea, technician.district, technician.state, technician.pinCode)
                                .filter { it.isNotBlank() }
                                .joinToString(", "),
                            style = MaterialTheme.typography.labelMedium,
                            color = TextPrimaryWhite
                        )
                        if (technician.fullAddress.isNotBlank()) {
                            Text(technician.fullAddress, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        }
                        Text(technician.mobileNumber, style = MaterialTheme.typography.labelMedium, fontFamily = JetBrainsMonoFontFamily, color = SuccessGreen)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onCallClick,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary)
            ) {
                Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.callNow)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = TextSecondarySlate)
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TechnicianProfileCard(
    technician: TechnicianCloud,
    strings: UiStrings,
    onCardClick: () -> Unit,
    onCallClick: () -> Unit
) {
    val cardKey = technician.id.ifBlank { technician.technicianId }
    val isVerified = V2DomainHelper.isVerifiedTechnicianRecord(technician)
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(
                    listOf(CyanAccent.copy(alpha = 0.6f), ElectricBluePrimary.copy(alpha = 0.28f))
                ),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onCardClick)
            .testTag("technician_card_$cardKey"),
        color = Color.Transparent,
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .background(CardSurfaceGradient)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                TechnicianAvatar(
                    photoUrl = technician.photoUrl,
                    fullName = technician.fullName
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = technician.fullName,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (isVerified) {
                            Icon(
                                imageVector = Icons.Filled.Verified,
                                contentDescription = "Verified Technician",
                                tint = SuccessGreen,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    if (technician.experience.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.WorkHistory,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "${strings.experienceLabel}: ${technician.experience}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanAccent
                            )
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        technician.serviceCategories.forEach { category ->
                            val localizedCat = when (category) {
                                "AC" -> strings.categoryAc
                                "Refrigerator" -> strings.categoryFridge
                                "Washing Machine" -> strings.categoryWasher
                                else -> category
                            }
                            Surface(
                                color = ElectricBluePrimary.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Build,
                                        contentDescription = null,
                                        tint = CyanAccent,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = localizedCat,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimaryWhite,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = DeepCardSurface.copy(alpha = 0.85f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CardBorderSubtle)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = buildString {
                                append(technician.cityArea)
                                if (technician.district.isNotBlank()) append(", ${technician.district}")
                                if (technician.state.isNotBlank()) append(" • ${technician.state}")
                                if (technician.pinCode.isNotBlank()) append(" - ${technician.pinCode}")
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = technician.fullAddress,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Phone,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = technician.mobileNumber,
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = TextPrimaryWhite
                        )
                    }
                }
            }

            Button(
                onClick = onCallClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("call_tech_$cardKey"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricBluePrimary,
                    contentColor = TextPrimaryWhite
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.Call,
                    contentDescription = strings.callNow,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${strings.callNow} • ${technician.mobileNumber}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun TechnicianAvatar(
    photoUrl: String,
    fullName: String
) {
    val initials = remember(fullName) {
        val parts = fullName.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        when {
            parts.isEmpty() -> "RP"
            parts.size == 1 -> parts[0].take(2).uppercase()
            else -> "${parts.first().first()}${parts.last().first()}".uppercase()
        }
    }

    val fallbackBox: @Composable () -> Unit = {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(ElectricBluePrimary, CyanAccent.copy(alpha = 0.7f))))
                .border(1.5.dp, CyanAccent.copy(alpha = 0.7f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initials,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimaryWhite,
                fontWeight = FontWeight.Bold
            )
        }
    }

    if (photoUrl.startsWith("https://")) {
        SubcomposeAsyncImage(
            model = photoUrl,
            contentDescription = "$fullName profile photo",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(ElevatedCardSurface)
                .border(1.5.dp, CyanAccent.copy(alpha = 0.7f), CircleShape),
            loading = { fallbackBox() },
            error = { fallbackBox() }
        )
    } else {
        fallbackBox()
    }
}
