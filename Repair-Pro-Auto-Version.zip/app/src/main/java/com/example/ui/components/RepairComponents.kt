package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.R
import com.example.ads.AdMobManager
import com.example.data.remote.AppSettingCloud
import com.example.i18n.AppLanguage
import com.example.ui.theme.CardBorderCyan
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CardSurfaceGradient
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMutedSteel
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@DrawableRes
fun categoryDrawableRes(categoryId: String): Int = when (categoryId.lowercase()) {
    "ac" -> R.drawable.img_cat_ac_1795249926667
    "fridge" -> R.drawable.img_cat_fridge_1795249926943
    "washer" -> R.drawable.img_cat_washer_1795249925832
    else -> R.drawable.img_splash_appliances_1795249925550
}

/**
 * Global Application Header matching Repair Pro V2.0 reference design:
 * Left hamburger menu -> Center/left Repair Pro brand logo + subtitle ->
 * Right Notification bell with unread badge + User avatar.
 */
@Composable
fun RepairProTopHeader(
    subtitle: String,
    userName: String,
    userPhotoUrl: String,
    unreadNotifications: Int,
    onOpenMenu: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            IconButton(
                onClick = onOpenMenu,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("global_header_menu_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Menu,
                    contentDescription = "Open navigation menu",
                    tint = TextPrimaryWhite
                )
            }
            Column {
                RepairProBrandLogo(compact = true)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondarySlate,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box {
                IconButton(
                    onClick = onOpenNotifications,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("global_header_notifications_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Notifications,
                        contentDescription = "Notifications",
                        tint = if (unreadNotifications > 0) CyanAccent else TextSecondarySlate
                    )
                }
                if (unreadNotifications > 0) {
                    Surface(
                        color = ErrorCrimson,
                        shape = CircleShape,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 6.dp, end = 6.dp)
                    ) {
                        Text(
                            text = if (unreadNotifications > 9) "9+" else unreadNotifications.toString(),
                            color = TextPrimaryWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(ElectricBluePrimary.copy(alpha = 0.25f))
                    .border(1.2.dp, CyanAccent.copy(alpha = 0.7f), CircleShape)
                    .clickable(onClick = onOpenProfile)
                    .testTag("global_header_avatar_button"),
                contentAlignment = Alignment.Center
            ) {
                if (userPhotoUrl.startsWith("https://")) {
                    AsyncImage(
                        model = userPhotoUrl,
                        contentDescription = "User profile",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(40.dp).clip(CircleShape)
                    )
                } else {
                    Text(
                        text = userName.trim().take(1).uppercase().ifBlank { "R" },
                        color = CyanAccent,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }
        }
    }
}

/**
 * Online-only repair guide guard. Shown whenever the device has no internet connection.
 */
@Composable
fun OnlineOnlyOfflineGuardCard(
    title: String = "No Internet Connection",
    message: String = "Please connect to the internet to view repair guides.",
    retryLabel: String = "Retry",
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("online_only_offline_guard"),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(WarningAmber.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.CloudOff,
                    contentDescription = title,
                    tint = WarningAmber,
                    modifier = Modifier.size(30.dp)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimaryWhite,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondarySlate,
                textAlign = TextAlign.Center
            )
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("online_only_retry_button")
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(retryLabel)
            }
        }
    }
}

@Composable
fun CompactApplianceHomeCard(
    categoryId: String,
    title: String,
    countBadge: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(CyanAccent.copy(alpha = 0.6f), ElectricBluePrimary.copy(alpha = 0.25f))
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .testTag("appliance_card_$categoryId"),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Image(
                painter = painterResource(id = categoryDrawableRes(categoryId)),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(66.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .border(1.dp, CardBorderSubtle, RoundedCornerShape(11.dp))
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = TextPrimaryWhite,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
            Surface(
                color = ElectricBluePrimary.copy(alpha = 0.2f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = countBadge,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyanAccent,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun DashboardStatCard(
    value: String,
    label: String,
    accent: Color = CyanAccent,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = accent,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondarySlate,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun RepairProBrandLogo(
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(if (compact) 30.dp else 44.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(
                    Brush.linearGradient(listOf(ElectricBluePrimary, CyanAccent))
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Build,
                contentDescription = "Repair Pro Logo",
                tint = TextPrimaryWhite,
                modifier = Modifier.size(if (compact) 17.dp else 24.dp)
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Repair ",
                style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.headlineLarge,
                color = TextPrimaryWhite,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Pro",
                style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.headlineLarge,
                color = CyanAccent,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun GlowingApplianceCard(
    categoryId: String,
    title: String,
    subtitle: String,
    badgeText: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(
                width = 1.25.dp,
                brush = Brush.horizontalGradient(
                    listOf(CyanAccent.copy(alpha = 0.7f), ElectricBluePrimary.copy(alpha = 0.35f))
                ),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick)
            .testTag("appliance_card_$categoryId"),
        color = Color.Transparent,
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .background(CardSurfaceGradient)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = categoryDrawableRes(categoryId)),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(96.dp)
                    .height(74.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, CardBorderSubtle, RoundedCornerShape(12.dp))
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimaryWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = ElectricBluePrimary.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanAccent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Open $title",
                tint = CyanAccent,
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

@Composable
fun ElectricQuickTile(
    icon: ImageVector,
    label: String,
    accentColor: Color = CyanAccent,
    testTagName: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .testTag(testTagName),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label.replace("\n", " "),
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(7.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextPrimaryWhite,
                textAlign = TextAlign.Center,
                maxLines = 2,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
fun LanguageSwitcherRow(
    currentLanguage: AppLanguage,
    onSelect: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(DeepCardSurface)
            .border(1.dp, CardBorderSubtle, RoundedCornerShape(12.dp))
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        AppLanguage.entries.forEach { lang ->
            val selected = lang == currentLanguage
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .clickable { onSelect(lang) }
                    .testTag("lang_chip_${lang.code}"),
                color = if (selected) ElectricBluePrimary else Color.Transparent,
                shape = RoundedCornerShape(9.dp)
            ) {
                Text(
                    text = lang.nativeLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) TextPrimaryWhite else TextSecondarySlate,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun ErrorCodePill(
    code: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ElectricBluePrimary.copy(alpha = 0.2f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.7f))
    ) {
        Text(
            text = code,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = CyanAccent,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun VerificationBadge(
    status: String,
    verifiedLabel: String,
    unverifiedLabel: String,
    modifier: Modifier = Modifier
) {
    val verified = status.equals("VERIFIED", ignoreCase = true)
    val badgeColor = if (verified) SuccessGreen else WarningAmber
    Surface(
        modifier = modifier,
        color = badgeColor.copy(alpha = 0.14f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                imageVector = if (verified) Icons.Filled.CheckCircle else Icons.Filled.Info,
                contentDescription = if (verified) verifiedLabel else unverifiedLabel,
                tint = badgeColor,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = if (verified) verifiedLabel else unverifiedLabel,
                style = MaterialTheme.typography.labelSmall,
                color = badgeColor
            )
        }
    }
}

@Composable
fun SafetyWarningBanner(
    title: String,
    message: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ErrorCrimson.copy(alpha = 0.14f)),
        border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = title,
                tint = ErrorCrimson,
                modifier = Modifier.size(24.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = ErrorCrimson,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimaryWhite
                )
            }
        }
    }
}

/**
 * Real Google Mobile Ads SDK Banner Slot controlled by Super Admin Firestore config
 * (global toggle, emergency kill switch, banner toggle, per-category AC/Fridge/Washer switches,
 * testMode flag, online check, and user NPA consent).
 */
@Composable
fun AdMobBannerSlot(
    config: AppSettingCloud,
    categoryId: String? = null,
    isOnline: Boolean,
    consentGranted: Boolean,
    screenTag: String,
    modifier: Modifier = Modifier
) {
    if (!isOnline || !AdMobManager.isBannerAllowed(config, categoryId)) return

    val context = LocalContext.current
    val unitId = AdMobManager.resolveBannerUnitId(config)
    val adView = remember(unitId, consentGranted) {
        AdMobManager.createBannerAdView(context, config, consentGranted)
    }

    DisposableEffect(adView) {
        onDispose {
            try {
                adView?.destroy()
            } catch (_: Throwable) {
                // Safe teardown
            }
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("admob_banner_$screenTag"),
        color = SecondaryNavySurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        if (adView != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { adView },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            // Safe fallback container for JVM Robolectric tests where Play Services AdView is absent
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (config.testMode) "Google AdMob Banner (Test Mode)" else "Google AdMob Banner",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimaryWhite
                    )
                    Text(
                        text = unitId,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMutedSteel,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
