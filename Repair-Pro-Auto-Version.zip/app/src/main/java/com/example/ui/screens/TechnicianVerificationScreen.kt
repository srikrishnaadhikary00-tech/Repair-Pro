package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.TechnicianVerificationRequestCloud
import com.example.data.remote.V2DomainHelper
import com.example.i18n.UiStrings
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMutedSteel
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun TechnicianVerificationScreen(
    strings: UiStrings,
    defaultName: String,
    existingRequest: TechnicianVerificationRequestCloud?,
    submitting: Boolean,
    uploadProgress: Float?,
    onBack: () -> Unit,
    onSubmit: (
        draft: TechnicianVerificationRequestCloud,
        profilePhotoBytes: ByteArray?,
        profilePhotoMime: String,
        credentialBytes: ByteArray?,
        credentialMime: String,
        credentialFileName: String
    ) -> Unit
) {
    val context = LocalContext.current
    val currentStatus = existingRequest?.status ?: "NONE"
    val canSubmit = currentStatus in listOf("NONE", "PENDING", "REJECTED")

    var fullName by remember(existingRequest) { mutableStateOf(existingRequest?.fullName?.ifBlank { defaultName } ?: defaultName) }
    var mobileNumber by remember(existingRequest) { mutableStateOf(existingRequest?.mobileNumber ?: "") }
    var experience by remember(existingRequest) { mutableStateOf(existingRequest?.experience ?: "") }
    var bio by remember(existingRequest) { mutableStateOf(existingRequest?.bio ?: "") }
    var fullAddress by remember(existingRequest) { mutableStateOf(existingRequest?.fullAddress ?: "") }
    var state by remember(existingRequest) { mutableStateOf(existingRequest?.state ?: "") }
    var district by remember(existingRequest) { mutableStateOf(existingRequest?.district ?: "") }
    var cityArea by remember(existingRequest) { mutableStateOf(existingRequest?.cityArea ?: "") }
    var pinCode by remember(existingRequest) { mutableStateOf(existingRequest?.pinCode ?: "") }
    var selectedCategories by remember(existingRequest) {
        mutableStateOf(existingRequest?.serviceCategories?.toSet() ?: setOf("AC"))
    }

    var pickedAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var pickedAvatarBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pickedAvatarMime by remember { mutableStateOf("image/jpeg") }

    var pickedCredBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pickedCredMime by remember { mutableStateOf("application/pdf") }
    var pickedCredName by remember(existingRequest) { mutableStateOf(existingRequest?.credentialDocName ?: "") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null && bytes.size < 10 * 1024 * 1024) {
                pickedAvatarUri = uri
                pickedAvatarBytes = bytes
                pickedAvatarMime = context.contentResolver.getType(uri) ?: "image/jpeg"
                validationError = null
            } else {
                validationError = "Profile photo must be under 10 MB."
            }
        }
    }

    val credentialPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null && bytes.size < 10 * 1024 * 1024) {
                pickedCredBytes = bytes
                pickedCredMime = context.contentResolver.getType(uri) ?: "application/pdf"
                pickedCredName = resolveDisplayName(context, uri) ?: "Credential_Document"
                validationError = null
            } else {
                validationError = "Credential document must be under 10 MB."
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBackground)
            .testTag("technician_verification_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("verification_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Column {
                    Text(strings.technicianVerificationTitle, style = MaterialTheme.typography.headlineSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                    Text("Apply for an Admin-Verified Technician Badge", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                }
            }
        }

        // Live Status Card
        if (existingRequest != null) {
            item {
                val (statusColor, statusTitle, statusIcon) = when (existingRequest.status) {
                    "VERIFIED" -> Triple(SuccessGreen, "Verified Technician Active", Icons.Filled.Verified)
                    "REJECTED" -> Triple(ErrorCrimson, "Verification Rejected", Icons.Filled.Warning)
                    "SUSPENDED" -> Triple(ErrorCrimson, "Account Suspended", Icons.Filled.Warning)
                    else -> Triple(WarningAmber, "Pending Super Admin Review", Icons.Filled.HourglassTop)
                }
                Surface(
                    color = statusColor.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.55f)),
                    modifier = Modifier.fillMaxWidth().testTag("verification_status_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(statusIcon, contentDescription = statusTitle, tint = statusColor, modifier = Modifier.size(26.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(statusTitle, style = MaterialTheme.typography.titleSmall, color = statusColor, fontWeight = FontWeight.Bold)
                            val detail = when (existingRequest.status) {
                                "VERIFIED" -> "Your profile is verified and visible to customers in Find Technicians."
                                "REJECTED" -> existingRequest.rejectionReason.ifBlank { "Please update your details or credentials and resubmit." }
                                "SUSPENDED" -> existingRequest.rejectionReason.ifBlank { "Your verified technician status is suspended by Super Admin." }
                                else -> "Your details & private credentials are in the Super Admin verification queue."
                            }
                            Text(detail, style = MaterialTheme.typography.bodySmall, color = TextPrimaryWhite)
                        }
                    }
                }
            }
        }

        // Profile Photo & Private Credential Upload Card
        item {
            Surface(
                color = ElevatedCardSurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Profile Photo & Private Credentials", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(DeepCardSurface)
                                .border(1.2.dp, CyanAccent, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            val avatarModel: Any? = pickedAvatarUri ?: existingRequest?.profilePhotoUrl?.takeIf { it.startsWith("https://") }
                            if (avatarModel != null) {
                                AsyncImage(
                                    model = avatarModel,
                                    contentDescription = "Technician photo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                                )
                            } else {
                                Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, tint = CyanAccent)
                            }
                        }
                        OutlinedButton(
                            onClick = { avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            enabled = canSubmit && !submitting,
                            border = BorderStroke(1.dp, CyanAccent),
                            modifier = Modifier.testTag("verification_pick_avatar_button")
                        ) {
                            Text("Select Profile Photo", color = CyanAccent)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ID / Trade Certificate (Private)", style = MaterialTheme.typography.labelLarge, color = TextPrimaryWhite)
                            Text(
                                text = pickedCredName.ifBlank { "Optional PDF or image — visible only to you & Super Admin" },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (pickedCredName.isNotBlank()) SuccessGreen else TextMutedSteel
                            )
                        }
                        OutlinedButton(
                            onClick = { credentialPicker.launch(arrayOf("application/pdf", "image/*")) },
                            enabled = canSubmit && !submitting,
                            border = BorderStroke(1.dp, CardBorderSubtle),
                            modifier = Modifier.testTag("verification_pick_credential_button")
                        ) {
                            Icon(Icons.Filled.AttachFile, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Attach", color = CyanAccent)
                        }
                    }
                }
            }
        }

        // Service Categories
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Service Specializations", style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    V2DomainHelper.ALLOWED_SERVICE_CATEGORIES.forEach { cat ->
                        val selected = cat in selectedCategories
                        FilterChip(
                            selected = selected,
                            onClick = {
                                if (!canSubmit) return@FilterChip
                                selectedCategories = if (selected && selectedCategories.size > 1) {
                                    selectedCategories - cat
                                } else {
                                    selectedCategories + cat
                                }
                            },
                            label = { Text(if (cat == "Washing Machine") "Washer" else cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricBluePrimary,
                                selectedLabelColor = TextPrimaryWhite,
                                containerColor = ElevatedCardSurface,
                                labelColor = TextSecondarySlate
                            )
                        )
                    }
                }
            }
        }

        // Form Fields
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                VerificationTextField("Full Name *", fullName, { fullName = it }, canSubmit, "ver_name_input")
                VerificationTextField("Mobile Number *", mobileNumber, { mobileNumber = it }, canSubmit, "ver_mobile_input")
                VerificationTextField("Years of Experience (e.g. 6 Years)", experience, { experience = it }, canSubmit, "ver_exp_input")
                VerificationTextField("Workshop / Service Bio", bio, { bio = it }, canSubmit, "ver_bio_input", minLines = 3)
                VerificationTextField("Full Workshop / Service Address *", fullAddress, { fullAddress = it }, canSubmit, "ver_address_input")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        VerificationTextField("State *", state, { state = it }, canSubmit, "ver_state_input")
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        VerificationTextField("District *", district, { district = it }, canSubmit, "ver_district_input")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        VerificationTextField("City / Area *", cityArea, { cityArea = it }, canSubmit, "ver_city_input")
                    }
                    Box(modifier = Modifier.weight(0.8f)) {
                        VerificationTextField("PIN Code *", pinCode, { pinCode = it }, canSubmit, "ver_pin_input")
                    }
                }
            }
        }

        if (uploadProgress != null) {
            item {
                LinearProgressIndicator(
                    progress = { uploadProgress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)),
                    color = CyanAccent,
                    trackColor = DeepCardSurface
                )
            }
        }

        if (validationError != null) {
            item {
                Text(validationError ?: "", color = WarningAmber, style = MaterialTheme.typography.bodySmall)
            }
        }

        item {
            Button(
                onClick = {
                    val cats = selectedCategories.toList()
                    val err = V2DomainHelper.validateVerificationApplication(
                        fullName = fullName,
                        mobileNumber = mobileNumber,
                        fullAddress = fullAddress,
                        state = state,
                        district = district,
                        cityArea = cityArea,
                        pinCode = pinCode,
                        serviceCategories = cats
                    )
                    if (err != null) {
                        validationError = err
                        return@Button
                    }
                    validationError = null
                    val draft = TechnicianVerificationRequestCloud(
                        fullName = fullName.trim(),
                        mobileNumber = mobileNumber.trim(),
                        fullAddress = fullAddress.trim(),
                        state = state.trim(),
                        district = district.trim(),
                        cityArea = cityArea.trim(),
                        pinCode = pinCode.trim(),
                        serviceCategories = cats,
                        experience = experience.trim(),
                        bio = bio.trim(),
                        profilePhotoUrl = existingRequest?.profilePhotoUrl ?: "",
                        profilePhotoStoragePath = existingRequest?.profilePhotoStoragePath ?: "",
                        credentialDocUrl = existingRequest?.credentialDocUrl ?: "",
                        credentialDocStoragePath = existingRequest?.credentialDocStoragePath ?: "",
                        credentialDocName = pickedCredName
                    )
                    onSubmit(draft, pickedAvatarBytes, pickedAvatarMime, pickedCredBytes, pickedCredMime, pickedCredName)
                },
                enabled = canSubmit && !submitting,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("verification_submit_button")
            ) {
                if (submitting) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = TextPrimaryWhite, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Submitting Application...")
                } else {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (currentStatus) {
                            "VERIFIED" -> "Already Verified"
                            "SUSPENDED" -> "Contact Admin"
                            "PENDING" -> "Update Pending Application"
                            "REJECTED" -> "Resubmit for Verification"
                            else -> "Submit for Verification"
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun VerificationTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    enabled: Boolean,
    tag: String,
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = TextSecondarySlate) },
        enabled = enabled,
        minLines = minLines,
        singleLine = minLines == 1,
        modifier = Modifier.fillMaxWidth().testTag(tag),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CyanAccent,
            unfocusedBorderColor = CardBorderSubtle,
            focusedContainerColor = DeepCardSurface,
            unfocusedContainerColor = DeepCardSurface,
            focusedTextColor = TextPrimaryWhite,
            unfocusedTextColor = TextPrimaryWhite
        )
    )
}

private fun resolveDisplayName(context: android.content.Context, uri: Uri): String? {
    return try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
        }
    } catch (_: Exception) {
        null
    }
}
