package com.example.ui

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.RepairRepository
import com.example.data.local.ApplianceCategoryEntity
import com.example.data.local.BrandEntity
import com.example.data.local.ErrorCodeEntity
import com.example.data.local.ProblemGuideEntity
import com.example.data.local.SearchHistoryEntity
import com.example.data.remote.AdminRoleCloud
import com.example.data.remote.AnnouncementCloud
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.AuditLogCloud
import com.example.data.remote.CatalogEntryCloud
import com.example.data.remote.CommunityCommentCloud
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.CommunityReportCloud
import com.example.data.remote.CommunityUserRestrictionCloud
import com.example.data.remote.PendingCommunityPhoto
import com.example.data.remote.ProblemReportCloud
import com.example.data.remote.SavedGuideCloud
import com.example.data.remote.SavedPostCloud
import com.example.data.remote.TechnicalDocumentCloud
import com.example.data.remote.TechnicianCloud
import com.example.data.remote.TechnicianVerificationRequestCloud
import com.example.data.remote.UserNotificationCloud
import com.example.data.remote.V2DomainHelper
import com.example.i18n.AppLanguage
import com.example.notifications.RepairProMessagingService
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class RepairViewModel(
    private val repository: RepairRepository,
    val currentUserId: String,
    val userDisplayName: String,
    val userEmail: String,
    val userPhotoUrl: String = "",
    initialLanguage: AppLanguage = AppLanguage.EN
) : ViewModel() {

    private val _language = MutableStateFlow(initialLanguage)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _isOnline = MutableStateFlow(repository.isNetworkAvailable())
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _isAdmin = MutableStateFlow(repository.cloud.isCurrentUserBootstrapAdmin())
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private val _isBootstrapAdmin = MutableStateFlow(repository.cloud.isCurrentUserBootstrapAdmin())
    val isBootstrapAdmin: StateFlow<Boolean> = _isBootstrapAdmin.asStateFlow()

    private val _adminRoleChecked = MutableStateFlow(false)
    val adminRoleChecked: StateFlow<Boolean> = _adminRoleChecked.asStateFlow()

    private val _adConsentGranted = MutableStateFlow(true)
    val adConsentGranted: StateFlow<Boolean> = _adConsentGranted.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(true)
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _isVerifiedTechnician = MutableStateFlow(false)
    val isVerifiedTechnician: StateFlow<Boolean> = _isVerifiedTechnician.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _uploadProgress = MutableStateFlow<Float?>(null)
    val uploadProgress: StateFlow<Float?> = _uploadProgress.asStateFlow()

    private val _techniciansRetryTick = MutableStateFlow(0)
    private val _communityRetryTick = MutableStateFlow(0)
    private val _communitySubmitting = MutableStateFlow(false)
    val communitySubmitting: StateFlow<Boolean> = _communitySubmitting.asStateFlow()

    val categories: StateFlow<List<ApplianceCategoryEntity>> = repository.categories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val brands: StateFlow<List<BrandEntity>> = repository.allBrands
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val publishedCloudCatalog: StateFlow<List<CatalogEntryCloud>> = safeCloudFlow(
        source = repository.cloud.observePublishedCatalog(currentUserId),
        fallback = emptyList(),
        label = "published_catalog"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Online-only live merge: base catalog + published Firestore entries combined in memory (no offline DB sync)
    val errorCodes: StateFlow<List<ErrorCodeEntity>> = combine(
        repository.allErrorCodes,
        publishedCloudCatalog
    ) { baseCodes, cloudEntries ->
        val cloudCodes = repository.mapCloudEntriesToErrorCodes(cloudEntries)
        val existingIds = baseCodes.map { it.id }.toSet()
        cloudCodes.filter { it.id !in existingIds } + baseCodes
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val problems: StateFlow<List<ProblemGuideEntity>> = combine(
        repository.allProblems,
        publishedCloudCatalog
    ) { baseProblems, cloudEntries ->
        val cloudProblems = repository.mapCloudEntriesToProblems(cloudEntries)
        val existingIds = baseProblems.map { it.id }.toSet()
        cloudProblems.filter { it.id !in existingIds } + baseProblems
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val searchHistory: StateFlow<List<SearchHistoryEntity>> = repository.searchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val savedGuides: StateFlow<List<SavedGuideCloud>> = safeCloudFlow(
        source = repository.cloud.observeSavedGuides(currentUserId),
        fallback = emptyList(),
        label = "saved_guides"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val userReports: StateFlow<List<ProblemReportCloud>> = safeCloudFlow(
        source = repository.cloud.observeUserProblemReports(currentUserId),
        fallback = emptyList(),
        label = "user_reports"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adMobConfig: StateFlow<AppSettingCloud> = safeCloudFlow(
        source = repository.cloud.observeAdMobConfig(currentUserId),
        fallback = AppSettingCloud(id = "admob_config", configType = "ADMOB"),
        label = "admob_config"
    ).stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000L),
        AppSettingCloud(id = "admob_config", configType = "ADMOB")
    )

    val globalConfig: StateFlow<AppSettingCloud> = safeCloudFlow(
        source = repository.cloud.observeGlobalConfig(currentUserId),
        fallback = AppSettingCloud(id = "global_config", configType = "GLOBAL"),
        label = "global_config"
    ).stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000L),
        AppSettingCloud(id = "global_config", configType = "GLOBAL")
    )

    // --- V2.0 USER STREAMS: VERIFICATION, PDFs/DIAGRAMS, NOTIFICATIONS, RESTRICTIONS ---
    val myVerificationRequest: StateFlow<TechnicianVerificationRequestCloud?> = safeCloudFlow(
        source = repository.v2.observeMyVerificationRequest(currentUserId),
        fallback = null,
        label = "my_verification_request"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val publishedTechnicalDocuments: StateFlow<List<TechnicalDocumentCloud>> = safeCloudFlow(
        source = repository.v2.observePublishedTechnicalDocuments(currentUserId),
        fallback = emptyList(),
        label = "technical_documents"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val myNotifications: StateFlow<List<UserNotificationCloud>> = safeCloudFlow(
        source = repository.v2.observeMyNotifications(currentUserId),
        fallback = emptyList(),
        label = "user_notifications"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val announcements: StateFlow<List<AnnouncementCloud>> = safeCloudFlow(
        source = repository.v2.observeAnnouncements(currentUserId),
        fallback = emptyList(),
        label = "announcements"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val readAnnouncementIds: StateFlow<Set<String>> = safeCloudFlow(
        source = repository.v2.observeReadAnnouncementIds(currentUserId),
        fallback = emptySet(),
        label = "read_announcements"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptySet())

    val unreadNotificationCount: StateFlow<Int> = combine(
        myNotifications,
        announcements,
        readAnnouncementIds
    ) { personal, broadcast, readIds ->
        V2DomainHelper.countUnreadNotifications(personal, broadcast, readIds)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0)

    val myCommunityRestriction: StateFlow<CommunityUserRestrictionCloud?> = safeCloudFlow(
        source = repository.v2.observeMyCommunityRestriction(currentUserId),
        fallback = null,
        label = "my_community_restriction"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    // --- ADMIN-ONLY STREAMS ---
    val adminAllReports: StateFlow<List<ProblemReportCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.cloud.observeAllProblemReportsForAdmin(currentUserId),
                emptyList(),
                "admin_reports"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminAllCatalog: StateFlow<List<CatalogEntryCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.cloud.observeAllCatalogForAdmin(currentUserId),
                emptyList(),
                "admin_catalog"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminAuditLogs: StateFlow<List<AuditLogCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.cloud.observeAuditLogsForAdmin(currentUserId),
                emptyList(),
                "audit_logs"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminRoles: StateFlow<List<AdminRoleCloud>> = _isBootstrapAdmin
        .flatMapLatest { bootstrap ->
            if (bootstrap) safeCloudFlow(
                repository.cloud.observeAdminRolesForBootstrapAdmin(currentUserId),
                emptyList(),
                "admins"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminVerificationRequests: StateFlow<List<TechnicianVerificationRequestCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.v2.observeAllVerificationRequestsForAdmin(currentUserId),
                emptyList(),
                "admin_verification_requests"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminTechnicalDocuments: StateFlow<List<TechnicalDocumentCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.v2.observeAllTechnicalDocumentsForAdmin(currentUserId),
                emptyList(),
                "admin_technical_documents"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminCommunityRestrictions: StateFlow<List<CommunityUserRestrictionCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.v2.observeAllCommunityRestrictionsForAdmin(currentUserId),
                emptyList(),
                "admin_community_restrictions"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // --- TECHNICIAN DIRECTORY STREAMS ---
    val activeTechniciansState: StateFlow<UiState<List<TechnicianCloud>>> = _techniciansRetryTick
        .flatMapLatest {
            repository.cloud.observeActiveTechnicians(currentUserId)
                .map<List<TechnicianCloud>, UiState<List<TechnicianCloud>>> { list ->
                    UiState.Success(list.filter { !it.blocked })
                }
                .onStart { emit(UiState.Loading) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val message = (firestoreError ?: error).localizedMessage ?: "Unable to load technicians."
                    Log.w(TAG, "Cloud stream error (active_technicians): $message")
                    emit(UiState.Error(message))
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val adminAllTechnicians: StateFlow<List<TechnicianCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.cloud.observeAllTechniciansForAdmin(currentUserId),
                emptyList(),
                "admin_technicians"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // --- TECHNICIAN COMMUNITY STREAMS ---
    val approvedCommunityPostsState: StateFlow<UiState<List<CommunityPostCloud>>> = _communityRetryTick
        .flatMapLatest {
            repository.community.observeApprovedPosts(currentUserId)
                .map<List<CommunityPostCloud>, UiState<List<CommunityPostCloud>>> { UiState.Success(it) }
                .onStart { emit(UiState.Loading) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val message = (firestoreError ?: error).localizedMessage ?: "Unable to load community posts."
                    Log.w(TAG, "Cloud stream error (community_posts): $message")
                    emit(UiState.Error(message))
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val myCommunityPosts: StateFlow<List<CommunityPostCloud>> = safeCloudFlow(
        source = repository.community.observeMyPosts(currentUserId),
        fallback = emptyList(),
        label = "my_community_posts"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val likedCommunityPostIds: StateFlow<Set<String>> = safeCloudFlow(
        source = repository.community.observeLikedPostIds(currentUserId),
        fallback = emptySet(),
        label = "liked_posts"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptySet())

    val savedCommunityPosts: StateFlow<List<SavedPostCloud>> = safeCloudFlow(
        source = repository.community.observeSavedPosts(currentUserId),
        fallback = emptyList(),
        label = "saved_posts"
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminAllCommunityPosts: StateFlow<List<CommunityPostCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.community.observeAllPostsForAdmin(currentUserId),
                emptyList(),
                "admin_community_posts"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminAllCommunityReports: StateFlow<List<CommunityReportCloud>> = _isAdmin
        .flatMapLatest { admin ->
            if (admin) safeCloudFlow(
                repository.community.observeAllCommunityReportsForAdmin(currentUserId),
                emptyList(),
                "admin_community_reports"
            ) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    fun observeCommunityPost(postId: String): Flow<CommunityPostCloud?> {
        return safeCloudFlow(
            source = repository.community.observePost(postId, currentUserId),
            fallback = null,
            label = "community_post_$postId"
        )
    }

    fun observeCommunityComments(postId: String): Flow<List<CommunityCommentCloud>> {
        return safeCloudFlow(
            source = repository.community.observeComments(postId, currentUserId),
            fallback = emptyList(),
            label = "community_comments_$postId"
        )
    }

    val totalModelCount: StateFlow<Int> = brands
        .combine(categories) { brandList, _ ->
            brandList.sumOf { brand ->
                brand.modelsCsv.split(",").count { it.isNotBlank() }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0)

    init {
        viewModelScope.launch {
            repository.ensureBaseCatalogSeeded()
            _isOnline.value = repository.isNetworkAvailable()
            repository.cloud.ensureUserProfile(
                userId = currentUserId,
                displayName = userDisplayName,
                preferredLanguage = _language.value.code
            )
            _isBootstrapAdmin.value = repository.cloud.isCurrentUserBootstrapAdmin()
            _isAdmin.value = repository.cloud.checkIsAdmin(currentUserId)
            _adminRoleChecked.value = true
        }
        viewModelScope.launch {
            safeCloudFlow(repository.cloud.observeUserProfile(currentUserId), null, "profile")
                .collect { profile ->
                    if (profile != null) {
                        _adConsentGranted.value = profile.adConsentGranted
                        _notificationsEnabled.value = profile.notificationsEnabled
                        _isVerifiedTechnician.value = profile.isVerifiedTechnician
                    }
                }
        }
    }

    private fun <T> safeCloudFlow(source: Flow<T>, fallback: T, label: String): Flow<T> {
        return source.catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Cloud stream error ($label): ${(firestoreError ?: error).message}")
            emit(fallback)
        }
    }

    fun syncFcmToken(context: Context) {
        RepairProMessagingService.ensureChannels(context)
        RepairProMessagingService.syncCurrentFcmToken(context, currentUserId)
    }

    fun refreshConnectivity(): Boolean {
        val online = repository.isNetworkAvailable()
        _isOnline.value = online
        if (online) {
            _techniciansRetryTick.value += 1
            _communityRetryTick.value += 1
        }
        return online
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
        viewModelScope.launch {
            repository.cloud.updateUserPreferences(currentUserId, preferredLanguage = lang.code)
        }
    }

    fun setAdConsent(granted: Boolean) {
        _adConsentGranted.value = granted
        viewModelScope.launch {
            val res = repository.cloud.updateUserPreferences(currentUserId, adConsentGranted = granted)
            if (res.isSuccess) {
                _statusBanner.value = if (granted) "Personalized ad consent updated" else "Non-personalized ads enabled"
            }
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        _notificationsEnabled.value = enabled
        viewModelScope.launch {
            val res = repository.cloud.updateUserPreferences(currentUserId, notificationsEnabled = enabled)
            if (res.isSuccess) {
                _statusBanner.value = if (enabled) "Notifications enabled" else "Notifications muted"
            }
        }
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun recordSearch(query: String, categoryId: String? = null) {
        viewModelScope.launch {
            repository.recordSearch(query, categoryId)
        }
    }

    fun clearSearchHistory() {
        viewModelScope.launch {
            repository.clearSearchHistory()
        }
    }

    fun isGuideSaved(itemType: String, itemId: String): Boolean {
        return savedGuides.value.any { it.itemType == itemType && it.itemId == itemId }
    }

    fun toggleSavedGuide(
        itemType: String,
        itemId: String,
        categoryId: String,
        title: String,
        subtitle: String
    ) {
        viewModelScope.launch {
            val existing = savedGuides.value.firstOrNull { it.itemType == itemType && it.itemId == itemId }
            val result = if (existing != null) {
                repository.cloud.removeSavedGuide(currentUserId, existing.id)
            } else {
                repository.cloud.saveGuide(currentUserId, itemType, itemId, categoryId, title, subtitle)
            }
            if (result.isFailure) {
                _statusBanner.value = "Sync failed: ${result.exceptionOrNull()?.localizedMessage ?: "Check connection"}"
            } else {
                _statusBanner.value = if (existing != null) "Removed from Saved Guides" else "Saved to your cloud bookmarks"
            }
        }
    }

    fun submitProblemReport(
        categoryId: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        description: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.cloud.submitProblemReport(
                userId = currentUserId,
                categoryId = categoryId,
                brandName = brandName,
                modelName = modelName,
                errorCode = errorCode,
                description = description,
                preferredLanguage = _language.value.code
            )
            if (result.isSuccess) {
                _statusBanner.value = "Problem report submitted successfully!"
                onSuccess()
            } else {
                _statusBanner.value = result.exceptionOrNull()?.localizedMessage ?: "Unable to submit report"
            }
        }
    }

    // --- TECHNICIAN VERIFICATION WORKFLOW ---
    fun submitTechnicianVerification(
        draft: TechnicianVerificationRequestCloud,
        profilePhotoBytes: ByteArray? = null,
        profilePhotoMime: String = "image/jpeg",
        credentialBytes: ByteArray? = null,
        credentialMime: String = "application/pdf",
        credentialFileName: String = "",
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _communitySubmitting.value = true
            _uploadProgress.value = 0f
            try {
                var toSubmit = draft.copy(userId = currentUserId)
                if (profilePhotoBytes != null && profilePhotoBytes.isNotEmpty()) {
                    val photoRes = repository.v2.uploadVerificationFile(
                        userId = currentUserId,
                        prefix = "avatar",
                        bytes = profilePhotoBytes,
                        mimeType = profilePhotoMime,
                        onProgress = { _uploadProgress.value = it * 0.5f }
                    )
                    if (photoRes.isFailure) {
                        _statusBanner.value = photoRes.exceptionOrNull()?.localizedMessage ?: "Profile photo upload failed."
                        return@launch
                    }
                    val (url, path) = photoRes.getOrThrow()
                    toSubmit = toSubmit.copy(profilePhotoUrl = url, profilePhotoStoragePath = path)
                }
                if (credentialBytes != null && credentialBytes.isNotEmpty()) {
                    val docRes = repository.v2.uploadVerificationFile(
                        userId = currentUserId,
                        prefix = "credential",
                        bytes = credentialBytes,
                        mimeType = credentialMime,
                        onProgress = { _uploadProgress.value = 0.5f + (it * 0.5f) }
                    )
                    if (docRes.isFailure) {
                        _statusBanner.value = docRes.exceptionOrNull()?.localizedMessage ?: "Credential upload failed."
                        return@launch
                    }
                    val (url, path) = docRes.getOrThrow()
                    toSubmit = toSubmit.copy(
                        credentialDocUrl = url,
                        credentialDocStoragePath = path,
                        credentialDocName = credentialFileName.ifBlank { "Credential Document" }
                    )
                }
                val res = repository.v2.submitVerificationRequest(currentUserId, toSubmit)
                if (res.isSuccess) {
                    _statusBanner.value = "Verification application submitted for admin review."
                    onSuccess()
                } else {
                    _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Unable to submit application."
                }
            } finally {
                _communitySubmitting.value = false
                _uploadProgress.value = null
            }
        }
    }

    fun adminReviewVerification(
        request: TechnicianVerificationRequestCloud,
        newStatus: String,
        rejectionReason: String
    ) {
        viewModelScope.launch {
            val res = repository.v2.adminReviewVerificationRequest(request, newStatus, rejectionReason)
            _statusBanner.value = if (res.isSuccess) {
                "Technician '${request.fullName}' marked $newStatus"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Verification review failed."
            }
        }
    }

    // --- TECHNICAL DOCUMENTS (PDF MANUALS, CIRCUIT DIAGRAMS, REPAIR PHOTOS) ---
    fun adminUploadTechnicalDocument(
        docType: String,
        categoryId: String,
        brandName: String,
        modelName: String,
        linkedEntryId: String,
        title: String,
        description: String,
        fileBytes: ByteArray,
        mimeType: String,
        published: Boolean,
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _communitySubmitting.value = true
            _uploadProgress.value = 0f
            try {
                val uploadRes = repository.v2.uploadRepairMedia(
                    categoryId = categoryId,
                    prefix = docType.lowercase(),
                    bytes = fileBytes,
                    mimeType = mimeType,
                    onProgress = { _uploadProgress.value = it }
                )
                if (uploadRes.isFailure) {
                    _statusBanner.value = uploadRes.exceptionOrNull()?.localizedMessage ?: "File upload failed."
                    return@launch
                }
                val (url, storagePath) = uploadRes.getOrThrow()
                val res = repository.v2.saveTechnicalDocument(
                    TechnicalDocumentCloud(
                        docType = docType,
                        categoryId = categoryId,
                        brandName = brandName,
                        modelName = modelName,
                        linkedEntryId = linkedEntryId,
                        title = title,
                        description = description,
                        fileUrl = url,
                        storagePath = storagePath,
                        mimeType = mimeType,
                        fileSizeBytes = fileBytes.size.toLong(),
                        published = published
                    )
                )
                if (res.isSuccess) {
                    _statusBanner.value = "Uploaded '$title' to online repair library."
                    onDone()
                } else {
                    _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to save document metadata."
                }
            } finally {
                _communitySubmitting.value = false
                _uploadProgress.value = null
            }
        }
    }

    fun adminDeleteTechnicalDocument(doc: TechnicalDocumentCloud) {
        viewModelScope.launch {
            val res = repository.v2.deleteTechnicalDocument(doc)
            _statusBanner.value = if (res.isSuccess) {
                "Removed '${doc.title}'"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Failed to delete document."
            }
        }
    }

    fun adminUploadCatalogMedia(
        categoryId: String,
        prefix: String,
        bytes: ByteArray,
        mimeType: String,
        onUploaded: (url: String, storagePath: String) -> Unit
    ) {
        viewModelScope.launch {
            _uploadProgress.value = 0f
            try {
                val res = repository.v2.uploadRepairMedia(
                    categoryId = categoryId,
                    prefix = prefix,
                    bytes = bytes,
                    mimeType = mimeType,
                    onProgress = { _uploadProgress.value = it }
                )
                if (res.isSuccess) {
                    val (url, path) = res.getOrThrow()
                    onUploaded(url, path)
                    _statusBanner.value = "Media uploaded and attached."
                } else {
                    _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Media upload failed."
                }
            } finally {
                _uploadProgress.value = null
            }
        }
    }

    // --- NOTIFICATIONS & ANNOUNCEMENTS ---
    fun markNotificationRead(notificationId: String) {
        viewModelScope.launch {
            repository.v2.markNotificationRead(notificationId)
        }
    }

    fun markAnnouncementRead(announcementId: String) {
        viewModelScope.launch {
            repository.v2.markAnnouncementRead(currentUserId, announcementId)
        }
    }

    fun adminPublishAnnouncement(
        title: String,
        body: String,
        category: String = "GENERAL",
        targetRoute: String = "",
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.v2.adminPublishAnnouncement(title, body, category, targetRoute)
            if (res.isSuccess) {
                _statusBanner.value = "Announcement published to all users."
                onDone()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to publish announcement."
            }
        }
    }

    fun adminDeleteAnnouncement(announcementId: String) {
        viewModelScope.launch {
            val res = repository.v2.adminDeleteAnnouncement(announcementId)
            _statusBanner.value = if (res.isSuccess) "Announcement deleted." else res.exceptionOrNull()?.localizedMessage
        }
    }

    // --- SUPER ADMIN MUTATIONS ---
    fun adminUpdateReportStatus(reportId: String, newStatus: String, adminNote: String) {
        viewModelScope.launch {
            val res = repository.cloud.updateProblemReportStatus(reportId, newStatus, adminNote)
            _statusBanner.value = if (res.isSuccess) "Report marked $newStatus" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminPublishCatalogEntry(entry: CatalogEntryCloud, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.cloud.publishCatalogEntry(entry)
            if (res.isSuccess) {
                _statusBanner.value = "Published '${entry.titleEn}' live to online catalog."
                onDone()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to publish entry"
            }
        }
    }

    fun adminDeleteCatalogEntry(entryId: String) {
        viewModelScope.launch {
            val res = repository.cloud.deleteCatalogEntry(entryId)
            _statusBanner.value = if (res.isSuccess) "Catalog entry removed" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminSaveAdMobConfig(config: AppSettingCloud) {
        viewModelScope.launch {
            val res = repository.cloud.saveAdMobConfig(config)
            _statusBanner.value = if (res.isSuccess) "AdMob remote settings saved & audited" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminSaveGlobalConfig(announcement: String, maintenanceNotice: String, minVersion: String) {
        viewModelScope.launch {
            val res = repository.cloud.saveGlobalConfig(announcement, maintenanceNotice, minVersion)
            _statusBanner.value = if (res.isSuccess) "Remote App Settings updated" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminUpsertRole(targetUid: String, role: String) {
        viewModelScope.launch {
            val res = repository.cloud.upsertAdminRole(targetUid, role)
            _statusBanner.value = if (res.isSuccess) "Admin role ($role) saved in Firestore" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminRevokeRole(targetUid: String) {
        viewModelScope.launch {
            val res = repository.cloud.removeAdminRole(targetUid)
            _statusBanner.value = if (res.isSuccess) "Admin role revoked" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun retryLoadTechnicians() {
        _isOnline.value = repository.isNetworkAvailable()
        _techniciansRetryTick.value += 1
    }

    fun adminSaveTechnician(
        technician: TechnicianCloud,
        photoBytes: ByteArray? = null,
        photoMimeType: String = "image/jpeg",
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            var toSave = technician
            if (photoBytes != null && photoBytes.isNotEmpty()) {
                val targetId = technician.id.ifBlank {
                    "tech_${java.util.UUID.randomUUID().toString().replace("-", "").take(14)}"
                }
                val uploadRes = repository.cloud.uploadTechnicianPhoto(targetId, photoBytes, photoMimeType)
                if (uploadRes.isFailure) {
                    _statusBanner.value = "Photo upload failed: ${uploadRes.exceptionOrNull()?.localizedMessage ?: "Check Firebase Storage"}"
                    return@launch
                }
                val (url, storagePath) = uploadRes.getOrThrow()
                toSave = technician.copy(id = targetId, technicianId = targetId, photoUrl = url, photoStoragePath = storagePath)
            }
            val res = repository.cloud.saveTechnician(toSave)
            if (res.isSuccess) {
                _statusBanner.value = "Technician '${toSave.fullName}' saved"
                onDone()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to save technician"
            }
        }
    }

    fun adminToggleTechnicianStatus(technician: TechnicianCloud) {
        viewModelScope.launch {
            val nextActive = technician.status != "ACTIVE"
            val res = repository.cloud.setTechnicianStatus(technician.id, nextActive, technician.fullName)
            _statusBanner.value = if (res.isSuccess) {
                "${technician.fullName} marked ${if (nextActive) "ACTIVE" else "INACTIVE"}"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Status update failed"
            }
        }
    }

    fun adminDeleteTechnician(technician: TechnicianCloud) {
        viewModelScope.launch {
            val res = repository.cloud.deleteTechnician(technician.id, technician.fullName, technician.photoStoragePath)
            _statusBanner.value = if (res.isSuccess) {
                "Technician '${technician.fullName}' removed"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Delete failed"
            }
        }
    }

    fun showStatusMessage(message: String) {
        _statusBanner.value = message
    }

    // --- TECHNICIAN COMMUNITY MUTATIONS ---
    fun retryLoadCommunity() {
        _isOnline.value = repository.isNetworkAvailable()
        _communityRetryTick.value += 1
    }

    fun createCommunityPost(
        category: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        title: String,
        body: String,
        photos: List<PendingCommunityPhoto> = emptyList(),
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            _communitySubmitting.value = true
            _uploadProgress.value = if (photos.isNotEmpty()) 0f else null
            try {
                val res = repository.community.createPost(
                    userId = currentUserId,
                    authorName = userDisplayName,
                    authorPhotoUrl = userPhotoUrl,
                    category = category,
                    brandName = brandName,
                    modelName = modelName,
                    errorCode = errorCode,
                    title = title,
                    body = body,
                    photos = photos,
                    isAdminAuthor = _isAdmin.value,
                    onUploadProgress = { _uploadProgress.value = it }
                )
                if (res.isSuccess) {
                    val status = res.getOrNull()
                    _statusBanner.value = if (status == "APPROVED") {
                        "Post published live to Technician Community."
                    } else {
                        "Post submitted for admin review."
                    }
                    onSuccess()
                } else {
                    _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to submit post."
                }
            } finally {
                _communitySubmitting.value = false
                _uploadProgress.value = null
            }
        }
    }

    fun updateCommunityPost(
        postId: String,
        category: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        title: String,
        body: String,
        existingPhotoUrls: List<String>,
        existingStoragePaths: List<String>,
        newPhotos: List<PendingCommunityPhoto> = emptyList(),
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            _communitySubmitting.value = true
            try {
                val res = repository.community.updateOwnPost(
                    userId = currentUserId,
                    postId = postId,
                    category = category,
                    brandName = brandName,
                    modelName = modelName,
                    errorCode = errorCode,
                    title = title,
                    body = body,
                    existingPhotoUrls = existingPhotoUrls,
                    existingStoragePaths = existingStoragePaths,
                    newPhotos = newPhotos,
                    isAdminAuthor = _isAdmin.value
                )
                if (res.isSuccess) {
                    _statusBanner.value = if (res.getOrNull() == "APPROVED") {
                        "Post updated."
                    } else {
                        "Post updated and submitted for admin review."
                    }
                    onSuccess()
                } else {
                    _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to update post."
                }
            } finally {
                _communitySubmitting.value = false
            }
        }
    }

    fun toggleCommunityPostLike(postId: String) {
        viewModelScope.launch {
            val currentlyLiked = likedCommunityPostIds.value.contains(postId)
            val res = repository.community.toggleLike(currentUserId, postId, currentlyLiked)
            if (res.isFailure) {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Unable to update like."
            }
        }
    }

    fun toggleCommunityPostBookmark(post: CommunityPostCloud) {
        viewModelScope.launch {
            val targetId = post.postId.ifBlank { post.id }
            val currentlySaved = savedCommunityPosts.value.any { it.postId == targetId || it.id == targetId }
            val res = repository.community.toggleBookmarkPost(currentUserId, post, currentlySaved)
            _statusBanner.value = if (res.isSuccess) {
                if (currentlySaved) "Removed post from bookmarks" else "Post bookmarked"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Unable to update bookmark."
            }
        }
    }

    fun addCommunityComment(
        postId: String,
        body: String,
        parentCommentId: String = "",
        replyToAuthorName: String = "",
        postAuthorUid: String = "",
        replyTargetUid: String = "",
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.community.addCommentOrReply(
                userId = currentUserId,
                authorName = userDisplayName,
                postId = postId,
                body = body,
                parentCommentId = parentCommentId,
                replyToAuthorName = replyToAuthorName,
                postAuthorUid = postAuthorUid,
                replyTargetUid = replyTargetUid
            )
            if (res.isSuccess) {
                _statusBanner.value = if (parentCommentId.isBlank()) "Comment posted" else "Reply posted"
                onSuccess()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Unable to post comment."
            }
        }
    }

    fun editCommunityComment(postId: String, commentId: String, newBody: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.community.editCommentOrReply(postId, commentId, newBody)
            if (res.isSuccess) {
                _statusBanner.value = "Comment updated"
                onSuccess()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Unable to edit comment."
            }
        }
    }

    fun deleteCommunityComment(postId: String, commentId: String) {
        viewModelScope.launch {
            val res = repository.community.deleteCommentOrReply(postId, commentId)
            _statusBanner.value = if (res.isSuccess) "Comment deleted" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun reportCommunityPostOrComment(
        postId: String,
        commentId: String = "",
        reason: String,
        details: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = repository.community.reportCommunityContent(
                userId = currentUserId,
                reporterName = userDisplayName,
                postId = postId,
                commentId = commentId,
                reason = reason,
                details = details
            )
            if (res.isSuccess) {
                _statusBanner.value = "Report submitted for Super Admin review."
                onSuccess()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Unable to submit report."
            }
        }
    }

    fun deleteCommunityPost(post: CommunityPostCloud, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.community.deletePost(post, asAdmin = _isAdmin.value)
            if (res.isSuccess) {
                _statusBanner.value = "Community post deleted."
                onDeleted()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Unable to delete post."
            }
        }
    }

    fun adminModerateCommunityPost(
        postId: String,
        newStatus: String,
        moderationNote: String,
        authorUid: String = "",
        postTitle: String = ""
    ) {
        viewModelScope.launch {
            val res = repository.community.moderatePost(postId, newStatus, moderationNote, authorUid, postTitle)
            _statusBanner.value = if (res.isSuccess) {
                "Post marked $newStatus"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Moderation failed."
            }
        }
    }

    fun adminTogglePinCommunityPost(postId: String, pinned: Boolean) {
        viewModelScope.launch {
            val res = repository.community.togglePinPost(postId, pinned)
            _statusBanner.value = if (res.isSuccess) {
                if (pinned) "Post pinned to top of community" else "Post unpinned"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Unable to update pin state."
            }
        }
    }

    fun adminSetCommunityUserBlocked(targetUid: String, userName: String, blocked: Boolean, reason: String) {
        viewModelScope.launch {
            val res = repository.v2.adminSetCommunityUserBlocked(targetUid, userName, blocked, reason)
            _statusBanner.value = if (res.isSuccess) {
                if (blocked) "Blocked $userName from posting/commenting" else "Unblocked $userName"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Failed to update restriction."
            }
        }
    }

    fun adminUpdateCommunityReportStatus(reportId: String, newStatus: String, adminNote: String) {
        viewModelScope.launch {
            val res = repository.community.updateCommunityReportStatus(reportId, newStatus, adminNote)
            _statusBanner.value = if (res.isSuccess) {
                "Community report marked $newStatus"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Failed to update report."
            }
        }
    }

    fun exportCatalogBackupJson(): String {
        return repository.exportCatalogAsJson(errorCodes.value, problems.value)
    }

    fun deleteMyCloudData(onDeleted: () -> Unit) {
        viewModelScope.launch {
            val res = repository.cloud.deleteUserCloudData(currentUserId)
            if (res.isSuccess) {
                _statusBanner.value = "Cloud profile, bookmarks, and reports deleted."
                onDeleted()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Deletion failed"
            }
        }
    }

    companion object {
        private const val TAG = "RepairViewModel"
    }
}
