package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.remote.AnnouncementCloud
import com.example.data.remote.UserNotificationCloud
import com.example.i18n.UiStrings
import com.example.notifications.RepairProMessagingService
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMutedSteel
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotificationsScreen(
    strings: UiStrings,
    userNotifications: List<UserNotificationCloud>,
    announcements: List<AnnouncementCloud>,
    readAnnouncementIds: Set<String>,
    notificationsEnabled: Boolean,
    onToggleNotifications: (Boolean) -> Unit,
    onMarkNotificationRead: (String) -> Unit,
    onMarkAnnouncementRead: (String) -> Unit,
    onNavigateRoute: (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var permissionGranted by remember {
        mutableStateOf(RepairProMessagingService.hasNotificationPermission(context))
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
    }
    val fmt = remember { SimpleDateFormat("dd MMM • HH:mm", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBackground)
            .testTag("notifications_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("notifications_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
                }
                Column {
                    Text(strings.notificationsTitle, style = MaterialTheme.typography.headlineSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                    Text("Community replies, verification updates & admin announcements", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                }
            }
        }

        // Notification Preference & Android 13+ POST_NOTIFICATIONS Runtime Permission
        item {
            Surface(
                color = ElevatedCardSurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CardBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("In-App & Push Alerts", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                            Text("Post approvals, replies, verification & safety updates", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                        }
                        Switch(
                            checked = notificationsEnabled,
                            onCheckedChange = onToggleNotifications,
                            colors = SwitchDefaults.colors(checkedTrackColor = ElectricBluePrimary, checkedThumbColor = TextPrimaryWhite),
                            modifier = Modifier.testTag("notifications_toggle_switch")
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !permissionGranted) {
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("request_notification_permission_button")
                        ) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("Allow Android Push Notifications")
                        }
                    }
                }
            }
        }

        if (announcements.isNotEmpty()) {
            item {
                Text("Official Announcements", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
            }
            items(announcements, key = { "ann_${it.announcementId.ifBlank { it.id }}" }) { ann ->
                val annId = ann.announcementId.ifBlank { ann.id }
                val isUnread = annId !in readAnnouncementIds
                Surface(
                    color = if (isUnread) ElectricBluePrimary.copy(alpha = 0.14f) else ElevatedCardSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, if (isUnread) CyanAccent.copy(alpha = 0.6f) else CardBorderSubtle),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (isUnread) onMarkAnnouncementRead(annId)
                            if (ann.targetRoute.isNotBlank()) onNavigateRoute(ann.targetRoute)
                        }
                        .testTag("announcement_card_$annId")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CyanAccent.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Campaign, contentDescription = null, tint = CyanAccent)
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(ann.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (isUnread) {
                                    Box(modifier = Modifier.size(9.dp).clip(CircleShape).background(CyanAccent))
                                }
                            }
                            Text(ann.body, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                            val ts = ann.createdAt?.toDate()?.let { fmt.format(it) } ?: ""
                            Text("${ann.category} • $ts", style = MaterialTheme.typography.labelSmall, color = TextMutedSteel)
                        }
                    }
                }
            }
        }

        item {
            Text("Personal Activity", style = MaterialTheme.typography.titleMedium, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
        }

        if (userNotifications.isEmpty()) {
            item {
                Surface(
                    color = ElevatedCardSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CardBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Filled.Notifications, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(34.dp))
                        Text("You're all caught up", style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite)
                        Text("Approvals, comments, replies, and technician verification updates will appear here.", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                    }
                }
            }
        } else {
            items(userNotifications, key = { "ntf_${it.notificationId.ifBlank { it.id }}" }) { item ->
                val notifId = item.notificationId.ifBlank { item.id }
                val iconAndTint = when (item.type) {
                    "POST_APPROVED" -> Icons.Filled.CheckCircle to SuccessGreen
                    "VERIFICATION_APPROVED" -> Icons.Filled.Verified to SuccessGreen
                    "COMMENT", "REPLY" -> Icons.Filled.Forum to CyanAccent
                    else -> Icons.Filled.Notifications to WarningAmber
                }
                Surface(
                    color = if (!item.isRead) ElectricBluePrimary.copy(alpha = 0.13f) else ElevatedCardSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, if (!item.isRead) CyanAccent.copy(alpha = 0.55f) else CardBorderSubtle),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (!item.isRead) onMarkNotificationRead(notifId)
                            if (item.targetRoute.isNotBlank()) onNavigateRoute(item.targetRoute)
                        }
                        .testTag("user_notification_card_$notifId")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(iconAndTint.second.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(iconAndTint.first, contentDescription = item.type, tint = iconAndTint.second, modifier = Modifier.size(20.dp))
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(item.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (!item.isRead) {
                                    Box(modifier = Modifier.size(9.dp).clip(CircleShape).background(CyanAccent))
                                }
                            }
                            Text(item.body, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                            val ts = item.createdAt?.toDate()?.let { fmt.format(it) } ?: fmt.format(Date())
                            Text(ts, style = MaterialTheme.typography.labelSmall, color = TextMutedSteel)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
