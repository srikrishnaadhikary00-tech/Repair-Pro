package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.COMMUNITY_CATEGORIES
import com.example.data.remote.CommunityDomainHelper
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.CommunityUserRestrictionCloud
import com.example.data.remote.SavedPostCloud
import com.example.i18n.AppLanguage
import com.example.i18n.StringsProvider
import com.example.ui.UiState
import com.example.ui.components.RepairProTopHeader
import com.example.ui.theme.CardBorderCyan
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

@Composable
fun CommunityFeedScreen(
    language: AppLanguage,
    currentUserUid: String,
    userName: String,
    userPhotoUrl: String,
    unreadNotificationCount: Int,
    isAdmin: Boolean,
    restriction: CommunityUserRestrictionCloud?,
    approvedPostsState: UiState<List<CommunityPostCloud>>,
    myPosts: List<CommunityPostCloud>,
    likedPostIds: Set<String>,
    savedPosts: List<SavedPostCloud>,
    initialTab: Int = 0,
    onOpenMenu: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenProfile: () -> Unit,
    onRetry: () -> Unit,
    onOpenCreatePost: () -> Unit,
    onEditPost: (String) -> Unit,
    onOpenPost: (String) -> Unit,
    onOpenImageViewer: (url: String, title: String) -> Unit,
    onToggleLike: (String) -> Unit,
    onToggleBookmark: (CommunityPostCloud) -> Unit,
    onRemoveSavedPost: (SavedPostCloud) -> Unit,
    onReportPost: (postId: String, reason: String, details: String, onSuccess: () -> Unit) -> Unit,
    onDeletePost: (CommunityPostCloud) -> Unit
) {
    val strings = StringsProvider.get(language)
    val context = LocalContext.current
    var activeTab by rememberSaveable(initialTab) { mutableIntStateOf(initialTab) } // 0 = For You, 1 = My Posts, 2 = Saved
    var selectedCategory by rememberSaveable { mutableStateOf("ALL") }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var visibleCount by rememberSaveable { mutableIntStateOf(10) }
    var reportingPostId by remember { mutableStateOf<String?>(null) }
    var deletingPost by remember { mutableStateOf<CommunityPostCloud?>(null) }

    val isBlocked = restriction != null
    val savedPostIds = remember(savedPosts) { savedPosts.map { it.postId.ifBlank { it.id } }.toSet() }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .testTag("community_feed_list"),
            contentPadding = PaddingValues(top = 6.dp, bottom = 92.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                RepairProTopHeader(
                    subtitle = strings.communityTitle,
                    userName = userName,
                    userPhotoUrl = userPhotoUrl,
                    unreadNotifications = unreadNotificationCount,
                    onOpenMenu = onOpenMenu,
                    onOpenNotifications = onOpenNotifications,
                    onOpenProfile = onOpenProfile
                )
            }

            if (isBlocked) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = ErrorCrimson.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.55f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Filled.Block, contentDescription = null, tint = ErrorCrimson)
                            Column {
                                Text(
                                    text = "Posting & Commenting Restricted",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = ErrorCrimson,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = restriction?.reason?.ifBlank { "Restricted by Super Admin moderation." }
                                        ?: "Restricted by Super Admin moderation.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimaryWhite
                                )
                            }
                        }
                    }
                }
            }

            // Tabs + Refresh button
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val tabs = listOf(
                            0 to "For You",
                            1 to "My Posts (${myPosts.size})",
                            2 to "Saved (${savedPosts.size})"
                        )
                        tabs.forEach { (idx, label) ->
                            FilterChip(
                                selected = activeTab == idx,
                                onClick = {
                                    activeTab = idx
                                    visibleCount = 10
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag("community_tab_$idx"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricBluePrimary,
                                    selectedLabelColor = TextPrimaryWhite,
                                    containerColor = SecondaryNavySurface,
                                    labelColor = TextSecondarySlate
                                )
                            )
                        }
                    }
                    IconButton(
                        onClick = onRetry,
                        modifier = Modifier.testTag("community_refresh_button")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh feed", tint = CyanAccent)
                    }
                }
            }

            // Search + Category Filters
            if (activeTab == 0 || activeTab == 1) {
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it.take(80)
                            visibleCount = 10
                        },
                        label = { Text("Search posts, brand, model, or error code") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = CyanAccent) },
                        singleLine = true,
                        colors = communityTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("community_search_input")
                    )
                }
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val cats = listOf("ALL") + COMMUNITY_CATEGORIES
                        cats.forEach { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = {
                                    selectedCategory = cat
                                    visibleCount = 10
                                },
                                label = { Text(if (cat == "ALL") "All" else cat) },
                                modifier = Modifier.testTag("community_filter_${cat.lowercase().replace(" ", "_")}"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                                    selectedLabelColor = CyanAccent,
                                    containerColor = DeepCardSurface,
                                    labelColor = TextSecondarySlate
                                )
                            )
                        }
                    }
                }
            }

            when (activeTab) {
                0 -> {
                    when (approvedPostsState) {
                        is UiState.Loading -> {
                            item {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        CircularProgressIndicator(color = CyanAccent)
                                        Text("Loading Technician Community…", style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                                    }
                                }
                            }
                        }

                        is UiState.Error -> {
                            item {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = ElevatedCardSurface,
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.5f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text("Unable to load community feed", style = MaterialTheme.typography.titleSmall, color = ErrorCrimson)
                                        Text(approvedPostsState.message, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                                        OutlinedButton(
                                            onClick = onRetry,
                                            border = BorderStroke(1.dp, CyanAccent),
                                            modifier = Modifier.testTag("community_retry_button")
                                        ) {
                                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Retry", color = CyanAccent)
                                        }
                                    }
                                }
                            }
                        }

                        is UiState.Success -> {
                            val filtered = CommunityDomainHelper.filterPosts(
                                posts = approvedPostsState.data,
                                category = selectedCategory,
                                query = searchQuery
                            )
                            if (filtered.isEmpty()) {
                                item {
                                    CommunityEmptyCard(
                                        title = if (approvedPostsState.data.isEmpty()) "No approved community posts yet" else "No matching posts",
                                        subtitle = if (approvedPostsState.data.isEmpty()) {
                                            "Share a field repair case, PCB photos, or error code solution with fellow technicians."
                                        } else {
                                            "Try clearing your search query or switching category filters."
                                        },
                                        onCreateClick = onOpenCreatePost
                                    )
                                }
                            } else {
                                val paginated = filtered.take(visibleCount)
                                items(paginated, key = { it.postId.ifBlank { it.id } }) { post ->
                                    val pid = post.postId.ifBlank { post.id }
                                    CommunityPostCard(
                                        post = post,
                                        showStatusBanner = false,
                                        isLiked = likedPostIds.contains(pid),
                                        isBookmarked = savedPostIds.contains(pid),
                                        canEdit = post.authorUid == currentUserUid && !isBlocked,
                                        canDelete = post.authorUid == currentUserUid || isAdmin,
                                        onOpen = { onOpenPost(pid) },
                                        onOpenImageViewer = onOpenImageViewer,
                                        onToggleLike = { onToggleLike(pid) },
                                        onToggleBookmark = { onToggleBookmark(post) },
                                        onShare = {
                                            val shareText = buildString {
                                                append("Repair Pro Community — ${post.title}\n")
                                                if (post.brandName.isNotBlank() || post.errorCode.isNotBlank()) {
                                                    append("${post.category} | ${post.brandName} ${post.errorCode}\n\n")
                                                }
                                                append(post.body)
                                            }
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, shareText)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Share Community Post"))
                                        },
                                        onEdit = { onEditPost(pid) },
                                        onReport = { reportingPostId = pid },
                                        onDelete = { deletingPost = post }
                                    )
                                }
                                if (filtered.size > visibleCount) {
                                    item {
                                        OutlinedButton(
                                            onClick = { visibleCount += 10 },
                                            border = BorderStroke(1.dp, CyanAccent),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("community_load_more_button")
                                        ) {
                                            Text("Load More (${filtered.size - visibleCount} remaining)", color = CyanAccent)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    val filteredMine = CommunityDomainHelper.filterPosts(myPosts, selectedCategory, searchQuery)
                    if (filteredMine.isEmpty()) {
                        item {
                            CommunityEmptyCard(
                                title = "You haven't posted yet",
                                subtitle = "Submit your first repair question or field solution. Pending posts appear here until approved by Super Admin.",
                                onCreateClick = onOpenCreatePost
                            )
                        }
                    } else {
                        items(filteredMine, key = { it.postId.ifBlank { it.id } }) { post ->
                            val pid = post.postId.ifBlank { post.id }
                            CommunityPostCard(
                                post = post,
                                showStatusBanner = true,
                                isLiked = likedPostIds.contains(pid),
                                isBookmarked = savedPostIds.contains(pid),
                                canEdit = !isBlocked,
                                canDelete = true,
                                onOpen = { onOpenPost(pid) },
                                onOpenImageViewer = onOpenImageViewer,
                                onToggleLike = { onToggleLike(pid) },
                                onToggleBookmark = { onToggleBookmark(post) },
                                onShare = {
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, "${post.title}\n\n${post.body}")
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Share Post"))
                                },
                                onEdit = { onEditPost(pid) },
                                onReport = { reportingPostId = pid },
                                onDelete = { deletingPost = post }
                            )
                        }
                    }
                }

                2 -> {
                    if (savedPosts.isEmpty()) {
                        item {
                            CommunityEmptyCard(
                                title = "No bookmarked posts",
                                subtitle = "Tap the bookmark icon on any Technician Community post to save it here for quick field reference.",
                                onCreateClick = { activeTab = 0 },
                                actionLabel = "Browse Community"
                            )
                        }
                    } else {
                        items(savedPosts, key = { it.postId.ifBlank { it.id } }) { saved ->
                            val pid = saved.postId.ifBlank { saved.id }
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { onOpenPost(pid) }
                                    .testTag("saved_post_card_$pid"),
                                color = ElevatedCardSurface,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, CardBorderSubtle)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    if (saved.photoUrl.startsWith("https://")) {
                                        AsyncImage(
                                            model = saved.photoUrl,
                                            contentDescription = saved.title,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(56.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(
                                            text = saved.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimaryWhite,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${saved.category} • By ${saved.authorName}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CyanAccent
                                        )
                                    }
                                    IconButton(
                                        onClick = { onRemoveSavedPost(saved) },
                                        modifier = Modifier.testTag("remove_saved_post_$pid")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Bookmark,
                                            contentDescription = "Remove bookmark",
                                            tint = CyanAccent
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating Create Post Action Button
        if (!isBlocked) {
            FloatingActionButton(
                onClick = onOpenCreatePost,
                containerColor = ElectricBluePrimary,
                contentColor = TextPrimaryWhite,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(18.dp)
                    .testTag("community_new_post_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Create Community Post")
            }
        }
    }

    val activeReportId = reportingPostId
    if (activeReportId != null) {
        ReportCommunityDialog(
            targetLabel = "Community Post",
            onDismiss = { reportingPostId = null },
            onSubmit = { reason, details ->
                onReportPost(activeReportId, reason, details) {
                    reportingPostId = null
                }
            }
        )
    }

    val targetDelete = deletingPost
    if (targetDelete != null) {
        AlertDialog(
            onDismissRequest = { deletingPost = null },
            containerColor = SecondaryNavySurface,
            title = { Text("Delete Post?", color = ErrorCrimson, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    text = "Permanently delete \"${targetDelete.title}\"? This action cannot be undone.",
                    color = TextPrimaryWhite
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePost(targetDelete)
                        deletingPost = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorCrimson),
                    modifier = Modifier.testTag("confirm_delete_post_button")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingPost = null }) {
                    Text("Cancel", color = TextSecondarySlate)
                }
            }
        )
    }
}

@Composable
private fun CommunityEmptyCard(
    title: String,
    subtitle: String,
    onCreateClick: () -> Unit,
    actionLabel: String = "Create Post"
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Filled.Forum, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(36.dp))
            Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
            Spacer(modifier = Modifier.height(4.dp))
            Button(
                onClick = onCreateClick,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBluePrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(actionLabel)
            }
        }
    }
}

@Composable
private fun CommunityPostCard(
    post: CommunityPostCloud,
    showStatusBanner: Boolean,
    isLiked: Boolean,
    isBookmarked: Boolean,
    canEdit: Boolean,
    canDelete: Boolean,
    onOpen: () -> Unit,
    onOpenImageViewer: (url: String, title: String) -> Unit,
    onToggleLike: () -> Unit,
    onToggleBookmark: () -> Unit,
    onShare: () -> Unit,
    onEdit: () -> Unit,
    onReport: () -> Unit,
    onDelete: () -> Unit
) {
    val pid = post.postId.ifBlank { post.id }
    val photos = remember(post) { post.resolvedPhotoUrls() }
    val initials = remember(post.authorName) {
        post.authorName.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
            .take(2).joinToString("") { it.first().uppercase() }.ifBlank { "RP" }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onOpen)
            .testTag("community_post_card_$pid"),
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (post.isPinned) CardBorderCyan else CardBorderSubtle)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (post.isPinned) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(Icons.Filled.PushPin, contentDescription = "Pinned", tint = CyanAccent, modifier = Modifier.size(14.dp))
                    Text("Pinned by Super Admin", style = MaterialTheme.typography.labelSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
                }
            }

            // Author Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(ElectricBluePrimary.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (post.authorPhotoUrl.startsWith("https://")) {
                        AsyncImage(
                            model = post.authorPhotoUrl,
                            contentDescription = post.authorName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(38.dp).clip(CircleShape)
                        )
                    } else {
                        Text(initials, style = MaterialTheme.typography.labelLarge, color = CyanAccent, fontWeight = FontWeight.Bold)
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = post.authorName.ifBlank { "Technician" },
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (post.authorVerified) {
                            Icon(
                                imageVector = Icons.Filled.Verified,
                                contentDescription = "Verified Technician",
                                tint = SuccessGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = "${post.category} • ${formatCommunityTimestamp(post.createdAt)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondarySlate
                    )
                }
                if (showStatusBanner) {
                    CommunityStatusPill(status = post.approvalStatus)
                }
            }

            // Moderation note banner for pending/rejected user posts
            if (showStatusBanner && post.approvalStatus != "APPROVED") {
                Surface(
                    color = (if (post.approvalStatus == "REJECTED") ErrorCrimson else WarningAmber).copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (post.moderationNote.isNotBlank()) {
                            "Admin note: ${post.moderationNote}"
                        } else if (post.approvalStatus == "REJECTED") {
                            "This post was rejected by Super Admin moderation."
                        } else {
                            "Awaiting Super Admin approval before appearing in the public feed."
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (post.approvalStatus == "REJECTED") ErrorCrimson else WarningAmber,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Technical pills
            if (post.brandName.isNotBlank() || post.modelName.isNotBlank() || post.errorCode.isNotBlank()) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (post.errorCode.isNotBlank()) {
                        Surface(
                            color = ErrorCrimson.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.45f))
                        ) {
                            Text(
                                text = post.errorCode,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = ErrorCrimson,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    if (post.brandName.isNotBlank()) {
                        Surface(
                            color = DeepCardSurface,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, CardBorderSubtle)
                        ) {
                            Text(
                                text = post.brandName,
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanAccent,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    if (post.modelName.isNotBlank()) {
                        Surface(
                            color = DeepCardSurface,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, CardBorderSubtle)
                        ) {
                            Text(
                                text = post.modelName,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondarySlate,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            if (post.title.isNotBlank()) {
                Text(
                    text = post.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.Bold
                )
            }
            if (post.body.isNotBlank()) {
                Text(
                    text = post.body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondarySlate,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Multi-Photo Gallery (1 full-width or scrollable multi-photo strip with tap-to-zoom)
            if (photos.size == 1) {
                AsyncImage(
                    model = photos.first(),
                    contentDescription = "Photo for ${post.title}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 160.dp, max = 230.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(DeepCardSurface)
                        .clickable { onOpenImageViewer(photos.first(), post.title) }
                )
            } else if (photos.size > 1) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    photos.forEachIndexed { index, url ->
                        AsyncImage(
                            model = url,
                            contentDescription = "Photo ${index + 1} for ${post.title}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .width(200.dp)
                                .height(165.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(DeepCardSurface)
                                .clickable { onOpenImageViewer(url, "${post.title} (${index + 1}/${photos.size})") }
                        )
                    }
                }
            }

            // Action Bar: Like, Comment, Share, Bookmark, Edit, Report, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(
                        onClick = onToggleLike,
                        enabled = post.approvalStatus == "APPROVED",
                        modifier = Modifier.testTag("post_like_btn_$pid")
                    ) {
                        Icon(
                            imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = if (isLiked) "Unlike post" else "Like post",
                            tint = if (isLiked) ErrorCrimson else TextSecondarySlate
                        )
                    }
                    Text(
                        text = "${post.likeCount.coerceAtLeast(0L)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isLiked) ErrorCrimson else TextSecondarySlate
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = onOpen,
                        modifier = Modifier.testTag("post_comment_btn_$pid")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ChatBubbleOutline,
                            contentDescription = "View comments",
                            tint = CyanAccent
                        )
                    }
                    Text(
                        text = "${post.commentCount.coerceAtLeast(0L)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondarySlate
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onShare,
                        modifier = Modifier.testTag("post_share_btn_$pid")
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = "Share post", tint = TextSecondarySlate)
                    }
                    IconButton(
                        onClick = onToggleBookmark,
                        modifier = Modifier.testTag("post_bookmark_btn_$pid")
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                            contentDescription = if (isBookmarked) "Remove bookmark" else "Bookmark post",
                            tint = if (isBookmarked) CyanAccent else TextSecondarySlate
                        )
                    }
                    if (canEdit) {
                        IconButton(
                            onClick = onEdit,
                            modifier = Modifier.testTag("post_edit_btn_$pid")
                        ) {
                            Icon(Icons.Filled.Edit, contentDescription = "Edit post", tint = CyanAccent)
                        }
                    }
                    if (post.approvalStatus == "APPROVED") {
                        IconButton(
                            onClick = onReport,
                            modifier = Modifier.testTag("post_report_btn_$pid")
                        ) {
                            Icon(Icons.Filled.Flag, contentDescription = "Report post", tint = WarningAmber)
                        }
                    }
                    if (canDelete) {
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.testTag("post_delete_btn_$pid")
                        ) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete post", tint = ErrorCrimson)
                        }
                    }
                }
            }
        }
    }
}
