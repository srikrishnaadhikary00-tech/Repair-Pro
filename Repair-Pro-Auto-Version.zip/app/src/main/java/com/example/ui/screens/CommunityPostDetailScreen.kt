package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.CommunityCommentCloud
import com.example.data.remote.CommunityDomainHelper
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.CommunityUserRestrictionCloud
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DeepCardSurface
import com.example.ui.theme.ElectricBluePrimary
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SecondaryNavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.WarningAmber

private data class ReplyTarget(
    val parentCommentId: String,
    val authorName: String,
    val authorUid: String
)

@Composable
fun CommunityPostDetailScreen(
    post: CommunityPostCloud?,
    comments: List<CommunityCommentCloud>,
    currentUserUid: String,
    isAdmin: Boolean,
    restriction: CommunityUserRestrictionCloud?,
    isLiked: Boolean,
    isBookmarked: Boolean,
    onBack: () -> Unit,
    onEditPost: (String) -> Unit,
    onOpenImageViewer: (url: String, title: String) -> Unit,
    onToggleLike: () -> Unit,
    onToggleBookmark: () -> Unit,
    onAddComment: (
        body: String,
        parentCommentId: String,
        replyToAuthorName: String,
        postAuthorUid: String,
        replyTargetUid: String,
        onSuccess: () -> Unit
    ) -> Unit,
    onEditComment: (commentId: String, newBody: String, onSuccess: () -> Unit) -> Unit,
    onDeleteComment: (commentId: String) -> Unit,
    onReport: (commentId: String, reason: String, details: String, onSuccess: () -> Unit) -> Unit,
    onDeletePost: (onDeleted: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    var commentDraft by remember { mutableStateOf("") }
    var commentError by remember { mutableStateOf<String?>(null) }
    var replyTarget by remember { mutableStateOf<ReplyTarget?>(null) }
    var reportCommentId by remember { mutableStateOf<String?>(null) }
    var editingComment by remember { mutableStateOf<CommunityCommentCloud?>(null) }
    var confirmDeletePost by remember { mutableStateOf(false) }

    val isBlocked = restriction != null
    val threads = remember(comments) { CommunityDomainHelper.buildCommentThreads(comments) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("community_detail_back")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimaryWhite)
            }
            Text(
                text = "Technician Discussion",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimaryWhite,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            if (post != null) {
                val pid = post.postId.ifBlank { post.id }
                IconButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "Repair Pro Community — ${post.title}\n\n${post.body}")
                        }
                        context.startActivity(Intent.createChooser(intent, "Share Post"))
                    },
                    modifier = Modifier.testTag("detail_share_post_button")
                ) {
                    Icon(Icons.Filled.Share, contentDescription = "Share post", tint = TextSecondarySlate)
                }
                IconButton(onClick = onToggleBookmark, modifier = Modifier.testTag("detail_bookmark_button")) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                        contentDescription = if (isBookmarked) "Remove bookmark" else "Bookmark post",
                        tint = if (isBookmarked) CyanAccent else TextSecondarySlate
                    )
                }
                if (post.authorUid == currentUserUid && !isBlocked) {
                    IconButton(onClick = { onEditPost(pid) }, modifier = Modifier.testTag("detail_edit_post_button")) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit post", tint = CyanAccent)
                    }
                }
                if (post.approvalStatus == "APPROVED") {
                    IconButton(onClick = { reportCommentId = "" }, modifier = Modifier.testTag("detail_report_post_button")) {
                        Icon(Icons.Filled.Flag, contentDescription = "Report post", tint = WarningAmber)
                    }
                }
                if (post.authorUid == currentUserUid || isAdmin) {
                    IconButton(onClick = { confirmDeletePost = true }, modifier = Modifier.testTag("detail_delete_post_button")) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete post", tint = ErrorCrimson)
                    }
                }
            }
        }

        if (post == null) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Post not available", style = MaterialTheme.typography.titleMedium, color = TextPrimaryWhite)
                    Text(
                        text = "This post may have been deleted or is pending Super Admin moderation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate
                    )
                    Button(onClick = onBack) { Text("Back to Community") }
                }
            }
            return
        }

        val photos = remember(post) { post.resolvedPhotoUrls() }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("community_detail_list"),
            contentPadding = PaddingValues(top = 6.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = ElevatedCardSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CardBorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (post.isPinned) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                Icon(Icons.Filled.PushPin, contentDescription = "Pinned", tint = CyanAccent, modifier = Modifier.size(14.dp))
                                Text("Pinned Post", style = MaterialTheme.typography.labelSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(ElectricBluePrimary.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (post.authorPhotoUrl.startsWith("https://")) {
                                        AsyncImage(
                                            model = post.authorPhotoUrl,
                                            contentDescription = post.authorName,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.size(38.dp).clip(CircleShape)
                                        )
                                    } else {
                                        Text(
                                            text = post.authorName.take(2).uppercase().ifBlank { "RP" },
                                            style = MaterialTheme.typography.labelLarge,
                                            color = CyanAccent,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(post.authorName.ifBlank { "Technician" }, style = MaterialTheme.typography.titleSmall, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                                        if (post.authorVerified) {
                                            Icon(Icons.Filled.Verified, contentDescription = "Verified Technician", tint = SuccessGreen, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    Text("${post.category} • ${formatCommunityTimestamp(post.createdAt)}", style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate)
                                }
                            }
                            if (post.approvalStatus != "APPROVED") {
                                CommunityStatusPill(status = post.approvalStatus)
                            }
                        }

                        if (post.approvalStatus != "APPROVED") {
                            Surface(
                                color = (if (post.approvalStatus == "REJECTED") ErrorCrimson else WarningAmber).copy(alpha = 0.14f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = post.moderationNote.ifBlank {
                                        if (post.approvalStatus == "REJECTED") "Rejected by Super Admin." else "Pending Super Admin approval."
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (post.approvalStatus == "REJECTED") ErrorCrimson else WarningAmber,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        if (post.brandName.isNotBlank() || post.modelName.isNotBlank() || post.errorCode.isNotBlank()) {
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (post.errorCode.isNotBlank()) {
                                    Surface(color = ErrorCrimson.copy(alpha = 0.16f), shape = RoundedCornerShape(8.dp)) {
                                        Text(
                                            text = post.errorCode,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = JetBrainsMonoFontFamily,
                                            color = ErrorCrimson,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                                if (post.brandName.isNotBlank()) {
                                    Surface(color = DeepCardSurface, shape = RoundedCornerShape(8.dp)) {
                                        Text(post.brandName, style = MaterialTheme.typography.labelSmall, color = CyanAccent, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                    }
                                }
                                if (post.modelName.isNotBlank()) {
                                    Surface(color = DeepCardSurface, shape = RoundedCornerShape(8.dp)) {
                                        Text(post.modelName, style = MaterialTheme.typography.labelSmall, color = TextSecondarySlate, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                    }
                                }
                            }
                        }

                        if (post.title.isNotBlank()) {
                            Text(post.title, style = MaterialTheme.typography.titleLarge, color = TextPrimaryWhite, fontWeight = FontWeight.Bold)
                        }
                        if (post.body.isNotBlank()) {
                            Text(post.body, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryWhite)
                        }

                        if (photos.size == 1) {
                            AsyncImage(
                                model = photos.first(),
                                contentDescription = "Post photo",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 180.dp, max = 340.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DeepCardSurface)
                                    .clickable { onOpenImageViewer(photos.first(), post.title) }
                            )
                        } else if (photos.size > 1) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                photos.forEachIndexed { idx, url ->
                                    AsyncImage(
                                        model = url,
                                        contentDescription = "Post photo ${idx + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .width(240.dp)
                                            .height(210.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(DeepCardSurface)
                                            .clickable { onOpenImageViewer(url, "${post.title} (${idx + 1}/${photos.size})") }
                                    )
                                }
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                onClick = onToggleLike,
                                enabled = post.approvalStatus == "APPROVED",
                                color = if (isLiked) ErrorCrimson.copy(alpha = 0.18f) else DeepCardSurface,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, if (isLiked) ErrorCrimson else CardBorderSubtle),
                                modifier = Modifier.testTag("detail_like_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                        contentDescription = "Like",
                                        tint = if (isLiked) ErrorCrimson else TextSecondarySlate,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "${post.likeCount.coerceAtLeast(0L)} Likes",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (isLiked) ErrorCrimson else TextPrimaryWhite
                                    )
                                }
                            }

                            Text(
                                text = "${comments.size} Comments & Replies",
                                style = MaterialTheme.typography.labelMedium,
                                color = CyanAccent
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Discussion (${comments.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = CyanAccent,
                    fontWeight = FontWeight.Bold
                )
            }

            if (threads.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = DeepCardSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, CardBorderSubtle)
                    ) {
                        Text(
                            text = if (post.approvalStatus == "APPROVED") {
                                "No comments yet. Share your troubleshooting experience below."
                            } else {
                                "Comments unlock once this post is approved by Super Admin."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            } else {
                items(threads, key = { it.parent.commentId.ifBlank { it.parent.id } }) { thread ->
                    val rootId = thread.parent.commentId.ifBlank { thread.parent.id }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        CommentItemCard(
                            comment = thread.parent,
                            isNestedReply = false,
                            canReply = post.approvalStatus == "APPROVED" && !isBlocked,
                            canEdit = thread.parent.authorUid == currentUserUid && !isBlocked,
                            canDelete = thread.parent.authorUid == currentUserUid || isAdmin,
                            onReply = {
                                replyTarget = ReplyTarget(
                                    parentCommentId = rootId,
                                    authorName = thread.parent.authorName.ifBlank { "Technician" },
                                    authorUid = thread.parent.authorUid
                                )
                            },
                            onEdit = { editingComment = thread.parent },
                            onReport = { reportCommentId = rootId },
                            onDelete = { onDeleteComment(rootId) }
                        )

                        thread.replies.forEach { reply ->
                            val replyId = reply.commentId.ifBlank { reply.id }
                            Row(modifier = Modifier.fillMaxWidth().padding(start = 20.dp)) {
                                Box(
                                    modifier = Modifier
                                        .width(2.dp)
                                        .height(64.dp)
                                        .background(CyanAccent.copy(alpha = 0.4f))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                CommentItemCard(
                                    comment = reply,
                                    isNestedReply = true,
                                    canReply = post.approvalStatus == "APPROVED" && !isBlocked,
                                    canEdit = reply.authorUid == currentUserUid && !isBlocked,
                                    canDelete = reply.authorUid == currentUserUid || isAdmin,
                                    onReply = {
                                        replyTarget = ReplyTarget(
                                            parentCommentId = rootId,
                                            authorName = reply.authorName.ifBlank { "Technician" },
                                            authorUid = reply.authorUid
                                        )
                                    },
                                    onEdit = { editingComment = reply },
                                    onReport = { reportCommentId = replyId },
                                    onDelete = { onDeleteComment(replyId) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Comment / Reply Composer
        if (post.approvalStatus == "APPROVED" && !isBlocked) {
            Surface(
                color = DeepCardSurface,
                border = BorderStroke(1.dp, CardBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val activeReply = replyTarget
                    if (activeReply != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(ElectricBluePrimary.copy(alpha = 0.2f))
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Replying to @${activeReply.authorName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanAccent
                            )
                            IconButton(
                                onClick = { replyTarget = null },
                                modifier = Modifier.size(28.dp).testTag("clear_reply_target_button")
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "Cancel reply", tint = TextSecondarySlate, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                    if (!commentError.isNullOrBlank()) {
                        Text(commentError!!, style = MaterialTheme.typography.labelSmall, color = ErrorCrimson)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = commentDraft,
                            onValueChange = {
                                commentDraft = it.take(1000)
                                commentError = null
                            },
                            placeholder = {
                                Text(if (activeReply == null) "Write a comment…" else "Write a reply…")
                            },
                            maxLines = 3,
                            colors = communityTextFieldColors(),
                            modifier = Modifier.weight(1f).testTag("community_comment_input")
                        )
                        IconButton(
                            onClick = {
                                val err = CommunityDomainHelper.validateCommentBody(commentDraft)
                                if (err != null) {
                                    commentError = err
                                    return@IconButton
                                }
                                onAddComment(
                                    commentDraft.trim(),
                                    activeReply?.parentCommentId.orEmpty(),
                                    activeReply?.authorName.orEmpty(),
                                    post.authorUid,
                                    activeReply?.authorUid.orEmpty()
                                ) {
                                    commentDraft = ""
                                    replyTarget = null
                                    commentError = null
                                }
                            },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(ElectricBluePrimary)
                                .testTag("community_send_comment_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send comment", tint = TextPrimaryWhite)
                        }
                    }
                }
            }
        }
    }

    val activeEdit = editingComment
    if (activeEdit != null) {
        val cid = activeEdit.commentId.ifBlank { activeEdit.id }
        EditCommunityCommentDialog(
            initialBody = activeEdit.body,
            onDismiss = { editingComment = null },
            onSave = { updatedBody ->
                onEditComment(cid, updatedBody) {
                    editingComment = null
                }
            }
        )
    }

    val activeReportComment = reportCommentId
    if (activeReportComment != null) {
        ReportCommunityDialog(
            targetLabel = if (activeReportComment.isEmpty()) "Community Post" else "Comment",
            onDismiss = { reportCommentId = null },
            onSubmit = { reason, details ->
                onReport(activeReportComment, reason, details) {
                    reportCommentId = null
                }
            }
        )
    }

    if (confirmDeletePost) {
        AlertDialog(
            onDismissRequest = { confirmDeletePost = false },
            containerColor = SecondaryNavySurface,
            title = { Text("Delete Post?", color = ErrorCrimson, fontWeight = FontWeight.Bold) },
            text = { Text("Permanently remove this post from Technician Community?", color = TextPrimaryWhite) },
            confirmButton = {
                Button(
                    onClick = {
                        confirmDeletePost = false
                        onDeletePost(onBack)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorCrimson)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeletePost = false }) {
                    Text("Cancel", color = TextSecondarySlate)
                }
            }
        )
    }
}

@Composable
private fun CommentItemCard(
    comment: CommunityCommentCloud,
    isNestedReply: Boolean,
    canReply: Boolean,
    canEdit: Boolean,
    canDelete: Boolean,
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onReport: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cid = comment.commentId.ifBlank { comment.id }
    Surface(
        modifier = modifier.fillMaxWidth().testTag("comment_card_$cid"),
        color = if (isNestedReply) DeepCardSurface else ElevatedCardSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, CardBorderSubtle)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = comment.authorName.ifBlank { "Technician" },
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.Bold
                    )
                    if (comment.authorVerified) {
                        Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = SuccessGreen, modifier = Modifier.size(14.dp))
                    }
                }
                Text(
                    text = formatCommunityTimestamp(comment.createdAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondarySlate
                )
            }

            if (isNestedReply && comment.replyToAuthorName.isNotBlank()) {
                Text(
                    text = "@${comment.replyToAuthorName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyanAccent,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Text(
                text = comment.body,
                style = MaterialTheme.typography.bodySmall,
                color = TextPrimaryWhite
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                if (canReply) {
                    TextButton(
                        onClick = onReply,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("reply_comment_btn_$cid")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Reply, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Reply", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    }
                }
                if (canEdit) {
                    TextButton(
                        onClick = onEdit,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("edit_comment_btn_$cid")
                    ) {
                        Icon(Icons.Filled.Edit, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Edit", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    }
                }
                TextButton(
                    onClick = onReport,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.testTag("report_comment_btn_$cid")
                ) {
                    Icon(Icons.Filled.Flag, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Report", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
                if (canDelete) {
                    TextButton(
                        onClick = onDelete,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("delete_comment_btn_$cid")
                    ) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = ErrorCrimson, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Delete", style = MaterialTheme.typography.labelSmall, color = ErrorCrimson)
                    }
                }
            }
        }
    }
}
