package com.example.data.remote

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import com.google.firebase.storage.storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

data class PendingCommunityPhoto(
    val bytes: ByteArray,
    val mimeType: String = "image/jpeg"
)

class CommunityRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
    private val storageProvider: () -> FirebaseStorage = { Firebase.storage }
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Please sign in with Google to use Technician Community.")
    }

    fun observeApprovedPosts(userId: String): Flow<List<CommunityPostCloud>> = flow {
        val path = "community_posts"
        emitAll(
            db.collection("community_posts")
                .whereEqualTo("approvalStatus", "APPROVED")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CommunityPostCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .filter { it.approvalStatus == "APPROVED" }
                        .sortedWith(
                            compareByDescending<CommunityPostCloud> { it.isPinned }
                                .thenByDescending { it.createdAt?.seconds ?: 0L }
                        )
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeMyPosts(userId: String): Flow<List<CommunityPostCloud>> = flow {
        val path = "community_posts"
        emitAll(
            db.collection("community_posts")
                .whereEqualTo("authorUid", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(CommunityPostCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeAllPostsForAdmin(adminUid: String): Flow<List<CommunityPostCloud>> = flow {
        val path = "community_posts"
        emitAll(
            db.collection("community_posts")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CommunityPostCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedWith(
                            compareByDescending<CommunityPostCloud> { it.isPinned }
                                .thenByDescending { it.createdAt?.seconds ?: 0L }
                        )
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    fun observePost(postId: String, userId: String): Flow<CommunityPostCloud?> = flow {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        emitAll(
            db.collection("community_posts")
                .document(safePostId)
                .snapshots()
                .map { snap ->
                    if (snap.exists()) {
                        snap.toObject(CommunityPostCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                    } else null
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeLikedPostIds(userId: String): Flow<Set<String>> = flow {
        val path = "users/$userId/liked_posts"
        emitAll(
            db.collection("users").document(userId).collection("liked_posts")
                .snapshots()
                .map { snap -> snap.documents.map { it.id }.toSet() }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeSavedPosts(userId: String): Flow<List<SavedPostCloud>> = flow {
        val path = "users/$userId/saved_posts"
        emitAll(
            db.collection("users").document(userId).collection("saved_posts")
                .snapshots()
                .map { snap ->
                    snap.toObjects(SavedPostCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeComments(postId: String, userId: String): Flow<List<CommunityCommentCloud>> = flow {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId/comments"
        emitAll(
            db.collection("community_posts").document(safePostId).collection("comments")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CommunityCommentCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeAllCommunityReportsForAdmin(adminUid: String): Flow<List<CommunityReportCloud>> = flow {
        val path = "community_reports"
        emitAll(
            db.collection("community_reports")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CommunityReportCloud::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, adminUid)
                    throw error
                }
        )
    }

    suspend fun uploadCommunityPostPhoto(
        userId: String,
        postId: String,
        imageBytes: ByteArray,
        contentType: String = "image/jpeg",
        index: Int = 0,
        onProgress: (Float) -> Unit = {}
    ): Result<Pair<String, String>> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val safeContentType = when (contentType.lowercase()) {
            "image/png" -> "image/png"
            "image/webp" -> "image/webp"
            else -> "image/jpeg"
        }
        val ext = when (safeContentType) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        val storagePath = "community_posts/$userId/$safePostId/photo_${index}_${System.currentTimeMillis()}.$ext"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            require(imageBytes.isNotEmpty() && imageBytes.size < 5 * 1024 * 1024) {
                "Each photo must be smaller than 5 MB."
            }
            val ref = storageProvider().reference.child(storagePath)
            val metadata = StorageMetadata.Builder()
                .setContentType(safeContentType)
                .build()
            val task = ref.putBytes(imageBytes, metadata)
            task.addOnProgressListener { snap ->
                if (snap.totalByteCount > 0) {
                    onProgress((snap.bytesTransferred.toFloat() / snap.totalByteCount.toFloat()).coerceIn(0f, 1f))
                }
            }
            task.await()
            val downloadUrl = ref.downloadUrl.await().toString()
            Result.success(downloadUrl to storagePath)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createPost(
        userId: String,
        authorName: String,
        authorPhotoUrl: String = "",
        category: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        title: String,
        body: String,
        photos: List<PendingCommunityPhoto> = emptyList(),
        isAdminAuthor: Boolean,
        onUploadProgress: (Float) -> Unit = {}
    ): Result<String> {
        val postId = CloudRepository.sanitizeId("post_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "community_posts/$postId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val boundedPhotos = photos.take(4)
            val validationError = CommunityDomainHelper.validatePostDraft(
                title = title,
                body = body,
                category = category,
                hasPhotos = boundedPhotos.isNotEmpty()
            )
            require(validationError == null) { validationError ?: "Invalid post." }

            val uploadedUrls = mutableListOf<String>()
            val uploadedPaths = mutableListOf<String>()
            boundedPhotos.forEachIndexed { idx, photo ->
                val uploadRes = uploadCommunityPostPhoto(
                    userId = userId,
                    postId = postId,
                    imageBytes = photo.bytes,
                    contentType = photo.mimeType,
                    index = idx,
                    onProgress = { single ->
                        val overall = (idx + single) / boundedPhotos.size.toFloat()
                        onUploadProgress(overall)
                    }
                )
                if (uploadRes.isFailure) {
                    return Result.failure(uploadRes.exceptionOrNull() ?: IllegalStateException("Photo upload failed."))
                }
                val (url, storagePath) = uploadRes.getOrThrow()
                uploadedUrls.add(url)
                uploadedPaths.add(storagePath)
            }

            val resolvedTitle = CommunityDomainHelper.resolvePostTitle(title, body, category)
            val approvalStatus = if (isAdminAuthor) "APPROVED" else "PENDING"
            val payload = mutableMapOf<String, Any>(
                "postId" to postId,
                "authorUid" to userId,
                "authorName" to authorName.trim().ifBlank { "Repair Pro Technician" }.take(80),
                "authorVerified" to false,
                "category" to category,
                "title" to resolvedTitle,
                "body" to body.trim().take(3000),
                "isPinned" to false,
                "approvalStatus" to approvalStatus,
                "likeCount" to 0L,
                "commentCount" to 0L,
                "reportCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            authorPhotoUrl.trim().takeIf { it.startsWith("https://") && it.length <= 1000 }?.let {
                payload["authorPhotoUrl"] = it
            }
            brandName.trim().take(80).takeIf { it.isNotEmpty() }?.let { payload["brandName"] = it }
            modelName.trim().take(100).takeIf { it.isNotEmpty() }?.let { payload["modelName"] = it }
            errorCode.trim().uppercase().take(32).takeIf { it.isNotEmpty() }?.let { payload["errorCode"] = it }
            if (uploadedUrls.isNotEmpty()) {
                payload["photoUrl"] = uploadedUrls.first()
                payload["photoStoragePath"] = uploadedPaths.first()
                payload["photoUrls"] = uploadedUrls
                payload["photoStoragePaths"] = uploadedPaths
            }

            db.collection("community_posts").document(postId).set(payload).await()
            Result.success(approvalStatus)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateOwnPost(
        userId: String,
        postId: String,
        category: String,
        brandName: String,
        modelName: String,
        errorCode: String,
        title: String,
        body: String,
        existingPhotoUrls: List<String>,
        existingStoragePaths: List<String>,
        newPhotos: List<PendingCommunityPhoto> = emptyList(),
        isAdminAuthor: Boolean
    ): Result<String> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val totalPhotoCount = (existingPhotoUrls.size + newPhotos.size).coerceAtMost(4)
            val validationError = CommunityDomainHelper.validatePostDraft(
                title = title,
                body = body,
                category = category,
                hasPhotos = totalPhotoCount > 0
            )
            require(validationError == null) { validationError ?: "Invalid post." }

            val finalUrls = existingPhotoUrls.take(4).toMutableList()
            val finalPaths = existingStoragePaths.take(4).toMutableList()
            val slotsLeft = (4 - finalUrls.size).coerceAtLeast(0)
            newPhotos.take(slotsLeft).forEachIndexed { idx, photo ->
                val res = uploadCommunityPostPhoto(userId, safePostId, photo.bytes, photo.mimeType, finalUrls.size + idx)
                if (res.isFailure) return Result.failure(res.exceptionOrNull() ?: IllegalStateException("Photo upload failed."))
                val (url, storagePath) = res.getOrThrow()
                finalUrls.add(url)
                finalPaths.add(storagePath)
            }

            val nextStatus = if (isAdminAuthor) "APPROVED" else "PENDING"
            val updates = mapOf(
                "category" to category,
                "brandName" to brandName.trim().take(80),
                "modelName" to modelName.trim().take(100),
                "errorCode" to errorCode.trim().uppercase().take(32),
                "title" to CommunityDomainHelper.resolvePostTitle(title, body, category),
                "body" to body.trim().take(3000),
                "photoUrl" to (finalUrls.firstOrNull() ?: ""),
                "photoStoragePath" to (finalPaths.firstOrNull() ?: ""),
                "photoUrls" to finalUrls,
                "photoStoragePaths" to finalPaths,
                "approvalStatus" to nextStatus,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("community_posts").document(safePostId).update(updates).await()
            Result.success(nextStatus)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleLike(
        userId: String,
        postId: String,
        currentlyLiked: Boolean
    ): Result<Boolean> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId/likes/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val postRef = db.collection("community_posts").document(safePostId)
            val postLikeRef = postRef.collection("likes").document(userId)
            val userLikeRef = db.collection("users").document(userId)
                .collection("liked_posts").document(safePostId)

            val batch = db.batch()
            if (currentlyLiked) {
                batch.delete(postLikeRef)
                batch.delete(userLikeRef)
                batch.update(
                    postRef,
                    mapOf(
                        "likeCount" to FieldValue.increment(-1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                val likePayload = mapOf(
                    "postId" to safePostId,
                    "userId" to userId,
                    "createdAt" to FieldValue.serverTimestamp()
                )
                batch.set(postLikeRef, likePayload)
                batch.set(userLikeRef, likePayload)
                batch.update(
                    postRef,
                    mapOf(
                        "likeCount" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(!currentlyLiked)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun addCommentOrReply(
        userId: String,
        authorName: String,
        postId: String,
        body: String,
        parentCommentId: String = "",
        replyToAuthorName: String = "",
        postAuthorUid: String = "",
        replyTargetUid: String = ""
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val commentId = CloudRepository.sanitizeId("cmt_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "community_posts/$safePostId/comments/$commentId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val err = CommunityDomainHelper.validateCommentBody(body)
            require(err == null) { err ?: "Invalid comment." }

            val postRef = db.collection("community_posts").document(safePostId)
            val commentRef = postRef.collection("comments").document(commentId)
            val cleanAuthor = authorName.trim().ifBlank { "Repair Pro Technician" }.take(80)
            val payload = mutableMapOf<String, Any>(
                "commentId" to commentId,
                "postId" to safePostId,
                "parentCommentId" to parentCommentId.trim().take(128),
                "authorUid" to userId,
                "authorName" to cleanAuthor,
                "authorVerified" to false,
                "body" to body.trim().take(1000),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            replyToAuthorName.trim().take(80).takeIf { it.isNotEmpty() }?.let {
                payload["replyToAuthorName"] = it
            }

            val batch = db.batch()
            batch.set(commentRef, payload)
            batch.update(
                postRef,
                mapOf(
                    "commentCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()

            // Send in-app notification to reply target or post author (if not self)
            val targetRecipient = when {
                replyTargetUid.isNotBlank() && replyTargetUid != userId -> replyTargetUid
                postAuthorUid.isNotBlank() && postAuthorUid != userId -> postAuthorUid
                else -> ""
            }
            if (targetRecipient.isNotBlank()) {
                val isReply = parentCommentId.isNotBlank()
                sendBestEffortNotification(
                    recipientUid = targetRecipient,
                    actorUid = userId,
                    type = if (isReply) "REPLY" else "COMMENT",
                    title = if (isReply) "$cleanAuthor replied to your comment" else "$cleanAuthor commented on your post",
                    body = body.trim().take(180),
                    targetRoute = "community/post/$safePostId"
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun editCommentOrReply(
        postId: String,
        commentId: String,
        newBody: String
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val safeCommentId = CloudRepository.sanitizeId(commentId)
        val path = "community_posts/$safePostId/comments/$safeCommentId"
        return try {
            requireUserId()
            val err = CommunityDomainHelper.validateCommentBody(newBody)
            require(err == null) { err ?: "Invalid comment." }
            db.collection("community_posts").document(safePostId)
                .collection("comments").document(safeCommentId)
                .update(
                    mapOf(
                        "body" to newBody.trim().take(1000),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteCommentOrReply(postId: String, commentId: String): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val safeCommentId = CloudRepository.sanitizeId(commentId)
        val path = "community_posts/$safePostId/comments/$safeCommentId"
        return try {
            requireUserId()
            val postRef = db.collection("community_posts").document(safePostId)
            val commentRef = postRef.collection("comments").document(safeCommentId)
            db.runTransaction { tx ->
                val postSnap = tx.get(postRef)
                val currentCount = (postSnap.get("commentCount") as? Number)?.toLong() ?: 0L
                tx.delete(commentRef)
                if (postSnap.exists() && currentCount > 0L) {
                    tx.update(
                        postRef,
                        mapOf(
                            "commentCount" to currentCount - 1L,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleBookmarkPost(
        userId: String,
        post: CommunityPostCloud,
        currentlySaved: Boolean
    ): Result<Boolean> {
        val safePostId = CloudRepository.sanitizeId(post.postId.ifBlank { post.id })
        val path = "users/$userId/saved_posts/$safePostId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            val ref = db.collection("users").document(userId)
                .collection("saved_posts").document(safePostId)
            if (currentlySaved) {
                ref.delete().await()
            } else {
                val payload = mutableMapOf<String, Any>(
                    "userId" to userId,
                    "postId" to safePostId,
                    "title" to post.title.trim().ifBlank { "Community Post" }.take(140),
                    "category" to if (post.category in COMMUNITY_CATEGORIES) post.category else "General",
                    "authorName" to post.authorName.trim().ifBlank { "Technician" }.take(80),
                    "createdAt" to FieldValue.serverTimestamp()
                )
                post.resolvedPhotoUrls().firstOrNull()?.takeIf { it.length <= 1000 }?.let {
                    payload["photoUrl"] = it
                }
                ref.set(payload).await()
            }
            Result.success(!currentlySaved)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun reportCommunityContent(
        userId: String,
        reporterName: String,
        postId: String,
        commentId: String = "",
        reason: String,
        details: String
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val reportId = CloudRepository.sanitizeId("crep_${UUID.randomUUID().toString().replace("-", "").take(16)}")
        val path = "community_reports/$reportId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed." }
            require(CommunityDomainHelper.validateReportReason(reason)) { "Select a valid report reason." }

            val reportRef = db.collection("community_reports").document(reportId)
            val postRef = db.collection("community_posts").document(safePostId)
            val payload = mutableMapOf<String, Any>(
                "reportId" to reportId,
                "postId" to safePostId,
                "reporterUid" to userId,
                "reporterName" to reporterName.trim().ifBlank { "Repair Pro User" }.take(80),
                "reason" to reason,
                "status" to "OPEN",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            commentId.trim().take(128).takeIf { it.isNotEmpty() }?.let { payload["commentId"] = it }
            details.trim().take(600).takeIf { it.isNotEmpty() }?.let { payload["details"] = it }

            val batch = db.batch()
            batch.set(reportRef, payload)
            batch.update(
                postRef,
                mapOf(
                    "reportCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deletePost(
        post: CommunityPostCloud,
        asAdmin: Boolean
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(post.postId.ifBlank { post.id })
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            db.collection("community_posts").document(safePostId).delete().await()
            post.resolvedStoragePaths().forEach { storagePath ->
                if (storagePath.startsWith("community_posts/")) {
                    try {
                        storageProvider().reference.child(storagePath).delete().await()
                    } catch (_: Exception) {
                        // Best-effort cleanup
                    }
                }
            }
            if (asAdmin) {
                logAdminAction(uid, "DELETE_COMMUNITY_POST", "community_posts", safePostId, "Deleted '${post.title.take(80)}'")
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- ADMIN MODERATION WORKFLOW ---
    suspend fun moderatePost(
        postId: String,
        newStatus: String,
        moderationNote: String,
        authorUid: String = "",
        postTitle: String = ""
    ): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        val cleanStatus = when (newStatus) {
            "APPROVED" -> "APPROVED"
            "REJECTED" -> "REJECTED"
            else -> "PENDING"
        }
        return try {
            val uid = requireUserId()
            db.collection("community_posts").document(safePostId).update(
                mapOf(
                    "approvalStatus" to cleanStatus,
                    "moderationNote" to moderationNote.trim().take(500),
                    "reviewedByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            if (authorUid.isNotBlank() && authorUid != uid && cleanStatus in listOf("APPROVED", "REJECTED")) {
                sendBestEffortNotification(
                    recipientUid = authorUid,
                    actorUid = uid,
                    type = if (cleanStatus == "APPROVED") "POST_APPROVED" else "POST_REJECTED",
                    title = if (cleanStatus == "APPROVED") "Community Post Approved" else "Community Post Needs Attention",
                    body = if (cleanStatus == "APPROVED") {
                        "Your post '${postTitle.take(60)}' is now live in Technician Community."
                    } else {
                        "Your post '${postTitle.take(60)}' was rejected.${if (moderationNote.isNotBlank()) " Note: ${moderationNote.trim()}" else ""}"
                    },
                    targetRoute = "community/post/$safePostId"
                )
            }

            logAdminAction(
                uid,
                "MODERATE_COMMUNITY_POST",
                "community_posts",
                safePostId,
                "Status -> $cleanStatus${if (moderationNote.isNotBlank()) " (${moderationNote.trim().take(120)})" else ""}"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun togglePinPost(postId: String, pinned: Boolean): Result<Unit> {
        val safePostId = CloudRepository.sanitizeId(postId)
        val path = "community_posts/$safePostId"
        return try {
            val uid = requireUserId()
            db.collection("community_posts").document(safePostId).update(
                mapOf(
                    "isPinned" to pinned,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            logAdminAction(uid, if (pinned) "PIN_COMMUNITY_POST" else "UNPIN_COMMUNITY_POST", "community_posts", safePostId, "isPinned=$pinned")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateCommunityReportStatus(
        reportId: String,
        newStatus: String,
        adminNote: String
    ): Result<Unit> {
        val safeReportId = CloudRepository.sanitizeId(reportId)
        val path = "community_reports/$safeReportId"
        val cleanStatus = when (newStatus) {
            "REVIEWED", "RESOLVED", "DISMISSED" -> newStatus
            else -> "OPEN"
        }
        return try {
            val uid = requireUserId()
            db.collection("community_reports").document(safeReportId).update(
                mapOf(
                    "status" to cleanStatus,
                    "adminNote" to adminNote.trim().take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            logAdminAction(
                uid,
                "MODERATE_COMMUNITY_REPORT",
                "community_reports",
                safeReportId,
                "Report -> $cleanStatus"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    private suspend fun sendBestEffortNotification(
        recipientUid: String,
        actorUid: String,
        type: String,
        title: String,
        body: String,
        targetRoute: String
    ) {
        try {
            val notifId = CloudRepository.sanitizeId("ntf_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            db.collection("user_notifications").document(notifId).set(
                mapOf(
                    "notificationId" to notifId,
                    "recipientUid" to CloudRepository.sanitizeId(recipientUid),
                    "actorUid" to actorUid.take(128),
                    "type" to type,
                    "title" to title.take(140),
                    "body" to body.take(600),
                    "targetRoute" to targetRoute.take(160),
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (_: Exception) {
            // Non-fatal
        }
    }

    private suspend fun logAdminAction(
        adminUid: String,
        action: String,
        targetType: String,
        targetId: String,
        details: String
    ) {
        try {
            val logId = CloudRepository.sanitizeId("log_${UUID.randomUUID().toString().replace("-", "").take(16)}")
            val email = auth.currentUser?.email ?: "admin@repairpro.local"
            val payload = mapOf(
                "adminUid" to adminUid,
                "adminEmail" to email.take(160),
                "action" to action.take(100),
                "targetType" to targetType.take(64),
                "targetId" to targetId.take(128),
                "details" to details.take(500),
                "createdAt" to FieldValue.serverTimestamp()
            )
            db.collection("audit_logs").document(logId).set(payload).await()
        } catch (_: Exception) {
            // Non-fatal
        }
    }

    private fun logStreamErrorIfActive(
        error: Throwable,
        op: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
    }
}
