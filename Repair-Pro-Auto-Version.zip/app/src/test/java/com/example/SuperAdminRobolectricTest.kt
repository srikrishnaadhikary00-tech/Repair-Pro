package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.RepairProDatabase
import com.example.data.local.SeedDataPart1
import com.example.data.local.SeedDataPart2
import com.example.data.remote.AdminRoleCloud
import com.example.data.remote.AppSettingCloud
import com.example.data.remote.AuditLogCloud
import com.example.data.remote.CatalogEntryCloud
import com.example.data.remote.CommunityPostCloud
import com.example.data.remote.ProblemReportCloud
import com.example.data.remote.TechnicianCloud
import com.example.data.remote.TechnicianVerificationRequestCloud
import com.example.ui.screens.SuperAdminScreen
import com.example.ui.theme.RepairProTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h2600dp")
class SuperAdminRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `non-admin user is blocked by server-side role gate`() {
        composeRule.setContent {
            RepairProTheme {
                SuperAdminScreen(
                    isAdmin = false,
                    isBootstrapAdmin = false,
                    adminRoleChecked = true,
                    currentUserUid = "regular_user_123",
                    adminEmail = "user@example.com",
                    categories = SeedDataPart1.categories,
                    brands = SeedDataPart1.brands,
                    totalModels = 42,
                    errorCodes = SeedDataPart1.acErrorCodes + SeedDataPart2.fridgeAndWasherErrorCodes,
                    problems = SeedDataPart1.acProblems + SeedDataPart2.fridgeAndWasherProblems,
                    allReports = emptyList(),
                    allCatalog = emptyList(),
                    auditLogs = emptyList(),
                    adminRoles = emptyList(),
                    adMobConfig = AppSettingCloud(id = "admob_config", configType = "ADMOB"),
                    globalConfig = AppSettingCloud(id = "global_config", configType = "GLOBAL"),
                    onBack = {},
                    onUpdateReportStatus = { _, _, _ -> },
                    onPublishCatalogEntry = { _, _ -> },
                    onDeleteCatalogEntry = {},
                    onSaveAdMobConfig = {},
                    onSaveGlobalConfig = { _, _, _ -> },
                    onUpsertAdminRole = { _, _ -> },
                    onRevokeAdminRole = {},
                    onExportBackupJson = { "{}" }
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_access_denied_view").assertIsDisplayed()
        composeRule.onNodeWithText("Super Admin access required").assertIsDisplayed()
    }

    @Test
    fun `super admin navigates v2 modules publishes catalog saves admob and moderates community and verification`() {
        var publishedEntry: CatalogEntryCloud? = null
        var savedAdMob: AppSettingCloud? = null
        var verifiedStatus: String? = null
        var publishedAnnouncementTitle: String? = null

        val sampleReport = ProblemReportCloud(
            id = "rep_1",
            userId = "u1",
            categoryId = "ac",
            brandName = "Daikin",
            errorCode = "U4",
            description = "Indoor outdoor communication loss",
            status = "PENDING"
        )
        val sampleCatalog = CatalogEntryCloud(
            id = "cat_cloud_1",
            entryType = "ERROR_CODE",
            categoryId = "washer",
            brandName = "LG",
            code = "OE",
            titleEn = "Drain Pump Fault",
            titleBn = "ড্রেন পাম্প সমস্যা",
            titleHi = "ड्रेन पंप त्रुटि",
            summaryEn = "Machine failed to drain water within 10 minutes.",
            published = true,
            revision = 1L
        )
        val sampleLog = AuditLogCloud(
            id = "log_1",
            adminUid = "admin_1",
            adminEmail = "srikrishnaadhikary00@gmail.com",
            action = "UPDATE_ADMOB_CONFIG",
            targetType = "app_settings",
            targetId = "admob_config",
            details = "Global=true"
        )
        val sampleRole = AdminRoleCloud(id = "admin_1", userId = "admin_1", role = "SUPER_ADMIN")
        val sampleVerification = TechnicianVerificationRequestCloud(
            id = "tech_u2",
            userId = "tech_u2",
            fullName = "Arjun Das",
            mobileNumber = "+91 98300 11223",
            fullAddress = "22 Salt Lake Sector V",
            state = "West Bengal",
            district = "North 24 Parganas",
            cityArea = "Salt Lake",
            pinCode = "700091",
            serviceCategories = listOf("AC", "Refrigerator"),
            experience = "8 Years",
            status = "PENDING"
        )
        val samplePost = CommunityPostCloud(
            id = "post_1",
            postId = "post_1",
            authorUid = "tech_u2",
            authorName = "Arjun Das",
            category = "AC",
            title = "Inverter Outdoor PCB Fix",
            body = "Checked 15V regulator and replaced shorted diode.",
            approvalStatus = "PENDING"
        )

        composeRule.setContent {
            RepairProTheme {
                SuperAdminScreen(
                    isAdmin = true,
                    isBootstrapAdmin = true,
                    adminRoleChecked = true,
                    currentUserUid = "admin_1",
                    adminEmail = "srikrishnaadhikary00@gmail.com",
                    categories = SeedDataPart1.categories,
                    brands = SeedDataPart1.brands,
                    totalModels = 42,
                    errorCodes = SeedDataPart1.acErrorCodes + SeedDataPart2.fridgeAndWasherErrorCodes,
                    problems = SeedDataPart1.acProblems + SeedDataPart2.fridgeAndWasherProblems,
                    allReports = listOf(sampleReport),
                    allCatalog = listOf(sampleCatalog),
                    auditLogs = listOf(sampleLog),
                    adminRoles = listOf(sampleRole),
                    adMobConfig = AppSettingCloud(id = "admob_config", configType = "ADMOB", adsGlobalEnabled = true),
                    globalConfig = AppSettingCloud(id = "global_config", configType = "GLOBAL"),
                    onBack = {},
                    onUpdateReportStatus = { _, _, _ -> },
                    onPublishCatalogEntry = { entry, onDone ->
                        publishedEntry = entry
                        onDone()
                    },
                    onDeleteCatalogEntry = {},
                    onSaveAdMobConfig = { savedAdMob = it },
                    onSaveGlobalConfig = { _, _, _ -> },
                    onUpsertAdminRole = { _, _ -> },
                    onRevokeAdminRole = {},
                    onExportBackupJson = { "{\"ok\":true}" },
                    allCommunityPosts = listOf(samplePost),
                    verificationRequests = listOf(sampleVerification),
                    onReviewVerification = { _, newStatus, _ -> verifiedStatus = newStatus },
                    onPublishAnnouncement = { title, _, _, _, onDone ->
                        publishedAnnouncementTitle = title
                        onDone()
                    }
                )
            }
        }
        composeRule.waitForIdle()

        // 1. Dashboard visible
        composeRule.onNodeWithText("Live System Metrics").assertIsDisplayed()

        // 2. Navigate to Appliances (AC / Fridge / Washer)
        composeRule.onNodeWithTag("admin_tab_1").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_appliance_card_ac").assertIsDisplayed()
        composeRule.onNodeWithTag("admin_appliance_card_fridge").assertIsDisplayed()
        composeRule.onNodeWithTag("admin_appliance_card_washer").assertExists()

        // 3. Navigate to Catalog & Guides and publish a multilingual entry
        composeRule.onNodeWithTag("admin_tab_2").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_catalog_brand").performTextInput("Samsung")
        composeRule.onNodeWithTag("admin_catalog_code").performTextInput("E101")
        composeRule.onNodeWithTag("admin_catalog_title_en").performTextInput("Communication Error")
        composeRule.onNodeWithTag("admin_catalog_summary_en").performTextInput("Indoor and outdoor PCB lost signal.")
        composeRule.onNodeWithTag("admin_publish_catalog_button").performClick()
        composeRule.waitForIdle()

        assertNotNull(publishedEntry)
        assertEquals("Samsung", publishedEntry?.brandName)
        assertEquals("E101", publishedEntry?.code)
        assertEquals("Communication Error", publishedEntry?.titleEn)

        // 4. Navigate to Reports tab
        composeRule.onNodeWithTag("admin_tab_3").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("User Submitted Reports (1)").assertIsDisplayed()

        // 5. Navigate to AdMob Ads tab, toggle kill switch, and save
        composeRule.onNodeWithTag("admin_tab_4").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admob_kill_switch").performClick()
        composeRule.onNodeWithTag("admob_save_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertNotNull(savedAdMob)
        assertTrue(savedAdMob!!.emergencyKillSwitch)

        // 6. Navigate to Roles & Logs tab
        composeRule.onNodeWithTag("admin_tab_6").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_content_list").performScrollToNode(hasTestTag("admin_audit_heading"))
        composeRule.onNodeWithText("Immutable Admin Audit Logs (1)").assertIsDisplayed()

        // 7. Navigate to Community tab
        composeRule.onNodeWithTag("admin_tab_8").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_community_heading").assertIsDisplayed()

        // 8. Navigate to Verifications tab and approve pending technician
        composeRule.onNodeWithTag("admin_tab_9").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_verification_heading").assertIsDisplayed()
        composeRule.onNodeWithTag("admin_verify_approve_tech_u2").performClick()
        composeRule.waitForIdle()
        assertEquals("VERIFIED", verifiedStatus)

        // 9. Navigate to PDFs & Diagrams tab
        composeRule.onNodeWithTag("admin_tab_10").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_docs_heading").assertIsDisplayed()

        // 10. Navigate to Notifications tab and publish an announcement
        composeRule.onNodeWithTag("admin_tab_11").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_announcements_heading").assertIsDisplayed()
        composeRule.onNodeWithTag("admin_ann_title").performTextInput("New Daikin Manuals")
        composeRule.onNodeWithTag("admin_ann_body").performTextInput("Updated inverter PCB diagrams uploaded.")
        composeRule.onNodeWithTag("admin_ann_publish_button").performClick()
        composeRule.waitForIdle()
        assertEquals("New Daikin Manuals", publishedAnnouncementTitle)
    }

    @Test
    fun `base room catalog seeds ac fridge washer data`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, RepairProDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val dao = db.repairDao()
            dao.upsertCategories(SeedDataPart1.categories)
            dao.upsertBrands(SeedDataPart1.brands)
            dao.upsertErrorCodes(SeedDataPart1.acErrorCodes + SeedDataPart2.fridgeAndWasherErrorCodes)
            dao.upsertProblems(SeedDataPart1.acProblems + SeedDataPart2.fridgeAndWasherProblems)

            val cats = dao.observeCategories().first()
            assertEquals(3, cats.size)
            assertTrue(cats.any { it.id == "ac" })
            assertTrue(cats.any { it.id == "fridge" })
            assertTrue(cats.any { it.id == "washer" })
            assertTrue(dao.observeAllErrorCodes().first().isNotEmpty())
            assertTrue(dao.observeAllProblems().first().isNotEmpty())
        } finally {
            db.close()
        }
    }

    @Test
    fun `super admin manages technicians adds new technician and toggles active status`() {
        var savedTech: TechnicianCloud? = null
        var toggledTech: TechnicianCloud? = null
        val existingTech = TechnicianCloud(
            id = "tech_existing",
            technicianId = "tech_existing",
            fullName = "Suman Roy",
            mobileNumber = "+91 98310 55667",
            fullAddress = "12 MG Road",
            state = "West Bengal",
            district = "Kolkata",
            cityArea = "Park Street",
            pinCode = "700016",
            serviceCategories = listOf("AC", "Refrigerator"),
            experience = "6 Years",
            status = "ACTIVE"
        )

        composeRule.setContent {
            RepairProTheme {
                SuperAdminScreen(
                    isAdmin = true,
                    isBootstrapAdmin = true,
                    adminRoleChecked = true,
                    currentUserUid = "admin_1",
                    adminEmail = "srikrishnaadhikary00@gmail.com",
                    categories = SeedDataPart1.categories,
                    brands = SeedDataPart1.brands,
                    totalModels = 42,
                    errorCodes = SeedDataPart1.acErrorCodes,
                    problems = SeedDataPart1.acProblems,
                    allReports = emptyList(),
                    allCatalog = emptyList(),
                    auditLogs = emptyList(),
                    adminRoles = emptyList(),
                    adMobConfig = AppSettingCloud(id = "admob_config", configType = "ADMOB"),
                    globalConfig = AppSettingCloud(id = "global_config", configType = "GLOBAL"),
                    onBack = {},
                    onUpdateReportStatus = { _, _, _ -> },
                    onPublishCatalogEntry = { _, _ -> },
                    onDeleteCatalogEntry = {},
                    onSaveAdMobConfig = {},
                    onSaveGlobalConfig = { _, _, _ -> },
                    onUpsertAdminRole = { _, _ -> },
                    onRevokeAdminRole = {},
                    onExportBackupJson = { "{}" },
                    allTechnicians = listOf(existingTech),
                    onSaveTechnician = { tech, _, _, onDone ->
                        savedTech = tech
                        onDone()
                    },
                    onToggleTechnicianStatus = { toggledTech = it },
                    onDeleteTechnician = {}
                )
            }
        }
        composeRule.waitForIdle()

        // Navigate to Technicians tab (index 7)
        composeRule.onNodeWithTag("admin_tab_7").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("admin_technicians_heading").assertIsDisplayed()

        // Add new technician via editor form
        composeRule.onNodeWithTag("admin_tech_name").performTextInput("Bikash Sen")
        composeRule.onNodeWithTag("admin_tech_mobile").performTextInput("+91 98301 22334")
        composeRule.onNodeWithTag("admin_tech_address").performTextInput("45 College Street")
        composeRule.onNodeWithTag("admin_tech_state").performTextInput("West Bengal")
        composeRule.onNodeWithTag("admin_tech_district").performTextInput("Kolkata")
        composeRule.onNodeWithTag("admin_tech_area").performTextInput("Sealdah")
        composeRule.onNodeWithTag("admin_tech_pin").performTextInput("700009")
        composeRule.onNodeWithTag("admin_save_tech_button").performClick()
        composeRule.waitForIdle()

        assertNotNull(savedTech)
        assertEquals("Bikash Sen", savedTech?.fullName)
        assertEquals("Kolkata", savedTech?.district)
        assertEquals("ACTIVE", savedTech?.status)

        // Toggle existing technician status (deactivate)
        composeRule.onNodeWithTag("admin_content_list").performScrollToNode(hasTestTag("admin_tech_toggle_tech_existing"))
        composeRule.onNodeWithTag("admin_tech_toggle_tech_existing").performClick()
        composeRule.waitForIdle()
        assertEquals("tech_existing", toggledTech?.id)
    }
}
